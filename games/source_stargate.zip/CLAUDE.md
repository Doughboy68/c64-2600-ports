# Stargate: Atari 2600 to Commodore 64, the source (version 1.0)

This folder is everything that makes the C64 version of Stargate (Atari 2600, 1984): the C64 port's
source, its checking tools and the shared tools, from <https://doughboy68.github.io/c64-2600-ports/>
(project: github.com/Doughboy68/c64-2600-ports; the port by Claude and Doughboy68). The disassembly
of the original 2600 program, `games/stargate/2600/stargate.asm`, was made in your browser from your own
ROM: the site holds no original game code. Keep it that way if you share your changes: no ROMs,
no disassembly, no built `.prg` / `.d64` (they contain the original code).

## What you need

* The original cartridge ROM (MD5 `0c48e820301251fbb6bcdc89bd3555d9`, any file name, or its .zip) in `roms_port/`.
* Node.js (the tools are plain JavaScript, no packages).
* 64tass 1.60 as `tools/64tass/64tass.exe` (<https://sourceforge.net/projects/tass64/>).
* VICE (`x64sc`, and `c1541` for the disk image) on the PATH, for the disk image and the VICE tools.

## Build

`games/stargate/build.cmd` (Windows; elsewhere run its steps by hand). It rebuilds the ROM from the
disassembly and checks it's identical to yours, then assembles the C64 version:
`games/stargate/build/stargate-1.0.prg` and `.d64`. If `2600/stargate.asm` is missing it makes it from your
ROM with `node tools/disasm.js games/stargate` (names and notes come from `2600/symbols.js`).

## Where things are

* `games/stargate/README.md`: controls, how the port works, differences from the 2600, and "How it
  was checked": the tools in `games/stargate/tools/` and what each one proves.
* `games/stargate/HANDOFF.md`: where the work stands, what's open, the checks to run.
* `games/stargate/2600/`: `symbols.js` (names and notes for the 2600's RAM and routines),
  `RAM-MAP.md` (made from it), the disassembly (made from your ROM).
* `games/stargate/c64/`: the C64 port, 64tass source.
* `tools/`: shared tools (`rom.js` finds the ROM by MD5, `vcs.js` a small scriptable 2600 emulator,
  `disasm.js` the disassembler, `vicemon.js` / `vice.js` drive VICE's remote monitor,
  `buildname.js` the build's file names).
* `README.md`: the whole project (other games too), its layout and standard controls.

## Conventions (keep them when changing it)

* The original 2600 program runs on the C64 almost unchanged (a few patches, listed in the C64
  source); new C64 code does what the 2600's hardware did. Check changes with the game's tools
  (lockstep: the game's RAM identical to the 2600's every frame; screencheck: the picture).
* Standard keys: F1 Game Reset (fire also starts a game), F2 power off and on, F3 Game Select,
  F5 colour / B&W, F7 / F8 difficulties, F flicker on / off (in games that flicker); W A S D +
  Space for player 1. Controls and credits go in the BASIC listing (`LIST`).
* The version is in the BASIC listing (`" version X.Y"`); build files are named
  `<short name>-<version>`, at most 16 characters (a C64 file name).
