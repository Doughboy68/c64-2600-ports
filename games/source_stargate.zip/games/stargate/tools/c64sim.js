// The C64 version's code on a plain 6502 (the 6502 core of tools/vcs.js) with 64K of RAM,
// for lockstep.js and screencheck.js. $D000-$DFFF is I/O when the CPU port ($01) says so;
// I/O writes land in `io` (colour RAM writes also in `colram`). Set up like Start: the 2600
// program copied to $D000 / $F000 and patched, the tables and video set up.
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const ROMMD5 = require('../2600/symbols.js').game.md5;
const rom = require('../../../tools/rom').load(ROMMD5);
const build = process.env.SG_BUILD || path.join(__dirname, '..', 'build');   // (SG_BUILD: another build's folder)

class C64 extends VCS {
  constructor() {
    super(rom);
    this.mem = new Uint8Array(65536);
    this.io = new Uint8Array(4096);
    this.colram = new Uint8Array(1024);
    const f = require('../../../tools/buildname').files(build);
    const prg = fs.readFileSync(f.prg);
    this.lst = fs.readFileSync(f.lst, 'latin1');
    this.mem.set(prg.subarray(2), prg.readUInt16LE(0));
  }
  ioOn() { return (this.mem[1] & 3) !== 0 && (this.mem[1] & 4) !== 0; }
  read(a) { a &= 0xFFFF; return a >= 0xD000 && a < 0xE000 && this.ioOn() ? this.io[a - 0xD000] : this.mem[a]; }
  write(a, v) {
    a &= 0xFFFF;
    if (a >= 0xD000 && a < 0xE000 && this.ioOn()) { this.io[a - 0xD000] = v; if (a >= 0xD800 && a < 0xDC00) this.colram[a - 0xD800] = v & 15; }
    else this.mem[a] = v;
  }
  commit() {} flush() {} tick(n) { this.cycles += n; }
  sym(name) {
    // (part 2's and 3's lines: the load address, then the run address)
    const m = this.lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t](?:([0-9a-f]{4})[ \\t])?.*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
    if (m) return parseInt(m[2] || m[1], 16);
    const e = this.lst.match(new RegExp(`^${name}\\s*=\\s*\\$([0-9a-f]+)`, 'mi'));
    if (e) return parseInt(e[1], 16);
    throw new Error('no symbol ' + name);
  }
  call(addr, limit = 3e6) {      // JSR addr from a stub, run until it returns
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    const start = this.cycles;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error('runaway at $' + this.pc.toString(16)); }
    return this.cycles - start;
  }
  // what Start does that matters here
  start(pal = true) {
    const m = this.mem, img = this.sym('GameImage');
    this.s = 0xFF;
    m[1] = 0x35;
    m.copyWithin(0xD000, img, img + 0x1000);
    m.copyWithin(0xF000, img + 0x1000, img + 0x2000);
    for (let p = this.sym('Patches'); ;) {             // address, count, bytes
      const a = m[p] | m[p + 1] << 8;
      if (!a) break;
      const n = m[p + 2];
      for (let i = 0; i < n; i++) m[a + i] = m[p + 3 + i];
      p += 3 + n;
    }
    m.fill(0, 0xF080, 0xF100);
    const w = (a, v) => { m[a] = v & 255; m[a + 1] = v >> 8; };
    w(0xFFFA, this.sym('Nmi')); w(0xFFFE, this.sym('Irq'));
    m[0x0280] = 0xFF; m[0x0282] = 0x0B; m[0x0285] = 0x80; m[0x3C] = m[0x3D] = 0x80;
    m[this.sym('firstTick')] = 1;
    m[this.sym('switches')] = 0x0B;
    m[this.sym('isPal')] = pal ? 1 : 0;
    this.call(this.sym('InitTables'));
    this.call(this.sym('InitVars'));
    this.call(this.sym('CopyPart2'));
    this.call(this.sym('InitPos'));
    this.call(this.sym('InitVideo'));
  }
}
module.exports = { C64, rom, ROMMD5 };
