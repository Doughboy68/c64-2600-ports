// Run the C64 version's game ticks (the patched 2600 program plus the capture code, from
// build/stargate-<version>.prg) on a plain 6502 (tools/c64sim.js), side by side with the
// original game in tools/vcs.js, with the same inputs (tools/play.js). Once a frame both stop
// after the picture: the game RAM and the SuperChip RAM must be identical, and the collision
// bits the game reads (CXM0P, CXP0FB bit 7). Any difference is a bug in a patch or in what
// the C64 code leaves in RAM for the kernel. Also runs Render each frame and reports the
// cycles both take.
//   node games/stargate/tools/lockstep.js [frames] [--seed=N] [--cheat] [--ntsc] [--pal]
//        [--power=N] [--verbose] [--profile]
// --pal: draw only 5 of every 6 ticks, as a PAL C64 does (its 50 Hz frames run 6 ticks every 5)
// --power=N: at frame N press F2 (power off and on) on the C64, and switch on a new 2600.
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 3000);
const verbose = process.argv.includes('--verbose');

const c64 = new C64();
c64.start(!process.argv.includes('--ntsc'));
const sym = n => c64.sym(n);
const profile = process.argv.includes('--profile') ? {} : null;
// (labels at their run-time address: part 2's lines list the load address, then the logical one)
const labels = [...c64.lst.matchAll(/^\.([0-9a-f]{4})\t(?:([0-9a-f]{4})\t)?(?:.*\t)?([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[2] || m[1], 16), m[3]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => {
  if (pc >= 0x5000 && pc < 0x6000) return 'layer code 0';
  if (pc >= 0xE000 && pc < 0xF000) return 'layer code 1';
  if (pc >= 0xD000) return '2600 program';
  let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r;
};
let phase = 'tick';                               // (--profile: the tick's and the render's apart)
const entry = new Set(labels.map(l => l[0])), calls = {};
if (profile) { profile.tick = {}; profile.render = {}; const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc), t = profile[phase]; t[k] = (t[k] || 0) + this.cycles - c; if (entry.has(pc)) calls[k] = (calls[k] || 0) + 1; return r; }; }

// ---- the original: stop once a frame where the game resumes after the picture
const RESUME = 0xD16C;
let vcs, atResume = false, resumeFrame = -1;
const newVcs = () => {
  vcs = new VCS(rom); vcs.superChip = true; vcs.hmoveBlank = true; resumeFrame = -1;
  const origStep = vcs.step.bind(vcs);
  vcs.step = function () {
    if (this.pc === RESUME && this.frames !== resumeFrame) { atResume = true; resumeFrame = this.frames; }
    return origStep();
  };
};
newVcs();
const runToResume = () => { atResume = false; let g = 0; while (!atResume) { vcs.step(); if (++g > 2e6) throw new Error('2600 never got past the picture'); } };

// The stack ($FE/$FF: the 2600's is in its RAM, the C64's in page 1) isn't compared.
const IGNORE = new Set([0xFE, 0xFF]);
const NAMES = {};
const S = require('../2600/symbols.js');
for (const [a, n, size] of S.ram) for (let i = 0; i < size; i++) NAMES[a + i] = size > 1 ? `${n}+${i}` : n;
for (const [a, n, size] of S.xram || []) for (let i = 0; i < size; i++) NAMES[a + i] = size > 1 ? `${n}+${i}` : n;

if (process.argv.includes('--noflicker')) c64.mem[sym('Flicker')] = 0;   // (flicker off: the game's hidden objects drawn too)
const play0 = require('./play')(arg('seed', 11));
// --idle=N: from frame N no input, and the game's idle counter ($F0FD) at $80: idle mode at once
const idleAt = arg('idle', -1);
const play = (f, ram) => {
  if (idleAt < 0 || f < idleAt) return play0(f, ram);
  if (f === idleAt) { vcs.xram[0x7D] = 0x80; c64.mem[0xF0FD] = 0x80; }
  return { swcha: 0xFF, swchb: 0x0B, fire: [false, false] };
};
const cheat = process.argv.includes('--cheat') ? require('./cheat')() : null;
let bad = 0, done = 0, maxTick = 0, totalTick = 0, maxRender = 0, totalRender = 0;
const diffCount = {};
const powerAt = arg('power', -1);
for (let f = 0; f < frames; f++) {
  if (f === powerAt) {                            // F2: power off and on
    c64.call(sym('PowerCycle'));
    newVcs();
    console.log(`frame ${f}: power off and on`);
  }
  if (cheat) {                                    // (the same cheat on both)
    cheat(f, vcs.ram, vcs.xram);
    c64.mem.set(vcs.ram.subarray(0, 0x7E), 0x80);
    c64.mem.set(vcs.xram, 0xF080);
  }
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire = p.fire;
  c64.mem[0x0280] = p.swcha; c64.mem[0x0282] = p.swchb; c64.mem[0x3C] = p.fire[0] ? 0 : 0x80; c64.mem[0x3D] = p.fire[1] ? 0 : 0x80;
  runToResume();
  const cyc = c64.call(sym('Tick'));
  maxTick = Math.max(maxTick, cyc); totalTick += cyc;
  done++;
  if (!(process.argv.includes('--pal') && f % 6 === 5)) {
    c64.mem[sym('pending')] = 0;                  // draw it, as the main loop would
    c64.mem[sym('curBuf')] ^= 1;                  // (and show it)
    phase = 'render';
    const rc = c64.call(sym('Render'));
    phase = 'tick';
    if (f >= 30) maxRender = Math.max(maxRender, rc);
    totalRender += rc;
  }
  const diffs = [];
  for (let a = 0x80; a < 0x100; a++) if (!IGNORE.has(a) && vcs.ram[a - 0x80] !== c64.mem[a]) {
    diffs.push(`${NAMES[a] || '$' + a.toString(16)} 2600 ${vcs.ram[a - 0x80].toString(16)} C64 ${c64.mem[a].toString(16)}`);
    diffCount[a] = (diffCount[a] || 0) + 1;
  }
  for (let i = 0; i < 128; i++) if (vcs.xram[i] !== c64.mem[0xF080 + i]) {
    const a = 0xF080 + i;
    diffs.push(`${NAMES[a] || '$' + a.toString(16)} 2600 ${vcs.xram[i].toString(16)} C64 ${c64.mem[a].toString(16)}`);
    diffCount[a] = (diffCount[a] || 0) + 1;
  }
  const cxA = vcs.tiaRead(0) & 0x80, cxB = vcs.tiaRead(2) & 0x80;
  if (cxA !== (c64.mem[0x30] & 0x80)) diffs.push(`CXM0P 2600 ${cxA.toString(16)} C64 ${(c64.mem[0x30] & 0x80).toString(16)}`);
  if (cxB !== (c64.mem[0x32] & 0x80)) diffs.push(`CXP0FB 2600 ${cxB.toString(16)} C64 ${(c64.mem[0x32] & 0x80).toString(16)}`);
  if (diffs.length) {
    bad++;
    if (bad <= 5 || verbose) console.log(`frame ${f}: ${diffs.join(', ')}`);
    for (let a = 0x80; a < 0x100; a++) if (!IGNORE.has(a)) c64.mem[a] = vcs.ram[a - 0x80];   // resync and carry on
    c64.mem.set(vcs.xram, 0xF080);
    c64.mem[0x30] = cxA; c64.mem[0x32] = cxB;
  }
}
if (bad) console.log('bytes that differed (frames):', Object.entries(diffCount).map(([a, n]) => `${NAMES[a] || '$' + (+a).toString(16)} ${n}`).join(', '));
if (profile) for (const ph of ['tick', 'render']) {
  const t = profile[ph], tot = Object.values(t).reduce((a, b) => a + b, 0);
  console.log(`-- ${ph}: ${Math.round(tot / done)} cycles a frame on average`);
  for (const [k, v] of Object.entries(t).sort((a, b) => b[1] - a[1]).slice(0, 24)) console.log(k.padEnd(16), String(Math.round(v / done)).padStart(7), (100 * v / tot).toFixed(1).padStart(5) + '%', calls[k] ? ((calls[k] / done).toFixed(1) + ' calls a frame').padStart(20) : '');
}
console.log(`${done} frames, ${bad} with differences; C64 tick ${Math.round(totalTick / done)} cycles on average, ${maxTick} at most; render ${Math.round(totalRender / done)} on average, ${maxRender} at most`);
