// A random player for the checks (model.js, lockstep.js, screencheck.js): the same inputs
// from the same seed. Flies about and fires most of the time; now and then the right
// joystick (inviso up, hyperspace down, smartbomb on its fire button). Between games it
// waits a little and presses Game Reset.
//   const play = require('./play')(seed);  play(frame, ram) -> { swcha, swchb, fire: [left, right] }
module.exports = function (seed, opts = {}) {
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const DIRS = [0xF, 0x7, 0xB, 0xE, 0xD, 0x6, 0x5, 0xA, 0x9];   // none, R, L, U, D, diagonals
  let left = 0xF, right = 0xF, fire = false, fire2 = false, between = 0;
  return function (f, ram) {
    const R = a => ram[a - 0x80];
    const swchb = 0x0B | (opts.diff || 0);
    if (!R(0x82)) {                                // no game running
      if (between === 0) between = 30 + Math.floor(rnd() * 90);
      between--;
      return { swcha: 0xFF, swchb: between <= 4 ? swchb & ~1 : swchb, fire: [false, false] };
    }
    between = 0;
    if (f % 10 === 0) {
      const r = rnd();
      left = r < 0.25 ? 0x7 : r < 0.4 ? 0xB : DIRS[Math.floor(rnd() * 9)];
      fire = rnd() < 0.6;
      right = rnd() < 0.04 ? [0xE, 0xD][Math.floor(rnd() * 2)] : 0xF;
      fire2 = rnd() < 0.02;
    }
    return { swcha: left << 4 | right, swchb, fire: [fire && f % 4 < 2, fire2] };
  };
};
