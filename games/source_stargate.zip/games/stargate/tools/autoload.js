// Speed: the auto game on the simulator: tick + render cycles per frame (median, 90%, 99%, max,
// how many frames over 12K ... 20K).
//   node games/stargate/tools/autoload.js [--ntsc]
const { C64 } = require('./c64sim');
const c64 = new C64(); c64.start(!process.argv.includes('--ntsc'));
const sym = n => c64.sym(n), M = c64.mem;
M[sym('DbgAuto')] = 1; c64.call(sym('PowerCycle'));
const all = []; let f = 0;
while (M[sym('DbgAuto')] && f < 9000) {
  const t = c64.call(sym('Tick'));
  M[sym('pending')] = 0; M[sym('curBuf')] ^= 1; const r = c64.call(sym('Render'));
  f++;
  if (f > 300) all.push([t + r, t, r, f, M[sym('CapKind')]]);
}
const s = all.map(a => a[0]).sort((a, b) => a - b), q = p => s[Math.floor(p * (s.length - 1))];
console.log(`${f} ticks, wave ${M[0x89]}; tick + render: median ${q(.5)}, 90% ${q(.9)}, 99% ${q(.99)}, max ${q(1)}; avg ${Math.round(s.reduce((a, b) => a + b) / s.length)}; tick avg ${Math.round(all.reduce((a, b) => a + b[1], 0) / all.length)}`);
for (const lim of [12000, 13000, 14000, 14500, 15000, 16000, 20000]) console.log(`  over ${lim}: ${s.filter(v => v > lim).length}`);
