// Test cheats (--cheat in the checks): reach later waves and the wave-end screens quickly.
// With a game running: ships left held at 3, and every `every` frames (on an even frame) the
// wave's enemies cleared and its timer ($A8) set so the wave ends: then the bonus screen and
// the next wave. ram / xram: the 2600's RAM ($80-$FF) and SuperChip RAM ($F080-$F0FF) as arrays.
//   const cheat = require('./cheat')(every);  cheat(frame, ram, xram)
module.exports = (every = 900) => (f, ram, xram) => {
  if (!ram[0x82 - 0x80]) return;
  ram[0x82 - 0x80] = 3;
  if (f % every < 2 && !(ram[0x81 - 0x80] & 1) && !ram[0xAA - 0x80]) {
    for (let i = 0x22; i <= 0x30; i++) xram[i] = 0;
    ram[0xA8 - 0x80] = 5;
  }
};
