// Facts for the C64 design from the model over random play: enemies per frame (player 0
// stretches), their heights, vertical gaps, colours per enemy (as C64 colours), stars and
// mountains (missile 1 / ball pixels per frame), the laser.
//   node games/stargate/tools/stats.js [frames] [seed]
const { VCS } = require('../../../tools/vcs');
const model = require('./model');
const MAP = [0,11,11,12,15,15,1,1, 9,9,8,8,7,7,7,7, 9,9,8,8,10,10,15,15, 2,9,8,10,10,10,10,10, 2,2,2,10,10,10,10,10, 4,4,4,4,10,10,10,10, 6,4,4,4,4,14,14,14, 6,6,6,14,14,14,14,1, 6,6,6,14,14,14,3,3, 6,6,14,14,14,14,3,3, 11,11,14,14,3,3,3,3, 11,5,5,5,13,13,13,13, 5,5,5,5,13,13,13,13, 5,5,5,5,13,13,13,13, 9,9,5,5,13,13,7,7, 9,9,8,8,7,7,7,7];
const frames = +(process.argv[2] || 3000);
const play = require('./play')(+(process.argv[3] || 1));
const vcs = new VCS(model.rom);
vcs.superChip = true; vcs.hmoveBlank = true;
let st = null, stF = -1;
const os = vcs.step.bind(vcs);
vcs.step = function () { if (this.pc === model.KERNEL && this.frames !== stF) { st = model.snap(this); stF = this.frames; } return os(); };
const hist = {}, h = (k, v) => { hist[k] = hist[k] || {}; hist[k][v] = (hist[k][v] || 0) + 1; };
for (let f = 0; f < frames; f++) {
  const p = play(f, vcs.ram); vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire = p.fire;
  st = null; vcs.runFrames(1);
  if (!st) continue;
  const m = model.render(st);
  if (m.sch.kind !== 'field') continue;
  // player 0 stretches: runs of lines with P0 pixels
  const runs = []; let cur = null;
  for (let y = 84; y < 224; y++) {
    let any = false; const cols = new Set();
    for (let x = 0; x < 160; x++) if (m.ob[y * 160 + x] & 1) { any = true; cols.add(MAP[m.fb[y * 160 + x]]); }
    if (any) { if (!cur || cur.end !== y - 1) runs.push(cur = { start: y, end: y, cols: new Set() }); cur.end = y; cols.forEach(c => cur.cols.add(c)); }
  }
  h('enemies per frame', runs.length);
  runs.forEach((r, i) => { h('enemy height', r.end - r.start + 1); h('colours per enemy', r.cols.size); if (i) h('gap to the one above', Math.min(r.start - runs[i - 1].end, 30)); });
  let m1 = 0, bl = 0, pf = 0, m0 = 0;
  for (let i = 84 * 160; i < 224 * 160; i++) { const o = m.ob[i]; if (o & 8) m1++; if (o & 16) bl++; if (o & 32) pf++; if (o & 4) m0++; }
  h('M1 pixels', Math.min(Math.round(m1 / 20) * 20, 400)); h('BL pixels', Math.min(Math.round(bl / 20) * 20, 400)); h('laser pixels', Math.round(pf / 10) * 10); h('M0 pixels', m0);
}
for (const [k, v] of Object.entries(hist)) console.log(k + ':', Object.entries(v).sort((a, b) => a[0] - b[0]).map(([a, n]) => `${a}x${n}`).join(' '));
