// Speed: the whole C64 program on the simulator with a raster: the main loop and the raster
// interrupts run as on the C64 (the frame top, the schedule, the frame end), the VIC's badlines
// and sprite fetches take their cycles from the CPU. The C64 plays by itself (DbgAuto, as
// tools/c64late.js), and the same counters are read (the timing aids off: DbgOn costs cycles; --poke=DbgOn:1), a quick stand-in for c64late in VICE, to
// compare main-loop ideas. No keyboard or joysticks (the auto game sets the inputs).
//   node games/stargate/tools/loopsim.js [--ntsc] [--steal=N] [--prof[=N]]
// (--steal: extra cycles a frame, a fudge; --prof: the N routines that took the most cycles a
// frame, the waiting loop included)
// (SG_BUILD: another build's folder)
const { C64 } = require('./c64sim');
const ntsc = process.argv.includes('--ntsc');
const num = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const LINES = ntsc ? 263 : 312, CPL = ntsc ? 65 : 63;
const EXTRA = num('steal', 0);

class Raster extends C64 {
  constructor() {
    super();
    this.line = 0; this.lineStart = 0;    // the raster line and the cycle it started on
    this.cmp = 0; this.irqFlag = 0;
    this.irqCyc = 0; this.vicCyc = 0; this.inIrq = false;   // (cycles in the interrupts, taken by the VIC)
  }
  read(a) {
    a &= 0xFFFF;
    if (a >= 0xD000 && a < 0xE000 && this.ioOn()) {
      if (a === 0xD012) return this.line & 255;
      if (a === 0xD011) return (this.io[0x11] & 0x7F) | (this.line > 255 ? 0x80 : 0);
      if (a === 0xD019) return this.irqFlag | (this.irqFlag ? 0x80 : 0) | 0x70;
      if (a === 0xDC00 || a === 0xDC01) return 0xFF;
      if (a === 0xDD04 || a === 0xDD05) { const t = 0xFFFF - (this.cycles & 0xFFFF); return a === 0xDD04 ? t & 255 : t >> 8; }
    }
    return super.read(a);
  }
  write(a, v) {
    a &= 0xFFFF;
    if (a >= 0xD000 && a < 0xE000 && this.ioOn()) {
      if (a === 0xD012) { this.cmp = (this.cmp & 0x100) | v; }
      else if (a === 0xD011) { this.cmp = (this.cmp & 0xFF) | ((v & 0x80) << 1); }
      else if (a === 0xD019) { this.irqFlag &= ~v & 0x0F; return; }
    }
    super.write(a, v);
  }
  // the cycles the VIC takes on a line: a badline's 40, 2 per sprite fetched (+ 3 to start)
  stolen(line) {
    let n = 0;
    const d011 = this.io[0x11];
    if ((d011 & 0x10) && line >= 0x30 && line <= 0xF7 && (line & 7) === (d011 & 7)) n += 40;
    const en = this.io[0x15];
    let s = 0;
    for (let i = 0; i < 8; i++) if (en & (1 << i)) { const y = this.io[1 + 2 * i]; const d = (line - y - 1 + 512) % 512; if (d < 21) s++; }
    if (s) n += 3 + 2 * s;
    return n;
  }
  step() {
    const c0 = this.cycles, rti = this.mem[this.pc] === 0x40 && this.inIrq;
    super.step();
    if (this.inIrq) this.irqCyc += this.cycles - c0;
    if (rti) this.inIrq = false;
    const c1 = this.cycles;
    while (this.cycles - this.lineStart >= CPL) {
      this.lineStart += CPL;
      this.line = (this.line + 1) % LINES;
      if (this.line === 0) this.cycles += EXTRA;
      this.cycles += this.stolen(this.line);
      if (this.line === this.cmp) this.irqFlag |= 1;
    }
    this.vicCyc += this.cycles - c1;
    if ((this.irqFlag & this.io[0x1A] & 0x0F) && !(this.p & 4)) {
      this.push(this.pc >> 8); this.push(this.pc & 255); this.push(this.p & 0xEF);
      this.p |= 4;
      this.pc = this.read(0xFFFE) | (this.read(0xFFFF) << 8);
      this.cycles += 7; this.irqCyc += 7; this.inIrq = true;
    }
  }
}

const c64 = new Raster(); c64.start(!ntsc);
const M = c64.mem, sym = n => c64.sym(n);
// Start's last steps: the raster interrupt on, then the main loop
const lbl = n => { const m = c64.lst.match(new RegExp(`^\\.([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?(?:.*\\t)?${n}:`, 'm')); if (!m) throw new Error(n); return parseInt(m[2] || m[1], 16); };
M[sym('curBuf')] = 0;
{ const it = lbl('ITop'), v = sym('irqVec'); M[v] = it & 255; M[v + 1] = it >> 8; }   // (Start sets the first handler)
c64.write(0xD012, 20); c64.write(0xD011, 0x3B); c64.io[0x1A] = 1;
M[sym('Flicker')] = 1; M[sym('DbgOn')] = 0; M[sym('DbgAuto')] = 1; M[sym('PowerReq')] = 1;
for (const a of process.argv.filter(x => x.startsWith('--poke='))) {   // --poke=Label:value (testing knobs)
  const [n, v] = a.slice(7).split(':'); M[sym(n)] = +v;
}
c64.s = 0xFF; c64.p = 0x20; c64.pc = lbl('MainLoop');
const base0 = sym('DbgLoops');
const t0 = Date.now(), frames0 = () => Math.floor(c64.cycles / (LINES * CPL));
const verbose = process.argv.includes('--verbose');
const profArg = process.argv.find(a => a.startsWith('--prof'));
const acc = profArg ? new Float64Array(65536) : null;
if (acc) {
  const st = c64.step.bind(c64);
  c64.step = function () { const pc = this.pc, c = this.cycles; st(); acc[pc] += this.cycles - c; };
}
const AUTO = sym('DbgAuto');
for (let next = 2e7; M[AUTO];) {
  c64.step();
  if (c64.cycles > next) {
    next += 2e7;
    if (verbose) console.log(`${(c64.cycles / 1e6).toFixed(0)}M cycles: tick ${M[sym('autoT')] + 256 * M[sym('autoT') + 1]}, passes ${M[base0] + 256 * M[base0 + 1]}, pc ${c64.pc.toString(16)}, line ${c64.line}, cmp ${c64.cmp}, irqVec ${M[sym('irqVec')]}`);
    if (c64.cycles > 2e9) throw new Error('DbgAuto never finished');
  }
}
const frames = frames0();
if (acc) {
  const labels = [...c64.lst.matchAll(/^.([0-9a-f]{4})	(?:([0-9a-f]{4})	)?(?:.*	)?([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[2] || m[1], 16), m[3]]).sort((a, b) => a[0] - b[0]);
  const labelOf = pc => { if (pc >= 0xD000 && !(pc >= 0xE000 && pc < 0xF000)) return '2600 program'; if (pc >= 0x5000 && pc < 0x6000 || pc >= 0xE000 && pc < 0xF000) return 'layer code'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
  const t = {}; for (let a = 0; a < 65536; a++) if (acc[a]) { const k = labelOf(a); t[k] = (t[k] || 0) + acc[a]; }
  for (const [k, v] of Object.entries(t).sort((a, b) => b[1] - a[1]).slice(0, +(profArg.split('=')[1] || 40))) console.log('  ' + k.padEnd(18), Math.round(v / frames));
}
const lo = sym('DbgAutoRes'), base = sym('DbgLoops');
const w = n => { const a = lo + sym(n) - base; return M[a] + 256 * M[a + 1]; };
const has = n => { try { sym(n); return true; } catch { return false; } };
const sh = lo + sym('DbgShown') - base;
console.log(`${ntsc ? 'NTSC' : 'PAL'} loopsim: ${w('DbgLoops')} passes, ${w('DbgLate')} late; frames shown: even ${M[sh] + 256 * M[sh + 1]}, odd ${M[sh + 2] + 256 * M[sh + 3]}, ` +
  `${w('DbgSame')} of the same kind as the one before` + (has('DbgFrames') ? `; ${w('DbgFrames')} frame ends, ${w('DbgRepeat')} repeated, ${w('DbgLost')} ticks left out` : '') +
  `; per frame: interrupts ${Math.round(c64.irqCyc / frames)} cycles, VIC ${Math.round(c64.vicCyc / frames)}` +
  ` (${((Date.now() - t0) / 1000).toFixed(0)} s)`);
