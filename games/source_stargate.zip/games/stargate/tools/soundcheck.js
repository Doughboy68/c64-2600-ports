// Sound check in VICE: the C64 plays by itself (DbgAuto) with VICE's "dump" sound driver, which
// logs every SID register write; then the log is checked against the game's own TIA sound
// registers' rules (UpdateSound): which voices sounded, waveforms, pitches, gates, and that
// they went quiet again.
//   node games/stargate/tools/soundcheck.js [seconds] [--ntsc]
// (SG_BUILD: another build's folder)
const path = require('path');
const fs = require('fs');
const net = require('net');
const os = require('os');
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
const ntsc = process.argv.includes('--ntsc');
const seconds = +(process.argv.slice(2).find(a => /^\d+$/.test(a)) || 20);
const build = process.env.SG_BUILD || path.join(__dirname, '..', 'build');
const { prg, lst: lstFile } = require('../../../tools/buildname').files(build);
const lst = fs.readFileSync(lstFile, 'latin1');
const addr = n => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t](?:([0-9a-f]{4})[ \\t])?.*?\\b${n}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + n);
  return m[2] || m[1];
};
const sleep = ms => new Promise(r => setTimeout(r, ms));
let PORT = 0, vice = null;
const mon = cmds => new Promise(res => {
  const s = net.connect(PORT, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d; }); s.on('error', () => res(b));
  s.on('connect', async () => { await sleep(150); for (const c of cmds) { s.write(c + '\n'); await sleep(400); } s.end(); res(b); });
});
const dump = path.join(os.tmpdir(), `stargate-sid-${process.pid}.txt`).split(path.sep).join('/');

(async () => {
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '-sounddev', 'dump', '-soundarg', dump, '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prg]);
  await sleep(8000);
  if (!await runsOurs(mon, prg)) throw new Error(`the VICE on port ${PORT} isn't running our build: stopping`);
  await mon([`> ${addr('DbgAuto')} 1`, `> ${addr('PowerReq')} 1`]);
  await sleep(seconds * 1000);
  await mon(['quit']);                         // (the dump is written as VICE quits)
  await sleep(2500);
  stopVice(vice); vice = null;
  const lines = fs.readFileSync(dump, 'latin1').split(/\r?\n/).filter(Boolean);
  fs.unlinkSync(dump);
  // each line: clock delta, register, value
  const voice = [{ wave: {}, freq: new Set(), gates: 0, offs: 0, writes: 0 }, { wave: {}, freq: new Set(), gates: 0, offs: 0, writes: 0 }, { writes: 0 }];
  const reg = new Uint8Array(32); let other = 0, vol = -1;
  for (const l of lines) {
    const p = l.trim().split(/\s+/).map(Number);
    if (p.length < 3 || p.some(isNaN)) continue;
    const [, r, v] = p;
    const prev = reg[r]; reg[r] = v;
    if (r === 0x18) { vol = v & 15; continue; }
    const vn = Math.floor(r / 7), off = r % 7;
    if (vn > 2) { if (v) other++; continue; }     // (InitSound clears them all: only values count)
    if (vn === 2) { if (v) voice[2].writes++; continue; }
    voice[vn].writes++;
    if (off === 4) {
      if ((v & 1) && !(prev & 1)) { voice[vn].gates++; voice[vn].wave[v & 0xF0] = (voice[vn].wave[v & 0xF0] || 0) + 1; }
      if (!v) voice[vn].offs++;
    }
    if (off === 1) voice[vn].freq.add(reg[vn * 7] | v << 8);
  }
  const W = { 0x10: 'triangle', 0x20: 'saw', 0x40: 'pulse', 0x80: 'noise' };
  console.log(`${ntsc ? 'NTSC' : 'PAL'}: ${lines.length} SID writes in ${seconds} s; volume ${vol}`);
  for (const k of [0, 1]) {
    const v = voice[k];
    console.log(`  voice ${k + 1}: ${v.writes} writes, ${v.gates} notes (${Object.entries(v.wave).map(([w, n]) => `${W[w] || w} ${n}`).join(', ')}), ${v.offs} silences, ${v.freq.size} pitches`);
  }
  console.log(`  voice 3 (unused): ${voice[2].writes} values written, filter: ${other}`);
  const ok = vol === 15 && voice[0].gates > 0 && voice[0].offs > 0 && voice[1].gates > 0 && voice[2].writes === 0 && other === 0;
  console.log(ok ? 'sound: ok' : 'sound: CHECK');
})().catch(e => console.log(e.message)).finally(() => stopVice(vice));
