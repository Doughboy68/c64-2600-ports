// Random play in tools/vcs.js, saving a screenshot every N frames.
//   node games/stargate/tools/shots.js <outdir> [frames] [every] [seed]
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('0c48e820301251fbb6bcdc89bd3555d9'));
vcs.superChip = true;
const [out, frames = 2000, every = 100, seed = 1] = process.argv.slice(2);
fs.mkdirSync(out, { recursive: true });
const play = require('./play')(+seed);
vcs.cropTop = 0; vcs.cropHeight = 262;
for (let f = 0; f < +frames; f++) {
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire = p.fire;
  vcs.runFrames(1);
  if (f % +every === 0) vcs.savePNG(path.join(out, `f${String(f).padStart(5, '0')}.png`), 1);
}
