// Play random games in tools/vcs.js and list executed code the disassembler didn't find
// (it would show as data in 2600/stargate.asm).
//   node games/stargate/tools/coverage.js [frames]
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('0c48e820301251fbb6bcdc89bd3555d9'));
vcs.superChip = true;
const frames = +(process.argv[2] || 20000);
const executed = new Set();
const st = vcs.step.bind(vcs);
vcs.step = function () { executed.add(this.bank << 16 | this.pc); return st(); };
let seed = 5;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const DIRS = [0xF, 0x7, 0xB, 0xE, 0xD, 0x6, 0x5, 0xA, 0x9];   // none, R, L, U, D, diagonals
for (let f = 0; f < frames; f++) {
  if (f % 15 === 0) {
    const right = rnd() < .1 ? DIRS[Math.floor(rnd() * 9)] : 0xF;
    vcs.swcha = DIRS[Math.floor(rnd() * 9)] << 4 | right;
    vcs.fire[0] = rnd() < .6;
    vcs.fire[1] = rnd() < .03;
    vcs.swchb = rnd() < .01 ? 0x0A : 0x0B;   // now and then Game Reset
  }
  vcs.runFrames(1);
}
// Instruction starts the disassembler marked as code: lines "...; XXXX: bytes"
const asm = fs.readFileSync(path.join(__dirname, '..', '2600', 'stargate.asm'), 'utf8');
const code = new Set();
let bank = 0;
for (const l of asm.split('\n')) {
  if (/======== bank 1/.test(l)) bank = 1;
  const m = l.match(/; ([0-9A-F]{4}): /);
  if (m) code.add(bank << 16 | parseInt(m[1], 16));
}
const missed = [...executed].filter(a => !code.has(a)).sort((a, b) => a - b);
console.log('executed', executed.size, 'instruction addresses; not found by the disassembler:', missed.length);
console.log(missed.map(a => `b${a >> 16}:$${(a & 0xFFFF).toString(16)}`).join(' '));
