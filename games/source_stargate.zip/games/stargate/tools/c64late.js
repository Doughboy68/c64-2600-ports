// How the C64 version keeps up in VICE: frames drawn, frame ends that came with the last
// frame's tick still due (late), the most cycles drawing a frame / a tick / a wait took
// (debug counters DbgLoops .. DbgPMax), and frames shown of each kind (DbgShown: by FrameCount
// bit 0 of the tick they show, the flicker's turns; DbgSame: shown after one of the same kind;
// DbgFrames: frame ends, DbgRepeat: those that showed nothing new; DbgLost: ticks left out).
// --auto (the default): the C64 plays by itself (DbgAuto, c64/auto.asm): from F2, a game played
// with the same inputs at the same ticks whatever the timing, ships held at 3 and a wave ended
// every 900 ticks or so (into the later waves), counted over the same 7200 ticks, so builds
// can be compared. With flicker on, then off. Screenshots with --png=dir.
//   node games/stargate/tools/c64late.js [--ntsc] [--png=dir] [--flicker=on|off] [--timing]
// --timing: the timing aids on too (DbgOn: the most cycles, waiting and working; they cost
// cycles themselves: about 150 more frames repeated on NTSC)
// (SG_BUILD: another build's folder)
const net = require('net');
const fs = require('fs');
const path = require('path');
const ntsc = process.argv.includes('--ntsc');
const timing = process.argv.includes('--timing');
const pngArg = process.argv.find(a => a.startsWith('--png='));
const flArg = process.argv.find(a => a.startsWith('--flicker='));
const build = process.env.SG_BUILD || path.join(__dirname, '..', 'build');
const { prg: prgFile, lst: lstFile } = require('../../../tools/buildname').files(build);
const lst = fs.readFileSync(lstFile, 'latin1');
const addr = n => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t](?:([0-9a-f]{4})[ \\t])?.*?\\b${n}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + n);
  return parseInt(m[2] || m[1], 16);           // (part 2's lines: the load address, then the run address)
};
const hex = v => v.toString(16);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
let vice = null;              // the VICE this run started (only that one is closed)
let PORT = 0;                 // our own monitor port (another session's VICE may have 6510)
const mon = cmds => new Promise((resolve, reject) => {
  const s = net.connect(PORT, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d; }); s.on('error', reject);
  s.on('connect', async () => {
    await sleep(150);
    for (const c of cmds) {                     // (time for each answer before the next command)
      s.write(c + '\n');
      await sleep(c.startsWith('screenshot') ? 1200 : 400);
    }
    s.write('x\n'); await sleep(100); s.end(); resolve(b);
  });
});
const dump = async (lo, hi, extra = []) => {
  const o = await mon([`m ${hex(lo)} ${hex(hi)}`, ...extra]);
  const mem = {};
  for (const m of o.matchAll(/>C:([0-9a-f]{4})((?:\s+[0-9a-f]{2}\b)+)/gi))
    m[2].trim().split(/\s+/).forEach((x, k) => { mem[parseInt(m[1], 16) + k] = parseInt(x, 16); });
  return mem;
};
const shot = async name => { if (pngArg) await mon([`screenshot "${path.join(pngArg.slice(6), name).split(path.sep).join('/')}" 2`]); };

(async () => {
  if (pngArg) fs.mkdirSync(pngArg.slice(6), { recursive: true });
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prgFile]);
  // wait until the program runs (its main loop counting passes; VICE's autostart takes a varying time)
  const loops = async () => { try { const m = await dump(addr('DbgLoops'), addr('DbgLoops') + 1); const v = m[addr('DbgLoops')] + 256 * m[addr('DbgLoops') + 1]; return isNaN(v) ? -1 : v; } catch { return -1; } };
  for (let t = 0, last = -1; t < 40; t++) {
    await sleep(1000);
    const n = await loops();
    if (last > 0 && n > last) break;
    last = n;
  }
  if (!await runsOurs(mon, prgFile)) throw new Error(`the VICE on port ${PORT} isn't running our build: stopping`);
  const flickers = flArg ? [flArg.endsWith('off') ? 0 : 1] : [1, 0];
  for (const flicker of flickers) {
    await mon([`> ${hex(addr('Flicker'))} ${flicker}`, `> ${hex(addr('DbgOn'))} ${timing ? 1 : 0}`, `> ${hex(addr('DbgAuto'))} 1`, `> ${hex(addr('PowerReq'))} 1`]);
    const t0 = Date.now();
    for (;;) {
      await sleep(3000);
      const m = await dump(addr('DbgAuto'), addr('DbgAuto'));
      if (m[addr('DbgAuto')] === 0) break;
      if (Date.now() - t0 > 600000) throw new Error('DbgAuto never finished');
    }
    const lo = addr('DbgAutoRes'), base = addr('DbgLoops');
    const mem = await dump(lo, lo + addr('DbgWork') + 3 - base, ['m 89 89']);
    const w = n => mem[lo + addr(n) - base] + 256 * mem[lo + addr(n) - base + 1];
    const sh = addr('DbgShown') - base;
    const w3 = n => mem[lo + addr(n) - base] + 256 * mem[lo + addr(n) - base + 1] + 65536 * mem[lo + addr(n) - base + 2] + 16777216 * mem[lo + addr(n) - base + 3];
    const passes = w('DbgLoops');
    console.log(`${ntsc ? 'NTSC' : 'PAL'} auto, flicker ${flicker ? 'on' : 'off'}: ${w('DbgLoops')} frames drawn, ${w('DbgLate')} late (a frame end with the last tick still due); ` +
      (timing ? `most cycles: drawing a frame ${w('DbgRMax')}, a tick ${w('DbgTMax')}, a wait ${w('DbgPMax')} (a frame has ${ntsc ? 17095 : 19656}); ` : '') +
      `frames shown: even ${mem[lo + sh] + 256 * mem[lo + sh + 1]}, odd ${mem[lo + sh + 2] + 256 * mem[lo + sh + 3]}, ${w('DbgSame')} of the same kind as the one before; ` +
      `${w('DbgFrames')} frame ends, ${w('DbgRepeat')} repeated (nothing new), ${w('DbgLost')} ticks left out; ` +
      `wave ${mem[0x89]}` + (timing ? `; per frame drawn: waiting ${Math.round(w3('DbgWait') / passes)} cycles, working ${Math.round(w3('DbgWork') / passes)}` : ''));
    await shot(`auto-flicker-${flicker ? 'on' : 'off'}${ntsc ? '-ntsc' : ''}.png`);
  }
})().catch(e => console.log(e.message)).finally(() => {   // close the VICE started here, whatever happened
  stopVice(vice);
});
