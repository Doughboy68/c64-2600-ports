// VICE: plays with random inputs (the Dbg pokes) and checks every few seconds that the main
// loop still runs; if it stops, dumps the CPU, the VIC and the raster schedule (this found the
// freeze of fbfffe7). Its own monitor port, only its own VICE closed.
//   node games/stargate/tools/stress.js [seconds] [--seed=N] [--pal]
const fs = require('fs'), net = require('net'), path = require('path');
const ntsc = !process.argv.includes('--pal');
const secs = +(process.argv.find(a => /^\d+$/.test(a)) || 180);
const build = path.join(__dirname, '..', 'build');
const { prg, lst: lstFile } = require('../../../tools/buildname').files(build);
const lst = fs.readFileSync(lstFile, 'latin1');
const addr = n => { const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t](?:([0-9a-f]{4})[ \\t])?.*?\\b${n}(?::|[ \\t]+\\.)`, 'm')); if (!m) throw new Error(n); return m[2] || m[1]; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
let PORT = 0, vice = null;
const mon = cmds => new Promise((res, rej) => {
  const s = net.connect(PORT, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d; }); s.on('error', rej);
  s.on('connect', async () => { await sleep(150); for (const c of cmds) { s.write(c + '\n'); await sleep(300); } s.write('x\n'); await sleep(100); s.end(); res(b); });
});
const word = (o, a) => { const m = o.match(new RegExp(`>C:${a}\\s+([0-9a-f]{2})\\s+([0-9a-f]{2})`, 'i')); return m ? parseInt(m[1], 16) + 256 * parseInt(m[2], 16) : -1; };
(async () => {
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prg]);
  await sleep(8000);
  if (!await runsOurs(mon, prg)) throw new Error('not our VICE');
  const A = { sw: addr('DbgSWCHA'), i4: addr('DbgINPT4'), i5: addr('DbgINPT5'), loops: addr('DbgLoops') };
  await mon([`> ${A.i4} 7f`]); await sleep(500); await mon([`> ${A.i4} ff`]);
  let seed = +(process.argv.find(a => a.startsWith('--seed=')) || '--seed=7').slice(7);
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const DIRS = ['7f', '7f', 'bf', 'bf', 'ef', 'df', '6f', 'af', '5f', '9f', 'ff'];
  let last = -1, stuck = 0; const t0 = Date.now();
  while (Date.now() - t0 < secs * 1000) {
    let d = DIRS[Math.floor(rnd() * DIRS.length)];
    const r = rnd();
    if (r < 0.06) d = d[0] + 'e'; else if (r < 0.1) d = d[0] + 'd';
    const fire = rnd() < 0.7 ? '7f' : 'ff', bomb = rnd() < 0.05 ? '7f' : 'ff';
    const o = await mon([`> ${A.sw} ${d}`, `> ${A.i4} ${fire}`, `> ${A.i5} ${bomb}`, `m ${A.loops} ${(parseInt(A.loops, 16) + 1).toString(16)}`, 'm 82 82']);
    const n = word(o, A.loops.toLowerCase());
    if (n === last) {
      if (++stuck >= 2) {
        console.log('main loop stopped at', n, 'after', Math.round((Date.now() - t0) / 1000), 's');
        const st = await mon(['r', 'io d000', `m ${addr('irqVec')} ${addr('irqVec')}`, 'm 0040 007f', `m ${addr('SchRas')} ${(parseInt(addr('SchRas'),16)+48*7).toString(16)}`]);
        console.log(st);
        const pc = (st.match(/\.;([0-9a-f]{4})/i) || [])[1];
        if (pc) console.log(await mon([`d ${pc} ${(parseInt(pc, 16) + 40).toString(16)}`]));
        await sleep(1000);
        console.log(await mon(['r']));
        break;
      }
    } else stuck = 0;
    last = n;
    await sleep(600);
  }
  if (stuck < 2) console.log('no stop in', secs, 's; main loop passes', last);
})().catch(e => console.log(e.message)).finally(() => stopVice(vice));
