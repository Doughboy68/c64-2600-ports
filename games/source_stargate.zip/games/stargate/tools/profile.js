// Cycles the game spends per frame outside the kernel (what the C64 runs as its "tick"):
// from $D16C (after the picture) to $F28E (bank 1 waits for its timer), less the VSYNC wait.
//   node games/stargate/tools/profile.js [frames] [seed]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('0c48e820301251fbb6bcdc89bd3555d9'));
vcs.superChip = true;
const frames = +(process.argv[2] || 3000);
const play = require('./play')(+(process.argv[3] || 1));
let start = -1, wait = 0, inWait = false, cyc0 = 0;
const res = [];
const os = vcs.step.bind(vcs);
vcs.step = function () {
  const pc = this.pc;
  if (pc === 0xD16C) { start = this.cycles; wait = 0; }
  if (pc === 0xD90B || pc === 0xD90E) { if (!inWait) { inWait = true; cyc0 = this.cycles; } } else if (inWait) { inWait = false; wait += this.cycles - cyc0; }
  if (pc === 0xF28E && start >= 0) { res.push(this.cycles - start - wait); start = -1; }
  return os();
};
for (let f = 0; f < frames; f++) { const p = play(f, vcs.ram); vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire = p.fire; vcs.runFrames(1); }
res.sort((a, b) => a - b);
const q = p => res[Math.floor(p * (res.length - 1))];
console.log(`${res.length} ticks: min ${q(0)} median ${q(0.5)} 90% ${q(0.9)} 99% ${q(0.99)} max ${q(1)} cycles`);
