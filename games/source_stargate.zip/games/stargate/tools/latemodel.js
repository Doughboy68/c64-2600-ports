// Speed: a model of the main loop's timing over the auto game (tick and render cycles from the
// simulator): passes wait for a frame end, draw, run the frames' ticks (catch-up, at most 3).
// Fitted to VICE (tools/c64late.js): B cycles a frame for our work, O a pass. Prints frames shown
// again (late) and the game's speed, catching up (as now) or not, at x1, x0.9, x0.8 the work.
//   node games/stargate/tools/latemodel.js [--ntsc] [--B=14250] [--O=1500]
const { C64 } = require('./c64sim');
const ntsc = process.argv.includes('--ntsc');
const num = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const c64 = new C64(); c64.start(!ntsc);
const sym = n => c64.sym(n), M = c64.mem;
M[sym('DbgAuto')] = 1; c64.call(sym('PowerCycle'));
const T = [], R = []; let f = 0;
while (M[sym('DbgAuto')] && f < 7500) { T.push(c64.call(sym('Tick'))); M[sym('pending')] = 0; M[sym('curBuf')] ^= 1; R.push(c64.call(sym('Render'))); f++; }
const B = num('B', ntsc ? 14250 : 16700), O = num('O', 1500);
const run = (policy, scale) => {
  let t = 0, tick = 300, lastFrame = 0, passes = 0, repeats = 0, acc = 0, first = true;
  const end = 7500;
  while (tick < end) {
    let nowFrame = Math.floor(t / B);
    if (!first && nowFrame === lastFrame) { t = (nowFrame + 1) * B; nowFrame++; }
    const frames = first ? 1 : Math.min(3, nowFrame - lastFrame);
    repeats += frames - 1; lastFrame = nowFrame; passes++; first = false;
    t += O + R[tick - 1] * scale;
    let ticks = 0;
    const fr = policy === 'catchup' ? frames : 1;
    for (let k = 0; k < fr; k++) { if (ntsc) ticks++; else { acc += 6; while (acc >= 5) { acc -= 5; ticks++; } } }
    for (let k = 0; k < ticks && tick < end; k++) t += T[tick++] * scale;
  }
  const nominal = (end - 300) * (ntsc ? 1 : 5 / 6);
  return `${passes} passes, ${repeats} frames repeated, game speed ${(100 * nominal / (t / B)).toFixed(1)}%`;
};
for (const scale of [1, 0.9, 0.8]) for (const p of ['catchup', 'none']) console.log(`${ntsc ? 'NTSC' : 'PAL'} work x${scale}, ${p}: ${run(p, scale)}`);
