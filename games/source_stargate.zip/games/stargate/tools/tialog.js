// Log one frame's TIA writes (line, clock, register, value, pc) after N frames of random play
// (tools/play.js, as shots.js); optional list of registers to show.
//   node games/stargate/tools/tialog.js <frame> [seed] [REG,REG...]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('0c48e820301251fbb6bcdc89bd3555d9'));
vcs.superChip = true;
const N = ['VSYNC', 'VBLANK', 'WSYNC', 'RSYNC', 'NUSIZ0', 'NUSIZ1', 'COLUP0', 'COLUP1', 'COLUPF', 'COLUBK', 'CTRLPF',
  'REFP0', 'REFP1', 'PF0', 'PF1', 'PF2', 'RESP0', 'RESP1', 'RESM0', 'RESM1', 'RESBL', 'AUDC0', 'AUDC1', 'AUDF0', 'AUDF1',
  'AUDV0', 'AUDV1', 'GRP0', 'GRP1', 'ENAM0', 'ENAM1', 'ENABL', 'HMP0', 'HMP1', 'HMM0', 'HMM1', 'HMBL', 'VDELP0', 'VDELP1',
  'VDELBL', 'RESMP0', 'RESMP1', 'HMOVE', 'HMCLR', 'CXCLR'];
const args = process.argv.slice(2);
const play = require('./play')(+(args[1] || 1));
const frame = +args[0];
for (let f = 0; f <= frame; f++) {
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire = p.fire;
  if (f === frame) {
    const want = args[2] ? new Set(args[2].split(',')) : null;
    const tw = vcs.tiaWrite.bind(vcs);
    vcs.tiaWrite = function (a, v) {
      const n = N[a] || a.toString(16);
      if (n !== 'WSYNC' && (!want || want.has(n))) console.log(`${this.line} ${this.clock - 68} ${n} ${v.toString(16)} ${this.lastPc.toString(16)}`);
      return tw(a, v);
    };
    const hex = b => [...b].map(x => x.toString(16).padStart(2, '0')).join(' ');
    for (let i = 0; i < 128; i += 16) console.error((0x80 + i).toString(16), hex(vcs.ram.subarray(i, i + 16)));
    for (let i = 0; i < 128; i += 16) console.error('x' + (0x80 + i).toString(16), hex(vcs.xram.subarray(i, i + 16)));
  }
  vcs.runFrames(1);
}
