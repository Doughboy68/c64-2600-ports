// Speed: the auto game (DbgAuto, c64/auto.asm: the same game as tools/c64late.js plays in VICE)
// on the simulator, cycles per routine (exclusive; ours and the 2600 program's by its labels),
// tick and render apart, per frame. --field: field frames only.
//   node games/stargate/tools/autoprof.js [--field] [--ntsc]
const { C64 } = require('./c64sim');
const fs = require('fs');
const c64 = new C64(); c64.start(!process.argv.includes('--ntsc'));
const sym = n => c64.sym(n), M = c64.mem;
const labels = [...c64.lst.matchAll(/^\.([0-9a-f]{4})\t(?:([0-9a-f]{4})\t)?(?:.*\t)?([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[2] || m[1], 16), m[3]]);
const src = fs.readFileSync(__dirname + '/../2600/stargate.asm', 'utf8').split('\n'); let pend = null;
for (const l of src) { const lm = l.match(/^([A-Za-z_][A-Za-z0-9_]*):/); if (lm) pend = lm[1]; const am = l.match(/;\s*([DEF][0-9A-F]{3}):/); if (am && pend) { labels.push([parseInt(am[1], 16), '2600 ' + pend]); pend = null; } }
labels.sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0x5000 && pc < 0x6000) return 'layer code 0'; if (pc >= 0xE000 && pc < 0xF000) return 'layer code 1'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
let phase = 'tick'; const prof = { tick: {}, render: {} };
const st = c64.step.bind(c64);
c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc), t = prof[phase]; t[k] = (t[k] || 0) + this.cycles - c; return r; };
M[sym('DbgAuto')] = 1; c64.call(sym('PowerCycle'));
let f = 0;
const only = process.argv.includes('--field'); let n = 0; const keep = () => JSON.parse(JSON.stringify(prof));
while (M[sym('DbgAuto')] && f < 9000) { const save = keep(); phase = 'tick'; c64.call(sym('Tick')); M[sym('pending')] = 0; M[sym('curBuf')] ^= 1; phase = 'render'; c64.call(sym('Render')); f++; if (only && M[sym('CapKind')] !== 0) { prof.tick = save.tick; prof.render = save.render; } else n++; }
f = n;
for (const ph of ['tick', 'render']) {
  const t = prof[ph], tot = Object.values(t).reduce((a, b) => a + b, 0), is26 = k => k.startsWith('2600');
  const t26 = Object.entries(t).filter(([k]) => is26(k)).reduce((a, [, v]) => a + v, 0);
  console.log(`-- ${ph}: ${Math.round(tot / f)} a frame${ph === 'tick' ? ` (2600 program ${Math.round(t26 / f)})` : ''}`);
  for (const [k, v] of Object.entries(t).filter(([k]) => ph === 'render' || !is26(k)).sort((a, b) => b[1] - a[1]).slice(0, 26)) console.log('  ' + k.padEnd(20), Math.round(v / f));
}
