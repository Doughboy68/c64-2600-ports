// A model of what Stargate's kernel draws, built only from RAM (and the SuperChip RAM) and the
// TIA registers as the kernel starts ($F28E, where bank 1 waits for its timer), checked against
// tools/vcs.js over random games: the TIA writes, the pixels (objects and colour) and the
// collisions. The C64 version draws from the same rules, so this is where its geometry is
// worked out and proven.
//
// The model restates the kernel as the TIA writes it makes on each line, at the clock each one
// lands on (pixel position: 3 * cycle - 68, counted from the end of WSYNC), following the
// kernel's own branches; the writes are then played on a bare TIA (tools/vcs.js's pixel rules).
// A write at clock c changes pixels from c on.
//
// The picture (2600 lines, counted from the end of VSYNC):
//   37       VBLANK ends; players and ball reset for the score band
//   38       (idle too long: the background colour from here, nothing else)
//   39-45    score: six digits (players 0 and 1, three copies each, VDEL), colour cycling
//   47-52    ships left (a line of the colour write, five of icons), up to six icons
//   54-57    smartbombs left (three lines)
//   59-61    inviso left (two lines)
//   62-77    scanner: the playfield's walls and floor, players 0 and 1 (48 pixels, seven rows of
//            two lines from the SuperChip RAM), the ball marks the ship's place
//   78-81    positioning: ball, missile 1, missile 0, player 1 (the ship)
//   82-83    HMOVE twice (fine positions), the field's colours
//   84-223   the field, one line per Y (counting down from $8A to 1), HMOVE on every line:
//            player 1   the ship, graphics ($94),y (switched from a blank page at row $97)
//            player 0   the enemies, one after another down the screen (slots from $A2-1 down
//                       to 0), each repositioned on two lines when the one above ends (a 0
//                       graphics byte); graphics ($9D),y and colour ($9F),y; VDELP0 is on, so
//                       each GRP0 write shows from the next GRP1 write (the next line's start)
//            missile 1 + ball   stars and mountains: enable and size from ($9B),y every line,
//                       moved 3 pixels left (missile) and right (ball) by every HMOVE
//            missile 0  the enemy shot: one row ($9A), enabled by PHP into ENAM0
//            playfield  the laser: row $D7 (PF0-PF2 left and right from $DA-$DF, mid-line)
//   224      VBLANK on
//
// Other kernels (title, wave end) come later; the model reports them as not modelled.
//
//   node games/stargate/tools/model.js [frames] [--seed=N] [--verbose] [--show=frame] [--cheat]
// --cheat: endless ships and quick wave ends (tools/cheat.js): later waves, the wave-end screen
'use strict';
const { VCS } = require('../../../tools/vcs');
const ROMMD5 = require('../2600/symbols.js').game.md5;
const rom = require('../../../tools/rom').load(ROMMD5);

const KERNEL = 0xF28E;
const FIRST = 37, LAST = 224;
const REG = { VBLANK: 0x01, NUSIZ0: 0x04, NUSIZ1: 0x05, COLUP0: 0x06, COLUP1: 0x07, COLUPF: 0x08, COLUBK: 0x09,
  CTRLPF: 0x0A, REFP0: 0x0B, REFP1: 0x0C, PF0: 0x0D, PF1: 0x0E, PF2: 0x0F, RESP0: 0x10, RESP1: 0x11, RESM0: 0x12,
  RESM1: 0x13, RESBL: 0x14, GRP0: 0x1B, GRP1: 0x1C, ENAM0: 0x1D, ENAM1: 0x1E, ENABL: 0x1F, HMP0: 0x20, HMP1: 0x21,
  HMM0: 0x22, HMM1: 0x23, HMBL: 0x24, VDELP0: 0x25, VDELP1: 0x26, HMOVE: 0x2A, HMCLR: 0x2B, CXCLR: 0x2C };

// ---- snapshot: RAM, SuperChip RAM, the TIA and the CPU as the kernel starts
function snap(v) {
  return { ram: Uint8Array.from(v.ram), xram: Uint8Array.from(v.xram), r: Uint8Array.from(v.r), pos: [...v.pos],
    grpOld: [...v.grpOld], blOld: v.blOld, cx: v.cx, resetLine: [...v.resetLine], p: v.p };
}

// Bank 1's view of memory: SuperChip RAM at $F080-$F0FF, otherwise the ROM
function mem(s) {
  return a => ((a & 0x1F80) === 0x1080 ? s.xram[a & 0x7F] : rom[0x1000 + (a & 0xFFF)]);
}

// The kernel's writes: lines[L] = [[clock, register, value], ...] (HMOVE, RESxx, CXCLR, HMCLR
// strobes too). Also: the RAM it changes (ram), where it reads CXPPMM (cxReads), facts for the C64.
function schedule(s) {
  const ram = Uint8Array.from(s.ram);
  const R = a => ram[a - 0x80];
  const W = (a, v) => { ram[a - 0x80] = v & 0xFF; };
  const M = mem(s), X = a => s.xram[a - 0xF080];
  const ind = (zp, y) => M(((R(zp) | R(zp + 1) << 8) + y) & 0xFFFF);
  const lines = {};
  let line = 37;
  // (a 'loose' write's clock isn't modelled: it lands where nothing shows, on that line or the one
  // before; played at the line's start)
  const w = (c, reg, v = 0) => (lines[line] = lines[line] || []).push(c === 'loose' ? [-68, REG[reg], v & 0xFF, true] : [c, REG[reg], v & 0xFF]);
  const cxReads = [];
  const out = { lines, ram, cxReads, kind: 'field', bands: [] };

  // ---- line 37: VBLANK off, players and ball reset, the ball's motion for the scanner.
  // HMBL = $C0 - ShipX with the carry left by the score's leading-zero test (cmp #$26).
  w(-35, 'VBLANK', 0); w(-26, 'GRP0', 0); w(-17, 'GRP1', 0); w(-8, 'REFP0', 0); w(1, 'REFP1', 0);
  w(25, 'HMBL', 0xC0 - R(0x85) - (s.p & 1 ? 0 : 1)); w(40, 'CTRLPF', 0x15);
  w(49, 'RESP0'); w(58, 'RESP1'); w(79, 'RESBL'); w(88, 'HMP0', 0xFF);
  // the laser row's star / mountain bits go into $DA's low nibble (ENAM1 / ENABL on that line)
  W(0xDA, (ind(0x9B, R(0xD7)) & 0x0F) | (R(0xDA) & 0xF0));
  line = 38;
  w(-68, 'NUSIZ0', 3); w(-59, 'HMOVE');
  if (X(0xF0FD) & 0x80) {                      // idle too long (XFlash bit 7): the field blanked, the background colour cycling
    w(-20, 'COLUBK', (X(0xF0FD) << 1) & 0xF7);
    out.kind = 'idle';
    W(0xA2, 0); W(0xA3, 0);
    return finish(out);
  }
  w(-29, 'NUSIZ1', 3); w(-20, 'VDELP0', 3); w(-11, 'VDELP1', 3);

  // ---- 48-pixel bands ($F900): the colour on the line before, then one line per row
  let T;                                       // absolute clock: line * 228 + clock + 68
  const at = t => { line = Math.floor(t / 228); return t % 228 - 68; };
  const band = (colour, rows, cycles, firstLine) => {
    if (firstLine !== undefined) {             // placed by a timer wait: the colour on the line before
      line = firstLine - 1;
      if (colour !== null) { w('loose', 'COLUP0', colour); w('loose', 'COLUP1', colour); }
    } else {
      let c;
      if (cycles === undefined) { c = 49; } else { T += 3 * cycles; c = at(T); }
      w(c, 'COLUP0', colour); w(c + 9, 'COLUP1', colour);
    }
    const first = line + 1;
    for (let y = rows - 1; y >= 0; y--) {
      line++;
      const g = zp => ind(zp, y);
      w(-17, 'GRP0', g(0xF2)); w(7, 'GRP1', g(0xF4)); w(31, 'GRP0', g(0xF6)); w(64, 'GRP1', g(0xF8));
      w(73, 'GRP0', g(0xFA)); w(82, 'GRP1', g(0xFC)); w(91, 'GRP0', g(0xF8));
    }
    w(127, 'GRP0', 0); w(136, 'GRP1', 0); w(145, 'GRP0', 0);
    W(0xF0, 0xFF); W(0xF1, ind(0xFC, 0));
    out.bands.push({ first, rows, colour, ptr: [0xF2, 0xF4, 0xF6, 0xF8, 0xFA, 0xFC].map(z => R(z) | R(z + 1) << 8) });
    T = line * 228 + 145 + 68;
  };
  // $F66B: Y icons (at most six) from the right, the rest blank ($89); returns its cycle count
  const icons = (n, lo) => {
    let cyc = 2, x = 10, y = n;
    for (;;) {
      y = (y - 1) & 0xFF; cyc += 2;
      if (y & 0x80) { cyc += 3 + 2; for (;;) { W(0xF2 + x, 0x89); x -= 2; cyc += 8; if (x < 0) { cyc += 2; break; } cyc += 3; } break; }
      cyc += 2; W(0xF2 + x, lo); x -= 2; cyc += 8;
      if (x < 0) { cyc += 2; break; }
      cyc += 3;
    }
    return cyc + 6;
  };
  band((R(0x81) << 1 & 0xF0) | 0x14, 7);       // score
  // $FAF4: twelve bytes from $FA3B (ending at Y) into $F2-$FD (the bands' graphics pointers)
  const text = yy => { for (let i = 11; i >= 0; i--) W(0xF2 + i, M(0xFA3B + yy - (11 - i))); };
  const DIGIT = 0xF93E;
  if (!R(0x82)) {                              // title ($F118): STARGATE, (c) 1984 Atari; or attract text
    out.kind = 'title';
    if (!R(0xAE)) { text(0x17); band(null, 128, 0, 60); text(0x0B); band(0x32, 7, 0, 213); }
    else { text(0x51); band(0x24, 7, 0, 136); }
    W(0xA2, 0); W(0xA3, 0);
    return finish(out);
  }
  let cyc = 6 + 3 + 3 + 2 + 2 + 6 + icons((R(0x82) - 1) & 0xFF, 0x40);
  band(0x32, 5, cyc + 13);                     // ships left
  band(0xFF, 3, 17 + icons(R(0x83), 0x53) + 13);   // smartbombs
  band(0x32, 2, 17 + icons(R(0x84), 0xDD) + 13);   // inviso
  if (R(0xAA)) { waveEnd(); return finish(out); }

  // ---- scanner, lines 62-77
  line = 62;
  w(-32, 'COLUP0', 0xC2); w(-23, 'COLUP1', 0xC2);
  const lo = (0x67 - M(0xFA29 + (R(0x99) >> 3))) & 0xFF;
  W(0xF8, lo); W(0xF9, 0xFE);
  w(115, 'PF2', 2);
  for (let f = 13; f >= 0; f--) {
    line++;
    const y = f >> 1;
    w(-68, 'ENABL', M(0xFE00 + lo + y));
    w(-8, 'GRP0', X(0xF0CF + y)); w(13, 'GRP1', X(0xF0D6 + y)); w(34, 'GRP0', X(0xF0DD + y));
    w(64, 'GRP1', X(0xF0E4 + y)); w(73, 'GRP0', X(0xF0EB + y)); w(82, 'GRP1', X(0xF0F2 + y)); w(91, 'GRP0', X(0xF0E4 + y));
    W(0xF1, X(0xF0F2 + y));
  }
  W(0xF0, 0xFF);
  line = 77;
  w(-53, 'PF2', 0x82);
  w(-20, 'GRP0', 0); w(-11, 'GRP1', 0); w(-2, 'GRP0', 0); w(49, 'GRP0', 0); w(58, 'GRP1', 0); w(67, 'GRP0', 0);
  w(94, 'ENABL', 0); w(103, 'VDELP1', 0); w(112, 'NUSIZ0', 0); w(121, 'NUSIZ1', 0); w(136, 'PF2', 0xFE);

  // ---- positioning, lines 78-81: ball, missile 1, missile 0, player 1 ($88, $87, $86, $85).
  // Each X code (from the table at $FBD0) gives a coarse delay (bits 1-2, and bit 7 a cycle
  // more), the fine motion (bits 3-6, shifted into HMxx) and bit 0 a second, later reset.
  // (Looking the code up in $FBD0 takes a cycle more from $30 on: the index crosses a page.)
  const resClock = v => 7 + (v & 0x80 ? 3 : 0) + 15 * (v & 6);
  const RES = ['RESP1', 'RESM0', 'RESM1', 'RESBL'], HM = ['HMP1', 'HMM0', 'HMM1', 'HMBL'];
  for (let i = 3; i >= 0; i--) {
    line = 81 - i;
    if (i < 3) w(-53, 'PF2', 0);
    const v = M(0xFBD0 + R(0x85 + i)), cross = R(0x85 + i) >= 0x30 ? 0 : -3, c = resClock(v) + cross;
    w(c, RES[i]); w(c + 33 + cross, HM[i], v << 1);
    if (v & 1) w(c + 78 + cross, RES[i]);
  }
  line = 82; w(-59, 'HMOVE');
  line = 83; w(-59, 'HMOVE');
  w(-41, 'COLUBK', R(0x8F)); w(-20, 'COLUP1', X(0xF0CA)); w(-11, 'COLUPF', X(0xF0CA));
  w(16, 'REFP1', X(0xF081) - 1); w(31, 'CXCLR'); w(40, 'HMCLR');
  if (R(0xAD)) {                               // no field this frame
    out.kind = 'blank';
    W(0xA2, 0); W(0xA3, 0);
    return finish(out);
  }
  w(73, 'HMM1', 0x30); w(88, 'HMBL', 0xD0);

  // ---- the field, lines 84-223: one line per Y, Y from $8B down
  let y = 0x8B, x = 0, colour = 0, state = 'F461';
  const rows = [];                             // per line: Y as the line starts (facts for the C64)
  const startLine = () => { line++; rows[line] = y; };
  const enabled = e => [e];
  for (let guard = 0; guard < 400; guard++) {
    if (state === 'END') break;
    switch (state) {
      case 'F461': {                           // next enemy: two lines to reposition player 0
        x = R(0xA2);
        if (!x) { W(0xA1, 0); state = 'F407'; break; }
        x--; W(0xA1, R(0xC2 + x));
        startLine();                           // R1
        w(-59, 'HMOVE'); w(-50, 'GRP1', ind(0x94, y)); y = (y - 1) & 0xFF;
        const v = R(0xB0 + x), c = resClock(v);
        w(-23, 'REFP0', v); w(c, 'RESP0');
        W(0xB0 + x, v >> 1);
        const h = R(0xB6 + x);
        w(c + 39, 'HMP0', h); W(0xA0, h | 0xF0); W(0x9E, h | 0xF0);
        if (v & 1) w(c + 78, 'RESP0');
        startLine();                           // R2
        w(-59, 'HMOVE'); w(-35, 'GRP1', ind(0x94, y));
        const e = ind(0x9B, y);
        w(-11, 'ENAM1', e); w(-2, 'ENABL', e); w(16, 'ENAM0', y === R(0x9A) ? 2 : 0);
        y = (y - 1) & 0xFF;
        W(0x9F, R(0xBC + x)); W(0x9D, R(0xC8 + x));
        cxReads.push({ line, clock: 76, addr: 0xB0 + x });
        W(0xA2, x);
        state = y === R(0xD7) ? 'F4BF' : 'F407';
        break;
      }
      case 'F407': colour = 0xFF; state = 'F409'; break;
      case 'F400': colour = ind(0x9F, y); state = 'F409'; break;
      case 'F409': {                           // line A
        startLine();
        w(-59, 'HMOVE'); w(-50, 'COLUP0', colour); w(-26, 'GRP1', ind(0x94, y));
        const e = ind(0x9B, y);
        w(-2, 'ENAM1', e); w(7, 'ENABL', e); w(22, 'NUSIZ1', e & 0xF0); w(31, 'CTRLPF', e & 0xF0);
        y = (y - 1) & 0xFF;
        if (!y) { state = 'END'; break; }
        let late = 0;
        if (y < R(0x97)) { W(0x94, R(0x96)); late = 15; }
        w(76 + late, 'HMP0', 0);
        if (y < R(0xA1)) {
          w(118 + late, 'GRP0', ind(0x9D, y));
          const col = ind(0x9F, y);
          startLine(); w(-59, 'HMOVE'); w(-50, 'COLUP0', col);
        } else { startLine(); w(-59, 'HMOVE'); }
        state = 'F444';
        break;
      }
      case 'F444': {                           // line B (already started)
        w(-26, 'GRP1', ind(0x94, y));
        const e = ind(0x9B, y);
        w(-2, 'ENAM1', e); w(7, 'ENABL', e); w(25, 'ENAM0', y === R(0x9A) ? 2 : 0);
        y = (y - 1) & 0xFF;
        state = y === R(0xD7) ? 'F4CC' : 'F457';
        break;
      }
      case 'F457':
        if (y >= R(0xA1)) { state = 'F407'; break; }
        {
          const g = ind(0x9D, y);
          w(97, 'GRP0', g);
          state = g ? 'F400' : 'F461';
        }
        break;
      case 'F4CC': {                           // the laser row, from line B
        W(0xA4, x);
        if (y >= R(0xA1)) { state = 'F4BF'; break; }
        w(103, 'PF0', R(0xDA)); w(127, 'GRP0', ind(0x9D, y)); w(145, 'PF1', R(0xDB));
        const col = ind(0x9F, y);
        startLine(); w(-59, 'HMOVE'); w(-50, 'COLUP0', col);
        state = 'F4E4';
        break;
      }
      case 'F4BF':                             // the laser row, no enemy on it
        w(142, 'PF0', R(0xDA));
        startLine(); w(-68, 'PF1', R(0xDB)); w(-59, 'HMOVE');
        state = 'F4E4';
        break;
      case 'F4E4': {                           // laser line: PF0-PF2 left then right
        const d = R(0xDA);
        w(-41, 'ENABL', d); w(-32, 'ENAM1', d); w(-8, 'GRP1', ind(0x94, y)); w(10, 'PF2', R(0xDC));
        y = (y - 1) & 0xFF;
        x = 0;
        w(31, 'HMP0', 0); w(49, 'PF0', R(0xDD)); w(67, 'PF1', R(0xDE)); w(85, 'PF2', R(0xDF)); w(103, 'PF0', 0);
        if (y >= R(0xA1)) {
          w(151, 'PF1', 0);
          startLine(); w(-68, 'PF2', 0); w(-59, 'HMOVE');
          state = 'F444';
        } else {
          w(133, 'PF1', 0); w(142, 'GRP0', ind(0x9D, y)); w(151, 'PF2', 0);
          const z = y === R(0x9A);
          startLine(); w(-59, 'HMOVE'); w(-50, 'ENAM0', z ? 2 : 0); w(-26, 'COLUP0', ind(0x9F, y));
          const e = ind(0x9B, y);
          w(-2, 'ENAM1', e); w(7, 'ENABL', e); w(31, 'GRP1', ind(0x94, y));
          y = (y - 1) & 0xFF;
          state = 'F457';
        }
        break;
      }
    }
  }
  out.rows = rows;
  return finish(out);

  // wave end ($F553): "attack wave N completed", the bonus, humanoids left; scores the bonus
  function waveEnd() {
    out.kind = 'wave end';
    const special = X(0xF0CE) === 0x20;
    text(special ? 0x5D : 0x23); band(0x82, 7, 0, 79);
    text(0x2F);
    W(0xF8, M(DIGIT + (R(0x89) & 15) + (special ? 1 : 0)));
    if (R(0x89) >> 4) W(0xF6, M(DIGIT + (R(0x89) >> 4)));
    band(null, 7, 0, 93);
    if (!special) { text(0x39); band(null, 7, 0, 109); }
    if (!(R(0xAA) & 7)) {
      W(0x92, 0);
      let n = 0; for (let b = 0; b < 8; b++) if (R(0xD6) >> b & 1) n++;
      if (n !== R(0xD4)) {
        W(0xD4, R(0xD4) + 1); W(0x90, 0xFD);
        const bcd = (a, b) => { let lo = (a & 15) + (b & 15), c = 0; if (lo > 9) { lo -= 10; c = 1; } let hi = (a >> 4) + (b >> 4) + c; c = 0; if (hi > 9) { hi -= 10; c = 1; } return [(hi << 4 | lo) & 0xFF, c]; };
        const [v, c] = bcd(R(0x8C), X(0xF0CE));
        W(0x8C, v);
        if (c) { W(0x82, R(0x82) + 1); W(0x84, R(0x84) + 1); W(0x83, R(0x83) + 1); W(0x93, 0x8B); W(0x8B, R(0x8B) + 1); }
      }
    }
    W(0x99, 0); W(0xAA, R(0xAA) - 1);
    if (!R(0xAA)) {
      W(0x8E, 0); W(0xD4, 0); W(0x81, 0xFF);
      const wv = R(0x89) & 15;
      if (wv === 0 || wv === 5) { W(0xD6, 0xFF); W(0xA9, 0); }
      W(0x85, 0x53); W(0x99, 0x49);
    }
    out.xramWrites = [[0x01, 1], [0x41, 1]];
    text(0x45);
    if (!special) W(0xFA, M(DIGIT + X(0xF0CE)));
    band(0xC2, 7, 0, 157);
    text(0x2F);
    let yy = R(0xD4), xx = 0;
    while (yy !== 0) {
      W(0xF4 + xx, yy < 2 ? 0x5E : 0x56); xx += 2; yy = (yy - 2) & 0xFF;
      if (yy & 0x80) break;
    }
    band(0x54, 8, 0, 169);
    line = 177; w(-56, 'CXCLR');
    W(0xA2, 0); W(0xA3, 0);
  }

  function finish(o) {
    line = LAST;
    w(-53, 'VBLANK', 2); w(-38, 'COLUBK', 0); w(-29, 'ENAM1', 0); w(-20, 'ENAM0', 0); w(-11, 'ENABL', 0);
    return o;
  }
}

// Play the writes on a bare TIA: { fb, ob, cx, sch } for lines FIRST..LAST (like tools/vcs.js);
// the kernel's collision reads (CXPPMM into $B0,x) are filled into sch.ram.
function render(s) {
  const sch = schedule(s);
  const t = new VCS(rom);
  t.hmoveBlank = true;
  t.r.set(s.r); t.pos = [...s.pos]; t.grpOld = [...s.grpOld]; t.blOld = s.blOld; t.cx = s.cx;
  t.resetLine = [...s.resetLine];
  const reads = {};
  for (const c of sch.cxReads) reads[c.line] = c;
  for (let line = FIRST; line <= LAST; line++) {
    t.line = line;
    const ev = (sch.lines[line] || []).slice().sort((a, b) => a[0] - b[0]);
    let k = 0;
    const apply = ([c, reg, v]) => { t.clock = c + 68; t.tiaWrite(reg, v); };
    const rd = reads[line];
    while (k < ev.length && ev[k][0] <= -68) apply(ev[k++]);
    for (let xx = -68; xx < 160; xx++) {
      while (k < ev.length && ev[k][0] <= xx) apply(ev[k++]);
      if (rd && rd.clock === xx) sch.ram[rd.addr - 0x80] = t.tiaRead(7);
      if (xx >= 0) { t.clock = xx + 68; t.pixel(xx); }
    }
    while (k < ev.length) apply(ev[k++]);
  }
  return { fb: t.fb, ob: t.ob, cx: t.cx, sch };
}

module.exports = { snap, schedule, render, mem, KERNEL, FIRST, LAST, REG, rom, ROMMD5 };
if (require.main !== module) return;

// ---- check against tools/vcs.js over random play: the writes, the pixels, the collisions and
// the RAM the kernel leaves
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const frames = +(process.argv[2] || 3000);
const verbose = process.argv.includes('--verbose');
const showFrame = arg('show', -1);
const play = require('./play')(arg('seed', 1));
const cheat = process.argv.includes('--cheat') ? require('./cheat')() : null;
const NAME = Object.fromEntries(Object.entries(REG).map(([k, v]) => [v, k]));
const vcs = new VCS(rom);
vcs.superChip = true; vcs.hmoveBlank = true;
let state = null, stFrame = -1, log = [];
const origStep = vcs.step.bind(vcs);
vcs.step = function () {
  if (this.pc === KERNEL && this.frames !== stFrame) { state = snap(this); stFrame = this.frames; log = []; }
  if (this.pc === 0xD16C && state && !state.after) state.after = { ram: Uint8Array.from(this.ram), cx: this.cx };
  return origStep();
};
const tw = vcs.tiaWrite.bind(vcs);
vcs.tiaWrite = function (a, v) {
  if (state && !state.after && a !== 2 && !(a >= 0x15 && a <= 0x1A) && this.line >= FIRST && this.line <= LAST) log.push([this.line, this.clock - 68, a, v]);
  return tw(a, v);
};
const cov = {}, count = k => { cov[k] = (cov[k] || 0) + 1; };
let bad = 0, checked = 0;
const NAMES = ['P0', 'P1', 'M0', 'M1', 'BL', 'PF'];
const objs = o => NAMES.filter((n, i) => o & (1 << i)).join('+') || '-';
for (let f = 0; f < frames; f++) {
  if (cheat) cheat(f, vcs.ram, vcs.xram);
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire = p.fire;
  vcs.runFrames(1);
  if (!state || !state.after) continue;
  const m = render(state);
  count(m.sch.kind);
  checked++;
  const diffs = [];
  // writes, line by line (ENAM0 from PHP: only bit 1 counts)
  const STROBE = a => (a >= 0x10 && a <= 0x14) || a >= 0x2A;
  const got = log.filter(e => e[0] <= LAST).map(([l, c, a, v]) => `${l}:${c} ${NAME[a] || a}=${(STROBE(a) ? 0 : a === 0x1D ? v & 2 : v).toString(16)}`);
  const want = [];
  for (const l of Object.keys(m.sch.lines).map(Number).sort((a, b) => a - b))
    for (const [c, a, v, loose] of m.sch.lines[l].slice().sort((p1, p2) => p1[0] - p2[0])) {
      const k = `${NAME[a] || a}=${v.toString(16)}`;
      if (!loose) { want.push(`${l}:${c} ${k}`); continue; }
      const i = got.findIndex(g => (g.startsWith(l + ':') || g.startsWith((l - 1) + ':')) && g.endsWith(' ' + k));   // any clock, that line or the one before
      if (i < 0) diffs.push(`write ${l}:? ${k} missing`); else got.splice(i, 1);
    }
  for (let i = 0; i < Math.max(got.length, want.length); i++) if (got[i] !== want[i]) { diffs.push(`write ${i}: 2600 ${got[i]}, model ${want[i]}`); break; }
  for (let y = FIRST; y <= LAST; y++) for (let x = 0; x < 160; x++) {
    const i = y * 160 + x;
    if (m.fb[i] !== vcs.fb[i] || m.ob[i] !== vcs.ob[i]) diffs.push(`line ${y} px ${x}: 2600 ${objs(vcs.ob[i])} col ${(vcs.fb[i] * 2).toString(16)}, model ${objs(m.ob[i])} col ${(m.fb[i] * 2).toString(16)}`);
  }
  // RAM the kernel leaves (as the game resumes in bank 0); $FE/$FF hold the stack
  for (let a = 0x80; a < 0xFE; a++) if (m.sch.ram[a - 0x80] !== state.after.ram[a - 0x80]) diffs.push(`RAM $${a.toString(16)}: 2600 ${state.after.ram[a - 0x80].toString(16)}, model ${m.sch.ram[a - 0x80].toString(16)}`);
  if ((m.cx & 0x7FFF) !== (state.after.cx & 0x7FFF)) diffs.push(`collisions: 2600 ${state.after.cx.toString(2)}, model ${m.cx.toString(2)}`);
  if (diffs.length) {
    bad++;
    if (bad <= 5 || verbose) console.log(`frame ${f} (${m.sch.kind}): ${diffs.length} differences:\n  ` + diffs.slice(0, 12).join('\n  '));
  }
  if (f === showFrame) {
    vcs.cropTop = 30; vcs.cropHeight = 200; vcs.savePNG('show-2600.png');
    const v2 = new VCS(rom); v2.fb = m.fb; v2.cropTop = 30; v2.cropHeight = 200; v2.savePNG('show-model.png');
  }
}
console.log('kernels (frames):', Object.entries(cov).sort().map(([k, n]) => `${k} ${n}`).join(', '));
console.log(`${checked} frames checked, ${bad} with differences`);
