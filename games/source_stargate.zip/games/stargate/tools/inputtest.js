// Test the C64 version's controls (ReadInput) on the 6502 of tools/c64sim.js with an
// emulated keyboard matrix and joysticks: the 2600 ports it fills in for each key.
//   node games/stargate/tools/inputtest.js
const { C64 } = require('./c64sim');
const c64 = new C64();
c64.start(true);
const M = c64.mem, sym = n => c64.sym(n);
// C64 keyboard: [row (CIA 1 port A bit), column (port B bit)]
const KEYS = { F1: [0, 4], F3: [0, 5], F5: [0, 6], F7: [0, 3], RETURN: [0, 1], LSHIFT: [1, 7], RSHIFT: [6, 4], W: [1, 1], A: [1, 2],
  S: [1, 5], D: [2, 2], SPACE: [7, 4], I: [4, 1], K: [4, 5], J: [4, 2], 6: [2, 3], F: [2, 5] };
let held = [], joy2 = 0xFF, joy1 = 0xFF, portA = 0xFF;
const rd = c64.read.bind(c64), wr = c64.write.bind(c64);
c64.read = function (a) {
  if (this.ioOn() && a === 0xDC00) return portA & joy2;
  if (this.ioOn() && a === 0xDC01) {
    let v = 0xFF;
    for (const k of held) { const [r, c] = KEYS[k]; if (!(portA & (1 << r))) v &= ~(1 << c); }
    return v & joy1;
  }
  return rd(a);
};
c64.write = function (a, v) { if (this.ioOn() && a === 0xDC00) portA = v; return wr(a, v); };
const read = (keys, j2 = 0xFF, j1 = 0xFF) => {
  held = keys; joy2 = j2; joy1 = j1;
  c64.call(sym('ReadInput'));
  return { swcha: M[0x280], swchb: M[0x282], inpt4: M[0x3C], inpt5: M[0x3D], flicker: M[sym('Flicker')], power: M[sym('PowerReq')] };
};
const hex = v => '$' + v.toString(16).padStart(2, '0');
let fails = 0;
const check = (name, got, want) => {
  const bad = Object.keys(want).filter(k => got[k] !== want[k]);
  if (bad.length) fails++;
  console.log(`${bad.length ? 'FAIL' : 'ok  '} ${name}${bad.length ? ': ' + bad.map(k => `${k} ${hex(got[k])} (want ${hex(want[k])})`).join(', ') : ''}`);
};
M[0x82] = 3;                                   // a game running (ships left)
check('nothing', read([]), { swcha: 0xFF, swchb: 0x0B, inpt4: 0x80, inpt5: 0x80 });
check('W: left joystick up', read(['W']), { swcha: 0xEF });
check('S: down', read(['S']), { swcha: 0xDF });
check('A: left', read(['A']), { swcha: 0xBF });
check('D: right', read(['D']), { swcha: 0x7F });
check('W + D: up and right', read(['W', 'D']), { swcha: 0x6F });
check('Space: laser (left fire)', read(['SPACE']), { inpt4: 0x00, inpt5: 0x80 });
check('I: right joystick up (inviso)', read(['I']), { swcha: 0xFE });
check('K: right joystick down (hyperspace)', read(['K']), { swcha: 0xFD });
check('Return: right fire (smartbomb)', read(['RETURN']), { inpt4: 0x80, inpt5: 0x00 });
check('J: nothing', read(['J']), { swcha: 0xFF, inpt4: 0x80, inpt5: 0x80 });
check('joystick port 2 up: left joystick', read([], 0xFE), { swcha: 0xEF, inpt4: 0x80 });
check('joystick port 2 right', read([], 0xF7), { swcha: 0x7F });
check('joystick port 2 fire: laser', read([], 0xEF), { inpt4: 0x00, inpt5: 0x80 });
check('joystick port 1 up: inviso', read([], 0xFF, 0xFE), { swcha: 0xFE });
check('joystick port 1 down: hyperspace', read([], 0xFF, 0xFD), { swcha: 0xFD });
check('joystick port 1 fire: smartbomb', read([], 0xFF, 0xEF), { inpt4: 0x80, inpt5: 0x00 });
check('both joysticks at once', read([], 0xF6, 0xED), { swcha: 0x6D, inpt4: 0x80, inpt5: 0x00 });
check('port 1 held: keys on its lines ignored, others work', read(['W', 'SPACE'], 0xFF, 0xFE), { swcha: 0xEE, inpt4: 0x00 });
check('F1: Game Reset', read(['F1']), { swchb: 0x0A, power: 0 });
read([]);
check('F2 (F1 + shift): power, not reset', read(['F1', 'LSHIFT']), { swchb: 0x0B, power: 1 });
M[sym('PowerReq')] = 0;
check('F2 held: no second request', read(['F1', 'RSHIFT']), { power: 0 });
read([]);
check('F3: Game Select', read(['F3']), { swchb: 0x09 });
read([]);
check('F5: black and white', read(['F5']), { swchb: 0x03 });
check('F5 held: no change', read(['F5']), { swchb: 0x03 });
read([]); read(['F5']); read([]);
check('F5 again: colour', read([]), { swchb: 0x0B });
read(['F7']); read([]);
check('F7: left difficulty A', read([]), { swchb: 0x4B });
read(['F7', 'LSHIFT']); read([]);
check('F8: right difficulty A', read([]), { swchb: 0xCB });
read(['F7']); read([]); read(['F7', 'RSHIFT']); read([]);
check('F7, F8 again: both B', read([]), { swchb: 0x0B });
const f0 = M[sym('Flicker')];
read(['F']); read([]);
check('F: flicker toggles', read([]), { flicker: f0 ^ 1 });
read(['6']); read([]);
check('6: no change', read([]), { flicker: f0 ^ 1 });
read(['F']); read([]);
M[0x82] = 0;                                   // no game running
check('fire with no game: Game Reset', read(['SPACE']), { swchb: 0x0A });
check('joystick fire with no game: Game Reset', read([], 0xEF), { swchb: 0x0A });
M[0x82] = 3;
check('fire in a game: no reset', read(['SPACE']), { swchb: 0x0B });
console.log(fails ? `${fails} failed` : 'all passed');
process.exit(fails ? 1 : 0);
