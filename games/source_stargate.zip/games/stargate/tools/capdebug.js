// Debugging aid: run lockstep's game to frame N, then print the C64 capture (FieldHook's
// findings) next to the model's picture facts for the same frame.
//   node games/stargate/tools/capdebug.js <frame> [--seed=N] [--cheat]
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const model = require('./model');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const N = +process.argv[2];
const c64 = new C64();
c64.start(true);
const sym = n => c64.sym(n);
const vcs = new VCS(rom); vcs.superChip = true; vcs.hmoveBlank = true;
let snap = null, sf = -1, atResume = false, rf = -1;
const os = vcs.step.bind(vcs);
vcs.step = function () {
  if (this.pc === model.KERNEL && this.frames !== sf) { snap = model.snap(this); sf = this.frames; }
  if (this.pc === 0xD16C && this.frames !== rf) { atResume = true; rf = this.frames; }
  return os();
};
const play = require('./play')(arg('seed', 11));
const cheat = process.argv.includes('--cheat') ? require('./cheat')() : null;
for (let f = 0; f <= N; f++) {
  if (cheat) { cheat(f, vcs.ram, vcs.xram); c64.mem.set(vcs.ram.subarray(0, 0x7E), 0x80); c64.mem.set(vcs.xram, 0xF080); }
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire = p.fire;
  c64.mem[0x0280] = p.swcha; c64.mem[0x0282] = p.swchb; c64.mem[0x3C] = p.fire[0] ? 0 : 0x80; c64.mem[0x3D] = p.fire[1] ? 0 : 0x80;
  atResume = false; while (!atResume) vcs.step();
  c64.call(sym('Tick'));
  if (f < N) { for (let a = 0x80; a < 0xFE; a++) c64.mem[a] = vcs.ram[a - 0x80]; c64.mem.set(vcs.xram, 0xF080); }
}
const m = c64.mem, b = n => m[sym(n)], arr = (n, k) => [...m.subarray(sym(n), sym(n) + k)];
const h = v => v.toString(16).padStart(2, '0');
console.log('C64: kind', b('CapKind'), 'nD', b('nD'), 'ShipX', b('ShipX'), 'ShipTop', h(b('ShipTop')), 'M0X', b('M0X'), 'M1X83', b('M1X83'), 'BLX83', b('BLX83'));
const nD = b('nD');
for (const k of ['DSlot', 'DR1', 'DTop', 'DBot', 'DQuirk', 'DRef', 'DX', 'DPg', 'DCLo', 'DGLo']) console.log('  ' + k.padEnd(7), arr(k, nD).map(h).join(' '));
console.log('  laser on', b('lzOn'), 'Y', h(b('lzY')), 'act', b('lzAct'), ' shot seen', b('m0Seen'), 'on', b('m0On'), 'off', b('m0Off'), 'cols', arr('m0Col', 3).map(h).join(' '), ' m1Y', h(b('m1Y')));
console.log('  m0 lines', b('m0N'), 'Y', arr('m0Y', 3).map(h).join(' '), 'X0', arr('m0X0', 3).join(' '), 'X1', arr('m0X1', 3).join(' '));
console.log('  CXM0P', h(m[0x30]), 'CXP0FB', h(m[0x32]), ' 2600:', h(vcs.tiaRead(0)), h(vcs.tiaRead(2)), 'cx bits', vcs.cx.toString(2));
// the model: which objects where
const r = model.render(snap);
const R = a => snap.ram[a - 0x80];
console.log('2600: slots $A2', R(0xA2), 'ShotRow', h(R(0x9A)), 'LaserRow', h(R(0xD7)), 'ShipRow', h(R(0x97)), 'pos codes', [0x85, 0x86, 0x87, 0x88].map(a => h(R(a))).join(' '));
const NAMES = ['P0', 'P1', 'M0', 'M1', 'BL', 'PF'];
for (let L = 84; L <= 224; L++) {
  const objs = [];
  for (let x = 0; x < 160; x++) { const o = r.ob[L * 160 + x]; if (o & 0x3D) objs.push(x + ':' + NAMES.filter((n, i) => o & (1 << i)).join('+')); }
  const sel = process.argv.includes("--all") ? objs : objs.filter(s => /P0|M0|PF/.test(s));
  if (sel.length) console.log(`  line ${L} (Y ${h(223 - L)}): ${sel.slice(0, 14).join(' ')}${sel.length > 14 ? ' ...' : ''}`);
}
if (process.argv.includes('--tables')) {
  console.log('Times3Mod', [...m.subarray(0xC500, 0xC500 + 50)].join(' '));
  console.log('star bytes at 5c-5e', [0x5c, 0x5d, 0x5e].map(y => h(m[(m[0x9B] | m[0x9C] << 8) + y])).join(' '), 'ptr', h(m[0x9C]) + h(m[0x9B]));
}
if (process.argv.includes('--sprites')) {
  m[sym('pending')] = 0; m[sym('curBuf')] ^= 1;
  c64.call(sym('Render'));
  const rb = m[sym('rb')], vic = rb ? 0x8000 : 0x4000;
  for (let s = 0; s < 8; s++) {
    const st = sym('StX') + 8 * rb + s;
    if (!(m[sym('StEn') + rb] >> s & 1)) continue;
    const rows = [];
    for (let r = 0; r < 21; r++) { const b = vic + m[vic + 0x3F8 + s] * 64 + r * 3; rows.push([m[b], m[b + 1], m[b + 2]].map(h).join('')); }
    console.log(`sprite ${s}: x ${m[st] | ((m[sym('StMsb') + rb] >> s & 1) << 8)} y ${m[st + 16]} col ${m[st + 32]} rows ${rows.join(' ')}`);
  }
}
{ const lineArg = process.argv.find(a => a.startsWith('--line=')); if (lineArg) { const L = +lineArg.slice(7); console.log(`model line ${L} colours:`, [...r.fb.subarray(L * 160, L * 160 + 160)].map((c, x) => c ? `${x}:${(c * 2).toString(16)}` : '').filter(Boolean).join(' ')); } }
if (process.argv.includes('--colours')) {
  const nD = m[sym('nD')];
  for (let d = 0; d < nD; d++) {
    const pg = m[sym('DPg') + d], cl = m[sym('DCLo') + d], gl = m[sym('DGLo') + d], top = m[sym('DTop') + d], bot = m[sym('DBot') + d];
    const rows = [];
    for (let y = top; y >= bot && y; y--) rows.push(`${h(m[(pg << 8) + gl + y])}/${h(m[(pg << 8) + cl + y])}`);
    console.log(`slot ${d}: rows gfx/colour`, rows.join(' '));
  }
}
if (process.argv.includes('--mc')) console.log('EnMcA', [...m.subarray(sym('EnMcA'), sym('EnMcA') + 6)].join(','), 'EnMcB', [...m.subarray(sym('EnMcB'), sym('EnMcB') + 6)].join(','), 'ColorMap[0..8]', [...m.subarray(sym('ColorMap'), sym('ColorMap') + 8)].join(','));
if (process.argv.includes('--encol')) {
  for (let d = 0; d < m[sym('nD')]; d++) {
    m[sym('cD')] = d; c64.call(sym('EnColours'));
    console.log('slot', d, 'ec', m[sym('ec0')], m[sym('ec1')], m[sym('ec2')], 'codes', [...m.subarray(sym('RowCode'), sym('RowCode') + 12)].join(''));
  }
}
