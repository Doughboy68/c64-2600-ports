// Draws the C64 frame from what the C64 code set up (the multicolour bitmap, its screen and
// colour RAM, the staged sprites and the raster schedule) and compares it with the 2600's
// picture (tools/model.js, which matches tools/vcs.js), in C64 colours (the C64 version's
// ColorMap), line by line for lines 37-223. Runs the game as lockstep.js does.
//   node games/stargate/tools/screencheck.js [frames] [--seed=N] [--cheat] [--verbose] [--idle=N]
//        [--show=frame] [--from=N] [--skip=N]
// --skip=N: about one frame in N (pseudo-random) not drawn, as when the C64 runs late (the next
// frame drawn then goes to the buffer that showed the other kind of tick: flicker's turns).
// --show=N saves show-2600.png and show-c64.png for frame N (C64 colours, VICE's palette).
const fs = require('fs');
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const model = require('./model');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const frames = +(process.argv[2] || 2000);
const verbose = process.argv.includes('--verbose');
const showFrame = arg('show', -1), from = arg('from', 0), skipN = arg('skip', 0);
const skipped = f => skipN > 0 && (Math.imul(f + 1, 2654435761) >>> 0) % skipN === 0;

const c64 = new C64();
c64.start(true);
const sym = n => c64.sym(n);
const COLMAP = [...c64.mem.subarray(sym('ColorMap'), sym('ColorMap') + 128)];
const PEPTO = ['000000', 'FFFFFF', '96282E', '5BD6CE', '9F2DAD', '41B936', '2724C4', 'EFF347', '9F4815', '5E3500', 'DA5F66', '474747', '787878', '91FF84', '6864FF', 'AEAEAE'];

const vcs = new VCS(rom); vcs.superChip = true; vcs.hmoveBlank = true;
let snap = null, sf = -1, atResume = false, rf = -1;
const os = vcs.step.bind(vcs);
vcs.step = function () {
  if (this.pc === model.KERNEL && this.frames !== sf) { snap = model.snap(this); sf = this.frames; }
  if (this.pc === 0xD16C && this.frames !== rf) { atResume = true; rf = this.frames; }
  return os();
};

// The C64 picture of buffer b: C64 colour per 2600 pixel, lines 37-223
function c64Frame(b) {
  const m = c64.mem, io = c64.io;
  const vic = b ? 0x8000 : 0x4000, bmp = vic + 0x2000, scr = vic;
  const out = new Uint8Array(160 * 262).fill(255);
  const stage = 8 * b;
  const St = n => sym(n);
  const en = m[St('StEn') + b], msb = m[St('StMsb') + b];
  let bg = m[St('StBg') + b] & 15, mc1 = m[St('StMc1') + b] & 15, mc2 = m[St('StMc2') + b] & 15;
  const spr = [];
  for (let i = 0; i < 8; i++) spr.push({ x: m[St('StX') + stage + i] | ((msb >> i & 1) << 8), y: m[St('StY') + stage + i], col: m[St('StCol') + stage + i] & 15, on: en >> i & 1, ptr: m[scr + 0x3F8 + i] });
  // the schedule: changes by raster
  const sch = [];
  for (let i = m[St('SchBase') + b]; i < 2 * 24; i++) {
    const t = m[St('SchType') + i];
    if (t === 0xFF) break;
    sch.push({ ras: m[St('SchRas') + i], t, a: m[St('SchA') + i], b: m[St('SchB') + i], c: m[St('SchC') + i], d: m[St('SchD') + i], e: m[St('SchE') + i] });
  }
  let xs = 0, ecm = false;
  for (let L = 37; L <= 223; L++) {
    const ras = L + 14;
    for (const s of sch) if (s.ras === ras) {              // (the interrupt comes 2 lines before: written as raster r starts)
      if (s.t === 0) { mc1 = s.a & 15; mc2 = s.b & 15; }
      else if (s.t === 1) bg = s.a & 15;
      else if (s.t === 3) xs = (s.a & 7) >> 1;                 // $D016: fine scroll (2600 pixels)
      else if (s.t === 4) ecm = (s.a & 0x40) !== 0;            // $D011: ECM + bitmap = black graphics
      else { const n = s.a >> 1; spr[n].x = s.b | ((s.e >> n & 1) << 8); spr[n].y = s.c; spr[n].col = s.d & 15; }
    }
    const bl = L - 37, row = bl >> 3;
    for (let x = 0; x < 160; x++) {
      const bx = x - xs;                                        // (the fine scroll: background left of it)
      let col = bg;
      if (bx >= 0) {
        const cell = bx >> 2, byte = m[bmp + row * 320 + cell * 8 + (bl & 7)];
        const v = byte >> (6 - 2 * (bx & 3)) & 3;
        const s = m[scr + row * 40 + cell], cr = c64.colram[row * 40 + cell];
        col = [bg, s >> 4, s & 15, cr][v];
      }
      if (ecm) col = 0;
      // sprites: the lowest number in front
      for (let i = 7; i >= 0; i--) {
        const sp = spr[i];
        if (!sp.on) continue;
        const r = ras - (sp.y + 1);
        if (r < 0 || r >= 21) continue;
        const px = (sp.x - 24) / 2;                          // 2600 pixel of the sprite's first multicolour pixel
        const j = x - Math.floor(px);
        if (j < 0 || j >= 12) continue;
        const data = m[vic + sp.ptr * 64 + r * 3 + (j >> 2)];
        const sv = data >> (6 - 2 * (j & 3)) & 3;
        if (sv) col = [0, mc1, sp.col, mc2][sv];
      }
      out[L * 160 + x] = col;
    }
  }
  return out;
}

function png(file, pix) {
  const v = new VCS(rom);
  // write via a tiny PNG of C64 colours (2x wide pixels)
  const W = 320, H = 187, zlib = require('zlib');
  const raw = Buffer.alloc((W * 3 + 1) * H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const c = pix[(y + 37) * 160 + (x >> 1)];
    const h = PEPTO[c === 255 ? 0 : c];
    raw.set([0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)), y * (W * 3 + 1) + 1 + x * 3);
  }
  const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; return c; });
  const crc32 = buf => { let c = -1; for (const x of buf) c = CRC[(c ^ x) & 0xFF] ^ (c >>> 8); return (c ^ -1) >>> 0; };
  const chunk = (type, data) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]); const c = Buffer.alloc(4); c.writeUInt32BE(crc32(td)); return Buffer.concat([len, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2;
  fs.writeFileSync(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
}

if (process.argv.includes('--noflicker')) c64.mem[sym('Flicker')] = 0;   // (flicker off: the game's hidden objects drawn too)
if (process.env.SG_SLOW) c64.mem[sym('BuildLayer')] = 0x60;          // (testing: the slow star path always)
const play0 = require('./play')(arg('seed', 11));
// --idle=N: from frame N no input, and the game's idle counter ($F0FD) at $80: idle mode at once
const idleAt = arg('idle', -1);
const play = (f, ram) => {
  if (idleAt < 0 || f < idleAt) return play0(f, ram);
  if (f === idleAt) { vcs.xram[0x7D] = 0x80; c64.mem[0xF0FD] = 0x80; }
  return { swcha: 0xFF, swchb: 0x0B, fire: [false, false] };
};
const cheat = process.argv.includes('--cheat') ? require('./cheat')() : null;
let bad = 0, checked = 0;
const kinds = {}, badKinds = {};
for (let f = 0; f < frames; f++) {
  if (cheat) { cheat(f, vcs.ram, vcs.xram); c64.mem.set(vcs.ram.subarray(0, 0x7E), 0x80); c64.mem.set(vcs.xram, 0xF080); }
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire = p.fire;
  c64.mem[0x0280] = p.swcha; c64.mem[0x0282] = p.swchb; c64.mem[0x3C] = p.fire[0] ? 0 : 0x80; c64.mem[0x3D] = p.fire[1] ? 0 : 0x80;
  atResume = false; while (!atResume) vcs.step();
  c64.call(sym('Tick'));
  for (let a = 0x80; a < 0xFE; a++) c64.mem[a] = vcs.ram[a - 0x80];        // (lockstep checks the logic: keep in step)
  c64.mem.set(vcs.xram, 0xF080);
  if (skipped(f)) continue;
  c64.mem[sym('pending')] = 0;
  c64.mem[sym('curBuf')] ^= 1;
  c64.call(sym('Render'));
  const b = c64.mem[sym('rb')];
  if (f < from || !snap) continue;
  const r = model.render(snap);
  if (process.env.SG_OBJ && f === showFrame) for (const L of process.env.SG_OBJ.split(",").map(Number)) { const o = []; for (let x = 0; x < 160; x++) { const b = r.ob[L * 160 + x]; if (b || (COLMAP[r.fb[L * 160 + x]] & 15) !== (COLMAP[r.fb[L * 160 + 159]] & 15)) o.push(x + ":" + b.toString(2) + "/" + (COLMAP[r.fb[L * 160 + x]] & 15)); } console.log("2600 line", L, o.join(" ")); }
  const kind = r.sch.kind;
  kinds[kind] = (kinds[kind] || 0) + 1;
  const pic = c64Frame(b);
  checked++;
  const diffs = [];
  for (let L = 37; L <= 223; L++) for (let x = 0; x < 160; x++) {
    const want = COLMAP[r.fb[L * 160 + x]] & 15, got = pic[L * 160 + x];
    if (want !== got) diffs.push({ L, x, want, got, ob: r.ob[L * 160 + x] });
  }
  if (diffs.length) {
    bad++;
    badKinds[kind] = (badKinds[kind] || 0) + 1;
    if (bad <= 6 || verbose) {
      const lines = [...new Set(diffs.map(d => d.L))];
      console.log(`frame ${f} (${kind}): ${diffs.length} pixels differ on ${lines.length} lines (${lines.slice(0, 12).join(' ')}${lines.length > 12 ? ' ...' : ''})`);
      const NAMES = ['P0', 'P1', 'M0', 'M1', 'BL', 'PF'];
      for (const d of diffs.slice(0, arg("ndiff", 6))) console.log(`   line ${d.L} px ${d.x}: 2600 ${d.want} (${NAMES.filter((n, i) => d.ob & (1 << i)).join('+') || 'bg'}), C64 ${d.got}`);
    }
  }
  if (f === showFrame && process.argv.includes("--dump")) { const vic = b ? 0x8000 : 0x4000; for (let s = 0; s < 8; s++) { const rows = []; for (let rr = 0; rr < 21; rr++) { const a = vic + c64.mem[vic + 0x3F8 + s] * 64 + rr * 3; rows.push([0, 1, 2].map(i => c64.mem[a + i].toString(16).padStart(2, "0")).join("")); } if (s === 0) { const sb = c64.mem[sym("SchBase") + b]; const e = []; for (let i = sb; i < sb + 24 && c64.mem[sym("SchType") + i] !== 255; i++) e.push(["SchRas","SchType","SchA","SchB"].map(n => c64.mem[sym(n) + i]).join("/")); console.log("nD", c64.mem[sym("nD")], "DTop", [0,1,2,3].map(i => c64.mem[sym("DTop") + i].toString(16)).join(","), "DBot", [0,1,2,3].map(i => c64.mem[sym("DBot") + i].toString(16)).join(","), "DCLo", [0,1,2,3].map(i => c64.mem[sym("DCLo") + i].toString(16)).join(","), "DPg", [0,1,2,3].map(i => c64.mem[sym("DPg") + i].toString(16)).join(","), "MaskY", [...c64.mem.subarray(0x0700, 0x0790)].map((v, i) => v ? i.toString(16) + ":" + v.toString(16) : "").filter(Boolean).join(" "), "DX", [0,1,2,3].map(i => c64.mem[sym("DX") + i]).join(","), "DQuirk", [0,1,2,3].map(i => c64.mem[sym("DQuirk") + i]).join(",")); console.log("StMc", c64.mem[sym("StMc1") + b], c64.mem[sym("StMc2") + b], "StBg", c64.mem[sym("StBg") + b], "sched", e.join(" "), "EffA", [0,1,2,3,4,5].map(i => c64.mem[sym("EffA") + i]).join(","), "EnMcA", [0,1,2,3,4,5].map(i => c64.mem[sym("EnMcA") + i]).join(",")); } if (s === 0) console.log("m0", ["m0N","m0Seen","m0On","m0Off","M0X","ShotRow"].map(n => n + "=" + c64.mem[n === "ShotRow" ? 0x9A : sym(n)]).join(" "), "cols", [0,1,2].map(i => c64.mem[sym("m0Col") + i].toString(16)).join(" "), "X0", [0,1,2].map(i => c64.mem[sym("m0X0") + i]).join(" "), "X1", [0,1,2].map(i => c64.mem[sym("m0X1") + i]).join(" "), "col0", c64.mem[sym("StCol") + 8 * b]); console.log("sprite", s, "en", c64.mem[sym("StEn") + b] >> s & 1, rows.join(" ")); } }
  if (f === showFrame) {
    const want = new Uint8Array(160 * 262);
    for (let i = 0; i < want.length; i++) want[i] = COLMAP[r.fb[i]] & 15;
    png('show-2600.png', want); png('show-c64.png', pic);
    console.log('saved show-2600.png, show-c64.png');
  }
}
console.log('kinds:', Object.entries(kinds).map(([k, n]) => `${k} ${n}` + (badKinds[k] ? ` (${badKinds[k]} differ)` : '')).join(', '));
console.log(`${checked} frames checked, ${bad} differ`);
