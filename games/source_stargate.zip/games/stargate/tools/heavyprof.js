// Speed: the auto game's heavy frames (tick + render over LIMIT cycles, the ones that come late on
// NTSC): cycles per routine (exclusive) per heavy frame.
//   node games/stargate/tools/heavyprof.js [LIMIT, default 17000]
const { C64 } = require('./c64sim');
const fs = require('fs');
const c64 = new C64(); c64.start(true);
const sym = n => c64.sym(n), M = c64.mem;
const LIMIT = +(process.argv[2] || 17000);
const labels = [...c64.lst.matchAll(/^\.([0-9a-f]{4})\t(?:([0-9a-f]{4})\t)?(?:.*\t)?([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[2] || m[1], 16), m[3]]);
labels.sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xD000 && !(pc >= 0xE000 && pc < 0xF000)) return '2600 program'; if (pc >= 0x5000 && pc < 0x6000 || pc >= 0xE000 && pc < 0xF000) return 'layer code'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
let acc = {}; const st = c64.step.bind(c64);
c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc); acc[k] = (acc[k] || 0) + this.cycles - c; return r; };
M[sym('DbgAuto')] = 1; c64.call(sym('PowerCycle'));
let f = 0, n = 0; const tot = {};
while (M[sym('DbgAuto')] && f < 7500) {
  acc = {}; const t = c64.call(sym('Tick')); M[sym('pending')] = 0; M[sym('curBuf')] ^= 1; const r = c64.call(sym('Render')); f++;
  if (f < 300 || t + r <= LIMIT) continue;
  n++; for (const [k, v] of Object.entries(acc)) tot[k] = (tot[k] || 0) + v;
}
console.log(`${n} frames over ${LIMIT}`);
for (const [k, v] of Object.entries(tot).sort((a, b) => b[1] - a[1]).slice(0, 40)) console.log('  ' + k.padEnd(18), Math.round(v / n));
