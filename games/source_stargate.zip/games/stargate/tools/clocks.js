// For every kernel instruction that writes the TIA, the clocks (beam positions) it writes at,
// over many frames of random play: which writes are fixed in time, which vary.
//   node games/stargate/tools/clocks.js [frames] [seed]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('0c48e820301251fbb6bcdc89bd3555d9'));
vcs.superChip = true;
const N = ['VSYNC', 'VBLANK', 'WSYNC', 'RSYNC', 'NUSIZ0', 'NUSIZ1', 'COLUP0', 'COLUP1', 'COLUPF', 'COLUBK', 'CTRLPF',
  'REFP0', 'REFP1', 'PF0', 'PF1', 'PF2', 'RESP0', 'RESP1', 'RESM0', 'RESM1', 'RESBL', 'AUDC0', 'AUDC1', 'AUDF0', 'AUDF1',
  'AUDV0', 'AUDV1', 'GRP0', 'GRP1', 'ENAM0', 'ENAM1', 'ENABL', 'HMP0', 'HMP1', 'HMM0', 'HMM1', 'HMBL', 'VDELP0', 'VDELP1',
  'VDELBL', 'RESMP0', 'RESMP1', 'HMOVE', 'HMCLR', 'CXCLR'];
const frames = +(process.argv[2] || 3000);
const play = require('./play')(+(process.argv[3] || 1));
const seen = new Map();
const tw = vcs.tiaWrite.bind(vcs);
vcs.tiaWrite = function (a, v) {
  if (this.bank === 1 && a !== 2 && !(a >= 0x15 && a <= 0x1A)) {
    const k = this.lastPc.toString(16) + ' ' + (N[a] || a);
    if (!seen.has(k)) seen.set(k, new Map());
    const m = seen.get(k), c = this.clock - 68;
    m.set(c, (m.get(c) || 0) + 1);
  }
  return tw(a, v);
};
for (let f = 0; f < frames; f++) {
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire = p.fire;
  vcs.runFrames(1);
}
for (const [k, m] of [...seen].sort()) {
  const cs = [...m].sort((a, b) => a[0] - b[0]);
  console.log(k.padEnd(14), cs.length === 1 ? cs[0][0] : cs.map(([c, n]) => `${c}x${n}`).join(' '));
}
