@echo off
rem Build Stargate:
rem   build\stargate.a26        the 2600 ROM (8K, two banks, SuperChip) rebuilt from source (checked against the original)
rem   build\stargate-V.prg      the Commodore 64 version
rem   build\stargate-V.d64      the C64 version on a disk image
rem The original ROM (or its .zip) must be in roms_port\ (found by MD5, any file name).
rem (V: the version in the BASIC listing; file names at most 16 characters: ..\..\tools\buildname.js)
cd /d "%~dp0"
set TASS=..\..\tools\64tass\64tass.exe
set MD5=0c48e820301251fbb6bcdc89bd3555d9
if not exist build mkdir build
if not exist 2600\stargate.asm node ..\..\tools\disasm.js . || exit /b 1
set NAME=
for /f %%n in ('node ..\..\tools\buildname.js . stargate') do set NAME=%%n
if "%NAME%"=="" (echo no build name: see tools\buildname.js & exit /b 1)

node ..\..\tools\rom.js %MD5% build\original.a26 >nul || exit /b 1
%TASS% -q --nostart -o build\stargate.a26 2600\stargate.asm || exit /b 1
fc /b build\original.a26 build\stargate.a26 >nul && (echo OK: build\stargate.a26 matches the original ROM) || (echo DIFFERENT: build differs from the original ROM & exit /b 1)

node tools\mkc64tables.js >nul || exit /b 1
node tools\mkpatches.js >nul || exit /b 1
del /q build\stargate-*.prg build\stargate-*.d64 build\stargate-*.lst 2>nul
%TASS% -q -C -a -o build\%NAME%.prg -L build\%NAME%.lst c64\main.asm || exit /b 1
echo OK: build\%NAME%.prg


where c1541 >nul 2>&1 || (echo c1541 not found, skipping the disk image & exit /b 0)
if exist build\%NAME%.d64 del build\%NAME%.d64
c1541 -format "stargate,sg" d64 build\%NAME%.d64 -write build\%NAME%.prg "stargate" >nul || exit /b 1
echo OK: build\%NAME%.d64
