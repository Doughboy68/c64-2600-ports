# Stargate port: handoff (2026-10-05, after the third session: speed)

Version 1.0, published 2026-10-05 (the next version: 1.1). Read this, `README.md` (how it works, every tool), the top-level README,
and the memory notes `stargate-port.md`, `c64-vic-lessons.md` and `vice-launch-monitor.md`.

## Where it stands

| Part | State |
|---|---|
| Game logic | Exact: `tools/lockstep.js` 0 differences (seeds 11, 3, 5 `--cheat`, `--power=N`, `--noflicker`, `--idle=N`). |
| Picture | `tools/screencheck.js`: 1-2 frames in 2,000-3,000 differ (seed 11: 1, `--seed=3` 3000: 2, `--seed=5 --cheat` 3000: 2; `--skip=4`: 1, `--seed=5 --cheat --skip=3`: 0). |
| Features | Flicker off (F), idle mode, background flashes, standard keys, sound: done. |
| VICE | c64test, inputtest (all pass), soundcheck (ok), stress (no freeze, many 5-minute runs this session). |
| **Speed** | Much better; still the open item on NTSC. |

## Speed: the numbers

The measure is **frames repeated** (a frame end with nothing new to show), from `tools/c64late.js`
(VICE, the C64 plays by itself into wave 8, 7200 ticks, flicker on, the timing aids off). The old
"late" count isn't comparable (it counted passes, with the timing aids on, which cost ~150 repeats).

| | Session start (fbfffe7 + counters) | 921f7dd (VICE) | 92248f3 (VICE) | now (loopsim) |
|---|---|---|---|---|
| NTSC repeated | 1444 | 1088 | 987 | ~962 |
| PAL repeated | 987 | 626 | 541 | ~536 |

`tools/loopsim.js` (the whole program with a raster on the simulator: main loop, interrupts,
badlines, sprite fetches; 5 s a run) agrees with VICE within ~3% and is deterministic: use it for
every idea, confirm in VICE now and then. Small changes move it by +-10 (timing chaos).
`loopsim --steal=-N` gives N cycles a frame more: about 200 repeats less per 500 cycles a frame.

## What was done (commits 73ce5a4 .. d9f597c)

* Main loop: the frame-end interrupt counts the ticks due (`owed`, at most 6); the loop never
  idles while there is work; it draws when the other buffer is free unless 4+ ticks are due.
  (Ticks-first from 2 due was worse: drawing while a little behind lets busy frames borrow from
  quiet ones; the picture may then trail the game by up to ~3 frames in busy moments.)
* SprCopy: an enemy image the other buffer already built (same key) is copied. With flicker each
  buffer normally shows one parity of ticks; a skipped frame swaps that and every enemy image was
  rebuilt (a cascade into more late frames).
* ReadInput quick path when no key is down; DigitPtrs reuse while the score is the same;
  BandHook leaner, and the score/icon bands skip the loop's leftover state (their callers never
  use it); LoadTextPtrs unrolled (TextPtrsC patch); FieldColour unrolled; the raster interrupt
  leaner (JMP (irqVec), X/Y in zero page, the next entry set up while waiting); SprPlace and the
  DrawSprites enemy loop leaner; Schedule's enemy entries without temporaries; DrawScanner's row
  loop by shifting; the testing aids cheap when off; the frame top writes only the shown sprites' registers;
  BandHook compares the caller (line and rows are constants per caller); the SID pulse width once.
* Memory: part 3 ($8600) holds only this machine's SID tables (DetectPal copies them, before
  InitVideo) and code from $8A00 (input.asm, auto.asm). Free: below $4000 ~300 bytes, part 2
  ~260, part 3 ~700.
* Tools: `loopsim.js` (`--prof`: cycles per routine under the real loop; `--poke=Label:value`),
  `screencheck --skip=N` (frames left undrawn as when late: caught a SprCopy bug), c64late prints
  frame ends / repeated / ticks left out (`--timing` for the old timing aids), DbgFrames /
  DbgRepeat / DbgLost counters.

## Measured and dropped

* Single-pass EnemyBuild (colour mask patched in): slower (~3 colour changes a build, 40% of
  builds have black rows to fix up afterwards).
* Colour pass reusing the last row's mask: no gain. LayerEdge skip when nothing moved: ~2% of
  frames. DrawScanner early exit: never triggers. UpdateSound quick check: sound changes on half
  the ticks.
* Running a tick ahead (render the older state later): Render reads ~150-200 bytes the next tick
  overwrites; too costly to keep.
* Walk loop without the laser check when it can't come: no gain. Testing counters in IEnd only
  with DbgAuto: real play -50 cycles but the measurement +20 repeats (kept inline). Layer move
  clearing only bytes the new draw doesn't cover (41 of 110 have a neighbour; moves are ±1 cell):
  needs ~3K more generated code.
* **Parity lock** (each buffer draws only its own tick parity): flicker turns perfect (frames of
  the same kind 965 -> 8 on NTSC) but repeats 1073 -> 1215 NTSC, PAL much worse. The user's call
  (asked in the session: not decided).

## Where the time goes now

Field frames with the laser (73% of the auto game, nearly all repeats are there), per frame
(`node tools/_lzprof.js`-style, every tick drawn): 2600 program 3256 (fixed), DrawSprites ~980,
EnemyBuild ~840, DrawScanner 500 + ScanByte 240, layer code 490 + SpCall 171 (moves), WNext 419 +
W457 291 + WScan 145 + FieldHook 207 (walk), BandHook0 403, Collide 357, DrawLayer 294, DrawLaser
280 + LzClose 192 + FillTop 128, LayerEdge 260, Schedule 258, SpanQ 227, IconRowC 160, ClearField
154 + Record 148, ShipImage 152, StarLine 146, EffMc 138. Interrupts ~880 a frame, VIC ~1240.
Everything left is 30-100 cycles a step.

## How to work

* After every change: `build.cmd`, `node tools/lockstep.js 2000` and `--seed=5 --cheat` (0
  differences), `node tools/screencheck.js 2000` / `3000 --seed=3` / `3000 --seed=5 --cheat` /
  `3000 --skip=4` / `3000 --seed=5 --cheat --skip=3` (no new differing frames), `loopsim --ntsc`
  and PAL. VICE `tools/stress.js 300 --seed=N` (several, PAL too) after anything touching the main
  loop or interrupts; `tools/inputtest.js` after input changes; soundcheck after sound changes.
* Lessons: 64tass anonymous labels (+/-) break when an edit adds one in between; helpers clobber
  tmp (and DrawSprites keeps the X MSBs in tmp4: SprCopy's bug); write scripts with the Write tool,
  not Bash heredocs (regex backslashes); `git stash pop` leaves CRLF files (sed 's/\r$//');
  branches go out of range easily in the unrolled code (jmp instead).

Commit only `games/stargate` (and shared tools when needed). Never commit site/ or other
sessions' files. Publish only when the user says so; the next published version is 1.1.
