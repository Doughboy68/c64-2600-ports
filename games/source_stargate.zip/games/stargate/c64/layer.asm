; ------------------------------------------------------------ the star layer
; The stars and mountains (missile 1 and the ball) all move sideways together: missile 1 is at
; M1X83 - 3 * (line - 83), the ball always D = BLX83 - M1X83 further on (+ 3 * (line - 83)).
; So the layer is drawn once into each bitmap at a cell offset c0 = M1X83 / 4 and the VIC's
; fine scroll ($D016, lines 84-222) adds the rest (M1X83 & 3 pixels): it is redrawn only
; when c0 changes. BuildLayer makes the list of its bytes (line, cell, pixels) and, for speed,
; code that writes them ("lda #pixels / sta address,y" for each, Y = 8 * c0 & 255; the
; bytes whose cell + c0 passes 39 wrap 320 back; c0 32-39 add 256): four copies per buffer,
; for those cases, the bytes sorted by cell (the wrapping ones first). On the left the comb
; hides screen pixels 0-7 (bitmap cells 0-1 shifted by the scroll): those bytes are written
; again every frame, masked.
LAYMAX      = 120               ; bytes in the layer (Stargate's: 110)
SPDRAW      = 5 * LAYMAX + 1    ; a copy of the drawing code ("lda #, sta abs,y" each, rts)
SPERASE     = 3 * LAYMAX + 1    ; ... of the clearing code ("sta abs,y" each, rts)
SPCOPY      = SPDRAW + SPERASE
SpBase:     .byte >$5000, >$e000            ; per buffer: its four copies

; BuildLayer: the layer's bytes for this pattern ($9B) and D, and the code that writes them
BuildLayer:
        lda StarPtr
        sta LayFor
        lda LayDNow
        sta LayD
        lda #$ff                ; (both buffers: nothing drawn)
        sta LayC0
        sta LayC0+1
        lda #0
        sta LayN
        sta LayOk
        ; the bytes, line by line (rows in StarRows' order: lines going down)
        ldx #0
_row    cpx StarN
        bne +
        jmp _sort
+       stx v3
        lda LayN                ; this line's first byte
        sta v2
        lda #140                ; k = 140 - Y
        sec
        sbc SRowY,x
        tay
        lda #160                ; missile 1: -3k mod 160
        sec
        sbc Times3Mod,y
        cmp #160
        bcc +
        lda #0
+       jsr _span
        ldx v3
        lda #140
        sec
        sbc SRowY,x
        tay
        lda LayD                ; the ball: D + 3k mod 160
        clc
        adc Times3Mod,y
        bcs +
        cmp #160
        bcc ++
+       sbc #160
+       jsr _span
        ldx v3
        inx
        jmp _row
_span   sta v0                  ; pixels v0 .. v0 + width - 1 (mod 160) of row v3
        ldx v3
        lda SRowW,x
        sta v1
-       lda v0
        cmp #160
        bcc +
        sbc #160
        sta v0
+       lsr
        lsr
        sta tmp                 ; cell
        lda v0
        and #3
        tay
        lda Pix11,y
        sta tmp2
        ldy v2                  ; the same cell already on this line?
-       cpy LayN
        beq _new
        lda LayCellR,y
        cmp tmp
        beq _or
        iny
        bne -
_new    cpy #LAYMAX
        bcs _next               ; (too many: BuildLayer gives up: LayOk stays 0)
        lda tmp
        sta LayCellR,y
        lda tmp2
        sta LayPatR,y
        ldx v3
        lda #223
        sec
        sbc SRowY,x
        sta LayLineR,y
        inc LayN
        jmp _next
_or     lda LayPatR,y
        ora tmp2
        sta LayPatR,y
_next   inc v0
        dec v1
        bne --
        rts
        ; sort by cell, highest first (counting); per cell: first index, count
_sort   lda LayN
        cmp #LAYMAX
        bcc +
        rts                     ; (too many bytes: not used)
+       ldx #39
        lda #0
-       sta CellCnt,x
        dex
        bpl -
        ldy #0
-       cpy LayN
        beq +
        ldx LayCellR,y
        inc CellCnt,x
        iny
        bne -
+       lda #0                  ; first index per cell, cells 39 down to 0
        ldx #39
-       sta CellFirst,x
        clc
        adc CellCnt,x
        dex
        bpl -
        ldx #39                 ; (a running copy)
-       lda CellFirst,x
        sta CellPut,x
        dex
        bpl -
        ldy #0
-       cpy LayN
        beq +
        ldx LayCellR,y
        lda CellPut,x
        inc CellPut,x
        tax
        lda LayCellR,y
        sta LayCell,x
        lda LayPatR,y
        sta LayPat,x
        lda LayLineR,y
        sta LayLine,x
        iny
        bne -
+       ldx LayN                ; each byte's line: its offset in the bitmap
-       dex
        bmi +
        ldy LayLine,x
        lda LineLo,y
        sta LayOfsLo,x
        lda LineHi,y
        sta LayOfsHi,x
        jmp -
+       ; WrapN[c0]: the bytes with cell + c0 >= 40 (cells 40 - c0 and up: the first ones)
        lda #0
        sta WrapN
        ldx #1
-       stx tmp                 ; c0 = X: cells 40 - X .. 39 = the first CellFirst[40 - X] +
        lda #40                 ; CellCnt[40 - X] bytes
        sec
        sbc tmp
        tay
        lda CellFirst,y
        clc
        adc CellCnt,y
        sta WrapN,x
        inx
        cpx #40
        bne -
        ; per line: its bytes (for redrawing a line), as a chain
        ldx #0
        lda #$ff
-       sta LineHead,x
        inx
        cpx #140
        bne -
        ldy LayN
-       dey
        bmi +
        lda LayLine,y
        sec
        sbc #84
        tax
        lda LineHead,x
        sta LineNext,y
        tya
        sta LineHead,x
        jmp -
+       ; the code: per buffer, four copies (base offsets 0, -320 (wrapping), +256 (c0 32-39),
        ; -64 (both))
        lda #0
        sta v3                  ; buffer
_gbuf   lda #0
        sta v2                  ; copy
_gcopy  ldx v3
        lda SpBase,x            ; this copy's drawing code: SpBase + copy * SPCOPY
        sta ptrC+1
        lda #0
        sta ptrC
        ldx v2
        beq +
-       lda ptrC
        clc
        adc #<SPCOPY
        sta ptrC
        lda ptrC+1
        adc #>SPCOPY
        sta ptrC+1
        dex
        bne -
+       lda ptrC                ; ... its clearing code after it
        clc
        adc #<SPDRAW
        sta ptrD
        lda ptrC+1
        adc #>SPDRAW
        sta ptrD+1
        ldx #0
_gent   cpx LayN
        bne +
        jmp _gend
+
        stx v1
        ldy LayLine,x           ; address: the bitmap + line + 8 * cell + the copy's offset
        lda LineLo,y
        sta tmp
        lda LineHi,y
        ldy v3
        clc
        adc BmpHiTab,y
        sta tmp2
        ldy LayCell,x           ; (8 * cell: ColOfs by pixel 4 * cell)
        lda CellPix,y
        tay
        lda tmp
        clc
        adc ColOfsLo,y
        sta tmp
        lda tmp2
        adc ColOfsHi,y
        sta tmp2
        ldy v2
        lda tmp
        clc
        adc CopyOfsLo,y
        sta tmp
        lda tmp2
        adc CopyOfsHi,y
        sta tmp2
        ldy #0                  ; draw: lda #pixels, sta abs,y
        lda #$a9
        sta (ptrC),y
        iny
        lda LayPat,x
        sta (ptrC),y
        iny
        lda #$99
        sta (ptrC),y
        iny
        lda tmp
        sta (ptrC),y
        iny
        lda tmp2
        sta (ptrC),y
        lda ptrC
        clc
        adc #5
        sta ptrC
        bcc +
        inc ptrC+1
+       ldy #0                  ; clear: sta abs,y
        lda #$99
        sta (ptrD),y
        iny
        lda tmp
        sta (ptrD),y
        iny
        lda tmp2
        sta (ptrD),y
        lda ptrD
        clc
        adc #3
        sta ptrD
        bcc +
        inc ptrD+1
+       ldx v1
        inx
        jmp _gent
_gend   lda #$60                ; rts
        ldy #0
        sta (ptrC),y
        sta (ptrD),y
        inc v2
        lda v2
        cmp #4
        beq +
        jmp _gcopy
+       inc v3
        lda v3
        cmp #2
        beq +
        jmp _gbuf
+       lda #1
        sta LayOk
        rts
CopyOfsLo:  .byte <0, <-320, <256, <-64
CopyOfsHi:  .byte >0, >-320, >256, >-64

; SpCall: run the layer code for this buffer with Y = 8 * c0 & 255 (c0 in spC0): drawing
; (A = 0) or clearing (A = 1). The wrapping bytes (the first K = WrapN[c0]) from the wrapping
; copy (an rts put in after them for the call), the others from the plain copy's entry K on.
SpCall: sta spKind
        lda spC0
        asl
        asl
        asl
        sta spY
        ldx spC0
        lda WrapN,x
        sta spK
        sta tmp3                ; K * the entry's size (5 drawing, 3 clearing): tmp3 / tmp4
        lda #0
        sta tmp4
        lda tmp3
        asl
        rol tmp4
        ldy spKind
        bne +
        asl
        rol tmp4
+       clc
        adc tmp3
        sta tmp3
        bcc +
        inc tmp4
+       lda rb                  ; the code: buffer * 8 + copy * 2 + kind (plain copy 0, or 2
        asl                     ; from c0 = 32 on; + 2: its wrapping copy)
        asl
        asl
        ora spKind
        cpx #32
        bcc +
        ora #4
+       tax
        lda spK                 ; the wrapping ones
        beq _plain
        lda SpCodeLo+2,x
        sta _go+1
        clc
        adc tmp3
        sta _at+1
        sta _put+1
        lda SpCodeHi+2,x
        sta _go+2
        adc tmp4
        sta _at+2
        sta _put+2
_at     lda $ffff
        sta spSave
        lda #$60                ; (rts)
        jsr _put
        ldy spY
        lda #0
_go     jsr $ffff
        lda spSave
        jsr _put
_plain  lda spK                 ; the others (the copy ends with an rts)
        cmp LayN
        bcs _none
        lda SpCodeLo,x
        clc
        adc tmp3
        sta _go2+1
        lda SpCodeHi,x
        adc tmp4
        sta _go2+2
        ldy spY
        lda #0
_go2    jmp $ffff
_put    sta $ffff
_none   rts
; per buffer, copy and kind: the layer code's address
SpCodeLo:   .for b = 0, b < 2, b += 1
            .for c = 0, c < 4, c += 1
            .byte <((b == 0 ? $5000 : $e000) + c * SPCOPY), <((b == 0 ? $5000 : $e000) + c * SPCOPY + SPDRAW)
            .next
            .next
SpCodeHi:   .for b = 0, b < 2, b += 1
            .for c = 0, c < 4, c += 1
            .byte >((b == 0 ? $5000 : $e000) + c * SPCOPY), >((b == 0 ? $5000 : $e000) + c * SPCOPY + SPDRAW)
            .next
            .next

; LayerLine: the layer's bytes on line A redrawn at this buffer's c0 (after something cleared
; them), or cleared (LayerZero)
LayerZero:
        ldx #0
        stx spKind
        jmp +
LayerLine:
        ldx #1
        stx spKind
+       sec
        sbc #84
        tax
        lda LineHead,x
        bmi _done
        tax
_ent    lda LayCell,x           ; this buffer's cell: (cell + c0) mod 40
        ldy rb
        clc
        adc LayC0,y
        cmp #40
        bcc +
        sbc #40
+       tay
        lda CellPix,y
        tay
        stx tmp
        lda LayLine,x
        tax
        lda LineLo,x
        clc
        adc ColOfsLo,y
        sta ptrD
        lda LineHi,x
        adc ColOfsHi,y
        adc bmpHi
        sta ptrD+1
        ldx tmp
        lda spKind
        beq +
        lda LayPat,x
+       ldy #0
        sta (ptrD),y
        lda LineNext,x
        bmi _done
        tax
        jmp _ent
_done   rts

; LayerEdge: the layer's bytes at bitmap cells 0-1, where the comb is (screen pixels 0-7 are
; bitmap pixels 0-7 shifted by the fine scroll fScr). Cell 0 is always in it: its colour RAM is
; black in cell rows 5-22 (FieldColour), so only its bytes on lines 221-222 are cleared (cell
; row 23 is line 223's too); cell 1 keeps its pixels at screen 8 and on.
LayerEdge:
        ldy rb
        lda #40                 ; the layer's cell at bitmap cell 0: 40 - c0 (mod 40)
        sec
        sbc LayC0,y
        cmp #40
        bcc +
        lda #0
+       sta tmp4
        tax
        lda CellCnt,x
        beq _cell1
        sta tmp2
        lda CellFirst,x
        tax
-       lda LayLine,x
        cmp #221
        bcc +
        lda LayOfsLo,x          ; (bitmap cell 0: the line's offset)
        sta ptrD
        lda LayOfsHi,x
        clc
        adc bmpHi
        sta ptrD+1
        lda #0
        tay
        sta (ptrD),y
+       inx
        dec tmp2
        bne -
_cell1  ldx tmp4                ; bitmap cell 1
        inx
        cpx #40
        bcc +
        ldx #0
+       lda CellCnt,x
        beq _out
        sta tmp2
        ldy fScr
        lda EdgeMask,y
        sta tmp3
        lda CellFirst,x
        tax
        lda #8                  ; (+8: cell 1; a line's offset is cell row * 320 + 0-7)
        sta ptrD
-       ldy LayOfsLo,x
        lda LayOfsHi,x
        clc
        adc bmpHi
        sta ptrD+1
        lda LayPat,x
        and tmp3
        sta (ptrD),y
        inx
        dec tmp2
        bne -
_out    rts
EdgeMask:   .byte $00, $03, $0f, $3f    ; screen cell 1 = bitmap pixels 4-7 + fine scroll: from 8

; DrawLayer: the field's stars and mountains from the layer (see BuildLayer): this buffer's
; lines that something else drew over last time redrawn, the layer moved if c0 changed, the
; comb's cells masked for this fine scroll, then what the layer can't show: R1 lines (they keep
; the line before's enable), line 223 (line 222 again, no comb, no fine scroll).
DrawLayer:
        ldx rb                  ; (the layer writes the comb's cells: BgStars fills them again)
        lda #0
        sta CombFill,x
        lda M1X83               ; the fine scroll and the cell offset
        and #3
        sta fScr
        lda M1X83
        lsr
        lsr
        sta c0New
        ldx rb                  ; the lines drawn over: the layer's bytes back
        lda LayC0,x
        cmp #$ff
        beq _nodirty
        lda DirtyN,x
        beq _nodirty
        sta v3
        txa
        asl
        asl
        asl
        sta v2                  ; (8 per buffer)
-       ldx v2
        lda Dirty,x
        jsr LayerLine
        inc v2
        dec v3
        bne -
_nodirty
        ldx rb
        lda #0
        sta DirtyN,x
        lda LayC0,x             ; moved?
        cmp c0New
        beq _same
        cmp #$ff
        beq _draw
        sta spC0                ; cleared where it was,
        lda #1
        jsr SpCall
_draw   lda c0New               ; drawn where it is
        sta spC0
        ldx rb
        sta LayC0,x
        lda #0
        jsr SpCall
_same   jsr LayerEdge
        ; R1 lines: hidden if the line before has no star / mountain, added if only it has
        ldx nD
_r1     dex
        bpl +
        jmp _223
+       stx v3
        ldy DR1,x
        lda (StarPtr),y
        and #2
        sta tmp
        iny
        lda (StarPtr),y
        and #2
        cmp tmp
        beq _r1n                ; (the same: as the layer has it)
        lda tmp
        beq _add
        ldx v3                  ; on, but the line before off: hidden
        lda #223
        sec
        sbc DR1,x
        jsr LayerZero
        ldx v3
        lda #223
        sec
        sbc DR1,x
        jsr MarkDirty
        jmp _r1n
_add    ldx v3                  ; off, but the line before on: drawn (the slow way)
        lda DR1,x
        sta cy
        jsr StarLine
_r1n    ldx v3
        jmp _r1
_223    ldy #1                  ; line 223: as line 222 (Y = 1)
        lda (StarPtr),y
        and #2
        beq +
        ldx nD                  ; (line 222 an R1 line: left to the slow way's rules)
-       dex
        bmi ++
        lda DR1,x
        cmp #1
        bne -
+       rts
+       lda #0
        sta cy
        jmp StarLine

; NewLayer: the layer changes (its pattern or D): what each buffer shows of the old one is
; cleared first: this buffer's now (its code still matches it), the other's bytes listed
; (StaleLo / StaleHi: its bitmap is on the screen now) to clear when it's drawn next
; (ClearStale); then BuildLayer
NewLayer:
        jsr ClearLayer
        lda rb
        eor #1
        tax
        lda LayC0,x
        cmp #$ff
        beq _build
        sta tmp4                ; (its cell offset)
        stx StaleBuf
        lda BmpHiTab,x
        sta tmp3
        ldx #0
-       cpx LayN
        beq _done
        lda LayCell,x           ; each byte: its line's offset + 8 * ((cell + c0) mod 40)
        clc
        adc tmp4
        cmp #40
        bcc +
        sbc #40
+       tay
        lda CellPix,y
        tay
        lda LayOfsLo,x
        clc
        adc ColOfsLo,y
        sta StaleLo,x
        lda LayOfsHi,x
        adc ColOfsHi,y
        adc tmp3
        sta StaleHi,x
        inx
        bne -
_done   stx StaleN
        ldx StaleBuf
        lda #$ff
        sta LayC0,x
        lda #0
        sta DirtyN,x
_build  jmp BuildLayer

; ClearStale: an old layer's bytes listed for this buffer (NewLayer), cleared
ClearStale:
        ldx StaleN
        beq _out
        lda StaleBuf
        cmp rb
        bne _out
        lda #0
        sta StaleN
        tay
-       dex
        bmi _out
        lda StaleLo,x
        sta ptrD
        lda StaleHi,x
        sta ptrD+1
        tya
        sta (ptrD),y
        jmp -
_out    rts

; ClearLayer: the layer cleared from this buffer (no field drawn), lines drawn over forgotten
ClearLayer:
        ldx rb
        lda #0
        sta DirtyN,x
        lda LayC0,x
        cmp #$ff
        beq +
        sta spC0
        lda #$ff
        sta LayC0,x
        lda LayOk
        beq +
        lda #1
        jmp SpCall
+       rts

; MarkDirty: line A of this buffer gets the layer's bytes back next time (something drew over
; them, or they were hidden)
MarkDirty:
        pha
        ldx rb
        lda DirtyN,x
        cmp #8
        bcs _full
        inc DirtyN,x
        sta mdT                 ; (not tmp: the shot's loop counts in it, ShotBmp)
        txa
        asl
        asl
        asl
        clc
        adc mdT
        tax
        pla
        sta Dirty,x
        rts
_full   pla                     ; (more than 8: the whole layer drawn again next time)
        ldx rb
        lda #$ff
        sta LayC0,x
        rts

