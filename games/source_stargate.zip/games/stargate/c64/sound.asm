; =================================================================== sound
; The game's TIA sound registers, translated to SID voices 1 and 2 once a frame.
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        bne _on
        jmp _off
_on     cmp #3                  ; very quiet (1-2) from silence: left silent (starting the SID's
        bcs +                   ; envelope goes to the top first: whispers became clicks)
        lda SndOn,x
        beq _off
+       ldy v1
        lda SidWave,y
        beq _off2
        sta tmp                 ; waveform
        lda v1                  ; frequency index = AUDC * 32 + AUDF
        lsr
        lsr
        lsr
        sta ptrA+1
        lda v1
        asl
        asl
        asl
        asl
        asl
        ora v2
        clc
        adc FreqTab
        sta ptrA
        lda ptrA+1
        adc FreqTab+1
        sta ptrA+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d400,y
        inc ptrA+1
        inc ptrA+1
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d401,y
        ldy v1                  ; the pulse width (the TIA waveform's duty)
        lda SidPWHi,y
        pha
        lda SidPWLo,y
        ldy tmp2
        sta $d402,y
        pla
        sta $d403,y
        lda v0                  ; volume becomes the sustain level
        asl
        asl
        asl
        asl
        sta $d406,y
        lda SndLast,x           ; the envelope restarted (gate off, on: it goes to the top, then
        cmp v0                  ; down to the sustain level) only when the volume rises: a lower
        bcs +                   ; sustain level it follows by itself (restarting on every step
        lda tmp                 ; made a fade sputter). (Gate off before: on starts it anyway.)
        sta $d404,y
+       lda tmp
        ora #1
        sta $d404,y
        lda #1
        sta SndOn,x
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
        sta SndOn,x
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts
