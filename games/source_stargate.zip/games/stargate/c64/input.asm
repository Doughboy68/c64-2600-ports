; ================================================================== input
; Joystick in port 2 (or W A S D + Space): the 2600's left joystick, the ship and its laser.
; Joystick in port 1 (or I up, K down, Return fire): the right one: up inviso, down
; hyperspace, fire smartbomb. Console: F1 Game Reset, F2 (F1 with shift) power off and on,
; F3 Game Select, F5 colour/B&W, F7 / F8 left / right difficulty, F flicker on/off. Fire
; starts a game when none is running.
ReadInput:
        lda #$ff
        sta $dc02               ; port A output, port B input
        lda #0
        sta $dc03
        lda #$ff
        sta $dc00
        lda $dc00
        sta joyb                ; port 2
        lda $dc01
        sta joyb+1              ; port 1
        eor #$1f                ; (lines a port 1 joystick pulls low: ignored in the keyboard)
        and #$1f
        sta tmp
        lda #0                  ; any key at all? (every row at once)
        sta $dc00
        lda $dc01
        ldx #$ff
        stx $dc00
        ora tmp
        cmp #$ff
        bne _keys
        jmp NoKeys
_keys
        .for r in [0, 1, 2, 4, 6, 7]    ; the keyboard rows with our keys
        lda #($ff ^ (1 << r))
        sta $dc00
        lda $dc01
        ora tmp
        sta Keys+r
        .next
        lda #$ff
        sta $dc00

        ; SWCHA: the left joystick (high nibble: right, left, down, up; 0 = pressed) from port 2
        ; and W S A D, the right one (low nibble) from port 1 and I K
        lda joyb
        asl
        asl
        asl
        asl
        sta tmp
        lda joyb+1
        and #$0f
        ora tmp
        sta tmp
        .for k in [[1, $02, $ef], [1, $20, $df], [1, $04, $bf], [2, $04, $7f], [4, $02, $fe], [4, $20, $fd]]
        lda Keys+k[0]           ; (W up, S down, A left, D right; I up, K down)
        and #k[1]
        bne +
        lda tmp
        and #k[2]
        sta tmp
+
        .next
        lda tmp
        and DbgSWCHA            ; debug overrides, poked from the VICE monitor by tools
        sta SWCHA
        lda joyb                ; INPT4: the left fire button (port 2 or Space)
        and #$10
        beq +
        lda Keys+7
        and #$10
        beq +
        lda #$80
+       and DbgINPT4
        sta INPT4
        lda joyb+1              ; INPT5: the right one (port 1 or Return)
        and #$10
        beq +
        lda Keys+0
        and #$02
        beq +
        lda #$80
+       and DbgINPT5
        sta INPT5

        ; F: flicker on / off (on key-down)
        lda Keys+2
        and #$20
        bne +
        lda PrevKeyF
        and #$20
        beq +
        lda Flicker
        eor #1
        sta Flicker
+       lda Keys+2
        sta PrevKeyF

        ; console switches
        lda Keys+0              ; F5: colour / B&W (on key-down)
        and #$40
        bne +
        lda PrevKeys
        and #$40
        beq +
        lda switches
        eor #$08
        sta switches
+       lda Keys+0              ; F7 / F8: difficulty
        and #$08
        bne +
        lda PrevKeys
        and #$08
        beq +
        lda Keys+1              ; with either shift key (F8): right difficulty
        bpl _right
        lda Keys+6
        and #$10
        beq _right
        lda #$40                ; F7: left difficulty
        bne _tog
_right  lda #$80
_tog    eor switches
        sta switches
+       lda Keys+0
        sta PrevKeys
        jsr PowerKey
        lda switches            ; reset (F1) and select (F3) are held buttons
        and #$fc
        sta tmp
        lda f2now               ; F1 is Game Reset (F2, on the same key, is the power switch)
        bne _rup
        lda Keys+0
        and #$10
        beq _f3
        lda ShipsLeft           ; fire, with no game running: Game Reset
        bne _rup
        lda INPT4
        bpl _f3
_rup    inc tmp                 ; bit 0 up
_f3     lda Keys+0
        and #$20
        beq +
        lda tmp
        ora #2
        sta tmp
+       lda tmp
        and DbgSWCHB
        sta SWCHB
        rts

; ReadInput without a key pressed: the same, quicker (the joysticks only)
NoKeys: lda joyb                ; SWCHA
        asl
        asl
        asl
        asl
        sta tmp
        lda joyb+1
        and #$0f
        ora tmp
        and DbgSWCHA
        sta SWCHA
        lda joyb                ; INPT4, INPT5
        and #$10
        beq +
        lda #$80
+       and DbgINPT4
        sta INPT4
        lda joyb+1
        and #$10
        beq +
        lda #$80
+       and DbgINPT5
        sta INPT5
        stx PrevKeyF            ; (X = $ff: every key up)
        stx PrevKeys
        lda #0
        sta f2now
        sta PrevF2
        lda switches            ; reset and select up; fire with no game running: Game Reset
        and #$fc
        ora #2
        sta tmp
        lda ShipsLeft
        bne _rup
        lda INPT4
        bpl +
_rup    inc tmp
+       lda tmp
        and DbgSWCHB
        sta SWCHB
        rts

; F2 (F1 with either shift key): ask for a power cycle on key-down. f2now = F2 held.
PowerKey:
        lda #0
        sta f2now
        lda Keys+0
        and #$10
        bne _up                 ; F1 key up
        lda Keys+1              ; left shift
        bpl _down
        lda Keys+6              ; right shift
        and #$10
        bne _up
_down   inc f2now
        lda PrevF2
        bne _up
        lda #1
        sta PowerReq
_up     lda f2now
        sta PrevF2
        rts

