; ================================================================== tables
; Built at start-up (InitTables), a page each
LineLo      = $C000     ; 2600 line (37-236) -> its offset in the bitmap: cell row * 320 + line
LineHi      = $C100     ; in the cell (without the bitmap's base)
PosP        = $C200     ; X code -> pixel where the positioning (lines 78-83) puts a player,
PosM        = $C300     ; ... a missile or the ball (from the game's table at $FBD0)
Reverse     = $C400     ; a byte's bits reversed (REFPx)
Times3Mod   = $C500     ; n -> 3n mod 160 (n = 0-141: missile 1 and the ball move 3 a line)
ErLo0       = $C800     ; per buffer: the bitmap bytes the field wrote (to clear): low bytes,
ErHi0       = $C900     ; ... high bytes
ErLo1       = $CA00
ErHi1       = $CB00
ERMAX       = 255
ColOfsLo    = $CC00     ; pixel (0-159) -> its cell's offset in a bitmap line (cell * 8)
ColOfsHi    = $CD00
W4A         = $CE00     ; pixel -> a 4-pixel span's "11" bits in its first cell,
W4B         = $CE00 + 160   ; ... in the next (0: none)
R1Flag      = $CF40     ; Y -> 1 on an R1 line (the walk's, until the next walk; Y 0-$8C)
BandIdx     = $0400     ; a band's caller (return address low byte) -> BandCall index ($ff: none)
Hi11        = $0500     ; a byte's bits 7-4 as four "11" pixels,
Lo11        = $0600     ; ... its bits 3-0
MaskY       = $0700     ; EnemyBuild: each row's pixels' mask, by its Y
SlotClk     = $C600     ; a slot's position byte ($B0,x) -> the clock its reset puts it at + 5
FineOf      = $C700     ; its fine motion byte ($B6,x) -> 2 * the fine motion (signed)

InitTables:
        ; bitmap lines: cell row * 320 + line in the cell
        ldx #0
        txa
-       sta LineLo,x
        sta LineHi,x
        inx
        bne -
        sta tmp                 ; offset of the cell row
        sta tmp2
        ldx #FIRSTLINE
_ln     txa
        sec
        sbc #FIRSTLINE
        and #7
        sta tmp3
        clc
        adc tmp
        sta LineLo,x
        lda tmp2
        adc #0
        sta LineHi,x
        lda tmp3
        cmp #7
        bne +
        lda tmp                 ; the next cell row: +320
        clc
        adc #<320
        sta tmp
        lda tmp2
        adc #>320
        sta tmp2
+       inx
        cpx #FIRSTLINE + 200
        bne _ln
        ; reversed bytes
        ldx #0
-       txa
        ldy #8
_rv     lsr
        rol tmp
        dey
        bne _rv
        lda tmp
        sta Reverse,x
        inx
        bne -
        ; pixel -> cell * 8
        ldx #0
-       txa
        lsr
        lsr
        sta tmp
        lda #0
        asl tmp
        asl tmp
        rol
        asl tmp
        rol
        sta ColOfsHi,x
        lda tmp
        sta ColOfsLo,x
        inx
        cpx #160
        bne -
        ; 4-pixel spans: the first cell's bits, the next's
        ldx #0
-       txa
        and #3
        tay
        lda FromPix,y
        sta W4A,x
        lda #0
        dey
        bmi +
        lda ToPix,y
+       sta W4B,x
        inx
        cpx #160
        bne -
        lda #0                  ; no R1 marks ($CF40-$CFFF)
        tax
-       sta R1Flag,x
        inx
        cpx #$c0
        bne -
        ; 3n mod 160
        ldx #0
        lda #0
-       sta Times3Mod,x
        clc
        adc #3
        cmp #160
        bcc +
        sbc #160
+       inx
        cpx #142
        bne -
        lda #$ff                ; the bands' callers
        ldx #0
-       sta BandIdx,x
        inx
        bne -
        ldy #BandCallN - 1
-       ldx BandCallLo,y
        tya
        sta BandIdx,x
        dey
        bpl -
        ldx #0                  ; the slots' positions: a reset at clock 7 + 15 * (bits 1-2),
-       txa                     ; +3 with bit 7, 78 later with bit 0; a player 5 on
        and #6
        tay
        lda Times15,y
        clc
        adc #7 + 5
        cpx #$80
        bcc +
        adc #3 - 1              ; (carry set)
+       sta tmp
        txa
        lsr
        lda tmp
        bcc +
        adc #78 - 1             ; (carry set)
+       sta SlotClk,x
        txa                     ; ... the fine motion (high nibble)
        lsr
        lsr
        lsr
        lsr
        tay
        lda Fine2,y
        sta FineOf,x
        inx
        bne -
        ldx #0                  ; a byte's nibbles as "11" pixels
-       txa
        lsr
        lsr
        lsr
        lsr
        tay
        lda Nib11,y
        sta Hi11,x
        txa
        and #15
        tay
        lda Nib11,y
        sta Lo11,x
        inx
        bne -
        rts

BitTab:     .byte $01, $02, $04, $08, $10, $20, $40, $80
Pix01:      .byte $40, $10, $04, $01
Pix11:      .byte $c0, $30, $0c, $03
NotPix:     .byte $3f, $cf, $f3, $fc
Fine1:      .char 0, 1, 2, 3, 4, 5, 6, 7, -8, -7, -6, -5, -4, -3, -2, -1
SidVoice:   .byte 0, 7
BmpHiTab:   .byte >(VIC0 + $2000), >(VIC1 + $2000)  ; per buffer: bitmap,
ScrHiTab:   .byte >VIC0, >VIC1                      ; screen,
SprHiTab:   .byte >(VIC0 + $0400), >(VIC1 + $0400)  ; sprite blocks,
BankBits:   .byte 2, 1                              ; $DD00 (VIC bank 1, 2)
SprStage:   .byte 0, 8                              ; staged sprite values
SchBase:    .byte 0, SCHMAX                         ; schedule entries
BandBase:   .byte 0, BANDMAX                        ; band entries
ScanBase:   .byte 0, ScanRec                        ; scanner records
BandTimes12: .for i = 0, i < BANDMAX, i += 1
            .byte 12 * i
            .next
Row40Lo:    .for r = 0, r < 25, r += 1
            .byte <(40 * r)
            .next
Row40Hi:    .for r = 0, r < 25, r += 1
            .byte >(40 * r)
            .next

        .include "tables.inc"

; ------------------------------------------------------- variables (RAM)
DbgSWCHA:   .byte $ff           ; AND masks applied to the inputs (testing aid)
DbgINPT4:   .byte $ff
DbgINPT5:   .byte $ff
DbgSWCHB:   .byte $ff
DbgBorder:  .byte 0             ; non-zero: colour the border while drawing / running the game
DbgLoops:   .word 0             ; frames drawn
DbgLate:    .word 0             ; frame ends that came with the last one's tick still due
DbgRMax:    .word 0             ; the most cycles drawing a frame took,
DbgTMax:    .word 0             ; ... a tick,
DbgPMax:    .word 0             ; ... a wait
DbgShown:   .word 0, 0          ; frames shown from even / odd ticks (FrameCount bit 0: the
DbgSame:    .word 0             ; flicker's turns), ... of the same kind as the one before
DbgFrames:  .word 0             ; frame ends,
DbgRepeat:  .word 0             ; ... that showed nothing new (the frame shown again)
DbgLost:    .word 0             ; ticks left out (more than 6 due: the game slows)
DbgWait:    .byte 0, 0, 0, 0    ; cycles (CIA 2 timer) waiting for the frame end in all,
DbgWork:    .byte 0, 0, 0, 0    ; ... working
DbgAutoN    = DbgWork + 4 - DbgLoops
DbgAuto:    .byte 0             ; testing aid: 1 plays a game by itself from F2 on (AutoInput)
DbgAutoRes: .fill DbgAutoN      ; ... DbgLoops to DbgSame over its ticks AUTOFROM-AUTOTO
autoT:      .word 0             ; ... ticks since F2
autoW:      .word 0             ; ... since the last wave ended
autoRnd:    .byte 1
autoDir:    .byte $f
autoFire:   .byte 0
autoRight:  .byte $f
BufPar:     .fill 2             ; per buffer: FrameCount bit 0 of the tick it shows
lastPar:    .byte 0             ; ... of the frame shown last
DbgBadBand: .byte 0             ; bands from an unknown caller (shouldn't happen)
dbgT1:      .word 0
dbgNow:     .word 0
dbgTmp:     .word 0
dbgW:       .word 0
dbgY:       .byte 0
dbgWaiting: .byte 0
DbgOn:      .byte 0             ; testing aid: time the passes (DbgRMax ... DbgWork)
FreqTab:    .word SidFreq       ; the SID's frequency tables
Flicker:    .byte 1             ; 1: the 2600's turns (key F)
PrevKeyF:   .byte $ff
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
SndLast:    .fill 6, $ff
SndOn:      .fill 2             ; per voice: gate on (sounding)
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0
tickS:      .byte 0             ; our stack pointer during a tick

; the tick's capture
CapN:       .byte 0             ; a tick has run (there is something to draw)
CapKind:    .byte 0             ; KFIELD ... KWAVE
DigitC:     .byte 0             ; the carry DigitPtrs left (bit 0)
DigScore:   .byte $ff, $ff, $ff ; DigitPtrs: the score it made pointers for, their low bytes, X,
DigLo:      .fill 6             ; the flags N, Z, C
DigX:       .byte 0
DigNZC:     .byte 0
BANDMAX     = 12
BandN:      .byte 0             ; bands recorded this tick
BandNLast:  .byte 0             ; ... the last tick
HidN:       .byte 0             ; objects the game hid this tick (the flicker; HideObj)
HidObj:     .fill 2
hidY:       .byte 0
XN:         .byte 0             ; flicker off: their slots (XtraSlots)
XPos:       .fill 2
XFine:      .fill 2
XTop:       .fill 2
XGfx:       .fill 2
XCol:       .fill 2
xT:         .byte 0
xT2:        .byte 0
nDX:        .byte 0             ; drawn slots and the hidden objects (Render)
BandGen:    .byte 0             ; bumped when any band changes (its line, rows, graphics, colour)
bandColour: .byte 0
BandWho:    .fill BANDMAX, $ff  ; per band: its caller (BandCall index)
BandLine:   .fill BANDMAX
BandRows:   .fill BANDMAX       ; rows - 1
BandCol:    .fill BANDMAX
BandPtrs:   .fill 12 * BANDMAX
BandVer:    .fill BANDMAX       ; ... a count bumped when its line, rows or graphics change
BandK0:     .fill BANDMAX       ; ... what its graphics came from (the score; IconRow's A, Y)
BandK1:     .fill BANDMAX
BandK2:     .fill BANDMAX
IconA:      .byte 0             ; IconRowC's A and Y
IconY:      .byte 0
; FieldHook
ShipX:      .byte 0             ; pixels
M0X:        .byte 0
M1X83:      .byte 0             ; missile 1 and the ball on line 83
BLX83:      .byte 0
ShipRef:    .byte 0             ; REFP1 (bit 3)
ShipTop:    .byte 0             ; the ship's first row (Y = $97 - 1)
nD:         .byte 0             ; slots drawn
DSMAX       = 8
DSlot:      .fill DSMAX         ; ... each: its slot (X), R1's Y, first and last row shown,
DR1:        .fill DSMAX
DTop:       .fill DSMAX
DBot:       .fill DSMAX
DQuirk:     .fill DSMAX         ; ... L2's Y if an enemy row is there,
DRef:       .fill DSMAX         ; ... REFP0, pixel, pointers
DX:         .fill DSMAX
DPg:        .fill DSMAX
DCLo:       .fill DSMAX
DGLo:       .fill DSMAX
lzOn:       .byte 0             ; the laser line (L1) was drawn: its Y; an enemy row on L2
lzY:        .byte 0
lzAct:      .byte 0
xreg:       .byte 0             ; the kernel's X
m0Seen:     .byte 0             ; the shot's ENAM0 write on (Y = $9A): its clock; off: pixel
m0On:       .byte 0
m0Off:      .byte 0
m0Col:      .fill 3             ; colours of the lines Y = $9A - 2, - 1, $9A
; collisions
hitAny:     .byte 0
cxM0P:      .byte 0
cxP0F:      .byte 0
m1Y:        .byte 0
oLR:        .byte 0
oX:         .byte 0
eLR:        .byte 0
eX:         .byte 0
xLo:        .byte 0
xHi:        .byte 0
qOld:       .byte 0
m0N:        .byte 0             ; the shot's lines: Y, first and last + 1 pixel it shows on
m0Y:        .fill 3
m0X0:       .fill 3
m0X1:       .fill 3
; render
ScBallX:    .byte 0
BufGen:     .byte $ff, $ff      ; per buffer: BandGen when its bands were drawn
BufBandN:   .fill 2             ; per buffer: its bands (BANDMAX each): first line, rows - 1,
BANDBUF     = 2 * BANDMAX       ; colour, graphics drawn, their pointers
ScanRec     = 7 * 8 + 1         ; per buffer: the scanner's rows as drawn (6 bytes, marker, a spare), marker x
ScanOk:     .fill 2
ScDirty:    .byte 0             ; the scanner rows the game wrote this tick (bit y: row y),
ScDirtyB:   .fill 2             ; ... since each buffer's were drawn
ScanF8:     .byte $ff, $ff      ; per buffer: the marker's pointer ($F8) when drawn
scMask:     .byte 0             ; DrawScanner: the rows to look at
sClip:      .byte 0             ; the ship's image key being checked: clip, edge, rows' address
sEdge:      .byte 0
sAddr:      .word 0
kSlot:      .byte 0             ; an enemy's: 8 * buffer + sprite, clip
eClipK:     .byte 0
eBlack:     .byte 0             ; building an image (more in zero page): any black rows, the
irqEn:      .byte 0             ; the frame top: the sprites shown (shifted out)
kStage:     .byte 0             ; DrawSprites: this buffer's first staged slot
eBlkX:      .byte 0             ; block's offset
KeyOfs5:    .byte 0, 5
BPtr:       .fill 12
BRow:       .fill 12
BLine:      .fill 7
SCells:     .fill 12            ; a scanner row's cells 14-25
scK:        .byte 0             ; ScanByte: the column, its first cell's offset
scOfs:      .byte 0
FieldCol:   .byte $ff           ; the colour RAM's field colour now
FieldNow:   .byte 0             ; this frame's (C64 colour)
BgNow:      .byte 0             ; the field's background this frame (C64 colour)
CombFill:   .fill 2             ; per buffer: the comb's cells filled "01" (BgStars)
CombOk:     .byte 1, 1          ; ... lines 82-83's comb cells "01" (else all clear: CombIdle)
SprEc0:     .fill 16            ; per buffer and sprite: the colours its image was built with
SprEc1:     .fill 16
SprEc2:     .fill 16
StarFor:    .byte $ff           ; StarY is for this $9B
spanEnd:    .byte 0
spFs:       .byte 0             ; StarLine: its line's shift (the fine scroll)
LayFor:     .byte $ff           ; the layer is for this $9B,
LayD:       .byte $ff           ; ... this D (BLX83 - M1X83 mod 160)
LayDNow:    .byte 0
LayOk:      .byte 0             ; ... and usable (not too many bytes)
LayN:       .byte 0             ; its bytes
LayC0:      .byte $ff, $ff      ; per buffer: the cell offset it's drawn at ($ff: not drawn)
mdT:        .byte 0             ; MarkDirty's
StaleN:     .byte 0             ; an old layer's bytes to clear (NewLayer): how many, in which buffer
StaleBuf:   .byte 0
DirtyN:     .fill 2             ; per buffer: lines drawn over (the layer's bytes back next time)
Dirty:      .fill 16
c0New:      .byte 0
fScr:       .byte 0             ; the fine scroll (pixels) on lines 84-222
spC0:       .byte 0             ; SpCall's working variables
spKind:     .byte 0
spY:        .byte 0
spK:        .byte 0
spSave:     .byte 0
lzRun:      .byte 0             ; DrawLaser: the run's first cell, its pixels, the cell at hand
lzX0:       .byte 0
lzX1:       .byte 0
lzCell:     .byte 0
LZMAX       = 4
LzSpN:      .fill 2             ; per buffer: the laser's runs drawn (LZMAX each): first byte,
LzSpLo:     .fill 2 * LZMAX     ; bytes
LzSpHi:     .fill 2 * LZMAX
LzSpB:      .fill 2 * LZMAX
qPix2:      .byte 0
qRow:       .byte 0             ; the L2 quirk's row: right part, left part
qRow2:      .byte 0
qPix:       .byte 0
lastC:      .byte 0             ; the shot's last row's code
EnMcA:      .fill 6             ; the drawn enemies' shared colours ($D025, $D026)
EnMcB:      .fill 6
EffA:       .fill 6             ; ... in effect from each one's R1 on
EffB:       .fill 6
mcN:        .byte 0             ; (McAt: enemies drawn as sprites, the line asked about)
mcY:        .byte 0
StarN:      .byte 0             ; the rows with stars or mountains (Y)
ErN:        .fill 2             ; per buffer: bytes on the field's list
SprLen:     .fill 16, 63        ; per buffer and sprite: the bytes its block holds
; staged per buffer for the frame top
StX:        .fill 16
StY:        .fill 16
StCol:      .fill 16
StMsb:      .fill 2
StEn:       .fill 2
StBg:       .fill 2
StMc1:      .fill 2
StMc2:      .fill 2
; the schedule (per buffer SCHMAX entries): raster, type, arguments
SCHMAX      = 24

; ---- larger arrays in RAM the VIC doesn't show ($9000-$9FFF: in VIC bank 2 it sees the
; character ROM there), cleared by InitVars
        .virtual $9000
BufBandL:   .fill BANDBUF
BufBandR:   .fill BANDBUF
BufBandC:   .fill BANDBUF
BufBandG:   .fill BANDBUF
BufBandV:   .fill BANDBUF
ShipKey:    .fill 10            ; per buffer: the key the ship's image was built from (5 bytes)
EKClip:     .fill 16            ; per buffer and sprite: the key an enemy's image was built from
EKG:        .fill 16
EKTop:      .fill 16
EKC:        .fill 16
EKPg:       .fill 16
EKBot:      .fill 16
EKRef:      .fill 16
EKQ:        .fill 16
ScanBuf:    .fill 2 * ScanRec
SRowY:      .fill 140           ; per row: Y, bitmap line offset, 3k mod 160, width
SRowLo:     .fill 140
SRowHi:     .fill 140
SRowK3:     .fill 140
SRowW:      .fill 140
SchRas:     .fill 2 * SCHMAX
SchType:    .fill 2 * SCHMAX       ; ($ff: InitVars)
SchA:       .fill 2 * SCHMAX
SchB:       .fill 2 * SCHMAX
SchC:       .fill 2 * SCHMAX
SchD:       .fill 2 * SCHMAX
SchE:       .fill 2 * SCHMAX
LayCellR:   .fill LAYMAX        ; the layer's bytes as made (cell, pixels, line),
LayPatR:    .fill LAYMAX
LayLineR:   .fill LAYMAX
LayCell:    .fill LAYMAX        ; ... sorted by cell, highest first
LayPat:     .fill LAYMAX
LayLine:    .fill LAYMAX
LineNext:   .fill LAYMAX        ; ... the next of the same line
LayOfsLo:   .fill LAYMAX        ; ... its line's offset in the bitmap
LayOfsHi:   .fill LAYMAX
StaleLo:    .fill LAYMAX        ; ... their addresses (ClearStale)
StaleHi:    .fill LAYMAX
CellCnt:    .fill 40            ; per cell: bytes, the first's index
CellFirst:  .fill 40
CellPut:    .fill 40
WrapN:      .fill 40            ; per c0: the bytes whose cell + c0 >= 40
LineHead:   .fill 140           ; per line (84-223): its first byte ($ff: none)
        .cerror * > $a000, "the variables at $9000 run past $9FFF"
        .endv

; InitVars: the arrays at $9000 cleared, the schedules empty
InitVars:
        lda #0
        tax
-       .for p = $9000, p < $a000, p += $100
        sta p,x
        .next
        inx
        bne -
        lda #$ff
        ldx #2 * SCHMAX - 1
-       sta SchType,x
        dex
        bpl -
        rts

; ======================================================= the 2600 program
; The original 8K ROM, copied at start-up (bank 0 to $D000, bank 1 to $F000) and patched
; (c64/patches.inc)
        .cerror * > $4000, "code and initialised data run past $3FFF (InitVideo clears $4000-$45FF)"
ROM = "../build/original.a26"     ; extracted from roms_port by build.cmd
GameImage:
        .binary ROM
        .cerror * - GameImage != $2000, "the 2600 image must be 8K"
Patches:
        .include "patches.inc"
