; Stargate (Atari 2600, 1984) running on the Commodore 64.
;
; The original 8K program (two 4K banks, F8 bank switching, plus Atari's SuperChip: 128 bytes
; of RAM on the cartridge) runs almost unchanged: bank 0 is copied to the RAM at $D000 (under
; the I/O area) and bank 1 to $F000 (under the KERNAL), where they were written to run, so a
; bank switch is just a jump. The SuperChip's RAM is the C64 RAM at $F080-$F0FF (the game
; reads it there; its writes, to $F000-$F07F on the cartridge, are patched to meet them).
; The game's ticks run with all RAM visible ($01 = $34); our interrupts switch the I/O in
; while they run. Patches: c64/patches.inc (made by tools/mkpatches.js). This file supplies
; everything the 2600 hardware used to do:
;
;   - display: a multicolour bitmap laid out line for line like the 2600 picture (one 2600
;     pixel = one multicolour pixel = two C64 pixels, one 2600 line = one C64 line): the
;     score bands, the scanner, the stars and mountains and the laser are drawn into it; the
;     ship, the enemies (one multicolour sprite each, reused down the screen) and the enemy
;     shot are sprites. The rules come from tools/model.js, which matches the 2600 pixel for
;     pixel.
;   - collisions: the 2600's kernel read the TIA's collision registers while drawing; the C64
;     works out the same overlaps (capture.asm)
;   - input: keyboard and joysticks mapped onto the 2600's two joysticks and switches
;   - sound: the game's TIA sound registers translated to the SID
;
; The game's TIA writes land harmlessly in zero page $02-$2C (VSYNC / VBLANK are patched to
; $03); it reads the TIA at the mirrors $30-$3D, where we put the collisions and the fire
; buttons. Its RIOT accesses ($0280-$0297) hit plain C64 RAM, which we fill in each frame.
;
; Build: build.cmd (64tass -C -a -o build/stargate-<version>.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM
Random      = $80
FrameCount  = $81
ShipsLeft   = $82       ; 0: no game (title)
Smartbombs  = $83
Inviso      = $84
PosCode     = $85       ; 4 X codes (table $FBD0): ship (P1), shot (M0), stars M1, stars ball
Wave        = $89
Score       = $8B       ; 3 bytes BCD
FieldBg     = $8F
ShipGfx     = $94       ; ship graphics pointer; $96 replaces the low byte from row $97
ShipLo2     = $96
ShipRow     = $97
ShipY       = $99
ShotRow     = $9A
StarPtr     = $9B       ; stars and mountains: enable and size per row
EnGfx       = $9D       ; kernel: the enemy's graphics pointer
EnCol       = $9F       ; kernel: ... colour pointer
EnTop       = $A1       ; kernel: the enemy's top row
Slots       = $A2       ; kernel: slots left to draw (1 + enemies shown)
LaserSlot   = $A4       ; kernel: the slot drawn when the laser row came
NoField     = $AD
SlotPos     = $B0       ; 6 slots: coarse position, REFP0 (kernel: then CXPPMM)
SlotFine    = $B6       ; 6: HMP0 (high nibble), graphics page (low nibble)
SlotColLo   = $BC       ; 6: colour pointer, low byte
SlotTop     = $C2       ; 6: top row
SlotGfxLo   = $C8       ; 6: graphics pointer, low byte
LaserRow    = $D7
LaserPF     = $DA       ; 6: PF0, PF1, PF2 left, PF0, PF1, PF2 right
DigitPtr    = $F2       ; 6 pointers: the 48-pixel bands' graphics

; SuperChip RAM (as the game reads it)
XShipCol    = $F0CA     ; the ship's, stars', mountains' and laser's colour
XShipRefl   = $F081     ; REFP1 + 1
XFlash      = $F0FD     ; bit 7: smartbomb flash (background colour in bits 0-6)
XScanner    = $F0CF     ; 42: the scanner's six columns, 7 rows each

; ------------------------------- 2600 hardware: TIA writes land in zero page
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
CXM0P       = $30       ; bit 7: the enemy shot hit the ship
CXP0FB      = $32       ; bit 7: the laser hit an enemy
INPT4       = $3C       ; bit 7 clear: fire (left joystick)
INPT5       = $3D       ; ... (right joystick: smartbomb)
; RIOT
SWCHA       = $0280     ; joysticks (high nibble: left, low nibble: right)
SWCHB       = $0282     ; console switches
TIMINT      = $0285     ; timer flag (kept at $80: the game's waits for its timer end at once)

; ------------------------------------------------ 2600 program addresses
Reset0      = $D103     ; power on (bank 0's code, after bank 1's switch at $F100)
Overscan    = $D16C     ; where the game continues after the picture
PosTable    = $FBD0     ; X code -> coarse delay, fine motion
StarTable   = $FE00     ; stars and mountains per row
ScanBall    = $FA29     ; the scanner's ship marker

; ------------------------------------------------------------ C64 layout
; Two frame buffers in two VIC banks: buffer 0 in bank 1 ($4000), buffer 1 in bank 2 ($8000).
; Each: screen (the bitmap's colours, sprite pointers) at +$0000, sprite blocks at +$0400,
; bitmap at +$2000.
VIC0        = $4000
VIC1        = $8000
SPRBLK      = 16        ; first sprite block (+$0400)
D018VAL     = $08       ; screen +$0000, bitmap +$2000
COLRAM      = $D800
; 2600 line L is raster L + 14 and bitmap line L - 37: lines 37-236 fill the C64's 200.
; Sprite Y register = raster.
LINE2RAS    = 14
FIRSTLINE   = 37
TOPRASTER   = 20        ; frame top (in the border)
ENDRASTER   = 224 + LINE2RAS    ; frame end: the 2600's VBLANK
; what a tick ended with (CapKind)
KFIELD      = 0         ; the field
KBLANK      = 1         ; ... not drawn this frame ($AD)
KIDLE       = 2         ; idle too long: background only ($F0FD bit 7)
KTITLE      = 3         ; title / attract text
KWAVE       = 4         ; wave end

; ------------------------------------------------------- zero page ($40+)
; $02-$2C take the game's TIA writes and $30-$3D are its TIA reads, so ours start at $40.
        .virtual $40
ptrA        .word ?
ptrB        .word ?
ptrC        .word ?
ptrD        .word ?
tmp         .byte ?
tmp2        .byte ?
tmp3        .byte ?
tmp4        .byte ?
owed        .byte ?     ; game ticks due (counted by the raster interrupt, at most 6)
isPal       .byte ?
tickAcc     .byte ?
firstTick   .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)

switches    .byte ?     ; SWCHB toggles
curBuf      .byte ?     ; raster interrupt: frame buffer in use (0/1)
pending     .byte ?     ; a new frame is ready in the other buffer
rb          .byte ?     ; render: buffer being drawn
irqSave1    .byte ?     ; the interrupt: $01 as it found it
irqA        .byte ?
schI        .byte ?     ; the interrupt: next schedule entry, its line
waitR       .byte ?
v0          .byte ?
v1          .byte ?
v2          .byte ?
v3          .byte ?
fY          .byte ?     ; capture: the kernel's Y,
fLine       .byte ?     ; ... the 2600 line,
fSlot       .byte ?     ; ... the slot (X)
fTop        .byte ?     ; ... the enemy's top row (EnTop)
fRow        .byte ?     ; ... rows of the enemy so far
fCol        .byte ?     ; ... COLUP0
bmpHi       .byte ?     ; render: the bitmap's page
sprHi       .byte ?     ; render: the sprite blocks' page
erLoP       .word ?     ; render: the buffer's list of field bytes to clear (low, high bytes),
erHiP       .word ?
ern         .byte ?     ; ... its count
ptrE        .word ?     ; FillRun: ptrC + 256, its entry
frVec       .word ?
cD          .byte ?     ; collisions, images: the drawn slot, its row's Y
cy          .byte ?
ec0         .byte ?     ; an enemy's colours: its own, the shared ones
ec1         .byte ?
ec2         .byte ?
eMask       .byte ?     ; building an image: pixels outside the comb, REFP0, quirk line, last
eRef        .byte ?     ; row, the row's mask
eQ          .byte ?
eBot        .byte ?
eMk         .byte ?
eStop       .byte ?     ; EnemyBuild: the Y after its last row, after the rows being drawn
eEnd        .byte ?
irqX        .byte ?     ; the interrupt: X, Y as it found them, its next part, the next entry's
irqY        .byte ?     ; interrupt line
irqVec      .word ?
schR2       .byte ?
        .cerror * > $80, "zero page overflow"
        .endv

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title, credits and controls.
; (Lower case here: 64tass -a turns it into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " stargate"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600 (1984)"
Bas30   .word Bas40, 30
        .null $8f, " version 0.1"
Bas40   .word Bas50, 40
        .null $8f, " ported by claude and doughboy68"
Bas50   .word Bas60, 50
        .null $8f, " joy port 2 or wasd-fly space-fire"
Bas60   .word Bas70, 60
        .null $8f, " joy port 1: up inviso down hyper"
Bas70   .word Bas80, 70
        .null $8f, "  fire smartbomb (keys i k return)"
Bas80   .word Bas90, 80
        .null $8f, " f1 or fire-start f2-power off/on"
Bas90   .word Bas100, 90
        .null $8f, " f3-select f5-colour/b&w"
Bas100  .word Bas110, 100
        .null $8f, " f7/f8-difficulty"
Bas110  .word BasEnd, 110
        .null $8f, " f-flicker on/off"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #$ff
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01

        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -
        jsr InitTables
        jsr InitVars

        ; copy the 2600 program: bank 0 to $D000 (under the I/O: $01 = $34 meanwhile), bank 1
        ; to $F000, then patch it
        lda #<GameImage
        sta ptrA
        lda #>GameImage
        sta ptrA+1
        lda #0
        sta ptrB
        lda #$d0
        sta ptrB+1
        lda #$34
        sta $01
        ldx #32
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        lda ptrB+1
        cmp #$e0                ; (bank 1 follows bank 0 in the image, at $F000)
        bne +
        lda #$f0
        sta ptrB+1
+       dex
        bne -
        lda #<Patches           ; the patches: address, count, bytes
        sta ptrA
        lda #>Patches
        sta ptrA+1
_patch  ldy #0
        lda (ptrA),y
        sta ptrB
        iny
        lda (ptrA),y
        sta ptrB+1
        beq _patched
        iny
        lda (ptrA),y
        tax
-       iny
        lda (ptrA),y
        sty tmp
        ldy #0
        sta (ptrB),y
        inc ptrB
        bne +
        inc ptrB+1
+       ldy tmp
        dex
        bne -
        iny
        tya
        clc
        adc ptrA
        sta ptrA
        bcc _patch
        inc ptrA+1
        bne _patch
_patched
        lda #0                  ; the SuperChip RAM starts clear
        tax
-       sta $f080,x
        inx
        bpl -
        lda #<Nmi               ; our vectors replace the 2600's
        sta $fffa
        lda #>Nmi
        sta $fffb
        lda #<Irq
        sta $fffe
        lda #>Irq
        sta $ffff
        lda #$35
        sta $01
        jsr CopyPart2           ; (after the 2600 program: its copy at $4600 lies over the image)
        jsr InitPos

        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #$80
        sta TIMINT
        sta INPT4
        sta INPT5
        lda #1
        sta firstTick

        jsr DetectPal           ; (before InitVideo clears where the SID tables load)
        jsr InitVideo
        jsr InitSound
        lda #$ff                ; CIA 2 timer A free-running (testing aid: DbgTime)
        sta $dd04
        sta $dd05
        lda #%00010001
        sta $dd0e

        lda #0                  ; start the raster interrupt on an empty frame
        sta curBuf
        lda #<ITop
        sta irqVec
        lda #>ITop
        sta irqVec+1
        lda #TOPRASTER
        sta $d012
        lda #$3b                ; bitmap mode, 25 rows, screen on
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

; ================================================================ main loop
; The raster interrupt counts the game ticks due (owed: one a frame, PAL 6 every 5 frames, at
; most 6; more and the game slows). The loop never waits while there is work: it draws the
; state the last tick left when the other buffer is free (pending clear: the frame drawn last
; has been shown) and the game isn't far behind; else it runs a tick if one is due. Far behind
; (4 or more due) the ticks come first. (Drawing while a few ticks behind lets the busy frames
; borrow time from the quiet ones: tools/loopsim.js measured fewer frames shown twice than
; with ticks first from 2 due, on NTSC and PAL.)
MainLoop:
        lda CapN                ; a state not drawn yet,
        beq _tick
        lda pending             ; ... the buffer free (the frame end may show it: never draw
        bne _tick               ; into it before, a half-written schedule)
        lda owed                ; ... not far behind: draw it
        cmp #4
        bcs _tick
        lda DbgOn               ; (testing aids: timing, the border shows where the time goes)
        ora DbgBorder
        beq +
        lda #2
        jsr DbgStart
+       jsr Render
        lda #0
        sta CapN
        inc DbgLoops            ; (testing aid: frames drawn)
        bne +
        inc DbgLoops+1
+       lda DbgOn
        beq +
        ldy #0
        jsr DbgMax
+       jmp MainLoop
_tick   lda owed                ; a tick due: run it
        beq _wait
        lda DbgOn
        ora DbgBorder
        beq +
        lda #5
        jsr DbgStart
+       jsr ReadInput
        lda PowerReq            ; F2: the power switch
        beq +
        jsr PowerCycle
+       jsr Tick
        dec owed
        jsr UpdateSound
        lda DbgOn
        beq +
        ldy #2
        jsr DbgMax
+       jmp MainLoop
_wait   jsr DbgWait0            ; nothing to do until the next frame end
        lda DbgBorder
        beq +
        lda #0
        sta $d020
+       jmp MainLoop

; Testing aids (tools/c64late.js sets DbgOn): CIA 2 timer A counts down freely; the most cycles
; drawing a frame took (DbgRMax), a tick (DbgTMax), a wait (DbgPMax), and in all the cycles spent
; waiting (DbgWait) and working (DbgWork). DbgWork0 starts a piece of work (a wait ending: its
; time summed), DbgMax ends it, DbgWait0 starts a wait.
DbgStart:                       ; (A: the border's colour, if DbgBorder)
        ldx DbgBorder
        beq DbgWork0
        sta $d020
DbgWork0:
        lda DbgOn
        beq _out
        jsr DbgTime
        stx dbgT1               ; (this piece of work's start)
        sty dbgT1+1
        lda dbgWaiting
        beq _out
        lda #0
        sta dbgWaiting
        lda dbgW                ; the wait
        ldx dbgW+1
        ldy #4
        jsr DbgMax0
        lda dbgW
        ldx dbgW+1
        ldy #DbgWait - DbgRMax
        jmp DbgSum
_out    rts
DbgWait0:
        lda DbgOn
        beq _out
        lda dbgWaiting
        bne _out
        inc dbgWaiting
        jsr DbgTime
        stx dbgW
        sty dbgW+1
_out    rts
; DbgSum: cycles from the time in A/X (low/high) to dbgNow added to the 32-bit sum at DbgRMax+Y
DbgSum: sec
        sbc dbgNow
        sta dbgTmp
        txa
        sbc dbgNow+1
        tax
        lda dbgTmp
        clc
        adc DbgRMax,y
        sta DbgRMax,y
        txa
        adc DbgRMax+1,y
        sta DbgRMax+1,y
        bcc +
        lda DbgRMax+2,y
        adc #0
        sta DbgRMax+2,y
        bcc +
        lda DbgRMax+3,y
        adc #0
        sta DbgRMax+3,y
+       rts

; DbgTime: dbgNow (and X/Y) = CIA 2 timer A
DbgTime:
-       ldy $dd05
        ldx $dd04
        cpy $dd05
        bne -
        stx dbgNow
        sty dbgNow+1
        rts
; DbgMax: the cycles since this piece of work started (dbgT1): summed in DbgWork, the largest
; kept at DbgRMax+Y (Y = 0 drawing, 2 a tick); DbgMax0: from the time in A/X (low/high) to
; dbgNow (Y = 4: a wait)
DbgMax:
        lda DbgOn
        bne _dm
        rts
_dm     sty dbgY
        jsr DbgTime
        lda dbgT1
        ldx dbgT1+1
        ldy #DbgWork - DbgRMax
        jsr DbgSum
        ldy dbgY
        lda dbgT1
        ldx dbgT1+1
DbgMax0:
        sec                     ; (the timer counts down: start - now)
        sbc dbgNow
        sta dbgTmp
        txa
        sbc dbgNow+1
        sta dbgTmp+1
        cmp DbgRMax+1,y
        bcc _keep
        bne _new
        lda dbgTmp
        cmp DbgRMax,y
        bcc _keep
_new    lda dbgTmp
        sta DbgRMax,y
        lda dbgTmp+1
        sta DbgRMax+1,y
_keep   rts

; One 2600 frame of game logic: the original code from the end of the picture ($D16C) to
; where it would draw the next (FieldHook, or bank 1's switch back at $FFF2 after the title,
; wave end and smartbomb flash kernels): both come to TickEnd. The game runs with all RAM
; visible ($01 = $34). Our stack pointer is kept for TickEnd (the game's own TXS are patched
; out; this way nothing it leaves on the stack matters).
Tick:
        lda DbgAuto             ; (testing aid: the inputs by the tick count)
        beq +
        jsr AutoInput
+       lda #0                  ; bands drawn this tick (BandHook), objects hidden (HideObj),
        sta BandN               ; their slots (XtraSlots)
        sta HidN
        sta XN
        lda #$34
        sta $01
        tsx
        stx tickS
        lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp Reset0              ; the very first frame starts at power-on
+       jmp Overscan

TickEndK:                       ; (bank 1's switch back, $FFF2: the kernels it ran itself)
        lda #KIDLE
        bit XFlash
        bmi +
        lda #KTITLE
        ldx ShipsLeft
        beq +
        lda #0                  ; wave end: CXCLR on line 177, nothing after
        sta CXM0P
        sta CXP0FB
        lda #KWAVE
+       sta CapKind
TickEnd:
        lda ScDirty             ; the scanner rows the game wrote: for both buffers
        beq +
        ora ScDirtyB
        sta ScDirtyB
        lda ScDirty
        ora ScDirtyB+1
        sta ScDirtyB+1
        lda #0
        sta ScDirty
+       lda BandN               ; (a different number of bands: they changed)
        cmp BandNLast
        beq +
        sta BandNLast
        inc BandGen
+       ldx tickS
        txs
        lda #$35
        sta $01
        lda #1
        sta CapN
        rts                     ; (returns to whoever called Tick)

; Replaces the 2600's clearing loop ($D10B: "sta $00,x / sta $EF80,x / inx / bne", A = 0,
; from X = 0 at power-on, X = $89 at Game Reset): the 2600 RAM ($80-$FF, not the C64's zero
; page) and the SuperChip's (on the C64: $F080-$F0FF; $EF80 + X is its write address).
ClearLoop:
-       cpx #$80
        bcc +
        sta $00,x
        sta $f000,x
+       inx
        bne -
        lda #$7f                ; (the scanner's rows: all changed)
        sta ScDirty
        lda #0
        rts

; Replaces $F259-$F289: the score's digit pointers, built on the 2600 with PHA (its stack
; pointer at $FD: the stack is in its RAM, $F2-$FD), then the leading zeros (digit pointer
; $26) blanked (pointer $89), at most five. $F2/$F3: the score's first digit ... $FC/$FD
; the last. Leaves the carry as the 2600's last CMP #$26 did (the scanner's ship marker
; depends on it: HMBL at $F2A6).
DigitPtrs:
        lda Flicker             ; (flicker off: the hidden objects' slots, XtraSlots)
        bne +
        lda HidN
        beq +
        jsr XtraSlots
+       lda #$f8                ; (every digit's page)
        .for i = 1, i < 12, i += 2
        sta DigitPtr+i
        .next
        lda Score               ; the same score as last time: the same pointers
        cmp DigScore
        bne _make
        lda Score+1
        cmp DigScore+1
        bne _make
        lda Score+2
        cmp DigScore+2
        bne _make
        .for i = 0, i < 12, i += 2
        lda DigLo+i/2
        sta DigitPtr+i
        .next
        ldx DigX
        php                     ; (the flags as the CMP left them: N, Z, C kept)
        pla
        and #$7c
        ora DigNZC
        sta DigitC
        lsr
        rts
_make   lda Score               ; (a new score: kept)
        sta DigScore
        lda Score+1
        sta DigScore+1
        lda Score+2
        sta DigScore+2
        .for i = 0, i < 3, i += 1
        lda Score+i             ; score byte i: digits 2i, 2i + 1
        and #$0f
        tax
        lda DigitTab,x
        sta DigitPtr+4*i+2
        lda Score+i
        lsr
        lsr
        lsr
        lsr
        tax
        lda DigitTab,x
        sta DigitPtr+4*i
        .next
        ldx #0                  ; leading zeros
-       lda DigitPtr,x
        cmp #$26
        bne +
        lda #$89
        sta DigitPtr,x
        inx
        inx
        cpx #10
        bne -
        sec                     ; (five zeros: the last CMP was equal)
+       php                     ; (kept for the scanner's marker)
        stx DigX                ; (and for the same score next time)
        .for i = 0, i < 12, i += 2
        ldx DigitPtr+i
        stx DigLo+i/2
        .next
        ldx DigX
        pla
        sta DigitC
        and #$83
        sta DigNZC
        lda DigitC
        lsr
        rts
DigitTab    = $F93E             ; digit -> graphics (low byte), page $F8

; $F900 / $F904 (patched to come here): a 48-pixel band, colour A ($F900) or the colour
; already set ($F904), Y + 1 rows from the graphics pointers $F2-$FD. The C64 draws it later
; (Render): here it's recorded with the line it starts on, which depends only on where it's
; called from (the kernels time their bands by WSYNC and timer waits that don't depend on
; the game: tools/model.js). Leaves the RAM and the registers as the 2600's routine would.
BandHook:
        sta bandColour
BandHook0:
        sty tmp                 ; rows - 1
        tsx                     ; the caller: the return address (the low bytes all differ)
        ldy $0101,x
        ldx BandIdx,y           ; ... -> its BandCall index
        bpl +
        inc DbgBadBand          ; (not a known caller: shouldn't happen)
        ldx #0
+       ldy BandN
        cpy #BANDMAX
        bcs _full
        txa                     ; the same as the last tick's band here? (else a new version)
        cmp BandWho,y           ; (the same caller: the same line and rows, every caller's Y
        bne _newj               ; is a constant)
        lda BandCallKind,x      ; the score's band: its pointers come from the score alone
        beq _ptrs               ; (DigitPtrs); an icon band's from IconRow's A and Y alone
        lsr
        bcs _score
        lda IconA
        cmp BandK0,y
        bne _newj
        lda IconY
        cmp BandK1,y
        bne _newj
        beq _sameK
_score  lda Score
        cmp BandK0,y
        bne _newj
        lda Score+1
        cmp BandK1,y
        bne _newj
        lda Score+2
        cmp BandK2,y
        bne _newj
_sameK  lda bandColour          ; (the score's and the icons' callers, $F2EA-$F31A, use nothing
        cmp BandCol,y           ; the loop leaves: FieldHook or the next band sets it again)
        beq +
        sta BandCol,y
        inc BandGen
+       inc BandN
        rts
_same   lda bandColour
        cmp BandCol,y
        beq +
        sta BandCol,y
        inc BandGen
+       inc BandN
_full   lda #$ff                ; as the loop leaves it: $F0 = $FF, $F1 / Y = ($FC),0,
        sta $f0                 ; X = ($FA),0, A = 0 (Z set)
        ldy #0
        lda (DigitPtr+10),y
        sta $f1
        lda (DigitPtr+8),y
        tax
        ldy $f1
        lda #0
        rts
_newj   jmp _new
_ptrs   stx tmp3                ; (the call's index)
        ldx BandTimes12,y
        .for i = 0, i < 12, i += 1
        lda DigitPtr+i
        cmp BandPtrs+i,x
        bne _newp
        .next
        jmp _same
_newp   ldx tmp3
_new    txa                     ; a new version: caller, line, rows, pointers, key
        sta BandWho,y
        lda BandCallLine,x
        sta BandLine,y
        lda tmp
        sta BandRows,y
        lda BandCallKind,x
        sta tmp3
        ldx BandTimes12,y
        .for i = 0, i < 12, i += 1
        lda DigitPtr+i
        sta BandPtrs+i,x
        .next
        lda tmp3                ; (its key)
        beq _key
        lsr
        bcc +
        lda Score
        sta BandK0,y
        lda Score+1
        sta BandK1,y
        lda Score+2
        sta BandK2,y
        jmp _key
+       lda IconA
        sta BandK0,y
        lda IconY
        sta BandK1,y
_key    tya
        tax
        inc BandVer,x
        inc BandGen
        jmp _same

; The kernels' calls of $F900 / $F904 (return address - 1, as JSR pushes it; the low bytes
; all differ) and the line each band starts on
BandCallN   = 12
BandCallLo:  .byte <$F2EA, <$F2FE, <$F30C, <$F31A, <$F12C, <$F13F, <$F154, <$F56E, <$F59F, <$F5B7, <$F63B, <$F665
BandCallLine: .byte 39, 48, 55, 60, 60, 213, 136, 79, 93, 109, 157, 169
BandCallKind: .byte 1, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0    ; 1 the score's (after DigitPtrs), 2 an icon row's (after IconRow)

; Replaces IconRow ($F66B, called only before the bands at $F2FE, $F30C, $F31A): Y icons (A) in
; the band's pointers' low bytes from $FC down, then $89 (blank); the same, and its A and Y
; kept for BandHook. (Its callers set A and Y again before the band: the registers it leaves
; don't matter.)
IconRowC:
        sta IconA
        sty IconY
        dey
        bmi _b0
        sta DigitPtr+10
        dey
        bmi _b1
        sta DigitPtr+8
        dey
        bmi _b2
        sta DigitPtr+6
        dey
        bmi _b3
        sta DigitPtr+4
        dey
        bmi _b4
        sta DigitPtr+2
        dey
        bmi _b5
        sta DigitPtr+0
        rts
_b0     lda #$89
        sta DigitPtr+10
_b1     lda #$89
        sta DigitPtr+8
_b2     lda #$89
        sta DigitPtr+6
_b3     lda #$89
        sta DigitPtr+4
_b4     lda #$89
        sta DigitPtr+2
_b5     lda #$89
        sta DigitPtr
        rts

; Replaces LoadTextPtrs ($FAF4: X = 11 down to 0, $F2,X = $FA3B,Y, Y down too), unrolled:
; the same RAM, registers and flags (X = $FF: N set, Z clear; the carry kept)
TextPtrsC:
        .for k = 11, k >= 0, k -= 1
        lda $fa3b,y
        sta DigitPtr+k
        dey
        .next
        ldx #$ff
        rts

; Replaces $DBF1-$DBF5 (LDA #$FF / STA $F043,X: an object left out of this frame's display
; list, the flicker): the same, the object kept for flicker off (HidObj, 2 at most). Keeps X, Y.
HideObj:
        sty hidY
        ldy HidN
        cpy #2
        bcs +
        lda $f0c3,x
        sta HidObj,y
        inc HidN
+       ldy hidY
        lda #$ff
        sta $f0c3,x
        rts

; XtraSlots: (flicker off) the hidden objects' slots as the kernel's preparation ($F1F7) would
; have made them: position code, fine motion and page, top row, graphics and colour pointers
XtraSlots:
        lda #0
        sta XN
        ldx #0
_obj    cpx HidN
        beq _out
        stx hidY
        ldy HidObj,x            ; the object
        ldx $f082,y             ; its X code -> position (REFP0 from $F092 bit 3)
        lda $fbd0,x
        sta xT
        eor $f092,y
        and #8
        eor xT
        ldx XN
        sta XPos,x
        lda $e0,y               ; its row
        sta XTop,x
        lda $f0a2,y             ; its type (exploding: $F6's)
        tay
        lda $a7
        beq +
        ldy $f6
+       sty xT2
        lda xT                  ; fine motion and page
        asl
        and #$f0
        ora $f948,y
        sta XFine,x
        tya                     ; graphics and colours: type * 4 + its animation frame
        asl
        asl
        ldx $fa00,y
        ora $f8,x
        tay
        ldx XN
        lda $fb00,y
        sec
        sbc XTop,x
        sta XGfx,x
        lda $fb50,y
        sbc XTop,x
        sta XCol,x
        inc XN
        ldx hidY
        inx
        bne _obj
_out    rts

; F2: power off and on. Clear the TIA (our copies of its registers) and start again from the
; game's power-on code; the console switches stay as they are.
PowerCycle:
        lda #0
        sta PowerReq
        sta autoT               ; (testing aid: AutoInput from the start)
        sta autoT+1
        sta autoW
        sta autoW+1
        lda #1
        sta autoRnd
        lda #0
        ldx #2                  ; the TIA's registers ($02-$2C) and our copies of its reads
-       sta $00,x
        inx
        cpx #$3e
        bne -
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        sta INPT5
        sta TIMINT
        lda #1
        sta firstTick
        rts

; =========================================================== interrupts
; The frame top shows the buffer whose frame is ready (VIC bank, sprites, colours), then
; the buffer's schedule (the enemies' multicolour sprite colours, moves of reused sprites,
; the field's background) runs entry by entry, and the frame end lets the main loop draw
; the next frame. The game runs with $01 = $34 (no I/O): the interrupt switches the I/O in
; and puts $01 back. Each part sets the next one's line and handler (irqVec).
Irq:
        sta irqA
        stx irqX
        sty irqY
        lda $01
        sta irqSave1
        lda #$35
        sta $01
        cld                     ; the game uses decimal mode now and then
        lda $d019
        sta $d019
        jmp (irqVec)

; frame top: the buffer's VIC bank, sprites, background
ITop:   ldy curBuf
        lda BankBits,y
        sta $dd00
        lda #$18                ; (no fine scroll above the field)
        sta $d016
        lda StMsb,y
        sta $d010
        lda StEn,y
        sta $d015
        sta irqEn               ; (only the sprites shown need their registers)
        lda StBg,y              ; background (only when it changes)
        cmp $d021
        beq +
        sta $d021
+       lda StMc1,y
        sta $d025
        lda StMc2,y
        sta $d026
        tya                     ; 8 * buffer: staged sprite values
        asl
        asl
        asl
        tay
        .for i = 0, i < 8, i += 1
        lsr irqEn
        bcc +
        lda StCol+i,y
        sta $d027+i
        lda StX+i,y
        sta $d000+2*i
        lda StY+i,y
        sta $d001+2*i
+
        .next
        ldy curBuf              ; the schedule's first entry
        lda SchBase,y
        sta schI
        tay
        lda SchType,y
        bmi _none
        lda SchRas,y            ; (its interrupt 2 lines before its line)
        sec
        sbc #2
        sta $d012
        sta schR2
        lda #<ISched
        sta irqVec
        lda #>ISched
        sta irqVec+1
        lda $d012               ; (that line reached already: now, else it would wait a frame)
        cmp schR2
        bcs +
        jmp IrqOut
+
        lda #1
        sta $d019
        jmp ISched
_none   jsr IEnd0
        jmp IrqOut

; a schedule entry: SchType 0 = enemy colours ($D025, $D026), 1 = background ($D021),
; 3 = fine scroll ($D016), 4 = $D011
; (the interrupt comes 2 lines before the entry's line, SchRas: the value is loaded, then
; written as that line starts, in the border left of the picture)
IWAIT   .macro
-       ldy $d012
        cpy waitR
        bcc -
        .endm
ISched: ldy schI
        lda SchType+1,y         ; the next entry's interrupt set up first (while this one waits)
        bmi _last
        lda SchRas+1,y
        sec
        sbc #2
        sta $d012
        sta schR2
        bne _this               ; (always)
_last   jsr IEnd0               ; (none: the frame end next)
_this   lda SchRas,y
        sta waitR
        lda SchType,y
        bne +
        lda SchA,y              ; 0: the enemies' shared colours
        ldx SchB,y
        .IWAIT
        sta $d025
        stx $d026
        jmp _next
+       cmp #1
        bne +
        lda SchA,y              ; 1: the background
        .IWAIT
        sta $d021
        jmp _next
+       cmp #3
        bne +
        lda SchA,y              ; 3: the fine scroll
        .IWAIT
        sta $d016
        jmp _next
+       cmp #4
        bne _next               ; (no other kinds)
        lda SchA,y              ; 4: $D011 (the invalid mode: a black field)
        .IWAIT
        sta $d011
_next   inc schI
        ldy schI
        lda SchType,y
        bmi _out                ; (the last: the frame end next)
        lda $d012               ; the next one's line reached already: now, else it would wait
        cmp schR2               ; a frame
        bcs +
_out    jmp IrqOut
+
        lda #1
        sta $d019
        jmp ISched

; IEnd0: the frame end's interrupt next (keeps Y)
IEnd0:  lda #ENDRASTER
        sta $d012
        lda #<IEnd
        sta irqVec
        lda #>IEnd
        sta irqVec+1
        rts

; frame end
IEnd:   lda #$3b                ; (out of the invalid mode, if a black field used it)
        sta $d011
        lda #<ITop
        sta irqVec
        lda #>ITop
        sta irqVec+1
        lda owed                ; (testing aid: a frame end with the last one's tick still due)
        beq +
        inc DbgLate
        bne +
        inc DbgLate+1
+       ldx #1                  ; the ticks due: one a frame, PAL 6 every 5
        lda isPal
        beq _add
        ldy tickAcc
        iny
        cpy #5
        bcc +
        ldy #0
        inx
+       sty tickAcc
_add    txa
        clc
        adc owed
        cmp #7                  ; (at most 6: further behind, the game slows)
        bcc +
        inc DbgLost
        bne _cap
        inc DbgLost+1
_cap    lda #6
+       sta owed
        inc DbgFrames           ; (testing aid: frame ends, and those with nothing new)
        bne +
        inc DbgFrames+1
+       lda pending             ; a newly finished frame: shown from the next frame top
        bne _new
        inc DbgRepeat
        bne _top
        inc DbgRepeat+1
        jmp _top
_new
        lda curBuf
        eor #1
        sta curBuf
        lda #0
        sta pending
        ldx curBuf              ; (testing aid: frames shown by their tick's kind)
        lda BufPar,x
        cmp lastPar
        sta lastPar
        bne _kind
        inc DbgSame
        bne _kind
        inc DbgSame+1
_kind   asl
        tax
        inc DbgShown,x
        bne +
        inc DbgShown+1,x
+
_top    lda #TOPRASTER
        sta $d012
IrqOut  lda irqSave1
        sta $01
        ldx irqX
        ldy irqY
        lda irqA
        rti

Nmi:    rti

        .include "capture.asm"
        .include "collide.asm"
        .include "render.asm"
        .include "data.asm"

; ---- part 2: code in bank 1's RAM the VIC doesn't show ($4600-$4FFF), stored after the 2600
; program and copied there at start-up (CopyPart2)
PART2       = $4600
Part2Src:
        .logical PART2
Part2:
        .include "layer.asm"
        .include "part2.asm"

Part2End:
        .cerror * > $5000, "part 2 runs past $4FFF (the layer code for buffer 0 is at $5000)"
        .here

; ---- part 3: bank 2's RAM the VIC doesn't show ($8600-$8FFF): the SID's pitch tables for
; this machine (SidFreq, 1K: DetectPal copies them from SidSrc), then code, stored after part 2
; and copied there at start-up (CopyPart2)
SidFreq     = $8600
PART3       = $8A00
Part3Src:
        .logical PART3
        .include "input.asm"
        .include "sound.asm"
        .include "auto.asm"
Part3End:
        .cerror * > $9000, "part 3 runs past $8FFF (the variables at $9000)"
        .here

; the SID's pitch tables, PAL and NTSC (only loaded: DetectPal copies one to SidFreq)
SidSrc:
        .include "sidtables.inc"

; CopyPart2: part 2 to $4600, part 3 to $8A00 (from where they load, past the 2600 program)
CopyPart2:
        lda #<Part2Src
        sta ptrA
        lda #>Part2Src
        sta ptrA+1
        lda #<PART2
        sta ptrB
        lda #>PART2
        sta ptrB+1
        ldx #>(Part2End - PART2 + 255)
        jsr _copy
        lda #<Part3Src
        sta ptrA
        lda #>Part3Src
        sta ptrA+1
        lda #<PART3
        sta ptrB
        lda #>PART3
        sta ptrB+1
        ldx #>(Part3End - PART3 + 255)
_copy   ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        rts
