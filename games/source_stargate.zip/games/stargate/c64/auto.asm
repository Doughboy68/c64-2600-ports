; ---------------------------------------------------------------- testing aid
; tools/c64late.js --auto: with DbgAuto set, the inputs are played by the tick count from F2 on
; (Game Reset, then flying about and firing as tools/play.js does, now and then the right
; joystick), ships held at 3 and a wave ended every 900 ticks or so (as tools/cheat.js does),
; so every build plays the same game whatever its timing, into the later waves. From tick
; AUTOFROM to AUTOTO the counters (DbgLoops ... DbgSame) run; then they're kept in DbgAutoRes,
; DbgAuto is cleared and the inputs are left alone again.
AUTOFROM    = 300
AUTOTO      = AUTOFROM + 7200

AutoInput:
        inc autoT
        bne +
        inc autoT+1
+       lda autoT+1             ; ticks 60-67: Game Reset
        bne _play
        lda autoT
        cmp #68
        bcs _play
        ldx #$0b
        cmp #60
        bcc +
        dex
+       stx SWCHB
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        sta INPT5
        rts
_play   lda #$0b
        sta SWCHB
        lda ShipsLeft           ; ships held at 3
        beq +
        lda #3
        sta ShipsLeft
+       inc autoW               ; every 900 ticks or so (on an even frame, no wave end on): the
        bne +                   ; wave's enemies cleared and its timer set
        inc autoW+1
+       lda autoW+1
        cmp #>900
        bcc _in
        lda autoW
        cmp #<900
        bcc _in
        lda FrameCount
        lsr
        bcs _in
        lda $aa
        bne _in
        lda ShipsLeft
        beq _in
        lda #0
        sta autoW
        sta autoW+1
        ldx #$0e
-       sta $f0a2,x
        dex
        bpl -
        lda #5
        sta $a8
_in     lda autoT               ; new inputs every 8 ticks
        and #7
        bne _set
        jsr _rnd
        and #7
        tax
        lda AutoDirs,x
        sta autoDir
        jsr _rnd
        and #$f0
        cmp #$60                ; (fire 10 times in 16)
        lda #0
        rol
        sta autoFire
        jsr _rnd
        ldx #$0f                ; the right joystick: up or down now and then
        cmp #$f8
        bcc +
        ldx #$0e
        lsr
        bcc +
        ldx #$0d
+       stx autoRight
_set    lda autoDir
        asl
        asl
        asl
        asl
        ora autoRight
        sta SWCHA
        lda #$80
        ldx autoFire            ; fire pressed 2 ticks in 4
        beq +
        lda autoT
        and #2
        beq +
        lda #$80
+       sta INPT4
        lda #$80
        sta INPT5
        lda autoT+1             ; the counters
        cmp #>AUTOFROM
        bne +
        lda autoT
        cmp #<AUTOFROM
        bne +
        lda #0                  ; AUTOFROM: from 0
        ldx #DbgAutoN - 1
-       sta DbgLoops,x
        dex
        bpl -
+       lda autoT+1
        cmp #>AUTOTO
        bne _out
        lda autoT
        cmp #<AUTOTO
        bne _out
        ldx #DbgAutoN - 1       ; AUTOTO: the counters kept, the inputs left alone
-       lda DbgLoops,x
        sta DbgAutoRes,x
        dex
        bpl -
        lda #0
        sta DbgAuto
_out    rts
_rnd    lda autoRnd
        asl
        bcc +
        eor #$1d
+       sta autoRnd
        rts
AutoDirs:   .byte $7, $7, $b, $f, $e, $d, $6, $9    ; right, right, left, none, up, down, diagonals
