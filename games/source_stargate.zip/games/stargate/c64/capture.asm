; ================================================================ capture
; FieldHook replaces the 2600's scanner and field kernel ($F322-$F550, patched to come here):
; it works out what the kernel would draw, for Render, and leaves the RAM as the kernel would,
; collision results included. The rules are tools/model.js's:
;
; The field is lines 84-223, one line per Y: line = 223 - Y (Y = $8B on line 84, the field ends
; on the line where Y reaches 0 after Y = 1). Lines with odd Y are "A" lines, even Y "B" lines;
; an enemy's repositioning takes two lines in their place (R1, odd; R2, even), the laser two
; (L1 odd, L2 even). Player 0 draws the enemies one after another (slots $A2-1 down to 0): an
; enemy shows on the line of Y = y the graphics byte g(y) and colour c(y) (pointers $9D, $9F),
; from its first row ($A1, or later) until a zero byte read on a B line (one row before Y);
; then R1 and R2 for the next slot. VDELP0 is on, so each GRP0 write shows from the next
; line; on L2 the ship's GRP1 is written mid-line (clock 31) and both players show the line
; before's graphics left of it.
;
; Collisions (the TIA's, from line 83's CXCLR on): CXPPMM is read in each slot's R2 (clock 76)
; and saved in its $B0,x: P0-P1 (bit 7: an enemy above touched the ship) and M0-M1 (bit 6: the
; shot met a star or mountain); after the field the game reads CXM0P bit 7 (the shot hit the
; ship) and CXP0FB bit 7 (the laser hit an enemy). The HMOVE comb (pixels 0-7 of every field
; line) draws nothing and collides with nothing.

FieldHook:
        ; the scanner's side effects: $F8/$F9 its marker's pointer, $F0/$F1 the loop's
        lda ShipY
        lsr
        lsr
        lsr
        tax
        lda #$67
        sec
        sbc ScanBall,x
        sta $f8
        lda #$fe
        sta $f9
        lda $f0f2
        sta $f1
        lda #$ff
        sta $f0
        lda NoField
        beq +
        lda #0                  ; no field this frame ($F535; CXCLR on line 83, nothing after)
        sta CXM0P
        sta CXP0FB
        sta Slots
        sta $a3
        lda #KBLANK
        sta CapKind
        jmp TickEnd
+       lda #KFIELD
        sta CapKind
        ldx nD                  ; (the last walk's R1 marks cleared)
        beq +
        lda #0
-       ldy DR1-1,x
        sta R1Flag,y
        dex
        bne -
+
        ; what the field needs: positions, the ship's rows
        ldx PosCode             ; the ship (player 1)
        lda PosP,x
        sta ShipX
        ldx PosCode+1           ; the shot (missile 0)
        lda PosM,x
        sta M0X
        ldx PosCode+2           ; stars and mountains (missile 1, ball) on line 83
        lda PosM,x
        sta M1X83
        ldx PosCode+3
        lda PosM,x
        sta BLX83
        lda XShipRefl           ; REFP1 = $F081 - 1 (bit 3)
        sec
        sbc #1
        and #8
        sta ShipRef
        lda ShipRow             ; the ship's rows: ($96),y from Y = $97 - 1 down (16): the
        sec                     ; pointer in ptrD for Collide (on the field's lines Y = 1-$8B
        sbc #1                  ; a row is just that)
        sta ShipTop
        lda ShipLo2
        sta ptrD
        lda ShipGfx+1
        sta ptrD+1

        ; ---- the walk, line by line, as the kernel goes (model.js 'F461' ... states)
        lda #0
        sta nD
        sta lzOn
        sta lzAct
        sta m0Seen
        sta xreg
        lda #160                ; (the shot's off write: none yet)
        sta m0Off
        lda #$ff
        sta fCol
        lda #$8b
        sta fY

; F461: the next slot (on a line start: R1)
WNext:  ldx Slots
        bne +
        lda #0                  ; no more: $A1 = 0, X = 0
        sta EnTop
        sta xreg
        jmp WScan
+       dex
        stx xreg
        lda SlotTop,x
        sta EnTop
        ldy nD                  ; a new drawn slot
        txa
        sta DSlot,y
        lda fY
        sta DR1,y
        sty tmp4
        tay                     ; (marked: IsR1)
        lda #1
        sta R1Flag,y
        ldy tmp4
        lda #0
        sta DTop,y
        sta DBot,y
        sta DQuirk,y
        lda SlotPos,x           ; position: coarse delay (bits 1-2, bit 7 a cycle more, bit 0 a
        sta tmp                 ; later reset), fine motion twice (HMP0 at R2 and the next line)
        and #8
        sta DRef,y
        lda tmp
        lsr                     ; (the kernel's LSR $B0,x: the RAM keeps it until CXPPMM)
        sta SlotPos,x
        ldy tmp                 ; (SlotClk: the reset's clock + 5, from bits 1-2, 7, 0)
        lda SlotClk,y
        ldy SlotFine,x
        sec
        sbc FineOf,y            ; - 2 * fine motion (signed)
        ldy nD
        jsr Mod160
        sta DX,y
        lda SlotFine,x          ; pointers: page from the fine byte's low nibble
        ora #$f0
        sta EnGfx+1
        sta EnCol+1
        sta DPg,y
        lda SlotColLo,x
        sta EnCol
        sta DCLo,y
        lda SlotGfxLo,x
        sta EnGfx
        sta DGLo,y
        stx Slots
        inc nD
        dec fY                  ; R1, R2
        dec fY
        lda fY                  ; (R2's DEY leaves the next line's Y: the laser row?)
        cmp LaserRow
        bne WScan
        jmp WL1                 ; the laser row, no enemy on it yet ($F4BF)

; F407 / F409 / F444 / F457 while the enemy isn't on yet: at the start of an A line (fY odd),
; skip to what comes first: the line its rows start (Y <= $A1: an A line shows its first row
; on the next line; a B line reads it now, and a zero byte there ends the enemy at once),
; the laser row's B line (Y = $D7 + 1, if $D7 is odd: B lines have even Y), or the end
; (Y = 1).
WScan:  lda EnTop
        cmp fY
        bcc +
        lda fY                  ; (on from this line)
+       sta tmp
        lda LaserRow
        lsr
        bcc _nolz
        lda LaserRow
        adc #0                  ; (carry set: $D7 + 1)
        cmp fY
        bcs _nolz               ; (already passed)
        cmp tmp
        bcc _nolz               ; (the rows start first)
        lda LaserRow            ; the laser's B line: its DEY leaves Y = $D7
        sta fY
        jmp W4CC
_nolz   lda tmp
        cmp #2
        bcs +
        jmp WEnd                ; (the end first)
+       sta fY
        lsr
        bcc WActB
        dec fY                  ; an A line: its first row shows on the B line (Y - 1)
        jsr WTop
WB:     dec fY                  ; a B line: DEY, the laser row?
        lda fY
        cmp LaserRow
        beq W4CC
; F457: (Y after the B line's DEY) on: a row, or a zero byte (the enemy's end); off: F407
W457:   lda fY
        cmp EnTop
        bcs WScan
        ldy fY
        lda (EnGfx),y
        beq WZero
        jsr WTop                ; (the row shows on the A line, Y = fY)
        ldy fY                  ; then, while it's on (Y < $A1 from here), two lines at a time:
-       dey                     ; F400 / F409: the A line's DEY: the end?
        beq _endOn
        dey                     ; the B line's DEY: the laser row?
        cpy LaserRow
        beq _laser
        lda (EnGfx),y           ; F457: a row, or a zero byte (the end)
        bne -
        sty fY
        jmp WZero
_endOn  sty fY
        jmp WEndOn
_laser  sty fY
        jmp W4CC
WZero   ldx nD                  ; the enemy's last row: the B line's (Y + 1)
        ldy fY
        iny
        tya
        sta DBot-1,x
        jmp WNext               ; R1 next
WActB   dec fY                  ; a B line (no row yet): DEY, the laser row?
        lda fY
        cmp LaserRow
        beq W4CC
        jmp W457
WEndOn  ldx nD                  ; the field ended with an enemy on: its rows down to Y = 1
        lda #1
        sta DBot-1,x
        jmp WEnd

; F4CC: the laser row's B line (DEY done: Y = $D7)
W4CC:   lda xreg
        sta LaserSlot
        lda fY
        cmp EnTop
        bcs WL1                 ; (F4BF: no enemy row on L1)
        jsr WTop                ; the row Y shows on L1
; F4E4: L1, the laser line
WL1:    lda #1
        sta lzOn
        lda fY
        sta lzY
        dec fY
        lda #0
        sta xreg
        lda fY
        cmp EnTop
        bcc _act
        dec fY                  ; L2 = a B line (F444 on): DEY, then F457
        jmp W457
_act    lda #1                  ; an enemy row on L2: PF2 cleared at clock 151 on L1,
        sta lzAct               ; GRP0 written there, L2's GRP1 mid-line (the quirk)
        ldx nD
        lda fY
        sta DQuirk-1,x
        jsr WTop
        dec fY                  ; L2's DEY, then F457
        jmp W457

WEnd:   jmp FieldDone

; the enemy's first row shown: fY (if not set yet)
WTop:   ldx nD
        lda DTop-1,x
        bne +
        lda fY
        sta DTop-1,x
        sta DBot-1,x
+       rts

; ---- after the walk: what the kernel leaves in RAM, the shot's lines, the collisions
FieldDone:
        ; the ship's pointer: $96 from the first A line (odd Y, not R1 or L1) whose DEY leaves
        ; Y below $97 (the field's last such line is Y = 3)
        lda ShipRow
        cmp #$8c
        bcc +
        lda #$8b
+       tay                     ; the odd Y at or below it
        and #1
        bne +
        dey
+
-       cpy #3
        bcc _noShip
        jsr IsTrueA
        bcs _ship
        dey
        dey
        jmp -
_ship   lda ShipLo2
        sta ShipGfx
_noShip jsr M0Setup
        jsr Collide
        lda nD                  ; (flicker off: the hidden objects too, for Render only)
        sta nDX
        lda XN
        beq +
        jsr XtraDraw
+       jmp TickEnd

; XtraDraw: (flicker off) the hidden objects' slots (XtraSlots) as drawn slots after the walk's
; (nDX): whole, from their top row (on the field) down to their first zero byte
XtraDraw:
        ldx #0
_x      cpx XN
        bne +
        rts
+       stx hidY
        ldy nDX
        cpy #DSMAX
        bcs _out
        lda #$ff                ; (no slot: no collisions)
        sta DSlot,y
        lda #0
        sta DR1,y
        sta DQuirk,y
        sta DTop,y
        lda XPos,x
        and #8
        sta DRef,y
        lda XFine,x
        ora #$f0
        sta DPg,y
        sta ptrB+1
        lda XCol,x
        sta DCLo,y
        lda XGfx,x
        sta DGLo,y
        sta ptrB
        lda XTop,x              ; rows: from the top (on the field)
        cmp #$8c
        bcc +
        lda #$8b
+       sta tmp
        ldy XPos,x              ; x as the slot's would be
        lda SlotClk,y
        ldy XFine,x
        sec
        sbc FineOf,y
        jsr Mod160
        ldy nDX
        sta DX,y
        ldy tmp                 ; the rows down to the first zero byte (or Y = 1)
        beq _skip
        lda (ptrB),y
        beq _skip
        tya
        ldx nDX
        sta DTop,x
-       sta DBot,x
        dey
        beq +
        lda (ptrB),y
        beq +
        tya
        bne -
+       inc nDX
_skip   ldx hidY
        inx
        jmp _x
_out    rts

; M0Setup: the shot's ENAM0 writes and colours from the line types. ENAM0 = (Y = $9A) is
; written on every B-type line (even Y): R2 at clock 16, L2 after an enemy row at -50, the
; others at 25; so the shot shows from its row's write to the write two lines down.
M0Setup:
        lda #0
        sta m0Seen
        lda #160
        sta m0Off
        lda ShotRow
        lsr
        bcs _no                 ; (odd: never)
        lda ShotRow
        cmp #2
        bcc _no
        cmp #$8b
        bcs _no
        inc m0Seen
        jsr EnamClock
        sta m0On
        lda ShotRow
        sec
        sbc #2
        cmp #2
        bcc _no                 ; (no write before the field ends: m0Off 160)
        jsr EnamClock
        bpl +
        lda #0
+       sta m0Off
_no     rts

; M0Colours: the colours (COLUP0) of the shot's lines Y = $9A, $9A - 1, $9A - 2 (for Render:
; from what the tick's walk found)
M0Colours:
        ldx #2
-       txa
        clc
        adc ShotRow
        sec
        sbc #2
        jsr ColAt
        sta m0Col,x
        dex
        bpl -
        rts

; EnamClock: Y = A (a B-type line): the clock of its ENAM0 write
EnamClock:
        sta tmp3
        tay                     ; R2? (the line after an R1 line)
        lda R1Flag+1,y
        beq +
        lda #16
        rts
+       lda lzAct               ; L2 after an enemy row?
        beq +
        ldy lzY
        dey
        cpy tmp3
        bne +
        lda #256 - 50
        rts
+       lda #25
        rts

; ColAt: A = Y: COLUP0 on that line. A row shown: its colour; R1, R2 and the laser's lines
; without an enemy row keep the colour of the line before (line 83: $C2, the scanner's); the
; others $FF.
ColAt:  sta tmp3
        ldy nD                  ; a row shown?
-       dey
        bmi _notShown
        lda DTop,y
        cmp tmp3
        bcc -
        lda tmp3
        cmp DBot,y
        bcc -
        lda DPg,y
        sta ptrB+1
        lda DCLo,y
        sta ptrB
        ldy tmp3
        lda (ptrB),y
        rts
_notShown
        lda tmp3                ; the line before's colour?
        cmp #$8c
        bcc +
        lda #$c2
        rts
+       tay                     ; R1, R2
        lda R1Flag,y
        ora R1Flag+1,y
        bne _before
        lda lzOn                ; the laser's lines (no row: else shown above)
        beq _ff
        lda tmp3
        cmp lzY
        beq _before
        clc
        adc #1
        cmp lzY
        beq _before
_ff     lda #$ff
        rts
_before lda tmp3
        clc
        adc #1
        jmp ColAt

; The game's writes into its scanner rows (XScanner: the 2600 writes them at $F04F-$F078, its
; only writes there are these): made, and the row marked if the byte changed (ScDirty, a bit per
; row) for Render. The flags as the STA left them.
ScW4D:  php
        cmp XScanner-2,x
        beq ScSame
        sta XScanner-2,x
        pha
        lda ScRowBit-2,x
        jmp ScW
ScW4E:  php
        cmp XScanner-1,x
        beq ScSame
        sta XScanner-1,x
        pha
        lda ScRowBit-1,x
        jmp ScW
ScW4F:  php
        cmp XScanner,x
        beq ScSame
        sta XScanner,x
        pha
        lda ScRowBit,x
ScW     ora ScDirty
        sta ScDirty
        pla
ScSame  plp
        rts
ScRowBit:   .for i = 0, i < 42, i += 1      ; a scanner byte (7 * column + row) -> its row's bit
            .byte 1 << (i % 7)
            .next

; Mod160: A (0-255, from a sum that may have gone below 0 by up to 96) mod 160
; (from 160-223: over the end; 224-255: below 0)
Mod160: cmp #160
        bcc +
        cmp #224
        bcs _neg
        sbc #160 - 1            ; (carry clear)
        rts
_neg    adc #160 - 1            ; (carry set)
+       rts

Times15:    .byte 0, 0, 30, 0, 60, 0, 90
Fine2:      .char 0, 2, 4, 6, 8, 10, 12, 14, -16, -14, -12, -10, -8, -6, -4, -2
