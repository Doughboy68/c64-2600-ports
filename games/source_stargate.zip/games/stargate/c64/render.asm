; ================================================================= render
; Draws the frame the last tick left (FieldHook's capture, BandHook's bands, and the 2600 RAM
; as the kernel left it) into the buffer not being shown, and stages its sprites and raster
; schedule; the frame end's interrupt shows it. The layout follows tools/model.js.
;
; Bitmap colours: "01" (screen RAM high nibble) the bands with an even index and the
; scanner's walls; "10" (low nibble) the bands with an odd index and the field (stars,
; mountains, laser: the ship's colour); "11" (colour RAM) the scanner's dots.

Render:
        lda curBuf              ; draw into the buffer not shown
        eor #1
        sta rb
        tax
        lda BmpHiTab,x
        sta bmpHi
        lda SprHiTab,x
        sta sprHi
        jsr SetErList
        lda CapKind
        cmp #KFIELD
        beq _field
        cmp #KBLANK
        beq _blank
        jsr ClearScanner        ; title, wave end, idle: no scanner, no field (cleared before
        jsr ClearField          ; the bands, which may cover their lines)
        jsr ClearLayer
        jsr NoSprites
        jsr DrawBands
        lda CapKind
        cmp #KIDLE
        bne _sched
        jsr CombIdle
        jmp _sched
_blank  jsr CombField
        jsr DrawBands           ; no field this frame: the scanner still
        jsr DrawScanner
        jsr ClearField
        jsr ClearLayer
        jsr NoSprites
        jmp _sched
_field  jsr CombField
        jsr DrawBands
        jsr DrawScanner
        jsr DrawStars
        jsr DrawLaser
        jsr DrawSprites
_sched  ldx rb                  ; (the field's list: its count kept)
        lda ern
        sta ErN,x
        lda FrameCount          ; (testing aid: the kind of tick it shows)
        and #1
        sta BufPar,x
        jsr Schedule
        lda #1
        sta pending
        rts

; CombIdle: (idle, the background colour on the whole screen) the comb's cells 0-1 of lines
; 82-222 cleared (no HMOVE there in idle frames: the background shows), once; CombField: lines
; 82-83's comb cells "01" (black) again for the field (lines 84-222: the layer, BgStars)
CombIdle:
        ldx rb
        lda CombOk,x
        beq _out
        lda #0
        sta CombOk,x
        sta CombFill,x
        lda #82
        sta v0
-       ldx v0
        lda LineLo,x
        sta ptrA
        lda LineHi,x
        clc
        adc bmpHi
        sta ptrA+1
        lda #0
        tay
        sta (ptrA),y
        ldy #8
        sta (ptrA),y
        inc v0
        lda v0
        cmp #223
        bne -
_out    rts
CombField:
        ldx rb
        lda CombOk,x
        bne _out
        lda #1
        sta CombOk,x
        lda #82
        sta v0
-       ldx v0
        lda LineLo,x
        sta ptrA
        lda LineHi,x
        clc
        adc bmpHi
        sta ptrA+1
        lda #$55
        ldy #0
        sta (ptrA),y
        ldy #8
        sta (ptrA),y
        inc v0
        lda v0
        cmp #84
        bne -
_out    rts

; ------------------------------------------------------------ bands
; Each band BandHook recorded: BandRows + 1 lines from BandLine, six bytes a line (pointers
; BandPtrs, row y = rows - 1 at the top): 48 pixels from pixel 55 (players 0 and 1, three copies
; each), drawn as cells 13-26 (pixels 52-107). Each buffer remembers its bands: a band drawn
; there before in the same version (BandVer) isn't drawn again (its colour may change), and
; when no band changed at all (BandGen) there's nothing to do;
; when the bands' lines change, the old bands' lines are cleared first.
DrawBands:
        ldx rb                  ; nothing changed since this buffer's were drawn?
        lda BandGen
        cmp BufGen,x
        bne +
        rts
+       sta BufGen,x
        lda BufBandN,x          ; the same lines as this buffer's bands?
        cmp BandN
        bne _layout
        lda BandBase,x
        tay
        ldx #0
-       cpx BandN
        beq _same
        lda BandLine,x
        cmp BufBandL,y
        bne _layout
        lda BandRows,x
        cmp BufBandR,y
        bne _layout
        inx
        iny
        bne -
_layout ldx rb                  ; no: clear the old bands' lines, forget their graphics
        lda BufBandN,x
        sta tmp4
        lda BandBase,x
        tax
-       lda tmp4
        beq +
        lda BufBandL,x
        sta v0
        lda BufBandR,x
        sta v1
        inc v1
        stx v2
        jsr ClearBandLines
        ldx v2
        lda #$ff                ; (colour and graphics unknown)
        sta BufBandC,x
        inx
        dec tmp4
        jmp -
+       ldx rb
        lda BandN
        sta BufBandN,x
        lda BandBase,x
        tay
        ldx #0
-       cpx BandN
        beq _same
        lda BandLine,x
        sta BufBandL,y
        lda BandRows,x
        sta BufBandR,y
        lda #$ff
        sta BufBandC,y
        lda #0                  ; (graphics: none drawn)
        sta BufBandG,y
        inx
        iny
        bne -
_same   ldx #0                  ; each band: its colour, its graphics
_band   cpx BandN
        beq _done
        stx v3
        jsr DrawBand
        ldx v3
        inx
        jmp _band
_done   rts

; v0 = first line, v1 = lines: cells 13-26 cleared
ClearBandLines:
-       ldx v0
        jsr LineAddr
        lda #0
        .for c = 0, c < 14, c += 1
        ldy #8 * c
        sta (ptrA),y
        .next
        inc v0
        dec v1
        bne -
        rts

; X = a line (37-236): ptrA = its byte in cell 13 of the buffer's bitmap
LineAddr:
        lda LineLo,x
        clc
        adc #<(13 * 8)
        sta ptrA
        lda LineHi,x
        adc bmpHi
        sta ptrA+1
        rts

; Band v3: its colour in its cells (if changed), its lines (if its graphics changed)
DrawBand:
        ldx v3
        txa                     ; its entry in the buffer's list
        ldy rb
        clc
        adc BandBase,y
        sta v2
        lda BandCol,x           ; the colour: even bands "01", odd "10"
        lsr
        tay
        lda ColorMap,y
        ldy v2
        cmp BufBandC,y
        beq _graph
        sta BufBandC,y
        sta tmp4
        txa
        and #1
        sta v1
        lda BandLine,x          ; each cell row the band touches
        sec
        sbc #FIRSTLINE
        lsr
        lsr
        lsr
        sta tmp
        lda BandLine,x
        clc
        adc BandRows,x
        sec
        sbc #FIRSTLINE
        lsr
        lsr
        lsr
        sta tmp2
-       ldx tmp
        lda v1
        jsr CellColour
        lda tmp
        cmp tmp2
        inc tmp
        bcc -
_graph  ldx v3                  ; the graphics: the version drawn there?
        ldy v2
        lda BufBandG,y
        beq _draw
        lda BandVer,x
        cmp BufBandV,y
        bne _draw
        rts
_draw   lda #1
        sta BufBandG,y
        lda BandVer,x
        sta BufBandV,y
        lda BandTimes12,x
        tax
        ldy #0
-       lda BandPtrs,x
        sta BPtr,y
        inx
        iny
        cpy #12
        bne -
        ldx v3
        lda BandRows,x
        sta v1                  ; row y (the top line: rows - 1)
        lda BandLine,x
        sta v0                  ; line
        txa
        and #1
        sta v2                  ; colour code
_line   ldy v1
        .for i = 0, i < 6, i += 1
        lda BPtr+2*i
        sta ptrB
        lda BPtr+2*i+1
        sta ptrB+1
        lda (ptrB),y
        sta BLine+i
        .next
        ldx v0
        jsr LineAddr
        lda v2
        bne +
        jsr Line48a
        jmp ++
+       jsr Line48b
+       inc v0
        dec v1
        bpl _line
        rts

; Line48a/b: the six bytes in BLine as 48 pixels from pixel 55 on the line at ptrA (cell 13),
; "01" / "10" pixels; cell 26 cleared
Line48  .macro mid, rgt, one
        lda #0
        bit BLine
        bpl +
        lda #\one
+       ldy #0
        sta (ptrA),y
        ldx BLine
        .for i = 0, i < 6, i += 1
        lda \mid,x
        ldy #8 + 16 * i
        sta (ptrA),y
        lda \rgt,x
        .if i < 5
        ldx BLine+i+1
        bpl +
        ora #\one
+
        .endif
        ldy #16 + 16 * i
        sta (ptrA),y
        .next
        lda #0
        ldy #104
        sta (ptrA),y
        rts
        .endm
Line48a .Line48 Mid01, Rgt01, $01
Line48b .Line48 Mid10, Rgt10, $02

; CellColour: cell row X (0-24), cells 13-26 get colour tmp4 in the nibble for code A
; (0: "01", the high nibble; 1: "10", the low one)
CellColour:
        sta tmp3
        lda Row40Lo,x
        clc
        adc #13
        sta ptrB
        lda Row40Hi,x
        adc #0
        ldx rb
        adc ScrHiTab,x
        sta ptrB+1
        lda tmp3
        bne _lo
        lda tmp4
        asl
        asl
        asl
        asl
        sta tmp3
        ldy #13
-       lda (ptrB),y
        and #$0f
        ora tmp3
        sta (ptrB),y
        dey
        bpl -
        rts
_lo     ldy #13
-       lda (ptrB),y
        and #$f0
        ora tmp4
        sta (ptrB),y
        dey
        bpl -
        rts

; ------------------------------------------------------------ the scanner
; Lines 62-78: the walls (playfield, reflected: pixels 52-55 and 104-107 on lines 63-77, the
; middle 76-83 too on line 77, the floor 52-107 on line 78), the six columns (players, 48
; pixels from 55, seven rows of two lines from the SuperChip RAM, "11"), the ship's marker
; (the ball, two pixels, rows from $F8; it stays on to clock 94 of line 77). Walls and marker
; "01" (the playfield has priority over the players here). Each buffer remembers what its
; rows show: only rows that changed are drawn again.
DrawScanner:
        ldx rb
        lda ScanOk,x
        beq +
        jmp _rows
+       lda #1                  ; first time here: colours, the floor, every row
        sta ScanOk,x
        lda #$08 >> 1           ; walls grey ("01") in cell rows 3-5
        tay
        lda ColorMap,y
        sta tmp4
        ldx #3
        lda #0
        jsr CellColour
        ldx #4
        lda #0
        jsr CellColour
        ldx #5
        lda #0
        jsr CellColour
        ldx #77                 ; line 77: walls, the middle (the marker: row 0)
        jsr LineAddr
        jsr Walls77
        ldx #78                 ; line 78: the floor
        jsr LineAddr
        lda #$55
        .for c = 0, c < 14, c += 1
        ldy #8 * c
        sta (ptrA),y
        .next
        lda #63                 ; lines 63-76: the walls (cells 13 and 26: the playfield has
        sta v0                  ; priority, they never change)
-       ldx v0
        jsr LineAddr
        lda #$55
        ldy #0
        sta (ptrA),y
        ldy #13 * 8
        sta (ptrA),y
        inc v0
        lda v0
        cmp #77
        bne -
        ldx rb                  ; every row differs
        lda ScanBase,x
        tax
        lda #$ff
        ldy #ScanRec - 1
-       sta ScanBuf,x
        inx
        dey
        bpl -
_rows   ; the ship's marker: x = 83 - fine motion of HMBL = $C0 - ShipX - (no carry)
        lda DigitC
        lsr                     ; carry as the score's last CMP left it
        lda #$c0
        sbc PosCode
        lsr
        lsr
        lsr
        lsr
        tay
        lda #83
        sec
        sbc Fine1,y
        sta ScBallX
        ldx rb                  ; the rows to look at: those the game wrote since this buffer's
        lda ScDirtyB,x          ; were drawn, all if the marker's rows may differ ($F8 changed)
        sta scMask
        lda #0
        sta ScDirtyB,x
        lda $f8
        cmp ScanF8,x
        beq +
        sta ScanF8,x
        lda #$7f
        sta scMask
+       lda ScanBase,x
        sta v2                  ; this buffer's record: 7 rows x 8 (6 bytes, marker), marker x
        tax
        lda ScBallX
        cmp ScanBuf+56,x
        beq _xSame
        sta ScanBuf+56,x
        ldy #7                  ; (a new x: every row showing the marker differs)
-       lda ScanBuf+6,x
        beq _mOff
        lda #$fe
        sta ScanBuf+6,x
_mOff   txa
        clc
        adc #8
        tax
        dey
        bne -
        lda #$7f
        sta scMask
_xSame  lda #6
        sta v0                  ; row y (6: lines 63-64, ... 0: 75-76)
        asl scMask              ; (shifted out a row at a time: row 6 first)
_row    asl scMask
        bcs _rdo
        beq _rnone
        jmp _next
_rnone  rts                     ; (no rows left)
_rdo    lda v0                  ; its record
        asl
        asl
        asl
        adc v2                  ; (carry clear)
        sta v3
        tax
        ldy v0
        lda ($f8),y             ; the marker as it was: column by column
        and #2
        sta v1
        cmp ScanBuf+6,x
        beq _cols
        sta ScanBuf+6,x         ; else the whole row
        .for k = 0, k < 6, k += 1
        lda XScanner+7*k,y
        sta ScanBuf+k,x
        sta BLine+k
        .next
        lda v0                  ; its two lines: 63 + 2 * (6 - y)
        eor #7
        asl
        adc #61                 ; ((7 - y) * 2 + 61 = 63 + 2 * (6 - y); carry clear)
        tax
        jsr ScanRow
        lda v0                  ; row 0: line 77 too (the marker up to clock 94)
        bne _n77
        ldx #77
        jsr LineAddr
        jsr Walls77
        lda v1
        beq _n77
        lda ScBallX
        cmp #94
        bcs _n77
        ldx #2
        jsr PlotScan
_n77    jmp _next
_cols   .for k = 0, k < 6, k += 1
        lda XScanner+7*k,y
        cmp ScanBuf+k,x
        beq +
        sta ScanBuf+k,x
        ldy #k
        jsr ScanByte
        ldy v0
        ldx v3
+
        .next
_next   dec v0
        bmi +
        jmp _row
+       rts

; ScanByte: column Y (k) of scanner row v0 changed (its record at X, updated): the cells it
; touches on the row's two lines: 2k - 1 (column k - 1's last three pixels, column k's first),
; 2k, 2k + 1 (its own, column k + 1's first); the marker (v1) over them again
ScanByte:
        sty scK
        stx tmp4
        lda v0                  ; the row's first line, ptrA
        eor #7
        asl
        adc #61                 ; (carry clear)
        tax
        jsr LineAddr
        lda scK
        asl
        asl
        asl
        asl
        sta scOfs               ; 16k: cell 2k - 1's offset (cell c at 8 * (c - 13): 14 + 2k - 1)
        lda tmp4
        clc
        adc scK
        tax                     ; X: column k's byte in the record
        lda scK
        beq _mid
        ldy ScanBuf-1,x         ; cell 2k - 1
        lda Rgt11,y
        ldy ScanBuf,x
        bpl +
        ora #$03
+       ldy scOfs
        sta (ptrA),y
        iny
        sta (ptrA),y
_mid    ldy ScanBuf,x           ; cell 2k
        lda Rgt11,y             ; (cell 2k + 1: the last three pixels, column k + 1's first)
        sta tmp
        lda scK
        cmp #5
        beq +
        lda ScanBuf+1,x
        bpl +
        lda tmp
        ora #$03
        sta tmp
+       lda Mid11,y
        ldy scOfs
        iny
        iny
        iny
        iny
        iny
        iny
        iny
        iny
        sta (ptrA),y
        iny
        sta (ptrA),y
        tya
        clc
        adc #7
        tay
        lda tmp
        sta (ptrA),y
        iny
        sta (ptrA),y
        lda v1
        bne ScanMark
        rts

; ScanMark: the ship's marker ("01", pixels ScBallX and + 1) on the scanner row's two lines at
; ptrA (under the walls, cells 13 and 26, it doesn't show)
ScanMark:
        lda ScBallX
        jsr _px
        lda ScBallX
        clc
        adc #1
_px     sec                     ; pixel A: cells 14-25 (pixels 56-103)
        sbc #56
        cmp #48
        bcs _out
        tay
        and #3
        tax
        tya
        and #$fc                ; offset 8 * ((A - 56) / 4 + 1)
        asl
        adc #8                  ; (carry clear)
        tay
        lda (ptrA),y
        and NotPix,x
        ora Pix01,x
        sta (ptrA),y
        iny
        sta (ptrA),y
_out    rts

; ScanRow: a scanner row's two lines, X = the first: cells 14-25 from the columns (BLine,
; "11"), the marker (v1: "01", two pixels from ScBallX; under the walls in cells 13 and 26
; it doesn't show), each byte stored on both lines (a row's lines share their cell row)
ScanRow:
        jsr LineAddr
        .for i = 0, i < 6, i += 1
        ldx BLine+i
        lda Mid11,x
        sta SCells+2*i
        lda Rgt11,x
        .if i < 5
        ldx BLine+i+1
        bpl +
        ora #$03
+
        .endif
        sta SCells+2*i+1
        .next
        lda v1
        beq _store
        lda ScBallX
        jsr _mark
        lda ScBallX
        clc
        adc #1
        jsr _mark
_store  .for c = 0, c < 12, c += 1
        lda SCells+c
        ldy #8 * (c + 1)
        sta (ptrA),y
        iny
        sta (ptrA),y
        .next
        rts
_mark   sec                     ; pixel A: cell (A - 52) / 4 = 14-25 -> SCells 0-11
        sbc #56
        cmp #48
        bcs +
        tay
        and #3
        tax
        tya
        lsr
        lsr
        tay
        lda SCells,y
        and NotPix,x
        ora Pix01,x
        sta SCells,y
+       rts

; line 77 at ptrA: walls and the middle (pixels 76-83: cells 19-20), the rest clear
Walls77:
        .for c = 0, c < 14, c += 1
        .if c == 0 || c == 6 || c == 7 || c == 13
        lda #$55
        .else
        lda #0
        .endif
        ldy #8 * c
        sta (ptrA),y
        .next
        rts

; PlotScan: A = pixel, X = width: "01" pixels on the line in ptrA (cell 13 base)
PlotScan:
        sec
        sbc #52
        sta tmp2
-       lda tmp2
        and #3
        sta tmp3
        lda tmp2
        lsr
        lsr
        asl
        asl
        asl
        tay
        stx tmp
        ldx tmp3
        lda (ptrA),y
        and NotPix,x
        ora Pix01,x
        sta (ptrA),y
        ldx tmp
        inc tmp2
        dex
        bne -
        rts

ClearScanner:
        ldx rb
        lda ScanOk,x
        bne +
        rts
+       lda #0
        sta ScanOk,x
        lda #62
        sta v0
        lda #17
        sta v1
        jmp ClearBandLines

; ------------------------------------------------------------ the field
; Stars and mountains (missile 1 and the ball: each row's enable and size from ($9B),y,
; R1 lines keeping the line before's enable; missile 1 moves 3 pixels left a line, the ball 3
; right) and the laser (playfield, line L1) are "11" pixels: the colour RAM holds the field's
; colour (the ship's, $F0CA) in cell rows 5-24. Each buffer keeps a list of the bitmap bytes
; it wrote, cleared before the next frame is drawn there. Line 223 (after the field's last
; line, Y = 1) shows what line 222 did, without the HMOVE comb.
DrawStars:
        jsr ClearField
        lda FieldBg             ; a background (not black) on the field: BgStars
        lsr
        tay
        lda ColorMap,y
        sta BgNow
        lda XShipCol            ; the field's colour: in colour RAM (both buffers; when it changes),
        lsr                     ; but black (inviso blinks it) by switching lines 84-223 into an
        tay                     ; invalid VIC mode (bitmap + ECM: black graphics, sprites as ever)
        lda ColorMap,y
        sta FieldNow
        ldx BgNow
        beq +
        jmp BgStars
+       tax
        beq +
        cmp FieldCol
        beq +
        sta FieldCol
        jsr FieldColour
+       lda StarPtr             ; the rows with stars or mountains (when $9B changes)
        cmp StarFor
        beq +
        jsr StarRows
+       lda BLX83               ; the layer: D = BLX83 - M1X83 (mod 160) and the pattern
        sec
        sbc M1X83
        bcs +
        adc #160
+       sta LayDNow
        cmp LayD
        bne +
        lda StarPtr
        cmp LayFor
        beq ++
+       jsr NewLayer
+       lda LayOk
        bne +
        jmp SlowStars
+       jmp DrawLayer
; BgStars: the field with a background (not black: COLUBK, the screen flashes now and then).
; The comb (pixels 0-7 of lines 84-222) must stay black, but the fine scroll would show the
; background left of the bitmap: so no fine scroll, no layer (the stars the slow way), the comb's
; cells "01" (black: InitComb), the field's colour in colour RAM even when black (the invalid
; mode would hide the background too)
BgStars:
        lda FieldNow
        cmp FieldCol
        beq +
        sta FieldCol
        jsr FieldColour
+       jsr ClearLayer
        ldx rb
        lda CombFill,x
        bne +
        inc CombFill,x
        lda #84                 ; (once, till the layer writes there again)
        sta v0
-       ldx v0
        lda LineLo,x
        sta ptrA
        lda LineHi,x
        clc
        adc bmpHi
        sta ptrA+1
        lda #$55
        ldy #0
        sta (ptrA),y
        ldy #8
        sta (ptrA),y
        inc v0
        lda v0
        cmp #223
        bne -
+       lda StarPtr
        cmp StarFor
        beq +
        jsr StarRows
+       jmp SlowStars

; the stars' / mountains' line of Y = cy: missile 1 at M1X83 - 3 * (line - 83), the ball at
; BLX83 + 3 * (line - 83) (line 223: line 222's), both "size" wide (from the row's byte; an R1
; line's from the row before)
StarLine:
        ldy cy
        bne +
        iny                     ; (line 223: Y = 1's)
+       sty tmp4
        tya
        jsr IsR1
        ldy tmp4
        bcc +
        iny
+       lda (StarPtr),y
        lsr
        lsr
        lsr
        lsr
        and #3
        tay
        lda Width,y
        sta v2
        lda cy                  ; k = line - 83 = 140 - Y (Y = 0: 139, line 222's)
        bne +
        lda #1
+       eor #$ff
        sec
        adc #140
        tay
        sty tmp4                ; (k)
        lda #223                ; the line (ptrB), its shift (the fine scroll, but on 223)
        sec
        sbc cy
        tax
        lda LineLo,x
        sta ptrB
        lda LineHi,x
        clc
        adc bmpHi
        sta ptrB+1
        lda #0
        ldx cy
        beq +
        lda fScr
+       sta spFs
        lda M1X83               ; missile 1
        sec
        sbc Times3Mod,y
        bcs +
        adc #160
+       jsr SpanQ
        ldy tmp4                ; the ball
        lda BLX83
        clc
        adc Times3Mod,y
        bcs +
        cmp #160
        bcc SpanQ
+       sbc #160

; SpanQ: as Span, quicker when the span doesn't wrap or touch the comb and is 1 or 4 pixels
; wide (from tables): A = first pixel, v2 = width, cy = Y, ptrB = its line, spFs = its shift
SpanQ:  tay
        clc
        adc v2
        cmp #161
        bcs _slow               ; (wraps)
        lda cy
        beq +
        cpy #8
        bcc _slow               ; (the comb)
+       tya
        sec
        sbc spFs
        tay                     ; (the bitmap's pixel)
        lda ColOfsLo,y
        clc
        adc ptrB
        sta ptrC
        lda ColOfsHi,y
        adc ptrB+1
        sta ptrC+1
        lda v2
        cmp #4
        beq _w4
        cmp #1
        bne _slow2
        tya
        and #3
        tax
        lda Pix11,x
        ldy #0
        ora (ptrC),y
        sta (ptrC),y
        jmp Record
_w4     lda W4B,y
        sta tmp2
        lda W4A,y
        ldy #0
        ora (ptrC),y
        sta (ptrC),y
        jsr Record
        lda tmp2
        beq _done
        ldy #8
        ora (ptrC),y
        sta (ptrC),y
        lda ptrC
        clc
        adc #8
        sta ptrC
        bcc +
        inc ptrC+1
+       jmp Record
_done   rts
_slow2  tya                     ; (back to the screen's pixel)
        clc
        adc spFs
        tay
_slow   tya
        jmp Span

; Span: A = first pixel, v2 = width (1-8), cy = Y (0: line 223): "11" pixels, a byte or two
; at a time, recorded for clearing. Pixels past 159 wrap to 0 on; 0-7 are the comb (but on 223).
Span:   sta v0
        lda #223                ; the line: 223 - Y
        sec
        sbc cy
        tax
        lda LineLo,x
        sta ptrB
        lda LineHi,x
        clc
        adc bmpHi
        sta ptrB+1
        lda v0                  ; end = first + width
        clc
        adc v2
        cmp #161
        bcc _one
        sbc #160                ; wraps: [first, 160) and [0, end - 160)
        sta spanEnd
        lda #160
        jsr _run
        lda #0
        sta v0
        lda spanEnd
_one
_run    sta v1                  ; [v0, v1)
        lda cy
        beq +
        lda v0                  ; (the comb)
        cmp #8
        bcs +
        lda #8
        sta v0
+       lda v0
        cmp v1
        bcs _none
        lda cy                  ; lines 84-222: bitmap pixel = screen pixel - fine scroll
        beq +
        lda v0
        sec
        sbc fScr
        sta v0
        lda v1
        sec
        sbc fScr
        sta v1
+       lda v0
        tay                     ; the first cell
        lda ColOfsLo,y
        clc
        adc ptrB
        sta ptrC
        lda ColOfsHi,y
        adc ptrB+1
        sta ptrC+1
        lda v0
        and #3
        tax
        lda FromPix,x           ; pixels from v0 to the cell's end
        sta tmp2
        lda v1                  ; the last pixel's cell the same?
        sec
        sbc #1
        eor v0
        and #$fc
        bne _two
        lda v1
        sbc #1
        and #3
        tax
        lda ToPix,x
        and tmp2
        ldy #0
        ora (ptrC),y
        sta (ptrC),y
        jmp Record
_two    lda tmp2                ; two cells (a width of 8 could take three: not used here)
        ldy #0
        ora (ptrC),y
        sta (ptrC),y
        jsr Record
        lda v1
        sec
        sbc #1
        and #3
        tax
        lda ToPix,x
        ldy #8
        ora (ptrC),y
        sta (ptrC),y
        lda ptrC
        clc
        adc #8
        sta ptrC
        bcc +
        inc ptrC+1
+       jmp Record
_none   rts
FromPix:    .byte $ff, $3f, $0f, $03    ; "11" pixels from pixel n of a cell to its end,
ToPix:      .byte $c0, $f0, $fc, $ff    ; ... from its start to pixel n

; Record: the byte at ptrC goes on this buffer's list to clear (erLoP / erHiP, ern: set by
; SetErList for the buffer being drawn). Keeps X.
Record: ldy ern
        cpy #ERMAX
        bcs +
        lda ptrC
        sta (erLoP),y
        lda ptrC+1
        sta (erHiP),y
        inc ern
+       rts

; SetErList: this buffer's list: pointers, count
SetErList:
        ldx rb
        lda ErPage,x
        sta erLoP+1
        clc
        adc #1
        sta erHiP+1
        lda #0
        sta erLoP
        sta erHiP
        lda ErN,x
        sta ern
        rts
ErPage:     .byte >ErLo0, >ErLo1

; ClearField: the bytes this buffer's list holds, cleared
ClearField:
        jsr ClearStale
        jsr ClearLaser
        ldy ern
        beq +
        ldx #0
-       dey
        lda (erLoP),y
        sta ptrD
        lda (erHiP),y
        sta ptrD+1
        txa
        sta (ptrD,x)
        tya
        bne -
        sty ern
+       rts

; LzGroup: the playfield cells first .. first + n - 1, left-aligned in A (Z: from loading it)
LzGroup .macro first, n
        beq _off
        cmp #($ff << (8 - \n)) & $ff
        beq _on
        ldy #\first
_cell   asl
        bcc _c0
        bit lzRun               ; on: a run starts (if none is open)
        bpl _cn
        sty lzRun
        jmp _cn
_c0     bit lzRun               ; off: the open run ends
        bmi _cn
        pha
        sty lzCell
        jsr LzClose
        ldy lzCell
        pla
_cn     iny
        cpy #\first + \n
        bne _cell
        beq _done
_on     bit lzRun
        bpl _done
        lda #\first
        sta lzRun
        bpl _done
_off    bit lzRun
        bmi _done
        ldy #\first
        jsr LzClose
_done
        .endm

; DrawLaser: the laser line (L1, Y = lzY): the playfield's cells (4 pixels each; PF0 bits 4-7,
; PF1 bits 7-0, PF2 bits 0-7, left from $DA-$DC, right from $DD-$DF), cells 0-1 in the comb;
; with an enemy row on L2 PF2 is cleared at clock 151 (pixels 151-159 off). The cells are
; taken a playfield register at a time (one all on or all off at once) as runs, each drawn
; shifted by the fine scroll over the layer (the line is marked to get the layer back) and
; kept as a span to clear (LzSpan).
DrawLaser:
        lda lzOn
        bne +
        rts
+       lda #223
        sec
        sbc lzY
        pha
        jsr MarkDirty
        pla
        tax
        lda LineLo,x
        sta ptrB
        lda LineHi,x
        clc
        adc bmpHi
        sta ptrB+1
        lda #$ff
        sta lzRun               ; (no run open)
        ldx LaserPF             ; cells 0-3: PF0 bits 4-7 (left to right: reversed)
        lda Reverse,x
        asl
        asl
        asl
        asl
        .LzGroup 0, 4
        lda LaserPF+1           ; cells 4-11: PF1 bits 7-0
        .LzGroup 4, 8
        ldx LaserPF+2           ; cells 12-19: PF2 bits 0-7
        lda Reverse,x
        .LzGroup 12, 8
        ldx LaserPF+3
        lda Reverse,x
        asl
        asl
        asl
        asl
        .LzGroup 20, 4
        lda LaserPF+4
        .LzGroup 24, 8
        ldx LaserPF+5
        lda Reverse,x
        .LzGroup 32, 8
        bit lzRun               ; a run to the end
        bmi +
        ldy #40
        jmp LzClose
+       rts

; LzClose: the run of cells lzRun .. Y - 1 (from cell 2: the comb) drawn: screen pixels
; 4 * first .. 4 * end - 1 (with an enemy row on L2: to 150 at most), bitmap pixels lzX0 ..
; lzX1 - 1 (less the fine scroll), "11" ORed in (whole bytes inside the run just stored)
LzClose:
        lda lzRun
        ldx #$ff
        stx lzRun
        cmp #2
        bcs +
        lda #2
+       asl
        asl
        sec
        sbc fScr
        sta lzX0
        tya
        asl
        asl
        ldx lzAct
        beq +
        cmp #151
        bcc +
        lda #151
+       sec
        sbc fScr
        sta lzX1
        cmp lzX0
        beq _none
        bcs +
_none   rts
+       ldy lzX0                ; the first byte
        lda ColOfsLo,y
        clc
        adc ptrB
        sta ptrC
        lda ColOfsHi,y
        adc ptrB+1
        sta ptrC+1
        tya
        and #3
        tax
        lda FromPix,x
        sta tmp3                ; its pixels
        lda lzX1                ; the last byte's pixels
        sec
        sbc #1
        tay
        and #3
        tax
        lda ToPix,x
        sta tmp4
        tya                     ; bytes after the first: (x1 - 1) / 4 - x0 / 4
        lsr
        lsr
        sta tmp2
        lda lzX0
        lsr
        lsr
        eor #$ff
        sec
        adc tmp2
        sta tmp2
        ldx rb                  ; kept to clear: the first byte's address, the bytes
        ldy LzSpN,x
        cpy #LZMAX
        bcs +
        inc LzSpN,x
        txa
        asl
        asl                     ; (LZMAX = 4 per buffer)
        adc LzSpN,x
        tay
        lda ptrC
        sta LzSpLo-1,y
        lda ptrC+1
        sta LzSpHi-1,y
        lda tmp2
        clc
        adc #1
        sta LzSpB-1,y
+       ldy #0
        ldx tmp2
        bne _many
        lda tmp3                ; one byte
        and tmp4
        ora (ptrC),y
        sta (ptrC),y
        rts
_many   lda tmp3                ; the first byte
        ora (ptrC),y
        sta (ptrC),y
        txa                     ; the last: 8 * tmp2 on (ptrD)
        asl
        asl
        asl
        php
        clc
        adc ptrC
        sta ptrD
        lda ptrC+1
        adc #0
        plp
        adc #0
        sta ptrD+1
        lda tmp4
        ora (ptrD),y
        sta (ptrD),y
        dex                     ; those between: all on
        beq _done
        lda ptrC
        clc
        adc #8
        sta ptrC
        bcc +
        inc ptrC+1
+       lda #$ff
        jmp FillRun
_done   rts

; ClearLaser: the laser's runs drawn in this buffer, cleared (their line's layer comes back)
ClearLaser:
        ldx rb
        lda LzSpN,x
        beq _out
        sta tmp
        lda #0
        sta LzSpN,x
        txa
        asl
        asl
        tax
_span   lda LzSpLo,x
        sta ptrC
        lda LzSpHi,x
        sta ptrC+1
        stx tmp2
        lda LzSpB,x
        tax
        lda #0
        jsr FillRun
        ldx tmp2
        inx
        dec tmp
        bne _span
_out    rts

; FillRun: X bytes (1-40) 8 apart from ptrC (cells on a bitmap line) = A: unrolled, entered
; at the right place (ptrE = ptrC + 256 for the bytes from 32 on)
FillRun:
        pha
        lda ptrC
        sta ptrE
        ldy ptrC+1
        iny
        sty ptrE+1
        txa                     ; FillTop + 4 * (40 - X)
        eor #$ff
        sec
        adc #40
        asl
        asl
        clc
        adc #<FillTop
        sta frVec
        lda #>FillTop
        adc #0
        sta frVec+1
        pla
        jmp (frVec)
FillTop:
        .for k = 39, k >= 0, k -= 1
        ldy #<(8 * k)
        .if k >= 32
        sta (ptrE),y
        .else
        sta (ptrC),y
        .endif
        .next
        rts

CellPix:    .for c = 0, c < 40, c += 1
            .byte 4 * c
            .next

; ------------------------------------------------------------ sprites
; Sprite 0: the shot; 1-6: the enemies (drawn slots, in turn); 7: the ship. Multicolour,
; one sprite pixel = one 2600 pixel.
NoSprites:
        ldx rb
        lda #0
        sta StEn,x
        rts

DrawSprites:
        lda #0
        sta v3                  ; enable bits
        sta tmp4                ; X MSBs
        ; ---- the ship (sprite 7): its 16 rows from ShipTop. Its image's key: the rows'
        ; address ($96 + ShipTop: ShipImage reads ($96),y from Y = ShipTop down), ShipTop
        ; itself near the edges (rows past the field cleared, line 223's row repeated), REFP1,
        ; the comb's clip
        ldx rb
        lda XShipCol
        lsr
        tay
        lda ColorMap,y
        ldy SprStage,x
        sta StCol+7,y
        lda #8
        ldy ShipX
        cpy #8
        bcs +
        tya
+       sta sClip
        lda ShipTop
        cmp #16
        bcc +
        cmp #$90
        bcs +
        lda #0
+       sta sEdge
        lda ShipTop
        clc
        adc ShipLo2
        sta sAddr
        lda ShipGfx+1
        adc #0
        sta sAddr+1
        ldy KeyOfs5,x           ; (5 bytes a buffer)
        lda sAddr
        cmp ShipKey,y
        bne _ship
        lda sAddr+1
        cmp ShipKey+1,y
        bne _ship
        lda sEdge
        cmp ShipKey+2,y
        bne _ship
        lda ShipRef
        cmp ShipKey+3,y
        bne _ship
        lda sClip
        cmp ShipKey+4,y
        beq _shipOk
_ship   lda sAddr
        sta ShipKey,y
        lda sAddr+1
        sta ShipKey+1,y
        lda sEdge
        sta ShipKey+2,y
        lda ShipRef
        sta ShipKey+3,y
        lda sClip
        sta ShipKey+4,y
        jsr ShipImage
_shipOk ldx rb
        lda SprStage,x
        ora #7
        tay
        lda ShipTop
        ldx ShipX
        jsr SprPlace
        ; ---- the enemies (sprites 1-6). An image's key: the slot's pointers, rows, REFP0,
        ; L2 quirk line, clip (x when left of 31: the comb, the quirk's split)
        lda #0
        sta v2
        ldy rb                  ; (this buffer's staged slots)
        lda SprStage,y
        sta kStage
_en     lda v2
        cmp nDX                 ; (flicker off: the hidden objects too)
        beq _enEnd
        cmp #6
        bne +
_enEnd  jmp _shot
+       tax
        lda DTop,x
        bne +
        jmp _enx
+       stx cD
        inx
        stx v1                  ; sprite number
        txa                     ; its slot in the keys (and colours, staged values)
        ora kStage
        sta kSlot
        tay
        ldx cD
        lda DX,x
        cmp #31
        bcc +
        lda #8
+       cpx nD                  ; (a hidden object: in its own colour only, a key of its own)
        bcc +
        ora #$80
+       sta eClipK
        cmp EKClip,y
        bne _new
        lda DGLo,x
        cmp EKG,y
        bne _new
        lda DTop,x
        cmp EKTop,y
        bne _new
        lda DCLo,x
        cmp EKC,y
        bne _new
        lda DPg,x
        cmp EKPg,y
        bne _new
        lda DBot,x
        cmp EKBot,y
        bne _new
        lda DRef,x
        cmp EKRef,y
        bne _new
        lda DQuirk,x
        cmp EKQ,y
        bne _new
        lda SprEc0,y            ; the same: its colours as kept with the image
        sta ec0
        lda SprEc1,y
        sta ec1
        lda SprEc2,y
        sta ec2
        jmp _enOk
_new    lda eClipK
        sta EKClip,y
        lda DGLo,x
        sta EKG,y
        lda DTop,x
        sta EKTop,y
        lda DCLo,x
        sta EKC,y
        lda DPg,x
        sta EKPg,y
        lda DBot,x
        sta EKBot,y
        lda DRef,x
        sta EKRef,y
        lda DQuirk,x
        sta EKQ,y
        tya                     ; the other buffer's image of this sprite has the same key (a
        eor #8                  ; skipped frame turned the flicker's turns round): copied
        tax
        .for k in [EKG, EKTop, EKC, EKBot, EKPg, EKRef, EKQ, EKClip]
        lda k,y
        cmp k,x
        bne _build
        .next
        jsr SprCopy
        jmp _built
_build  jsr EnemyBuild          ; its colours (up to three) and image
_built  ldy kSlot
        lda ec0
        sta SprEc0,y
        lda ec1
        sta SprEc1,y
        lda ec2
        sta SprEc2,y
_enOk   ldx cD                  ; (line 223: pixels past 159 wrap into view; every frame)
        lda DBot,x
        cmp #1
        bne +
        jsr Wrap223
+       ldx v1                  ; its colours: its own, the two shared ones (the schedule)
        lda ec1
        sta EnMcA-1,x
        lda ec2
        sta EnMcB-1,x
        lda ec0
        ldy kSlot
        sta StCol,y
        ldx cD                  ; placed (as SprPlace; Y = kSlot)
        lda DTop,x
        eor #$ff
        sec
        sbc #255 - (223 + LINE2RAS - 1)
        sta StY,y
        lda DX,x
        ldx v1
        asl
        bcs _hi
        adc #24
        sta StX,y
        bcc _lo
        bcs _msb
_hi     adc #24 - 1             ; (carry set)
        sta StX,y
_msb    lda BitTab,x
        ora tmp4
        sta tmp4
_lo     lda BitTab,x
        ora v3
        sta v3
_enx    inc v2
        jmp _en
_shot   jsr EffMc           ; the shared colours in effect after each enemy's R1
        ; ---- the shot (sprite 0): its visible lines; the first visible line's colour is the
        ; sprite's own, others match a shared colour in effect on their line if they can
        lda m0N
        bne +
        jmp _out
+       jsr M0Colours
        lda #0
        jsr SprPtr
        lda #$ff
        sta ec0
        ldx #0
        ldy #0
_sl     stx tmp
        sty v0
        lda #2                  ; line i's colour: m0Col[2 - i]
        sec
        sbc tmp
        tay
        lda m0Col,y
        lsr
        tay
        lda ColorMap,y
        sta qRow
        lda #0
        sta tmp2
        lda #2
        sta tmp3
        lda M0X
        cmp m0X0,x
        bcc _put
        cmp m0X1,x
        bcs _put
        lda #$80
        sta tmp2
        lda ec0
        cmp #$ff
        bne +
        lda qRow
        sta ec0
+       lda qRow
        cmp ec0
        beq _put
        lda m0Y,x               ; the shared colours on that line
        jsr McAt
        lda qRow
        cmp EffA,y
        bne +
        lda #1
        sta tmp3
        bne _put
+       cmp EffB,y
        bne _bmp
        lda #3
        sta tmp3
        bne _put
_bmp    ldx tmp                 ; neither: into the bitmap ("10", the cell's colour)
        jsr ShotBmp
        lda #0
        sta tmp2
_put    ldy v0
        lda tmp3
        sta lastC
        jsr RowC
        ldx tmp
        inx
        cpx m0N
        bne _sl
        lda m0Off               ; still on after the field (no write turned it off): line 223
        cmp #160                ; too (the comb isn't there)
        bne _sh223
        ldx m0N
        lda m0Y-1,x
        cmp #1
        bne _sh223
        lda #$80
        sta tmp2
        lda lastC               ; (line 222's colour)
        sta tmp3
        jsr RowC
_sh223  lda #0
        jsr ClearRest
        lda ec0
        ldx rb
        ldy SprStage,x
        sta StCol,y
        lda m0Y
        ldx M0X
        jsr SprPlace
_out    ldx rb
        lda v3
        sta StEn,x
        lda tmp4
        sta StMsb,x
        rts

; Wrap223: drawn slot cD's row 1 on line 223 (the field's last row shows again there, with
; no comb): its pixels past 159 wrap to 0-6, drawn into the bitmap ("10", the cell's colour)
Wrap223:
        ldx cD
        lda DBot,x
        cmp #1
        bne _no
        lda DX,x
        cmp #153
        bcs +
_no     rts
+       lda #1
        sta cy
        jsr EnemyRow            ; (left to right)
        sta qRow2
        ldx cD
        lda DPg,x               ; its colour
        sta ptrB+1
        lda DCLo,x
        sta ptrB
        ldy #1
        lda (ptrB),y
        lsr
        tay
        lda ColorMap,y
        sta qRow
        ldx #223
        lda LineLo,x
        sta ptrB
        lda LineHi,x
        clc
        adc bmpHi
        sta ptrB+1
        ldx rb                  ; cells 0-1 of cell row 23: the low nibble
        lda ScrHiTab,x
        sta ptrA+1
        lda #<(23 * 40)
        sta ptrA
        lda ptrA+1
        clc
        adc #>(23 * 40)
        sta ptrA+1
        ldy #0
        lda (ptrA),y
        and #$f0
        ora qRow
        sta (ptrA),y
        iny
        lda (ptrA),y
        and #$f0
        ora qRow
        sta (ptrA),y
        ldx cD                  ; the pixels: j = 160 - x on
        lda #160
        sec
        sbc DX,x
        tax                     ; (first wrapped bit, 1-7)
        lda ptrC
        pha
        lda ptrC+1
        pha
        lda #0
        sta qPix                ; pixel 0 on
-       lda qRow2
        and BitHi,x
        beq +
        lda qPix
        lsr
        lsr
        asl
        asl
        asl
        clc
        adc ptrB
        sta ptrC
        lda #0
        adc ptrB+1
        sta ptrC+1
        lda qPix                ; ("10" in place: player 0 has priority over the stars)
        and #3
        tay
        lda Pix11,y
        and #$aa
        sta tmp3
        lda NotPix,y
        ldy #0
        and (ptrC),y
        ora tmp3
        sta (ptrC),y
        stx qRow
        jsr Record
        ldx qRow
+       inc qPix
        inx
        cpx #8
        bne -
        pla
        sta ptrC+1
        pla
        sta ptrC
        rts
BitHi:  .byte $80, $40, $20, $10, $08, $04, $02, $01

; ShotBmp: the shot's pixel on line i = X (m0Y) in the bitmap, colour qRow: "10" pixel, the
; cell's low nibble (free in the field's cell rows) = the colour; recorded for clearing
ShotBmp:
        lda M0X                 ; (lines 84-222: shifted by the fine scroll)
        sec
        sbc fScr
        sta qPix2
        lda #223
        sec
        sbc m0Y,x
        tax
        lda LineLo,x
        sta ptrB
        lda LineHi,x
        clc
        adc bmpHi
        sta ptrB+1
        txa                     ; the cell row: (line - 37) / 8
        sec
        sbc #FIRSTLINE
        lsr
        lsr
        lsr
        tax
        lda Row40Lo,x
        sta ptrA
        lda Row40Hi,x
        ldx rb
        clc
        adc ScrHiTab,x
        sta ptrA+1
        lda qPix2
        lsr
        lsr
        tay
        lda (ptrA),y
        and #$f0
        ora qRow
        sta (ptrA),y
        lda ptrC                ; (ptrC is the sprite's block: Record takes ptrC, so swap)
        pha
        lda ptrC+1
        pha
        ldy qPix2
        lda ColOfsLo,y
        clc
        adc ptrB
        sta ptrC
        lda ColOfsHi,y
        adc ptrB+1
        sta ptrC+1
        tya                     ; ("10" in place: missile 0 has priority over the stars)
        and #3
        tay
        lda Pix11,y
        and #$aa
        sta qPix
        lda NotPix,y
        ldy #0
        and (ptrC),y
        ora qPix
        sta (ptrC),y
        lda tmp3
        pha
        jsr Record
        ldx tmp                 ; (the line: marked for the layer)
        lda #223
        sec
        sbc m0Y,x
        jsr MarkDirty
        pla
        sta tmp3
        pla
        sta ptrC+1
        pla
        sta ptrC
        rts

; EffMc: the shared colours ($D025, $D026) in effect from each drawn enemy's R1 on (EffA,
; EffB): an enemy that doesn't use one leaves it as it was
EffMc:  lda #0
        sta tmp
        sta tmp2
        lda nD
        cmp #7
        bcc +
        lda #6
+       sta tmp3
        sta mcN
        ldx #0
_eff    cpx tmp3
        beq _effEnd
        lda EnMcA,x
        cmp #$ff
        beq _keepA
        sta tmp
_keepA  lda tmp
        sta EffA,x
        lda EnMcB,x
        cmp #$ff
        beq _keepB
        sta tmp2
_keepB  lda tmp2
        sta EffB,x
        inx
        bne _eff
_effEnd rts

; McAt: A = a line's Y: Y = the drawn enemy whose colours are in effect there (the last whose
; R1 is at or above it; 0 above them all)
McAt:   sta mcY
        ldy #0
        ldx #1
-       cpx mcN
        bcs +
        lda DR1,x
        cmp mcY
        bcc +
        txa
        tay
        inx
        bne -
+       rts

; SprPtr: A = sprite: ptrC = its block in the buffer being drawn
SprPtr: asl
        asl
        asl
        asl
        asl
        asl
        sta ptrC
        lda #0
        adc sprHi
        sta ptrC+1
        rts

; Row10: a sprite row (Y = offset in the block) from tmp2 (left to right, 8 pixels), "10"
; pixels; Y += 3
Row10:  lda tmp2
        lsr
        lsr
        lsr
        lsr
        tax
        lda Nib10,x
        sta (ptrC),y
        iny
        lda tmp2
        and #15
        tax
        lda Nib10,x
        sta (ptrC),y
        iny
        lda #0
        sta (ptrC),y
        iny
        rts
; RowC: as Row10 with the pixels' code in tmp3 (1 "01", 2 "10", 3 "11")
RowC:   lda tmp3
        cmp #2
        beq Row10
        bcs _c11
        cmp #0                  ; (0: left out)
        bne +
        sta (ptrC),y
        iny
        sta (ptrC),y
        iny
        sta (ptrC),y
        iny
        rts
+
        lda tmp2
        lsr
        lsr
        lsr
        lsr
        tax
        lda Nib01,x
        sta (ptrC),y
        iny
        lda tmp2
        and #15
        tax
        lda Nib01,x
        jmp _c2
_c11    lda tmp2
        lsr
        lsr
        lsr
        lsr
        tax
        lda Nib11,x
        sta (ptrC),y
        iny
        lda tmp2
        and #15
        tax
        lda Nib11,x
_c2     sta (ptrC),y
        iny
        lda #0
        sta (ptrC),y
        iny
        rts

; SprCopy: sprite v1's block and colours (ec0-2) from the other buffer's (its slot X, ours Y)
SprCopy:
        lda SprEc0,x
        sta ec0
        lda SprEc1,x
        sta ec1
        lda SprEc2,x
        sta ec2
        lda SprLen,x
        sta eBlkX
        lda v1
        jsr SprPtr
        lda ptrC
        sta ptrD
        lda ptrC+1
        eor #>(VIC0 ^ VIC1)     ; (the other bank)
        sta ptrD+1
        ldy eBlkX
        beq +
-       dey
        lda (ptrD),y
        sta (ptrC),y
        tya
        bne -
+       ldy eBlkX
        lda v1
        jmp ClearRest

; ClearRest: A = sprite, Y = the bytes just written in its block (ptrC): clear what the
; block held past them before (SprLen: per buffer and sprite)
ClearRest:
        sty tmp3
        ldx rb
        clc
        adc SprStage,x
        tax
        lda SprLen,x
        sta tmp
        lda tmp3
        sta SprLen,x
        lda #0
-       cpy tmp
        bcs +
        sta (ptrC),y
        iny
        bne -
+       rts

; ShipImage: sprite 7's block: its 16 rows, ($96),y from Y = ShipTop down (Y = 0: line 223
; shows Y = 1's again; Y >= $90: none), "10" pixels (REFP1, the comb's clip). A row's two bytes
; from Hi11 / Lo11 (its third byte is always 0 in every block: never written)
ShipImage:
        lda #7
        jsr SprPtr
        lda ptrC
        sta _s1+1
        sta _s2+1
        inc _s2+1               ; (a block is 64-aligned: + 1 doesn't carry)
        lda ptrC+1
        sta _s1+2
        sta _s2+2
        ldy ShipX
        jsr CombMask
        lda ShipLo2
        sta ptrB
        lda ShipGfx+1
        sta ptrB+1
        lda ShipTop
        sta cy
        ldx #0                  ; X: the block's offset
        stx tmp3                ; (the row before)
-       ldy cy
        beq _again              ; (Y = 0: the row before again)
        lda #0
        cpy #$90
        bcs +
        lda (ptrB),y
+       sta tmp3
_again  lda tmp3
        dec cy
        ldy ShipRef
        beq +
        tay
        lda Reverse,y
+       and eMask
        tay
        lda Hi11,y
        and #$aa
_s1     sta $ffff,x
        lda Lo11,y
        and #$aa
_s2     sta $ffff,x
        inx
        inx
        inx
        cpx #48
        bne -
        txa
        tay
        lda #7
        jmp ClearRest

; CombMask: Y = the object's pixel x: eMask = its pixels (left to right) outside the comb (x < 8)
CombMask:
        lda #$ff
        cpy #8
        bcs +
        tya                     ; (8 - x pixels off: LeftOff[8 - x] = LeftOff[(x ^ 7) + 1])
        eor #7
        tay
        lda LeftOff+1,y
+       sta eMask
        rts

; EnemyBuild: sprite v1's block from drawn slot cD, in two quick passes: the rows' colours (a mask per row's Y in MaskY: $55 "01", $AA
; "10", $FF "11", 0 none), then the image (Hi11 / Lo11 looked up by patched addresses: X keeps
; the block's offset; the L2 quirk's row the slow way: left of 31 the row before). The rows:
; DTop down to DBot, 21 at most; then line 223's (row 1 again, no comb) if they reached Y = 1.
EnemyBuild:
        lda v1
        jsr SprPtr
        lda ptrC                ; the stores
        sta _s1+1
        sta _r1+1
        clc
        adc #1                  ; (a block is 64-aligned: + 1 doesn't carry)
        sta _s2+1
        sta _r2+1
        lda ptrC+1
        sta _s1+2
        sta _s2+2
        sta _r1+2
        sta _r2+2
        ldx cD
        lda DGLo,x
        sta ptrB
        lda DPg,x
        sta ptrB+1
        sta ptrD+1
        lda DCLo,x
        sta ptrD
        lda DRef,x
        sta eRef
        lda DBot,x
        sta eBot
        ldy DX,x
        jsr CombMask
        ldx cD
        lda DTop,x              ; rows - 1 (21 rows at most)
        sec
        sbc DBot,x
        cmp #21
        bcc +
        lda #20
+       sta tmp
        lda DTop,x              ; eStop: the Y after the last row
        clc
        sbc tmp
        sta eStop
        lda #$ff                ; ---- the colours: the first row's (not black) is the sprite's
        sta ec0                 ; own ("10"), the next two others the shared ones ($D025 "01",
        sta ec1                 ; $D026 "11"), a fourth falls back to the sprite's own; then
        sta ec2                 ; black (if any rows are) takes the first of those left, else
        cpx nD                  ; (a hidden object, flicker off: its own colour only)
        bcc +
        lda #$fe
        sta ec1
        sta ec2
        lda #$ff
+                               ;
        lda #0                  ; its rows are left out (transparent: the same on a black
        sta eBlack              ; background, but over a star). ec0-2 = $ff: not used.
        ldy DTop,x
_cl     lda (ptrD),y
        lsr
        tax
        lda ColorMap,x
        beq _cblk
        cmp ec0
        bne _coth
        lda #$aa
_cset   sta MaskY,y
        dey
        cpy eStop
        bne _cl
        beq _cdone
_cblk   lda #1                  ; (black: 1 until it's known)
        sta eBlack
        bne _cset
_coth   cmp ec1
        beq _c1
        cmp ec2
        beq _c3
        ldx ec0                 ; a new colour: the first free of own, $D025, $D026
        inx
        bne +
        sta ec0
        lda #$aa
        bne _cset
+       ldx ec1
        inx
        bne +
        sta ec1
_c1     lda #$55
        bne _cset
+       ldx ec2
        inx
        bne +
        sta ec2
_c3     lda #$ff
        bne _cset
+       lda #$aa                ; (none left: the sprite's own)
        bne _cset
_cdone  lda eBlack
        beq _image
        ldx #$aa                ; black: the first left of own, $D025, $D026, or none
        lda ec0
        cmp #$ff
        bne +
        lda #0
        sta ec0
        beq _blk
+       ldx #$55
        lda ec1
        cmp #$ff
        bne +
        lda #0
        sta ec1
        beq _blk
+       ldx #$ff
        lda ec2
        cmp #$ff
        bne +
        lda #0
        sta ec2
        beq _blk
+       ldx #0
_blk    stx tmp
        ldx cD
        ldy DTop,x
-       lda MaskY,y
        cmp #1
        bne +
        lda tmp
        sta MaskY,y
+       dey
        cpy eStop
        bne -
_image  ldx cD                  ; ---- the image
        ldy DTop,x
        lda eStop
        sta eEnd
        lda DQuirk,x            ; (the L2 quirk's row, if drawn: the rows above it first)
        beq +
        cmp eStop
        beq +
        bcc +
        sta eEnd
+       ldx #0
_seg    cpy eEnd
        beq _segEnd
        lda eRef
        bne _refl
_plain  lda (ptrB),y
        and eMask
        sta _h+1
        sta _l+1
_h      lda Hi11
        and MaskY,y
_s1     sta $ffff,x
_l      lda Lo11
        and MaskY,y
_s2     sta $ffff,x
        inx
        inx
        inx
        dey
        cpy eEnd
        bne _plain
        beq _segEnd
_refl   lda (ptrB),y
        sta _rv+1
_rv     lda Reverse
        and eMask
        sta _rh+1
        sta _rl+1
_rh     lda Hi11
        and MaskY,y
_r1     sta $ffff,x
_rl     lda Lo11
        and MaskY,y
_r2     sta $ffff,x
        inx
        inx
        inx
        dey
        cpy eEnd
        bne _refl
_segEnd cpy eStop
        beq _tail
        sty cy                  ; the quirk's row (Y = DQuirk)
        stx eBlkX
        lda MaskY,y
        sta eMk
        jsr QuirkRow
        and eMask
        tax
        ldy eBlkX
        lda Hi11,x
        and eMk
        sta (ptrC),y
        iny
        lda Lo11,x
        and eMk
        sta (ptrC),y
        iny
        iny
        tya
        tax
        ldy cy                  ; then the rest
        dey
        lda eStop
        sta eEnd
        jmp _seg
_tail   lda eBot                ; line 223: row 1 again (no comb), if the rows got to it
        cmp #1
        bne _done
        lda eStop
        bne _done
        cpx #63
        bcs _done
        ldy #1
        lda (ptrB),y
        ldy eRef
        beq +
        tay
        lda Reverse,y
+       sta tmp
        txa
        tay
        ldx tmp
        lda Hi11,x
        and MaskY+1
        sta (ptrC),y
        iny
        lda Lo11,x
        and MaskY+1
        sta (ptrC),y
        iny
        iny
        tya
        tax
_done   txa
        tay
        lda v1
        jmp ClearRest

; QuirkRow: drawn slot cD's row at cy on the L2 quirk's line (GRP1 written at clock 31: both
; players show the line before's graphics left of it): pixels 31 on from this row, 8-30 from
; the row before (Y + 1), left to right (tools/model.js). (Pixels past 159 are in the border:
; kept, so the image doesn't depend on x from 31 on.)
QuirkRow:
        jsr EnemyRow
        sta qRow
        lda DX,x
        sta eX
        lda #31
        sta xLo
        lda #255
        sta xHi
        lda eX
        jsr RangeMask           ; (uses tmp2, tmp3)
        and qRow
        sta qRow
        inc cy
        jsr EnemyRow
        dec cy
        sta qRow2
        lda #8
        sta xLo
        lda #31
        sta xHi
        lda eX
        jsr RangeMask
        and qRow2
        ora qRow
        rts

; SprPlace: Y = the sprite's staged slot (8 * buffer + sprite), A = its top row's Y (line
; 223 - Y), X = 2600 pixel: staged X / Y, enabled
SprPlace:
        eor #$ff                ; 223 + LINE2RAS - 1 - A (a sprite shows from the raster after
        sec                     ; its Y)
        sbc #255 - (223 + LINE2RAS - 1)
        sta StY,y
        txa                     ; X: 24 + 2 * pixel (9 bits)
        asl
        bcs _hi
        adc #24
        sta StX,y
        bcc _lo
        bcs _msb
_hi     adc #24 - 1             ; (carry set)
        sta StX,y
_msb    tya
        and #7
        tax
        lda BitTab,x
        ora tmp4
        sta tmp4
_lo     tya
        and #7
        tax
        lda BitTab,x
        ora v3
        sta v3
        rts

; ------------------------------------------------------------ the schedule
; Per buffer: the raster interrupts after the frame top (none yet: just the end marker)
; Frame top: background black (above line 83), the first enemy's shared colours. Then, in
; order down the screen: the field's background from line 83 (COLUBK at clock -41), its fine
; scroll and black (the invalid mode) from 84, each next enemy's shared colours from its R1 line
; (the lines R1, R2 and the A line after them show no enemy), the fine scroll off from 223.
Schedule:
        ldx rb
        lda SchBase,x
        sta v0                  ; next entry
        lda #0
        sta StBg,x
        lda CapKind             ; idle too long: the background colour from line 38 to 223,
        cmp #KIDLE              ; nothing else ($F0FD bit 7: ($F0FD << 1) & $F7)
        bne _notIdle
        lda XFlash
        and #$7b
        tay
        lda ColorMap,y
        ldy v0
        sta SchA,y
        lda #0
        sta SchA+1,y
        lda #1
        sta SchType,y
        sta SchType+1,y
        lda #38 + LINE2RAS
        sta SchRas,y
        lda #224 + LINE2RAS
        sta SchRas+1,y
        lda #$ff
        sta SchType+2,y
        lda #38 - FIRSTLINE     ; line 38's HMOVE comb: cells 0-1 "01" (black)
        sta ptrA
        lda bmpHi
        sta ptrA+1
        lda #$55
        ldy #0
        sta (ptrA),y
        ldy #8
        sta (ptrA),y
        rts
_notIdle
        lda FieldBg             ; the field's background (when not black)
        lsr
        tay
        lda ColorMap,y
        beq +
        ldy v0
        sta SchA,y
        lda #1
        sta SchType,y
        lda #83 + LINE2RAS
        sta SchRas,y
        inc v0
+       lda CapKind             ; the field's fine scroll ($D016) from line 84 to 222
        cmp #KFIELD
        bne +
        lda fScr
        beq +
        asl
        ora #$18
        ldy v0
        sta SchA,y
        lda #3
        sta SchType,y
        lda #84 + LINE2RAS
        sta SchRas,y
        inc v0
+       lda CapKind             ; a black field: lines 84-223 in the invalid mode
        cmp #KFIELD
        bne +
        lda FieldNow
        ora BgNow               ; (not with a background: BgStars)
        bne +
        ldy v0
        lda #$7b                ; ($D011: ECM + bitmap + screen on, 25 rows)
        sta SchA,y
        lda #4
        sta SchType,y
        lda #84 + LINE2RAS
        sta SchRas,y
        inc v0
+       lda nD                  ; the enemies' shared colours
        beq _end
        cmp #7
        bcc +
        lda #6
+       sta v2
        ldy rb                  ; the first: at the frame top
        lda EffA
        sta StMc1,y
        lda EffB
        sta StMc2,y
        ldy #1
-       cpy v2
        bcs _end
        lda EffA,y              ; (no change: no entry)
        cmp EffA-1,y
        bne _chg
        lda EffB,y
        cmp EffB-1,y
        beq _nx
_chg    lda #223 + LINE2RAS     ; R1's raster
        sec
        sbc DR1,y
        ldx v0
        sta SchRas,x
        lda EffA,y
        sta SchA,x
        lda EffB,y
        sta SchB,x
        lda #0
        sta SchType,x
        inc v0
_nx     iny
        bne -
_end    lda CapKind             ; the fine scroll off from line 223 (the last: the entries go
        cmp #KFIELD             ; down the screen, an interrupt each)
        bne +
        lda fScr
        beq +
        ldy v0
        lda #$18
        sta SchA,y
        lda #3
        sta SchType,y
        lda #223 + LINE2RAS
        sta SchRas,y
        inc v0
+       ldy v0
        lda #$ff
        sta SchType,y
        rts

