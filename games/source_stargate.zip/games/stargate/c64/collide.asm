; =============================================================== collisions
; The overlaps the 2600's TIA would have latched in the field (from line 83's CXCLR), worked
; out from what FieldHook found (see capture.asm), and left where the game looks:
;   - each drawn slot's $B0,x: CXPPMM as its R2 read it (clock 76): bit 7 if an enemy drawn
;     before it touched the ship, bit 6 if the shot met missile 1 (a star or mountain) before
;   - CXM0P ($30) bit 7: the shot touched the ship
;   - CXP0FB ($32) bit 7: the laser (playfield, line L1) touched an enemy
; Pixels 0-7 of a field line are the HMOVE comb: nothing there collides. Objects past pixel 159
; wrap into the comb.

Collide:
        lda #0
        sta hitAny              ; P0-P1 so far (bit 7)
        sta cxM0P
        sta cxP0F
        lda #$ff
        sta m1Y                 ; the first line the shot met missile 1 (none)
        jsr M0Lines             ; the shot's visible lines

        ; ---- each drawn slot, top to bottom: $B0,x as its R2 read it, then its own P0-P1
        ldx #0
_slot   cpx nD
        bne +
        jmp _final
+       stx cD
        lda hitAny              ; P0-P1 from the slots before
        sta tmp4
        lda m1Y                 ; M0-M1 before this R2 (Y = DR1 - 1, clock 76)?
        cmp #$ff
        beq +
        lda DR1,x
        sec
        sbc #1
        cmp m1Y
        bcc _m1                 ; (the overlap's line is above R2)
        bne +
        lda M0X
        cmp #76
        bcs +
_m1     lda tmp4
        ora #$40
        sta tmp4
+       ldy DSlot,x
        lda tmp4
        sta SlotPos,y
        ; this slot against the ship, line by line (only if they're less than 8 pixels apart:
        ; Overlap's test, the same on every line)
        lda DX,x
        sec
        sbc ShipX
        bcs +
        eor #$ff
        adc #1
+       cmp #8
        bcs _next
        lda DTop,x
        beq _next               ; (nothing shown)
        cmp ShipTop             ; (from the ship's first row: none above it can touch it)
        bcc +
        lda ShipTop
        cmp DBot,x
        bcc _next
+       sta cy
_row    lda ShipTop
        sec
        sbc cy
        cmp #16
        bcs _next               ; below them: done
        ldy cy                  ; the ship's row there (ptrD: FieldHook)
        lda (ptrD),y
        beq _down
        ldx ShipRef
        jsr ToLR
        sta oLR
        lda ShipX
        sta oX
        ldx cD
        jsr EnemyRow            ; A = this slot's row at cy, left to right
        sta eLR
        lda DX,x
        sta eX
        lda #8                  ; the whole line (but the quirk line: right of 31)
        sta xLo
        lda #160
        sta xHi
        jsr QuirkSplit
        jsr Overlap
        bne _hit
        lda qOld                ; ... left of 31: the line before's rows
        beq _down
        jsr Overlap
        bne _hit
_down   ldx cD
        lda cy
        cmp DBot,x
        beq _next
        dec cy
        jmp _row
_hit    lda #$80
        sta hitAny
_next   ldx cD
        inx
        jmp _slot

_final  ; ---- the shot: the ship (CXM0P) and missile 1 (for the slots: done above); only if
        ; it's less than 8 pixels from the ship (Overlap's test)
        lda M0X
        sec
        sbc ShipX
        bcs +
        eor #$ff
        adc #1
+       cmp #8
        bcs _laser
        ldx #0
_m0     cpx m0N
        beq _laser
        stx cD
        lda m0Y,x
        sta cy
        lda ShipTop             ; the ship's row on that line
        sec
        sbc cy
        cmp #16
        bcs _m0n
        ldy cy
        lda M0X                 ; (quirk line: left of 31 the line before's row)
        cmp #31
        bcs +
        lda lzAct
        beq +
        lda cy
        clc
        adc #1
        cmp lzY
        bne +
        lda cy                  ; (the ship's first row: none before it)
        cmp ShipTop
        bcs _m0n
        iny
+       lda (ptrD),y
        ldx ShipRef
        jsr ToLR
        sta oLR
        lda ShipX
        sta oX
        lda #$80                ; the shot: one pixel
        sta eLR
        lda M0X
        sta eX
        ldx cD
        lda m0X0,x
        sta xLo
        lda m0X1,x
        sta xHi
        jsr Overlap
        beq _m0n
        lda #$80
        sta cxM0P
_m0n    ldx cD
        inx
        jmp _m0

_laser  ; ---- the laser line (L1): the enemy on it against the playfield
        lda lzOn
        beq _done
        ldx #0
-       cpx nD
        beq _done
        lda DTop,x
        cmp lzY
        bcc +
        lda lzY
        cmp DBot,x
        bcs _lz
+       inx
        bne -
_lz     stx cD
        lda lzY
        sta cy
        jsr EnemyRow
        sta eLR
        lda DX,x
        sta eX
        ldy #0                  ; its eight pixels
-       asl eLR
        bcc +
        tya
        clc
        adc eX
        cmp #8
        bcc +
        cmp #160
        bcs +
        jsr PFBit
        beq +
        lda #$80
        sta cxP0F
        bne _done
+       iny
        cpy #8
        bne -
_done   lda cxM0P
        sta CXM0P
        lda cxP0F
        sta CXP0FB
        rts

; A = slot cD's graphics at row cy (left to right: REFP0 reverses), X = cD
EnemyRow:
        ldx cD
        lda DGLo,x
        sta ptrB
        lda DPg,x
        sta ptrB+1
        ldy cy
        lda (ptrB),y
        pha
        lda DRef,x
        tax
        pla
        jsr ToLR
        ldx cD
        rts

; A = graphics byte, X = REFPx (bit 3): A left to right (bit 7 = the leftmost pixel). On the
; 2600 bit 7 is drawn first unless reflected.
ToLR:   cpx #0
        beq +
        tax
        lda Reverse,x
+       rts

; The L2 quirk (the laser line's next line, when an enemy row is on it): GRP1 is written at
; clock 31, so both players show the line before's graphics left of it. For the overlap at
; cy: if this is that line, Overlap first covers 31-159 (xLo), and qOld says to call it again
; for 8-30 with the rows before in oLR / eLR.
QuirkSplit:
        lda #0
        sta qOld
        lda lzAct
        beq _no
        lda cy
        clc
        adc #1
        cmp lzY
        bne _no
        lda #31
        sta xLo
        inc qOld
        ; (the second call: rows of the line before)
        rts
_no     rts

; Overlap: any pixel x in [xLo, xHi) where both eLR (at eX) and oLR (at oX) are set?
; Leaves A non-zero (Z clear) if so. With qOld = 1 (QuirkSplit) it then sets up the second
; call: the rows of the line before, pixels 8-30 (qOld = 2); after that call qOld = 0.
Overlap:
        lda eX
        sec
        sbc oX
        bcs _pos                ; eX >= oX: e is right of o by d
        eor #$ff                ; o is right of e by d
        adc #1
        cmp #8
        bcs _none
        tay
        lda oLR
_sh1    dey
        bmi _sh1d
        lsr
        jmp _sh1
_sh1d   and eLR
        sta tmp
        lda eX
        jmp _mask
_pos    cmp #8
        bcs _none
        tay
        lda eLR
_sh2    dey
        bmi _sh2d
        lsr
        jmp _sh2
_sh2d   and oLR
        sta tmp
        lda oX
_mask   jsr RangeMask
        and tmp
        bne _yes
_none   lda #0
_yes    pha
        lda qOld
        cmp #1
        beq _setup
        lda #0
        sta qOld
        pla
        rts
_setup  inc qOld                ; the second call: the line before's rows, pixels 8-30
        lda #8
        sta xLo
        lda #31
        sta xHi
        lda ShipTop             ; the ship's row on the line before (Y + 1)
        sec
        sbc cy
        sec
        sbc #1
        bmi _noShip
        cmp #16
        bcs _noShip
        ldy cy
        iny
        lda (ptrD),y
        ldx ShipRef
        jsr ToLR
        jmp _ship
_noShip lda #0
_ship   sta oLR
        lda cy                  ; the enemy's row before (if it was on)
        pha
        inc cy
        ldx cD
        lda DTop,x
        cmp cy
        bcc _noEn
        jsr EnemyRow
        jmp _en
_noEn   lda #0
_en     sta eLR
        pla
        sta cy
        pla
        rts

; RangeMask: A = x of the leftmost pixel; the bits (left to right) of the pixels x..x+7 that
; lie in [xLo, xHi)
RangeMask:
        sta tmp2
        lda xLo                 ; pixels left of xLo: xLo - x of them (0-8)
        sec
        sbc tmp2
        bcs +
        lda #0
+       cmp #9
        bcc +
        lda #8
+       tay
        lda LeftOff,y
        sta tmp3
        lda tmp2                ; pixels at xHi and right: x + 8 - xHi of them
        clc
        adc #8
        sec
        sbc xHi
        bcs +
        lda #0
+       cmp #9
        bcc +
        lda #8
+       tay
        lda RightOff,y
        and tmp3
        rts
LeftOff:    .byte $ff, $7f, $3f, $1f, $0f, $07, $03, $01, $00
RightOff:   .byte $ff, $fe, $fc, $f8, $f0, $e0, $c0, $80, $00

; PFBit: A = pixel (0-159) on the laser line: Z clear if the playfield is on there
PFBit:  sty tmp3
        ldx #0
        cmp #80
        bcc +
        sbc #80
        ldx #3
        cmp #151 - 80           ; (an enemy row on L2: PF2 is cleared at clock 151)
        bcc +
        ldy lzAct
        beq +
        ldy tmp3
        lda #0
        rts
+       lsr                     ; cell 0-19
        lsr
        cmp #4
        bcs +
        tay                     ; PF0: bits 4-7, cell 0 = bit 4
        lda LaserPF,x
        and Bit4,y
        ldy tmp3
        cmp #0
        rts
+       cmp #12
        bcs +
        tay                     ; PF1: cell 4 = bit 7
        lda LaserPF+1,x
        and PF1Bit-4,y
        ldy tmp3
        cmp #0
        rts
+       sec                     ; PF2: cell 12 = bit 0
        sbc #12
        tay
        lda LaserPF+2,x
        and Bit,y
        ldy tmp3
        cmp #0
        rts
Bit4:   .byte $10, $20, $40, $80
PF1Bit: .byte $80, $40, $20, $10, $08, $04, $02, $01
Bit:    .byte $01, $02, $04, $08, $10, $20, $40, $80

; M0Lines: the shot's visible lines from the walk's ENAM0 writes (m0On, m0Off): m0N lines,
; each with its Y (m0Y) and the pixels where it shows (m0X0 - m0X1: all of the shot's one
; pixel, or none); also the first line where it meets missile 1 (m1Y).
M0Lines:
        lda #0
        sta m0N
        lda m0Seen
        bne +
        rts
+       lda M0X
        cmp #8
        bcs +
        rts                     ; (in the comb)
+       ldx ShotRow             ; line Y = $9A: from the write's clock
        lda m0On
        bpl +
        lda #0
+       jsr _add
        dex                     ; Y = $9A - 1: all of it
        lda #0
        jsr _add
        dex                     ; Y = $9A - 2: up to the next write
        lda #0
        jsr _addOff
        rts
_add    stx tmp
        cpx #1                  ; (the field's lines: Y 1-$8B)
        bcc _skip
        ldy m0N
        sta m0X0,y
        lda #160
        sta m0X1,y
        txa
        sta m0Y,y
        inc m0N
        jsr M1Meets
_skip   ldx tmp
        rts
_addOff stx tmp
        cpx #1
        bcc _skip
        ldy m0N
        sta m0X0,y
        lda m0Off               ; (the walk keeps it as a pixel: 0-160)
        sta m0X1,y
        txa
        sta m0Y,y
        inc m0N
        jsr M1Meets
        ldx tmp
        rts

; M1Meets: does missile 1 cover the shot's pixel on the line of Y = X, within the shot's
; range (the entry just added)? If so and no earlier line did: m1Y = Y.
M1Meets:
        ldy m0N
        dey
        lda M0X
        cmp m0X0,y
        bcc _no
        cmp m0X1,y
        bcs _no
        lda m1Y
        cmp #$ff
        bne _no                 ; (an earlier line already)
        stx cy
        ; enabled? R1 lines keep the line before's enable
        txa
        jsr IsR1
        ldy cy
        bcc +
        iny
+       lda (StarPtr),y
        and #2
        beq _no
        ; width: the size of the latest true A line (sizes are written at clock 22 on A
        ; lines: left of that the A line before's)
        ldy cy
        jsr IsTrueA
        bcc _prev
        lda M0X
        cmp #22
        bcs _this
_prev   iny                     ; the A lines above (odd Y, not R1 or L1)
        cpy #$8c
        bcs _w1                 ; (none: NUSIZ1 = 0 from line 77)
        tya
        and #1
        beq _prev
        jsr IsTrueA
        bcc _prev
_this   lda (StarPtr),y
        lsr
        lsr
        lsr
        lsr
        and #3
        tay
        lda Width,y
_wset   sta tmp2
        ; missile 1's x on that line: M1X83 - 3 * (line - 83), line = 223 - Y
        lda #140
        sec
        sbc cy                  ; line - 83
        tay
        lda M0X
        sec
        sbc M1X83               ; M0X - x1 = M0X - M1X83 + 3 * (line - 83) (mod 160)
        bcs +
        adc #160
+       clc
        adc Times3Mod,y         ; 3 * (line - 83) mod 160
        bcs +
        cmp #160
        bcc ++
+       sbc #160                ; (carry set)
+       cmp tmp2
        bcs _no
        ldx cy
        stx m1Y
        rts
_no     ldx cy
        rts
_w1     lda #1
        jmp _wset
Width:  .byte 1, 2, 4, 8

; Carry set if Y = A is an R1 line (a slot's first: R1Flag). Changes Y.
IsR1:   tay
        lda R1Flag,y
        lsr
        tya
        rts
; Carry set if the line of Y (register Y) is a true A line (odd, not R1, not the laser's L1)
IsTrueA:
        tya
        and #1
        beq _no
        tya
        cmp lzY
        bne +
        lda lzOn
        bne _no
+       tya
        sty tmp3
        jsr IsR1
        ldy tmp3
        bcs _no
        sec
        rts
_no     clc
        rts
