; ---- part 2 (c64/main.asm): start-up code (run after CopyPart2) and the slow star path

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        lda #<SidFreqLo         ; the SID's pitch depends on the machine's clock: its tables
        ldy #>SidFreqLo         ; to SidFreq
        cpx #0                  ; (PAL: keep A)
        bne +
        lda #<SidFreqLoN
        ldy #>SidFreqLoN
+       sta ptrA
        sty ptrA+1
        lda #<SidFreq
        sta ptrB
        lda #>SidFreq
        sta ptrB+1
        ldx #4
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        rts

InitVideo:
        lda $dd02               ; the VIC bank bits are outputs
        ora #3
        sta $dd02
        lda #2                  ; bank 1 ($4000) to start
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d017               ; sprites: not Y-expanded (one sprite row a line),
        sta $d01d               ; not X-expanded (one multicolour pixel = one 2600 pixel),
        sta $d01b               ; in front of the bitmap
        lda #$ff
        sta $d01c               ; multicolour
        lda #$18                ; multicolour, 40 columns
        sta $d016
        lda #D018VAL
        sta $d018
        lda #<VIC0              ; clear what the two banks show: screen and sprite blocks
        sta ptrB                ; (+$0000-$05FF), bitmap (+$2000-$3FFF); bank 1's +$0600-$1FFF
        lda #>VIC0              ; holds code (part 2, the layer code), bank 2's the variables
        sta ptrB+1
        ldy #0
_page   lda ptrB+1
        and #$3f
        cmp #$06
        bcc _clr
        cmp #$20
        bcc _skip
_clr    tya
-       sta (ptrB),y
        iny
        bne -
_skip   inc ptrB+1
        lda ptrB+1
        cmp #>(VIC1 + $4000)
        bne _page
        lda #$c2 >> 1           ; colour RAM: the scanner's dots
        tax
        lda ColorMap,x
        ldx #0
-       sta COLRAM,x
        sta COLRAM+$100,x
        sta COLRAM+$200,x
        sta COLRAM+$2e8,x
        inx
        bne -
        jsr InitComb
        ldx #7                  ; sprite pointers: sprite n uses block SPRBLK + n in its bank
-       txa
        clc
        adc #SPRBLK
        sta VIC0+$3f8,x
        sta VIC1+$3f8,x
        dex
        bpl -
        rts

InitSound:
        ldx #$18
        lda #0
-       sta $d400,x
        dex
        bpl -
        lda #$0f                ; full volume
        sta $d418
        ldx #5
        lda #$ff
-       sta SndLast,x
        dex
        bpl -
        rts

SlowStars:
        lda #0                  ; (no fine scroll)
        sta fScr
        ldx #0                  ; each row with a star or mountain (R1 lines, R1Flag, keep the
                                ; line before's enable)
_row    cpx StarN
        bne +
        jmp _extra
+       ldy SRowY,x
        lda R1Flag,y
        beq _fast
        iny                     ; an R1 line: on if the line before is (the slow way)
        lda (StarPtr),y
        and #2
        beq _nextRow
        stx v3
        dey
        sty cy
        jsr StarLine
        ldx v3
        jmp _nextRow
_fast   lda M1X83               ; missile 1: M1X83 - 3k
        sec
        sbc SRowK3,x
        bcs +
        adc #160
+       jsr FastSpan
        lda BLX83               ; the ball: BLX83 + 3k
        clc
        adc SRowK3,x
        bcs +
        cmp #160
        bcc ++
+       sbc #160
+       jsr FastSpan
_nextRow
        inx
        jmp _row
_extra  ldx nD                  ; R1 lines that show the line before's star or mountain
-       dex
        bmi _223
        stx v3
        ldy DR1,x
        lda (StarPtr),y
        and #2
        bne +
        iny
        lda (StarPtr),y
        and #2
        beq +
        lda DR1,x
        sta cy
        jsr StarLine
+       ldx v3
        jmp -
_223    ldy #1                  ; line 223: as line 222 (Y = 1)
        lda (StarPtr),y
        and #2
        beq +
        lda R1Flag+1
        bne +
        lda #0
        sta cy
        jsr StarLine
+       rts

; FastSpan: row X's span at pixel A (missile 1 or the ball), width SRowW (1 or 4): the bytes
; straight from tables; near the edges (the comb, wrapping past 159) the slow way (Span)
FastSpan:
        tay
        lda SRowW,x
        cmp #1
        bne _w4
        cpy #8
        bcc _slow
        lda SRowLo,x
        clc
        adc ColOfsLo,y
        sta ptrC
        lda SRowHi,x
        adc ColOfsHi,y
        adc bmpHi               ; (no carry from the line before: < $2000)
        sta ptrC+1
        tya
        and #3
        tay
        lda Pix11,y
        ldy #0
        ora (ptrC),y
        sta (ptrC),y
        jmp Record
_w4     cpy #8
        bcc _slow
        cpy #157
        bcs _slow
        lda SRowLo,x
        clc
        adc ColOfsLo,y
        sta ptrC
        lda SRowHi,x
        adc ColOfsHi,y
        adc bmpHi
        sta ptrC+1
        lda W4B,y
        sta tmp2
        lda W4A,y
        ldy #0
        ora (ptrC),y
        sta (ptrC),y
        jsr Record
        lda tmp2
        beq _w4end
        ldy #8
        ora (ptrC),y
        sta (ptrC),y
        lda ptrC
        clc
        adc #8
        sta ptrC
        bcc +
        inc ptrC+1
+       jmp Record
_w4end  rts
_slow   sty v0                  ; (Span: A = pixel, v2 = width, cy = Y)
        stx v3
        lda SRowW,x
        sta v2
        lda SRowY,x
        sta cy
        lda v0
        jsr Span
        ldx v3
        rts

; StarRows: the rows (Y = $8B down to 1) whose ($9B),y byte enables missile 1 / the ball, and
; per row: Y, its bitmap line's offset, 3 * (line - 83) mod 160, the width (1 or 4)
StarRows:
        lda StarPtr
        sta StarFor
        ldx #0
        ldy #$8b
_sr     lda (StarPtr),y
        and #2
        beq _nx
        tya
        sta SRowY,x
        lda (StarPtr),y
        lsr
        lsr
        lsr
        lsr
        and #3
        sty tmp
        tay
        lda Width,y
        sta SRowW,x
        lda #223                ; the line
        sec
        sbc tmp
        tay
        lda LineLo,y
        sta SRowLo,x
        lda LineHi,y
        sta SRowHi,x
        lda #140                ; k = line - 83 = 140 - Y
        sec
        sbc tmp
        tay
        lda Times3Mod,y
        sta SRowK3,x
        ldy tmp
        inx
_nx     dey
        bne _sr
        stx StarN
        rts

; FieldColour: colour RAM cell rows 5-24 (bytes 200-999) = FieldCol, but column 0 of rows
; 5-22 black: on the field's lines it's always in the comb (screen pixels 0-7, whatever the fine
; scroll), so the layer's "11" pixels there don't show (cell row 23 has line 223 too: LayerEdge)
FieldColour:
        lda FieldCol
        ldx #49
-       .for k = 0, k < 16, k += 1
        sta COLRAM+200+50*k,x
        .next
        dex
        bpl -
        lda #0
        .for r = 5, r < 23, r += 1
        sta COLRAM+40*r
        .next
        rts

; InitComb: the HMOVE comb, black pixels 0-7 of lines 82-222 (an HMOVE at the start of each):
; in both bitmaps cells 0-1 "01" with a black high nibble (cell rows 5-23). Only seen where the
; background isn't black.
InitComb:
        lda #0
        sta v2
_buf    ldx v2
        lda BmpHiTab,x
        sta bmpHi
        lda #82
        sta v0
-       ldx v0
        lda LineLo,x
        sta ptrA
        lda LineHi,x
        clc
        adc bmpHi
        sta ptrA+1
        lda #$55
        ldy #0
        sta (ptrA),y
        ldy #8
        sta (ptrA),y
        inc v0
        lda v0
        cmp #84                 ; (lines 84-222: the layer masks screen cells 0-1 itself)
        bne -
        ldx v2                  ; screen: cells 0-1 of rows 5-23
        lda ScrHiTab,x
        sta ptrA+1
        lda #<(5 * 40)
        sta ptrA
        inc ptrA+1              ; (5 * 40 = 200 < 256: same page as the screen's start)
        dec ptrA+1
        ldx #19
-       lda #0
        ldy #0
        sta (ptrA),y
        iny
        sta (ptrA),y
        lda ptrA
        clc
        adc #40
        sta ptrA
        bcc +
        inc ptrA+1
+       dex
        bne -
        inc v2
        lda v2
        cmp #2
        bne _buf
        rts

; The positions the field's positioning gives each X code (needs the 2600 program in place):
; the code's byte v in $FBD0: reset at clock 7 + 15 * (bits 1-2) (+3 with bit 7; 3 earlier for
; codes below $30, where the table look-up doesn't cross a page), again 78 later (+3 the
; same way) with bit 0; a player is at the clock + 5, a missile + 4; then HMOVE twice with the
; fine motion in bits 3-6 (moving left for positive values).
InitPos:
        ldx #0
_pos    lda PosTable,x
        sta tmp
        and #6
        tay
        lda Times15,y
        clc
        adc #7
        bit tmp
        bpl +
        adc #3
+       cpx #$30
        bcs +
        sbc #3 - 1              ; (carry clear)
+       lsr tmp                 ; bit 0: the later reset
        bcc +
        adc #78 - 1             ; (carry set)
        cpx #$30
        bcs +
        sbc #3 - 1              ; (carry clear)
+       sta tmp2                ; the reset's clock
        lda PosTable,x          ; fine motion: (v << 1) >> 4 = bits 3-6
        lsr
        lsr
        lsr
        and #15
        tay
        lda tmp2
        clc
        adc #5
        sec
        sbc Fine2,y
        jsr Mod160
        sta PosP,x
        lda tmp2
        clc
        adc #4
        sec
        sbc Fine2,y
        jsr Mod160
        sta PosM,x
        inx
        bne _pos
        rts
