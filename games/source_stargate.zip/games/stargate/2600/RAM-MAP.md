# Stargate (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80` | Random | 1 | Random number (shift register, stepped every frame at $D916); $B5 at power on |
| `$81` | FrameCount | 1 | Frame counter; bit 0 picks the odd/even half of the logic; 0 = once-per-256-frames events (spawns) |
| `$82` | ShipsLeft | 1 | Ships left including the one in play; 0 = no game (title / game over screen) |
| `$83` | Smartbombs | 1 | Smartbombs left (3 at start, +1 every 10,000) |
| `$84` | Invisos | 1 | Inviso uses left (3 at start, +1 every 10,000) |
| `$85` | ShipX | 1 | Ship screen X code; drifts to $53 (facing right) or $AE (facing left) |
| `$86` | ShotX | 1 | Enemy shot (missile 0) X code; $CF = none |
| `$87-$88` | StarsX | 2 | Stars/mountains X codes: $87 missile 1, $88 the ball (moved by -Scroll, wrapped $30-$CF) |
| `$89` | Wave | 1 | Waves completed, BCD (shown +1); low digit picks the wave's enemies; +3 on a stargate warp |
| `$8A` | Level | 1 | Difficulty: +1 each wave, +3 on a warp; min(Level,15) ORed into the enemy/shot speed bits |
| `$8B-$8D` | Score | 3 | Score, BCD, high byte first ($8B ten-thousands, $8C hundreds, $8D ones) |
| `$8E` | Freeze | 1 | Nonzero: no enemy motion, firing or spawning; $D2 at wave end, 2 after the ship explodes until the player moves or fires |
| `$8F` | FieldColour | 1 | Field background colour (planet explosion colours, $0F smartbomb flash, $FF on ship death) |
| `$90-$91` | SoundPtr | 2 | Sound pointers into $DE7A for channel 0 ($90) and channel 1 ($91); each channel updated on alternate frames |
| `$92-$93` | SoundNext | 2 | Sound to start when the current one ends: $92 the thrust/engine hum ($28 moving, $2B idle), $93 the extra-ship sound ($8B) |
| `$94-$95` | ShipGfx | 2 | Kernel: ship graphics pointer (low 0 = blank page until row ShipSwitch; high $FF, or $FD when carrying humanoids) |
| `$96` | ShipGfxLow | 1 | Ship graphics pointer low byte switched into $94 at row ShipSwitch |
| `$97` | ShipSwitch | 1 | Row (ship row + 5) where the ship graphics start |
| `$98` | Scroll | 1 | Pixels the world scrolls this frame (signed, from ShipSpeed); $10 during hyperspace/stargate travel |
| `$99` | ShipRow | 1 | Ship row (8-$88; $49 at start; 0 while exploded/off) |
| `$9A` | ShotRow | 1 | Enemy shot row; >= $8C = no shot |
| `$9B-$9C` | StarsPtr | 2 | Pointer into page $FE: enable/size of missile 1 and ball per row (stars, mountains); low byte = PlanetGone |
| `$9D-$9E` | EnemyGfx | 2 | Kernel: current slot's graphics pointer |
| `$9F-$A0` | EnemyColour | 2 | Kernel: current slot's colour pointer (same page as the graphics) |
| `$A1` | KernelTop | 1 | Kernel: top row of the slot being drawn |
| `$A2` | Slots | 1 | Display list size; prep: slots to draw (objects + slot 0); kernel counts it down |
| `$A3` | SlotCount | 1 | Copy of Slots for bank 0 (collision loops over the slots) |
| `$A4` | LaserSlot | 1 | Kernel stores the slot being drawn on the laser row (0 = the humanoid) |
| `$A5` | BlastTimer | 1 | Enemy explosion animation timer ($0F): types $11 -> $12 -> $13 -> gone every 4 frames |
| `$A6` | ShipBlast | 1 | Ship explosion timer: $2F on a hit, ship removed at $24, a ship lost at 0 |
| `$A7` | Implode | 1 | Screen-wide explosion/materialise timer ($1F): all enemies drawn as explosion frames, no collisions |
| `$A8` | SpawnPhase | 1 | Wave schedule, -1 every 256 frames from $0B: $0A main set (objects 6-14), 8 objects 3-5, 6 objects 0-2, 0 a type 1-3 baiter (then every 512 frames) |
| `$A9` | PlanetGone | 1 | 0 = planet intact; 1-$1C planet explosion stage (all humanoids lost); restored every 5 waves |
| `$AA` | WaveEndTimer | 1 | Wave end / bonus screen frames left ($D2) |
| `$AB` | InvisoTimer | 1 | Inviso time left (+$1E per use, -1 every 4 frames); ship flickers, cannot be hit, kills what it touches |
| `$AC` | SmartbombTimer | 1 | Smartbomb frames left (2): destroys the enemies in the display slots |
| `$AD` | JumpTimer | 1 | Hyperspace / stargate travel frames left: field not drawn, world scrolls 16 px a frame |
| `$AE` | GameOverDelay | 1 | $80 set at game start; counts down with no game: game over screen, fire ignored until 0 |
| `$AF` | Carried | 1 | Humanoids carried by the ship (4+ through the stargate = warp) |
| `$B0-$B5` | SlotPos | 6 | Per slot: X code byte (coarse delay, late-RESP bit 0, REFP0 bit 3); the kernel overwrites it with CXPPMM (bit 7: ship hit, seen when this slot starts) |
| `$B6-$BB` | SlotMove | 6 | Per slot: HMP0 fine motion (high nibble) \| graphics page low nibble ($F8-$FF) |
| `$BC-$C1` | SlotColour | 6 | Per slot: colour pointer low byte (table address - top row) |
| `$C2-$C7` | SlotTop | 6 | Per slot: top row |
| `$C8-$CD` | SlotGfx | 6 | Per slot: graphics pointer low byte (table address - top row) |
| `$CE-$D2` | NearList | 5 | Objects in the near window (ObjHi = 0), sorted by row, lowest first (built on odd frames) |
| `$D3` | ShotDir | 1 | Enemy shot direction 0-15 (bits 3-2 speed from Random, bit 1 left, bit 0 down) |
| `$D4` | BonusCount | 1 | Wave end: humanoids counted so far for the bonus |
| `$D5` | NearCount | 1 | Objects in the near window; an object may not enter it when this is 5 |
| `$D6` | Humanoids | 1 | Humanoids on the planet, one bit per sector (bit k at view X ScrollPhase+128k); $FF at start |
| `$D7` | LaserRow | 1 | Laser row ((ShipRow & $FE) - 3); 0 = laser stopped by a hit |
| `$D8` | FireDelay | 1 | Frames until the laser may fire again ($10; $32 at start) |
| `$D9` | LaserTimer | 1 | Laser: bit 7 fired left, bits 0-6 step (counts down, picks the PF masks; 0 = gone) |
| `$DA-$DF` | LaserPF | 6 | Laser playfield bytes: PF0, PF1, PF2 left half, PF0, PF1, PF2 right half ($DA low nibble: the kernel merges the stars of the laser row) |
| `$E0-$EF` | ObjRow | 16 | Objects: top row; $EF (object 15, the stargate) is set to $6C every frame |
| `$F0-$F1` | Temp | 2 | Scratch |
| `$F2-$FD` | TextPtr | 12 | Bank 1: six pointers for the 48-pixel score/text rows (score digits via the stack, icons, messages); also scratch ($F2 Level bits, $F4, $F6 explosion type, $F8/$F9 animation frames) |
| `$FE-$FF` | Stack | 2 | Stack (S = $FF in the game logic; only single-level JSRs) |

## Cartridge RAM (SuperChip)

Written at `$F000-$F07F`, read at `$F080-$F0FF`.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$F080` | ScrollPhase | 1 | View X of the humanoid of bit 0 (0-127); -Scroll each frame, $D6 rotates when it wraps |
| `$F081` | Facing | 1 | Ship facing: 0 left, 1 right (REFP1 = Facing - 1) |
| `$F082-$F091` | ObjX | 16 | Objects: X, low 8 bits (screen X code when ObjHi = 0); start $10,$20..$A0,$10..$50,$80 |
| `$F092-$F0A1` | ObjDir | 16 | Objects: direction 0-16 (dy table $DD47, dx $DD36; bit 3 = facing left = REFP0) |
| `$F0A2-$F0B1` | ObjType | 16 | Objects: type (see the table above); $F0B1 = object 15 = $10 the stargate |
| `$F0B2-$F0C1` | ObjHi | 16 | Objects: X bits 8-9 (0 = near window); $F0C1 = the stargate's (1 or 2) |
| `$F0C2-$F0C7` | SlotObject | 6 | $F0C2+s = object drawn in slot s (s >= 1). Bank 0 writes $F0C3+ as the display list (on-screen near objects, $FF = skipped this frame for flicker), bank 1 compacts it |
| `$F0C8` | HumanoidSide | 1 | Which humanoid slot 0 shows: 0 bit 0 at ScrollPhase, 1 bit 1 at ScrollPhase+$80 (for the laser hit) |
| `$F0C9` | BlastRow | 1 | Ship explosion top row (ShipRow + 2) |
| `$F0CA` | ShipColour | 1 | Ship and laser colour ($32; explosion colours; 0 on inviso frames) |
| `$F0CB` | ScrollFrac | 1 | Scroll fraction (1/32 pixel) |
| `$F0CC` | ShipSpeed | 1 | Ship speed, signed, $C0-$40 in 1/32 pixel a frame; +-1 per frame pushed, decays by 1 |
| `$F0CD` | RightDebounce | 1 | Right controller latch: nonzero until the right stick is centred and its button released |
| `$F0CE` | BonusValue | 1 | Wave end: bonus per humanoid in hundreds, BCD (min(Wave,5)); $20 = stargate warp screen |
| `$F0CF-$F0F8` | Scanner | 42 | Scanner graphics: 6 columns x 7 rows ($F0CF sector 6, $F0D6 7, $F0DD 0, $F0E4 1, $F0EB 2, $F0F2 3); row 0 = humanoids |
| `$F0F9` | ScanObject | 1 | Scanner: object to look at next (one dot per frame, counts down); bit 7 = start the next column |
| `$F0FA` | ScanSector | 1 | Scanner: sector being drawn (order 0,1,2,3,6,7) |
| `$F0FB` | NearTotal | 1 | Entries in NearList this frame |
| `$F0FC` | StartSound | 1 | Game start sound timer ($80, plays while counting down) |
| `$F0FD` | IdleTimer | 1 | +1 every 256 frames without input (cleared by input in a game); bit 7 = screen blanked, background cycling |
| `$F0FE-$F0FF` | XramUnused | 2 | Not used? |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$D100` | BlastTypes | Table: explosion type for each BlastTimer step ($00, $13, $12; next byte is code) |
| `$D103` | Reset0 | Power on (from bank 1's $F100): clear RAM and SuperChip RAM, objects' X, stargate |
| `$D109` | ClearRam | Clear zero page and SuperChip from X ($89 at game start keeps $80-$88, xram $F000-$F008); then common start values |
| `$D16C` | Overscan | From bank 1: overscan timer; no game: game over delay, fire or Reset starts; Reset in a game restarts |
| `$D188` | StartGame | 3 ships, 3 smartbombs, 3 invisos, clear from $89 |
| `$D197` | GameLogic | S = $FF; no game: straight to VerticalSync |
| `$D1A1` | ShotHitsShip | CXM0P bit 7 (enemy shot touched the ship): ship explodes unless inviso |
| `$D1B5` | SmartbombKill | Smartbomb frames: every enemy in the display slots explodes and scores; carriers drop their humanoid |
| `$D200` | ShipTouches | Ship vs enemy from the kernel's CXPPMM in SlotPos: find the slot, check rows |
| `$D246` | ShipRamsCarrier | Ship hits a lander with a humanoid: lander gone, humanoid falls; ship explodes unless inviso |
| `$D25F` | ShipRamsEnemy | Ship hits an enemy: enemy explodes and scores, ship explodes unless inviso |
| `$D282` | EnterStargate | Ship in the stargate: with 4+ humanoids (and Wave < 10) warp 3 waves |
| `$D2B8` | StargateJump | Otherwise travel to a lander carrying a humanoid (JumpTimer from its distance) |
| `$D2F5` | LaserHits | CXP0FB bit 7 (laser playfield touched player 0): slot 0 = humanoid killed, else the enemy in LaserSlot |
| `$D314` | LaserHitsEnemy | Enemy takes its hit type ($DDD7) and scores; a carrier drops its humanoid (or loses it if the humanoid was hit) |
| `$D355` | LaserStop | Laser ends (LaserRow 0), explosion animation and sound |
| `$D361` | FrameHalf | Odd frames: $D369; even frames: $D454 |
| `$D369` | ShipExplosion | Odd: field colour; ship explosion: $2E freeze, $24 ship gone, baiters removed, enemies re-placed, humanoids carried return |
| `$D3D7` | ShipLost | Count ShipBlast down; at 0 a ship is lost, ship back at $53/$49 facing right |
| `$D3EC` | ShipColourSet | Ship colour ($32, explosion colours) |
| `$D3F8` | AnimateBlasts | Every 4 frames step all exploding objects (types $11+) |
| `$D41C` | PlanetExplosion | Advance PlanetGone to $1C with sounds; Implode countdown |
| `$D442` | EngineSound | Queue the engine hum (louder while the left stick is pushed sideways) |
| `$D454` | CheckWaveEnd | Even: all groups launched and no object 0-14 of type >= 4: next wave |
| `$D477` | WaveEnd | Start the wave end screen: BonusValue, WaveEndTimer = Freeze = $D2, SpawnPhase = $0B |
| `$D484` | CheckPlanet | No humanoids on the planet or carried: planet explodes (PlanetGone = 1) |
| `$D4A4` | LandersMutate | Planet gone: every lander (9) becomes a mutant (4) |
| `$D4B9` | SpawnSchedule | Once per 256 frames: step SpawnPhase |
| `$D4DB` | SpawnGroup | Objects 5-3 (phase 8) or 2-0 (phase 6): type from $DFE0 by wave digit, top row $87 |
| `$D4FC` | WaveSetup | Phase $0A: objects 6-14 from the wave table ($DF7C), objects 0-5 cleared, stargate moved, Implode |
| `$D542` | SpawnBaiter | Phase 0: a type 1/2/3 ($DDE7, random) in a free object 6-0, every 512 frames |
| `$D56C` | RightController | Right button: smartbomb (none left: inviso, none: hyperspace) |
| `$D598` | RightStick | Right stick up: inviso; down: hyperspace (latched by RightDebounce) |
| `$D5B3` | UseInviso | Inviso: InvisoTimer += $1E |
| `$D5BD` | Hyperspace | Hyperspace: random jump (JumpTimer = Random & $3F); below $0D the ship explodes |
| `$D5D2` | DropHumanoid | Carrying and near the ground: put one humanoid back, 500 points |
| `$D5FF` | ShipControl | Jump travel (Scroll $10); explosion: no scroll |
| `$D61A` | MoveShip | Left stick: input clears IdleTimer and Freeze; left/right accelerate and face, decay; scroll; ship drifts across; up/down |
| `$D6CF` | FireLaser | Left button: fire the laser (FireDelay, LaserTimer, LaserRow) |
| `$D70A` | LaserBeam | Laser playfield bytes for this step |
| `$D754` | MoveShot | Move the enemy shot (speed from Level), remove it off screen |
| `$D79D` | EnemyFires | No shot: the first slot with a lander, carrier, mutant or type 1 fires at the ship |
| `$D7F0` | MoveObjects | All 16 objects: move by their direction when their speed bits ($DD22 | Level) match the frame, minus Scroll; near window limit |
| `$D86E` | UpdateScanner | Scanner: plot one object per frame into the current sector's column |
| `$D8E7` | ScannerColumn | Next scanner column: humanoid dot on its bottom row |
| `$D90B` | VerticalSync | Wait for the timer, VSYNC, step Random |
| `$D925` | ShipPointer | Ship graphics pointers (inviso flicker, carried humanoids) |
| `$D955` | MoveStars | Stars/mountains X -= Scroll, wrap |
| `$D976` | Sound | Sound: one channel per frame from $DE7A (byte < $10 AUDC, $10 silence, else AUDF + volume) |
| `$D99F` | VblankLogic | End VSYNC, VBLANK timer, game start sound, frame counter, IdleTimer |
| `$D9DE` | BuildNearList | Odd: list the near window's objects and sort them by row |
| `$DA20` | ChaseShip | Even: near objects of type < 9 steer toward the ship |
| `$DA6D` | LanderAI | Even: objects 0-8 by type: falling humanoids, carriers rise and mutate, landers descend and abduct |
| `$DA88` | FallingHigh | Type $0F: falls, dies on landing |
| `$DAA3` | FallingLow | Type $0E: falls, lands: humanoid back on the planet, 250 points |
| `$DACF` | CarrierRises | Type $0D: rises; at the top becomes a mutant |
| `$DAE1` | LanderMoves | Type 9: descend; near the ground patrol, pick up the humanoid below |
| `$DB30` | SpreadRows | Push near objects apart vertically (less flicker) |
| `$DB6D` | RowLimits | Keep objects between the ground ($19, $11 without planet) and $86 |
| `$DB9B` | DisplayList | On-screen near objects into SlotObject; Slots |
| `$DBC7` | FlickerList | Objects too close vertically: skip one of each pair on alternate frames |
| `$DBF9` | ScrollHumanoids | ScrollPhase -= Scroll; rotate Humanoids at a sector boundary |
| `$DC1C` | PickHumanoid | Which humanoid slot 0 shows, then go to bank 1 |
| `$DC39` | ReturnHumanoid | Set the first free Humanoids bit from sector X |
| `$DC4E` | AddScore | Score += A (ones) and $F1 (hundreds), BCD |
| `$DC56` | AddHundreds | Score += A hundreds; every 10,000: +1 ship, smartbomb, inviso, sound |
| `$DD02` | BitMask | Table: 1 << n |
| `$DD12` | SpeedPattern | Table: movement bits by frame & 15 |
| `$DD22` | TypeSpeed | Table: speed bits by type |
| `$DD36` | DirDX | Table: X step by direction |
| `$DD47` | DirDY | Table: row step by direction |
| `$DD58` | ShotDY | Table: enemy shot row step by ShotDir |
| `$DD68` | ShotDX | Table: enemy shot X step by ShotDir |
| `$DDC4` | TypeHeight | Table: rows apart needed to share a frame, by type |
| `$DDD7` | HitType | Table: type after a hit (explosion $11; pod -> swarmers; swarmers 3 -> 2 -> 1) |
| `$DDE7` | BaiterTypes | Table: late spawn types (1,1,1,1,3,3,2,2) |
| `$DDEF` | ScoreHi | Table: points by type, hundreds (BCD) |
| `$DDFD` | ScoreLo | Table: points by type, ones (BCD) |
| `$DE0D` | CatchScore | Table: catching a falling humanoid, hundreds (5, 10, 15, 20...) |
| `$DE3D` | PlanetColours | Table: field colour by PlanetGone |
| `$DE5A` | StartRows | Table: objects' rows when (re)placed |
| `$DE6A` | StartX | Table: objects' X at power on |
| `$DE7A` | SoundData | Table: sound effects |
| `$DF7C` | WaveTables | Table: by wave digit, pointer to the 9 types of objects 6-14 (tables follow) |
| `$DFE0` | GroupTypes | Table: type of objects 0-5 by wave digit (9 landers, 5 dogfighters on digit 4, $0C firebombers on 9) |
| `$DFF2` | ToBank1 | Switch to bank 1 (continues at $F158) |
| `$F100` | Reset1 | Power on: switch to bank 0 (continues at $D103) |
| `$F118` | TitleScreen | No game: game over text while GameOverDelay, else the title text (INTIM waits) |
| `$F158` | KernelPrep | From bank 0: slot 0 = humanoid on the ground (or the ship explosion) |
| `$F1DC` | PrepSlots | Slots 1.. from the display list: X byte, page, pointers, animation frame |
| `$F255` | ScoreDigits | Score digit pointers pushed onto $F2-$FD with the stack, leading zeros blanked |
| `$F28E` | StartPicture | Wait for the timer; picture timer, VBLANK off, score band setup |
| `$F2D9` | ScoreBand | Score, then (in a game) ships, smartbombs, invisos |
| `$F322` | ScannerKernel | Scanner: 7 rows of 48 pixels from SuperChip, ball = ship's height |
| `$F393` | PositionObjects | Position ball, missile 1, missile 0, ship |
| `$F3C4` | FieldStart | Field colours, CXCLR; jump travel: no field |
| `$F400` | FieldKernel | Field kernel: ship, enemy slots, stars, enemy shot (PHP to ENAM0), laser row |
| `$F461` | NextSlot | Reposition player 0 for the next slot; store CXPPMM in SlotPos |
| `$F4CC` | LaserLine | The laser row: playfield writes mid-line; LaserSlot |
| `$F535` | NoField | No field drawn (jump travel, blanked screen, text screens): clear the slot counts |
| `$F53B` | KernelEnd | Wait for the timer, VBLANK on, back to bank 0 |
| `$F553` | WaveEndScreen | Wave end: wave number, bonus count (adds score here), next wave set up at the end |
| `$F66B` | IconRow | Point the text pointers at Y icons (max 6), rest blank |
| `$F900` | Text48 | Draw Y+1 rows of 48-pixel text from the six pointers (with colour A) |
| `$F904` | Text48Rows | Text48 without setting the colour |
| `$F92E` | ClearPlayers | GRP0/GRP1 off |
| `$F93E` | DigitPtr | Table: digit graphics low bytes |
| `$F948` | TypePage | Table: graphics/colour page by type |
| `$FA00` | TypeAnim | Table: animation speed by type |
| `$FAF4` | LoadTextPtrs | Load the six text pointers from $FA3B (Y = last byte) |
| `$FB00` | TypeGfx | Table: graphics low byte by type * 4 + frame |
| `$FB50` | TypeColours | Table: colour low byte by type * 4 + frame |
| `$FBD0` | XCodes | Table: X code -> coarse delay, late bit, fine motion |
| `$FE00` | StarsTable | Table: missile 1 / ball enable and size per row (mountains, stars) |
| `$FFF2` | ToBank0 | Switch to bank 0 (continues at $D16C) |
