; =================================================================== sound
; The game's TIA sound registers, translated to SID voices 1 and 2 once a frame.
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        beq _off
        ldy v1
        lda SidWave,y
        beq _off2
        sta tmp                 ; waveform
        lda v1                  ; frequency index = AUDC * 32 + AUDF
        lsr
        lsr
        lsr
        sta ptrA+1
        lda v1
        asl
        asl
        asl
        asl
        asl
        ora v2
        clc
        adc FreqTab
        sta ptrA
        lda ptrA+1
        adc FreqTab+1
        sta ptrA+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d400,y
        inc ptrA+1
        inc ptrA+1
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d401,y
        lda #0
        sta $d402,y
        sta $d405,y
        lda #8
        sta $d403,y
        lda v0                  ; volume becomes the sustain level
        asl
        asl
        asl
        asl
        sta $d406,y
        lda v0                  ; retrigger only when volume or waveform changes
        cmp SndLast,x
        bne +
        lda v1
        cmp SndLast+2,x
        beq _save
+       lda tmp
        sta $d404,y
        ora #1
        sta $d404,y
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts

; ================================================================== tables
Bit:        .byte $01, $02, $04, $08, $10, $20, $40, $80
SidVoice:   .byte 0, 7
PFRowLo:    .for p = 0, p < 44, p += 1
            .byte <(PFMASK + 24 * p)
            .next
PFRowHi:    .for p = 0, p < 44, p += 1
            .byte >(PFMASK + 24 * p)
            .next

PFColLo:    .for c = 0, c < 21, c += 1
            .byte <(PFCOL + 64 * c)
            .next
PFColHi:    .for c = 0, c < 21, c += 1
            .byte >(PFCOL + 64 * c)
            .next

; screen character for a cell from (top half on: $F0) | (bottom half on: $0F)
CellChar:   .for i = 0, i < 256, i += 1
            .byte ((i & $f0) != 0) | ((i & $0f) != 0) << 1
            .next

        .include "tables.inc"
        .include "hpos.inc"

; ------------------------------------------------------- variables (RAM)
DbgSWCHA:   .byte $ff           ; AND masks applied to the inputs (testing aid)
DbgINPT4:   .byte $ff
DbgSWCHB:   .byte $ff
DbgBorder:  .byte 0             ; non-zero: colour the border while drawing / running the game
DbgLoops:   .word 0             ; main loop passes
DbgLate:    .word 0             ; ... that found more than one frame gone by
DbgTops:    .byte 0             ; frame tops and score lines the interrupt has done
DbgDigits:  .byte 0
DbgDigRas:  .byte 0
DbgSprLate: .byte 0             ; sprite moves (robots 4-7, HMOVE bars, score line) written too late
DbgBarLost: .byte 0             ; HMOVE bars that can't be shown (under 22 lines after the last)
DbgRMax:    .word 0             ; the most cycles one pass spent drawing,
DbgTMax:    .word 0             ; ... running the game,
DbgPMax:    .word 0             ; ... in all
dbgT0:      .word 0
dbgT1:      .word 0
dbgNow:     .word 0
dbgTmp:     .word 0
FreqTab:    .word SidFreqLo     ; PAL or NTSC frequency tables
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0
Flicker:    .byte 1             ; 1: the humanoid and Evil Otto alternate like on the 2600 (key F)
PrevKeyF:   .byte $ff
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
SndLast:    .fill 6, $ff

; collisions
robIdx:     .byte 0
GetB:       .word 0
RobPX:      .fill 8             ; robots' left pixels
BandRow:    .fill 8             ; robot shot row that starts on each band's first line
BandSplit:  .fill 8             ; ... and the pixel where its new value takes effect
QuirkByte:  .fill 44
ColKey:     .fill 3, $ff        ; the room PFMASK holds
ROW:        .fill 24            ; a maze row as 2600 pixels (RowMask); the last 4 stay 0
ROWA:       .fill 20

; render
snTrans:    .byte 1             ; the last tick was a room change
snCurRec:   .byte 0
snColour:   .fill 4             ; COLUP0, COLUP1, COLUPF, COLUBK as the picture was drawn
RecHuman    = 0                 ; player 0 as last seen: top, bottom, pointer (2), vdel,
RecOtto     = 8                 ; reflect, pixel, age (ticks since)
Recs:       .fill 7, 0
            .byte 255
            .fill 7, 0
            .byte 255
mazeMode:   .byte 0
ScrKey:     .fill 4, $ff        ; the maze on screen: mode, offset, door, entry side
WallCol:    .byte $ff
CellPat:    .fill 23            ; column 1's maze cell on each row (bit 0 top, bit 1 bottom)
NotchMask:  .fill 23            ; HMOVE notch lines on each row (bit n: line n)
PrevNotch:  .fill 23, $ff       ; ... as its character has them
PrevRobY:   .fill 9, $ff        ; the robot rows those were worked out for
BarLine:    .fill 8             ; HMOVE bar lines this frame
BarY:       .fill 16            ; sprite 1's later positions (8 * buffer + segment) ...
BarPtr:     .fill 16            ; ... and shapes
PrevBarLine: .byte 0
irqIns:     .fill 4             ; SchedInsert's scratch
rbuf:       .byte 0
schedIdx:   .byte 0
sprN:       .byte 0
sprY:       .byte 0
sprPix:     .byte 0
srcRow:     .byte 0
srcN:       .byte 0
srcMask:    .byte 0
refl:       .byte 0
digit:      .byte 0
k0:         .byte 0             ; sprite block keys: what a block holds
k1:         .byte 0
k2:         .byte 0
k3:         .byte 0
BlkKey:     .fill 4 * 2 * NBLK, $ff
BlkN:       .fill 2 * NBLK, 0   ; rows of each block that may be non-blank
dbl:        .byte 0             ; FillBlock: each source row twice
outRows:    .byte 0
BlockRow:   .for r = 0, r < 21, r += 1   ; offset of each sprite row in a block
            .byte 3 * r
            .next
m0rowF:     .byte $ff           ; the shots' rows, from Collide
m0rowL:     .byte 0
m1rowF:     .byte $ff
m1rowL:     .byte 0
pfcRow:     .byte $ff           ; GetPF's last answer
pfcX:       .byte 0
pfcVal:     .byte 0
DgKey:      .fill 24, $ff      ; the score pointers each buffer's blocks hold

; staged frames (two buffers): sprite values for the frame top ...
StX:        .fill 16
StY:        .fill 16
StPtr:      .fill 16
StCol:      .fill 16
StMsb:      .fill 2
StEn:       .fill 2
StYexp:     .fill 2
StBg:       .fill 2
LastBg:     .byte 0             ; the colour last written to $D021 (InitVideo: black)
StD018:     .fill 2, D018BLANK
; ... robots 4-7, the score line, and the schedule
RbX:        .fill 16
RbY:        .fill 16
RbPtr:      .fill 16
RbMsb:      .fill 16
DgPtr:      .fill 2, BLK_BLANK
DgCol:      .fill 2
SchedRas:   .fill 2 * NSCHED
SchedType:  .fill 2 * NSCHED
SchedArg:   .fill 2 * NSCHED

; ======================================================= the 2600 program
; The original ROM, copied to $F000 at start-up, with these changes:
;   $F2C5  JSR OttoHit           shot stuns Evil Otto: CXCLR clears our latches
;   $F502  JMP $F50C             skip VBLANK/VSYNC (writing $00/$01 would remap C64 memory)
;   $F51A  STY $02               (was STY VSYNC)
;   $F83A  JMP KernelHook        stop where the 2600 would draw the picture
;   $F901  JSR PlaceRobots       the 2600 stack's leftovers in $FC/$FD
;   $F92A  JMP TransHook         ... and the room-change picture
;   $F9B1  NOP                   (was TXS: keep the C64's stack)
;   $F9B4  JSR ClearZP           clear the 2600 RAM, not the C64's zero page
ROM = "../build/original.a26"     ; extracted from roms_port by build.cmd
GameImage:
        .binary ROM, $0000, $02c5
        jsr OttoHit
        nop
        nop
        nop
        .binary ROM, $02cb, $0502-$02cb
        jmp $f50c
        .binary ROM, $0505, $051a-$0505
        .byte $02
        .binary ROM, $051b, $083a-$051b
        jmp KernelHook
        .binary ROM, $083d, $0901-$083d
        jsr PlaceRobots
        .binary ROM, $0904, $092a-$0904
        jmp TransHook
        .binary ROM, $092d, $09b1-$092d
        nop
        .binary ROM, $09b2, $09b4-$09b2
        jsr ClearZP
        nop
        nop
        .binary ROM, $09b9, $1000-$09b9
        .cerror * - GameImage != $1000, "the 2600 image must be 4K"
