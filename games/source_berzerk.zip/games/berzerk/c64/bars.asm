; ============================================================ HMOVE bars
; The 2600 blanks the first 8 pixels of each line where the kernel strobes HMOVE
; (the line above each robot, 2Y + 38): black, whatever the background colour.
; The left wall's characters already have those lines cut out (Notches); against
; a coloured background (attract mode) the bars also need to be black, so sprite 1
; draws them when Evil Otto isn't using it: one line at the left edge, moved down
; the screen by the raster schedule. Robots ten rows apart give bars exactly 20
; lines apart, which one 21-line sprite shows at once (block BLK_BAR2).
Bars:
        lda snColour+3          ; on a black background the notches in the wall are enough
        lsr
        tay
        lda ColorMap,y
        bne +
        rts
+       lda Flicker             ; sprite 1 is Evil Otto's with flicker off (while he's about)
        bne +
        lda Recs+RecOtto+7
        cmp #3
        bcs +
        rts
+       ldx #0                  ; bar lines of the robots, top to bottom (from line 39)
        ldy #0
-       cpx nRob
        bcs _segs
        lda RobotY,x
        asl
        clc
        adc #38
        cmp #39
        bcc +
        sta BarLine,y
        iny
+       inx
        jmp -
_segs   sty v3                  ; bars
        lda #0
        sta v4                  ; next bar
        sta v5                  ; segments so far
_seg    lda v4
        cmp v3
        bcc +
        rts
+       tax
        lda BarLine,x
        sta tmp                 ; this segment's first line
        lda #BLK_BAR1
        sta tmp2
        inx
        cpx v3                  ; the next bar exactly 20 lines on: in the same sprite
        bcs +
        lda BarLine,x
        sec
        sbc tmp
        cmp #20
        bne +
        lda #BLK_BAR2
        sta tmp2
        inx
+       stx v4
        lda tmp                 ; sprite Y
        clc
        adc #SPRYOFS
        sta sprY
        lda v5
        bne _later
        ldx bufOfs              ; the first: staged for the frame top
        lda sprY
        sta StY+1,x
        lda tmp2
        sta StPtr+1,x
        lda #24                 ; pixel 0
        sta StX+1,x
        lda #0
        sta StCol+1,x           ; black
        ldy rbuf
        lda StEn,y
        ora #2
        sta StEn,y
        lda StYexp,y            ; one line per row
        and #$fd
        sta StYexp,y
        lda StMsb,y
        and #$fd
        sta StMsb,y
        jmp _next
_later  lda PrevBarLine          ; (testing aid: under 22 lines after the last start the VIC
        clc                     ; can't start the sprite again: that bar is lost)
        adc #22
        cmp tmp
        beq +
        bcc +
        inc DbgBarLost
+       lda v5                  ; the others: moved there by the interrupt on the previous
        clc                     ; segment's last line (row 20: its data has been fetched, and
                                ; a bar on the very next line can still start)
        adc bufOfs
        tay                     ; Y = 8 * buffer + segment
        lda sprY
        sta BarY,y
        lda tmp2
        sta BarPtr,y
        tya
        tax
        lda PrevBarLine
        clc
        adc #20 + RASTEROFS
        ldy #S_BAR
        jsr SchedInsert
_next   lda tmp
        sta PrevBarLine
        inc v5
        jmp _seg

; Insert schedule entry: raster A, type Y, argument X, before the first later
; entry of this buffer's schedule (after entry 0, the frame top).
SchedInsert:
        sta irqIns
        sty irqIns+1
        stx irqIns+2
        lda rbuf
        asl
        asl
        asl
        asl
        tax
        inx                     ; first entry after the frame top
-       cpx schedIdx
        bcs _put
        lda SchedRas,x
        cmp irqIns
        bcs _shift
        inx
        bne -
_shift  stx irqIns+3              ; move entries x..schedIdx-1 up one
        ldy schedIdx
-       dey
        lda SchedRas,y
        sta SchedRas+1,y
        lda SchedType,y
        sta SchedType+1,y
        lda SchedArg,y
        sta SchedArg+1,y
        cpy irqIns+3
        bne -
        ldx irqIns+3
_put    lda irqIns
        sta SchedRas,x
        lda irqIns+1
        sta SchedType,x
        lda irqIns+2
        sta SchedArg,x
        inc schedIdx
        rts
