; Record A (offset in Recs) as sprite X (0 or 1): its rows from P0Top to P0Bottom.
ShowRec:
        stx sprN
        tay
        lda Recs+0,y            ; top row
        cmp #$58
        bcs _out                ; not in the picture
        sta srcRow
        sta k2
        lda Recs+1,y
        sec
        sbc srcRow
        sta srcN
        lda Recs+2,y
        sta ptrA
        sta k0
        lda Recs+3,y
        sta ptrA+1
        sta k1
        lda Recs+5,y
        sta refl
        ora srcN
        sta k3
        lda #0
        sta srcMask
        lda Recs+0,y            ; Y register: 2 * top + 38 + vdel
        asl
        clc
        adc #38 + SPRYOFS
        adc Recs+4,y
        sta sprY
        lda Recs+6,y
        sta sprPix
        lda sprN
        clc
        adc blkOfs              ; blocks B_HUMAN and B_OTTO are 0 and 1
        jsr FillBlock
        jsr PutSprite
_out    rts

; The shots (sprites 2 and 3): their enabled rows, 2 lines each.
RenderShots:
        lda snColour+0          ; (COLUP0)
        lsr
        tay
        lda ColorMap,y
        ldx bufOfs
        sta StCol+2,x
        lda snColour+1          ; (COLUP1)
        lsr
        tay
        lda ColorMap,y
        sta StCol+3,x
        ldx m0rowF              ; the humanoid's shot (rows found by Collide), top line 2 * row + 36
        ldy m0rowL
        cpx #$ff
        beq +
        lda m0mask
        sta srcMask
        lda #36 + SPRYOFS
        sta tmp
        lda #2
        sta sprN
        lda m0x
        sta sprPix
        lda M0Ptr
        sta ptrA
        lda M0Ptr+1
        sta ptrA+1
        jsr ShowShot
+       ldx m1rowF              ; the robot shot, top line 2 * row + 35
        ldy m1rowL
        cpx #$ff
        beq +
        lda m1mask
        sta srcMask
        lda #35 + SPRYOFS
        sta tmp
        lda #3
        sta sprN
        lda m1x
        sta sprPix
        lda M1Ptr
        sta ptrA
        lda M1Ptr+1
        sta ptrA+1
        jsr ShowShot
+       rts

; Rows X..Y of the missile table at ptrA, top line offset tmp, pixels srcMask.
ShowShot:
        stx srcRow
        stx k1
        txa
        asl
        clc
        adc tmp
        sta sprY
        tya
        sec
        sbc srcRow
        clc
        adc #1
        sta srcN
        eor srcMask
        sta k3
        lda ptrA
        sta k0
        lda ptrA+1
        sta k2
        lda #0
        sta refl
        lda sprN
        clc
        adc blkOfs              ; blocks B_M0 and B_M1 are 2 and 3
        jsr FillBlock
        jmp PutSprite

; Robots: 9 rows of 2 lines each. Robots 0-3 use sprites 4-7 from the top; robot n
; (4-7) reuses robot n-4's sprite once that one has been drawn.
RenderRobots:
        lda snColour+1          ; (COLUP1)
        lsr
        tay
        lda ColorMap,y
        ldx bufOfs
        sta StCol+4,x
        sta StCol+5,x
        sta StCol+6,x
        sta StCol+7,x
        lda #<RobotShapes
        sta ptrA
        lda #>RobotShapes
        sta ptrA+1
        lda #9
        sta srcN
        lda #1                  ; (rows doubled: see FillBlock)
        sta dbl
        lda #0
        sta refl
        sta srcMask
        sta k2
        sta k3
        lda #$fe
        sta k1
        ldx #0
_rob    cpx nRob
        bcc +
        lda #0
        sta dbl
        rts
+       stx robIdx
        lda RobotGfx,x
        sta srcRow
        sta k0
        lda RobotY,x            ; Y register: 2 * Y + 39
        asl
        clc
        adc #39 + SPRYOFS
        sta sprY
        lda RobPX,x
        sta sprPix
        txa
        clc
        adc #B_ROBOT
        adc blkOfs
        jsr FillBlock
        ldx robIdx
        cpx #4
        bcs _late
        txa
        ora #4
        sta sprN
        lda tmp                 ; (the block, from FillBlock)
        jsr PutSprite
        jmp _nextr
_late   lda robIdx              ; robots 4-7: staged for the interrupt
        clc
        adc bufOfs
        tay                     ; Y = 8 * buffer + robot
        lda tmp                 ; (the block, from FillBlock)
        sta RbPtr,y
        lda sprY
        sta RbY,y
        lda sprPix              ; X: 24 + 2 * pixel
        jsr SprX
        sta RbX,y
        lda #0
        bcc +
        lda robIdx              ; bit 8 for its sprite (4-7)
        and #3
        tax
        lda Bit+4,x
+       sta RbMsb,y
        ldx robIdx              ; the interrupt: after robot n-4's last line
        lda RobotY-4,x
        asl
        clc
        adc #57 + RASTEROFS
        ldx schedIdx
        sta SchedRas,x
        lda #S_ROBOT
        sta SchedType,x
        tya
        sta SchedArg,x
        inc schedIdx
_nextr  ldx robIdx
        inx
        cpx #8
        beq +
        jmp _rob
+       lda #0
        sta dbl
        rts

; The score line: six 8-pixel characters from the DigitPtr pointers, 7 lines
; (stored upside down), on sprites 4 and 5 below the play area. Redrawn only
; when the pointers change.
RenderDigits:
        lda AttractCol          ; the kernel colours it $1C EOR AttractCol
        eor #$1c
        lsr
        tay
        lda ColorMap,y
        ldx rbuf
        sta DgCol,x
        lda blkOfs
        clc
        adc #B_DIGITS
        sta DgPtr,x
        jsr _entry              ; (the schedule entry, whether or not the shapes change)
        lda rbuf                ; the same pointers as this buffer last had?
        beq +
        lda #12
+       tax
        ldy #0
-       lda DigitPtr,y
        cmp DgKey,x
        bne _draw
        inx
        iny
        cpy #12
        bne -
        rts
_draw   lda rbuf
        beq +
        lda #12
+       tax
        ldy #0
-       lda DigitPtr,y
        sta DgKey,x
        inx
        iny
        cpy #12
        bne -
        ldx rbuf
        lda DgPtr,x
        jsr BlockPtr            ; ptrB = first block, ptrA = second
        lda ptrB
        clc
        adc #64
        sta ptrA
        lda ptrB+1
        adc #0
        sta ptrA+1
        lda #0
        sta digit
_dig    lda digit
        asl
        tax
        lda DigitPtr,x
        sta ptrC
        lda DigitPtr+1,x
        sta ptrC+1
        lda digit               ; digits 0-2 in the first block, 3-5 in the second
        ldx ptrB
        ldy ptrB+1
        cmp #3
        bcc +
        sbc #3
        ldx ptrA
        ldy ptrA+1
+       stx ptrD
        sty ptrD+1
        sta tmp2                ; byte within the sprite row
        lda #6
        sta srcRow              ; source row 6 is the top line
-       ldy srcRow
        lda (ptrC),y
        ldy tmp2
        sta (ptrD),y
        lda tmp2
        clc
        adc #3
        sta tmp2
        dec srcRow
        bpl -
        inc digit
        lda digit
        cmp #6
        bne _dig
        rts
_entry  ldx schedIdx              ; (line 213: robots are done by then, and the VIC
        lda #DIGITLINE - 5 + RASTEROFS ; sees the new Y position in time even after a badline)
        sta SchedRas,x
        lda #S_DIGITS
        sta SchedType,x
        inc schedIdx
        rts

; ------------------------------------------------------------ sprite helpers
; Fill sprite block A from (ptrA) + srcRow: srcN rows, the rest blank; bits
; reversed if refl; with srcMask set, a missile table (bit 1 on = srcMask).
; Skipped if the block already holds this (key k0-k3). Keeps A in tmp.
FillBlock:
        sta tmp
        sec
        sbc #BLK_SET
        asl
        asl
        tax                     ; key offset: 4 * block (both sets)
        lda k0
        cmp BlkKey,x
        bne _new
        lda k1
        cmp BlkKey+1,x
        bne _new
        lda k2
        cmp BlkKey+2,x
        bne _new
        lda k3
        cmp BlkKey+3,x
        bne _new
        lda tmp
        rts
_new    lda k0
        sta BlkKey,x
        lda k1
        sta BlkKey+1,x
        lda k2
        sta BlkKey+2,x
        lda k3
        sta BlkKey+3,x
        lda srcN                ; sprite rows: one per source row, or two with dbl
        ldx dbl
        beq +
        asl
+       sta outRows
        lda tmp                 ; rows to write: this shape's, or the last one's if taller
        sec
        sbc #BLK_SET
        tax
        lda outRows
        cmp BlkN,x
        bcs +
        lda BlkN,x
+       sta v5
        lda outRows
        sta BlkN,x
        lda tmp
        jsr BlockPtr
        lda dbl                 ; robots: each row twice (they are drawn without Y expansion,
        beq _single             ; so a sprite is free again 21 lines after it starts)
        ldy srcRow
        ldx #0
-       cpx outRows
        bcs _zeros
        lda (ptrA),y
        sty v3
        ldy BlockRow,x
        sta (ptrB),y
        ldy BlockRow+1,x
        sta (ptrB),y
        ldy v3
        iny
        inx
        inx
        bne -
_single lda srcMask             ; plain rows (an unreflected humanoid): a quick copy
        ora refl
        bne _slow
        ldy srcRow
        ldx #0
-       cpx srcN
        bcs _zeros
        lda (ptrA),y
        sty v3
        ldy BlockRow,x
        sta (ptrB),y
        ldy v3
        iny
        inx
        bne -
_zeros  cpx v5
        bcs _fast
        ldy BlockRow,x
        lda #0
        sta (ptrB),y
        inx
        bne _zeros
_fast   lda tmp
        rts
_slow   lda #0                  ; row
        sta v3
        lda #0                  ; offset in the block
        sta v4
_row    lda #0
        ldx v3
        cpx srcN
        bcs _put
        txa
        clc
        adc srcRow
        tay
        lda (ptrA),y
        ldx srcMask
        beq +
        and #2                  ; a missile table: bit 1 enables it
        beq _put
        txa
        jmp _put
+       ldx refl
        beq _put
        tay
        lda REVERSE,y
_put    ldy v4
        sta (ptrB),y
        iny
        iny
        iny
        sty v4
        inc v3
        lda v3
        cmp v5
        bcc _row
        lda tmp
        rts

; ptrB = the address of sprite block A.
BlockPtr:
        pha
        lsr
        lsr
        clc
        adc #>VICBANK
        sta ptrB+1
        pla
        and #3
        lsr
        ror
        ror
        sta ptrB
        rts

; A = 2600 pixel -> A = low byte of the sprite X register (24 + 2 * pixel), carry = bit 8.
SprX:
        asl
        bcs _hi
        adc #24
        rts
_hi     adc #24 - 1             ; (carry was set)
        sec
        rts

; Block A becomes sprite sprN at sprY / pixel sprPix, enabled.
PutSprite:
        sta tmp
        lda sprN
        clc
        adc bufOfs
        tax
        lda tmp
        sta StPtr,x
        lda sprY
        sta StY,x
        lda sprPix
        jsr SprX
        sta StX,x
        ldy rbuf
        ldx sprN
        bcc +
        lda Bit,x
        ora StMsb,y
        sta StMsb,y
+       lda Bit,x
        ora StEn,y
        sta StEn,y
        rts
