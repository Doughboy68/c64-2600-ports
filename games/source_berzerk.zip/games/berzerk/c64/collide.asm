; ============================================================== collisions
; What the TIA would have reported for the picture the game is about to draw,
; from the same rules as tools/model.js (which matches the 2600 pixel for pixel,
; quirks included): the collision latches the game reads at $30-$37, and the
; latches the kernel saves at each robot band in RobotHit: +0 nothing, +1+n the
; collisions so far after robot n (bit 7: a robot hit the maze, the humanoid's
; shot or player 0; bit 0: a robot hit the robot shot). Lines 40-214 count (the
; kernel clears the latches at line 40).
;
; Objects are compared line by line by PairTest. Each object has a Get routine:
; for 2600 line lineL it returns the object's 8 pixels in A (bit 7 leftmost,
; 0 = nothing there) and its left pixel in X.
Collide:
        lda MazeOffset          ; a new room: rebuild the maze bitmap
        cmp ColKey
        bne +
        lda LeftDoor
        cmp ColKey+1
        bne +
        lda EntrySide
        cmp ColKey+2
        beq ++
+       jsr BuildPFMask
+       lda #$ff                ; forget GetPF's last answer
        sta pfcRow
        lda #0
        ldx #7
-       sta CXM0P,x
        dex
        bpl -
        jsr SetupP0
        jsr SetupRobots
        jsr SetupMissiles

        ; player 0 (humanoid or Evil Otto) against the maze
        lda p0first
        ldx p0last
        jsr Range
        bcs +
        lda p0x
        jsr PFAny
        beq +
        lda #<GetP0
        ldx #>GetP0
        jsr PairTestPF
        beq +
        lda #$80
        sta CXP0FB
+       ; the shots against the maze
        lda m0first
        ldx m0last
        jsr Range
        bcs +
        lda m0x
        jsr PFAny
        beq +
        lda #<GetM0
        ldx #>GetM0
        jsr PairTestPF
        beq +
        lda #$80
        sta CXM0FB
+       lda m1first
        ldx m1last
        jsr Range
        bcs +
        lda m1x
        jsr PFAny
        beq +
        lda #<GetM1
        ldx #>GetM1
        jsr PairTestPF
        beq +
        lda #$80
        sta CXM1FB
+       ; the shots against player 0 and each other
        lda m0x
        ldx p0x
        jsr Near
        bcs +
        lda m0first
        ldx m0last
        ldy #p0first
        jsr Range2
        bcs +
        lda #<GetP0
        sta GetB
        lda #>GetP0
        sta GetB+1
        lda #<GetM0
        ldx #>GetM0
        jsr PairTest
        beq +
        lda #$40                ; M0-P0
        ora CXM0P
        sta CXM0P
+       lda m1first
        ldx m1last
        ldy #p0first
        jsr Range2
        bcs +
        lda m1x
        ldx p0x
        jsr Near
        bcs +
        lda #<GetP0
        sta GetB
        lda #>GetP0
        sta GetB+1
        lda #<GetM1
        ldx #>GetM1
        jsr PairTest
        beq +
        lda #$80                ; M1-P0
        ora CXM1P
        sta CXM1P
+       lda m0first
        ldx m0last
        ldy #m1first
        jsr Range2
        bcs +
        lda m0x
        ldx m1x
        jsr Near
        bcs +
        lda #<GetM1
        sta GetB
        lda #>GetM1
        sta GetB+1
        lda #<GetM0
        ldx #>GetM0
        jsr PairTest
        beq +
        lda #$40                ; M0-M1
        ora CXPPMM
        sta CXPPMM
+
        ; the robots, top to bottom
        lda #0
        sta latch
        sta RobotHit
        ldx #0
_robot  cpx nRob
        bne +
        jmp _robEnd
+       stx robIdx
        lda RobotY,x            ; this robot's lines, left pixel, graphics
        sta robY
        asl
        clc
        adc #39
        sta rTop
        adc #17
        sta rBot
        lda RobPX,x
        sta rX
        lda RobotGfx,x
        sta rGfx
        lda #0
        sta bits

        lda CXP1FB              ; against the maze (no need once both results are set)
        and latch
        bmi +
        lda rTop
        ldx rBot
        jsr Range
        bcs +
        lda rX
        jsr PFAny               ; no maze near it: nothing to test
        beq +
        jsr RobotPF
        beq +
        lda #$80                ; P1-PF
        sta CXP1FB
        sta bits
+       lda CXPPMM              ; against player 0
        and latch
        bmi +
        lda rX
        ldx p0x
        jsr Near
        bcs +
        lda rTop
        ldx rBot
        ldy #p0first
        jsr Range2
        bcs +
        lda #<GetP0
        sta GetB
        lda #>GetP0
        sta GetB+1
        lda #<GetP1
        ldx #>GetP1
        jsr PairTest
        beq +
        lda #$80                ; P0-P1
        ora CXPPMM
        sta CXPPMM
        lda #$80
        ora bits
        sta bits
+       lda CXM0P               ; against the humanoid's shot
        and latch
        bmi +
        lda rX
        ldx m0x
        jsr Near
        bcs +
        lda rTop
        ldx rBot
        ldy #m0first
        jsr Range2
        bcs +
        lda #<GetM0
        sta GetB
        lda #>GetM0
        sta GetB+1
        lda #<GetP1
        ldx #>GetP1
        jsr PairTest
        beq +
        lda #$80                ; M0-P1
        ora CXM0P
        sta CXM0P
        lda #$80
        ora bits
        sta bits
+       lda latch               ; against the robot shot
        and #1
        beq +
        bit CXM1P
        bvs ++
+       lda rTop
        ldx rBot
        ldy #m1first
        jsr Range2
        bcs +
        lda rX
        ldx m1x
        jsr Near
        bcs +
        lda #<GetM1
        sta GetB
        lda #>GetM1
        sta GetB+1
        lda #<GetP1
        ldx #>GetP1
        jsr PairTest
        beq +
        lda #$40                ; M1-P1
        ora CXM1P
        sta CXM1P
        lda #$01
        ora bits
        sta bits
+       lda latch               ; the kernel saves the collisions so far at the next band
        ora bits
        sta latch
        ldx robIdx
        sta RobotHit+1,x
        inx
        jmp _robot
_robEnd

        ; P0Gfx as the kernel leaves it: the last row of player 0 it loaded
        lda P0Top
        cmp #$58
        bcs _noP0
        ldy P0Bottom
        dey
        cpy #$57
        bcc +
        ldy #$57
+       lda (P0Ptr),y
        sta P0Gfx
        rts
_noP0   lda #0
        sta P0Gfx
        rts

; The robot being tested against the maze, a row (2 lines) at a time: both lines
; are in the same maze row, which only differs on the second line by the quirk
; (when that is the last line of maze row 0-41). Z clear if they touch.
RobotPF:
        lda rX
        lsr
        lsr
        lsr
        sta v1                  ; byte of the maze row under the robot's left pixel
        ldx #0
_row    stx v3                  ; robot row 0-8
        txa
        clc
        adc rGfx
        tay
        lda RobotShapes,y
        beq _next
        sta ba
        lda robY
        clc
        adc v3
        sta v4                  ; Y + row: odd if the second line is a quirk line
        lsr
        tay                     ; maze row: (2 * (Y + row)) / 4
        cpy #44
        bcs _next
        sty v5
        lda PFRowLo,y
        sta ptrA
        lda PFRowHi,y
        sta ptrA+1
        ; first line (it doesn't count if it is line 39: row 0 of a robot at Y = 0)
        lda v3
        ora robY
        beq _second
        jsr _plain
        bne _hit
        ; second line: the same maze row, unless it is a quirk line
_second jsr _isQuirk
        bcs _q
        lda v3                  ; (not a quirk line: already tested, unless the first was skipped)
        ora robY
        bne _next
        jsr _plain
        bne _hit
        beq _next
_q      jsr _quirk
        bne _hit
_next   ldx v3
        inx
        cpx #9
        bcc _row
        lda #0
        rts
_hit    lda #1
        rts

_plain  ldy v1                  ; the maze row's pixels from rX
        lda (ptrA),y
        sta v0
        iny
        lda (ptrA),y
        sta tmp2
        ora v0
        beq _none
        jmp _test
_quirk  ldy v1                  ; the same with byte 17 from the quirk byte
        lda (ptrA),y
        sta v0
        iny
        lda (ptrA),y
        sta tmp2
        ldy v5
        lda v1
        cmp #17
        bne +
        lda QuirkByte,y
        sta v0
        jmp _test
+       lda QuirkByte,y         ; (v1 = 16: byte 17 is the second)
        sta tmp2
_test   lda rX                  ; shift the 16 maze pixels by rX & 7 and compare
        and #7
        tax
        beq +
-       asl tmp2
        rol v0
        dex
        bne -
+       lda v0
        and ba
        rts
_none   lda #0
        rts
_isQuirk                        ; carry set if the second line is a quirk line that matters:
        lda v4                  ; Y + row odd, maze row 0-41, and bytes 16-17 under the robot
        lsr
        bcc _no
        lda v5
        cmp #42
        bcs _no
        lda v1
        cmp #16
        beq _yes
        cmp #17
        beq _yes
_no     clc
        rts
_yes    sec
        rts

; ---------------------------------------------------------- object setup
SetupP0:                        ; humanoid or Evil Otto, whichever the game set up
        lda P0Ptr+1
        cmp #$fe
        bne +
        lda OttoX
        jmp ++
+       lda HumanX
+       clc
        adc #3
        sta p0x
        lda VDELP0              ; odd Y: delayed a line
        and #1
        sta p0vdel
        lda REFP0
        and #8
        sta p0refl
        lda #$ff                ; nothing (first > last) ...
        sta p0first
        lda #0
        sta p0last
        lda P0Top
        cmp #$58
        bcs _done               ; ... unless it starts in the picture
        asl                     ; first line: 2 * top + 38 + vdel
        adc #38
        adc p0vdel
        sta p0first
        ldy P0Bottom            ; last line: 212 if its last row isn't blank (the kernel
        dey                     ; keeps showing that row to the bottom of the play area),
        lda (P0Ptr),y           ; else the end of that row
        beq +
        lda #212
        bne ++
+       lda P0Bottom
        asl
        adc #37
        adc p0vdel
+       sta p0last
_done   rts

; The robots' left pixels, and where each band starts for the robot shot's quirk.
SetupRobots:
        ldx #0
_rob    lda RobotY,x
        cmp #$7f
        beq _end
        ldy #0                  ; late (3 pixels) if the band starts inside player 0's rows
        cmp P0Top               ; and reading player 0's graphics there crosses a page
        bcc +
        cmp P0Bottom
        bcs +
        clc
        adc P0Ptr
        bcc +
        ldy #3
+       sty tmp
        lda RobotX,x
        clc
        adc #6
        adc tmp
        sta RobPX,x
        lda RobotY,x            ; the robot shot's row that starts on the band's first line
        clc
        adc #1
        sta BandRow,x
        lda RobotDelay,x        ; and the pixel where its new value takes effect:
        bmi +                   ; 31 + 15 * delay (or 4 for negative delays), + late
        asl
        asl
        asl
        asl
        sec
        sbc RobotDelay,x
        clc
        adc #31
        jmp ++
+       lda #4
+       clc
        adc tmp
        sta BandSplit,x
        inx
        cpx #8
        bne _rob
_end    stx nRob
        rts

; The shots: rows enabled in their tables, left pixel, width.
SetupMissiles:
        ldx ShotX               ; (X + 2, wrapping unevenly past 157: see hpos.inc)
        lda MissilePos,x
        sta m0x
        lda NUSIZ0
        lsr
        lsr
        lsr
        lsr
        and #3
        tax
        lda WidthMask,x
        sta m0mask
        lda #<M0Ptr
        ldy #3                  ; the kernel's first M0 row
        jsr ScanRows
        stx m0rowF              ; (rows, for the renderer)
        sty m0rowL
        stx m0first             ; lines 2f+36 .. 2l+37
        sty m0last
        cpx #$ff
        beq +
        txa
        asl
        adc #36
        sta m0first
        tya
        asl
        adc #37
        sta m0last
+       ldx RobotShotX
        lda MissilePos,x
        sta m1x
        lda NUSIZ1
        lsr
        lsr
        lsr
        lsr
        and #3
        tax
        lda WidthMask,x
        sta m1mask
        lda #<M1Ptr
        ldy #4                  ; the kernel's first M1 row
        jsr ScanRows
        stx m1rowF
        sty m1rowL
        stx m1first             ; lines 2f+35 .. 2l+37 (a line more for the band quirk)
        sty m1last
        cpx #$ff
        beq +
        txa
        asl
        adc #35
        sta m1first
        tya
        asl
        adc #37
        sta m1last
+       rts

; Rows Y..$56 of the missile table at the zero-page pointer A whose bit 1 is set:
; X = first, Y = last (X = $FF, Y = 0 for none). The game's tables are in page $FB,
; where only $5A-$5C and $B2 have bit 1 set: work the rows out from those, unless
; the pointer is elsewhere or the rows reach into the next page (then look at each).
ScanRows:
        sty v2                  ; first row allowed
        tax
        lda $01,x
        bne +
        lda $00,x               ; pointing at page zero: on the 2600, rows below $80 read the
        cmp #$80 - $56          ; TIA (bit 1 always 0), so none of these rows can be on
        bcs _slow
        ldx #$ff
        ldy #0
        rts
+       cmp #>PF0Tab
        bne _slow
        lda $00,x
        cmp #$100 - $57
        bcs _slow
        sta v1                  ; pointer low byte
        lda #$ff
        sta v0                  ; first found
        lda #0
        sta tmp                 ; last found
        ldy #3
-       lda EnableOfs,y         ; row = offset - pointer, if in v2..$56
        sec
        sbc v1
        bcc +
        cmp v2
        bcc +
        cmp #$57
        bcs +
        cmp v0
        bcs ++
        sta v0
+
+       cmp tmp
        bcc +
        cmp #$57
        bcs +
        cmp v2
        bcc +
        sta tmp
+       dey
        bpl -
        ldx v0
        ldy tmp
        rts
_slow   txa
        ldy v2
        jmp ScanRowsAll
EnableOfs:  .byte $5a, $5b, $5c, $b2

ScanRowsAll:
        sta _p1+1
        sta _p2+1
        ldx #$ff
-
_p1     lda ($00),y
        and #2
        bne _found
        iny
        cpy #$57
        bcc -
        ldy #0
        rts
_found  tya
        tax                     ; first
        sta tmp                 ; last so far
-       iny
        cpy #$57
        bcs +
_p2     lda ($00),y
        and #2
        beq -
        sty tmp
        jmp -
+       ldy tmp
        rts

; Is there any maze at all under the 16 pixels from (A & ~7) on lines pLo..pHi?
; Z set if not: then nothing 8 pixels wide at A can touch it there. (PFCOL holds,
; for each 8-pixel column and maze row, that byte ORed with the next, quirk included.)
PFAny:
        lsr
        lsr
        lsr
        tax                     ; the 8-pixel column
        lda PFColLo,x
        sta ptrA
        lda PFColHi,x
        sta ptrA+1
        lda pHi
        sec
        sbc #39
        lsr
        lsr
        sta v2                  ; last maze row
        lda pLo
        sec
        sbc #39
        lsr
        lsr
        tay                     ; first maze row
        lda #0
-       ora (ptrA),y
        cpy v2
        iny
        bcc -
        and #$ff
        rts

; ------------------------------------------------------------ line tests
; Clip the line range A..X to the lines that count (40-214) into pLo..pHi.
; Carry set: nothing left.
Range:
        cmp #40
        bcs +
        lda #40
+       cpx #215
        bcc +
        ldx #214
+       sta pLo
        stx pHi
        cpx pLo
        bcc +
        clc
        rts
+       sec
        rts

; The same for the overlap of A..X with the range at zero-page address Y.
Range2:
        sta pLo
        stx pHi
        lda $00,y
        cmp pLo
        bcc +
        sta pLo
+       lda $01,y
        cmp pHi
        bcs +
        sta pHi
+       lda pLo
        ldx pHi
        jmp Range

; Carry set if pixels A and X are 8 or more apart (objects that can't touch).
Near:
        stx tmp
        sec
        sbc tmp
        bcs +
        eor #$ff
        adc #1
+       cmp #8
        rts

; Do objects A (Get routine at A/X) and B (at GetB) share a pixel on any line
; pLo..pHi? Z clear if so.
PairTestPF:
        ldy #<GetPF
        sty GetB
        ldy #>GetPF
        sty GetB+1
PairTest:
        sta _a+1
        stx _a+2
        lda GetB
        sta _b+1
        lda GetB+1
        sta _b+2
        lda pLo
        sta lineL
_a      jsr $ffff
        beq _next
        sta ba
        stx xa
_b      jsr $ffff
        beq _next
        sta bb
        stx xb
        jsr Overlap
        bne _hit
_next   lda lineL
        cmp pHi
        bcs _miss
        inc lineL
        jmp _a
_miss   lda #0
        rts
_hit    lda #1
        rts

; Do ba at pixel xa and bb at pixel xb share a pixel? Z clear if so.
Overlap:
        lda xb
        sec
        sbc xa
        bcc _neg
        cmp #8
        bcs _no
        tax                     ; B is d pixels right of A: move A's pixels left by d
        lda ba
        cpx #0
        beq +
-       asl
        dex
        bne -
+       and bb
        rts
_neg    eor #$ff
        adc #1
        cmp #8
        bcs _no
        tax
        lda bb
        cpx #0
        beq +
-       asl
        dex
        bne -
+       and ba
        rts
_no     lda #0
        rts

; ------------------------------------------------- the objects, line by line
; Player 0: rows of 2 lines from 2 * P0Top + 38 (+1 with VDELP0). Past its last
; row the kernel keeps showing that row; it stops after line 212. With VDELP0,
; line 211 shows row 85 and line 212 row 87 (the kernel's last lines go differently).
GetP0:
        lda lineL
        cmp #213
        bcs _none
        sec
        sbc #38
        bcc _none
        sec
        sbc p0vdel
        bcc _none
        lsr
        ldx p0vdel              ; with VDELP0 the kernel's last lines go differently:
        beq ++                  ; line 211 still shows row 85, line 212 shows row 87
        ldx lineL
        cpx #211
        bne +
        lda #85
+       cpx #212
        bne +
        lda #87
+       cmp #2                  ; the kernel's first row is row 2
        bcc _none
        cmp P0Top
        bcc _none
        cmp #$58
        bcs _none
        cmp P0Bottom
        bcc +
        lda P0Bottom
        sbc #1
+       tay
        lda (P0Ptr),y
        ldx p0refl
        beq +
        tax
        lda REVERSE,x
+       ldx p0x
        ora #0
        rts
_none   lda #0
        rts

; The robot being tested: 9 rows of 2 lines.
GetP1:
        lda lineL
        sec
        sbc rTop
        bcc _none
        cmp #18
        bcs _none
        lsr
        clc
        adc rGfx
        tay
        lda RobotShapes,y
        ldx rX
        ora #0
        rts
_none   lda #0
        rts

; The humanoid's shot: enable bit 1 of its table at row (line - 36) / 2, rows 3-$56.
GetM0:
        lda lineL
        sec
        sbc #36
        bcc _none
        lsr
        cmp #3
        bcc _none
        cmp #$57
        bcs _none
        tay
        lda (M0Ptr),y
        and #2
        beq _none
        ldx m0x
        lda m0mask
        rts
_none   lda #0
        rts

; The robot shot: rows (line - 35) / 2, rows 4-$56. On the first line of the row
; that starts a robot band, pixels left of that band's split still show the row before.
GetM1:
        lda lineL
        sec
        sbc #35
        bcc _none
        sta v2
        lsr
        cmp #4
        bcc _none
        cmp #$57
        bcs _none
        tay
        lda (M1Ptr),y
        and #2
        beq +
        lda m1mask
+       sta v0
        lda v2
        lsr
        bcs _done               ; second line of the row
        ldx nRob
-       dex
        bmi _done
        tya
        cmp BandRow,x
        bne -
        lda BandSplit,x         ; pixels to the left of the split: k = split - x, 0-8
        sec
        sbc m1x
        bcs +
        lda #0
+       cmp #8
        bcc +
        lda #8
+       tax
        dey
        lda (M1Ptr),y
        and #2
        beq +
        lda m1mask
+       and LeftMask,x
        sta v1
        lda LeftMask,x
        eor #$ff
        and v0
        ora v1
        sta v0
_done   ldx m1x
        lda v0
        rts
_none   lda #0
        rts

; The maze at line lineL under the 8 pixels from xa. Rows 0-41's last line has
; pixels 142-143 from the next row (the kernel writes PF1 before the line ends).
GetPF:
        lda lineL
        sec
        sbc #39
        bcc _out
        cmp #176
        bcc +
_out    jmp _none
+       sta v2                  ; line - 39
        lsr
        lsr
        tay                     ; maze row
        lda xa                  ; quirk line under bytes 16-17? (part of the cache key)
        lsr
        lsr
        lsr
        and #$fe
        cmp #16
        bne _nq
        lda v2
        and #3
        cmp #3
        bne _nq
        cpy #42
        bcs _nq
        lda #$80
        bne +
_nq     lda #0
+       sta v5
        ora xa
        cmp pfcX                ; the same row and pixel as last time: same answer
        bne _miss
        cpy pfcRow
        bne _miss
        lda pfcVal
        ldx xa
        rts
_miss   sta pfcX
        sty pfcRow
        lda PFRowLo,y
        sta ptrA
        lda PFRowHi,y
        sta ptrA+1
        lda xa
        lsr
        lsr
        lsr
        sta v1                  ; byte of the row
        tay
        lda (ptrA),y
        sta v0                  ; pixels from xa & ~7
        iny
        lda (ptrA),y
        sta tmp2
        lda v2                  ; the quirk line?
        and #3
        cmp #3
        bne _shift
        lda v2
        cmp #42 * 4
        bcs _shift
        lsr
        lsr
        tax
        lda v1
        cmp #17
        bne +
        lda QuirkByte,x
        sta v0
        jmp _shift
+       cmp #16
        bne _shift
        lda QuirkByte,x
        sta tmp2
_shift  lda xa
        and #7
        tax
        beq +
-       asl tmp2
        rol v0
        dex
        bne -
+       ldx xa
        lda v0
        sta pfcVal
        rts
_none   lda #0
        rts

WidthMask:  .byte $80, $c0, $f0, $ff
LeftMask:   .byte $00, $80, $c0, $e0, $f0, $f8, $fc, $fe, $ff
