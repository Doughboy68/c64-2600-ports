; =========================================================== snapshot
; The end of a game tick: remember what the 2600 would draw. Render reads the
; 2600 RAM directly (nothing runs between a tick and the next render), plus these.
Snapshot:
        jsr SaveColours
        lda #0
        sta snTrans
        ldx #RecHuman           ; player 0 this frame: the humanoid or Evil Otto
        lda P0Ptr+1
        cmp #$fe
        bne +
        ldx #RecOtto
+       stx snCurRec
        lda P0Top
        sta Recs+0,x
        lda P0Bottom
        sta Recs+1,x
        lda P0Ptr
        sta Recs+2,x
        lda P0Ptr+1
        sta Recs+3,x
        lda p0vdel
        sta Recs+4,x
        lda p0refl
        sta Recs+5,x
        lda p0x
        sta Recs+6,x
        lda #0
        sta Recs+7,x            ; age
        lda Recs+RecHuman+7     ; the other one gets older
        cmp #255
        bcs +
        inc Recs+RecHuman+7
+       lda Recs+RecOtto+7
        cmp #255
        bcs +
        inc Recs+RecOtto+7
+       ldx snCurRec
        lda #0
        sta Recs+7,x
        rts

SnapshotTrans:
        jsr SaveColours
        lda #1
        sta snTrans
        rts

; The colours as the picture was drawn (the score line changes the players').
SaveColours:
        ldx #3
-       lda COLUP0,x
        sta snColour,x
        dex
        bpl -
        rts

