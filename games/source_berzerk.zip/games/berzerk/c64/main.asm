; Berzerk (Atari 2600, 1982) running on the Commodore 64.
;
; The original 2600 program runs almost unchanged at $F000, in the RAM under
; the C64 KERNAL (patches: see GameImage at the end). This file supplies
; everything the 2600 hardware used to do:
;
;   - display: the maze as characters, the humanoid, Evil Otto, robots, shots
;     and the score as sprites, laid out line for line like the 2600 picture
;     (one 2600 pixel = two C64 pixels, one 2600 line = one C64 line)
;   - collisions: computed in software from the rules in tools/model.js, which
;     match the 2600 pixel for pixel, quirks included, and handed to the game
;     as the TIA collision registers and the kernel's robot-band latches
;   - input: keyboard and joysticks mapped onto the 2600 joystick/switch ports
;   - sound: the game's TIA sound registers translated to the SID
;
; The game's TIA writes land harmlessly in zero page $02-$2C; it reads the TIA
; at the mirrors $30-$3D, where we put the collisions and the fire button. Its
; RIOT accesses ($0280-$0297) hit plain C64 RAM, which we fill in each frame.
;
; Build: build.cmd (64tass -C -a -o build/berzerk-c64.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM
RoomState   = $81       ; $FF while changing rooms
MazeOffset  = $83
FrameCount  = $84
AttractCol  = $85
P0Ptr       = $89       ; 2 bytes
P0Top       = $8C
P0Bottom    = $8D
M0Ptr       = $8F       ; 2 bytes
HumanX      = $93
ShotX       = $96
M1Ptr       = $98       ; 2 bytes
RobotShotX  = $9D
TransTop    = $A6       ; transition: first visible line pair
RobotDelay  = $A7       ; 8 bytes
OttoX       = $AE
RobotGfx    = $AF       ; 8 bytes
RobotY      = $B8       ; 9 bytes, $7F ends the list
RobotX      = $C1       ; 8 bytes
RobotHit    = $C9       ; kernel latches, see Collide
TransBottom = $D0       ; transition: line pair where the picture ends
LeftDoor    = $E1
EntrySide   = $E2
DigitPtr    = $EA       ; 6 pointers
P0Gfx       = $FD

; ------------------------------- 2600 hardware: TIA writes land in zero page
NUSIZ0      = $04
NUSIZ1      = $05
COLUP0      = $06
COLUP1      = $07
COLUPF      = $08
COLUBK      = $09
REFP0       = $0B
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
VDELP0      = $25
; the game reads the TIA at $30-$3D: we fill these in
CXM0P       = $30       ; bit 7 M0-P1, bit 6 M0-P0
CXM1P       = $31       ; bit 7 M1-P0, bit 6 M1-P1
CXP0FB      = $32       ; bit 7 P0-PF
CXP1FB      = $33       ; bit 7 P1-PF
CXM0FB      = $34       ; bit 7 M0-PF
CXM1FB      = $35       ; bit 7 M1-PF
CXBLPF      = $36
CXPPMM      = $37       ; bit 7 P0-P1, bit 6 M0-M1
INPT4       = $3C       ; bit 7 clear: fire
; RIOT
SWCHA       = $0280     ; joystick (high nibble: player 0)
SWCHB       = $0282     ; console switches
INTIM       = $0284     ; timer (kept at 0 so the game never waits)

; ------------------------------------------------ 2600 program addresses
PowerOn     = $F9AC
Overscan    = $F1DD     ; where the game continues after drawing a picture
PF0Tab      = $FB00     ; maze tables (PF0, PF1, PF2), indexed by row + MazeOffset
PF1Tab      = $FD00
PF2Tab      = $FE00
RobotShapes = $FF33

; ------------------------------------------------------------ C64 layout
VICBANK     = $4000     ; the VIC sees $4000-$7FFF (no character ROM there)
SCREEN      = $4400
COLRAM      = $D800
BLANKCHARS  = $7000     ; characters 0-3 empty: the maze switched off
SPRDATA     = $7040     ; sprite blocks from here (block numbers SPRBASE+)
SPRBASE     = (SPRDATA - VICBANK) / 64
MAZECHARS   = $7800     ; characters 0-3: nothing, top half, bottom half, full
SPRPTR      = SCREEN + $3F8
PFMASK      = $C000     ; the maze as 2600 pixels: 44 rows x 24 bytes (collisions)
REVERSE     = $C500     ; byte with its bits in reverse order (REFP0)
PFCOL       = $C800     ; the maze for quick tests: 21 columns x 64 bytes (see PFAny)
D018MAZE    = $1E       ; screen +$0400, characters +$3800
D018BLANK   = $1C       ; screen +$0400, characters +$3000
NOTCHCHAR   = 8         ; characters 9-30: column 1 of rows 1-22 (the left wall, with HMOVE notches)

; 2600 line L is screen line L - LINEOFS (the play area starts on character row 1),
; raster line L + RASTEROFS, and sprite Y register value L + SPRYOFS.
LINEOFS     = 31
RASTEROFS   = 51 - LINEOFS
SPRYOFS     = 50 - LINEOFS
TOPRASTER   = 45        ; frame start: before the first line of the picture (2600 line 39)
ENDRASTER   = 246       ; frame end: after the score line (2600 line 224)
DIGITX      = 55        ; 2600 pixel of the score line's first character
DIGITLINE   = 218       ; 2600 line of its top row

; sprite blocks: two sets (the display uses one while the next frame is drawn into the other)
BLK_BLANK   = SPRBASE           ; always empty
BLK_SET     = SPRBASE + 1       ; set 0; set 1 follows
NBLK        = 14                ; per set: human, Otto, 2 shots, 8 robots, 2 score
B_HUMAN     = 0
B_OTTO      = 1
B_M0        = 2
B_M1        = 3
B_ROBOT     = 4
B_DIGITS    = 12
BLK_BAR1    = BLK_SET + 2 * NBLK  ; HMOVE bar shapes (shared): a line at row 0 ...
BLK_BAR2    = BLK_BAR1 + 1        ; ... at rows 0 and 20
        .cerror SPRDATA + 64 * (1 + 2 * NBLK + 2) > MAZECHARS, "sprite blocks overflow"

; schedule entry types for the raster interrupt
S_TOP       = 0         ; frame start: all sprites for the top of the picture
S_ROBOT     = 2         ; reuse a sprite for robot `arg`
S_DIGITS    = 4         ; the score line
S_MAZEON    = 6         ; transition window: maze characters on
S_MAZEOFF   = 8         ; ... and off
S_END       = 10        ; frame end
S_BAR       = 12        ; move sprite 1 to the next HMOVE bar(s)
NSCHED      = 16

; ------------------------------------------------------- zero page ($40+)
; $02-$2C take the game's TIA writes and $30-$3D are its TIA reads, so ours start at $40.
        .virtual $40
ptrA        .word ?
ptrB        .word ?
ptrC        .word ?
ptrD        .word ?
tmp         .byte ?
tmp2        .byte ?
lineL       .byte ?     ; collisions: current 2600 line
pLo         .byte ?     ; collisions: line range being tested
pHi         .byte ?
xa          .byte ?     ; collisions: the two objects on lineL
ba          .byte ?
xb          .byte ?
bb          .byte ?
p0x         .byte ?     ; player 0: left pixel, rows, line range
p0first     .byte ?
p0last      .byte ?
p0vdel      .byte ?
p0refl      .byte ?
m0x         .byte ?     ; missiles: left pixel, pixel mask, line range
m0mask      .byte ?
m0first     .byte ?
m0last      .byte ?
m1x         .byte ?
m1mask      .byte ?
m1first     .byte ?
m1last      .byte ?
nRob        .byte ?     ; robots on screen
rTop        .byte ?     ; the robot being tested
rBot        .byte ?
rX          .byte ?
rGfx        .byte ?
latch       .byte ?
bits        .byte ?
frameFlag   .byte ?     ; frames counted by the raster interrupt
frames      .byte ?
isPal       .byte ?
tickAcc     .byte ?
firstTick   .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)
outv        .word ?     ; SWCHA, INPT4 being built
switches    .byte ?     ; SWCHB toggles
curBuf      .byte ?     ; raster interrupt: frame buffer in use (0/1)
pending     .byte ?     ; a new frame is ready in the other buffer
irqIdx      .byte ?
irqTmp      .byte ?
bufOfs      .byte ?     ; render: 0 or 8 for the buffer being drawn
blkOfs      .byte ?     ; render: first sprite block of that buffer
v0          .byte ?
v1          .byte ?
v2          .byte ?
v3          .byte ?
v4          .byte ?
v5          .byte ?
robY        .byte ?
        .cerror * > $80, "zero page overflow"
        .endv

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title, credits and controls.
; (Lower case here: 64tass -a turns it into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " berzerk"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600"
Bas30   .word Bas40, 30
        .null $8f, " programmed by dan hitchens"
Bas40   .word Bas50, 40
        .null $8f, " version 1.2"
Bas50   .word Bas60, 50
        .null $8f, " ported by claude and doughboy68"
Bas60   .word Bas70, 60
        .null $8f, " joy port 2/1 or wasd space-fire"
Bas70   .word Bas80, 70
        .null $8f, " f1 or fire-start f2-power off/on"
Bas80   .word BasEnd, 80
        .null $8f, " f3-select f-flicker on/off"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #$ff
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01

        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -

        ; copy the patched 2600 program to $F000-$FFFF
        lda #<GameImage
        sta ptrA
        lda #>GameImage
        sta ptrA+1
        lda #0
        sta ptrB
        lda #$f0
        sta ptrB+1
        ldx #16
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        lda #<Nmi               ; our vectors replace the 2600's
        sta $fffa
        lda #>Nmi
        sta $fffb
        lda #<Irq
        sta $fffe
        lda #>Irq
        sta $ffff

        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #0
        sta INTIM
        lda #$80
        sta INPT4
        lda #1
        sta firstTick

        jsr InitVideo
        jsr InitSound
        jsr DetectPal
        lda #$ff                ; CIA 2 timer A free-running (testing aid: DbgTime)
        sta $dd04
        sta $dd05
        lda #%00010001
        sta $dd0e

        ldx #0                  ; start the raster interrupt on an empty frame
        stx curBuf
        stx irqIdx
        lda #TOPRASTER
        sta SchedRas
        sta SchedRas+NSCHED
        lda #S_TOP
        sta SchedType
        sta SchedType+NSCHED
        lda #ENDRASTER
        sta SchedRas+1
        sta SchedRas+NSCHED+1
        lda #S_END
        sta SchedType+1
        sta SchedType+NSCHED+1
        lda #TOPRASTER
        sta $d012
        lda #$1b
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

; ================================================================ main loop
MainLoop:
-       lda frameFlag           ; frames since we last got here (set by the raster interrupt)
        beq -
        sei
        lda frameFlag
        ldx #0
        stx frameFlag
        cli
        inc DbgLoops            ; (testing aid: passes, and frames that came late)
        bne +
        inc DbgLoops+1
+       cmp #2
        bcc +
        inc DbgLate
        bne +
        inc DbgLate+1
+       cmp #3                  ; if we fell behind, catch up at most 3 frames
        bcc +
        lda #3
+       sta frames
        jsr DbgTime             ; (testing aid: the most cycles drawing, ticking, both)
        stx dbgT0
        sty dbgT0+1
        lda DbgBorder           ; testing aid: the border shows where the time goes
        beq +
        lda #2
        sta $d020
+       jsr Render              ; draw the state the last tick produced
        jsr ReadInput
        lda PowerReq            ; F2: the power switch
        beq +
        jsr PowerCycle
+       jsr DbgTime
        stx dbgT1
        sty dbgT1+1
        lda dbgT0               ; drawing
        ldx dbgT0+1
        ldy #0
        jsr DbgMax
        lda DbgBorder
        beq _frame
        lda #5
        sta $d020
_frame  lda isPal               ; PAL: 6 game ticks every 5 frames keeps 2600 speed
        beq _ntsc
        lda tickAcc
        clc
        adc #6
        sta tickAcc
-       lda tickAcc
        cmp #5
        bcc _done
        sbc #5
        sta tickAcc
        jsr Tick
        jmp -
_ntsc   jsr Tick
_done   dec frames
        bne _frame
        jsr DbgTime
        lda dbgT1               ; the ticks (from the end of drawing)
        ldx dbgT1+1
        ldy #2
        jsr DbgMax
        lda dbgT0               ; the whole pass
        ldx dbgT0+1
        ldy #4
        jsr DbgMax
        jsr UpdateSound
        lda DbgBorder
        beq +
        lda #0
        sta $d020
+       jmp MainLoop

; Testing aid: CIA 2 timer A counts down freely. DbgTime: dbgNow (and X/Y) = its value.
DbgTime:
-       ldy $dd05
        ldx $dd04
        cpy $dd05
        bne -
        stx dbgNow
        sty dbgNow+1
        rts
; DbgMax: cycles from the time in A/X (low/high) to dbgNow; keep the largest at
; DbgRMax+Y (Y = 0 drawing, 2 ticks, 4 the whole pass).
DbgMax:
        sec                     ; (the timer counts down: start - now)
        sbc dbgNow
        sta dbgTmp
        txa
        sbc dbgNow+1
        sta dbgTmp+1
        cmp DbgRMax+1,y
        bcc _keep
        bne _new
        lda dbgTmp
        cmp DbgRMax,y
        bcc _keep
_new    lda dbgTmp
        sta DbgRMax,y
        lda dbgTmp+1
        sta DbgRMax+1,y
_keep   rts

; One 2600 frame of game logic: the original code from the end of the picture
; to the start of the next one, where it jumps to KernelHook (or TransHook).
Tick:
        lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp PowerOn             ; the very first frame starts at power-on
+       jmp Overscan

KernelHook:                     ; the game would draw the picture now
        jsr Collide             ; what the TIA would have seen
        jsr Snapshot            ; what to show
        jmp AfterPicture        ; (returns to whoever called Tick)
TransHook:                      ; the same, while changing rooms
        jsr SnapshotTrans
        jmp AfterPicture

; What the score line's code leaves behind, which the game relies on: TIA
; settings (no copies or wide shots, no reflection, the score's colours,
; vertical delay on), its row counter, and the fourth character's last row.
AfterPicture:
        lda #0
        sta NUSIZ0
        sta NUSIZ1
        sta REFP0
        sta $0d                 ; PF0-PF2
        sta $0e
        sta $0f
        sta $1b                 ; GRP0, GRP1
        sta $1c
        sta $21                 ; HMP1
        lda #$f0
        sta $20                 ; HMP0
        lda #$1c
        eor AttractCol
        sta COLUP0
        sta COLUP1
        lda #1
        sta VDELP0
        sta $26                 ; VDELP1
        lda #$ff
        sta $e8
        ldy #0
        lda ($f0),y
        sta $e9
        rts

; Replaces "jsr PlaceRobots" at the start of a room. On the 2600 the stack is the
; top of page zero: PlaceRobots' last call to RandomRange (from $FA8C) leaves its
; return address in $FC/$FD, and the game then uses $FD for the humanoid's graphics.
PlaceRobots:
        jsr $fa73
        lda #$fa
        sta P0Gfx
        lda #$8e
        sta $fc
        rts

; F2: the power switch off and on. The TIA is cleared and the next tick starts
; at the 2600's power-on code, which clears its RAM (game 1); the console switches
; stay as they are set, as on a real 2600. The display catches up by itself.
PowerCycle:
        lda #0
        sta PowerReq
        ldx #2                  ; the TIA's registers ($02-$2C) and our copies of its reads
-       sta $00,x
        inx
        cpx #$3e
        bne -
        sta INTIM
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        lda #1
        sta firstTick
        rts

; Replaces the 2600's "sta $00,x / inx / bne" clearing loop (A = 0): clear the
; 2600 RAM from X up, but not the C64's zero page below $80.
ClearZP:
        cpx #$80
        bcs +
        ldx #$80
+
-       sta $00,x
        inx
        bne -
        rts

; Replaces "lda #2 / sta OttoState / sta CXCLR" (the humanoid's shot stunned Evil Otto):
; clearing the TIA's latches means clearing our copies.
OttoHit:
        lda #2
        sta $f6
        lda #0
        ldx #7
-       sta CXM0P,x
        dex
        bpl -
        rts

; =========================================================== interrupts
; Each frame is a short schedule of raster lines (SchedRas/SchedType/SchedArg),
; built by Render into the buffer the display isn't using. At the top of the
; frame the interrupt switches to a newly finished buffer, so a half-drawn
; frame is never shown. The entries:
;   S_TOP     sprites for the top of the picture, colours, character set
;   S_ROBOT   reuse a sprite for robot 4-7, after robot 0-3 has been drawn
;   S_DIGITS  the score line's two sprites
;   S_MAZEON / S_MAZEOFF   the window of the room-change transition
;   S_END     frame end: let the main loop draw the next one
Irq:
        pha
        txa
        pha
        tya
        pha
        cld                     ; the game uses decimal mode now and then
        lda $d019
        sta $d019
_next   ldx irqIdx
        ldy SchedType,x
        lda IrqJump,y
        sta _jmp+1
        lda IrqJump+1,y
        sta _jmp+2
_jmp    jmp $ffff
_done   inc irqIdx              ; next entry; run it now if its line has passed already
        ldx irqIdx
        lda SchedRas,x
        sta $d012
        sec
        sbc #2
        cmp $d012
        bcc _next
_out    pla
        tay
        pla
        tax
        pla
        rti
IrqJump:    .word ITop, IRobot, IDigits, IMazeOn, IMazeOff, IEnd, IBar

ITop:   inc DbgTops             ; (testing aid)
        lda pending             ; switch to a newly finished frame
        beq +
        lda curBuf
        eor #1
        sta curBuf
        lda #0
        sta pending
+       lda curBuf
        asl
        asl
        asl
        sta irqTmp              ; 8 * buffer: staged sprite values
        asl
        sta irqIdx              ; 16 * buffer: this buffer's schedule, entry 0
        ldy irqTmp
        ldx #0
-       lda StPtr,y
        sta SPRPTR,x
        lda StCol,y
        sta $d027,x
        iny
        inx
        cpx #8
        bne -
        ldy irqTmp
        ldx #0
-       lda StX,y
        sta $d000,x
        lda StY,y
        sta $d001,x
        iny
        inx
        inx
        cpx #16
        bne -
        ldy curBuf
        lda StMsb,y
        sta $d010
        lda StEn,y
        sta $d015
        lda StYexp,y
        sta $d017
        lda StBg,y              ; (the border stays black)
        cmp LastBg              ; only when it changes: the C64C's VIC (8565) shows a grey
        beq +                   ; dot where the beam is at each colour register write (here
        sta $d021               ; on a visible line on NTSC, every frame)
        sta LastBg
+       lda StD018,y
        sta $d018
        jmp Irq._done

IRobot: ldy SchedArg,x          ; Y = 8 * buffer + robot (4-7)
        tya
        and #3
        ora #4
        tax                     ; its sprite, 4-7
        lda RbPtr,y
        sta SPRPTR,x
        lda Bit,x               ; X position bit 8
        eor #$ff
        and $d010
        ora RbMsb,y
        sta $d010
        txa
        asl
        tax
        lda RbX,y
        sta $d000,x
        lda RbY,y
        sta $d001,x
        jmp SprInTime

IDigits:
        lda #DIGITLINE + SPRYOFS ; first: the VIC must see the Y position before line 237
        sta $d009
        sta $d00b
        inc DbgDigits           ; (testing aid: count, the raster line it ran at, and in time?)
        lda $d012
        sta DbgDigRas
        cmp #DIGITLINE + SPRYOFS
        bcc +
        inc DbgSprLate
+
        ldy curBuf
        lda DgPtr,y
        sta SPRPTR+4
        clc
        adc #1
        sta SPRPTR+5
        lda #<(24 + 2 * DIGITX)
        sta $d008
        lda #<(24 + 2 * (DIGITX + 24))
        sta $d00a
        lda #DIGITLINE + SPRYOFS
        sta $d009
        sta $d00b
        lda $d010
        and #$cf
        ora #((24 + 2 * DIGITX) >> 8) << 4 | ((24 + 2 * (DIGITX + 24)) >> 8) << 5
        sta $d010
        lda DgCol,y
        sta $d02b
        sta $d02c
        lda $d017
        and #$cf
        sta $d017
        lda $d015
        and #$0f
        ora #$30
        sta $d015
        jmp Irq._done

IBar:   ldy SchedArg,x          ; Y = 8 * buffer + segment
        lda BarPtr,y
        sta SPRPTR+1
        lda BarY,y
        sta $d003
        jmp SprInTime

; (testing aid) A sprite moved to Y register A must be there before the raster
; reaches line A (the VIC compares in that line); count it if it came too late.
SprInTime:
        cmp $d012
        beq _late
        bcs +
_late   inc DbgSprLate
+       jmp Irq._done

IMazeOn:                        ; (entered on the line before: wait for the next to start)
        ldy #D018MAZE
        bne +
IMazeOff:
        ldy #D018BLANK
+       lda $d012
-       cmp $d012
        beq -
        sty $d018
        jmp Irq._done

IEnd:   inc frameFlag           ; frame end: the next interrupt is the frame top
        lda curBuf
        asl
        asl
        asl
        asl
        sta irqIdx
        lda #TOPRASTER
        sta $d012
        jmp Irq._out

Nmi:    rti

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        txa                     ; the SID's pitch depends on the machine's clock
        bne +
        lda #<SidFreqLoN
        sta FreqTab
        lda #>SidFreqLoN
        sta FreqTab+1
+       rts

InitVideo:
        lda $dd02               ; VIC bank 1 ($4000)
        ora #3
        sta $dd02
        lda $dd00
        and #$fc
        ora #2
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d017
        sta $d01b
        sta $d01c
        lda #$08
        sta $d016
        lda #D018BLANK
        sta $d018
        lda #$ff                ; every sprite double width: one 2600 pixel = two C64 pixels
        sta $d01d

        ; clear screen, colour RAM, and $3000-$3FFF (characters, sprite blocks)
        ldx #0
        lda #0
-       sta SCREEN,x
        sta SCREEN+$100,x
        sta SCREEN+$200,x
        sta SCREEN+$2e8,x
        sta COLRAM,x
        sta COLRAM+$100,x
        sta COLRAM+$200,x
        sta COLRAM+$2e8,x
        inx
        bne -
        lda #<BLANKCHARS
        sta ptrB
        lda #>BLANKCHARS
        sta ptrB+1
        ldx #16                 ; ($7000-$7FFF)
        ldy #0
        tya
-       sta (ptrB),y
        iny
        bne -
        inc ptrB+1
        dex
        bne -
        lda #$ff                ; the HMOVE bar shapes
        sta VICBANK + 64 * BLK_BAR1
        sta VICBANK + 64 * BLK_BAR2
        sta VICBANK + 64 * BLK_BAR2 + 60
        ldx #3                  ; maze characters: 1 top half, 2 bottom half, 3 full
        lda #$ff
-       sta MAZECHARS+8,x
        sta MAZECHARS+16+4,x
        sta MAZECHARS+24,x
        sta MAZECHARS+24+4,x
        dex
        bpl -

        ldx #0                  ; bit-reversal table
-       txa
        ldy #8
-       lsr
        rol tmp
        dey
        bne -
        lda tmp
        sta REVERSE,x
        inx
        bne --

        lda #BLK_BLANK          ; all sprites blank to start
        ldx #7
-       sta SPRPTR,x
        sta StPtr,x
        sta StPtr+8,x
        dex
        bpl -
        rts

InitSound:
        ldx #$18
        lda #0
-       sta $d400,x
        dex
        bpl -
        lda #$0f                ; full volume
        sta $d418
        ldx #5
        lda #$ff
-       sta SndLast,x
        dex
        bpl -
        rts

        .include "input.asm"
        .include "collide.asm"
        .include "maze.asm"
        .include "render.asm"
        .include "sprites.asm"
        .include "shapes.asm"
        .include "bars.asm"
        .include "data.asm"
        .cerror * > VICBANK, "the program runs into the video bank"
