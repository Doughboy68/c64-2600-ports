; ================================================================= render
; Draw the last tick's picture into the frame buffer the display isn't using,
; then hand it over (pending). Sprites: 0 humanoid (or player 0), 1 Evil Otto
; (flicker off), 2 the humanoid's shot, 3 the robot shot, 4-7 robots, reused
; down the screen, then 4-5 for the score line.
Render:
        lda pending             ; the last frame hasn't been shown yet
        beq +
        rts
+       jsr RenderMaze
        lda curBuf
        eor #1
        sta rbuf                ; buffer being drawn
        asl
        asl
        asl
        sta bufOfs
        lda #BLK_SET
        ldx rbuf
        beq +
        lda #BLK_SET + NBLK
+       sta blkOfs

        ldx rbuf
        lda #0
        sta StEn,x
        sta StMsb,x
        lda #$0f                ; players and shots Y-expanded; robots (4-7) not
        sta StYexp,x
        lda snColour+3          ; (COLUBK)
        lsr
        tay
        lda ColorMap,y
        sta StBg,x
        lda #D018MAZE
        sta StD018,x
        txa                     ; schedule: entry 0 is the frame top
        asl
        asl
        asl
        asl
        tax
        lda #TOPRASTER
        sta SchedRas,x
        lda #S_TOP
        sta SchedType,x
        inx
        stx schedIdx

        lda snTrans
        beq +
        jsr TransWindow         ; changing rooms: only the maze window and the score line
        jmp ++
+       jsr RenderP0
        jsr RenderShots
        jsr RenderRobots
        jsr Notches
        jsr Bars
+       jsr RenderDigits
        ldx schedIdx            ; frame end
        lda #ENDRASTER
        sta SchedRas,x
        lda #S_END
        sta SchedType,x
        lda #1
        sta pending
        rts

; Redraw the maze when the room (or the transition) changes; colour it.
RenderMaze:
        lda snTrans
        sta mazeMode
        cmp ScrKey
        bne _redraw
        lda MazeOffset
        cmp ScrKey+1
        bne _redraw
        lda LeftDoor
        cmp ScrKey+2
        bne _redraw
        lda EntrySide
        cmp ScrKey+3
        beq _colour
_redraw lda mazeMode
        sta ScrKey
        lda MazeOffset
        sta ScrKey+1
        lda LeftDoor
        sta ScrKey+2
        lda EntrySide
        sta ScrKey+3
        jsr DrawMaze
_colour lda snColour+2          ; (COLUPF)
        lsr
        tay
        lda ColorMap,y
        cmp WallCol
        beq +
        sta WallCol
        ldx #0                  ; colour RAM rows 1-22
-       sta COLRAM+40,x
        sta COLRAM+40+220,x
        sta COLRAM+40+440,x
        sta COLRAM+40+660,x
        inx
        cpx #220
        bne -
+       rts

; The transition window: visible from line 2 * TransTop + 37 to 2 * TransBottom + 38.
TransWindow:
        lda TransTop
        asl
        clc
        adc #37
        sta tmp                 ; first line
        lda TransBottom
        asl
        clc
        adc #38
        cmp #214
        bcc +
        lda #214
+       sta tmp2                ; last line
        ldx rbuf
        lda #D018BLANK
        sta StD018,x
        lda tmp2
        cmp tmp
        bcc _none               ; nothing left
        lda tmp
        cmp #40
        bcs +
        lda #D018MAZE           ; from the top
        sta StD018,x
        jmp _off
+       ldx schedIdx            ; on at the first line (the handler waits for its start)
        clc
        adc #RASTEROFS - 1
        sta SchedRas,x
        lda #S_MAZEON
        sta SchedType,x
        inc schedIdx
_off    lda tmp2
        cmp #214
        bcs _none
        ldx schedIdx            ; off after the last line
        clc
        adc #RASTEROFS
        sta SchedRas,x
        lda #S_MAZEOFF
        sta SchedType,x
        inc schedIdx
_none   rts

; Player 0: the humanoid and Evil Otto. With flicker on, only the one the 2600
; shows this frame (it alternates them); with it off, both, each as last seen.
RenderP0:
        lda snColour+0          ; (COLUP0)
        lsr
        tay
        lda ColorMap,y
        ldx bufOfs
        sta StCol,x
        sta StCol+1,x
        lda Flicker
        beq _both
        lda snCurRec
        ldx #0
        jmp ShowRec
_both   lda Recs+RecHuman+7
        cmp #3
        bcs +
        lda #RecHuman
        ldx #0
        jsr ShowRec
+       lda Recs+RecOtto+7
        cmp #3
        bcs +
        lda #RecOtto
        ldx #1
        jmp ShowRec
+       rts

