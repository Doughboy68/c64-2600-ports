; ================================================================ the maze
; Maze row p (0-43, 4 lines each from 2600 line 39): the top wall, 42 rows from the
; tables, the bottom wall. RowMask builds row p as 2600 pixels in ROW (20 bytes,
; then 4 zero bytes): with mazeMode = 1, the room-change version (doors open).
; The playfield is mirrored: 20 columns of 4 pixels, each 2-bit pair of a PF
; register is one byte here, and its mirror image is the same pair swapped.
RowMask:
        cpx #0
        bne +
        lda #$e0                ; top wall: the top door is shut if we came in there
        sta v0
        lda #$ff
        sta v1
        ldy #$07
        lda mazeMode
        bne _pf2
        lda EntrySide
        bne _pf2
        ldy #$ff
        jmp _pf2
+       cpx #43
        bne +
        lda #$e0                ; bottom wall
        sta v0
        lda #$ff
        sta v1
        ldy #$07
        lda mazeMode
        bne _pf2
        lda EntrySide
        cmp #1
        bne _pf2
        ldy #$ff
        jmp _pf2
+       txa                     ; a row from the tables: entry p + 1 + MazeOffset
        sec
        adc MazeOffset
        tay
        lda PF0Tab,y
        ldx mazeMode
        bne +
        ora LeftDoor            ; the side door we came in by is shut
+       sta v0
        lda PF1Tab,y
        sta v1
        lda PF2Tab,y
        tay
_pf2    sty v2
        lda v0                  ; PF0 bits 4-7: bytes 0-1 (and 19-18)
        lsr
        lsr
        lsr
        lsr
        pha
        and #3
        tax
        lda NibA,x
        sta ROW+0
        lda NibB,x
        sta ROW+19
        pla
        lsr
        lsr
        tax
        lda NibA,x
        sta ROW+1
        lda NibB,x
        sta ROW+18
        lda v1                  ; PF1 bits 7-0: bytes 2-5 (and 17-14), high bit first
        pha
        lsr
        lsr
        lsr
        lsr
        lsr
        lsr
        tax
        lda NibB,x
        sta ROW+2
        lda NibA,x
        sta ROW+17
        pla
        pha
        lsr
        lsr
        lsr
        lsr
        and #3
        tax
        lda NibB,x
        sta ROW+3
        lda NibA,x
        sta ROW+16
        pla
        pha
        lsr
        lsr
        and #3
        tax
        lda NibB,x
        sta ROW+4
        lda NibA,x
        sta ROW+15
        pla
        and #3
        tax
        lda NibB,x
        sta ROW+5
        lda NibA,x
        sta ROW+14
        lda v2                  ; PF2 bits 0-7: bytes 6-9 (and 13-10), low bit first
        and #3
        tax
        lda NibA,x
        sta ROW+6
        lda NibB,x
        sta ROW+13
        lda v2
        lsr
        lsr
        pha
        and #3
        tax
        lda NibA,x
        sta ROW+7
        lda NibB,x
        sta ROW+12
        pla
        lsr
        lsr
        pha
        and #3
        tax
        lda NibA,x
        sta ROW+8
        lda NibB,x
        sta ROW+11
        pla
        lsr
        lsr
        tax
        lda NibA,x
        sta ROW+9
        lda NibB,x
        sta ROW+10
        rts
NibA:       .byte $00, $f0, $0f, $ff    ; bit 0 -> left column, bit 1 -> right
NibB:       .byte $00, $0f, $f0, $ff    ; bit 1 -> left column, bit 0 -> right

; The maze as 2600 pixels for the collisions (PFMASK, 24 bytes a row), the quirk
; byte for each row's last line (pixels 142-143 from the next row's PF1 bit 7),
; and the columns for the quick test (PFCOL: each byte ORed with the next).
BuildPFMask:
        lda MazeOffset
        sta ColKey
        lda LeftDoor
        sta ColKey+1
        lda EntrySide
        sta ColKey+2
        lda #0
        sta mazeMode
        sta tmp2                ; row
_row    ldx tmp2
        jsr RowMask
        ldx tmp2
        lda PFRowLo,x
        sta ptrA
        lda PFRowHi,x
        sta ptrA+1
        ldy #19
-       lda ROW,y
        sta (ptrA),y
        dey
        bpl -
        .for j = 0, j < 21, j += 1
        lda ROW+j
        ora ROW+j+1
        sta PFCOL+64*j,x
        .next
        inc tmp2
        lda tmp2
        cmp #44
        beq +
        jmp _row
+       ldx #0                  ; quirk bytes, rows 0-41
-       lda PFRowLo,x
        sta ptrA
        lda PFRowHi,x
        sta ptrA+1
        ldy #17
        lda (ptrA),y
        and #$fc
        sta tmp
        txa                     ; the next row's PF1: entry x + 2 + MazeOffset
        clc
        adc #2
        adc MazeOffset
        tay
        lda PF1Tab,y
        bpl +
        lda tmp
        ora #3
        sta tmp
+       lda tmp
        sta QuirkByte,x
        ora PFCOL+64*16,x       ; the quick test's columns that include byte 17
        sta PFCOL+64*16,x
        lda tmp
        ora PFCOL+64*17,x
        sta PFCOL+64*17,x
        inx
        cpx #42
        bne -
        lda #0
        sta QuirkByte+42
        sta QuirkByte+43
        rts

; The maze on screen: rows 1-22, character 1 / 2 / 3 for the top / bottom / both
; halves of a cell (each half is one maze row).
DrawMaze:
        lda #1
        sta tmp2                ; screen row
_row    lda tmp2                ; its top half: maze row 2 * (row - 1)
        sec
        sbc #1
        asl
        tax
        stx v3
        jsr RowMask
        ldx #19
-       lda ROW,x
        sta ROWA,x
        dex
        bpl -
        ldx v3                  ; its bottom half
        inx
        jsr RowMask
        ldy tmp2
        lda RowLo,y
        sta ptrA
        lda RowHi,y
        sta ptrA+1
        ldx #0                  ; byte: columns 2x and 2x+1
        ldy #0
-       lda ROWA,x              ; left column: the high nibbles
        and #$f0
        sta tmp
        lda ROW,x
        lsr
        lsr
        lsr
        lsr
        ora tmp
        sty v4
        tay
        lda CellChar,y
        ldy v4
        sta (ptrA),y
        iny
        lda ROWA,x              ; right column: the low nibbles
        asl
        asl
        asl
        asl
        sta tmp
        lda ROW,x
        and #$0f
        ora tmp
        sty v4
        tay
        lda CellChar,y
        ldy v4
        sta (ptrA),y
        iny
        inx
        cpx #20
        bne -
        inc tmp2
        lda tmp2
        cmp #23
        beq +
        jmp _row
+       lda mazeMode            ; in play, column 1 (the left wall) gets a character of its own
        bne _done               ; on each row, for the HMOVE notches (see Notches)
        ldx #1
-       lda RowLo,x
        sta ptrA
        lda RowHi,x
        sta ptrA+1
        ldy #1
        lda (ptrA),y
        sta CellPat,x
        txa
        clc
        adc #NOTCHCHAR
        sta (ptrA),y
        lda #$ff                ; (rebuild its character)
        sta PrevNotch,x
        inx
        cpx #23
        bne -
_done   rts

; The 2600 strobes HMOVE at the start of the line above each robot (2Y + 38) to
; position it, which blanks that line's first 8 pixels: a notch in the left wall.
; Column 1's characters (one per row) get those lines cleared.
Notches:
        lda PrevNotch+1         ; nothing to do if the robots' rows are as last time
        cmp #$ff                ; (and the maze wasn't redrawn)
        beq _new
        ldx #8
-       lda RobotY,x
        cmp PrevRobY,x
        bne _new
        dex
        bpl -
        rts
_new    ldx #8
-       lda RobotY,x
        sta PrevRobY,x
        dex
        bpl -
        ldx #22
        lda #0
-       sta NotchMask,x
        dex
        bpl -
        ldx #0
_rob    cpx nRob
        bcs _chars
        lda RobotY,x            ; screen line 2Y + 38 - LINEOFS
        asl
        clc
        adc #38 - LINEOFS
        cmp #8
        bcc _next
        cmp #8 * 23
        bcs _next
        tay
        and #7
        sta tmp                 ; line within the character
        tya
        lsr
        lsr
        lsr
        tay                     ; screen row
        stx tmp2
        ldx tmp
        lda Bit,x
        ora NotchMask,y
        sta NotchMask,y
        ldx tmp2
_next   inx
        jmp _rob
_chars  ldx #1                  ; rebuild the rows whose notches changed
_row    lda NotchMask,x
        cmp PrevNotch,x
        beq _same
        sta PrevNotch,x
        sta v1                  ; notch lines
        lda CellPat,x
        sta v0                  ; bit 0: top half (lines 0-3), bit 1: bottom half (4-7)
        stx tmp
        txa
        clc
        adc #NOTCHCHAR
        asl
        asl
        asl
        tay                     ; its character's data
        ldx #0
-       lda v0
        cpx #4
        bcc +
        lsr
+       and #1
        beq _put                ; no wall here
        lda Bit,x
        and v1
        bne _blank              ; a notch line
        lda #$ff
        bne _put
_blank  lda #0
_put    sta MAZECHARS,y
        iny
        inx
        cpx #8
        bne -
        ldx tmp
_same   inx
        cpx #23
        bne _row
        rts
