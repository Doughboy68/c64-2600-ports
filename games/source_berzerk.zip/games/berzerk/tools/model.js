// A model of what Berzerk's kernel draws, built only from RAM (and the TIA
// registers the game set before the kernel), checked pixel by pixel against
// tools/vcs.js over a random game. The C64 version draws from the same rules,
// so this is where its geometry is worked out and proven.
//   node games/berzerk/tools/model.js [frames] [--verbose]
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('136f75c4dd02c29283752b7e5799f978');
const vcs = new VCS(rom);
const frames = +(process.argv[2] || 2000);
const verbose = process.argv.includes('--verbose');
const showAt = process.argv.indexOf('--show');                 // --show <frame> <P0|P1|M0|M1|PF>
const show = showAt > 0 ? { frame: +process.argv[showAt + 1], name: process.argv[showAt + 2] } : null;
let M = a => a >= 0xF000 ? rom[a - 0xF000] : vcs.ram[(a & 0xFF) - 0x80];     // memory as the game sees it

const TOP = 39, BOTTOM = 214;             // play area lines (walls included)
const HPOS = require('./hpos.json');    // missile pixel for each X (tools/mkhpos.js)
const PF0T = 0xFB00, PF1T = 0xFD00, PF2T = 0xFE00, ROBOTGFX = 0xFF33;

// ---- the model: a 160 x 262 map of object bits (1 P0, 2 P1, 4 M0, 8 M1, 32 PF)
function model(s) {
  const ob = new Uint8Array(160 * 262);
  const set = (y, x, bit) => { if (x >= 0 && x < 160 && y >= TOP && y <= BOTTOM) ob[y * 160 + x] |= bit; };
  // playfield: 20 columns, reflected
  const pfLine = (y, p0, p1, p2) => {
    const cols = [];
    for (let b = 4; b < 8; b++) cols.push((p0 >> b) & 1);
    for (let b = 7; b >= 0; b--) cols.push((p1 >> b) & 1);
    for (let b = 0; b < 8; b++) cols.push((p2 >> b) & 1);
    for (let c = 0; c < 20; c++) if (cols[c]) for (let i = 0; i < 4; i++) { set(y, c * 4 + i, 32); set(y, 156 - c * 4 + i, 32); }
  };
  for (let y = TOP; y < TOP + 4; y++) pfLine(y, 0xE0, 0xFF, s.entry === 0 ? 0xFF : 0x07);
  for (let k = 0; k < 42; k++) {
    const e = k + 2 + s.mazeOff;
    for (let i = 0; i < 4; i++) pfLine(TOP + 4 + 4 * k + i, M(PF0T + e) | s.leftDoor, M(PF1T + e), M(PF2T + e));
  }
  for (let y = BOTTOM - 3; y <= BOTTOM; y++) pfLine(y, 0xE0, 0xFF, s.entry === 1 ? 0xFF : 0x07);
  // The kernel writes PF1 near the end of the line before each new row: pixels 142-143
  // (the right copy of PF1 bit 7) already show the new row there.
  for (let k = 0; k < 42; k++) {
    const y = TOP + 3 + 4 * k, on = M(PF1T + k + 2 + s.mazeOff) & 0x80;
    for (const x of [142, 143]) { const i = y * 160 + x; ob[i] = on ? ob[i] | 32 : ob[i] & ~32; }
  }

  // player 0: humanoid or Evil Otto, rows of 2 lines, VDELP0 moves it down a line
  const p0x = (s.p0Hi === 0xFE ? s.ottoX : s.humX) + 3;
  // (the kernel never clears its graphics byte after the last row: a shape that doesn't end
  // in a blank row smears down to the bottom of the play area)
  // It stops after line 212; with VDELP0 the kernel's last lines go differently: line 211
  // still shows row 85 and line 212 shows row 87 (row 86 never appears).
  for (let y = 2 * s.p0Top + 38 + s.vdel; y <= 212; y++) {
    let r = (y - 38 - s.vdel) >> 1;
    if (s.vdel && y === 211) r = 85;
    if (s.vdel && y === 212) r = 87;
    if (r >= 0x58) break;
    if (r < 2) continue;                               // the kernel's first row is row 2
    const g = M(s.p0Ptr + Math.min(r, s.p0Bot - 1));
    for (let b = 0; b < 8; b++) if (g & (0x80 >> b)) set(y, s.refp0 & 8 ? p0x + 7 - b : p0x + b, 1);
  }
  // player 1: robots, 9 rows of 2 lines from the top of their band
  const bands = [];
  for (let i = 0; i < 8 && s.robots[i].y !== 0x7F; i++) {
    const { y, x, gfx, delay } = s.robots[i];
    // The band starts a cycle late (3 pixels) when its first row is inside player 0's rows and
    // reading player 0's graphics there crosses a page.
    const late = y >= s.p0Top && y < s.p0Bot && (s.p0Ptr & 0xFF) + y > 0xFF ? 3 : 0;
    // where on its first line the robot shot's new row takes effect (written after repositioning)
    const d = delay << 24 >> 24;
    bands.push({ y, split: (d >= 0 ? 31 + 15 * d : 4) + late });
    for (let r = 0; r < 9; r++) {
      const g = M(ROBOTGFX + gfx + r);
      for (let b = 0; b < 8; b++) if (g & (0x80 >> b)) { set(2 * y + 39 + 2 * r, x + 6 + late + b, 2); set(2 * y + 40 + 2 * r, x + 6 + late + b, 2); }
    }
  }
  // missiles: enable bit 1 of the table byte for each kernel row
  const missile = (ptr, x, nusiz, lineOfs, bit, first, bandRows = []) => {
    const w = 1 << ((nusiz >> 4) & 3);
    for (let r = first; r < 0x57; r++) {        // (the kernel's first enable is for row `first`)
      const on = M(ptr + r) & 2, band = bandRows.find(b => b.y + 1 === r);
      for (let i = 0; i < w; i++) {
        // first line: on a band start, pixels left of the split still show the previous row
        if (band && x + i < band.split ? M(ptr + r - 1) & 2 : on) set(2 * r + lineOfs, x + i, bit);
        if (on) set(2 * r + lineOfs + 1, x + i, bit);
      }
    }
  };
  missile(s.m0Ptr, HPOS[s.shotX], s.nusiz0, 36, 4, 3);
  missile(s.m1Ptr, HPOS[s.rsX], s.nusiz1, 35, 8, 4, bands);
  return ob;
}

// ---- collisions: the TIA's 15 latches (bit order as tools/vcs.js) from line 40 (where the
// kernel clears them) down, and the robot-band latches the kernel saves at each band start:
// ((P1-PF | M0-P1 | P0-P1) bit 7) | (M1-P1 bit 0), cumulative, at line 2Y+37 of the next band.
const PAIRS = [[4, 2], [4, 1], [8, 1], [8, 2], [1, 32], [1, 16], [2, 32], [2, 16], [4, 32], [4, 16], [8, 32], [8, 16], [16, 32], [1, 2], [4, 8]];
function collide(ob, s) {
  let cx = 0;
  const robots = s.robots.filter(r => r.y !== 0x7F);
  const latch = [];
  let next = 0;                                          // band whose start line we're looking for
  const save = () => latch.push(((cx >> 6 | cx >> 0 | cx >> 13) & 1 ? 0x80 : 0) | (cx >> 3 & 1));
  for (let y = 40; y <= BOTTOM; y++) {
    while (next < robots.length && y === 2 * robots[next].y + 37) { save(); next++; }
    for (let x = 0; x < 160; x++) {
      const o = ob[y * 160 + x];
      if (o & (o - 1)) PAIRS.forEach(([a, b], i) => { if ((o & a) && (o & b)) cx |= 1 << i; });
    }
  }
  while (next < robots.length) { save(); next++; }
  save();                                                // the kernel's last save, after the play area
  return { cx, latch };
}

// ---- snapshot the state as the kernel starts (from any VCS, at $F84D)
function snap(v) {
  const R = a => v.ram[a - 0x80], w = a => R(a) | R(a + 1) << 8;
  return {
      room: R(0x81), mazeOff: R(0x83), leftDoor: R(0xE1), entry: R(0xE2),
      p0Ptr: w(0x89), p0Hi: R(0x8A), p0Top: R(0x8C), p0Bot: R(0x8D), humX: R(0x93), ottoX: R(0xAE),
      vdel: v.r[0x25] & 1, refp0: v.r[0x0B], nusiz0: v.r[0x04], nusiz1: v.r[0x05],
      m0Ptr: w(0x8F), shotX: R(0x96), m1Ptr: w(0x98), rsX: R(0x9D),
      robots: [...Array(8)].map((_, i) => ({ y: R(0xB8 + i), x: R(0xC1 + i), gfx: R(0xAF + i), delay: R(0xA7 + i) })),
  };
}
// What the model predicts for another emulator stopped at $F84D: { cx, latch }
function predict(v) {
  const saved = M;
  M = a => a >= 0xF000 ? rom[a - 0xF000] : v.ram[(a & 0xFF) - 0x80];
  const s = snap(v), r = collide(model(s), s);
  M = saved;
  return { ...r, state: s };
}
module.exports = { model, collide, snap, predict };
if (require.main !== module) return;

// --trace <frame>: log the missile enables and robot band starts as the kernel writes them
const traceAt = process.argv.indexOf('--trace');
const traceFrame = traceAt > 0 ? +process.argv[traceAt + 1] : -1;
const origWrite = vcs.tiaWrite.bind(vcs);
vcs.tiaWrite = function (a, v) {
  if (this.frames + 1 === traceFrame && (a === 0x1D || a === 0x1E || a === 0x11) && this.line >= 30 && this.line < 220)
    console.log(`line ${this.line} clock ${this.clock} ${({ 0x1D: 'ENAM0', 0x1E: 'ENAM1', 0x11: 'RESP1' })[a]}=${v} y=${this.y}`);
  return origWrite(a, v);
};
let state = null;
const origStep = vcs.step.bind(vcs);
vcs.step = function () {
  if (this.pc === 0xF84D) state = snap(vcs);
  if (this.pc === 0xF1DD && state) check();          // play area drawn; the game is about to read the collisions
  if (this.pc === 0xF1DD && predicted) {
    const real = this.cx, latches = [...Array(8)].map((_, i) => vcs.ram[0xC9 - 0x80 + i]);
    if (real !== predicted.cx) { cxBad++; cxEx = cxEx || `frame ${this.frames}: 2600 ${real.toString(2)} model ${predicted.cx.toString(2)}`; }
    const n = predicted.latch.length;              // latches the kernel saved this frame: $C9..
    const ok = predicted.latch.every((v, i) => i >= 8 || latches[i] === v);
    if (!ok) { latchBad++; latchEx = latchEx || `frame ${this.frames}: 2600 ${latches.slice(0, n).map(v => v.toString(16))} model ${predicted.latch.map(v => v.toString(16))}`; }
    predicted = null;
  }
  return origStep();
};

// lines around the differences, 2600 vs model ('#' both, 'A' 2600 only, 'm' model only)
function picture(a, b, bit) {
  let y0 = 999, y1 = -1, x0 = 999, x1 = -1;
  for (let y = TOP; y <= BOTTOM; y++) for (let x = 0; x < 160; x++)
    if ((a[y * 160 + x] | b[y * 160 + x]) & bit) { y0 = Math.min(y0, y); y1 = Math.max(y1, y); x0 = Math.min(x0, x); x1 = Math.max(x1, x); }
  if (bit === 32) { x0 = 0; x1 = 159; }
  for (let y = Math.max(TOP, y0 - 1); y <= Math.min(BOTTOM, y1 + 1); y++) {
    let r = '';
    for (let x = Math.max(0, x0 - 2); x <= Math.min(159, x1 + 2); x++) {
      const p = !!(a[y * 160 + x] & bit), q = !!(b[y * 160 + x] & bit);
      r += p && q ? '#' : p ? 'A' : q ? 'm' : '.';
    }
    if (bit !== 32 || /[Am]/.test(r)) console.log(String(y).padStart(3), r);
  }
}
const NAMES = { 1: 'P0', 2: 'P1', 4: 'M0', 8: 'M1', 32: 'PF' };
const bad = {}, examples = {};
let ottoFrames = 0, checked = 0, cxBad = 0, latchBad = 0, cxEx = '', latchEx = '';
let predicted = null;
function check() {
  if (state.room !== 2) { state = null; return; }
  if (state.p0Hi === 0xFE) ottoFrames++;
  const ob = model(state);
  predicted = { ...collide(ob, state), n: state.robots.findIndex(r => r.y === 0x7F) };
  checked++;
  for (const bit of [1, 2, 4, 8, 32]) {
    let n = 0, first = null;
    for (let y = TOP; y <= BOTTOM; y++) for (let x = 0; x < 160; x++) {
      const a = !!(vcs.ob[y * 160 + x] & bit), b = !!(ob[y * 160 + x] & bit);
      if (a !== b) { n++; if (!first) first = `line ${y} x ${x}: 2600 ${a ? 'on' : 'off'}, model ${b ? 'on' : 'off'}`; }
    }
    if (show && show.frame === vcs.frames && show.name === NAMES[bit]) { console.log(JSON.stringify(state.robots), 'p0', state.p0Top, state.p0Bot, 'hm', [...Array(8)].map((_, i) => vcs.ram[0x9F - 0x80 + i].toString(16)).join(' '), 'dly', [...Array(8)].map((_, i) => vcs.ram[0xA7 - 0x80 + i].toString(16)).join(' ')); picture(vcs.ob, ob, bit); }
    if (n) { bad[NAMES[bit]] = (bad[NAMES[bit]] || 0) + 1; if (!examples[NAMES[bit]] || verbose) examples[NAMES[bit]] = `frame ${vcs.frames}: ${n} pixels, ${first}`; if (verbose) console.log(NAMES[bit], examples[NAMES[bit]]); }
  }
  state = null;
}

let seed = +(process.argv.find(a => a.startsWith('--seed=')) || '--seed=11').slice(7);
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const game = +(process.argv.find(a => a.startsWith('--game=')) || '--game=1').slice(7);   // 1-12
vcs.runFrames(10);
vcs.ram[0] = Math.floor(game / 10) * 16 + game % 10;   // GameNumber ($80, BCD), read when a game starts
vcs.fire[0] = true; vcs.runFrames(3); vcs.fire[0] = false;
for (let f = 0; f < frames; f++) {
  if (f % 15 === 0) {                // --bias=down|up|left|right: head that way more often (to reach the exits)
    const r = rnd(), bias = { down: 0xDF, up: 0xEF, left: 0xBF, right: 0x7F }[(process.argv.find(a => a.startsWith('--bias=')) || '').slice(7)];
    vcs.swcha = bias && r < 0.5 ? bias : [0x7F, 0xBF, 0xEF, 0xDF, 0xFF, 0x6F, 0x5F][Math.floor(rnd() * 7)];
    vcs.fire[0] = rnd() < .35;
  }
  if (vcs.ram[0xDA - 0x80] & 0x80) { vcs.fire[0] = true; }   // game over: start another
  vcs.runFrames(1);
}
console.log(`${checked} frames checked (${ottoFrames} with Evil Otto)`);
console.log('collisions', cxBad ? `${cxBad} frames differ, e.g. ${cxEx}` : 'exact');
console.log('band latches', latchBad ? `${latchBad} frames differ, e.g. ${latchEx}` : 'exact');
for (const k of Object.keys(NAMES).map(b => NAMES[b])) console.log(k.padEnd(3), bad[k] ? `${bad[k]} frames differ, e.g. ${examples[k]}` : 'exact');
