// Quick runner: boot the ROM, optionally press Game Reset, step frames, save screenshots.
//   node games/berzerk/tools/run.js <frames> [out.png] [--reset]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('136f75c4dd02c29283752b7e5799f978'));
let lines = 0;
vcs.onFrame = v => { lines = v.line; };
const frames = +(process.argv[2] || 60);
if (process.argv.includes('--reset')) {
  vcs.runFrames(10);
  vcs.swchb &= ~1; vcs.runFrames(5); vcs.swchb |= 1;   // press and release Game Reset
}
vcs.runFrames(frames);
console.log('frames', vcs.frames, 'lines/frame', lines, 'cycles', vcs.cycles);
const hex = b => [...b].map(x => x.toString(16).padStart(2, '0')).join(' ');
for (let i = 0; i < 128; i += 16) console.log((0x80 + i).toString(16), hex(vcs.ram.subarray(i, i + 16)));
if (process.argv[3] && !process.argv[3].startsWith('--')) { vcs.savePNG(process.argv[3]); console.log('saved', process.argv[3]); }
