// Run the C64 port's game ticks (the patched 2600 program plus our collision code,
// from build/berzerk-<version>.prg) on a plain 6502 with 64K of memory, side by side with
// the original game in tools/vcs.js, with the same joystick inputs. After every
// frame the two must have the same 2600 RAM at the same point: just after the
// picture (the C64 side has worked out its collisions; the 2600 has drawn it). Any difference is a bug in a patch or in the collisions.
//   node games/berzerk/tools/lockstep.js [frames] [--seed=N] [--game=N] [--verbose]
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const ROMMD5 = '136f75c4dd02c29283752b7e5799f978';
const rom = require('../../../tools/rom').load(ROMMD5);
const build = path.join(__dirname, '..', 'build');
const prg = fs.readFileSync(require('../../../tools/buildname').files(path.join(build)).prg);
const lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(build)).lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[1], 16);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 3000);
const verbose = process.argv.includes('--verbose');

// ---- the C64 side: the VCS 6502 core on a flat 64K memory
class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) { this.mem[a & 0xFFFF] = v; }
  commit() {}
  flush() {}
  tick(n) { this.cycles += n; }
  call(addr, limit = 2e6) {      // JSR addr from a stub, run until it returns
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    const start = this.cycles;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error('runaway at $' + this.pc.toString(16)); }
    return this.cycles - start;
  }
}
const c64 = new C64();
// --profile: cycles spent in each routine (by the nearest label before the PC)
const profile = process.argv.includes('--profile') ? {} : null;
const labels = [...lst.matchAll(/^\.([0-9a-f]{4})\t.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[1], 16), m[2]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xF000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
const tickProf = {}; let worst = { cyc: 0 };
if (profile) { const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc), d = this.cycles - c; profile[k] = (profile[k] || 0) + d; tickProf[k] = (tickProf[k] || 0) + d; return r; }; }
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
// what Start does that matters here: the 2600 image at $F000, the RIOT ports, the tables
c64.mem.set(c64.mem.subarray(sym('GameImage'), sym('GameImage') + 0x1000), 0xF000);
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x3C] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));

// ---- the original
const vcs = new VCS(rom);
let atKernel = false, kernelFrame = -1;   // (the 2600 waits for its timer there: stop once a frame)
const origStep = vcs.step.bind(vcs);
const { predict } = require('./model');
let prediction = null;
vcs.step = function () { if (this.pc === 0xF84D) prediction = predict(this); if (this.pc === 0xF1DD && this.frames !== kernelFrame) { atKernel = true; kernelFrame = this.frames; } return origStep(); };
const runToKernel = () => { atKernel = false; let g = 0; while (!atKernel) { vcs.step(); if (++g > 1e6) throw new Error('2600 never reached the kernel'); } };

// bytes the two may legitimately disagree on: the stack (on the 2600 it is page zero's top),
// and the kernel's own working bytes (robot graphics rows, band, positioning), set before use
const IGNORE = new Set([0xFE, 0xFF, 0xFC, 0xE6, 0xAF, 0xB0, 0xB1, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6]);
const NAMES = {};
for (const [a, n, size] of require('../2600/symbols.js').ram) for (let i = 0; i < size; i++) NAMES[a + i] = size > 1 ? `${n}+${i}` : n;

let seed = arg('seed', 11);
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const game = arg('game', 1);
let ottoFrames = 0, swcha = 0xFF, fire = false, maxCycles = 0, totalCycles = 0, bad = 0, done = 0, maxRender = 0, totalRender = 0;
for (let f = 0; f < frames; f++) {
  if (f === 1) vcs.ram[0] = c64.mem[0x80] = Math.floor(game / 10) * 16 + game % 10;    // game number (after power-on cleared it)
  if (f % 15 === 0) {                // --bias=down|up|left|right: head that way more often (to reach the exits)
    const bias = { down: 0xDF, up: 0xEF, left: 0xBF, right: 0x7F }[String(arg('bias', ''))];
    swcha = bias && rnd() < 0.5 ? bias : [0x7F, 0xBF, 0xEF, 0xDF, 0xFF, 0x6F, 0x5F, 0xAF, 0x9F][Math.floor(rnd() * 9)];
    fire = rnd() < .35;
  }
  if (vcs.ram[0x5A] & 0x80) fire = f % 30 < 15;        // no game: press fire to start one
  vcs.swcha = swcha; vcs.fire[0] = fire;
  c64.mem[0x0280] = swcha; c64.mem[0x3C] = fire ? 0 : 0x80;
  prediction = null;
  runToKernel();
  if (profile) for (const k in tickProf) delete tickProf[k];
  const cyc = c64.call(sym('Tick'));
  if (profile && cyc > worst.cyc) worst = { cyc, f, prof: { ...tickProf } };
  if (f === 0) { c64.mem[0xE3] = vcs.ram[0x63]; c64.mem[0xE4] = vcs.ram[0x64]; }   // the 2600 seeds its random numbers from the timer at power-on
  maxCycles = Math.max(maxCycles, cyc); totalCycles += cyc;
  c64.mem[sym('pending')] = 0;                          // draw it, as the main loop would
  const rc = c64.call(sym('Render'));
  maxRender = Math.max(maxRender, rc); totalRender += rc;
  done++;
  if (c64.mem[0x8A] === 0xFE) ottoFrames++;
  const diffs = [];
  for (let a = 0x80; a < 0x100; a++) if (!IGNORE.has(a) && vcs.ram[a - 0x80] !== c64.mem[a])
    diffs.push(`${NAMES[a] || '$' + a.toString(16)} 2600 ${vcs.ram[a - 0x80].toString(16)} C64 ${c64.mem[a].toString(16)}`);
  if (diffs.length) {
    bad++;
    if (bad <= 3 || verbose) {
      console.log(`frame ${f}: ${diffs.join(', ')}`);
      if (prediction) {
        const st = prediction.state, z = n => c64.mem[sym(n)];
        console.log(`  robots ${st.robots.filter(r => r.y !== 0x7F).map(r => `y${r.y} x${r.x} d${r.delay}`).join(', ')} | M1 x${st.rsX + 2} nusiz ${st.nusiz1.toString(16)} ptr ${st.m1Ptr.toString(16)} | p0 ${st.p0Top}-${st.p0Bot}`);
        console.log(`  C64: m1 x${z('m1x')} mask ${z('m1mask').toString(16)} lines ${z('m1first')}-${z('m1last')}; robots ${z('nRob')}: px ${[...Array(z('nRob'))].map((_, i) => c64.mem[sym('RobPX') + i]).join(' ')}; band rows ${[...Array(z('nRob'))].map((_, i) => c64.mem[sym('BandRow') + i] + '/' + c64.mem[sym('BandSplit') + i]).join(' ')}`);
      }
      if (process.argv.includes('--p0lines')) { const hits = []; for (let y = 0; y < 262; y++) for (let x = 0; x < 160; x++) if ((vcs.ob[y * 160 + x] & 33) === 33) hits.push(y + ':' + x); console.log('  P0+PF pixels:', hits.slice(0, 20).join(' '), 'P0 lines:', [...new Set([...Array(262 * 160).keys()].filter(i => vcs.ob[i] & 1).map(i => Math.floor(i / 160)))].join(',')); }
      if (false) for (let y = 200; y < 217; y++) { let t = ''; for (let x = 0; x < 160; x++) { const o = vcs.ob[y * 160 + x]; t += o & 1 ? (o & 32 ? 'X' : '0') : o & 32 ? '#' : '.'; } console.log(String(y).padStart(3), t.slice(40, 120)); }
      if (prediction) console.log(`  model: collisions ${prediction.cx.toString(2)} latches ${prediction.latch.map(v => v.toString(16))}; 2600 collisions ${vcs.cx.toString(2)}; C64 ${[0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x37].map(a => c64.mem[a].toString(16)).join(' ')}`);
    }
    if (bad === 3 && !verbose) { console.log('... stopping'); break; }
    for (let a = 0x80; a < 0x100; a++) c64.mem[a] = vcs.ram[a - 0x80];   // resync and carry on
  }
}
if (profile) console.log(`worst tick: frame ${worst.f}, ${worst.cyc} cycles: ` + Object.entries(worst.prof).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k, v]) => `${k} ${v}`).join(', '));
if (profile) { const tot = Object.values(profile).reduce((a, b) => a + b, 0); for (const [k, v] of Object.entries(profile).sort((a, b) => b[1] - a[1]).slice(0, 25)) console.log(k.padEnd(16), String(Math.round(v / done)).padStart(7), (100 * v / tot).toFixed(1) + '%'); }
console.log(`${done} frames (${ottoFrames} with Evil Otto), ${bad} with differences; C64 tick: ${Math.round(totalCycles / done)} cycles on average, ${maxCycles} at most; render: ${Math.round(totalRender / done)} on average, ${maxRender} at most`);
