// Check where the C64 version draws things against the 2600's picture. Runs the
// C64 port (ticks and Render, as in lockstep.js) next to tools/vcs.js, then draws
// the C64 frame in JavaScript from what Render staged (characters, sprite
// registers, the raster schedule), maps it back to 2600 pixels and compares it
// with the 2600's framebuffer, object by object.
//   node games/berzerk/tools/screencheck.js [frames] [--seed=N] [--png=dir]
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('136f75c4dd02c29283752b7e5799f978');
const build = path.join(__dirname, '..', 'build');
const prg = fs.readFileSync(require('../../../tools/buildname').files(path.join(build)).prg);
const lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(build)).lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[1], 16);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? a.split('=')[1] : d; };
const frames = +(process.argv[2] || 1000);

class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) { this.mem[a & 0xFFFF] = v; }
  commit() {} flush() {} tick(n) { this.cycles += n; }
  call(addr) {
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], 0x0300);
    this.pc = 0x0300;
    for (let i = 0; this.pc !== 0x0303; i++) { this.step(); if (i > 3e6) throw new Error('runaway at $' + this.pc.toString(16)); }
  }
}
const c64 = new C64();
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
c64.mem.set(c64.mem.subarray(sym('GameImage'), sym('GameImage') + 0x1000), 0xF000);
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x3C] = 0x80; c64.mem[sym('firstTick')] = 1;
c64.call(sym('InitVideo'));

// ---- the C64 picture from the staged frame, as 2600 pixels: 160 x 262, bit per object kind
const LINEOFS = 31, SPRYOFS = 19;
const B = { chars: 32, s0: 1, s1: 1, s2: 4, s3: 8, robot: 2, digits: 64 };
function c64Picture() {
  const m = c64.mem, ob = new Uint8Array(160 * 262);
  const buf = m[sym('curBuf')] ^ 1;               // the buffer Render just filled
  // characters: screen rows 1-22, maze charset; one character = 4 2600 pixels x 8 lines
  for (let row = 1; row <= 22; row++) for (let col = 0; col < 40; col++) {
    const ch = m[0x4400 + row * 40 + col];
    for (let l = 0; l < 8; l++) if (m[0x7800 + ch * 8 + l]) for (let i = 0; i < 4; i++) ob[(row * 8 + l + LINEOFS) * 160 + col * 4 + i] |= 32;
  }
  // The VIC can't start a sprite again until its last display (21 rows, 42 lines
  // Y-expanded) has finished: such a reuse is lost, and counted in vicLost.
  const busy = new Array(8).fill(-1);
  const sprite = (ptr, x9, y, yexp, bit, n) => {      // x9: sprite X register (9 bits)
    const start = y - SPRYOFS;
    if (start < busy[n]) { vicLost++; vicEx = vicEx || `frame ${curFrame}: sprite ${n} wanted at line ${start}, busy until ${busy[n]}`; return; }
    busy[n] = start + (yexp ? 43 : 22);   // (the DMA is off only in cycle 16 of the line after the last; a start is looked for in cycle 55)
    const base = 0x4000 + ptr * 64;
    for (let r = 0; r < 21; r++) for (let k = 0; k < 3; k++) {
      const v = m[base + r * 3 + k];
      for (let b = 0; b < 8; b++) if (v & (0x80 >> b)) {
        const cx = x9 - 24 + 2 * (k * 8 + b);          // X-expanded: each bit 2 C64 pixels
        const px = cx >> 1;
        for (let dy = 0; dy < (yexp ? 2 : 1); dy++) {
          const line = y - SPRYOFS + (yexp ? 2 * r + dy : r);
          if (px >= 0 && px < 160 && line >= 0 && line < 262) ob[line * 160 + px] |= bit;
        }
      }
    }
  };
  const en = m[sym('StEn') + buf], msb = m[sym('StMsb') + buf], yexp = m[sym('StYexp') + buf];
  const bits = [1, 1, 4, 8, 2, 2, 2, 2];
  const BAR1 = 222;                  // HMOVE bar shapes: blocks BLK_BAR1 (222) and BLK_BAR2
  for (let n = 0; n < 8; n++) if (en & (1 << n)) {
    const ptr = m[sym('StPtr') + 8 * buf + n];
    sprite(ptr, m[sym('StX') + 8 * buf + n] + (msb & (1 << n) ? 256 : 0), m[sym('StY') + 8 * buf + n], yexp & (1 << n), ptr >= BAR1 ? 128 : bits[n], n);
  }
  // robots 4-7 and the score line from the schedule
  const base = 16 * buf;
  for (let i = 0; i < 16; i++) {
    const type = m[sym('SchedType') + base + i];
    if (type === 10) break;
    if (type === 12) { const y = m[sym('SchedArg') + base + i]; sprite(m[sym('BarPtr') + y], 24, m[sym('BarY') + y], 0, 128, 1); }
    if (type === 2) { const y = m[sym('SchedArg') + base + i]; sprite(m[sym('RbPtr') + y], m[sym('RbX') + y] + (m[sym('RbMsb') + y] ? 256 : 0), m[sym('RbY') + y], 0, 2, 4 + (y & 3)); }
    if (type === 4) {
      const p = m[sym('DgPtr') + buf], dx = 55;
      sprite(p, 24 + 2 * dx, 218 + SPRYOFS, 0, 64, 4); sprite(p + 1, 24 + 2 * (dx + 24), 218 + SPRYOFS, 0, 64, 5);
    }
  }
  return ob;
}

// ---- run both
const vcs = new VCS(rom);
let atFrame = false, kf = -1;
const os = vcs.step.bind(vcs);
vcs.step = function () { if (this.pc === 0xF1DD && this.frames !== kf) { atFrame = true; kf = this.frames; } return os(); };
let seed = +arg('seed', 11);
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
let swcha = 0xFF, fire = false;
let barFrames = 0, vicLost = 0, vicEx = '', curFrame = 0;
const NAMES = { 128: 'HMOVE bars', 1: 'player 0', 2: 'robots', 4: 'shot', 8: 'robot shot', 32: 'maze', 64: 'score' };
const KERNELBYTES = new Set([0xFE, 0xFF, 0xFC, 0xE6, 0xAF, 0xB0, 0xB1, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6]);
const bad = {}, ex = {};
let checked = 0, allFrames = 0, scoreBad = 0, scoreEx = '';
const pngDir = arg('png', null);
for (let f = 0; f < frames; f++) {
  if (f % 15 === 0) { swcha = [0x7F, 0xBF, 0xEF, 0xDF, 0xFF, 0x6F, 0x5F, 0xAF, 0x9F][Math.floor(rnd() * 9)]; fire = rnd() < .35; }
  if (vcs.ram[0x5A] & 0x80) fire = f % 30 < 15;
  vcs.swcha = swcha; vcs.fire[0] = fire;
  c64.mem[0x0280] = swcha; c64.mem[0x3C] = fire ? 0 : 0x80;
  atFrame = false; while (!atFrame) vcs.step();          // the 2600 has drawn this frame
  c64.call(sym('Tick'));
  if (f === 0) { c64.mem[0xE3] = vcs.ram[0x63]; c64.mem[0xE4] = vcs.ram[0x64]; }
  // keep the game state identical (but not the kernel's working bytes, which the 2600's
  // kernel has changed and the C64 never does: robot graphics rows, band, positioning)
  for (let a = 0x80; a < 0x100; a++) if (!KERNELBYTES.has(a)) c64.mem[a] = vcs.ram[a - 0x80];
  c64.mem[sym('pending')] = 0;
  c64.call(sym('Render'));
  curFrame = f;
  const ob = c64Picture();
  { // the score line in every frame (attract, room changes, play)
    let n = 0, first = '';
    for (let y = 218; y <= 224; y++) for (let x = 0; x < 160; x++) {
      const a = !!(vcs.ob[y * 160 + x] & 3), b = !!(ob[y * 160 + x] & 64);
      if (a !== b) { n++; if (!first) first = `line ${y} x ${x}: 2600 ${a ? 'on' : 'off'}, C64 ${b ? 'on' : 'off'}`; }
    }
    allFrames++;
    if (n) { scoreBad++; scoreEx = scoreEx || `frame ${f} (RoomState ${vcs.ram[0x01].toString(16)}, Lives ${vcs.ram[0x5A].toString(16)}): ${n} pixels, ${first}`; }
  }
  if (vcs.ram[0x01] !== 2 || c64.mem[sym('snTrans')]) continue;   // the rest: play frames only
  checked++;
  // compare: maze, robots, shots everywhere in the play area; player 0 where the 2600
  // drew it (the C64 doesn't copy the smear past its last row); the score line
  const p0end = 2 * vcs.ram[0x0D] + 38 + (vcs.r[0x25] & 1);   // player 0's last row ends here
  const skip = (bit, y, x) => (bit === 32 && x >= 142 && x <= 143 && (y - 39) % 4 === 3) ||   // the maze quirk
                              (bit === 1 && y >= p0end);                                     // the smear
  // HMOVE blanking (tools/vcs.js doesn't draw it): pixels 0-7 of the line above each robot
  const notch = new Set([...Array(8).keys()].map(i => vcs.ram[0x38 + i]).filter(y => y !== 0x7F).map(y => 2 * y + 38));
  const check = (bit, tia, y0, y1) => {
    let n = 0, first = '';
    for (let y = y0; y <= y1; y++) for (let x = 0; x < 160; x++) {
      if (skip(bit, y, x)) continue;
      const a = !!(vcs.ob[y * 160 + x] & tia) && !(bit === 32 && x < 8 && notch.has(y)), b = !!(ob[y * 160 + x] & bit);
      if (a !== b) { n++; if (!first) first = `line ${y} x ${x}: 2600 ${a ? 'on' : 'off'}, C64 ${b ? 'on' : 'off'}`; }
    }
    if (n) { bad[bit] = (bad[bit] || 0) + 1; ex[bit] = ex[bit] || `frame ${f}: ${n} pixels, ${first}`; }
  };
  check(32, 32, 39, 214);
  check(2, 2, 39, 214);
  check(4, 4, 39, 214);
  check(8, 8, 39, 214);
  check(1, 1, 39, 200);
  check(64, 3, 218, 224);
  { // the HMOVE bars (sprite 1, when Evil Otto isn't using it): pixels 0-7 of each notch line
    let n = 0, first = '', any = false;
    for (let y = 39; y <= 214; y++) for (let x = 0; x < 16; x++) { if (ob[y * 160 + x] & 128) any = true; }
    if (any) for (let y = 39; y <= 214; y++) for (let x = 0; x < 16; x++) {
      const want = x < 8 && notch.has(y), got = !!(ob[y * 160 + x] & 128);
      if (want !== got) { n++; if (!first) first = `line ${y} x ${x}: want ${want ? 'bar' : 'none'}`; }
    }
    if (any) barFrames++;
    if (n) { bad[128] = (bad[128] || 0) + 1; ex[128] = ex[128] || `frame ${f}: ${n} pixels, ${first}`; }
  }
}
console.log(`score line, all ${allFrames} frames:`, scoreBad ? `${scoreBad} differ, e.g. ${scoreEx}` : 'exact');
console.log(`${checked} play frames compared`);
console.log(`(HMOVE bars drawn in ${barFrames} frames)`);
console.log('sprite reuse', vicLost ? `${vicLost} lost (the VIC would skip them), e.g. ${vicEx}` : 'always in time');
for (const bit of [32, 2, 1, 4, 8, 64, 128]) console.log(NAMES[bit].padEnd(11), bad[bit] ? `${bad[bit]} frames differ, e.g. ${ex[bit]}` : 'exact');
