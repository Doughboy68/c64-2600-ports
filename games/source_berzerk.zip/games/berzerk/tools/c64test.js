// Scripted play test of the C64 build in VICE (through the remote monitor):
// start it, press fire, wander about firing, and save screenshots.
//   node games/berzerk/tools/c64test.js <outdir> [seconds-of-play] [--timing] [--ntsc] [--game=N] [--still] [--noflicker]
const fs = require('fs');
const net = require('net');
const path = require('path');
const { execSync, spawn } = require('child_process');

const out = path.resolve(process.argv[2] || '.');
const playSeconds = +(process.argv[3] || 20);
const timing = process.argv.includes('--timing');
const ntsc = process.argv.includes('--ntsc');
const still = process.argv.includes('--still');
const gameArg = process.argv.find(a => a.startsWith('--game='));
const game = gameArg ? +gameArg.slice(7) : 0;
const root = path.join(__dirname, '..');
const lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(root, 'build')).lst, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return m[1];
};
const A = { swcha: addr('DbgSWCHA'), inpt4: addr('DbgINPT4'), swchb: addr('DbgSWCHB'), border: addr('DbgBorder'), flicker: addr('Flicker') };
const sleep = ms => new Promise(r => setTimeout(r, ms));

function mon(cmds) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(6510, '127.0.0.1');
    let buf = '';
    sock.on('data', d => { buf += d.toString('latin1'); });
    sock.on('error', reject);
    sock.on('connect', async () => {
      await sleep(150);
      for (const c of cmds) { sock.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 150); }
      sock.write('x\n');
      await sleep(100);
      sock.end();
      resolve(buf.replace(/\(C:\$[0-9a-f]{4}\) /g, ''));
    });
  });
}
const poke = (a, v) => mon([`> ${a} ${v}`]);
const shot = name => mon([`screenshot "${path.join(out, name).replace(/\\/g, '/')}" 2`]);

(async () => {
  fs.mkdirSync(out, { recursive: true });
  // (any VICE already running is left alone; only the one started here is closed at the end)
  const pids = () => execSync('powershell -NoProfile -Command "(Get-Process x64sc -ErrorAction SilentlyContinue).Id"').toString().split(/\s+/).filter(Boolean);
  const before = pids();
  await sleep(500);
  spawn('x64sc', ['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', 'ip4://127.0.0.1:6510',
    '-autostartprgmode', '1', '-autostart', require('../../../tools/buildname').files(path.join(root, 'build')).prg],
    { detached: true, stdio: 'ignore', shell: true }).unref();
  await sleep(7000);
  if (timing) await poke(A.border, '1');
  await shot('t0-attract.png');
  if (game) await poke('0080', (Math.floor(game / 10) * 16 + game % 10).toString(16));   // GameNumber (BCD)
  if (process.argv.includes('--noflicker')) await poke(A.flicker, '0');
  await poke(A.inpt4, '7f'); await sleep(600); await poke(A.inpt4, 'ff');   // fire: start a game
  await sleep(2500);
  await shot('t1-start.png');
  let seed = 1;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const t0 = Date.now();
  let n = 0;
  const DIRS = ['7f', 'bf', 'ef', 'df', 'ff'];
  while (Date.now() - t0 < playSeconds * 1000) {
    if (!still) await poke(A.swcha, DIRS[Math.floor(rnd() * DIRS.length)]);
    await sleep(500);
    if (!still && rnd() < 0.5) { await poke(A.inpt4, '7f'); await sleep(150); await poke(A.inpt4, 'ff'); }
    if (++n % (still ? 3 : 6) === 0) await shot(`t2-play${String(n / 6).padStart(2, '0')}.png`);
  }
  await poke(A.swcha, 'ff');
  await shot('t3-end.png');
  await sleep(500);
  for (const id of pids().filter(i => !before.includes(i))) execSync(`powershell -NoProfile -Command "Stop-Process -Id ${id}"`);
})();
