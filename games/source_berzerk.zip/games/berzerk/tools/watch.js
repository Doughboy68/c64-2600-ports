// Play a scripted game in tools/vcs.js and print chosen RAM bytes every few frames,
// to check what each byte means.
//   node games/berzerk/tools/watch.js [png-dir]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('136f75c4dd02c29283752b7e5799f978'));
const out = process.argv[2];
const r = a => vcs.ram[a - 0x80];
const h = v => v.toString(16).padStart(2, '0');
const hx = (a, n) => [...Array(n)].map((_, i) => h(r(a + i))).join(' ');
const UP = 0xEF, DOWN = 0xDF, LEFT = 0xBF, RIGHT = 0x7F, NONE = 0xFF;
// [frames, joystick, fire, note]
const script = [
  [10, NONE, false, 'boot'], [4, NONE, false, 'reset'], [60, NONE, false, 'start'],
  [40, RIGHT, false, 'walk right'], [30, DOWN, false, 'walk down'],
  [2, RIGHT, true, 'fire right'], [30, NONE, false, 'shot flies'],
  [40, UP, false, 'walk up'], [200, NONE, false, 'wait'],
];
let shot = 0;
for (const [n, joy, fire, note] of script) {
  if (note === 'reset') vcs.swchb &= ~1; else vcs.swchb |= 1;
  vcs.swcha = joy; vcs.fire[0] = fire;
  for (let i = 0; i < n; i++) {
    vcs.runFrames(1);
    if (i % 10 === 0 || i === n - 1)
      console.log(`${note.padEnd(11)} f${String(vcs.frames).padStart(4)} ` +
        `81=${h(r(0x81))} 84=${h(r(0x84))} hum x93=${h(r(0x93))} y8B=${h(r(0x8B))} 8E=${h(r(0x8E))} 91=${h(r(0x91))} ` +
        `shot 94=${h(r(0x94))} x96=${h(r(0x96))} y97=${h(r(0x97))} | robY ${hx(0xB8, 9)} | robX ${hx(0xC1, 8)} | anim ${hx(0xD2, 8)} | hit ${hx(0xC9, 8)} | ` +
        `otto ${h(r(0xAE))},${h(r(0xD9))} lives DA=${h(r(0xDA))} score ${hx(0xDD, 3)} E0=${h(r(0xE0))} DB=${h(r(0xDB))} DC=${h(r(0xDC))}`);
  }
  if (out) vcs.savePNG(`${out}/w${String(++shot).padStart(2, '0')}-${note.replace(/ /g, '-')}.png`);
}
