// Where Berzerk draws each object, next to the RAM values that control it, over a
// scripted game: prints the offsets (screen line/pixel minus RAM value) seen for each
// object, so the C64 version can place everything on the same pixels.
//   node games/berzerk/tools/geometry.js [frames]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('136f75c4dd02c29283752b7e5799f978'));
const R = a => vcs.ram[a - 0x80];
const frames = +(process.argv[2] || 1500);

// bounding boxes of one object bit, split into vertical groups separated by blank lines
function boxes(bit) {
  const out = []; let cur = null, gap = 0;
  for (let y = 30; y < 216; y++) {   // the play area only (the score line is below)
    let l = 999, r = -1;
    for (let x = 0; x < 160; x++) if (vcs.ob[y * 160 + x] & bit) { if (x < l) l = x; r = x; }
    if (r >= 0) {
      if (!cur || gap > 1) { cur = { top: y, bot: y, l, r }; out.push(cur); }
      cur.bot = y; cur.l = Math.min(cur.l, l); cur.r = Math.max(cur.r, r); gap = 0;
    } else gap++;
  }
  return out;
}

const stats = {};
const note = (k, v) => { (stats[k] = stats[k] || {})[v] = (stats[k][v] || 0) + 1; };
let state = null;   // RAM as it was when this frame's kernel ran
vcs.onFrame = () => {
  if (!state || state.room !== 2) return;
  const p0 = boxes(1), p1 = boxes(2), m0 = boxes(4), m1 = boxes(8), pf = boxes(32);
  if (pf.length) note('PF top/bottom line', `${pf[0].top}/${pf[pf.length - 1].bot}`);
  if (p0.length === 1) {
    const b = p0[0];
    if (!(state.frame & 1) && state.otto >= 3) note('Otto  top-Y, left-X', `${b.top - state.ottoY}, ${b.l - state.ottoX}  (h ${b.bot - b.top + 1})`);
    else if ((state.frame & 1) && state.humY !== 0x7f) note('Human top-Y, left-X', `${b.top - state.humY}, ${b.l - state.humX}  (h ${b.bot - b.top + 1})`);
  }
  // robots: match groups to slots in order
  const robots = state.robots.filter(r => r.y !== 0x7f);
  if (p1.length === robots.length)
    p1.forEach((b, i) => note('Robot top-2*Y, left-X', `${b.top - 2 * robots[i].y}, ${b.l - robots[i].x}  (h ${b.bot - b.top + 1}, w ${b.r - b.l + 1})`));
  if (m0.length === 1 && state.shot) note('Shot top-2Y, left-X', `${m0[0].top - 2 * state.shotY}, ${m0[0].l - state.shotX}  (${m0[0].r - m0[0].l + 1}x${m0[0].bot - m0[0].top + 1})`);
  if (m1.length === 1) note('Robot shot top-2Y, left-X', `${m1[0].top - 2 * state.rsY}, ${m1[0].l - state.rsX}  (${m1[0].r - m1[0].l + 1}x${m1[0].bot - m1[0].top + 1})`);
};
// snapshot the RAM when the kernel starts (first line of the playfield is drawn after VBLANK ends)
const origStep = vcs.step.bind(vcs);
vcs.step = function () {
  if (this.pc === 0xF84D) state = {
    room: R(0x81), frame: R(0x84), humX: R(0x93), humY: R(0x8B), ottoX: R(0xAE), ottoY: R(0xD9),
    shot: R(0x94), otto: R(0xF6), shotX: R(0x96), shotY: R(0x97), rsX: R(0x9D), rsY: R(0x9E),
    robots: [...Array(8)].map((_, i) => ({ y: R(0xB8 + i), x: R(0xC1 + i) })),
  };
  return origStep();
};

let seed = 7;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
vcs.runFrames(10);
vcs.fire[0] = true; vcs.runFrames(3); vcs.fire[0] = false;
for (let f = 0; f < frames; f++) {
  if (f % 20 === 0) { const r = rnd(); vcs.swcha = r < .25 ? 0x7F : r < .5 ? 0xBF : r < .75 ? 0xEF : 0xDF; vcs.fire[0] = rnd() < .3; }
  vcs.runFrames(1);
}
for (const [k, v] of Object.entries(stats))
  console.log(k.padEnd(24), Object.entries(v).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([x, n]) => `${x} [${n}]`).join('   '));
