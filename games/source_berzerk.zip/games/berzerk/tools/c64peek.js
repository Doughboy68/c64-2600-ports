// Start a game in VICE, walk in one direction until the room changes (RoomState
// $FF), then stop there and dump the VIC sprite registers, the sprite pointers,
// the raster schedule and a screenshot - for looking at display problems.
//   node games/berzerk/tools/c64peek.js <outdir> [left|right|up|down]
const net = require('net');
const fs = require('fs');
const path = require('path');
const { spawn, execSync } = require('child_process');
const out = path.resolve(process.argv[2] || '.');
const dir = process.argv[3] || 'left';
const root = path.join(__dirname, '..');
const lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(root, 'build')).lst, 'latin1');
const addr = n => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${n}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + n);
  return parseInt(m[1], 16);
};
const hex = v => v.toString(16);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const mon = cmds => new Promise((resolve, reject) => {
  const s = net.connect(6510, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d; }); s.on('error', reject);
  s.on('connect', async () => { await sleep(150); for (const c of cmds) { s.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 900 : 200); } s.write('x\n'); await sleep(100); s.end(); resolve(b); });
});
const pids = () => execSync('powershell -NoProfile -Command "(Get-Process x64sc -ErrorAction SilentlyContinue).Id"').toString().split(/\s+/).filter(Boolean);
const byte = async a => { const o = await mon([`m ${hex(a)} ${hex(a)}`]); const m = o.match(new RegExp(`>C:${hex(a).padStart(4, '0')}\\s+([0-9a-f]{2})`, 'i')); return m ? parseInt(m[1], 16) : -1; };

let before = [];
(async () => {
  fs.mkdirSync(out, { recursive: true });
  before = pids();
  spawn('x64sc', ['-default', '+sound', '-remotemonitor', '-remotemonitoraddress', 'ip4://127.0.0.1:6510',
    '-autostartprgmode', '1', '-autostart', require('../../../tools/buildname').files(path.join(root, 'build')).prg], { detached: true, stdio: 'ignore', shell: true }).unref();
  await sleep(7000);
  await mon([`> ${hex(addr('DbgINPT4'))} 7f`]); await sleep(500); await mon([`> ${hex(addr('DbgINPT4'))} ff`]);
  await sleep(2500);
  await mon([`> ${hex(addr('DbgSWCHA'))} ${{ left: 'bf', right: '7f', up: 'ef', down: 'df' }[dir]}`]);
  for (let i = 0; i < 200; i++) { if (await byte(0x81) === 0xFF) break; await sleep(100); }
  { // the interrupt's frame-top and score-line counters, twice, 0.3 s apart
    const t = addr('DbgTops');
    for (let i = 0; i < 2; i++) { console.log((await mon([`m ${hex(t)} ${hex(t + 2)}`, 'm 0081 0081'])).replace(/(C:$[0-9a-f]{4}) /g, '').trim()); await sleep(300); }
  }
  const o = await mon([`screenshot "${path.join(out, 'peek.png').split(path.sep).join('/')}" 2`, 'm d000 d02e', `m ${hex(0x4400 + 0x3f8)} ${hex(0x4400 + 0x3ff)}`,
    `m ${hex(addr('curBuf'))} ${hex(addr('curBuf') + 3)}`, `m ${hex(addr('SchedRas'))} ${hex(addr('SchedRas') + 31)}`, `m ${hex(addr('SchedType'))} ${hex(addr('SchedType') + 31)}`,
    `m ${hex(addr('DgPtr'))} ${hex(addr('DgPtr') + 3)}`, 'm 0081 0081', 'm 00ea 00f5', 'm 7380 73ff', 'm 7700 777f', `m ${hex(addr('DgKey'))} ${hex(addr('DgKey') + 23)}`]);
  console.log(o.replace(/\(C:\$[0-9a-f]{4}\) /g, ''));
})().catch(e => console.log(e.message)).finally(() => {
  for (const id of pids().filter(i => !before.includes(i))) execSync(`powershell -NoProfile -Command "Stop-Process -Id ${id}"`);
});
