// Screenshots in quick succession while holding a direction, to look at movement
// and room changes in VICE.
//   node games/berzerk/tools/c64seq.js <outdir> <direction: left|right|up|down|none> [shots] [interval-ms] [--attract]
const fs = require('fs');
const net = require('net');
const path = require('path');
const { execSync, spawn } = require('child_process');
const [outArg, dir = 'left', nArg = '12', ivArg = '250'] = process.argv.slice(2);
const out = path.resolve(outArg || '.');
const root = path.join(__dirname, '..');
const lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(root, 'build')).lst, 'latin1');
const addr = name => lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'))[1];
const sleep = ms => new Promise(r => setTimeout(r, ms));
const mon = cmds => new Promise((resolve, reject) => {
  const sock = net.connect(6510, '127.0.0.1'); let buf = '';
  sock.on('data', d => { buf += d.toString('latin1'); }); sock.on('error', reject);
  sock.on('connect', async () => { await sleep(100); for (const c of cmds) { sock.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 900 : 100); } sock.write('x\n'); await sleep(80); sock.end(); resolve(buf); });
});
(async () => {
  fs.mkdirSync(out, { recursive: true });
  // (any VICE already running is left alone; only the one started here is closed at the end)
  const pids = () => execSync('powershell -NoProfile -Command "(Get-Process x64sc -ErrorAction SilentlyContinue).Id"').toString().split(/\s+/).filter(Boolean);
  const before = pids();
  await sleep(500);
  spawn('x64sc', ['-default', '+sound', '-remotemonitor', '-remotemonitoraddress', 'ip4://127.0.0.1:6510',
    '-autostartprgmode', '1', '-autostart', require('../../../tools/buildname').files(path.join(root, 'build')).prg], { detached: true, stdio: 'ignore', shell: true }).unref();
  await sleep(7000);
  if (!process.argv.includes('--attract')) { await mon([`> ${addr('DbgINPT4')} 7f`]); await sleep(600); await mon([`> ${addr('DbgINPT4')} ff`]); }   // --attract: don't start a game
  await sleep(2000);
  await mon([`> ${addr('DbgSWCHA')} ${{ left: 'bf', right: '7f', up: 'ef', down: 'df' }[dir]}`]);
  for (let i = 0; i < +nArg; i++) { await mon([`screenshot "${path.join(out, `s${String(i).padStart(2, '0')}.png`).split(path.sep).join('/')}" 2`]); await sleep(+ivArg); }
  await mon([`> ${addr('DbgSWCHA')} ff`]);
  await sleep(500);
  for (const id of pids().filter(i => !before.includes(i))) execSync(`powershell -NoProfile -Command "Stop-Process -Id ${id}"`);
})();
