# Berzerk (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80` | GameNumber | 1 | Selected game, BCD 1-12 (Game Select steps it) |
| `$81` | RoomState | 1 | $FF: changing room (scroll transition, no switches read); 2: playing; 3: bonus life earned (sound on the next room) |
| `$82` | MazeIndex | 1 | Which of the 4 room layouts is showing |
| `$83` | MazeOffset | 1 | Row offset of the current layout in the playfield tables (0, $2A, $54, $7E) |
| `$84` | FrameCount | 1 | Frame counter; bit 0 alternates the humanoid and Evil Otto on player 0 |
| `$85` | AttractColor | 1 | Non-zero when no game is running; EORed into colours for the attract colour cycle |
| `$86` | SelectDelay | 1 | Frames until Game Select steps again |
| `$87` | IdleTimer | 1 | Counts up every 256 frames without joystick input; on wrap the game ends (back to attract) |
| `$88` | GameFlags | 1 | Features of the selected game (table TFEC4): Evil Otto, robot shots, bonus lives? |
| `$89-$8A` | P0Ptr | 2 | Player 0 graphics pointer (humanoid page $FD, Evil Otto page $FE), offset for the Y position |
| `$8B` | HumanY | 1 | Humanoid Y (2600 lines); $7F when not on screen |
| `$8C` | P0Top | 1 | First kernel row of player 0 (Y / 2) |
| `$8D` | P0Bottom | 1 | Row after the last of player 0 (top + 13) |
| `$8E` | HumanDir | 1 | Last joystick direction: bit 0 up, 1 down, 2 left, 3 right (also sets REFP0 when facing left) |
| `$8F-$90` | M0Ptr | 2 | Humanoid shot: pointer into the missile-enable table ($FBxx) offset for its Y |
| `$91` | HumanState | 1 | Walking animation frame 0-2; 3 and up while being killed |
| `$92` | HumanAnimTimer | 1 | Adds $70 a frame; each carry steps the walking animation |
| `$93` | HumanX | 1 | Humanoid X (2600 pixels) |
| `$94` | ShotActive | 1 | Non-zero while the humanoid's shot is flying |
| `$95` | ShotDir | 1 | Direction of the humanoid's shot (joystick bits) |
| `$96` | ShotX | 1 | Humanoid shot X |
| `$97` | ShotY | 1 | Humanoid shot Y |
| `$98-$99` | M1Ptr | 2 | Robot shot: pointer into the missile-enable table ($FBxx) offset for its Y |
| `$9A` | RobotShotDir | 1 | Direction of the robot shot; $0F = none |
| `$9B` | RobotShotTimer | 1 | Robot shot speed accumulator? |
| `$9C` | RobotShotDelay | 1 | Delay before robots may shoot again? |
| `$9D` | RobotShotX | 1 | Robot shot X |
| `$9E` | RobotShotY | 1 | Robot shot Y |
| `$9F-$A6` | RobotHM | 8 | Per robot slot: fine horizontal motion (HMP1) for the kernel. +0 also a temp: robots move this frame. +7 doubles as the transition line counter |
| `$A7-$AE` | RobotDelay | 8 | Per robot slot: coarse position delay for the kernel. +7 = $AE is Evil Otto X |
| `$AF-$B6` | RobotGfx | 8 | Per robot slot: index into the robot graphics (TFF33), stepped each line by the kernel |
| `$B7` | RobotSpeed | 1 | Robot movement accumulator: + RobotStep, carry = robots move this frame |
| `$B8-$C0` | RobotY | 9 | Per robot slot: Y (rows, top to bottom); $7F ends the list. +8 ($C0) is always $7F |
| `$C1-$C8` | RobotX | 8 | Per robot slot: X. +7 = $C8 is Evil Otto's bounce target |
| `$C9-$D0` | RobotHit | 8 | Collision latches the kernel saved at each robot band (cumulative): +1+n is robot n. Bit 7 robot hit (wall, shot, humanoid), bit 0 hit by a robot shot. +7 = $D0 doubles as the transition end line |
| `$D1` | OttoTargetY | 1 | Evil Otto: Y he is heading for? |
| `$D2-$D9` | RobotState | 8 | Per robot slot: animation / movement state (TFF1C steps it); $17 and up: exploding. +7 = $D9 is Evil Otto Y |
| `$DA` | Lives | 1 | Lives left; negative when no game is running (attract mode) |
| `$DB` | RobotsKilled | 1 | Robots shot in this room (room bonus when all are gone) |
| `$DC` | RoomCount | 1 | Rooms entered; picks robot colour and speed |
| `$DD-$DF` | Score | 3 | Score, BCD, high byte first |
| `$E0` | RobotStep | 1 | Robot speed: added to RobotSpeed each frame (faster with each kill and room) |
| `$E1` | LeftDoor | 1 | $20 closes the left exit (ORed into PF0) after entering from the left |
| `$E2` | EntrySide | 1 | Side the humanoid entered from (0-3); closes that exit and picks the start position |
| `$E3-$E4` | Random | 2 | Random number generator state |
| `$E5` | OttoTimer | 1 | Shifts in 1s each frame; $FF = Evil Otto may appear? |
| `$E6` | Temp | 1 | Scratch: robot graphics byte in the kernel, kill flag in the robot loop, digit index |
| `$E7` | Temp2 | 1 | Scratch (random range low / old score) |
| `$E8` | Temp3 | 1 | Scratch (random range high / digit row) |
| `$E9` | Temp4 | 1 | Scratch |
| `$EA-$F5` | DigitPtr | 12 | Six pointers to the bottom line's graphics (score digits, lives, or the copyright message) |
| `$F6` | OttoState | 1 | Evil Otto: 0 not yet, 1-2 waiting, 3 bouncing after the humanoid? |
| `$F7` | Sound0 | 1 | Channel 0 effect timer (shots, death, bonus) |
| `$F8` | Sound1 | 1 | Channel 1 effect timer (robot shot, robot explosion) |
| `$F9` | OttoStep | 1 | Evil Otto bounce step? |
| `$FC` | Band | 1 | Kernel: robot slot being drawn |
| `$FD` | P0Gfx | 1 | Kernel: next player 0 graphics byte (outside the kernel: humanoid animation offset) |
| `$FE` | P1Delay | 1 | Kernel: coarse delay for positioning the next robot |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$F000` | Reset | Power on: jump to the start-up code |
| `$F011` | BandStart | Kernel: save the collisions so far for this robot band, then position the next robot |
| `$F08F` | KernelLine | Kernel: main two-line loop (humanoid, shots, maze, robots) |
| `$F110` | KernelEnd | Kernel: bottom wall and the last band's collisions |
| `$F15C` | BottomLine | Draw the score / lives / copyright line (six digits, 48-pixel trick) |
| `$F1DD` | Overscan | After the picture: console switches, then the game logic |
| `$F1F5` | StartGame | Fire or Game Reset: clear RAM from $85 up and start |
| `$F2F1` | HumanLogic | Humanoid: deaths (Otto, robots, walls), joystick, walking, firing |
| `$F3A4` | MoveShot | Move the humanoid's shot |
| `$F42C` | PositionObjects | Position player 0 (humanoid or Otto, alternate frames) and the shots |
| `$F4FD` | WaitVSync | Wait for the timer, then vertical sync |
| `$F51B` | FrameTop | Top of the frame: digits for the bottom line, then the robots |
| `$F5B4` | RobotLoop | Move and animate each robot; kill the first one the kernel saw hit |
| `$F6A3` | RobotShot | Robots fire at the humanoid |
| `$F7CD` | PrepareKernel | Robot graphics and positions for the kernel, colours, top wall, wait for the timer |
| `$F85F` | NewRoom | Leaving the room: start the scroll transition |
| `$F8B2` | Transition | Scroll transition: step it; at the end set up the next room |
| `$F907` | TransitionKernel | Picture during the scroll transition (maze only) |
| `$F9AC` | PowerOn | Clear RAM and set up the TIA, then start the attract mode |
| `$FA04` | SetP0Y | Player 0 vertical position: rows and graphics pointer from Y (A) |
| `$FA19` | AddScore | Add A (BCD) to the score; extra life at the set score |
| `$FA50` | RandomRange | Next random number, scaled into Temp2..Temp3 |
| `$FA73` | PlaceRobots | New room: put robots at random positions |
| `$FA9C` | CheckRobotHit | Robot X: kill it if the kernel saw it collide (first one only) |
| `$FAB7` | RemoveRobot | Remove robot X from the list (shift the later ones down); faster robots, explosion sound |
| `$FADD` | HumanSector | Which part of the room the humanoid is in (Evil Otto entry)? |
| `$FED7` | CalcHPos | Horizontal position A -> fine motion (A) and coarse delay (Y) |
| `$FEF3` | SetHPos | Position object X using CalcHPos's result |
