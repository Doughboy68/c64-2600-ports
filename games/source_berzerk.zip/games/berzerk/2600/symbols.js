// Names for Berzerk's RAM and routines, worked out by reading the code and
// watching RAM in tools/vcs.js (games/berzerk/tools/watch.js). Used by tools/disasm.js
// to label the source and to write RAM-MAP.md. "?" marks something not yet confirmed.
//
// Conventions found in the code:
//   - Y coordinates count 2600 lines from the top of the play area; the kernel
//     works in line pairs, so many Y values are halved (rows).
//   - $7F in a Y coordinate means "nothing there"; the robot list ends with $7F.
//   - Robots are kept sorted top to bottom in slots 0-7; a dead robot is removed by
//     shifting the later slots down (RemoveRobot).
//   - Robot slot 7's X/state bytes double as Evil Otto's ($AE, $C8, $D9), so at most
//     7 robots and Otto are on screen together.

const game = { title: 'Berzerk', from: 'Atari 2600, 1982', md5: '136f75c4dd02c29283752b7e5799f978', asm: 'berzerk.asm' };

const ram = [
  [0x80, 'GameNumber', 1, 'Selected game, BCD 1-12 (Game Select steps it)'],
  [0x81, 'RoomState', 1, '$FF: changing room (scroll transition, no switches read); 2: playing; 3: bonus life earned (sound on the next room)'],
  [0x82, 'MazeIndex', 1, 'Which of the 4 room layouts is showing'],
  [0x83, 'MazeOffset', 1, 'Row offset of the current layout in the playfield tables (0, $2A, $54, $7E)'],
  [0x84, 'FrameCount', 1, 'Frame counter; bit 0 alternates the humanoid and Evil Otto on player 0'],
  [0x85, 'AttractColor', 1, 'Non-zero when no game is running; EORed into colours for the attract colour cycle'],
  [0x86, 'SelectDelay', 1, 'Frames until Game Select steps again'],
  [0x87, 'IdleTimer', 1, 'Counts up every 256 frames without joystick input; on wrap the game ends (back to attract)'],
  [0x88, 'GameFlags', 1, 'Features of the selected game (table TFEC4): Evil Otto, robot shots, bonus lives?'],
  [0x89, 'P0Ptr', 2, 'Player 0 graphics pointer (humanoid page $FD, Evil Otto page $FE), offset for the Y position'],
  [0x8B, 'HumanY', 1, 'Humanoid Y (2600 lines); $7F when not on screen'],
  [0x8C, 'P0Top', 1, 'First kernel row of player 0 (Y / 2)'],
  [0x8D, 'P0Bottom', 1, 'Row after the last of player 0 (top + 13)'],
  [0x8E, 'HumanDir', 1, 'Last joystick direction: bit 0 up, 1 down, 2 left, 3 right (also sets REFP0 when facing left)'],
  [0x8F, 'M0Ptr', 2, 'Humanoid shot: pointer into the missile-enable table ($FBxx) offset for its Y'],
  [0x91, 'HumanState', 1, 'Walking animation frame 0-2; 3 and up while being killed'],
  [0x92, 'HumanAnimTimer', 1, 'Adds $70 a frame; each carry steps the walking animation'],
  [0x93, 'HumanX', 1, 'Humanoid X (2600 pixels)'],
  [0x94, 'ShotActive', 1, 'Non-zero while the humanoid\'s shot is flying'],
  [0x95, 'ShotDir', 1, 'Direction of the humanoid\'s shot (joystick bits)'],
  [0x96, 'ShotX', 1, 'Humanoid shot X'],
  [0x97, 'ShotY', 1, 'Humanoid shot Y'],
  [0x98, 'M1Ptr', 2, 'Robot shot: pointer into the missile-enable table ($FBxx) offset for its Y'],
  [0x9A, 'RobotShotDir', 1, 'Direction of the robot shot; $0F = none'],
  [0x9B, 'RobotShotTimer', 1, 'Robot shot speed accumulator?'],
  [0x9C, 'RobotShotDelay', 1, 'Delay before robots may shoot again?'],
  [0x9D, 'RobotShotX', 1, 'Robot shot X'],
  [0x9E, 'RobotShotY', 1, 'Robot shot Y'],
  [0x9F, 'RobotHM', 8, 'Per robot slot: fine horizontal motion (HMP1) for the kernel. +0 also a temp: robots move this frame. +7 doubles as the transition line counter'],
  [0xA7, 'RobotDelay', 8, 'Per robot slot: coarse position delay for the kernel. +7 = $AE is Evil Otto X'],
  [0xAF, 'RobotGfx', 8, 'Per robot slot: index into the robot graphics (TFF33), stepped each line by the kernel'],
  [0xB7, 'RobotSpeed', 1, 'Robot movement accumulator: + RobotStep, carry = robots move this frame'],
  [0xB8, 'RobotY', 9, 'Per robot slot: Y (rows, top to bottom); $7F ends the list. +8 ($C0) is always $7F'],
  [0xC1, 'RobotX', 8, 'Per robot slot: X. +7 = $C8 is Evil Otto\'s bounce target'],
  [0xC9, 'RobotHit', 8, 'Collision latches the kernel saved at each robot band (cumulative): +1+n is robot n. Bit 7 robot hit (wall, shot, humanoid), bit 0 hit by a robot shot. +7 = $D0 doubles as the transition end line'],
  [0xD1, 'OttoTargetY', 1, 'Evil Otto: Y he is heading for?'],
  [0xD2, 'RobotState', 8, 'Per robot slot: animation / movement state (TFF1C steps it); $17 and up: exploding. +7 = $D9 is Evil Otto Y'],
  [0xDA, 'Lives', 1, 'Lives left; negative when no game is running (attract mode)'],
  [0xDB, 'RobotsKilled', 1, 'Robots shot in this room (room bonus when all are gone)'],
  [0xDC, 'RoomCount', 1, 'Rooms entered; picks robot colour and speed'],
  [0xDD, 'Score', 3, 'Score, BCD, high byte first'],
  [0xE0, 'RobotStep', 1, 'Robot speed: added to RobotSpeed each frame (faster with each kill and room)'],
  [0xE1, 'LeftDoor', 1, '$20 closes the left exit (ORed into PF0) after entering from the left'],
  [0xE2, 'EntrySide', 1, 'Side the humanoid entered from (0-3); closes that exit and picks the start position'],
  [0xE3, 'Random', 2, 'Random number generator state'],
  [0xE5, 'OttoTimer', 1, 'Shifts in 1s each frame; $FF = Evil Otto may appear?'],
  [0xE6, 'Temp', 1, 'Scratch: robot graphics byte in the kernel, kill flag in the robot loop, digit index'],
  [0xE7, 'Temp2', 1, 'Scratch (random range low / old score)'],
  [0xE8, 'Temp3', 1, 'Scratch (random range high / digit row)'],
  [0xE9, 'Temp4', 1, 'Scratch'],
  [0xEA, 'DigitPtr', 12, 'Six pointers to the bottom line\'s graphics (score digits, lives, or the copyright message)'],
  [0xF6, 'OttoState', 1, 'Evil Otto: 0 not yet, 1-2 waiting, 3 bouncing after the humanoid?'],
  [0xF7, 'Sound0', 1, 'Channel 0 effect timer (shots, death, bonus)'],
  [0xF8, 'Sound1', 1, 'Channel 1 effect timer (robot shot, robot explosion)'],
  [0xF9, 'OttoStep', 1, 'Evil Otto bounce step?'],
  [0xFC, 'Band', 1, 'Kernel: robot slot being drawn'],
  [0xFD, 'P0Gfx', 1, 'Kernel: next player 0 graphics byte (outside the kernel: humanoid animation offset)'],
  [0xFE, 'P1Delay', 1, 'Kernel: coarse delay for positioning the next robot'],
];

const labels = {
  0xF000: ['Reset', 'Power on: jump to the start-up code'],
  0xF011: ['BandStart', 'Kernel: save the collisions so far for this robot band, then position the next robot'],
  0xF08F: ['KernelLine', 'Kernel: main two-line loop (humanoid, shots, maze, robots)'],
  0xF110: ['KernelEnd', 'Kernel: bottom wall and the last band\'s collisions'],
  0xF15C: ['BottomLine', 'Draw the score / lives / copyright line (six digits, 48-pixel trick)'],
  0xF1DD: ['Overscan', 'After the picture: console switches, then the game logic'],
  0xF1F5: ['StartGame', 'Fire or Game Reset: clear RAM from $85 up and start'],
  0xF2F1: ['HumanLogic', 'Humanoid: deaths (Otto, robots, walls), joystick, walking, firing'],
  0xF3A4: ['MoveShot', 'Move the humanoid\'s shot'],
  0xF42C: ['PositionObjects', 'Position player 0 (humanoid or Otto, alternate frames) and the shots'],
  0xF4FD: ['WaitVSync', 'Wait for the timer, then vertical sync'],
  0xF51B: ['FrameTop', 'Top of the frame: digits for the bottom line, then the robots'],
  0xF5B4: ['RobotLoop', 'Move and animate each robot; kill the first one the kernel saw hit'],
  0xF6A3: ['RobotShot', 'Robots fire at the humanoid'],
  0xF7CD: ['PrepareKernel', 'Robot graphics and positions for the kernel, colours, top wall, wait for the timer'],
  0xF85F: ['NewRoom', 'Leaving the room: start the scroll transition'],
  0xF8B2: ['Transition', 'Scroll transition: step it; at the end set up the next room'],
  0xF907: ['TransitionKernel', 'Picture during the scroll transition (maze only)'],
  0xF9AC: ['PowerOn', 'Clear RAM and set up the TIA, then start the attract mode'],
  0xFA04: ['SetP0Y', 'Player 0 vertical position: rows and graphics pointer from Y (A)'],
  0xFA19: ['AddScore', 'Add A (BCD) to the score; extra life at the set score'],
  0xFA50: ['RandomRange', 'Next random number, scaled into Temp2..Temp3'],
  0xFA73: ['PlaceRobots', 'New room: put robots at random positions'],
  0xFA9C: ['CheckRobotHit', 'Robot X: kill it if the kernel saw it collide (first one only)'],
  0xFAB7: ['RemoveRobot', 'Remove robot X from the list (shift the later ones down); faster robots, explosion sound'],
  0xFADD: ['HumanSector', 'Which part of the room the humanoid is in (Evil Otto entry)?'],
  0xFED7: ['CalcHPos', 'Horizontal position A -> fine motion (A) and coarse delay (Y)'],
  0xFEF3: ['SetHPos', 'Position object X using CalcHPos\'s result'],
};

// Code the tracer can't reach on its own (jump tables, pushed return addresses)
const code = [
];

module.exports = { game, ram, labels, code };
