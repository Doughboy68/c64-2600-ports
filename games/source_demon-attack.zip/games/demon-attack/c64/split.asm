; ======================================================== split demons
; Split demons' halves as sprite pairs: which band or demon each sprite pair shows (the
; plan), the halves' sprites, the pairs' moves down. (In the start-up area, below the 2600
; program: there is no room left above it.)
; ------------------------------------------------------- the demon pairs' plan
; Each band's kind (ItK: 0 blank, 1 a sprite pair, 2 split: halves too far apart for one
; pair, 3 characters: four times as wide, or wrapping round), when any band's players are 17
; or more pixels apart. Without split bands the pairs go as always (plDyn 0; DrawBand's own
; tests): bands 0 and 2 on sprites 4-5, band 1 and the cannon band on 6-7.
; With them, a plan (plDyn 1): the bands and the cannon band's demon top to bottom, each on a
; pair whose last start is 22 lines up (the VIC's rule; 27 for the explosion, whose blocks
; have rows below 7: its pair moves only after the 21 rows before), split bands taking both
; pairs (a half each) when that leaves the rest placeable, else drawn as characters.
Classify:
        lda SplitFlags          ; (usually no band's demon split in two: nothing to plan;
        ora SplitFlags+1        ; with none, players 17 or more pixels apart never happen)
        ora SplitFlags+2
        beq _none
        .for k = 0, k < 3, k += 1   ; (and then usually still inside 17 pixels)
        lda bX1+k
        sec
        sbc bX0+k
        adc #15                 ; (carry set: + 16: under 33 if |x1 - x0| < 17)
        cmp #33
        bcs _some
        .next
        lda #0
_none   sta plDyn               ; (no plan: the bands' blocks may get whole demons, bytes 1-2 of
        ldx rbuf                ; their rows drawn: SprHalf blanks those first)
        ldy Mul3,x
        lda #1
        sta HfDirty,y
        sta HfDirty+1,y
        sta HfDirty+2,y
        rts
_some   lda #0
        sta plSplit
        ldx #2
_band   lda bP0,x
        ora bP1,x
        beq _k                  ; (0: blank)
        lda bW,x
        cmp #8
        bne _k3
        lda bX0,x
        cmp #153
        bcs _k3
        lda bX1,x
        cmp #153
        bcs _k3
        sec
        sbc bX0,x
        bcs +
        eor #$ff                ; |x1 - x0|
        adc #1
+       cmp #17
        lda #1
        bcc _k
        inc plSplit
        lda #2
        bne _k
_k3     lda #3
_k      sta ItK,x
        dex
        bpl _band
        lda plSplit
        bne Plan
        jmp _none               ; (A = 0)
; The plan: ItN (pairs per item: bands 0-2, the cannon band's demon 3; 3: a split band's
; left half on one pair, the right half characters), ItP (the pair of a one-pair item or a
; half, $ff none), MoveRas (raster of pair p's move after item j: 2j + p, 0 none).
Plan:
        ldx #2                  ; the items' first lines
-       lda #210
        sec
        sbc bC,x
        sta ItL,x
        dex
        bpl -
        lda #0
        sta plExp
        ldx cMode               ; the cannon band: a small demon, rows from 213 - C8; the
        dex                     ; explosion from max(188, 221 - C7) if its players are
        bne +                   ; inside 17 pixels (else not drawn); bullets: nothing
        lda #213
        sec
        sbc SmallY
        jmp _c
+       dex
        bne _no
        lda cX1
        sec
        sbc cX0
        bcs +
        eor #$ff
        adc #1
+       cmp #17
        bcs _no
        inc plExp
        lda #221
        sec
        sbc bC+2
        cmp #188
        bcs _c
        lda #188
_c      sta ItL+3
        lda #1
        .byte $2c               ; (bit: skips the next)
_no     lda #0
        sta ItK+3
        lda #7                  ; split bands may take both pairs, or one (a half), where they fit
        sta plConv
        sta plHalf
_try    jsr PlanTry
        bcc _ok
        lda plTaken             ; a band below didn't fit: the last split band that took pairs
        beq _fixed              ; takes fewer: both -> a half -> none (none: as always)
        ldx #2
-       lda BitLo,x
        and plTaken
        bne +
        dex
        bpl -
+       and plTakenF
        beq +
        eor plConv              ; (it had both: now a half at most)
        sta plConv
        jmp _try
+       lda BitLo,x             ; (a half: now characters)
        eor #$ff
        and plHalf
        sta plHalf
        jmp _try
_ok     lda #1
        sta plDyn
        ldx rbuf                ; (one-pair bands may get whole demons: as without a plan)
        ldy Mul3,x
        ldx #0
-       lda ItN,x
        cmp #1
        bne +
        sta HfDirty,y
+       iny
        inx
        cpx #3
        bne -
        ldx rbuf                ; the pairs blank at the frame top unless used there;
        lda RecBase,x           ; records from 2 on (0-1: without a plan)
        clc
        adc #2
        sta recI
        lda Mul8,x
        tax
        lda #BLK_BLANK
        sta StPtr+4,x
        sta StPtr+5,x
        sta StPtr+6,x
        sta StPtr+7,x
        lda #0
        sta StY+4,x
        sta StY+5,x
        sta StY+6,x
        sta StY+7,x
        rts
_fixed  lda #0
        jmp Classify._none
; one plan, split bands as sprites where they fit if plConv allows (bits 0-2: plTaken, those
; that did) -> carry clear: it fits
PlanTry:
        lda #0
        sta plTaken
        sta plTakenF
        sta plLast              ; (each pair's last start: 0 none yet,
        sta plLast+1
        ldx #5                  ; (no moves after the cannon band's)
-       sta MoveRas,x
        dex
        bpl -
        lda #$ff
        sta plItem              ; ... and the item there)
        sta plItem+1
        lda #22                 ; the gap to the pair's last start, the move after it
        sta plGap
        lda #8+LINE2RAS
        sta plMove
        ldx #0
_item   lda #$ff
        sta ItP,x
        lda #0
        sta ItN,x
        cpx #3
        beq _cannon
        lda ItK,x
        cmp #2
        beq +
        cmp #1
        bne _nx
        jmp _one
_nx     jmp _next
+       jsr _fits               ; split: both pairs if they fit (and plConv allows); one (a half,
        beq _nx                 ; the other half characters) if plHalf allows; else characters
        cmp #3
        bne _h1
        lda plConv
        and BitLo,x
        beq _h2
        lda plTaken
        ora BitLo,x
        sta plTaken
        lda plTakenF
        ora BitLo,x
        sta plTakenF
        lda #2
        sta ItN,x
        ldy #0
        jsr _use
        ldy #1
        jsr _use
        jmp _next
_h1     and #1                  ; (2: pair 0 only, 1: pair 1 only)
        tay
        lda plHalf
        and BitLo,x
        beq _nx
        bne _hp
_h2     lda plHalf              ; (both fit, both not allowed: the better one, as for one-pair
        and BitLo,x             ; bands)
        beq _nx
        jsr _choose
_hp     lda plTaken
        ora BitLo,x
        sta plTaken
        tya
        sta ItP,x
        lda #3
        sta ItN,x
        jsr _use
        jmp _next
_cannon lda ItK+3
        beq _next
        lda plExp
        beq _one
        lda #27
        sta plGap
        lda #21+LINE2RAS
        sta plMove
_one    jsr _fits
        beq _fail
        cmp #3
        beq _both
        and #1                  ; (2: pair 0 only, 1: pair 1 only)
        tay
        jmp _p
_both   jsr _choose
_p      tya
        sta ItP,x
        lda #1
        sta ItN,x
        jsr _use
_next   inx
        cpx #4
        beq +
        jmp _item
+       clc
        rts
_fail   sec
        rts
; both pairs fit: -> Y the unused one if just one is, else the one whose last start is later
; (the other stays free longer)
_choose ldy #0
        lda plItem
        eor plItem+1
        bpl _later
        lda plItem
        bmi +
        iny
+       rts
_later  lda plLast
        cmp plLast+1
        bcs +
        iny
+       rts
; -> A: bit 1 pair 0 fits, bit 0 pair 1 (the item's first line plGap or more after its last)
_fits   lda ItL,x
        sec
        sbc plGap
        cmp plLast
        rol tmp2
        cmp plLast+1
        lda tmp2
        rol
        and #3
        rts
; item X on pair Y: the pair's move after the item before on it
_use    lda plItem,y
        bmi +
        asl
        sty tmp
        ora tmp
        sta tmp
        lda plLast,y
        clc
        adc plMove
        stx tmp2
        ldx tmp
        sta MoveRas,x
        ldx tmp2
+       lda ItL,x
        sta plLast,y
        txa
        sta plItem,y
        rts

; ---------------------------------------------------------------- halves
; A split band's half as a sprite pair of its own (spPair): player 0 (hfP = 0) at bX0 in the
; band's blocks, or player 1 (hfP = 1) at bX1, reflected, the line above's row left of pixel
; 19, in the band's second set of blocks. Its pixels in byte 0 of rows 0-7 (bytes 1-2 blank),
; split into "this line's colour" and "the previous line's" (left of 43 / 52) as SprDemon does.
; Usually all of a half is one or the other: then its rows go straight into one sprite, line
; by line, and the other's are blank.
SprHalf:
        ldx band
        lda hfP
        bne _p1
        lda bX0,x               ; player 0: the previous line's colour left of 43
        sta swS
        lda bP0,x
        sta hfG
        lda #0
        sta hfUp
        lda #43
        jsr _left
        jmp _pv
_p1     lda bX1,x               ; player 1: left of 52; the line above's row left of 19
        sta swS
        lda bP1,x
        sta hfG
        lda #19
        jsr _left
        sta hfUp
        lda #52
        jsr _left
_pv     sta hfPv
        ldx rbuf                ; the blocks
        lda Mul3,x
        clc
        adc band
        tay
        lda hfP
        beq +
        jmp _b1
+       lda SprBlkNum,x         ; player 0: the band's own (B_DEMONS + 2 * band)
        adc #B_DEMONS
        adc band
        adc band
        sta swBlk
        tax
        adc #1
        sta swBlk2
        lda BlkLo,x
        sta ptrA
        lda BlkHi,x
        sta ptrA+1
        lda BlkLo+1,x
        sta ptrB
        lda BlkHi+1,x
        sta ptrB+1
        lda HfDirty,y           ; bytes 1-2 of the rows: blank them if a whole demon was
        bne +                   ; drawn there last
        jmp _go
+       lda #0
        sta HfDirty,y
        ldy #23
-       sta (ptrA),y
        sta (ptrB),y
        dey
        sta (ptrA),y
        sta (ptrB),y
        dey
        dey
        bpl -
        jmp _go
_b1     lda Half2A,y            ; player 1: the band's second set (only ever drawn here)
        sta swBlk
        lda Half2B,y
        sta swBlk2
        lda Half2ALo,y
        sta ptrA
        lda Half2AHi,y
        sta ptrA+1
        lda Half2BLo,y
        sta ptrB
        lda Half2BHi,y
        sta ptrB+1
_go     lda bandL               ; line 0's "this line's colour" in the first sprite if the first
        lsr                     ; line is even; all the previous line's (the whole half left
        lda hfPv                ; of its split): the other way round
        adc #0                  ; (carry: odd; $ff + 1: 0 with carry)
        and #1
        beq +
        ldx ptrA
        ldy ptrB
        stx ptrB
        sty ptrA
        ldx ptrA+1
        ldy ptrB+1
        stx ptrB+1
        sty ptrA+1
+       lda hfPv                ; all one colour, no row above to merge: straight
        beq +
        cmp #$ff
        bne _tomix
+       lda hfUp
        beq +
_tomix  jmp _mixed
+       lda #0                  ; the other sprite's rows blank
        .for j = 0, j < 8, j += 1
        ldy #3*j
        .if j & 1
        sta (ptrA),y
        .else
        sta (ptrB),y
        .endif
        .next
        ldx hfG
        lda hfP
        bne _r1
        .for j = 0, j < 8, j += 1
        lda DemonGfx+7-j,x
        ldy #3*j
        .if j & 1
        sta (ptrB),y
        .else
        sta (ptrA),y
        .endif
        .next
        jmp SprPos
_r1     .for j = 0, j < 8, j += 1
        ldy DemonGfx+7-j,x
        lda Reverse,y
        ldy #3*j
        .if j & 1
        sta (ptrB),y
        .else
        sta (ptrA),y
        .endif
        .next
        jmp SprPos
_mixed  lda hfG                 ; rows line by line (row 7 first), player 1's reflected and
        clc                     ; with the line above's (row 8 - j) left of 19
        adc #7
        tax
        ldy #0
-       lda DemonGfx,x
        sta HfRow,y
        dex
        iny
        cpy #8
        bne -
        lda hfP
        beq _mix
        ldy #7
-       ldx HfRow,y
        lda Reverse,x
        sta HfRow,y
        dey
        bpl -
        lda hfUp
        beq _mix
        lda hfG
        clc
        adc #8
        tax
        ldy #0
-       stx tmp4
        lda DemonGfx,x
        tax
        lda Reverse,x
        eor HfRow,y
        and hfUp
        eor HfRow,y
        sta HfRow,y
        ldx tmp4
        dex
        iny
        cpy #8
        bne -
_mix    lda hfPv                ; (all the previous line's: the sprites were swapped)
        cmp #$ff
        bne +
        lda #0
        sta hfPv
+
        .for j = 0, j < 8, j += 1
        lda HfRow+j
        and hfPv
        sta tmp2                ; previous colour
        eor HfRow+j             ; this line's
        ldy #3*j
        .if j & 1
        sta (ptrB),y
        lda tmp2
        sta (ptrA),y
        .else
        sta (ptrA),y
        lda tmp2
        sta (ptrB),y
        .endif
        .next
        jmp SprPos
; the half's pixels left of pixel A (it starts at swS)
_left   sec
        sbc swS
        bcs +
        lda #0
+       cmp #8
        bcc +
        lda #8
+       tax
        lda LeftMask,x
        rts
; each buffer's (3 * buffer + band) second set of blocks for player 1 (free parts of the
; sprite area and of the character sets: characters 216-255, never handed out)
Half2A:     .byte 61, 155, 157, 187, 189, 159
Half2B:     .byte 62, 156, 158, 188, 190, 191
Half2ALo:   .for b in [61, 155, 157, 187, 189, 159]
            .byte <(VICBANK + 64 * b)
            .next
Half2AHi:   .for b in [61, 155, 157, 187, 189, 159]
            .byte >(VICBANK + 64 * b)
            .next
Half2BLo:   .for b in [62, 156, 158, 188, 190, 191]
            .byte <(VICBANK + 64 * b)
            .next
Half2BHi:   .for b in [62, 156, 158, 188, 190, 191]
            .byte >(VICBANK + 64 * b)
            .next
        .cerror SPRDATA + 64 * (1 + 2 * NBLK) > VICBANK + 64 * 61, "Half2: sprite blocks 61-62 taken"
        .cerror VICBANK + 64 * 155 < CHARS0 + 8 * (FBCH + 36), "Half2: characters taken"

; ---------------------------------------------------------------- moves
; The plan's pair moves after item X (band 0-2): a record for each pair's next use, moved
; there at MoveRas (after this band's lines; the schedule stays in raster order)
SchedMoves:
        txa
        asl
        sta plJ
        tax
        lda MoveRas,x
        beq +
        ldy #0
        jsr PairMove
        ldx plJ
+       lda MoveRas+1,x
        beq +
        ldy #1
        jmp PairMove
+       rts
; pair Y's next use: the next record (PairRec), moved at raster A
PairMove:
        sta tmp
        ldx recI
        inc recI
        txa
        sta PairRec,y
        lda PairSpr,y           ; (sprites 4-5 / 6-7)
        sta PairN,x
        lda PairBits,y
        sta PairBitsR,x
        txa
        tay
        lda tmp
        ldx #S_PAIR
        jmp SchedAdd


; ---------------------------------------------------------------- tables made at start-up
; RasTab, DlyTab, DlyTabD (main.asm) and Ident, in the C64's old screen ($0400-$07FF: the VIC
; looks at bank 3), so they take no room in the program
InitTables:
        ldx #0
-       txa
        sta Ident,x
        clc
        adc #LINE2RAS-1
        sta RasTab,x
        txa
        and #7
        cmp #1
        beq +
        lda #4
        sta DlyTab,x
        lda #3
        sta DlyTabD,x
        bne ++
+       sta DlyTab,x
        sta DlyTabD,x
+       inx
        bne -
        rts

; Ready-made sprites for a whole demon in one colour (one piece: player 0 and player 1
; reflected, side by side): for each shape two blocks, its rows on the even lines and its
; rows on the odd lines (the other lines blank). Which sprite of the pair gets which then
; depends only on the line parity. In the RAM under the I/O area (the VIC sees RAM there).
InitImages:
        lda #$34                ; (all RAM)
        sta $01
        lda #<$d000
        sta ptrA
        lda #>$d000
        sta ptrA+1
        ldy #0                  ; clear $D000-$DFFF
        tya
        ldx #16
-       sta (ptrA),y
        iny
        bne -
        inc ptrA+1
        dex
        bne -
        lda #>$d000
        sta ptrA+1
        lda #0
        sta tmp3                ; shape
_shape  lda tmp3
        asl
        asl
        asl
        ora #7
        sta tmp2                ; row 7's graphics
        lda #0
        sta tmp4                ; sprite row 0-7
_row    ldy tmp2
        lda DemonGfx,y
        sta v0                  ; player 0
        tax
        lda Reverse,x
        sta v1                  ; player 1, reflected
        ldx tmp4
        txa                     ; (odd rows: the second block)
        and #1
        beq +
        lda #64
+       clc
        adc Mul3,x
        tay
        lda v0
        sta (ptrA),y
        iny
        lda v1
        sta (ptrA),y
        dec tmp2
        inc tmp4
        lda tmp4
        cmp #8
        bne _row
        lda ptrA                ; next shape: 128 bytes on
        clc
        adc #128
        sta ptrA
        bcc +
        inc ptrA+1
+       inc tmp3
        lda tmp3
        cmp #NIMG
        bne _shape
        lda #$35
        sta $01
        rts
