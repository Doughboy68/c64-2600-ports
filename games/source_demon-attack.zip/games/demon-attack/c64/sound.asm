; =================================================================== sound
; The game's TIA sound registers, translated to SID voices 1 and 2 once a frame.
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        beq _off
        ldy v1
        lda SidWave,y
        beq _off2
        sta tmp                 ; waveform
        lda SidRow,y            ; frequency index = AUDC's row (x 32) + AUDF
        ora v2
        clc
        adc FreqTab
        sta ptrA
        lda #0
        adc FreqTab+1
        sta ptrA+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d400,y
        inc ptrA+1              ; (the high bytes: 256 on)
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d401,y
        lda #0
        sta $d402,y
        sta $d405,y
        lda #8
        sta $d403,y
        lda v0                  ; volume becomes the sustain level
        asl
        asl
        asl
        asl
        sta $d406,y
        lda v0                  ; retrigger only when volume or waveform changes
        cmp SndLast,x
        bne +
        lda v1
        cmp SndLast+2,x
        beq _save
+       lda tmp
        sta $d404,y
        ora #1
        sta $d404,y
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts
SidVoice:   .byte 0, 7
