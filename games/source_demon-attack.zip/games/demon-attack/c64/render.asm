; =============================================================== render
; Draws the state the last tick left (the kernel's input, plus what Collide worked out)
; into the frame buffer the display isn't using, and builds its raster schedule.
;
; Line by line as on the 2600: 2600 line L is screen pixel row L - 40 (raster L + 11), 2600
; pixel x is C64 pixels 2x, 2x+1 (a multicolour pixel, or an expanded sprite pixel).
;
; Colours that change every line: where the 2600 writes a colour part-way along a line,
; the pixels left of the write still show the previous line's colour. So each demon is drawn
; with two colour registers (two sprites, or the multicolour pixel codes 01 and 10): on even
; lines the first holds that line's colour and the second the previous line's, on odd lines
; the other way round. A single write per line (the interrupt's colour runs) keeps both
; right: the register written is the one that held the previous line's colour.
;
; Demons are sprite pairs (sprites 4-5: bands 0 and 2; 6-7: band 1, then the small demon
; or the cannon's explosion). A split demon (its halves too far apart for one pair) gets a
; pair for each half when the sprites allow (or its left half on the one pair free, the right
; half characters); then the pairs go where a plan per picture says (split.asm). A demon four times as wide (materializing), wrapping round, or split where the
; sprites don't allow is drawn as multicolour characters instead (codes 01 / 10, registers
; $D022 / $D023). The score and bunkers are characters
; too, and the HMOVE marks (code 11: colour RAM black).
;
; Characters 1-26 (the score) and 27-48 (the bunkers) belong to their cells and are only
; redrawn when they change; the rest are handed out afresh each frame (GetCell), copying
; a score or bunker character first if something else is drawn over it. The cells used are
; put back before the buffer is drawn again.
DYN         = 56        ; first character handed out per frame (to FBCH - 1)
FBCH        = 176       ; the wide band's character pairs, one per cell (176-211)
GNDCH       = 53        ; the ground: characters 53-55 (rows 22-24), odd lines "10"
SCORECH     = 1         ; the score: characters 1-26, columns 13-25 of rows 0-1
SCORECOL    = 13
BUNKCH      = 27        ; the bunkers: characters 27-52, columns 3-15 of rows 22-23 (six
                        ; bunkers reach pixel 62)
BUNKCOL     = 3
BUNKCOLS    = 13
NRST        = 120       ; cells borrowed per frame, at most (2 * NRST < 256)
SCORELINE   = 41        ; the score's first line (row 9 of the digits, blank)
BUNKLINE    = 223       ; the bunkers' first line (and the ground's colours)
BULLINE     = 141       ; the bullets' column: 4 segments of 20 lines from here
NRUNS       = 8         ; colour runs per buffer
NPAIRS      = 7         ; demon sprite pair records per buffer (moves down)
IMGBLK      = ($d000 - VICBANK) / 64   ; ready-made demon sprites (RAM under the I/O)
NIMG        = 28        ; ... for shapes 0-27

InitRender:
        ldx #23                 ; the ground's characters, both sets
-       lda GroundChars,x
        sta CHARS0+GNDCH*8,x
        sta CHARS1+GNDCH*8,x
        dex
        bpl -
        ldx #39                 ; ... in rows 22-24 of both screens
-       lda #GNDCH
        sta SCREEN0+22*40,x
        sta SCREEN1+22*40,x
        lda #GNDCH+1
        sta SCREEN0+23*40,x
        sta SCREEN1+23*40,x
        lda #GNDCH+2
        sta SCREEN0+24*40,x
        sta SCREEN1+24*40,x
        dex
        bpl -
        lda #SCORECH            ; the score's and bunkers' characters, in both screens
        sta tmp
        ldx #0
-       lda tmp
        sta SCREEN0+SCORECOL,x
        sta SCREEN1+SCORECOL,x
        clc
        adc #13
        sta SCREEN0+40+SCORECOL,x
        sta SCREEN1+40+SCORECOL,x
        inc tmp
        inx
        cpx #13
        bne -
        lda #BUNKCH
        sta tmp
        ldx #0
-       lda tmp
        sta SCREEN0+22*40+BUNKCOL,x
        sta SCREEN1+22*40+BUNKCOL,x
        clc
        adc #BUNKCOLS
        sta SCREEN0+23*40+BUNKCOL,x
        sta SCREEN1+23*40+BUNKCOL,x
        inc tmp
        inx
        cpx #BUNKCOLS
        bne -
        ldx #23                 ; redraw the score and bunkers the first time
        lda #$ff
-       sta ScoreKey,x
        dex
        bpl -
        sta BunkKey
        sta BunkKey+1
        ldx #11                 ; the cannon's sprite (both buffers): rows 0-11, top first
        ldy #0                  ; (its graphics run bottom row first)
-       lda CannonGfx,x
        sta VICBANK+64*(BLK_SET+B_CANNON),y
        sta VICBANK+64*(BLK_SET+NBLK+B_CANNON),y
        iny
        iny
        iny
        dex
        bpl -
        jsr InitImages
        jmp FbCacheInit         ; (the materializing demons' ready-made lines)

Mul3:       .for i = 0, i < 21, i += 1
            .byte 3 * i
            .next

; ================================================================ frame
Render:
        lda curBuf
        eor #1
        sta rbuf
        tax
        lda ChrHiTab,x
        sta chrHi
        lda RstBase,x
        clc
        adc #NRST
        sta RstLimit
        jsr Restore             ; the cells last drawn into this buffer
        jsr RestoreFat
        lda #DYN
        sta nextChar
        jsr SchedStart
        jsr SchedGround
        jsr DrawScore
        jsr DrawBunkers
        lda #$ff                ; (the pairs' first uses: staged for the frame top)
        sta PairRec
        sta PairRec+1
        jsr Classify            ; (which pair each band uses: plDyn, the plan)
        lda plDyn
        bne _plan
        ldx #0                  ; as always: band 0 on sprites 4-5, moved down after it to
        stx band                ; band 2; band 1 on 6-7, moved after it to the cannon band
        jsr DrawBandF
        jsr SchedPair0
        ldx #1
        stx band
        jsr DrawBandF
        jsr SchedPair1
        ldx #2
        stx band
        jsr DrawBandF
        jmp _cannon
_plan   ldx #0                  ; the plan: each band's pairs, and their moves after it
        stx band
        jsr DrawBand
        ldx #0
        jsr SchedMoves
        ldx #1
        stx band
        jsr DrawBand
        ldx #1
        jsr SchedMoves
        ldx #2
        stx band
        jsr DrawBand
        ldx #2
        jsr SchedMoves
_cannon jsr DrawCannonBand
        jsr DrawNotches
        jsr DrawLaser
        jsr DrawCannon
        jsr DrawBullets
        jsr SchedGroundAdd
        lda #ENDRASTER          ; frame end
        ldx #S_END
        jsr SchedAdd
        ldx rbuf                ; (cells borrowed, for Restore)
        lda rstN
        sta RstEnd,x
        lda #1
        sta pending
        rts
ChrHiTab:   .byte >CHARS0, >CHARS1

; ---------------------------------------------------------- characters
; Put back the cells this buffer borrowed last time.
Restore:
        ldy rbuf
        lda RstBase,y
        sta rstN
        cmp RstEnd,y
        beq _done
        tax
-       lda RstLo,x
        sta rowPtr
        lda RstHi,x
        sta rowPtr+1
        lda RstVal,x
        ldy #0
        sta (rowPtr),y
        inx
        ldy rbuf
        txa
        cmp RstEnd,y
        bne -
_done   rts
RstBase:    .byte 0, NRST

; Line L (A, a 2600 line): rowPtr = its character row in this buffer's screen, lic = the
; line within the characters. Lines outside the screen (40-239): carry set.
LineRow:
        sec
        sbc #40
        bcc _out
        cmp #200
        bcs _out
        tax
        and #7
        sta lic
        txa
        lsr
        lsr
        lsr
        tax
        lda RowLo,x
        sta rowPtr
        lda RowHi,x
        ldx rbuf
        beq +
        clc
        adc #>(SCREEN1 - SCREEN0)
+       sta rowPtr+1
        clc
        rts
_out    sec
        rts

; A = column (taken mod 40): the character drawn there this frame -> dstPtr = its data.
; A cell not yet drawn into gets a new character: cleared, or a copy of the score or
; bunker character it held. -> carry set if there are none left (draw nothing).
GetCell:
        cmp #40
        bcc +
        sbc #40
+       tay
        lda (rowPtr),y
        cmp #DYN
        bcc +
        cmp #FBCH               ; (a wide band's pair: copied, as the score's are)
        bcs +
        jmp _have
+
        sta tmp2                ; what was there
        lda nextChar
        cmp #FBCH
        bcc +
        jmp _full
+
        ldx rstN                ; (and the list of borrowed cells is full)
        cpx RstLimit
        bcc +
        jmp _full
+
        sta (rowPtr),y
        inc nextChar
        tya                     ; remember the cell, to put it back
        clc
        adc rowPtr
        sta RstLo,x
        lda rowPtr+1
        adc #0
        sta RstHi,x
        lda tmp2
        sta RstVal,x
        inc rstN
        lda (rowPtr),y
        jsr CharAddr
        ldx tmp2
        bne _copy
        lda #0
        ldy #7
        sta (dstPtr),y
        ldy #6
        sta (dstPtr),y
        ldy #5
        sta (dstPtr),y
        ldy #4
        sta (dstPtr),y
        ldy #3
        sta (dstPtr),y
        ldy #2
        sta (dstPtr),y
        ldy #1
        sta (dstPtr),y
        ldy #0
        sta (dstPtr),y
        clc
        rts
_copy   lda CharLo,x            ; a copy of the old character
        sta ptrC
        lda CharHi,x
        ora chrHi
        sta ptrC+1
        ldy #7
        lda (ptrC),y
        sta (dstPtr),y
        ldy #6
        lda (ptrC),y
        sta (dstPtr),y
        ldy #5
        lda (ptrC),y
        sta (dstPtr),y
        ldy #4
        lda (ptrC),y
        sta (dstPtr),y
        ldy #3
        lda (ptrC),y
        sta (dstPtr),y
        ldy #2
        lda (ptrC),y
        sta (dstPtr),y
        ldy #1
        lda (ptrC),y
        sta (dstPtr),y
        ldy #0
        lda (ptrC),y
        sta (dstPtr),y
        clc
        rts
_have   jsr CharAddr
        clc
        rts
_full   inc DbgDrop             ; (testing aid)
        sec
        rts

; dstPtr = character A's data in this buffer's character set
CharAddr:
        tax
        lda CharLo,x
        sta dstPtr
        lda CharHi,x
        ora chrHi
        sta dstPtr+1
        rts

; Draw pixels on the line LineRow set up, from pixel plX: plN bytes (1-4) of pixel-order
; masks, plA the pixels drawn "01", plB the ones drawn "10". With plover set, the cells'
; pixels under them are cleared first (player 0 in front of player 1).
PlotLine:
        ldx #0
        ldy #0
-       stx tmp3
        lda plB,x               ; "10": the "01" pattern shifted left a bit
        tax
        lda MCHi,x
        asl
        sta mc,y
        lda MCLo,x
        asl
        sta mc+1,y
        ldx tmp3
        lda plA,x
        tax
        lda MCHi,x
        ora mc,y
        sta mc,y
        lda MCLo,x
        ora mc+1,y
        sta mc+1,y
        ldx tmp3
        lda plover
        beq +
        lda plA,x               ; (in front: the pixels' "11" masks)
        ora plB,x
        tax
        lda MCHi,x
        sta tmp
        asl
        ora tmp
        sta mo,y
        lda MCLo,x
        sta tmp
        asl
        ora tmp
        sta mo+1,y
        ldx tmp3
+       iny
        iny
        inx
        cpx plN
        bne -
        lda #0
        sta mc,y                ; (the byte the shift spills into)
        sta mo,y
        sty plM                 ; multicolour bytes, before the shift
        lda plX                 ; shift right by plX & 3 pixels
        and #3
        beq +
        jsr ShiftMC
        lda plover
        beq +
        jsr ShiftMO
+       inc plM
        lda plX
        lsr
        lsr
        sta plC
        ldx #0
-       stx plK
        lda mc,x
        beq _next               ; (nothing in this cell)
        lda plC
        jsr GetCell
        bcs _next
        ldx plK
        ldy lic
        lda plover
        beq +
        lda mo,x
        eor #$ff
        and (dstPtr),y
        ora mc,x
        sta (dstPtr),y
        jmp _next
+       lda mc,x
        ora (dstPtr),y
        sta (dstPtr),y
_next   inc plC
        ldx plK
        inx
        cpx plM
        bcc -
        rts

; shift mc[0..plM-1] right by A (1-3) pixels, into mc[0..plM]
ShiftMC:
        jsr ShiftPtrs
        ldx plM
-       dex                     ; from the right: each byte passes its low pixels on
        lda mc,x
        tay
        lda (ptrB),y
        ora mc+1,x
        sta mc+1,x
        lda (ptrA),y
        sta mc,x
        cpx #0
        bne -
        rts
ShiftMO:                        ; (the same for mo: the pointers are set)
        ldx plM
-       dex
        lda mo,x
        tay
        lda (ptrB),y
        ora mo+1,x
        sta mo+1,x
        lda (ptrA),y
        sta mo,x
        cpx #0
        bne -
        rts
ShiftPtrs:
        tax
        lda ShRLo-1,x
        sta ptrA
        lda ShRHi-1,x
        sta ptrA+1
        lda ShLLo-1,x
        sta ptrB
        lda ShLHi-1,x
        sta ptrB+1
        rts
ShRLo:      .byte <ShR1, <ShR2, <ShR3
ShRHi:      .byte >ShR1, >ShR2, >ShR3
ShLLo:      .byte <ShL1, <ShL2, <ShL3
ShLHi:      .byte >ShL1, >ShL2, >ShL3

; The same into a score or bunker character's own cells (no borrowing): plA only, plN
; bytes (up to 6).
PlotStatic:
        ldx #0
        ldy #0
-       stx tmp3
        lda plA,x
        tax
        lda MCHi,x
        sta mc,y
        lda MCLo,x
        sta mc+1,y
        ldx tmp3
        iny
        iny
        inx
        cpx plN
        bne -
        lda #0
        sta mc,y
        sty plM
        lda plX
        and #3
        beq +
        jsr ShiftMC
+       inc plM
        lda plX
        lsr
        lsr
        sta plC
        ldx #0
-       stx plK
        lda mc,x
        beq +
        ldy plC
        lda (rowPtr),y
        jsr CharAddr
        ldx plK
        ldy lic
        lda mc,x
        ora (dstPtr),y
        sta (dstPtr),y
+       inc plC
        ldx plK
        inx
        cpx plM
        bcc -
        rts

; ------------------------------------------------------------------ score
; Six digits from the pointers $DD-$E8 at pixels 55-102 (players 0 and 1, three copies
; each), rows 9-0 on lines 41-50 (row 9 is blank, but not in the Imagic logo's glyphs).
; Drawn as "01" into characters 1-26 when the pointers change.
DrawScore:
        ldx rbuf                ; changed since this buffer last drew it?
        lda Mul12,x
        tax
        lda DigitPtr+0
        cmp ScoreKey+0,x
        bne _chg
        lda DigitPtr+1
        cmp ScoreKey+1,x
        bne _chg
        lda DigitPtr+2
        cmp ScoreKey+2,x
        bne _chg
        lda DigitPtr+3
        cmp ScoreKey+3,x
        bne _chg
        lda DigitPtr+4
        cmp ScoreKey+4,x
        bne _chg
        lda DigitPtr+5
        cmp ScoreKey+5,x
        bne _chg
        lda DigitPtr+6
        cmp ScoreKey+6,x
        bne _chg
        lda DigitPtr+7
        cmp ScoreKey+7,x
        bne _chg
        lda DigitPtr+8
        cmp ScoreKey+8,x
        bne _chg
        lda DigitPtr+9
        cmp ScoreKey+9,x
        bne _chg
        lda scoreE7
        cmp ScoreKey+10,x
        bne _chg
        lda DigitPtr+11
        cmp ScoreKey+11,x
        bne _chg
        rts
_chg
        lda DigitPtr+0
        sta ScoreKey+0,x
        lda DigitPtr+1
        sta ScoreKey+1,x
        lda DigitPtr+2
        sta ScoreKey+2,x
        lda DigitPtr+3
        sta ScoreKey+3,x
        lda DigitPtr+4
        sta ScoreKey+4,x
        lda DigitPtr+5
        sta ScoreKey+5,x
        lda DigitPtr+6
        sta ScoreKey+6,x
        lda DigitPtr+7
        sta ScoreKey+7,x
        lda DigitPtr+8
        sta ScoreKey+8,x
        lda DigitPtr+9
        sta ScoreKey+9,x
        lda scoreE7
        sta ScoreKey+10,x
        lda DigitPtr+11
        sta ScoreKey+11,x
        ldx #0                  ; each digit's rows 9..0 -> ScD0-5 + 1..10 (line - 40)
        ldy #0
_dig    jsr DigitLo
        sta ptrA
        lda DigitPtr+1,y
        sta ptrA+1
        sty tmp
        lda DigitCol,x
        tax
        ldy #9
-       lda (ptrA),y
        sta ScD0+1,x
        inx
        dey
        bpl -
        ldy tmp
        iny
        iny
        tya
        lsr
        tax
        cpx #6
        bne _dig
        ; the 48 pixels from pixel 55: cell j of characters 1-13 / 14-26 has pixels 52 + 4j
        ; .. 55 + 4j: digit m's bits 6-3 (j = 2m + 1), or digit m - 1's bits 2-0 and digit
        ; m's bit 7 (j = 2m)
        lda rbuf
        beq _buf0
        jmp _buf1
_buf0  ldy #1
-
        ldx ScD0,y
        lda CellHiA,x
        sta CHARS0+(SCORECH+0)*8,y
        ldx ScD0,y
        lda CellLo,x
        sta CHARS0+(SCORECH+1)*8,y
        ldx ScD1,y
        lda CellHiA,x
        ldx ScD0,y
        ora CellHiB,x
        sta CHARS0+(SCORECH+2)*8,y
        ldx ScD1,y
        lda CellLo,x
        sta CHARS0+(SCORECH+3)*8,y
        ldx ScD2,y
        lda CellHiA,x
        ldx ScD1,y
        ora CellHiB,x
        sta CHARS0+(SCORECH+4)*8,y
        ldx ScD2,y
        lda CellLo,x
        sta CHARS0+(SCORECH+5)*8,y
        ldx ScD3,y
        lda CellHiA,x
        ldx ScD2,y
        ora CellHiB,x
        sta CHARS0+(SCORECH+6)*8,y
        ldx ScD3,y
        lda CellLo,x
        sta CHARS0+(SCORECH+7)*8,y
        ldx ScD4,y
        lda CellHiA,x
        ldx ScD3,y
        ora CellHiB,x
        sta CHARS0+(SCORECH+8)*8,y
        ldx ScD4,y
        lda CellLo,x
        sta CHARS0+(SCORECH+9)*8,y
        ldx ScD5,y
        lda CellHiA,x
        ldx ScD4,y
        ora CellHiB,x
        sta CHARS0+(SCORECH+10)*8,y
        ldx ScD5,y
        lda CellLo,x
        sta CHARS0+(SCORECH+11)*8,y
        ldx ScD5,y
        lda CellHiB,x
        sta CHARS0+(SCORECH+12)*8,y
        iny
        cpy #8
        beq +
        jmp -
+
_b0r1  ldy #8
-
        ldx ScD0,y
        lda CellHiA,x
        sta CHARS0+(SCORECH+0)*8+104-8,y
        ldx ScD0,y
        lda CellLo,x
        sta CHARS0+(SCORECH+1)*8+104-8,y
        ldx ScD1,y
        lda CellHiA,x
        ldx ScD0,y
        ora CellHiB,x
        sta CHARS0+(SCORECH+2)*8+104-8,y
        ldx ScD1,y
        lda CellLo,x
        sta CHARS0+(SCORECH+3)*8+104-8,y
        ldx ScD2,y
        lda CellHiA,x
        ldx ScD1,y
        ora CellHiB,x
        sta CHARS0+(SCORECH+4)*8+104-8,y
        ldx ScD2,y
        lda CellLo,x
        sta CHARS0+(SCORECH+5)*8+104-8,y
        ldx ScD3,y
        lda CellHiA,x
        ldx ScD2,y
        ora CellHiB,x
        sta CHARS0+(SCORECH+6)*8+104-8,y
        ldx ScD3,y
        lda CellLo,x
        sta CHARS0+(SCORECH+7)*8+104-8,y
        ldx ScD4,y
        lda CellHiA,x
        ldx ScD3,y
        ora CellHiB,x
        sta CHARS0+(SCORECH+8)*8+104-8,y
        ldx ScD4,y
        lda CellLo,x
        sta CHARS0+(SCORECH+9)*8+104-8,y
        ldx ScD5,y
        lda CellHiA,x
        ldx ScD4,y
        ora CellHiB,x
        sta CHARS0+(SCORECH+10)*8+104-8,y
        ldx ScD5,y
        lda CellLo,x
        sta CHARS0+(SCORECH+11)*8+104-8,y
        ldx ScD5,y
        lda CellHiB,x
        sta CHARS0+(SCORECH+12)*8+104-8,y
        iny
        cpy #11
        beq +
        jmp -
+
        rts
_buf1  ldy #1
-
        ldx ScD0,y
        lda CellHiA,x
        sta CHARS1+(SCORECH+0)*8,y
        ldx ScD0,y
        lda CellLo,x
        sta CHARS1+(SCORECH+1)*8,y
        ldx ScD1,y
        lda CellHiA,x
        ldx ScD0,y
        ora CellHiB,x
        sta CHARS1+(SCORECH+2)*8,y
        ldx ScD1,y
        lda CellLo,x
        sta CHARS1+(SCORECH+3)*8,y
        ldx ScD2,y
        lda CellHiA,x
        ldx ScD1,y
        ora CellHiB,x
        sta CHARS1+(SCORECH+4)*8,y
        ldx ScD2,y
        lda CellLo,x
        sta CHARS1+(SCORECH+5)*8,y
        ldx ScD3,y
        lda CellHiA,x
        ldx ScD2,y
        ora CellHiB,x
        sta CHARS1+(SCORECH+6)*8,y
        ldx ScD3,y
        lda CellLo,x
        sta CHARS1+(SCORECH+7)*8,y
        ldx ScD4,y
        lda CellHiA,x
        ldx ScD3,y
        ora CellHiB,x
        sta CHARS1+(SCORECH+8)*8,y
        ldx ScD4,y
        lda CellLo,x
        sta CHARS1+(SCORECH+9)*8,y
        ldx ScD5,y
        lda CellHiA,x
        ldx ScD4,y
        ora CellHiB,x
        sta CHARS1+(SCORECH+10)*8,y
        ldx ScD5,y
        lda CellLo,x
        sta CHARS1+(SCORECH+11)*8,y
        ldx ScD5,y
        lda CellHiB,x
        sta CHARS1+(SCORECH+12)*8,y
        iny
        cpy #8
        beq +
        jmp -
+
_b1r1  ldy #8
-
        ldx ScD0,y
        lda CellHiA,x
        sta CHARS1+(SCORECH+0)*8+104-8,y
        ldx ScD0,y
        lda CellLo,x
        sta CHARS1+(SCORECH+1)*8+104-8,y
        ldx ScD1,y
        lda CellHiA,x
        ldx ScD0,y
        ora CellHiB,x
        sta CHARS1+(SCORECH+2)*8+104-8,y
        ldx ScD1,y
        lda CellLo,x
        sta CHARS1+(SCORECH+3)*8+104-8,y
        ldx ScD2,y
        lda CellHiA,x
        ldx ScD1,y
        ora CellHiB,x
        sta CHARS1+(SCORECH+4)*8+104-8,y
        ldx ScD2,y
        lda CellLo,x
        sta CHARS1+(SCORECH+5)*8+104-8,y
        ldx ScD3,y
        lda CellHiA,x
        ldx ScD2,y
        ora CellHiB,x
        sta CHARS1+(SCORECH+6)*8+104-8,y
        ldx ScD3,y
        lda CellLo,x
        sta CHARS1+(SCORECH+7)*8+104-8,y
        ldx ScD4,y
        lda CellHiA,x
        ldx ScD3,y
        ora CellHiB,x
        sta CHARS1+(SCORECH+8)*8+104-8,y
        ldx ScD4,y
        lda CellLo,x
        sta CHARS1+(SCORECH+9)*8+104-8,y
        ldx ScD5,y
        lda CellHiA,x
        ldx ScD4,y
        ora CellHiB,x
        sta CHARS1+(SCORECH+10)*8+104-8,y
        ldx ScD5,y
        lda CellLo,x
        sta CHARS1+(SCORECH+11)*8+104-8,y
        ldx ScD5,y
        lda CellHiB,x
        sta CHARS1+(SCORECH+12)*8+104-8,y
        iny
        cpy #11
        beq +
        jmp -
+
        rts
DigitCol:   .byte 0, 11, 22, 33, 44, 55
; a score cell's "01" pixels: digit bits 6-3 (CellLo), bit 7 as the last pixel (CellHiA),
; bits 2-0 as the first three (CellHiB)
CellLo:     .for b = 0, b < 256, b += 1
            .byte ((b & $40) ? $40 : 0) | ((b & $20) ? $10 : 0) | ((b & $10) ? $04 : 0) | ((b & $08) ? $01 : 0)
            .next
CellHiA:    .for b = 0, b < 256, b += 1
            .byte (b & $80) ? $01 : 0
            .next
CellHiB:    .for b = 0, b < 256, b += 1
            .byte ((b & 4) ? $40 : 0) | ((b & 2) ? $10 : 0) | ((b & 1) ? $04 : 0)
            .next
Mul12:      .byte 0, 12
; the score's pointers (Y = 0-11) as the kernel used them (it overwrites $E7 after the score)
DigitLo:
        cpy #10
        beq +
        lda DigitPtr,y
        rts
+       lda scoreE7
        rts

; ---------------------------------------------------------------- bunkers
; Player 0 at pixel 15 and player 1 at 23, copies and size by NUSIZ (from the number of
; bunkers: the kernel's tables, read even when there are none left), graphics rows 5-1 on
; lines 223-227; player 1 from 2 bunkers up. Redrawn when the number changes.
; the bunkers' characters: the ground's "10" pixels on its odd lines, where no bunker is
BunkGround:
        lda #BUNKCH
        jsr CharAddr
        ldx #BUNKCOLS-1
_col    stx tmp3
        txa                     ; (row 22's character x, row 23's x + BUNKCOLS)
        asl
        asl
        asl
        sta tmp4
        ldx #5
-       lda BunkOdd,x
        cmp #8
        bcc +
        adc #BUNKCOLS*8-8-1     ; (row 23: BUNKCOLS characters on; carry set)
+       clc
        adc tmp4
        tay
        lda (dstPtr),y
        stx tmp2
        tax
        lda FbKeepOf,x
        and #$aa
        ldx tmp2
        ora (dstPtr),y
        sta (dstPtr),y
        dex
        bpl -
        ldx tmp3
        dex
        bpl _col
        rts

DrawBunkers:
        ldx Player              ; (the kernel's choice: player 1's in a co-op game)
        bit CoOp
        bpl +
        ldx #0
+       lda Lives,x
        ldx rbuf
        cmp BunkKey,x
        bne +
        rts
+       sta BunkKey,x
        sta bunkN
        lda #BUNKCH             ; clear the bunkers' characters
        jsr CharAddr
        ldy #2*BUNKCOLS*8-1
        lda #0
-       sta (dstPtr),y
        dey
        cpy #$ff
        bne -
        lda bunkN
        bne +
        jmp BunkGround          ; none
+       lda #5                  ; graphics rows 5..1
        sta bunkRow
        lda #BUNKLINE
        sta plL
_line   lda plL
        jsr LineRow
        ldx bunkRow
        lda BunkerGfx,x
        sta bunkG
        ldy bunkN
        lda BunkerNus0,y        ; player 0
        ldx #15
        jsr _player
        lda bunkN
        cmp #2
        bcc +
        ldy bunkN
        lda BunkerNus1,y        ; player 1
        ldx #23
        jsr _player
+       inc plL
        dec bunkRow
        bne _line
        jmp BunkGround
_player stx bunkX               ; NUSIZ A: copies at +16 / +32 / +64, size 1 / 2 / 4
        and #7
        tay
        lda NusCopies,y
        sta bunkC
        lda NusSize,y
        sta bunkS
        lda bunkX
        jsr _one
        lda bunkC
        lsr
        bcc +
        pha
        lda bunkX
        clc
        adc #16
        jsr _one
        pla
+       lsr
        bcc +
        pha
        lda bunkX
        clc
        adc #32
        jsr _one
        pla
+       lsr
        bcc +
        lda bunkX
        clc
        adc #64
        jsr _one
+       rts
_one    cmp #160                ; one copy at pixel A
        bcc +
        sbc #160
+       sta plX
        lda bunkG
        ldy bunkS
        cpy #1
        bne +
        sta plA
        lda #1
        sta plN
        jmp PlotStatic
+       tax                     ; two or four pixels a bit
        cpy #2
        bne +
        lda DblHi,x
        sta plA
        lda DblLo,x
        sta plA+1
        lda #2
        sta plN
        jmp PlotStatic
+       lda Quad0,x
        sta plA
        lda Quad1,x
        sta plA+1
        lda Quad2,x
        sta plA+2
        lda Quad3,x
        sta plA+3
        lda #4
        sta plN
        jmp PlotStatic
NusCopies:  .byte 0, 1, 2, 3, 4, 0, 6, 0
NusSize:    .byte 1, 1, 1, 1, 1, 2, 1, 4

; ----------------------------------------------------------------- demon bands
; Band X: rows 7..0 on lines 210-C .. 217-C. Player 0 at bX0, player 1 (reflected) at bX1,
; eight or 32 pixels wide. Colours: the band's colour table, a byte per row; left of pixel
; 43 (player 0) / 52 (player 1) a line shows the previous line's colour. Player 1's
; graphics are written at pixel 19: left of that, the line above's row.
; (DrawBand: as the plan says; DrawBandF: as always, without a plan)
DrawBand:
        lda #210                ; the band's first line
        sec
        sbc bC,x
        sta bandL
        stx spUse               ; its blocks
        lda ItP,x               ; the plan's pair ($ff: none, or a split band's halves on both),
        sta spPair              ; and what it is (Classify: 0 blank, 1 a sprite pair, 2 split: a
        lda ItK,x               ; pair for each half if the plan gives them, 3 characters)
        bne +
        jmp BlankUse
+       cmp #1
        beq _sp
        cmp #2
        bne _ch
        lda ItN,x
        cmp #2
        beq _sp
        cmp #3
        bne _ch
        jmp DrawBandF._half
_ch     jmp DrawBandF._chars
_sp     jmp DrawBandF._sprite
DrawBandF:
        lda #210                ; the band's first line
        sec
        sbc bC,x
        sta bandL
        stx spUse               ; its blocks
        lda FixedPair,x         ; bands 0 and 2 on sprites 4-5, band 1 on 6-7
        sta spPair
        lda bP0,x               ; shape 0 for both: blank (its "row above" too), nothing shown
        ora bP1,x
        bne +
        jmp BlankUse
+
        ; one sprite pair if it's normal width, both players inside 24 pixels, no wrapping
        lda bW,x
        cmp #8
        bne _tochars
        lda bX0,x
        cmp #153
        bcs _tochars
        lda bX1,x
        cmp #153
        bcs _tochars
        sec
        sbc bX0,x
        bcs +
        eor #$ff                ; |x1 - x0|
        adc #1
+       cmp #17
        bcc _sprite
_tochars jmp _chars
_sprite lda #0                  ; previous-colour pixels: player 0 left of 43, player 1 left of
        sta runPrev             ; 52 (or wrapped round)
        lda bX0,x
        cmp #43
        bcc +
        cmp #153
        bcs +
        lda bX1,x
        cmp #52
        bcc +
        cmp #153
        bcs +
        lda #64
        sta runPrev
+       jsr ColourBefore
        ldx spPair              ; (none: a split band, a pair for each half)
        bpl +
        jmp _split
+
        ldy PairRegP,x          ; (even lines: the first sprite's colour)
        jsr SchedColourRun
        ldx band
        ; ready-made: one piece (same graphics, player 1 right after player 0), a shape
        ; that has them, and all in one colour: player 0 from pixel 43 and player 1 from 52
        ; (x0 >= 44), or player 0 left of 43 and player 1 left of 52 but from 19 (11 - 35)
        lda bP0,x
        cmp bP1,x
        bne _own
        cmp #NIMG*8
        bcs _own
        lda bX0,x
        clc
        adc #8
        cmp bX1,x
        bne _own
        ldy #0
        lda bX0,x
        cmp #44
        bcs +
        iny                     ; (all the previous line's colour)
        cmp #36
        bcs _own
        cmp #11
        bcc _own
+       sty tmp3
        lda bandL               ; the first sprite: even rows if its colour is "this
        and #1                  ; line's" on even lines
        eor tmp3
        sta tmp3
        lda bP0,x               ; the even rows' block: IMGBLK + 2 * shape
        lsr
        lsr
        clc
        adc #IMGBLK
        ldy tmp3
        beq +
        sta swBlk2              ; (the odd rows' block first)
        adc #1
        sta swBlk
        jmp ++
+       sta swBlk
        adc #1
        sta swBlk2
+       lda bX0,x
        sta swS
        jmp SprPos
_own    lda bX0,x
        sta swX0
        lda bX1,x
        sta swX1
        lda bP0,x
        sta swG0
        lda bP1,x
        sta swG1
        lda #0
        sta swSmall
        jmp SprDemon
_split  ldy #6                  ; split, as sprites: both pairs, the same colours (both written;
        sty runDual             ; waiting for pixel 52 even without previous-colour pixels)
        ldy #0
        sty runPrev
        ldy #<$d02b
        jsr SchedColourRun
        lda #0
        sta runDual
        ldx band                ; the left half on sprites 4-5, whose register the run writes
        lda bX0,x               ; first (the right one's pixels start 17 or more pixels, 4
        ldy bX1,x               ; cycles, later: the second write has as long)
        cmp bX1,x
        bcc +
        tya
        ldy bX0,x
        ldx #1
        .byte $2c
+       ldx #0
        stx hfA                 ; (player 0's pair)
        ldx runH                ; (for the checks: their first pixels)
        sta RunXL-1,x
        tya
        sta RunXR-1,x
        lda hfA
        sta spPair              ; player 0: the band's blocks,
        lda #0
        sta hfP
        jsr SprHalf
        lda hfA                 ; player 1: its own
        eor #1
        sta spPair
        lda #1
        sta hfP
        jmp SprHalf
; a split band, one pair free (the plan): the left half on it, the right one characters
; (OneBand), one colour run for both (pair, then $D022 /
; $D023), waiting for pixel 52
_half   lda #0
        sta runPrev
        jsr ColourBefore
        ldy spPair
        ldx HalfDual,y
        stx runDual
        ldx spPair
        ldy PairRegP,x
        jsr SchedColourRun
        lda #0
        sta runDual
        ldx band                ; the left player (hfP) and the halves' first pixels (checks)
        lda bX0,x
        ldy bX1,x
        cmp bX1,x
        bcc +
        tya
        ldy bX0,x
        ldx #1
        .byte $2c
+       ldx #0
        stx hfP
        ldx runH
        sta RunXL-1,x
        tya
        sta RunXR-1,x
        jsr SprHalf
        lda hfP                 ; the right one: characters
        eor #1
        sta hfC
        jmp OneBand
HalfDual:   .byte 8, 10         ; (SchedColourRun's variants: a half on sprites 4-5 / 6-7)
_chars  lda #0                  ; characters: registers $D022 / $D023
        sta runPrev
        jsr ColourBefore
        ldy #<$d022
        jsr SchedColourRun
        jsr BlankUse
        ldx band
        lda bW,x
        cmp #8
        beq +
        jmp FatBand             ; (four times as wide)
+       jmp SlowBand
; the colour before the band's first line: band 0 the score's, the others the colour
; table's row 0 (the last band's last write)
ColourBefore:
        ldx band
        bne +
        lda ScoreColour
        and ColourMask
        rts
+       ldy #0
        lda (ColourPtr),y
        rts
FixedPair:  .byte 0, 1, 0, 1    ; each band's sprite pair without a plan (and the cannon band's)
PairRegP:   .byte <$d02b, <$d02d   ; each pair's first colour register

; ------------------------------------------------- a demon as a sprite pair
; swX0 / swX1: players' pixels, swG0 / swG1: their graphics (low bytes into page $1E),
; swSmall: 0 a demon band (player 1 reflected, both players), 1 the small demon (player 1
; only, not reflected; its own splits per line). Eight rows, 7..0, on lines bandL.., into
; use spUse's two blocks: each line's pixels split into "this line's colour" and "the
; previous line's", given to the two sprites by line parity.
SprDemon:
        lda spUse               ; (the cannon band's blocks: DrawPieces must clear them all)
        cmp #3
        bne +
        ldx rbuf
        lda #$ff
        sta PcN,x
+       lda swX0                ; the window: 24 pixels from the leftmost player
        ldx swSmall
        beq +
        lda swX1
+       cmp swX1
        bcc +
        lda swX1
+       sta swS
        lda swX0
        sec
        sbc swS
        sta swO0
        lda swX1
        sec
        sbc swS
        sta swO1
        ; the masks: each player's pixels, and those left of its colour split / pixel 19
        lda #$ff
        ldx swO0
        jsr Place
        ldx #2
-       lda pw,x
        sta in0,x
        dex
        bpl -
        lda #$ff
        ldx swO1
        jsr Place
        ldx #2
-       lda pw,x
        sta in1,x
        dex
        bpl -
        lda #43
        jsr LeftWin
        ldx #2
-       lda pw,x
        and in0,x
        sta pv0,x
        dex
        bpl -
        lda #52
        jsr LeftWin
        ldx #2
-       lda pw,x
        and in1,x
        sta pv1,x
        dex
        bpl -
        lda #19
        jsr LeftWin
        ldx #2
-       lda pw,x
        and in1,x
        sta left19,x
        dex
        bpl -
        lda left19              ; (none: player 1's line above isn't needed)
        ora left19+1
        ora left19+2
        sta swUp
        ; the blocks
        ldx rbuf
        lda SprBlkNum,x
        clc
        adc #B_DEMONS
        sta tmp
        lda spUse
        asl
        adc tmp
        sta swBlk               ; block number of the first sprite
        clc
        adc #1
        sta swBlk2
        lda swBlk
        tax
        lda BlkLo,x
        sta ptrA
        lda BlkHi,x
        sta ptrA+1
        lda BlkLo+1,x
        sta ptrB
        lda BlkHi+1,x
        sta ptrB+1
        lda spUse               ; the cannon band's blocks after the explosion: rows 8-20
        cmp #3                  ; blank again
        bne +
        ldx rbuf
        lda PcDirty,x
        beq +
        lda #0
        sta PcDirty,x
        ldy #8*3
-       sta (ptrA),y
        sta (ptrB),y
        iny
        cpy #63
        bne -
+       lda swG0
        ora #7
        sta swR0
        lda swG1
        ora #7
        sta swR1
        lda #0
        sta swRow
        lda bandL
        sta swL
        lda swSmall             ; the usual case: both players on byte boundaries of the
        beq +                   ; window, in different bytes
        jsr SmallSetup          ; (the small demon: its masks once)
        jmp _row
+
        lda swO0
        ora swO1
        and #7
        bne _row
        lda swO0
        cmp swO1
        beq _row
        jmp SprAligned
_row    lda swSmall
        bne _small
        ldy swR0                ; player 0
        lda DemonGfx,y
        ldx swO0
        jsr Place
        ldx #2
-       lda pw,x
        sta p0w,x
        dex
        bpl -
        ldy swR1                ; player 1, reflected: this row, and the line above's
        ldx DemonGfx,y          ; (shown left of pixel 19)
        lda Reverse,x
        ldx swO1
        jsr Place
        ldx #2
-       lda pw,x
        sta p1w,x
        dex
        bpl -
        lda swUp
        beq _mix
        ldy swR1
        iny
        ldx DemonGfx,y
        lda Reverse,x
        ldx swO1
        jsr Place
        jmp _mix
_small  jsr SmallRow            ; (the small demon: p0w = 0, p1w / pw, its own masks;
        lda swRow               ; bytes 1-2 blank: only byte 0's pixels)
        asl
        adc swRow
        tay
        lda pw
        eor p1w
        and left19
        eor p1w
        sta tmp
        and pv1                 ; previous colour
        sta tmp2
        eor tmp                 ; this line's
        pha                     ; (odd line: the second sprite has this line's colour)
        lda swL
        lsr
        pla
        bcs +
        sta (ptrA),y            ; (even line: the first sprite has this line's colour)
        lda tmp2
        sta (ptrB),y
        jmp ++
+       sta (ptrB),y
        lda tmp2
        sta (ptrA),y
+       lda #0
        iny
        sta (ptrA),y
        sta (ptrB),y
        iny
        sta (ptrA),y
        sta (ptrB),y
        jmp _mnext
_mix    lda swRow               ; per byte: player 1 = this row, the line above's where
        asl                     ; left19; under player 0 it doesn't show; "previous colour"
        adc swRow               ; pixels by the masks; into the blocks, row swRow (odd
        tay                     ; line: the second sprite has this line's colour)
        lda swL
        lsr
        bcc +
        jmp _modd
+
        lda pw+0
        eor p1w+0
        and left19+0
        eor p1w+0
        sta tmp
        lda p0w+0
        eor #$ff
        and tmp                 ; player 1 where player 0 isn't
        sta tmp
        and pv1+0
        sta tmp2
        lda p0w+0
        and pv0+0
        ora tmp2
        sta tmp2                ; previous colour
        lda p0w+0
        ora tmp
        eor tmp2                ; this line's
        sta (ptrA),y
        lda tmp2
        sta (ptrB),y
        iny
        lda pw+1
        eor p1w+1
        and left19+1
        eor p1w+1
        sta tmp
        lda p0w+1
        eor #$ff
        and tmp                 ; player 1 where player 0 isn't
        sta tmp
        and pv1+1
        sta tmp2
        lda p0w+1
        and pv0+1
        ora tmp2
        sta tmp2                ; previous colour
        lda p0w+1
        ora tmp
        eor tmp2                ; this line's
        sta (ptrA),y
        lda tmp2
        sta (ptrB),y
        iny
        lda pw+2
        eor p1w+2
        and left19+2
        eor p1w+2
        sta tmp
        lda p0w+2
        eor #$ff
        and tmp                 ; player 1 where player 0 isn't
        sta tmp
        and pv1+2
        sta tmp2
        lda p0w+2
        and pv0+2
        ora tmp2
        sta tmp2                ; previous colour
        lda p0w+2
        ora tmp
        eor tmp2                ; this line's
        sta (ptrA),y
        lda tmp2
        sta (ptrB),y
        jmp _mnext
_modd
        lda pw+0
        eor p1w+0
        and left19+0
        eor p1w+0
        sta tmp
        lda p0w+0
        eor #$ff
        and tmp                 ; player 1 where player 0 isn't
        sta tmp
        and pv1+0
        sta tmp2
        lda p0w+0
        and pv0+0
        ora tmp2
        sta tmp2                ; previous colour
        lda p0w+0
        ora tmp
        eor tmp2                ; this line's
        sta (ptrB),y
        lda tmp2
        sta (ptrA),y
        iny
        lda pw+1
        eor p1w+1
        and left19+1
        eor p1w+1
        sta tmp
        lda p0w+1
        eor #$ff
        and tmp                 ; player 1 where player 0 isn't
        sta tmp
        and pv1+1
        sta tmp2
        lda p0w+1
        and pv0+1
        ora tmp2
        sta tmp2                ; previous colour
        lda p0w+1
        ora tmp
        eor tmp2                ; this line's
        sta (ptrB),y
        lda tmp2
        sta (ptrA),y
        iny
        lda pw+2
        eor p1w+2
        and left19+2
        eor p1w+2
        sta tmp
        lda p0w+2
        eor #$ff
        and tmp                 ; player 1 where player 0 isn't
        sta tmp
        and pv1+2
        sta tmp2
        lda p0w+2
        and pv0+2
        ora tmp2
        sta tmp2                ; previous colour
        lda p0w+2
        ora tmp
        eor tmp2                ; this line's
        sta (ptrB),y
        lda tmp2
        sta (ptrA),y
_mnext  inc swL
        dec swR0
        dec swR1
        inc swRow
        lda swRow
        cmp #8
        beq SprPos
        jmp _row

; the pair's position: this buffer's staging (its first use) or the pair record its move
; down sets (PairRec), blocks swBlk and swBlk2
SprPos:
        lda swS
        jsr SprX                ; -> A low byte, tmp bit 8; X = rbuf
        sta tmp2
        lda bandL
        clc
        adc #SPRYOFS
        sta tmp3
        ldy spPair
        lda PairRec,y
        bpl _later
        lda Mul8,x              ; its first use: sprites 4-5 / 6-7 at the frame top
        ora PairSpr,y
        tay
        lda tmp2
        sta StX,y
        sta StX+1,y
        lda tmp3
        sta StY,y
        sta StY+1,y
        lda swBlk
        sta StPtr,y
        lda swBlk2
        sta StPtr+1,y
        lda tmp
        beq +
        ldy spPair
        lda PairBits,y
        ora StMsb,x
        sta StMsb,x
+       rts
_later  tay                     ; a pair record
        lda tmp2
        sta PairX,y
        lda tmp3
        sta PairY,y
        sta PairY2,y
        lda swBlk
        sta PairPtr,y
        lda swBlk2
        sta PairPtr2,y
        lda #0
        ldx tmp
        beq +
        lda PairBitsR,y
+       sta PairMsb,y
        rts
; the same with each sprite's own Y (the explosion's): tmp2 / tmp X, tmp3 / tmp4 Y; X = rbuf
PairSet:
        ldy spPair
        lda PairRec,y
        bpl _later
        lda Mul8,x              ; its first use: sprites 4-5 / 6-7 at the frame top
        ora PairSpr,y
        tay
        lda tmp2
        sta StX,y
        sta StX+1,y
        lda tmp3
        sta StY,y
        lda tmp4
        sta StY+1,y
        lda swBlk
        sta StPtr,y
        lda swBlk2
        sta StPtr+1,y
        lda tmp
        beq +
        ldy spPair
        lda PairBits,y
        ora StMsb,x
        sta StMsb,x
+       rts
_later  tay                     ; a pair record
        lda tmp2
        sta PairX,y
        lda tmp3
        sta PairY,y
        lda tmp4
        sta PairY2,y
        lda swBlk
        sta PairPtr,y
        lda swBlk2
        sta PairPtr2,y
        lda #0
        ldx tmp
        beq +
        lda PairBitsR,y
+       sta PairMsb,y
        rts
PairSpr:    .byte 4, 6
PairBits:   .byte $30, $c0
Mul8:       .byte 0, 8

; SprDemon's rows when both players sit on byte boundaries of the window: no shifting,
; one byte each.
SprAligned:
        lda swO0
        lsr
        lsr
        lsr
        sta k0
        tax
        lda pv0,x
        sta pv0b
        lda swO1
        lsr
        lsr
        lsr
        sta k1
        tax
        lda pv1,x
        sta pv1b
        lda left19,x
        sta l19b
_row    ldy swR0                ; player 0
        lda DemonGfx,y
        sta g0b
        ldy swR1                ; player 1 (reflected) ...
        ldx DemonGfx,y
        lda Reverse,x
        sta g1b
        lda l19b                ; ... and the line above's left of pixel 19
        beq +
        iny
        ldx DemonGfx,y
        lda Reverse,x
        eor g1b
        and l19b
        eor g1b
        sta g1b
+       lda g0b                 ; their pixels in the previous line's colour, and this line's
        and pv0b
        sta pr0
        eor g0b
        sta cu0
        lda g1b
        and pv1b
        sta pr1
        eor g1b
        sta cu1
        lda #0
        sta pa
        sta pa+1
        sta pa+2
        sta pb
        sta pb+1
        sta pb+2
        lda swL                 ; odd line: the second sprite has this line's colour
        lsr
        bcs _odd
        ldx k0
        lda cu0
        sta pa,x
        lda pr0
        sta pb,x
        ldx k1
        lda cu1
        sta pa,x
        lda pr1
        sta pb,x
        jmp _store
_odd    ldx k0
        lda cu0
        sta pb,x
        lda pr0
        sta pa,x
        ldx k1
        lda cu1
        sta pb,x
        lda pr1
        sta pa,x
_store  lda swRow
        asl
        adc swRow
        tay
        lda pa
        sta (ptrA),y
        lda pb
        sta (ptrB),y
        iny
        lda pa+1
        sta (ptrA),y
        lda pb+1
        sta (ptrB),y
        iny
        lda pa+2
        sta (ptrA),y
        lda pb+2
        sta (ptrB),y
        inc swL
        dec swR0
        dec swR1
        inc swRow
        lda swRow
        cmp #8
        beq +
        jmp _row
+       jmp SprPos

; This use of pair spPair shows nothing (the band is blank or drawn as characters; $ff: the
; plan gave it no pair)
BlankUse:
        ldy spPair
        bmi _none
        lda PairRec,y
        bpl _later
        ldx rbuf
        lda Mul8,x
        ora PairSpr,y
        tay
        lda #BLK_BLANK
        sta StPtr,y
        sta StPtr+1,y
        lda #0                  ; (and in the top border: a blank pair still runs its 21
        sta StY,y               ; rows, and its second use's pointer mustn't land in them)
        sta StY+1,y
_none   rts
_later  tay
        lda #BLK_BLANK
        sta PairPtr,y
        sta PairPtr2,y
        lda #0
        sta PairY,y
        sta PairY2,y
        sta PairX,y
        sta PairMsb,y
        rts

; pw[0..2] = byte A placed X (0-16) bits into a 24-bit window (pixel order)
Place:
        ldy #0
        sty pw
        sty pw+1
        sty pw+2
        tay
        txa
        and #7
        bne _shift
        txa
        lsr
        lsr
        lsr
        tax
        tya
        sta pw,x
        rts
_shift  sty tmp4                ; (the byte)
        tay
        lda BShRLo-1,y
        sta ptrC
        lda BShRHi-1,y
        sta ptrC+1
        lda BShLLo-1,y
        sta dstPtr
        lda BShLHi-1,y
        sta dstPtr+1
        txa
        lsr
        lsr
        lsr
        tax
        ldy tmp4
        lda (ptrC),y
        sta pw,x
        lda (dstPtr),y
        sta pw+1,x
        rts
BShRLo:     .byte <BShR1, <BShR2, <BShR3, <BShR4, <BShR5, <BShR6, <BShR7
BShRHi:     .byte >BShR1, >BShR2, >BShR3, >BShR4, >BShR5, >BShR6, >BShR7
BShLLo:     .byte <BShL1, <BShL2, <BShL3, <BShL4, <BShL5, <BShL6, <BShL7
BShLHi:     .byte >BShL1, >BShL2, >BShL3, >BShL4, >BShL5, >BShL6, >BShL7

; pw[0..2] = the window's pixels left of pixel A (window from swS)
LeftWin:
        sec
        sbc swS
        bcs +
        lda #0                  ; (all right of it)
+       cmp #24
        bcc +
        lda #24
+       tax                     ; (by table: the first n pixels of 24)
        lda LeftW0,x
        sta pw
        lda LeftW1,x
        sta pw+1
        lda LeftW2,x
        sta pw+2
        rts
LeftW0:     .for n = 0, n <= 24, n += 1
            .byte ($ff00 >> (n < 8 ? n : 8)) & $ff
            .next
LeftW1:     .for n = 0, n <= 24, n += 1
            .byte ($ff00 >> (n < 8 ? 0 : n < 16 ? n - 8 : 8)) & $ff
            .next
LeftW2:     .for n = 0, n <= 24, n += 1
            .byte ($ff00 >> (n < 16 ? 0 : n - 16)) & $ff
            .next

; ------------------------------------------------------------- wide (materializing) bands
; Each graphics bit is four pixels (NUSIZ 7). For each player: its cells (up to 9, from its
; first pixel's), each cell's "01" pixels on each line, from the rows' bits by table (player
; 1 left of pixel 19: the row above's), then coloured: this line's colour "01" on even lines
; and "10" on odd ones, the previous line's colour (left of the colour split) the other
; way round. Then each cell is written once per line: player 1, and player 0 in front.
; FbLitA: player 1's cells k at 9k + j, player 0's at 81 + 9k + j; j = 1..8 the band's
; lines, j = 0 the row above line 1's (row 8).
FatBand:
        ldx band
        lda bP0,x
        ora bP1,x
        bne +
        rts
+       lda bX1,x               ; the players' cells
        jsr FbCells1
        ldx band
        lda bX0,x
        jsr FbCells0
        lda #0
        sta fbCached
        ldx band                ; shapes 1-4 (the players have the same one): their cells'
        lda bP0,x               ; lines ready-made (FbCache), for player 1 at its pixel
        cmp bP1,x               ; offset 0-3 and player 0 at its
        bne _own
        sec
        sbc #8
        cmp #32
        bcs _own
        lsr                     ; ((shape - 1) x 4)
        sta tmp
        lda bX1,x
        and #3
        ora tmp
        tay
        lda bX0,x
        and #3
        ora tmp
        tax
        jsr FbFromCache
        lda FbGmAny             ; (left of pixel 19, the row above's graphics: a whole cell
        beq +                   ; reads its lines a row up; part of one, FbAbove)
        jsr FbAbove
+       jsr FbFlush
        ldx fbFilled            ; (CellIn back to none: those FbFill set)
        bne +
        rts
+       lda #0
        sta fbFilled
-       ldy FbFilledL-1,x
        sta CellIn,y
        dex
        bne -
        rts
_own    ldx band                ; others: worked out here
        lda bX1,x
        jsr FbCells1
        ldx band
        lda bP1,x
        jsr FbRows1
        jsr FbLit1
        lda FbGmAny
        beq +
        jsr FbAbove
+       ldx band
        lda bX0,x
        jsr FbCells0
        ldx band
        lda bP0,x
        jsr FbRows0
        jsr FbLit0
        ldx #17                 ; (every cell's lines in FbLitA)
        lda #1
-       sta CellIn,x
        dex
        bpl -
        jsr FbFlush
        lda #0
        ldx #17
-       sta CellIn,x
        dex
        bpl -
        rts

; Y = player 1's block, X = player 0's (0-15): the cells' lines are read from there (fbCB1 /
; fbCB0: line j of cell k at + 16k + j, player 0's cells 9-17 too; fbCB1s: player 1's a row
; up, for a whole cell left of pixel 19), none in FbLitA yet; FbAny from there
FbFromCache:
        inc fbCached
        lda CacheP1Lo,y
        sta fbCB1
        sta ptrA
        lda CacheP1Hi,y
        sta fbCB1+1
        sta ptrA+1
        lda fbCB1               ; (a row up: one byte before)
        sec
        sbc #1
        sta fbCB1s
        lda fbCB1+1
        sbc #0
        sta fbCB1s+1
        lda CacheP0Lo,x         ; (player 0's lines j = 1-8 are at + 16k + j - 1)
        sec
        sbc #1
        sta fbCB0
        lda CacheP0Hi,x
        sbc #0
        sta fbCB0+1
        lda FbMul9,x            ; FbAny: player 0's at FBANY0 + 9 x block + k
        tax
        .for k = 0, k < 9, k += 1
        lda FBANY0+k,x
        sta FbAny+9+k
        .next
        lda FbGmAny             ; player 1's (block + 16k + 9) too, unless a whole cell is left
        bne +                   ; of pixel 19
        .for k = 0, k < 9, k += 1
        ldy #16*k+9
        lda (ptrA),y
        sta FbAny+k
        .next
        rts
+                               ; (player 1's: a whole cell left of pixel 19, columns 0-3, at
        lda FbCol+0
        cmp #4
        ldy #16*0+9
        bcs +
        iny
+       lda (ptrA),y
        sta FbAny+0
        lda FbCol+1
        cmp #4
        ldy #16*1+9
        bcs +
        iny
+       lda (ptrA),y
        sta FbAny+1
        lda FbCol+2
        cmp #4
        ldy #16*2+9
        bcs +
        iny
+       lda (ptrA),y
        sta FbAny+2
        lda FbCol+3
        cmp #4
        ldy #16*3+9
        bcs +
        iny
+       lda (ptrA),y
        sta FbAny+3
        lda FbCol+4
        cmp #4
        ldy #16*4+9
        bcs +
        iny
+       lda (ptrA),y
        sta FbAny+4
        lda FbCol+5
        cmp #4
        ldy #16*5+9
        bcs +
        iny
+       lda (ptrA),y
        sta FbAny+5
        lda FbCol+6
        cmp #4
        ldy #16*6+9
        bcs +
        iny
+       lda (ptrA),y
        sta FbAny+6
        lda FbCol+7
        cmp #4
        ldy #16*7+9
        bcs +
        iny
+       lda (ptrA),y
        sta FbAny+7
        lda FbCol+8
        cmp #4
        ldy #16*8+9
        bcs +
        iny
+       lda (ptrA),y
        sta FbAny+8
        rts                     ; + 16k + 10: rows 0-7)

; Cell A (0-17): its lines into FbLitA (from the ready-made ones) if they aren't there
FbFill:
        tax
        lda CellIn,x
        bne _done
        lda #1
        sta CellIn,x
        ldy fbFilled            ; (listed, for FbCellsOut)
        txa
        sta FbFilledL,y
        inc fbFilled
        lda FbMul16,x
        cpx #9
        bcs _p0
        ldy FbCol,x             ; (columns 0-3: a row up)
        cpy #4
        bcc _up
        clc
        adc fbCB1
        sta srcP
        lda fbCB1+1
        jmp _hi
_up     clc
        adc fbCB1s
        sta srcP
        lda fbCB1s+1
        jmp _hi
_p0     clc
        adc fbCB0
        sta srcP
        lda fbCB0+1
_hi     adc #0
        sta srcP+1
        lda FbMul9,x
        tax
        ldy #0
        .for j = 0, j < 9, j += 1
        lda (srcP),y
        sta FbLitA+j,x
        .if j < 8
        iny
        .endif
        .next
_done   rts

; FbColumn's source for cell X (0-19), line j at Y = fbL0 + j - 1: srcP (fbAdj*: the bases
; + 1 - fbL0, set by FbFlush)
FbSrc:
        lda FbMul16,x
        ldy CellIn,x
        bne _lit
        cpx #9
        bcs _p0
        ldy FbCol,x             ; (columns 0-3: a row up)
        cpy #4
        bcc _up
        clc
        adc fbAdj1
        sta srcP
        lda fbAdj1+1
        jmp _hi
_up     clc
        adc fbAdj1s
        sta srcP
        lda fbAdj1s+1
        jmp _hi
_p0     clc
        adc fbAdj0
        sta srcP
        lda fbAdj0+1
        jmp _hi
_lit    lda FbMul9,x
        clc
        adc fbAdjL
        sta srcP
        lda fbAdjL+1
_hi     adc #0
        sta srcP+1
        rts
; the cells of X (player 1's lines' offset: 9k, 162 none) and Y (player 0's: 9k, 81 none)
; into FbLitA (X, Y kept)
FbFillXY:
        lda fbCached
        beq _done
        stx fbFX
        sty fbFY
        cpx #81
        bcs +
        lda Div9,x
        jsr FbFill
+       ldy fbFY
        cpy #81
        bcs +
        lda Div9,y
        clc
        adc #9
        jsr FbFill
+       ldx fbFX
        ldy fbFY
_done   rts

; The ready-made lines: for shapes 1-4 and pixel offsets 0-3 (block (shape - 1) x 4 + offset),
; player 1's cells (9 x 9 lines, j = 0-8), their FbAny (9) and their FbAny a row up (rows 0-7:
; 9); player 0's (9 x 9, j = 1-8 used) and FbAny. Worked out at the start by FbRows / FbLit.
FbCacheInit:
        lda #0
        sta tmp4                ; block
_b      lda tmp4
        and #3                  ; (the tables' index bases)
        asl
        asl
        asl
        asl
        sta fbS16
        asl
        sta fbS32
        lda tmp4                ; shape x 8
        and #$0c
        asl
        adc #8
        pha
        jsr FbRows1
        jsr FbLit1
        ldx tmp4
        lda CacheP1Lo,x
        sta ptrA
        lda CacheP1Hi,x
        sta ptrA+1
        ldx #8                  ; cell k: lines j = 0-8 at 16k + j, FbAny at + 9, and a row up's
-       ldy FbMul9,x            ; (any of rows j = 0-7) at + 10
        .for j = 0, j <= 8, j += 1
        lda FbLitA+j,y
        pha
        .next
        lda FbAny,x
        pha
        lda #0
        .for j = 0, j < 8, j += 1
        ora FbLitA+j,y
        .next
        pha
        lda FbMul16,x
        clc
        adc #10
        tay
        .for j = 0, j < 11, j += 1
        pla
        sta (ptrA),y
        dey
        .next
        dex
        bpl -
        pla
        jsr FbRows0
        jsr FbLit0
        ldx tmp4
        lda CacheP0Lo,x
        sta ptrA
        lda CacheP0Hi,x
        sta ptrA+1
        ldx #8                  ; cell k: lines j = 1-8 at 16k + j - 1
-       ldy FbMul9,x
        .for j = 1, j <= 8, j += 1
        lda FbLitA+81+j,y
        pha
        .next
        lda FbMul16,x
        clc
        adc #7
        tay
        .for j = 1, j <= 8, j += 1
        pla
        sta (ptrA),y
        dey
        .next
        dex
        bpl -
        lda tmp4                ; FbAny at FBANY0 + 9 x block + k
        tax
        lda FbMul9,x
        tay
        ldx #0
-       lda FbAny+9,x
        sta FBANY0,y
        iny
        inx
        cpx #9
        bne -
        inc tmp4
        lda tmp4
        cmp #16
        beq +
        jmp _b
+       rts
; (RAM under the KERNAL) Cells 16 bytes apart, as the columns' pairs are: player 1's block b
; at FBCACHE1 + 144b (cell k at 16k: lines j = 0-8, FbAny, any a row up); player 0's two
; blocks to 144 bytes (block b at FBCACHE0 + 144 (b / 2) + 8 (b & 1), cell k at 16k: lines j
; = 1-8), their FbAny at FBANY0 + 9b
FBCACHE1    = $f000
FBCACHE0    = FBCACHE1 + 144 * 16
FBANY0      = FBCACHE0 + 144 * 8
CacheP1Lo:  .for b = 0, b < 16, b += 1
            .byte <(FBCACHE1 + 144 * b)
            .next
CacheP1Hi:  .for b = 0, b < 16, b += 1
            .byte >(FBCACHE1 + 144 * b)
            .next
CacheP0Lo:  .for b = 0, b < 16, b += 1
            .byte <(FBCACHE0 + 144 * (b >> 1) + 8 * (b & 1))
            .next
CacheP0Hi:  .for b = 0, b < 16, b += 1
            .byte >(FBCACHE0 + 144 * (b >> 1) + 8 * (b & 1))
            .next
        .cerror FBANY0 + 9 * 16 > $fffa, "FbCache: no room"
FbMul16:    .for x = 0, x < 20, x += 1      ; a cell's ready-made lines' offset (cells 0-17)
            .byte x < 18 ? 16 * (x % 9) : 0
            .next
Div9:       .for i = 0, i < 172, i += 1
            .byte i / 9
            .next


; A = player 1's first pixel: its cells' columns (wrapping round past 39), FbGmAny (any left
; of its graphics split, pixel 19); the tables' index bases
FbCells1:
        tay
        and #3                  ; (the tables' index bases: s x 16, s x 32)
        asl
        asl
        asl
        asl
        sta fbS16
        asl
        sta fbS32
        tya
        lsr
        lsr
        tay
        .for k = 0, k < 9, k += 1
        lda ColMod+k,y
        sta FbCol+k
        .next
        lda #$55                ; (wrapping round: column 0's)
        cpy #32
        bcs +
        lda Left19,y            ; (else any when the first is)
+       sta FbGmAny
        rts
; A = player 0's first pixel: its cells' columns
FbCells0:
        tay
        and #3
        asl
        asl
        asl
        asl
        sta fbS16
        asl
        sta fbS32
        tya
        lsr
        lsr
        tay
        .for k = 0, k < 9, k += 1
        lda ColMod+k,y
        sta FbCol+9+k
        .next
        rts
ColMod:     .for u = 0, u < 48, u += 1      ; (u mod 40)
            .byte u % 40
            .next
; a column's "01" pixels left of pixel 52, 43, 19
Left52:     .for c = 0, c < 40, c += 1
            .byte c <= 12 ? $55 : 0
            .next
Left43:     .for c = 0, c < 40, c += 1
            .byte c <= 9 ? $55 : c == 10 ? $54 : 0
            .next
Left19:     .for c = 0, c < 40, c += 1
            .byte c <= 3 ? $55 : c == 4 ? $54 : 0
            .next

; A = player 1's graphics (shape x 8): rows 8..0's table indexes (j = 0..8)
FbRows1:
        ldy #0
        sty fbOr
        clc
        adc #8
        tax
        ldy #0
-       lda DemonGfx,x
        stx tmp                 ; (player 1 reflected)
        tax
        lda Reverse,x
        ldx tmp
        sta tmp2
        cpy #0                  ; (rows 7..0: their bits)
        beq +
        ora fbOr
        sta fbOr
        lda tmp2
+
        lsr
        lsr
        lsr
        lsr
        ora fbS16
        sta FbHi,y
        lda tmp2
        and #31
        ora fbS32
        sta FbLo,y
        dex
        iny
        cpy #9
        bne -
        rts
; A = player 0's graphics (shape x 8): rows 8..0's table indexes (j = 0..8)
FbRows0:
        ldy #0
        sty fbOr
        clc
        adc #8
        tax
        ldy #0
-       lda DemonGfx,x
        sta tmp2
        cpy #0                  ; (rows 7..0: their bits)
        beq +
        ora fbOr
        sta fbOr
        lda tmp2
+
        lsr
        lsr
        lsr
        lsr
        ora fbS16
        sta FbHi,y
        lda tmp2
        and #31
        ora fbS32
        sta FbLo,y
        dex
        iny
        cpy #9
        bne -
        rts
; player 1's cells' pixels, a row at a time (rows 8..0); which cells have any on the
; band's lines: from all the rows' bits at once (fbOr)
FbLit1:
        ldy #8
-       ldx FbHi,y
        lda FbT0,x
        sta FbLitA+0,y
        lda FbT1,x
        sta FbLitA+9,y
        lda FbT2,x
        sta FbLitA+18,y
        lda FbT3,x
        sta FbLitA+27,y
        ldx FbLo,y
        lda FbT4,x
        sta FbLitA+36,y
        lda FbT5,x
        sta FbLitA+45,y
        lda FbT6,x
        sta FbLitA+54,y
        lda FbT7,x
        sta FbLitA+63,y
        lda FbT8,x
        sta FbLitA+72,y
        dey
        bpl -
        lda fbOr
        lsr
        lsr
        lsr
        lsr
        ora fbS16
        tax
        lda FbT0,x
        sta FbAny+0
        lda FbT1,x
        sta FbAny+1
        lda FbT2,x
        sta FbAny+2
        lda FbT3,x
        sta FbAny+3
        lda fbOr
        and #31
        ora fbS32
        tax
        lda FbT4,x
        sta FbAny+4
        lda FbT5,x
        sta FbAny+5
        lda FbT6,x
        sta FbAny+6
        lda FbT7,x
        sta FbAny+7
        lda FbT8,x
        sta FbAny+8
        rts
; player 0's cells' pixels, a row at a time (rows 7..0); which cells have any on the
; band's lines: from all the rows' bits at once (fbOr)
FbLit0:
        ldy #8
-       ldx FbHi,y
        lda FbT0,x
        sta FbLitA+81,y
        lda FbT1,x
        sta FbLitA+90,y
        lda FbT2,x
        sta FbLitA+99,y
        lda FbT3,x
        sta FbLitA+108,y
        ldx FbLo,y
        lda FbT4,x
        sta FbLitA+117,y
        lda FbT5,x
        sta FbLitA+126,y
        lda FbT6,x
        sta FbLitA+135,y
        lda FbT7,x
        sta FbLitA+144,y
        lda FbT8,x
        sta FbLitA+153,y
        dey
        bne -
        lda fbOr
        lsr
        lsr
        lsr
        lsr
        ora fbS16
        tax
        lda FbT0,x
        sta FbAny+9
        lda FbT1,x
        sta FbAny+10
        lda FbT2,x
        sta FbAny+11
        lda FbT3,x
        sta FbAny+12
        lda fbOr
        and #31
        ora fbS32
        tax
        lda FbT4,x
        sta FbAny+13
        lda FbT5,x
        sta FbAny+14
        lda FbT6,x
        sta FbAny+15
        lda FbT7,x
        sta FbAny+16
        lda FbT8,x
        sta FbAny+17
        rts
; player 1 left of pixel 19: the row above's pixels (line j: j - 1); from the bottom up
FbAbove:
        lda fbCached            ; (ready-made lines: only column 4's cell, part of it left
        beq _all                ; of pixel 19; whole cells read theirs a row up)
        lda #4
        sec
        sbc FbCol
        bcs +
        adc #40
+       cmp #9
        bcc +
        rts
+       tax
        stx tmp4
        lda #$54
        jmp _part
_all    ldx #0
_k      ldy FbCol,x
        lda Left19,y
        bne +
        jmp _nk
+
        stx tmp4
        cmp #$55
        bne _part
        lda fbCached            ; (ready-made lines: the cell reads them a row up instead)
        beq +
        jmp _nk
+       lda FbMul9,x            ; (the whole cell: all of it the row above's)
        tax
        lda FbLitA+7,x
        sta FbLitA+8,x
        lda FbLitA+6,x
        sta FbLitA+7,x
        lda FbLitA+5,x
        sta FbLitA+6,x
        lda FbLitA+4,x
        sta FbLitA+5,x
        lda FbLitA+3,x
        sta FbLitA+4,x
        lda FbLitA+2,x
        sta FbLitA+3,x
        lda FbLitA+1,x
        sta FbLitA+2,x
        lda FbLitA+0,x
        sta FbLitA+1,x
        jmp _any
_part   sta tmp
        lda fbCached            ; (ready-made lines: this cell's into FbLitA first)
        beq +
        txa
        jsr FbFill
        ldx tmp4
+       lda FbMul9,x
        clc
        adc #8
        tay
        lda #8
        sta tmp2
-       lda FbLitA,y
        eor FbLitA-1,y
        and tmp
        eor FbLitA,y
        sta FbLitA,y
        dey
        dec tmp2
        bne -
        lda FbMul9,x
        tax
_any    lda FbLitA+1,x          ; (any now?)
        ora FbLitA+2,x
        ora FbLitA+3,x
        ora FbLitA+4,x
        ora FbLitA+5,x
        ora FbLitA+6,x
        ora FbLitA+7,x
        ora FbLitA+8,x
        ldx tmp4
        sta FbAny,x
        lda fbCached
        bne _rts
_nk     inx
        cpx #9
        beq _rts
        jmp _k
_rts    rts

; the colours of cell X (0-17): "01" x 2 on odd lines, and the other way round for the
; pixels left of the colour split (a whole cell: the even lines instead; part of one: even +
; those pixels, odd - those). (Only the cells in columns 10-12 need it: elsewhere both
; players' pixels have the same colour, put in as the column is written.)
FbColour:
        ldy FbCol,x             ; (the cell's pixels left of its colour split)
        cpx #9
        lda Left52,y
        bcc +
        lda Left43,y
+
        beq +
        cmp #$55
        bne _split
+       and #1                  ; (the lines to double: those of parity 1, or 0 if all
        eor bandL               ; the previous colour; line j = bandL + j - 1)
        and #1
        eor #1                  ; (j = 1 has that parity: start at 1, else at 2)
        clc
        adc FbMul9,x
        adc #1
        stx tmp4
        tax
        asl FbLitA,x
        asl FbLitA+2,x
        asl FbLitA+4,x
        asl FbLitA+6,x
        ldx tmp4
        rts
_split  sta fbCm
        lda FbMul9,x
        clc
        adc #1
        tay                     ; (j = 1)
        lda bandL
        and #1
        sta fbPar
        lda #8
        sta tmp2
-       lda FbLitA,y
        sta fbT
        and fbCm
        sta fbT2
        lda fbPar
        bne _odd
        lda fbT
        clc
        adc fbT2
        jmp _st
_odd    lda fbT
        asl
        sec
        sbc fbT2
_st     sta FbLitA,y
        lda fbPar
        eor #1
        sta fbPar
        iny
        dec tmp2
        bne -
        rts

; player 0's cell X (where player 1 shares its column): the pixels each line leaves
FbKeepCell:
        lda FbMul9+9,x
        tax
        ldy FbLitA+1,x
        lda FbKeepOf,y
        sta FbKeepA-81+1,x
        ldy FbLitA+2,x
        lda FbKeepOf,y
        sta FbKeepA-81+2,x
        ldy FbLitA+3,x
        lda FbKeepOf,y
        sta FbKeepA-81+3,x
        ldy FbLitA+4,x
        lda FbKeepOf,y
        sta FbKeepA-81+4,x
        ldy FbLitA+5,x
        lda FbKeepOf,y
        sta FbKeepA-81+5,x
        ldy FbLitA+6,x
        lda FbKeepOf,y
        sta FbKeepA-81+6,x
        ldy FbLitA+7,x
        lda FbKeepOf,y
        sta FbKeepA-81+7,x
        ldy FbLitA+8,x
        lda FbKeepOf,y
        sta FbKeepA-81+8,x
        rts

; Write the cells, a player's cells at a time (player 1's, then player 0's). Outside columns
; 10-12 both players' pixels have the same colour code (the colour splits are at pixels 43
; and 52): a cell's lines are written as they are, doubled to "10" on the lines that show
; that colour that way. Where both players share a column (K0Ext: player 0's cell there,
; $ff none), or in columns 10-12 (each cell coloured on its own, player 0 in front), the
; lines are put together in FbU first. Nothing else is drawn on the band's lines, so they
; are simply written.
; Each cell has a pair of characters of its own (FBCH + 2 x cell, and the next one for the
; second character row; where both players share a column, player 1's cell's): the band's
; eight lines are eight bytes in a row from line fbL0 of the first. The column's screen
; cells are taken when blank (FatCol: put back by RestoreFat); the pair's other lines are
; cleared when the last band drawn into it had another fbL0 (PairL0). Otherwise (a cell
; already in use, or a row off the screen) the column gets characters as other drawing does
; (GetCell).
FbFlush:
        ldx rbuf                ; (the band this buffer had last: FbFastSet)
        lda FatL0,x
        sta fbPrev
        .for k = 0, k < 9, k += 1  ; player 0's cells with pixels (K0Of)
        ldy #$ff
        lda FbAny+9+k
        beq +
        ldy #k
+       sty K0Of+k
        .next
        lda FbCol               ; player 0's cell in player 1's cell k's column: k + d (fbD9 =
        sec                     ; d + 9; none if they are more than 8 columns apart: 0)
        sbc FbCol+9             ; (d: the columns between them, -20 to 19)
        bpl +
        cmp #-20
        bcs ++
        adc #40
        jmp ++
+       cmp #20
        bcc +
        sbc #40
+       clc
        adc #9
        cmp #18
        bcc +
        lda #0
+       sta fbD9
        lda #0                  ; (the general writers: when first needed, FbGenSet)
        sta fbGen
        lda bandL               ; the character rows: the first's lines (from j = 1)
        sec
        sbc #40
        and #7
        sta fbL0                ; (the band's first line in it)
        asl                     ; the clearing: lines .. to fbL0 - 1 (3 bytes a line)
        adc fbL0
        adc #<FbZ
        sta _z1+1
        sta _z3+1
        lda #>FbZ
        adc #0
        sta _z1+2
        sta _z3+2
        lda #$60
_z1     sta FbZ
        lda fbL0                ; ... and fbL0 + 8 to 15
        asl
        adc fbL0
        adc #<(FbZ+24)
        sta FbColumn._z2+1
        lda #>(FbZ+24)
        adc #0
        sta FbColumn._z2+2
        lda #1                  ; the cells' sources (FbSrc): the bases + 1 - fbL0
        sec
        sbc fbL0
        sta tmp                 ; (-6 .. 1, and its sign extended)
        ldy #0
        tax
        bpl +
        dey
+       sty tmp2
        lda fbCB1
        clc
        adc tmp
        sta fbAdj1
        lda fbCB1+1
        adc tmp2
        sta fbAdj1+1
        lda fbCB1s
        clc
        adc tmp
        sta fbAdj1s
        lda fbCB1s+1
        adc tmp2
        sta fbAdj1s+1
        lda fbCB0
        clc
        adc tmp
        sta fbAdj0
        lda fbCB0+1
        adc tmp2
        sta fbAdj0+1
        lda fbLitA
        clc
        adc tmp
        sta fbAdjL
        lda fbLitA+1
        adc tmp2
        sta fbAdjL+1
        lda #0
        sta fbBad2
        lda bandL
        jsr LineRow
        lda #0
        rol
        sta fbBad1              ; (off the screen)
        lda rowPtr
        sta fbRow1
        lda rowPtr+1
        sta fbRow1+1
        lda fbL0                ; the second's
        bne _row2
        ldx rbuf                ; (one row: the second the same, for FbFast and RestoreFat)
        lda fbRow1
        sta fbRow2
        sta ptrB
        sta FatR2Lo,x
        lda fbRow1+1
        sta fbRow2+1
        sta ptrB+1
        sta FatR2Hi,x
        jmp +
_row2   lda fbBad1              ; (the row below the first: 40 on, unless that's the last)
        bne _lr2
        lda bandL
        cmp #232
        bcs _lr2
        lda rowPtr
        clc
        adc #40
        sta rowPtr
        bcc +
        inc rowPtr+1
+       jmp _r2
_lr2    lda #8
        clc
        adc bandL
        sec
        sbc fbL0
        jsr LineRow
        lda #0
        rol
        sta fbBad2
_r2     lda rowPtr
        sta fbRow2
        sta ptrB
        lda rowPtr+1
        sta fbRow2+1
        sta ptrB+1
        ldx rbuf                ; (the rows the pairs' cells are in, for RestoreFat)
        lda fbRow2
        sta FatR2Lo,x
        lda fbRow2+1
        sta FatR2Hi,x
+       ldx rbuf
        lda fbRow1
        sta FatR1Lo,x
        sta rowPtr
        lda fbRow1+1
        sta FatR1Hi,x
        sta rowPtr+1
        lda fbL0
        sta FatL0,x
        lda Mul18,x             ; (PairL0: this buffer's)
        sta fbPB
        lda Mul18,x
        sta fatI
        lda fbBad1
        ora fbBad2
        sta fbBad
        lda #0                  ; the common case first (FbFast1, FbFast0)
        sta fbFast
        lda fbCached
        beq +
        lda fbBad
        bne +
        inc fbFast
        jsr FbFastSet
        lda fatI                ; (FbRun's record pointers from fatI)
        clc
        adc #<FatCol
        sta FbRunO._qrec+1
        sta FbRunE._qrec+1
        jsr FbFast1
        lda FbRunO._qrec+1      ; (and back)
        sec
        sbc #<FatCol
        sta fatI
+       lda FbAny               ; player 1's cells (those not done; none: on)
        .for k = 1, k < 9, k += 1
        ora FbAny+k
        .next
        bne +
        jmp _p1d
+       ldx #8
_p1     lda FbAny,x
        bne _c1
_n1     dex
        bpl _p1
        jmp _p1d
_c1     stx fbI
        stx fbK1
        stx fbPx
        txa                     ; (player 0's cell there)
        clc
        adc fbD9
        tay
        lda K0Ext,y
        sta fbK0
        ldy FbCol,x
        sty fbCc
        lda FbMul9,x
        tax
        stx fbX1
        lda fbK0
        bmi _alone1
        tay                     ; both: player 0's cell done here
        lda #0
        sta FbAny+9,y
        lda FbMul9,y
        sta fbY0
        tay
        lda fbCc
        jsr FbSplitCol
        bcs +
        lda fbK0                ; (outside columns 10-12: player 0's lines ORed in as they
        adc #9                  ; are copied; carry clear)
        sta fbQ
+       jsr FbColumn
        lda #$ff
        sta fbQ
        jmp _nx1
_alone1 lda #81
        sta fbY0
        tay
        lda fbCc
        jsr FbSplitCol
        jsr FbColumn
_nx1    ldx fbI
        dex
        bpl _p1
_p1d    ; player 0's cells (those not done)
        lda fbFast
        beq +
        lda fatI                ; (FbRun's record pointers from fatI)
        clc
        adc #<FatCol
        sta FbRunO._qrec+1
        sta FbRunE._qrec+1
        jsr FbFast0
        lda FbRunO._qrec+1      ; (and back)
        sec
        sbc #<FatCol
        sta fatI
+       lda FbAny+9             ; (none left: on)
        .for k = 1, k < 9, k += 1
        ora FbAny+9+k
        .next
        bne +
        jmp _p0d
+       lda #$ff
        sta fbK1
        lda #162
        sta fbX1
        ldx #8
_p0     lda FbAny+9,x
        bne _c0
_n0     dex
        bpl _p0
        jmp _p0d
_c0     stx fbI
        stx fbK0
        txa
        clc
        adc #9
        sta fbPx
        ldy FbCol+9,x
        sty fbCc
        lda FbMul9,x
        sta fbY0
        tay
        clc
        adc #81
        tax
        lda fbCc
        jsr FbSplitCol
        jsr FbColumn
        ldx fbI
        dex
        bpl _p0
_p0d    ldx rbuf
        lda fatI
        sec
        sbc Mul18,x
        sta FatN,x
        lda fbGen
        beq +
        lda #$b1                ; (lda (zp),y: the general row 2 writer as it was)
_w2b    sta FbW2
+       lda #$91                ; (sta (zp),y)
_z3     sta FbZ
        rts

; the general writers (FbColumn's _gen), once a band when first needed: row 1 from line fbL0
; to 7, row 2 from 0 to fbL0 - 1 (5 bytes a line), and their sources: row 1 line y = FbU +
; 1 + y - fbL0, row 2's = FbU + 9 + y - fbL0
FbGenSet:
        inc fbGen
        lda fbL0
        asl
        asl
        adc fbL0
        sta tmp
        adc #<FbW1
        sta FbColumn._w1+1
        lda #>FbW1
        adc #0
        sta FbColumn._w1+2
        lda tmp
        clc
        adc #<FbW2
        sta _w2a+1
        sta FbFlush._w2b+1
        lda #>FbW2
        adc #0
        sta _w2a+2
        sta FbFlush._w2b+2
        lda #$60                ; (rts)
_w2a    sta FbW2
        lda #<(FbU+1)
        sec
        sbc fbL0
        sta fbS1
        lda #>(FbU+1)
        sbc #0
        sta fbS1+1
        lda #<(FbU+9)
        sec
        sbc fbL0
        sta fbS2
        lda #>(FbU+9)
        sbc #0
        sta fbS2+1
        rts

; A = column: in columns 10-12 put the lines together in FbU, coloured (X = 171, fbOdd 2:
; as written); else fbOdd = 1 ("10" on odd j) or 0 (on even j). -> carry set: FbU done
FbSplitCol:
        cmp #10
        bcc _left
        cmp #13
        bcs _right
        jsr FbBuildS
        ldx #171
        lda #2
        sta fbOdd
        sec
        rts
_left   lda #1                  ; (left of both splits: the previous line's colour)
        .byte $2c
_right  lda #0
        eor bandL
        and #1
        sta fbOdd
        clc
        rts

; One column (fbCc): its lines from FbLitA + X + 1-8 (fbOdd: which to double), into its
; pair if its cells are free, else as other drawing does
FbColumn:
        stx fbSrc
        lda fbBad
        bne _g
        ldy fbCc
        lda (rowPtr),y
        ora (ptrB),y            ; (one row: ptrB = rowPtr)
        beq +
_g      jmp _gen
+       ldx fbPx                ; the cell's pair: the second's character,
        lda PairCh1,x
        sta (ptrB),y
        eor #1                  ; the first's
        sta (rowPtr),y
        ldx fatI                ; (for RestoreFat)
        tya
        sta FatCol,x
        inc fatI
        ldx fbPx
        lda PairLo,x            ; its data
        sta ptrC
        ora fbL0
        sta dstPtr
        lda PairHi,x
        ora chrHi
        sta ptrC+1
        sta dstPtr+1
        txa                     ; the pair's other lines clear: of the lines last drawn
        clc                     ; (from p = PairL0, $ff: not known) those not drawn now
        adc fbPB
        tax
        lda PairL0,x
        cmp fbL0
        beq _clean
        tay
        lda fbL0
        sta PairL0,x
        cpy #8
        bcs _all
        cpy fbL0
        bcs _below
        tya                     ; p < fbL0: lines p to fbL0 - 1
        asl
        sty tmp
        adc tmp
        adc #<FbZ
        sta _z4+1
        lda #>FbZ
        adc #0
        sta _z4+2
        lda #0
_z4     jsr FbZ
        jmp _clean
_all    lda #0                  ; (lines 0 to fbL0 - 1, then)
        tay
        jsr FbZ
_below  lda fbL0                ; lines fbL0 + 8 to 15
        clc
        adc #8
        tay
        lda #0
_z2     jsr FbZ
_clean  ldx fbQ                 ; its lines (from line fbL0 of the pair: (srcP),Y with Y =
        bmi _one                ; fbL0 + j - 1); player 0's too where both are (fbQ: its
        jsr FbSrc               ; cell; into ptrB for the copy)
        lda srcP
        sta ptrB
        lda srcP+1
        sta ptrB+1
        ldx fbSrc
        lda Div9,x
        tax
        jsr FbSrc
        ldy fbL0
        lda fbOdd
        bne +
        jsr FbCopyE2
        jmp ++
+       jsr FbCopyO2
+       lda fbRow2              ; (ptrB: the second row again)
        sta ptrB
        lda fbRow2+1
        sta ptrB+1
        rts
_one    ldx fbSrc
        lda Div9,x
        tax
        jsr FbSrc
        ldy fbL0
        lda fbOdd
        beq +
        cmp #1
        beq ++
        jmp FbCopy
+       jmp FbCopyE
+       jmp FbCopyO
_gen    lda fbGen               ; as other drawing does: the lines in FbU
        bne +
        jsr FbGenSet
+       lda fbOdd
        cmp #2
        beq _write
        ldx fbX1
        ldy fbY0
        jsr FbFillXY
        lda fbOdd
        lsr
        bcc +
        jsr FbBuildO
        jmp _write
+       jsr FbBuildE
_write  lda fbBad1
        bne +
        lda fbRow1
        sta rowPtr
        lda fbRow1+1
        sta rowPtr+1
        lda fbCc
        jsr GetCell
        bcs +
        lda fbS1
        sta ptrB
        lda fbS1+1
        sta ptrB+1
        ldy fbL0
_w1     jsr FbW1
+       lda fbL0
        beq _back
        lda fbBad2
        bne _back
        lda fbRow2
        sta rowPtr
        lda fbRow2+1
        sta rowPtr+1
        lda fbCc
        jsr GetCell
        bcs _back
        lda fbS2
        sta ptrB
        lda fbS2+1
        sta ptrB+1
        ldy #0
        jsr FbW2
_back   lda fbRow1              ; (the rows' pointers back)
        sta rowPtr
        lda fbRow1+1
        sta rowPtr+1
        lda fbRow2
        sta ptrB
        lda fbRow2+1
        sta ptrB+1
        rts
; The common case, before the exact loops (shapes 1-4, both character rows on the screen): a
; player's cells alone in their columns (player 1: not where player 0 has pixels, nor at
; column 4, its graphics split; player 0: not at column 10, its colour split; neither
; wrapping round past column 39) whose two screen cells are blank: taken, recorded, the
; pair's other lines cleared and the ready-made lines copied in, a run of cells at a time
; (FbRange); the cells done get FbAny 0. The pairs of a player's columns are 16 bytes apart,
; as its cells' ready-made lines are: one pointer each (ptrC, srcP) for all of them, line
; fbL0 + j - 1 of cell k at Y = 16k + fbL0 + j - 1 (FbT).
FbFast1:
        ldy FbCol
        lda #9                  ; (wrapping round past column 39: cells to column 39 first)
        cpy #32
        bcc +
        lda #40
        sec
        sbc FbCol
+       sta fbKw
        lda PairLo              ; (its cells' pairs)
        sta ptrC
        lda PairHi
        ora chrHi
        sta ptrC+1
        lda #<K0Ext             ; (player 0's cell in the same column: K0Ext + fbD9 + k)
        clc
        adc fbD9
        sta FbRunO._qck+1
        sta FbRunE._qck+1
        lda #>K0Ext
        adc #0
        sta FbRunO._qck+2
        sta FbRunE._qck+2
        ldx fbD9                ; (where both are: player 0's lines through ptrA, its cell 16d
        beq +                   ; bytes on, at the same Y: fbAdj0 + 16 (fbD9 - 9); its FbAny
        lda fbAdj0
        clc                     ; at FbAny + fbD9 + k)
        adc D16Lo,x
        sta ptrA
        lda fbAdj0+1
        adc D16Hi,x
        sta ptrA+1
        txa
        clc
        adc #<FbAny
        sta FbRunO._qso+1
        sta FbRunE._qso+1
        lda #>FbAny
        adc #0
        sta FbRunO._qso+2
        sta FbRunE._qso+2
+       lda #0
        sta fbKf
        lda #4                  ; columns 0-3: a row up's lines
        sec
        sbc FbCol
        bcc _l                  ; (from column 5 on)
        beq _c4
        ldx fbAdj1s
        stx srcP
        ldx fbAdj1s+1
        stx srcP+1
        ldy #0
        jsr FbRange
_c4     inc fbKf                ; (column 4: the exact way)
_l      lda fbAdj1
        sta srcP
        lda fbAdj1+1
        sta srcP+1
        lda #13                 ; columns to 12: left of the colour split
        sec
        sbc FbCol
        bcc _r
        cmp #9
        bcc +
        lda #9
+       ldy #0
        jsr FbRange
_r      lda fbKw
        ldy #1
        jsr FbRange
        lda fbKw                ; the cells from column 0 on
        cmp #9
        bcs _rts
        sta fbKf
        lda fbAdj1s             ; columns 0-3: a row up's lines
        sta srcP
        lda fbAdj1s+1
        sta srcP+1
        lda #44
        sec
        sbc FbCol
        cmp #9
        bcc +
        lda #9
+       ldy #0
        jsr FbRange
        inc fbKf                ; (column 4: the exact way)
        lda fbAdj1
        sta srcP
        lda fbAdj1+1
        sta srcP+1
        lda #9
        ldy #0
        jmp FbRange
_rts    rts
FbFast0:
        lda PairLo+9            ; (its cells' pairs)
        sta ptrC
        lda PairHi+9
        ora chrHi
        sta ptrC+1
        lda #<(K0Ext-9)         ; (player 1's cells where both are: done by now; X = 9 + k:
        sta FbRunO._qck+1       ; K0Ext's first 9, none)
        sta FbRunE._qck+1
        lda #>(K0Ext-9)
        sta FbRunO._qck+2
        sta FbRunE._qck+2
        lda fbAdj0
        sta srcP
        lda fbAdj0+1
        sta srcP+1
        lda #9
        sta fbKf
        lda FbCol+9
        cmp #32
        bcs _wrap
        lda #10                 ; column 10's cell (9 + 10 - first column)
        sec
        sbc FbCol+9
        bcc _r                  ; (from column 11 on)
        adc #9-1                ; (carry set)
        pha
        cmp #18
        bcc +
        lda #18
+       ldy #0                  ; to column 9: left of the colour split
        jsr FbRange
        pla
        clc
        adc #1
        sta fbKf
_r      lda #18
        ldy #1
        jmp FbRange
_wrap   lda #9+40               ; wrapping round past column 39: to there right of the
        sec                     ; colour split, from column 0 on left of it
        sbc FbCol+9
        ldy #1
        jsr FbRange
        lda #18
        ldy #0
        jmp FbRange

; cells fbKf to A - 1 (none if A <= fbKf; then fbKf = A) from srcP; Y: 0 left of the colour
; split ("10" on the lines of the other parity than bandL's), 1 right
FbRange:
        cmp fbKf
        beq _none
        bcc _none
        ldx fbKf
        sta fbKf
        clv                     ; (FbRun: V set only for a shared cell)
        tya
        eor bandL
        lsr
        bcs _e
        lda fbKf
        sta FbRunO._qend+1
        jsr FbRunO._k
        lda FbRunO._qrec+1      ; (the other's record pointer the same)
        sta FbRunE._qrec+1
_none   rts
_e      lda fbKf
        sta FbRunE._qend+1
        jsr FbRunE._k
        lda FbRunE._qrec+1
        sta FbRunO._qrec+1
        rts
        .cerror (>FatCol) != (>(FatCol + 2 * 18 - 1)), "FatCol must be in one page (FbRun)"
        .cerror (>PairL0) != (>(PairL0 + 2 * 18 - 1)), "PairL0 must be in one page (FbFastSet)"
        .cerror (>PairL0) != (>(PairL0 + 2 * 18 - 1)), "PairL0 must be in one page (FbFastSet)"

; X = first cell, _qend the end, ptrC / srcP: its player's first pair and cell; odd: "10" on
; odd j (else even)
FbRun   .macro odd
_sh     cpy #10                 ; player 0's pixels there too (columns 10-12: the exact way):
        bcc +                   ; its cell done here, V set (the copy ORs its lines in)
        cpy #13
        bcc _n
+       lda #0
_qso    sta FbAny,x             ; (player 0's cell: FbAny + fbD9 + X)
        bit FbV40
        jmp _tk
_done   rts
_sc     php                     ; (the pair's last lines not the usual ones)
        jsr FbFastSC
        plp
        jmp _zend
_n      inx
_qend   cpx #0
        beq _done
_k      lda FbAny,x
        beq _n
        ldy FbCol,x
        lda (rowPtr),y          ; both screen cells blank (one row: ptrB = rowPtr)
        ora (ptrB),y
        bne _n
_qck    lda K0Ext,x
        bpl _sh
_tk     lda PairCh1,x           ; taken (the cell's pair)
        sta (ptrB),y
        eor #1
        sta (rowPtr),y
_qrec   sty FatCol              ; (for RestoreFat)
        inc _qrec+1
_qpl    lda PairL0,x            ; the pair's lines last drawn: the usual ones?
_qcp    cmp #0
        bne _sc
_ql1    lda #0                  ; (fbL0)
_qpl3   sta PairL0,x
        lda #0
        sta FbAny,x
_qzf    ldy FbT,x               ; their lines not drawn now cleared
_qzj    jmp _zend
        .rept 7
        sta (ptrC),y
        iny
        .endrept
_zend
_qly    ldy FbT,x               ; the cell's lines
        bvs _or
        .for j = 1, j <= 8, j += 1
        lda (srcP),y
        .if (j & 1) == \odd
        asl
        .endif
        sta (ptrC),y
        .if j < 8
        iny
        .endif
        .next
        jmp _n
_or     .for j = 1, j <= 8, j += 1  ; (and player 0's, ptrA: its cell at the same Y)
        lda (srcP),y
        ora (ptrA),y
        .if (j & 1) == \odd
        asl
        .endif
        sta (ptrC),y
        .if j < 8
        iny
        .endif
        .next
        clv                     ; (V clear again: FbRange clears it first)
        jmp _n
        .endm
FbRunO  .FbRun 1
FbRunE  .FbRun 0

; FbRun's other clearing (A = the line its pair was last drawn from, X = cell):
; the pair's lines but the band's
FbFastSC:
        cmp fbL0
        beq _done
        sta tmp
        lda fbL0
_qpl    sta PairL0,x
        lda tmp
        cmp #8
        bcs _all                ; (not known)
        cmp fbL0
        bcs _below
        asl                     ; p < fbL0: lines p to fbL0 - 1 (to FbFlush's rts)
        adc tmp
        adc #<FbZ
        sta _qzp+1
        lda #>FbZ
        adc #0
        sta _qzp+2
        lda tmp
        clc
        adc FbT,x
        tay
        lda #0
_qzp    jsr FbZ
        jmp _done
_all    ldy FbT,x               ; (16k: lines 0 to fbL0 - 1)
        lda #0
        jsr FbZ
_below
_qy8    ldy FbT,x               ; (16k + fbL0 + 8: lines to 15)
        lda #0
_qz5    jsr FbZ
_done   lda #0
        sta FbAny,x
        rts

; FbRun's values for this picture: fbL0, this buffer's PairL0, the usual clearing (pairs last
; drawn with fbPrev, the band this buffer had last: the lines that window had and this hasn't)
FbFastSet:
        ldx fbL0
        lda FbTLo,x
        sta FbRunO._qly+1
        sta FbRunE._qly+1
        lda FbTHi,x
        sta FbRunO._qly+2
        sta FbRunE._qly+2
        lda FbTLo+8,x
        sta FbFastSC._qy8+1
        lda FbTHi+8,x
        sta FbFastSC._qy8+2
        txa
        sta FbRunO._ql1+1
        sta FbRunE._ql1+1
        clc                     ; (FbZ + 3 (fbL0 + 8))
        adc #8
        sta tmp
        asl
        adc tmp
        adc #<FbZ
        sta FbFastSC._qz5+1
        lda #>FbZ
        adc #0
        sta FbFastSC._qz5+2
        lda #<PairL0
        ldx rbuf
        clc
        adc Mul18,x             ; (PairL0 in one page: the low byte)
        sta FbRunO._qpl+1
        sta FbRunO._qpl3+1
        sta FbRunE._qpl+1
        sta FbRunE._qpl3+1
        sta FbFastSC._qpl+1
        lda fbPrev
        cmp #8
        bcs _none
        sta FbRunO._qcp+1
        sta FbRunE._qcp+1
        sec
        sbc fbL0
        beq _none
        bcs _down
        eor #$ff                ; fbPrev < fbL0: lines fbPrev to fbL0 - 1 (carry clear)
        adc #1
        ldx fbPrev
        jmp _set
_down   tay                     ; fbPrev > fbL0: lines fbL0 + 8 to fbPrev + 7
        lda fbL0
        adc #8-1                ; (carry set)
        tax
        tya
        jmp _set
_none   lda fbL0                ; (none usual: those drawn with fbL0, nothing)
        sta FbRunO._qcp+1
        sta FbRunE._qcp+1
        lda #0
        tax
_set    sta tmp                 ; A lines from line X
        asl
        adc tmp
        sta tmp
        lda #<FbRunO._zend
        sec
        sbc tmp
        sta FbRunO._qzj+1
        lda #>FbRunO._zend
        sbc #0
        sta FbRunO._qzj+2
        lda #<FbRunE._zend
        sec
        sbc tmp
        sta FbRunE._qzj+1
        lda #>FbRunE._zend
        sbc #0
        sta FbRunE._qzj+2
        lda FbTLo,x
        sta FbRunO._qzf+1
        sta FbRunE._qzf+1
        lda FbTHi,x
        sta FbRunO._qzf+2
        sta FbRunE._qzf+2
        rts
FbV40:      .byte $40              ; (FbRun: bit sets V)
D16Lo:      .for i = 0, i < 18, i += 1      ; 16 (i - 9)
            .byte <(16 * (i - 9))
            .next
D16Hi:      .for i = 0, i < 18, i += 1
            .byte >(16 * (i - 9))
            .next
; FbRun's Y: line l of cell x's pair at FbT + 18l + x
FbT:        .for l = 0, l < 16, l += 1
            .for x = 0, x < 18, x += 1
            .byte 16 * (x % 9) + l
            .next
            .next
FbTLo:      .for l = 0, l < 16, l += 1
            .byte <(FbT + 18 * l)
            .next
FbTHi:      .for l = 0, l < 16, l += 1
            .byte >(FbT + 18 * l)
            .next

; each cell's pair: its second character (the first: - 1), and the first's data
PairCh1:    .for x = 0, x < 18, x += 1
            .byte FBCH + 2 * x + 1
            .next
PairLo:     .for x = 0, x < 18, x += 1
            .byte <(8 * (FBCH + 2 * x))
            .next
PairHi:     .for x = 0, x < 18, x += 1
            .byte >(8 * (FBCH + 2 * x))
            .next

; Put blank back into the cells the pairs took when this buffer was last drawn
RestoreFat:
        ldx rbuf
        lda FatN,x
        bne +
        rts
+       clc
        adc Mul18,x
        sta _qre+1
        lda #0
        sta FatN,x
        lda FatR1Lo,x
        sta rowPtr
        lda FatR1Hi,x
        sta rowPtr+1
        lda FatR2Lo,x           ; (one row: the same)
        sta ptrC
        lda FatR2Hi,x
        sta ptrC+1
        lda Mul18,x
        tax
        lda #0
-       ldy FatCol,x
        sta (rowPtr),y
        sta (ptrC),y
        inx
_qre    cpx #0
        bne -
        rts
Mul18:      .byte 0, 18

; a column's lines in its pair (ptrC), lines Y = fbL0 on, from (srcP),Y (FbSrc);
; FbCopyO doubles odd j, FbCopyE even j, FbCopy none (FbU: already coloured)
FbCopyO:
        .for j = 1, j <= 8, j += 1
        lda (srcP),y
        .if j & 1
        asl
        .endif
        sta (ptrC),y
        .if j < 8
        iny
        .endif
        .next
        rts
FbCopyE:
        .for j = 1, j <= 8, j += 1
        lda (srcP),y
        .if (j & 1) == 0
        asl
        .endif
        sta (ptrC),y
        .if j < 8
        iny
        .endif
        .next
        rts
FbCopyO2:                       ; (and (ptrB),Y ORed in)
        .for j = 1, j <= 8, j += 1
        lda (srcP),y
        ora (ptrB),y
        .if j & 1
        asl
        .endif
        sta (ptrC),y
        .if j < 8
        iny
        .endif
        .next
        rts
FbCopyE2:
        .for j = 1, j <= 8, j += 1
        lda (srcP),y
        ora (ptrB),y
        .if (j & 1) == 0
        asl
        .endif
        sta (ptrC),y
        .if j < 8
        iny
        .endif
        .next
        rts
FbCopy:
        .for j = 1, j <= 8, j += 1
        lda (srcP),y
        sta (ptrC),y
        .if j < 8
        iny
        .endif
        .next
        rts
; clearing a pair's lines from (ptrC): from line Y to the rts FbFlush puts in, or to 15
FbZ:
        .for y = 0, y < 16, y += 1
        sta (ptrC),y
        iny
        .next
        rts

; a column's lines where both players are (X: player 1's cell's lines, Y: player 0's, each
; from FbLitA + 9k), "10" on odd j (fbOdd 1) or even j
FbBuild:
        jsr FbFillXY
        lda fbOdd
        beq +
        jmp FbBuildO
+       jmp FbBuildE

; a column's lines (X: player 1's cell's lines, Y: player 0's, each from FbLitA + 9k; 162 /
; 81: none), "10" on odd j (FbBuildO) or even j (FbBuildE)
FbBuildO:
        .for j = 1, j <= 8, j += 1
        lda FbLitA+j,x
        ora FbLitA+81+j,y
        .if j & 1
        asl
        .endif
        sta FbU+j
        .next
        rts
FbBuildE:
        .for j = 1, j <= 8, j += 1
        lda FbLitA+j,x
        ora FbLitA+81+j,y
        .if (j & 1) == 0
        asl
        .endif
        sta FbU+j
        .next
        rts
; columns 10-12: the cells coloured, player 0 in front where player 1 is too (FbKeepA + 81:
; all kept)
FbBuildS:
        lda fbCached
        beq +
        jmp FbBuildSC
+       jsr FbFillXY
        stx fbX1
        sty fbY0
        ldx fbK1
        bmi +
        jsr FbColour
+       lda fbK0
        bmi +
        clc
        adc #9
        tax
        jsr FbColour
        lda fbK1
        bmi +
        ldx fbK0
        jsr FbKeepCell
+       ldx fbX1
        ldy fbY0
        .for j = 1, j <= 8, j += 1
        lda FbLitA+j,x
        and FbKeepA+j,y
        ora FbLitA+81+j,y
        sta FbU+j
        .next
        rts
; FbBuildS from the ready-made lines (fbCc: the column; X, Y kept): line j's colours from
; its parity (fbPar: bandL + j - 1): even, v + (v & m), odd, 2v - (v & m), m the pixels left
; of the colour split (player 1 in columns 10-12: all; player 0: Left43); player 0 in front
FbBuildSC:
        stx fbX1
        sty fbY0
        lda #<FbZero            ; player 1's lines (srcP; none: blank)
        sta srcP
        lda #>FbZero
        sta srcP+1
        ldx fbK1
        bmi +
        lda FbMul16,x
        clc
        adc fbCB1
        sta srcP
        lda fbCB1+1
        adc #0
        sta srcP+1
+       lda #<FbZero            ; player 0's (ptrA)
        sta ptrA
        lda #>FbZero
        sta ptrA+1
        ldx fbK0
        bmi +
        lda FbMul16,x
        clc
        adc fbCB0
        sta ptrA
        lda fbCB0+1
        adc #0
        sta ptrA+1
+       ldy fbCc
        lda Left43,y
        sta fbCm
        lda bandL
        and #1
        sta fbPar
        ldy #1
_j      lda (ptrA),y            ; player 0's line: v
        sta fbT
        and fbCm
        sta fbT2
        lda fbPar
        bne _o
        lda fbT                 ; (even: v + (v & m); player 1's doubled)
        clc
        adc fbT2
        tax
        lda (srcP),y
        asl
        jmp _k
_o      lda fbT                 ; (odd: 2v - (v & m); player 1's as it is)
        asl
        sec
        sbc fbT2
        tax
        lda (srcP),y
_k      and FbKeepOf,x          ; (player 0 in front)
        sta fbT
        txa
        ora fbT
        sta FbU,y
        lda fbPar
        eor #1
        sta fbPar
        iny
        cpy #9
        bne _j
        ldx fbX1
        ldy fbY0
        rts
; the writers: line y of the character from (ptrB),y, from line Y on (FbW1: to 7; FbW2: to
; fbL0 - 1, where FbFlush puts an rts)
FbW1:
        .for y = 0, y < 8, y += 1
        lda (ptrB),y
        sta (dstPtr),y
        iny
        .next
        rts
FbW2:
        .for y = 0, y < 8, y += 1
        lda (ptrB),y
        sta (dstPtr),y
        iny
        .next
        rts
FbMul9:     .byte 0, 9, 18, 27, 36, 45, 54, 63, 72, 81, 90, 99, 108, 117, 126, 135, 144, 153, 162, 171
FbZero:     .fill 9, 0
FbOnes:     .fill 9, $ff
FbT0:       .byte $00, $00, $00, $00, $00, $00, $00, $00, $55, $55, $55, $55, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $00, $00, $00, $00, $15, $15, $15, $15, $15, $15, $15, $15
            .byte $00, $00, $00, $00, $00, $00, $00, $00, $05, $05, $05, $05, $05, $05, $05, $05
            .byte $00, $00, $00, $00, $00, $00, $00, $00, $01, $01, $01, $01, $01, $01, $01, $01
FbT1:       .byte $00, $00, $00, $00, $55, $55, $55, $55, $00, $00, $00, $00, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $15, $15, $15, $15, $40, $40, $40, $40, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $05, $05, $05, $05, $50, $50, $50, $50, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $01, $01, $01, $01, $54, $54, $54, $54, $55, $55, $55, $55
FbT2:       .byte $00, $00, $55, $55, $00, $00, $55, $55, $00, $00, $55, $55, $00, $00, $55, $55
            .byte $00, $00, $15, $15, $40, $40, $55, $55, $00, $00, $15, $15, $40, $40, $55, $55
            .byte $00, $00, $05, $05, $50, $50, $55, $55, $00, $00, $05, $05, $50, $50, $55, $55
            .byte $00, $00, $01, $01, $54, $54, $55, $55, $00, $00, $01, $01, $54, $54, $55, $55
FbT3:       .byte $00, $55, $00, $55, $00, $55, $00, $55, $00, $55, $00, $55, $00, $55, $00, $55
            .byte $00, $15, $40, $55, $00, $15, $40, $55, $00, $15, $40, $55, $00, $15, $40, $55
            .byte $00, $05, $50, $55, $00, $05, $50, $55, $00, $05, $50, $55, $00, $05, $50, $55
            .byte $00, $01, $54, $55, $00, $01, $54, $55, $00, $01, $54, $55, $00, $01, $54, $55
FbT4:       .byte $00, $00, $00, $00, $00, $00, $00, $00, $55, $55, $55, $55, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $00, $00, $00, $00, $55, $55, $55, $55, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $00, $00, $00, $00, $15, $15, $15, $15, $15, $15, $15, $15
            .byte $40, $40, $40, $40, $40, $40, $40, $40, $55, $55, $55, $55, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $00, $00, $00, $00, $05, $05, $05, $05, $05, $05, $05, $05
            .byte $50, $50, $50, $50, $50, $50, $50, $50, $55, $55, $55, $55, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $00, $00, $00, $00, $01, $01, $01, $01, $01, $01, $01, $01
            .byte $54, $54, $54, $54, $54, $54, $54, $54, $55, $55, $55, $55, $55, $55, $55, $55
FbT5:       .byte $00, $00, $00, $00, $55, $55, $55, $55, $00, $00, $00, $00, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $55, $55, $55, $55, $00, $00, $00, $00, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $15, $15, $15, $15, $40, $40, $40, $40, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $15, $15, $15, $15, $40, $40, $40, $40, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $05, $05, $05, $05, $50, $50, $50, $50, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $05, $05, $05, $05, $50, $50, $50, $50, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $01, $01, $01, $01, $54, $54, $54, $54, $55, $55, $55, $55
            .byte $00, $00, $00, $00, $01, $01, $01, $01, $54, $54, $54, $54, $55, $55, $55, $55
FbT6:       .byte $00, $00, $55, $55, $00, $00, $55, $55, $00, $00, $55, $55, $00, $00, $55, $55
            .byte $00, $00, $55, $55, $00, $00, $55, $55, $00, $00, $55, $55, $00, $00, $55, $55
            .byte $00, $00, $15, $15, $40, $40, $55, $55, $00, $00, $15, $15, $40, $40, $55, $55
            .byte $00, $00, $15, $15, $40, $40, $55, $55, $00, $00, $15, $15, $40, $40, $55, $55
            .byte $00, $00, $05, $05, $50, $50, $55, $55, $00, $00, $05, $05, $50, $50, $55, $55
            .byte $00, $00, $05, $05, $50, $50, $55, $55, $00, $00, $05, $05, $50, $50, $55, $55
            .byte $00, $00, $01, $01, $54, $54, $55, $55, $00, $00, $01, $01, $54, $54, $55, $55
            .byte $00, $00, $01, $01, $54, $54, $55, $55, $00, $00, $01, $01, $54, $54, $55, $55
FbT7:       .byte $00, $55, $00, $55, $00, $55, $00, $55, $00, $55, $00, $55, $00, $55, $00, $55
            .byte $00, $55, $00, $55, $00, $55, $00, $55, $00, $55, $00, $55, $00, $55, $00, $55
            .byte $00, $15, $40, $55, $00, $15, $40, $55, $00, $15, $40, $55, $00, $15, $40, $55
            .byte $00, $15, $40, $55, $00, $15, $40, $55, $00, $15, $40, $55, $00, $15, $40, $55
            .byte $00, $05, $50, $55, $00, $05, $50, $55, $00, $05, $50, $55, $00, $05, $50, $55
            .byte $00, $05, $50, $55, $00, $05, $50, $55, $00, $05, $50, $55, $00, $05, $50, $55
            .byte $00, $01, $54, $55, $00, $01, $54, $55, $00, $01, $54, $55, $00, $01, $54, $55
            .byte $00, $01, $54, $55, $00, $01, $54, $55, $00, $01, $54, $55, $00, $01, $54, $55
FbT8:       .byte $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00
            .byte $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00, $00
            .byte $00, $40, $00, $40, $00, $40, $00, $40, $00, $40, $00, $40, $00, $40, $00, $40
            .byte $00, $40, $00, $40, $00, $40, $00, $40, $00, $40, $00, $40, $00, $40, $00, $40
            .byte $00, $50, $00, $50, $00, $50, $00, $50, $00, $50, $00, $50, $00, $50, $00, $50
            .byte $00, $50, $00, $50, $00, $50, $00, $50, $00, $50, $00, $50, $00, $50, $00, $50
            .byte $00, $54, $00, $54, $00, $54, $00, $54, $00, $54, $00, $54, $00, $54, $00, $54
            .byte $00, $54, $00, $54, $00, $54, $00, $54, $00, $54, $00, $54, $00, $54, $00, $54
; a cell line with player 0's colours v: the pixels it doesn't cover
FbKeepOf:   .byte $ff, $fc, $fc, $fc, $f3, $f0, $f0, $f0, $f3, $f0, $f0, $f0, $f3, $f0, $f0, $f0
            .byte $cf, $cc, $cc, $cc, $c3, $c0, $c0, $c0, $c3, $c0, $c0, $c0, $c3, $c0, $c0, $c0
            .byte $cf, $cc, $cc, $cc, $c3, $c0, $c0, $c0, $c3, $c0, $c0, $c0, $c3, $c0, $c0, $c0
            .byte $cf, $cc, $cc, $cc, $c3, $c0, $c0, $c0, $c3, $c0, $c0, $c0, $c3, $c0, $c0, $c0
            .byte $3f, $3c, $3c, $3c, $33, $30, $30, $30, $33, $30, $30, $30, $33, $30, $30, $30
            .byte $0f, $0c, $0c, $0c, $03, $00, $00, $00, $03, $00, $00, $00, $03, $00, $00, $00
            .byte $0f, $0c, $0c, $0c, $03, $00, $00, $00, $03, $00, $00, $00, $03, $00, $00, $00
            .byte $0f, $0c, $0c, $0c, $03, $00, $00, $00, $03, $00, $00, $00, $03, $00, $00, $00
            .byte $3f, $3c, $3c, $3c, $33, $30, $30, $30, $33, $30, $30, $30, $33, $30, $30, $30
            .byte $0f, $0c, $0c, $0c, $03, $00, $00, $00, $03, $00, $00, $00, $03, $00, $00, $00
            .byte $0f, $0c, $0c, $0c, $03, $00, $00, $00, $03, $00, $00, $00, $03, $00, $00, $00
            .byte $0f, $0c, $0c, $0c, $03, $00, $00, $00, $03, $00, $00, $00, $03, $00, $00, $00
            .byte $3f, $3c, $3c, $3c, $33, $30, $30, $30, $33, $30, $30, $30, $33, $30, $30, $30
            .byte $0f, $0c, $0c, $0c, $03, $00, $00, $00, $03, $00, $00, $00, $03, $00, $00, $00
            .byte $0f, $0c, $0c, $0c, $03, $00, $00, $00, $03, $00, $00, $00, $03, $00, $00, $00
            .byte $0f, $0c, $0c, $0c, $03, $00, $00, $00, $03, $00, $00, $00, $03, $00, $00, $00

; ------------------------------------------------------------- demon bands as characters
; Any band, the long way: each line's pixels for player 1 then player 0 (in front), each
; split into this line's colour and the previous line's.
SlowBand:
        ldx band
        lda bSh,x               ; (normal width: SmallBand)
        bne +
        jmp SmallBand
+       lda #4                  ; bytes per player: 4 (each bit four pixels)
        sta plN
        lda bX0,x               ; player 0's pixels left of 43 (previous colour)
        ldy bW,x
        ldx #43
        jsr SplitN
        ldx #3
-       lda sm,x
        sta sp0,x
        dex
        bpl -
        ldx band
        lda bX1,x               ; player 1's left of 52
        ldy bW,x
        ldx #52
        jsr SplitN
        ldx #3
-       lda sm,x
        sta sp1,x
        dex
        bpl -
        ldx band
        lda bX1,x               ; and left of 19 (the line above's graphics): stays in sm
        ldy bW,x
        ldx #19
        jsr SplitN
        ldx band
        lda bP0,x
        ora #7
        sta bandG
        lda bP1,x
        ora #7
        sta bandG1
        lda #8
        sta bandN
        lda #0
        sta prev1b
_line   lda bandL
        sta plL
        jsr LineRow
        bcc +
        jmp _next
+       ldy bandG1              ; player 1: this row (pixel order) ...
        ldx DemonGfx,y
        lda Reverse,x
        sta tmp
        ldx band
        ldy bSh,x
        bne _wide
        eor prev1b              ; ... or the line above's left of pixel 19
        and sm
        eor tmp
        ldy #0
        jsr ExpandB
        jmp +
_wide   jsr ExpandB             ; (wide: the same on the expanded pixels)
        jsr WideP1
+       ldx band
        lda bX1,x
        sta plX
        lda #4
        jsr SplitCodes
        lda #0
        sta plover
        jsr PlotLine
        ldy bandG               ; player 0, in front
        lda DemonGfx,y
        ldx band
        ldy bSh,x
        jsr ExpandB
        ldx band
        lda bX0,x
        sta plX
        lda #0
        jsr SplitCodes
        lda #1
        sta plover
        jsr PlotLine
        lda #0
        sta plover
_next   ldy bandG1              ; this row is the next line's "line above"
        ldx DemonGfx,y
        lda Reverse,x
        sta prev1b
        inc bandL
        dec bandG
        dec bandG1
        dec bandN
        beq +
        jmp _line
+       rts

; SlowBand for demons of normal width (split demons): each line's pixels worked out once,
; as SlowBand / PlotLine do, into three column slices a player (SbP1, SbP0, and SbM0 what
; player 0 covers, inverted; slice 3: none), then each cell fetched once (GetCell) and its
; lines written: (d | player 1) & ~covered | player 0 (player 0 in front).
SmallBand:
        ldx band
        lda bX0,x               ; player 0's pixels left of 43 (previous colour)
        ldx #43
        jsr Split8
        sta sbS0
        ldx band
        lda bX1,x               ; player 1's left of 52
        ldx #52
        jsr Split8
        sta sbS1
        ldx band
        lda bX1,x               ; and left of 19 (the line above's graphics)
        ldx #19
        jsr Split8
        sta sbG
        ldx band                ; the shifts (pixel offset in the column): player 1's through
        lda bX1,x               ; ptrA (right) / ptrB (what spills into the next column),
        and #3                  ; player 0's through ptrC / srcP
        tay
        lda SbRLo,y
        sta ptrA
        lda SbRHi,y
        sta ptrA+1
        lda SbLLo,y
        sta ptrB
        lda SbLHi,y
        sta ptrB+1
        lda bX0,x
        and #3
        tay
        lda SbRLo,y
        sta ptrC
        lda SbRHi,y
        sta ptrC+1
        lda SbLLo,y
        sta srcP
        lda SbLHi,y
        sta srcP+1
        lda bP0,x
        ora #7
        sta bandG
        lda bP1,x
        ora #7
        sta bandG1
        lda #0
        sta prev1b
        sta sbI
        lda bandL               ; the pixels drawn "10" on the first line: those left of the
        lsr                     ; colour split (the previous line's colour) on an even line,
        lda sbS1                ; the others on an odd one; the other way round each line
        bcc +
        eor #$ff
+       sta sbB1
        lda sbS0
        bcc +
        eor #$ff
+       sta sbB0
_line   ldy bandG1              ; player 1: this row (pixel order), or the line above's left
        ldx DemonGfx,y          ; of pixel 19
        lda Reverse,x
        ldx sbG
        beq ++
        tay
        eor prev1b
        and sbG
        sty prev1b
        sta tmp
        tya
        eor tmp
+
+       tay                     ; multicolour: "01" for each pixel, + "01" more for those
        and sbB1                ; drawn "10"
        tax
        lda MCLo,y
        clc
        adc MCLo,x
        sta tmp2
        lda MCHi,y
        adc MCHi,x
        tay
        ldx sbI
        lda (ptrA),y
        sta SbP1,x
        lda (ptrB),y
        ldy tmp2
        ora (ptrA),y
        sta SbP1+8,x
        lda (ptrB),y
        sta SbP1+16,x
        ldy bandG               ; player 0
        lda DemonGfx,y
        tay
        and sbB0
        tax
        lda MCLo,y
        clc
        adc MCLo,x
        sta tmp2
        lda MCHi,y
        adc MCHi,x
        tay
        ldx sbI                 ; (and what it covers, inverted: from its bytes, CoverInv)
        lda (ptrC),y
        sta SbP0,x
        sta tmp3
        lda (srcP),y
        ldy tmp2
        ora (ptrC),y
        sta SbP0+8,x
        tay
        lda CoverInv,y
        sta SbM0+8,x
        ldy tmp2
        lda (srcP),y
        sta SbP0+16,x
        tay
        lda CoverInv,y
        sta SbM0+16,x
        ldy tmp3
        lda CoverInv,y
        sta SbM0,x
        dec bandG
        dec bandG1
        lda sbB1
        eor #$ff
        sta sbB1
        lda sbB0
        eor #$ff
        sta sbB0
        inx
        stx sbI
        cpx #8
        beq +
        jmp _line
+
        ; (each slice: any pixels at all?)
        lda SbP1
        ora SbP1+1
        ora SbP1+2
        ora SbP1+3
        ora SbP1+4
        ora SbP1+5
        ora SbP1+6
        ora SbP1+7
        sta SbAny1
        lda SbP1+8
        ora SbP1+8+1
        ora SbP1+8+2
        ora SbP1+8+3
        ora SbP1+8+4
        ora SbP1+8+5
        ora SbP1+8+6
        ora SbP1+8+7
        sta SbAny1+1
        lda SbP1+16
        ora SbP1+16+1
        ora SbP1+16+2
        ora SbP1+16+3
        ora SbP1+16+4
        ora SbP1+16+5
        ora SbP1+16+6
        ora SbP1+16+7
        sta SbAny1+2
        lda SbP0
        ora SbP0+1
        ora SbP0+2
        ora SbP0+3
        ora SbP0+4
        ora SbP0+5
        ora SbP0+6
        ora SbP0+7
        sta SbAny0
        lda SbP0+8
        ora SbP0+8+1
        ora SbP0+8+2
        ora SbP0+8+3
        ora SbP0+8+4
        ora SbP0+8+5
        ora SbP0+8+6
        ora SbP0+8+7
        sta SbAny0+1
        lda SbP0+16
        ora SbP0+16+1
        ora SbP0+16+2
        ora SbP0+16+3
        ora SbP0+16+4
        ora SbP0+16+5
        ora SbP0+16+6
        ora SbP0+16+7
        sta SbAny0+2
        ldx band                ; the cells, a character row at a time
        lda bX1,x
        lsr
        lsr
        sta sbC1
        lda bX0,x
        lsr
        lsr
        sta sbC0
        lda bX1,x               ; (columns: 2 when the pixels start one, else 3)
        and #3
        cmp #1
        lda #2
        adc #0
        sta sbW1
        lda bX0,x
        and #3
        cmp #1
        lda #2
        adc #0
        sta sbW0
        ldx #0                  ; the cells with pixels: a list (column, player 1's slice,
        stx sbLN                ; player 0's; 3: none), the same for both character rows
_k1     stx sbK                 ; player 1's columns (and player 0's slice there)
        txa
        clc
        adc sbC1
        cmp #40
        bcc +
        sbc #40
+       sta sbCol
        sec
        sbc sbC0
        bcs +
        adc #40
+       cmp #3
        bcc +
        lda #3
+       tay
        lda SbAny1,x
        ora SbAny0,y
        beq _kskip
        lda SbAny0,y            ; (a slice without pixels: none, 3)
        bne _k0y
        ldy #3
_k0y    tya
        ldy sbLN
        sta SbLK0,y
        lda SbAny1,x
        beq _k1n
        txa
        .byte $2c               ; (bit: skips the next)
_k1n    lda #3
        sta SbLK1,y
        lda sbCol
        sta SbLCol,y
        inc sbLN
_kskip  ldx sbK
        inx
        cpx sbW1
        bne _k1
        ldx #0                  ; player 0's columns where player 1 isn't
_k0     txa
        clc
        adc sbC0
        cmp #40
        bcc +
        sbc #40
+       sta sbCol
        sec
        sbc sbC1
        bcs +
        adc #40
+       cmp #3
        bcc +
        lda SbAny0,x
        beq +
        ldy sbLN
        txa
        sta SbLK0,y
        lda #3
        sta SbLK1,y
        lda sbCol
        sta SbLCol,y
        inc sbLN
+       inx
        cpx sbW0
        bne _k0
        lda sbLN
        bne +
        rts
+       lda #0
        sta sbI
_row    lda bandL
        clc
        adc sbI
        jsr LineRow
        bcc +
        lda #1                  ; (off the screen: the next line)
        sta sbN
        jmp _nrow
+       lda #8                  ; lines in this row
        sec
        sbc lic
        sta sbN
        lda #8
        sec
        sbc sbI
        cmp sbN
        bcs +
        sta sbN
+       clc                     ; (SbCell's loops end at line sbI + sbN)
        adc sbI
        sta SbCell._qce+1
        lda #0
_cell   sta sbK
        tay
        lda SbLCol,y
        sta sbCol
        ldx SbLK1,y
        lda SbLK0,y
        tay
        jsr SbCell
        ldy sbK
        iny
        tya
        cpy sbLN
        bne _cell
_nrow   lda sbI
        clc
        adc sbN
        sta sbI
        cmp #8
        bcs +
        jmp _row
+       rts
; cell sbCol of the row LineRow set: X = player 1's slice, Y = player 0's (3: none); lines
; sbI on (sbN of them, from line lic of the cell)
SbCell:
        lda SbOfs,x
        sta _qa1+1
        sta _qp1+1
        lda SbOfs,y
        clc
        adc #<(SbP0-SbP1)
        sta _qa0+1
        sta _qp0+1
        adc #<(SbM0-SbP0)
        sta _qm0+1
        ldx sbI                 ; any pixels there?
        ldy sbN
_qa1    lda SbP1,x
_qa0    ora SbP0,x
        bne +
        inx
        dey
        bne _qa1
        rts
+       lda sbCol
        jsr GetCell
        bcs +
        ldx sbI
        ldy lic
-       lda (dstPtr),y
_qp1    ora SbP1,x
_qm0    and SbM0,x
_qp0    ora SbP0,x
        sta (dstPtr),y
        inx
        iny
_qce    cpx #0
        bne -
+       rts
; A split band's right half as characters, its left half a sprite pair (_half): player hfC
; alone. Its eight lines as SmallBand draws them ("01" for each pixel, "10" for those in the
; colour each line's register pair puts there; player 1 reflected, the line above's row left
; of pixel 19), into its 2-3 columns (OneL: 8 lines a column), then each cell with pixels on a
; row's lines written: player 1 ORed in, player 0 over what it covers.
OneBand:
        ldx band
        lda hfC
        bne _p1
        lda bX0,x               ; player 0: the previous line's colour left of 43
        sta sbX
        ldx #43
        jsr Split8
        sta sbS0
        lda #0
        sta sbG
        ldx band
        lda bP0,x
        jmp _g
_p1     lda bX1,x               ; player 1: left of 52; the line above's row left of 19
        sta sbX
        ldx #52
        jsr Split8
        sta sbS0
        ldx band
        lda bX1,x
        ldx #19
        jsr Split8
        sta sbG
        ldx band
        lda bP1,x
_g      ora #7
        sta bandG
        lda sbX                 ; its shift in the column (pixels): this cell, the next
        and #3
        tay
        lda SbRLo,y
        sta ptrA
        lda SbRHi,y
        sta ptrA+1
        lda SbLLo,y
        sta ptrB
        lda SbLHi,y
        sta ptrB+1
        lda bandL               ; the pixels drawn "10" on the first line: those left of the
        lsr                     ; colour split on an even line, the others on an odd one
        lda sbS0
        bcc +
        eor #$ff
+       sta sbB0
        lda #0
        sta prev1b
        tax
_line   stx sbI
        ldy bandG
        lda DemonGfx,y
        ldy hfC
        beq ++
        tax                     ; player 1: reflected, the line above's left of 19
        lda Reverse,x
        ldx sbG
        beq ++
        tay
        eor prev1b
        and sbG
        sty prev1b
        sta tmp
        tya
        eor tmp
+
+       tay                     ; multicolour: "01" for each pixel, + "01" more for those
        and sbB0                ; drawn "10"
        tax
        lda MCLo,y
        clc
        adc MCLo,x
        sta tmp2
        lda MCHi,y
        adc MCHi,x
        tay
        ldx sbI
        lda (ptrA),y
        sta OneL,x
        lda (ptrB),y
        ldy tmp2
        ora (ptrA),y
        sta OneL+8,x
        lda (ptrB),y
        sta OneL+16,x
        dec bandG
        lda sbB0
        eor #$ff
        sta sbB0
        inx
        cpx #8
        bne _line
        lda sbX                 ; the columns: from x / 4, two when the pixels start one
        lsr
        lsr
        sta sbC0
        lda sbX
        and #3
        cmp #1
        lda #2
        adc #0
        sta sbW0
        lda hfC                 ; player 0: what it covers (the other pixels, its own lines)
        bne +
        ldx #23
-       ldy OneL,x
        lda CoverInv,y
        sta OneM,x
        dex
        bpl -
+       lda #0
        sta sbI
_row    lda bandL               ; a character row at a time
        clc
        adc sbI
        jsr LineRow
        bcc +
        lda #1                  ; (off the screen: the next line)
        sta sbN
        jmp _nrow
+       lda #8                  ; lines in this row
        sec
        sbc lic
        sta sbN
        lda #8
        sec
        sbc sbI
        cmp sbN
        bcs +
        sta sbN
+       lda #0
        sta sbK
_col    asl                     ; column sbK: its lines sbI .. sbI + sbN - 1 (X), any pixels?
        asl
        asl
        clc
        adc sbI
        sta sbCo
        tax
        clc
        adc sbN
        sta sbE2
-       lda OneL,x
        bne +
        inx
        cpx sbE2
        bne -
        beq _ncol
+       lda sbC0
        clc
        adc sbK
        jsr GetCell
        bcs _ncol
        ldx sbCo
        ldy lic
        lda hfC
        bne _w1
-       lda (dstPtr),y          ; player 0: over what it covers
        and OneM,x
        ora OneL,x
        sta (dstPtr),y
        iny
        inx
        cpx sbE2
        bne -
        beq _ncol
_w1     lda (dstPtr),y          ; player 1: ORed in
        ora OneL,x
        sta (dstPtr),y
        iny
        inx
        cpx sbE2
        bne _w1
_ncol   inc sbK
        lda sbK
        cmp sbW0
        bne _col
_nrow   lda sbI
        clc
        adc sbN
        sta sbI
        cmp #8
        bcs +
        jmp _row
+       rts
SbOfs:      .byte <SbP1, <SbP1+8, <SbP1+16, <SbP1+24
CoverInv:   .for b = 0, b < 256, b += 1     ; multicolour byte -> the pixels it doesn't cover ("11")
            .byte ~((((b >> 6) & 3) != 0) * $c0 | (((b >> 4) & 3) != 0) * $30 | (((b >> 2) & 3) != 0) * $0c | ((b & 3) != 0) * $03) & $ff
            .next
SbRLo:      .byte <Ident, <ShR1, <ShR2, <ShR3
SbRHi:      .byte >Ident, >ShR1, >ShR2, >ShR3
SbLLo:      .byte <Zero256, <ShL1, <ShL2, <ShL3
SbLHi:      .byte >Zero256, >ShL1, >ShL2, >ShL3
        .cerror (>SbP1) != (>(SbM0 + 31)), "SmallBand's slices must be in one page"

; (wide) oB = this row of player 1, expanded; the line above's where sm says
WideP1:
        ldy bandG1
        iny
        ldx DemonGfx,y
        lda Reverse,x
        ldy #2
        jsr ExpandA             ; (oA is free here)
        ldx #3
-       lda oB,x
        eor oA,x
        and sm,x
        eor oB,x
        sta oB,x
        dex
        bpl -
        rts

; sm (1 or 4 bytes) = the pixels of an object at A, Y wide (8 or 32), left of pixel X
SplitN:
        sta smX
        stx smS
        sty smW
        ldx #0
-       stx tmp3
        lda smX
        ldx smS
        jsr Split8
        ldx tmp3
        sta sm,x
        lda smX
        clc
        adc #8
        cmp #160
        bcc +
        sbc #160
+       sta smX
        inx
        txa
        asl
        asl
        asl
        cmp smW
        bcc -
        rts

; oB (plN bytes, an object's pixels on line plL) -> plA / plB, its "01" and "10" pixels:
; those in the mask at spAll + A (0: sp0, 4: sp1) show the previous line's colour.
SplitCodes:
        sta spOfs
        lda plL                 ; odd line: this line's colour is "10"
        and #1
        sta tmp3
        ldy #0
-       ldx spOfs
        inc spOfs
        lda spAll,x
        and oB,y                ; previous colour
        sta tmp
        eor oB,y                ; this line's
        ldx tmp3
        bne +
        sta plA,y
        lda tmp
        sta plB,y
        jmp ++
+       sta plB,y
        lda tmp
        sta plA,y
+       iny
        cpy plN
        bne -
        rts

; ------------------------------------------------------------ cannon band
; A small demon diving (player 1 at $94, not reflected), or the cannon's explosion
; (players 0 and 1, pieces every eight lines): sprites 6-7 (pair use 3).
DrawCannonBand:
        lda #3
        sta spUse
        lda plDyn               ; its pair: 6-7 as always, or the plan's ($ff: none)
        bne +
        lda #1
        bne ++
+       lda ItP+3
+       sta spPair
        lda cMode
        cmp #1
        beq _small
        bcs +
        jmp BlankUse
+       jmp DrawPieces
_small  lda SmallY              ; rows 7..0 at X = $C8+7 .. $C8: lines 213-C8 .. 220-C8
        clc                     ; (always inside the cannon band)
        adc #7
        sta lnX
        lda #220
        sec
        sbc lnX
        sta bandL
        lda #0                  ; (previous-colour pixels: left of 52)
        sta runPrev
        lda cX1
        cmp #52
        bcc +
        cmp #153
        bcs +
        lda #64
        sta runPrev
+       ldy #0                  ; its colour writes (prev: band 2's last, row 0's colour)
        lda (ColourPtr),y
        ldx spPair
        ldy PairRegP,x
        jsr SchedColourRun
        lda cX1
        sta swX1
        sta swX0
        lda #1
        sta swSmall
        jmp SprDemon

; The small demon's row on the line SprDemon is at (X = lnX, counting down): GRP1 is
; written at pixel 28 on the cannon's lines (X < 12), else 10: left of that the line above's
; row; COLUP1 at 52 / 34. -> p0w = 0, p1w = this row, pw = the line above's, and the
; left19 / prev1 masks for this line.
SmallRow:
        ldx #0                  ; (the masks: the cannon's lines', or the others')
        lda lnX
        cmp #12
        bcc +
        inx
+       cpx smSet
        beq +
        stx smSet
        lda Mul3,x
        tax
        lda SmL19,x
        sta left19
        lda SmL19+1,x
        sta left19+1
        lda SmL19+2,x
        sta left19+2
        lda SmPv1,x
        sta pv1
        lda SmPv1+1,x
        sta pv1+1
        lda SmPv1+2,x
        sta pv1+2
+       lda lnX
        jsr SmallAt
        sta p1w
        lda lnX
        clc
        adc #1
        jsr SmallAt
        sta pw
        dec lnX
        rts
; its masks for both kinds of line (left19: 28 / 10, pv1: 52 / 34; the window starts at the
; demon), and the bytes that stay blank
SmallSetup:
        lda #28
        jsr LeftWin
        ldx #0
        jsr _l19
        lda #52
        jsr LeftWin
        ldx #0
        jsr _pv1
        lda #10
        jsr LeftWin
        ldx #3
        jsr _l19
        lda #34
        jsr LeftWin
        ldx #3
        jsr _pv1
        lda #0
        sta p0w
        sta p0w+1
        sta p0w+2
        sta pv0
        sta pv0+1
        sta pv0+2
        sta p1w+1
        sta p1w+2
        sta pw+1
        sta pw+2
        lda #$ff
        sta smSet
        rts
_l19    lda pw
        sta SmL19,x
        lda pw+1
        sta SmL19+1,x
        lda pw+2
        sta SmL19+2,x
        rts
_pv1    lda pw
        sta SmPv1,x
        lda pw+1
        sta SmPv1+1,x
        lda pw+2
        sta SmPv1+2,x
        rts

; The explosion: pieces j = 4..0 on lines X = 8j and 8j-1 (X = 0 only for j = 0), each row
; one colour (PieceColour[j]): sprite 6 from line max(188, the cannon band's first) and
; sprite 7 21 lines below it, colours set before each row. Players 0 and 1 (reflected; on
; line 0 not right of pixel 136) inside a 24-pixel window.
DrawPieces:
        lda cX1
        sec
        sbc cX0
        bcs +
        eor #$ff
        adc #1
+       cmp #17
        bcc +
        jmp BlankUse            ; (too far apart: not drawn)
+       lda cX0
        cmp cX1
        bcc +
        lda cX1
+       sta swS
        lda cX0
        sec
        sbc swS
        sta swO0
        lda cX1
        sec
        sbc swS
        sta swO1
        lda #221                ; the first line: the cannon band's, or 188
        sec
        sbc bC+2
        cmp #188
        bcs +
        lda #188
+       sta swL                 ; sprite 6's first line
        ldx rbuf                ; the blocks: clear both
        lda SprBlkNum,x
        clc
        adc #B_DEMONS+6
        sta swBlk
        tax
        lda BlkLo,x
        sta ptrA
        lda BlkHi,x
        sta ptrA+1
        lda BlkLo+1,x
        sta ptrB
        lda BlkHi+1,x
        sta ptrB+1
        ldx rbuf                ; clear the rows this buffer's blocks show (all of both if
        lda PcN,x               ; something else drew there)
        bpl _list
        ldy #62
        lda #0
-       sta (ptrA),y
        sta (ptrB),y
        dey
        bpl -
        jmp _clr
_list   beq _clr
        sta tmp
        lda Mul9,x
        tax
-       lda PcOfs,x             ; (bit 7: sprite 7's block)
        bmi _cb
        tay
        lda #0
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        sta (ptrA),y
        jmp _cn
_cb     and #$7f
        tay
        lda #0
        sta (ptrB),y
        iny
        sta (ptrB),y
        iny
        sta (ptrB),y
_cn     inx
        dec tmp
        bne -
_clr    ldx rbuf
        lda #1                  ; (rows past 7 drawn: the small demon clears them)
        sta PcDirty,x
        lda #0
        sta PcN,x
        lda Mul9,x
        sta pcL
        lda swO0                ; one player at the window's left edge, the other d = 0-16
        ora swO1                ; pixels in: byte d / 8, shifted d & 7 (tables)
        tax
        lsr
        lsr
        lsr
        sta pcB
        txa
        and #7
        tax
        lda PcShRLo,x
        sta ptrC
        lda PcShRHi,x
        sta ptrC+1
        lda PcShLLo,x
        sta dstPtr
        lda PcShLHi,x
        sta dstPtr+1
        lda #8
        sta pcI
_line   ldx pcI                 ; lines X = 32, 31, 24, 23 .. 8, 7, 0: row X / 8 rounded up
        lda PcLine,x
        sta lnX
        cmp bC+2                ; inside the cannon band?
        bcs _nextx
        lda PcRow,x
        tay
        lda (pcPtr),y
        bne +
_nextx  jmp _next
+       sta tmp3
        tax                     ; player 1: reflected, except right of pixel 136 on line 0
        lda Reverse,x
        ldx lnX
        bne +
        sta tq
        lda cX1
        ldx #136
        jsr Split8
        sta sm
        lda tmp3
        jsr MixByte
+       ldx swO0                ; player 0 at the edge: player 1 shifted, else player 0
        bne +
        ldx tmp3
        stx pa
        tay
        jmp ++
+       sta pa
        ldy tmp3
+       lda #0
        sta pa+1
        sta pa+2
        ldx pcB
        lda (ptrC),y
        ora pa,x
        sta pa,x
        lda (dstPtr),y
        sta pa+1,x
        lda #220                ; its line, and which sprite's row
        sec
        sbc lnX
        sec
        sbc swL
        ldx #0
        cmp #21
        bcc +
        sbc #21
        ldx #$80
+       stx tmp4
        sta tmp2                ; row
        asl
        adc tmp2
        ora tmp4
        ldx pcL                 ; (to clear next time)
        sta PcOfs,x
        inc pcL
        and #$7f
        tay
        lda pa
        bit tmp4
        bmi _s7
        sta (ptrA),y
        iny
        lda pa+1
        sta (ptrA),y
        iny
        lda pa+2
        sta (ptrA),y
        jmp +
_s7     sta (ptrB),y
        iny
        lda pa+1
        sta (ptrB),y
        iny
        lda pa+2
        sta (ptrB),y
+       ldx rbuf
        inc PcN,x
        lda lnX                 ; the row's colour, before its first line
        and #7
        bne _next
        lda tmp4
        asl
        rol
        sta tmp4                ; (0: sprite 6, 1: sprite 7)
        jsr SchedPieceColour
_next   dec pcI
        bmi +
        jmp _line
+       ; the pair: its first sprite at swL, the second at swL + 21
        lda swS
        jsr SprX
        sta tmp2
        lda swL
        clc
        adc #SPRYOFS
        sta tmp3
        adc #21
        sta tmp4
        ldy swBlk
        iny
        sty swBlk2
        jmp PairSet

; ------------------------------------------------------------ HMOVE marks
; Pixels 0-7 of each band's HMOVE line, and of line 222, are black on the 2600. Only drawn
; when the background isn't black.
DrawNotches:
        lda BgColour
        lsr
        tax
        lda ColorMap,x
        bne +
        rts
+       lda #54
        jsr _one
        ldx #0
-       stx band
        lda #220
        sec
        sbc bC,x
        jsr _one
        ldx band
        inx
        cpx #3
        bne -
        lda #222
_one    jsr LineRow
        bcs +
        lda #0
        jsr GetCell
        bcs +
        ldy lic
        lda #$ff
        sta (dstPtr),y
        lda #1
        jsr GetCell
        bcs +
        ldy lic
        lda #$ff
        sta (dstPtr),y
+       rts

; ---------------------------------------------------------------- sprites
; The laser: sprite 0, Collide's LaserRow (a bit per line) from LaserTop, LaserN lines (none:
; the sprite stays off). Rows 0 .. LaserN - 1 copied (LCopy0 / LCopy1: an rts goes in after
; them), then the rows the last laser drawn into this buffer had past those blanked (the
; rest are blank already).
DrawLaser:
        ldy LaserN
        bne +
        rts
+       ldx rbuf
        lda LCopyLo,x
        sta _c+1
        clc
        adc Mul6,y
        sta _r1+1
        sta _r2+1
        lda LCopyHi,x
        sta _c+2
        adc #0
        sta _r1+2
        sta _r2+2
        cpy #21
        beq _c
        lda #$60                ; (rts)
_r1     sta $ffff
_c      jsr $ffff
        ldy LaserN
        cpy #21
        beq +
        lda #$ad                ; (lda abs: as it was)
_r2     sta $ffff
+       ldx rbuf                ; rows LaserN .. (the last one's) - 1 blank
        lda LaserLast,x
        sec
        sbc LaserN
        beq +
        bcc +
        sta tmp
        lda SprLaserLo,x
        sta ptrA
        lda SprLaserHi,x
        sta ptrA+1
        lda Mul3,y
        tay
        lda #0
-       sta (ptrA),y
        iny
        iny
        iny
        dec tmp
        bne -
+       lda LaserN
        sta LaserLast,x
_pos
        lda bx
        jsr SprX
        ldy Mul8,x
        sta StX,y
        lda StMsb,x
        ora tmp
        sta StMsb,x
        lda LaserTop
        clc
        adc #SPRYOFS
        sta StY,y
        lda COLUPF
        lsr
        tax
        lda ColorMap,x
        sta StCol,y
        ldx rbuf
        lda SprBlkNum,x
        sta StPtr,y
        lda LaserN
        beq +
        lda StEn,x
        ora #1
        sta StEn,x
+       rts

; the laser's rows into a buffer's sprite block (6 bytes a row)
LCopy0:     .for k = 0, k < 21, k += 1
            lda LaserRow+k
            sta VICBANK+64*BLK_SET+3*k
            .next
            rts
LCopy1:     .for k = 0, k < 21, k += 1
            lda LaserRow+k
            sta VICBANK+64*(BLK_SET+NBLK)+3*k
            .next
            rts
        .cerror LCopy1 - LCopy0 != 21 * 6 + 1, "LCopy: 6 bytes a row"
LCopyLo:    .byte <LCopy0, <LCopy1
LCopyHi:    .byte >LCopy0, >LCopy1
SprLaserLo: .byte <(VICBANK+64*BLK_SET), <(VICBANK+64*(BLK_SET+NBLK))
SprLaserHi: .byte >(VICBANK+64*BLK_SET), >(VICBANK+64*(BLK_SET+NBLK))
Mul6:       .for i = 0, i < 22, i += 1
            .byte 6 * i
            .next

; A = 2600 pixel -> A = sprite X (low byte), tmp = bit 8 (in bit 0); X = rbuf
SprX:
        asl
        sta tmp2
        lda #0
        rol
        sta tmp
        lda tmp2
        clc
        adc #24
        bcc +
        inc tmp
+       ldx rbuf
        rts

; The cannon: sprite 1 (its rows are set up once), lines 209-220, not while it explodes.
DrawCannon:
        lda cMode
        cmp #2
        bne +
        rts
+       lda cX0
        jsr SprX
        ldy Mul8,x
        sta StX+1,y
        lda tmp
        asl
        ora StMsb,x
        sta StMsb,x
        lda #209+SPRYOFS
        sta StY+1,y
        lda CannonColour
        and ColourMask
        lsr
        tax
        lda ColorMap,x
        sta StCol+1,y
        ldx rbuf
        lda SprBlkNum,x
        clc
        adc #B_CANNON
        sta StPtr+1,y
        lda StEn,x
        ora #2
        sta StEn,x
        rts

; The bullets: player 1 at $94, a row of $A5-$AE every 8 lines (X < $50, inside the cannon
; band), dashed, GRP1 written at pixel 100 / 118 (+3 on a line that turns the laser on):
; left of that a line shows the line above's. Sprites 2 and 3 take turns down the column,
; four segments of 20 lines from line 141.
DrawBullets:
        lda cMode
        beq +
        rts
+       lda Bullets             ; any at all?
        ora Bullets+1
        ora Bullets+2
        ora Bullets+3
        ora Bullets+4
        ora Bullets+5
        ora Bullets+6
        ora Bullets+7
        ora Bullets+8
        ora Bullets+9
        bne +
        rts
+       lda cX1                 ; (the masks for where GRP1 lands: when the column changes)
        cmp bulSmX
        beq +
        jsr _masks
+       lda bC+2                ; none from X = min(80, C7) up (above the cannon band)
        cmp #80
        bcc +
        lda #80
+       sta bulLim
        ldx #$ff                ; the dashes: groups 2i+1 (lines 8i+7 .. 8i+4) and 2i (8i+3 ..
        lda Frame               ; 8i) of row i shown? (bit 2 of ~X)
        and DashMask
        beq +
        ldx #0
+       stx bulMO
        ldx #$ff
        lda Frame
        eor #4
        and DashMask
        beq +
        ldx #0
+       stx bulME
        lda #0
        sta prev1b
        ldx rbuf
        lda BulBlkLo,x
        sta ptrA
        lda BulBlkHi,x
        sta ptrA+1
        lda Mul10,x
        sta bulKB
        clc                     ; (this buffer's BulKZ, for the blank rows)
        adc #<BulKZ
        sta _qkz+1
        lda #>BulKZ
        adc #0
        sta _qkz+2
        ; each row, top first: the groups' values, and their first lines (the line above's
        ; value left of where GRP1 lands); redrawn when they change
        ldx #9
_row    stx bulRi
        lda Bullets,x           ; (no bullets, none above, and this buffer shows none: next)
        ora prev1b
        bne _rowf
_qkz    lda BulKZ,x
        beq _rowf
        jmp _nrow2
_rowf   txa
        asl
        asl
        asl
        cmp bulLim
        bcs _zrow               ; (all of it from bulLim up)
        adc #7
        cmp bulLim
        bcc +
        jmp _prow               ; (part of it)
+       lda Bullets,x
        and bulMO
        sta bulVo
        lda Bullets,x
        and bulME
        sta bulVe
        jmp _have
_zrow   lda #0
        sta bulVo
        sta bulVe
_have   lda bulVo               ; (a blank row this buffer shows blank: nothing to do)
        ora bulVe
        ora prev1b
        bne _have2
        lda bulKB
        clc
        adc bulRi
        tay
        lda BulKZ,y
        beq _have2
        jmp _nrow
_have2  lda bulVo               ; (the groups' first lines: the line above's left of where
        cmp prev1b              ; GRP1 lands; bulSmK 0: none of the column, 1: all of it)
        beq ++
        ldy bulSmK
        beq ++
        dey
        bne +
        lda prev1b
        jmp ++
+       sta tmp3
        lda prev1b
        sta tq
        lda bulRi
        asl
        asl
        asl
        ora #7
        jsr _mix
+       sta bulF1
        lda bulVe
        cmp bulVo
        beq ++
        ldy bulSmK
        beq ++
        dey
        bne +
        lda bulVo
        jmp ++
+       sta tmp3
        lda bulVo
        sta tq
        lda bulRi
        asl
        asl
        asl
        ora #3
        jsr _mix
+       sta bulF2
        lda bulKB               ; the same as this buffer shows?
        clc
        adc bulRi
        tay
        lda BulKP,y
        bne _wr
        lda bulVo
        cmp BulKo,y
        bne _wr
        lda bulVe
        cmp BulKe,y
        bne _wr
        lda bulF1
        cmp BulK1,y
        bne _wr
        lda bulF2
        cmp BulK2,y
        beq _nrow
_wr     lda #0
        sta BulKP,y
        sta BulKZ,y
        lda bulVo
        ora bulVe
        ora bulF1
        ora bulF2
        bne +
        lda #1
        sta BulKZ,y
+
        lda bulVo
        sta BulKo,y
        lda bulVe
        sta BulKe,y
        lda bulF1
        sta BulK1,y
        lda bulF2
        sta BulK2,y
        ldx bulRi
        ldy RowOfsA,x
        lda bulF1
        sta (ptrA),y
        lda bulVo
        iny
        iny
        iny
        sta (ptrA),y
        iny
        iny
        iny
        sta (ptrA),y
        iny
        iny
        iny
        sta (ptrA),y
        ldy RowOfsB,x
        lda bulF2
        sta (ptrA),y
        lda bulVe
        iny
        iny
        iny
        sta (ptrA),y
        iny
        iny
        iny
        sta (ptrA),y
        iny
        iny
        iny
        sta (ptrA),y
_nrow   lda bulVe
        sta prev1b
_nrow2  ldx bulRi
        dex
        bmi +
        jmp _row
+       jmp _pos
_prow   lda Bullets,x           ; line by line: none from bulLim up
        and bulMO
        sta bulVo
        lda Bullets,x
        and bulME
        sta bulVe
        txa
        asl
        asl
        asl
        sta lnX0
        ora #7
        sta lnX
_qpl     lda #0
        ldx lnX
        cpx bulLim
        bcs ++
        txa
        and #4
        beq +
        lda bulVo
        jmp ++
+       lda bulVe
+       sta tmp3
        cmp prev1b
        beq _pst
        lda prev1b
        sta tq
        lda lnX
        jsr _mix
_pst    ldx lnX
        ldy BulOfs,x
        sta (ptrA),y
        lda tmp3
        sta prev1b
        lda lnX
        cmp lnX0
        beq +
        dec lnX
        jmp _qpl
+       lda bulKB               ; (not the rows' values: redrawn next time)
        clc
        adc bulRi
        tay
        lda #1
        sta BulKP,y
        lda #0
        sta BulKZ,y
        jmp _nrow2
; line A: tmp3, but the line above's (tq) left of where GRP1 lands: pixel 100 / 103 (laser
; on) from line 12 up, 118 / 121 below
_mix    ldy bulSmK              ; (the column all left of those pixels: the line above's;
        beq _m0                 ; all right: this line's)
        dey
        beq _m1
        ldy #0
        cmp #12
        bcs +
        ldy #2
+       sec
        sbc LaserY
        and #$f8
        bne +
        iny
+       lda tmp3
        eor tq
        and bulSm,y
        eor tmp3
        rts
_m0     lda tmp3
        rts
_m1     lda tq
        rts
_masks  sta bulSmX              ; (when the bullets' column changes)
        ldx #3
-       stx tmp4
        lda BulSplit,x
        tax
        lda cX1
        jsr Split8
        ldx tmp4
        sta bulSm,x
        dex
        bpl -
        ldy #1                  ; bulSmK: 0 all clear, 1 all set, 2 mixed
        lda bulSm
        and bulSm+1
        and bulSm+2
        and bulSm+3
        cmp #$ff
        beq +
        dey
        lda bulSm
        ora bulSm+1
        ora bulSm+2
        ora bulSm+3
        beq +
        ldy #2
+       sty bulSmK
        rts
_pos
        ; positions: segments 0 (sprite 2) and 1 (sprite 3) at the frame top, 2 and 3 later
        lda cX1
        jsr SprX
        ldy Mul8,x
        sta StX+2,y
        sta StX+3,y
        lda tmp
        beq +
        lda #$0c
+       ora StMsb,x
        sta StMsb,x
        lda StEn,x
        ora #$0c
        sta StEn,x
        lda #$4e >> 1           ; COLUP1 = $4E
        tax
        lda ColorMap,x
        sta StCol+2,y
        sta StCol+3,y
        lda #BULLINE+SPRYOFS
        sta StY+2,y
        lda #BULLINE+20+SPRYOFS
        sta StY+3,y
        ldx rbuf
        lda SprBlkNum,x
        clc
        adc #B_BULLETS
        sta StPtr+2,y
        adc #1
        sta StPtr+3,y
        ldy Mul4,x
        adc #1
        sta BulPtr+2,y
        adc #1
        sta BulPtr+3,y
        lda #BULLINE+40+SPRYOFS
        sta BulY+2,y
        lda #BULLINE+60+SPRYOFS
        sta BulY+3,y
        tya
        ora #2                  ; segment 2: after sprite 2's first 21 lines
        tay
        lda #BULLINE+24+LINE2RAS
        ldx #S_BUL
        jsr SchedAdd
        iny                     ; segment 3: after sprite 3's
        lda #BULLINE+44+LINE2RAS
        ldx #S_BUL
        jmp SchedAdd

; ---------------------------------------------------------------- schedule
; Start this buffer's schedule: the frame top, and what it sets.
SchedStart:
        ldx rbuf
        lda SchedBase,x
        sta schedI
        sta schedB
        lda RunBase,x
        sta runI
        lda RunHBase,x
        sta runH
        lda SetBase,x
        sta setI
        lda BgColour            ; background, score colour
        lsr
        tay
        lda ColorMap,y
        sta StD021,x
        lda ScoreColour
        and ColourMask
        lsr
        tay
        lda ColorMap,y
        sta StD022,x
        lda #0
        sta StD023,x
        sta StMsb,x
        lda #$f0                ; the demon pairs: always on (blank when unused)
        sta StEn,x
        lda ColourPtr           ; the demons' colour table in C64 colours, rows 7..0
        cmp mapKey
        bne +
        lda ColourPtr+1
        cmp mapKey+1
        beq _mapped
+       lda ColourPtr
        sta mapKey
        lda ColourPtr+1
        sta mapKey+1
        ldy #7
        ldx #0
-       lda (ColourPtr),y
        lsr
        sta tmp
        stx tmp2
        ldx tmp
        lda ColorMap,x
        ldx tmp2
        sta MapColRev,x
        inx
        dey
        bpl -
        ldx #7                  ; the last line k (2-7) whose colour differs from line k - 2's
-       lda MapColRev,x         ; (the register it writes holds that)
        cmp MapColRev-2,x
        bne +
        dex
        cpx #2
        bcs -
        ldx #0
+       stx mapL
_mapped ldx rbuf                ; (this buffer's copy, for the frame top)
        lda Mul8,x
        tax
        lda MapColRev+0
        sta RunValB+0,x
        lda MapColRev+1
        sta RunValB+1,x
        lda MapColRev+2
        sta RunValB+2,x
        lda MapColRev+3
        sta RunValB+3,x
        lda MapColRev+4
        sta RunValB+4,x
        lda MapColRev+5
        sta RunValB+5,x
        lda MapColRev+6
        sta RunValB+6,x
        lda MapColRev+7
        sta RunValB+7,x
        lda #TOPRASTER
        ldx #S_TOP
        jmp SchedAdd
; The demon pairs' second uses: band 2 right after band 0's eight lines (from 210 - C: the
; rest of its blocks are blank, so the pair can move while its 21 rows run on; well before
; band 2's colour run takes the interrupt), the cannon band after band 1's 21 lines (its
; blocks can hold the explosion's lower rows). (Each goes in after its band's entries: the
; schedule is kept in raster order.)
; (Without a plan: records 0 and 1 of the buffer's, sprites 4-5 and 6-7.)
SchedPair0:
        ldy rbuf
        lda RecBase,y
        sta PairRec
        tay
        lda #218+LINE2RAS
        sec
        sbc bC
        ldx #S_PAIR
        jmp SchedAdd
SchedPair1:
        ldy rbuf
        lda RecBase,y
        tay
        iny
        sty PairRec+1
        lda #218+LINE2RAS       ; (the cannon band's blocks are blank past row 7 unless it
        ldx cMode               ; shows the explosion: then after band 1's 21 lines)
        cpx #2
        bne +
        lda #231+LINE2RAS
+       sec
        sbc bC+1
        ldx #S_PAIR
        jmp SchedAdd
RecBase:    .byte 0, NPAIRS     ; each buffer's pair records

; Add an entry: A = raster, X = type, Y = argument. Kept in raster order.
SchedAdd:
        stx saT
        ldx schedI              ; (usually in order: append)
        cpx schedB
        beq _app
        cmp SchedRas-1,x
        bcc _slow
_app    sta SchedRas,x
        lda saT
        sta SchedType,x
        tya
        sta SchedArg,x
        inc schedI
        rts
_slow   sta saR
        sty saA
-       cpx schedB
        beq _ins
        lda SchedRas-1,x
        cmp saR
        bcc _ins
        beq _ins
        sta SchedRas,x          ; (later: move it up one)
        lda SchedType-1,x
        sta SchedType,x
        lda SchedArg-1,x
        sta SchedArg,x
        dex
        bne -
_ins    lda saR
        sta SchedRas,x
        lda saT
        sta SchedType,x
        lda saA
        sta SchedArg,x
        inc schedI
        ldy saA
        rts

; A colour run for the 8 lines of a demon's rows from line bandL (rows 7..0), colours from
; the colour table (the frame's, RunValB). A = the colour before it (2600 value); Y = the
; register for even lines (low byte; odd lines use the next one). Each line's colour is
; written during the line before it (after its pixels left of 52 if runPrev = 0).
SchedColourRun:
        sty runReg
        lsr
        tax
        lda ColorMap,x
        ldx runH
        sta RunSetVal,x
        ldy mapL                ; the writes: up to the last that changes its register (line 0
        bne +                   ; always; line 1 if it differs from the colour before)
        cmp MapColRev+1
        beq +
        ldy #1
+       iny
        tya
        sta RunCnt,x
        lda #0
        sta RunSkip,x
        lda bandL               ; the registers: the first line's, and the other (which first
        and #1                  ; holds the colour before the run): the code for them
        sta tmp
        clc
        adc runReg
        sta RunRegA,x
        lda tmp
        eor #1
        clc
        adc runReg
        sta RunSetReg,x
        sta RunRegB,x
        lda runReg              ; (variants: $D02B, $D02D, $D022 pairs, both sprite pairs
        ldy runDual             ; (runDual 6), a pair and the characters (8: 4-5, 10: 6-7);
        bne +                   ; first register even / odd; + 12: no previous-colour pixels)
        cmp #<$d02b
        beq +
        ldy #2
        cmp #<$d02d
        beq +
        ldy #4
+       tya
        ora tmp
        ldy runPrev
        beq +
        clc
        adc #12
+       tay
        lda RunVLo,y
        sta RunJLo,x
        lda RunVHi,y
        sta RunJHi,x
        lda runPrev
        sta RunPrevF,x          ; (for the checks)
        lda bandL
        sta RunBand,x
        clc                     ; the entry: 2 lines before the first write; but when the
        adc #LINE2RAS-3         ; entry before it (a pair move, say) comes less than 3 lines
        ldx schedI              ; before that, a line before that one (first: it can wait,
        cpx schedB              ; this can't)
        beq +
        sta tmp
        sec
        sbc SchedRas-1,x
        cmp #3
        lda tmp
        bcs +
        lda SchedRas-1,x
        sbc #0                  ; (carry clear: one line earlier)
+       ldx #S_RUN
        ldy runH
        inc runH
        jmp SchedAdd

; The explosion's row at line 220 - lnX (lnX = 8j): its sprite's colour (tmp4: 0 sprite 6,
; 1 sprite 7), 2 lines before.
SchedPieceColour:
        lda lnX
        lsr
        lsr
        lsr
        tay
        lda PieceColour,y
        lsr
        tay
        lda ColorMap,y
        ldx spPair
        ldy PairRegP,x
        ldx setI
        sta SetVal,x
        tya
        clc
        adc tmp4
        sta SetReg,x
        lda #220-2+LINE2RAS
        sec
        sbc lnX
        ldx #S_SET
        ldy setI
        inc setI
        jmp SchedAdd

; The ground: $D021 = its colours on lines 223-229 (two shades darker each line; line
; 222 keeps the background), each written at the start of its line (RunDly 0); first
; $D022 = the bunkers' colour (from line 221, after the cannon band).
SchedGround:
        ldx rbuf                ; the same colours as this buffer's run has: just its entry
        lda Mul3,x
        tay
        ldx #0
        lda BgColour
        cmp GndKey,y
        beq +
        inx
        sta GndKey,y
+       lda GroundColour
        and ColourMask
        cmp GndKey+1,y
        beq +
        inx
        sta GndKey+1,y
+       lda BunkerColour
        cmp GndKey+2,y
        beq +
        inx
        sta GndKey+2,y
+       txa
        bne _new
        lda runI
        clc
        adc #8
        sta runI
        jmp _entry
_new    ldx runH
        lda BunkerColour
        lsr
        tay
        lda ColorMap,y
        sta RunSetVal,x
        lda #<$d022
        sta RunSetReg,x
        lda runI
        sta RunFirst,x
        ldy runI
        lda #BUNKLINE-1+LINE2RAS
        sta RunRas,y
        lda GroundColour        ; lines 223-229: two shades darker each
        and ColourMask
        sta tmp
        ldx #7
-       lda tmp
        lsr
        sta tmp2
        stx tmp3
        ldx tmp2
        lda ColorMap,x
        ldx tmp3
        sta RunVal,y
        lda tmp
        sec
        sbc #2
        sta tmp
        iny
        dex
        bne -
        iny                     ; (8 entries, as the cached path counts)
        sty runI
        ldy runH                ; the changes: line 223 + j (j = 1-6) against the line two
        ldx RunFirst,y          ; before (the same register; $D021 before line 224 holds the
        lda #0                  ; background)
        sta tmp                 ; (first)
        sta tmp2                ; (last)
        lda BgColour
        lsr
        tay
        lda ColorMap,y
        sta tmp3                ; ($D021)
        lda RunVal,x
        sta tmp4                ; ($D023)
        ldy #1
-       lda RunVal+1,x
        cpy #1
        beq ++
        cpy #3
        beq ++
        cpy #5
        beq ++
        cmp tmp4                ; (even j: $D023)
        sta tmp4
        jmp +++
+
+       cmp tmp3                ; (odd j: $D021)
        sta tmp3
+       beq +
        sty tmp2
        lda tmp
        bne +
        sty tmp
+       inx
        iny
        cpy #7
        bne -
        ldy runH
        lda tmp
        sta RunSkip,y
        beq +
        lda tmp2
        sec
        sbc tmp
        clc
        adc #1
+       clc
        adc #1                  ; (and line 223's)
        sta RunCnt,y
_entry  lda runH                ; (its entry goes in last: SchedGroundAdd)
        sta gndRun
        inc runH
        rts
; the ground run's entry, after the others (the schedule is kept in raster order, so adding
; the last line's entry last saves moving it each time one goes in before it)
SchedGroundAdd:
        ldy gndRun
        lda #220+LINE2RAS       ; (3 lines early: its setup takes ~1.7 lines after the interrupt's
                                ; entry, and line 225's write falls on a bad line, raster 235,
                                ; which leaves the CPU no time once it is reached late; demon
                                ; bands, the last users of $D022 / $D023, end above line 190)
        ldx #S_GND
        jmp SchedAdd

; the ground's characters: rows 22 (line 223 last), 23 (lines 224-231), 24: "10" on odd
; lines and from line 230 on (the ground below its colour bands keeps line 229's)
GroundChars: .byte 0, 0, 0, 0, 0, 0, 0, $aa
            .byte 0, $aa, 0, $aa, 0, $aa, $aa, $aa
            .byte $aa, $aa, $aa, $aa, $aa, $aa, $aa, $aa
; the bunkers' characters' lines that are odd ground lines (row 22: 7; row 23: 1, 3, 5-7)
BunkOdd:    .byte 7, 8+1, 8+3, 8+5, 8+6, 8+7
SchedBase:  .byte 0, NSCHED
RunBase:    .byte 0, NRUN
RunHBase:   .byte 0, NRUNS
SetBase:    .byte 0, NSETS
SprBlkNum:  .byte BLK_SET, BLK_SET+NBLK
BlkLo:      .for b = 0, b < 64, b += 1      ; sprite block addresses by block number
            .byte <(VICBANK + 64 * b)
            .next
BlkHi:      .for b = 0, b < 64, b += 1
            .byte >(VICBANK + 64 * b)
            .next
Mul4:       .byte 0, 4
; bullets: line X's row in the four blocks (they follow one another): segment, row
BulOfs:     .for x = 0, x < 80, x += 1
            .byte ((79 - x) / 20) * 64 + 3 * ((79 - x) % 20)
            .next
BulBlkLo:   .byte <(VICBANK + 64 * (BLK_SET + B_BULLETS)), <(VICBANK + 64 * (BLK_SET + NBLK + B_BULLETS))
BulBlkHi:   .byte >(VICBANK + 64 * (BLK_SET + B_BULLETS)), >(VICBANK + 64 * (BLK_SET + NBLK + B_BULLETS))
Mul24:      .byte 0, 24
BulSplit:   .byte 100, 103, 118, 121
; the explosion's lines (X) and rows; shift tables by 0-7 pixels: the byte, the next byte
PcLine:     .byte 0, 7, 8, 15, 16, 23, 24, 31, 32
PcRow:      .byte 0, 1, 1, 2, 2, 3, 3, 4, 4
PcShRLo:    .byte <Ident, <BShR1, <BShR2, <BShR3, <BShR4, <BShR5, <BShR6, <BShR7
PcShRHi:    .byte >Ident, >BShR1, >BShR2, >BShR3, >BShR4, >BShR5, >BShR6, >BShR7
PcShLLo:    .byte <Zero256, <BShL1, <BShL2, <BShL3, <BShL4, <BShL5, <BShL6, <BShL7
PcShLHi:    .byte >Zero256, >BShL1, >BShL2, >BShL3, >BShL4, >BShL5, >BShL6, >BShL7
Ident       = $0700             ; (b at b: InitTables)
Zero256:    .fill 256, 0
Mul10:      .byte 0, 10
RowOfsA:    .for i = 0, i < 10, i += 1          ; row i's groups' first lines (X = 8i+7, 8i+3)
            .byte ((72 - 8 * i) / 20) * 64 + 3 * ((72 - 8 * i) % 20)
            .next
RowOfsB:    .for i = 0, i < 10, i += 1
            .byte ((76 - 8 * i) / 20) * 64 + 3 * ((76 - 8 * i) % 20)
            .next
