; ============================================================= collisions
; What the TIA would have seen while the 2600 drew the frame, from the rules in
; tools/model.js (which match the 2600 pixel for pixel, timing quirks included):
;   CXPPMM bit 7 (P0-P1), CXP0FB bit 6 (P0-laser), CXP1FB bit 6 (P1-laser) at the end of
;   the frame, and what the kernel reads part-way down: $DC (P0-P1 in the demon bands)
;   and, when the demons shoot bullets, $BF (P1-laser in the demon bands).
; Also the rest of the RAM the kernel leaves changed (and the Y register), and for
; Render: each band's positions and graphics (bX0 ...) and where the laser shows
; (LaserTop, LaserN, LaserRow).
;
; Objects are handled as "pixel order" bytes: bit 7 is the object's leftmost pixel.
; Positions are pixel columns 0-159; an object can wrap round from 159 to 0. Two objects
; are only compared line by line when they are close enough to touch.
Collide:
        jsr BandSetup
        lda #0
        sta midPP
        sta p0bl
        sta p1blMid
        sta p1blEnd
        ldx #2                  ; P0-P1 in the demon bands (once is enough)
-       jsr BandPP
        lda midPP
        bne +
        dex
        bpl -
+       lda midPP
        sta endPP
        jsr CannonSetup
        lda endPP
        bne +
        jsr CannonPP            ; ... and in the cannon band
+       jsr BallLines           ; the laser against both, line by line

        ; the collision registers, as the game reads them
        lda #0
        ldx endPP
        beq +
        lda #$80
+       sta CXPPMM
        lda #0
        ldx midPP
        beq +
        lda #$80
+       sta $dc                 ; CXPPMM as read when the cannon band starts
        lda #0
        ldx p0bl
        beq +
        lda #$40
+       sta CXP0FB
        lda p1blMid
        ora p1blEnd
        beq +
        lda #$40
+       sta CXP1FB
        ; the RAM the kernel leaves changed
        lda #3                  ; $BF: the band counter, or CXP1FB read when the cannon band
        ldx cMode               ; starts (the bullets kernel)
        bne +
        lda #0
        ldx p1blMid
        beq +
        lda #$40
+       sta $bf
        lda bP0+2               ; $C0/$C1: graphics pointer
        ldx #>DemonGfx
        ldy cMode
        beq +
        lda sdPtr
        dey
        beq +
        lda pcPtr               ; (the explosion: pieces in page $1D)
        ldx #>PiecePtr
+       sta $c0
        stx $c1
        lda bP1+2
        sta $c2
        lda #>DemonGfx
        sta $c3
        lda DemonY+2
        sta $c4
        lda $e7                 ; (the score's last digit pointer, for Render)
        sta scoreE7
        lda GroundColour        ; the ground's last colour band
        and ColourMask
        sec
        sbc #12
        sta $e7
        ldx Player              ; Y: the kernel's last "ldy Lives,x" (player 1's in a co-op game)
        bit CoOp
        bpl +
        ldx #0
+       lda Lives,x
        sta kernelY
        rts

; ---------------------------------------------------------------- bands
; Per band: pixel columns, width (8, or 32 when materializing: NUSIZ 7), graphics
; (low bytes into page $1E: 8 bytes per shape, bottom row first) and the demon's line.
BandSetup:
        ldy P0Pos+0
        lda PosX,y
        sta bX0+0
        ldy P1Pos+0
        lda PosX,y
        sta bX1+0
        ldy P0Shape+0
        lda Times8,y
        sta bP0+0
        ldy P1Shape+0
        lda Times8,y
        sta bP1+0
        ldy P0Pos+1
        lda PosX,y
        sta bX0+1
        ldy P1Pos+1
        lda PosX,y
        sta bX1+1
        ldy P0Shape+1
        lda Times8,y
        sta bP0+1
        ldy P1Shape+1
        lda Times8,y
        sta bP1+1
        ldy P0Pos+2
        lda PosX,y
        sta bX0+2
        ldy P1Pos+2
        lda PosX,y
        sta bX1+2
        ldy P0Shape+2
        lda Times8,y
        sta bP0+2
        ldy P1Shape+2
        lda Times8,y
        sta bP1+2
        ldx Growing             ; (the materializing band: four times as wide; the widths
        cpx bGrow               ; change only with it)
        beq _same
        stx bGrow
        lda #8
        sta bW+0
        sta bW+1
        sta bW+2
        lda #0
        sta bSh+0
        sta bSh+1
        sta bSh+2
        cpx #3
        bcs _same
        lda #32
        sta bW,x
        lda #2
        sta bSh,x
_same   rts
Times8:     .for i = 0, i < 32, i += 1
            .byte 8 * i
            .next

; P0-P1 in band X, on its eight lines (rows 7-0). Player 1 is reflected; its GRP1 is
; written at pixel 19: left of that a line still shows the line above's row (blank above
; row 7).
BandPP:
        stx band
        lda bX1,x
        sec
        sbc bX0,x
        bcs +
        adc #160
+       sta oD                  ; P1 starts oD pixels after P0 (mod 160): can they touch?
        ldy bW,x
        sty oW
        cmp oW
        bcc +
        lda #160
        sec
        sbc oW
        cmp oD
        bcc +
        rts
+       lda bP0,x
        ora #7
        sta r0                  ; row 7
        lda bP1,x
        ora #7
        sta r1
        lda #8
        sta cnt
        lda bW,x
        cmp #8
        beq +
        jmp _quad
+
        lda bP1,x               ; normal width: a byte each, rows 7-0 by Y (the players'
        sta _qf1+1              ; graphics addresses put in)
        sta _qb1+1
        lda bP0,x
        sta _qf0+1
        sta _qb0+1
        lda bX1,x
        ldx #19
        jsr Split8
        sta sm
        lda #0
        sta prev1
        lda oD                  ; player 1 shifted right by oD (or player 0 by 160 - oD): a
        cmp #8                  ; jump into the shifts
        bcs _back
        sta tmp
        lda #<_fs0
        sec
        sbc tmp
        sta _qfj+1
        lda #>_fs0
        sbc #0
        sta _qfj+2
        ldy #7
_frow
_qf1    ldx DemonGfx,y          ; player 1's row, pixel order; the line above's left of 19
        lda Reverse,x
        tax
        eor prev1
        and sm
        stx prev1
        sta tmp
        txa
        eor tmp
_qfj    jmp _fs0
        .rept 7
        lsr
        .endrept
_fs0
_qf0    and DemonGfx,y
        bne _hit
        dey
        bpl _frow
        ldx band
        rts
_back   lda #160
        sec
        sbc oD
        sta tmp
        lda #<_bs0
        sec
        sbc tmp
        sta _qbj+1
        lda #>_bs0
        sbc #0
        sta _qbj+2
        ldy #7
_brow
_qb1    ldx DemonGfx,y
        lda Reverse,x
        tax
        eor prev1
        and sm
        stx prev1
        sta tmp
        txa
        eor tmp
        sta tmp
_qb0    lda DemonGfx,y
_qbj    jmp _bs0
        .rept 7
        lsr
        .endrept
_bs0    and tmp
        bne _hit
        dey
        bpl _brow
        ldx band
        rts
_hit    lda #1
        sta midPP
        ldx band
        rts

_quad   lda bX1,x               ; four times as wide: P1 from pixel 19 to 128 (no row mixed
        cmp #19                 ; with the line above's): on the graphics bytes, each bit four
        bcc +                   ; pixels; one starting d = 4q + r pixels after the other, its
        cmp #129                ; bit i can meet the other's i + q, and i + q + 1 when r > 0:
        bcc ++                  ; (b >> q | (r ? b >> (q + 1) : 0)) & other
+       jmp _qold
+
        lda oD
        cmp #32
        bcs +
        ldy bP0,x               ; player 1 after player 0: player 1 shifted
        sty _qq0+1
        ldy bP1,x
        sty _qq1+1
        ldy #<Ident
        sty _qt0+1
        ldy #>Ident
        sty _qt0+2
        ldy #<Reverse
        sty _qt1+1
        ldy #>Reverse
        sty _qt1+2
        jmp ++
+       ldy bP1,x               ; player 0 after player 1 (160 - oD): player 0 shifted
        sty _qq0+1
        ldy bP0,x
        sty _qq1+1
        ldy #<Reverse
        sty _qt0+1
        ldy #>Reverse
        sty _qt0+2
        ldy #<Ident
        sty _qt1+1
        ldy #>Ident
        sty _qt1+2
        eor #$ff                ; (160 - oD)
        sec
        adc #160
+       tay                     ; d = 4q + r
        and #3
        cmp #1
        lda #0
        sbc #0                  ; (r > 0: $ff)
        eor #$ff
        sta _qqm+1
        tya
        lsr
        lsr
        sta tmp
        lda #<_qs0
        sec
        sbc tmp
        sta _qqj+1
        lda #>_qs0
        sbc #0
        sta _qqj+2
        ldy #7
_qfr
_qq0    ldx DemonGfx,y          ; the other one's row
_qt0    lda Ident,x
        beq _qfn
        sta tmp
_qq1    ldx DemonGfx,y          ; the shifted one's
_qt1    lda Reverse,x
_qqj    jmp _qs0
        .rept 7
        lsr
        .endrept
_qs0    sta tmp2
        lsr
_qqm    and #0
        ora tmp2
        and tmp
        beq _qfn
        jmp _hit
_qfn    dey
        bpl _qfr
        ldx band
        rts
_qold   lda #0                  ; (P1's left of pixel 19 a byte (8 pixels) at a time)
        sta smAny
        lda bX1,x
        cmp #19
        bcc +
        cmp #129
        bcs +
        lda #0
        sta tq
        sta tq+1
        sta tq+2
        sta tq+3
        beq _qrow
+       sta tmp2
        inc smAny
        ldx #0
-       stx tmp3
        lda tmp2
        ldx #19
        jsr Split8
        ldx tmp3
        sta sm,x
        lda tmp2
        clc
        adc #8
        cmp #160
        bcc +
        sbc #160
+       sta tmp2
        inx
        cpx #4
        bne -
        lda #0
        sta tq
        sta tq+1
        sta tq+2
        sta tq+3
_qrow   ldy r0                  ; (player 0 blank on this row: nothing to touch, but the row
        lda DemonGfx,y          ; still becomes the next one's line above)
        bne +
        lda smAny
        beq _qnext
        ldy r1
        ldx DemonGfx,y
        lda Reverse,x
        ldy #2
        jsr ExpandB
        ldx #3
-       lda oB,x
        sta tq,x
        dex
        bpl -
        jmp _qnext
+       ldy r1
        ldx DemonGfx,y
        lda Reverse,x
        ldy #2
        jsr ExpandB             ; this row, 32 pixels
        lda smAny
        beq _qa
        ldx #3                  ; the line above's where sm says (and keep this row)
-       lda oB,x
        tay
        eor tq,x
        and sm,x
        sta tmp
        tya
        sta tq,x
        eor tmp
        sta oB,x
        dex
        bpl -
_qa     ldy r0
        lda DemonGfx,y
        ldy #2
        jsr ExpandA
        jsr Overlap
        beq _qnext
        jmp _hit
_qnext  dec r0
        dec r1
        dec cnt
        bne _qrow
        ldx band
        rts

; ------------------------------------------------------------ cannon band
; cMode: 0 the demons' bullets, 1 a small demon diving, 2 the cannon exploding
CannonSetup:
        ldy P0Pos+3
        lda PosX,y
        sta cX0
        ldy P1Pos+3
        lda PosX,y
        sta cX1
        ldx #2
        lda Dying
        bne +
        dex
        lda WaveFlags
        bpl +
        dex
+       stx cMode
        lda SmallShape          ; the small demon's graphics
        asl
        asl
        asl
        sta sdPtr
        lda #>DemonGfx
        sta sdPtr+1
        lda Dying               ; the explosion's pieces
        and #$38
        lsr
        lsr
        lsr
        tay
        lda PiecePtr,y
        sta pcPtr
        lda #>PiecePtr
        sta pcPtr+1
        rts

; The pieces' graphics on cannon-band line X (A): written at the start of the line,
; worked out on the line before (X+1): every 8 lines two lines, rows 0-4
PieceAt:
        clc
        adc #1
        tay
        and #6
        bne _none
        tya
        lsr
        lsr
        lsr
        cmp #5
        bcs _none
        tay
        lda (pcPtr),y
        rts
_none   lda #0
        rts

; The bullets' graphics on cannon-band line X (A): row X/8, or nothing on the dashes' gaps
; (and nothing above the cannon band: GRP1 is still the last band's blank row 0)
BulletRow:
        cmp #$50
        bcs _none
        cmp bC+2
        bcs _none
        tay
        eor #$ff
        eor Frame
        and DashMask
        bne _none
        tya
        lsr
        lsr
        lsr
        tay
        lda Bullets,y
        rts
_none   lda #0
        rts

; The small demon's graphics on cannon-band line X (A), row X - $C8 (0 outside rows 0-7)
SmallAt:
        sec
        sbc SmallY
        cmp #8
        bcs _none
        tay
        lda (sdPtr),y
        rts
_none   lda #0
        rts

; is the laser on, by the write on line X (A)? -> Z set: on
LaserOnX:
        sec
        sbc LaserY
        and #$f8
        rts
; ... -> A = 1 on, 0 off
LaserOn:
        jsr LaserOnX
        beq +
        lda #0
        rts
+       lda #1
        rts

; P0-P1 in the cannon band
CannonPP:
        lda cX1
        sec
        sbc cX0
        bcs +
        adc #160
+       sta oD
        lda #8
        sta oW
        jsr CanTouch
        bcs +
        rts
+       lda cMode
        cmp #1
        beq _small
        bcc +
        jmp _boom
+
        ; the bullets against the cannon (lines 11-0); GRP1 written at pixel 118 (121 when
        ; that line turns the laser on): left of it, the line above's bullets
        lda Bullets             ; (only rows 0-1 reach those lines)
        ora Bullets+1
        bne +
        rts
+       lda #11
        sta lnX
_bl     lda lnX
        jsr LaserOnX            ; (Z set: on; LDX would change the flags)
        php
        ldx #118
        plp
        bne +
        ldx #121
+       lda cX1
        jsr Split8
        sta sm
        lda lnX
        clc
        adc #1
        jsr BulletRow
        sta tq
        lda lnX
        jsr BulletRow
        jsr MixByte
        jsr CannonOverlap
        bne _hit
        dec lnX
        bpl _bl
        rts
_small  lda SmallY              ; the small demon against the cannon (only if it reaches lines
        cmp #13                 ; 12-0): GRP1 written at pixel 28
        bcc +
        rts
+       lda cX1
        ldx #28
        jsr Split8
        sta sm
        lda #11
        sta lnX
_sl     lda lnX
        clc
        adc #1
        jsr SmallAt
        sta tq
        lda lnX
        jsr SmallAt
        jsr MixByte
        jsr CannonOverlap
        bne _hit
        dec lnX
        bpl _sl
        rts
_hit    lda #1
        sta endPP
        rts
_boom   lda #8                  ; the explosion's pieces (only on lines 32, 31 .. 7, 0), P1
        sta tmp4                ; reflected (but not right of pixel 136 on the last line)
_xl     ldx tmp4
        lda PcLine,x
        sta lnX
        jsr PieceAt
        beq _xn
        sta oA
        tax
        lda Reverse,x
        sta oB
        lda lnX
        bne +
        lda oB
        sta tq
        lda cX1
        ldx #136
        jsr Split8
        sta sm
        lda oA
        jsr MixByte
        sta oB
+       jsr Overlap8
        bne _hit
_xn     dec tmp4
        bpl _xl
        rts

; A, except where sm says: there tq (the line above's graphics, or the other reflection)
MixByte:
        sta tmp
        eor tq
        and sm
        eor tmp
        rts

; player 1 = A against the cannon on line lnX (nothing from line 12 up)
CannonOverlap:
        sta oB
        lda #0
        ldx lnX
        cpx #12
        bcs +
        lda CannonGfx,x
+       sta oA
        jmp Overlap8

; ------------------------------------------------------------ the laser
; ENABL is written on every band line and every cannon-band line (the positioning lines
; write nothing), "on" for X = $95 .. $95+7, landing part-way along the line: left of
; that pixel the line still shows the earlier value. So the laser shows on one run of
; lines: from the first write that turns it on (or the line after, if its pixel is left
; of where that write lands) to the write that turns it off (if its pixel is left of where
; that lands; else the line before). Demon bands: line = 217 - X; cannon band: 220 - X.
BallLines:
        ldy LaserX
        lda BallX,y
        sta bx
        lda #0
        sta LaserN
        lda #218                ; the first line below the demon bands
        sec
        sbc bC+2
        sta demonEnd
        lda LaserY              ; the write that turns it on: the last write at or below
        clc                     ; X = $95 + 7, if that's still $95 or above
        adc #7
        jsr WriteX
        cmp LaserY
        bcs +
        rts                     ; (never on)
+       jsr XLine
        sta lnL
        jsr ClassifyLine
        lda bx
        cmp lnSp
        lda lnL
        bcs +
        adc #1                  ; (carry clear)
+       sta LaserTop
        lda LaserY              ; the write that turns it off: the last at or below $95 - 1
        sec
        sbc #1
        bcs +
        lda #220                ; (never off: to the bottom of the cannon band)
        bne ++
+       jsr WriteX
        jsr XLine
        sta lnL
        jsr ClassifyLine
        lda bx
        cmp lnSp
        lda lnL
        bcc +
        sbc #1                  ; (carry set)
+       sta lnEnd
        sec
        sbc LaserTop
        bcs +
        rts                     ; (no line)
+       cmp #20                 ; (at most 21 lines)
        bcc +
        lda #20
+       clc
        adc #1
        sta LaserN
        ; every line shows it, unless something is in front of it: only where a player's
        ; lines and column meet the laser's are they tested
        lda #$80                ; (all 21: Render uses the first LaserN)
        sta LaserRow+0
        sta LaserRow+1
        sta LaserRow+2
        sta LaserRow+3
        sta LaserRow+4
        sta LaserRow+5
        sta LaserRow+6
        sta LaserRow+7
        sta LaserRow+8
        sta LaserRow+9
        sta LaserRow+10
        sta LaserRow+11
        sta LaserRow+12
        sta LaserRow+13
        sta LaserRow+14
        sta LaserRow+15
        sta LaserRow+16
        sta LaserRow+17
        sta LaserRow+18
        sta LaserRow+19
        sta LaserRow+20
        lda LaserTop
        clc
        adc LaserN
        sta lnEnd               ; (the line after its last)
        jsr AnyUnder
        lda lowBall             ; the HMOVE lines blank pixels 0-7
        beq _bands
        lda #54
        jsr _hide
        ldx #2
-       stx band
        lda #220
        sec
        sbc bC,x
        jsr _hide
        ldx band
        dex
        bpl -
_bands  ldx #2                  ; each band's rows (7..0: lines 210 - C .. 217 - C) that the
_band   lda #217                ; laser's lines reach: the players' bits in its column
        sec
        sbc bC,x
        cmp LaserTop
        bcc _skip               ; (row 0 above its first line)
        sbc #7
        cmp lnEnd
        bcc +
_skip   jmp _nextb              ; (row 7 past its last)
+
        jsr Under
        lda m0,x
        ora m1,x
        beq _nextb
        stx band
        lda #210
        sec
        sbc bC,x
        cmp LaserTop
        bcs +
        lda LaserTop
+       sta lnL
_bline  lda lnL
        cmp lnEnd
        bcs _nextb2
        sta tmp
        lda #217
        sec
        sbc bC,x
        sec
        sbc tmp
        bcc _nextb2             ; (past row 0)
        sta lnRow               ; row = (217 - C) - line
        lda m0,x                ; player 0
        beq _b1
        lda bP0,x
        ora lnRow
        tay
        lda DemonGfx,y
        and m0,x
        beq _b1
        sta p0bl
        jsr _hit
_b1     lda m1,x                ; player 1, reflected; left of pixel 19 the line above's row
        beq _bnext
        lda bP1,x
        ora lnRow
        tay
        lda bx
        cmp #19
        bcs +
        iny
+       lda DemonGfx,y
        and m1,x
        beq _bnext
        sta p1blMid
        jsr _hit
_bnext  inc lnL
        jmp _bline
_nextb2 ldx band
_nextb  dex
        bmi +
        jmp _band
+       lda c0m                 ; the cannon band: lines 221 - C7 .. 220
        ora c1m
        beq _done
        lda #221
        sec
        sbc bC+2
        cmp LaserTop
        bcs +
        lda LaserTop
+       ldx c1m                 ; (only the cannon there: its lines 11-0 only, 209 on)
        bne +
        ldx cMode
        cpx #2
        beq +
        cmp #209
        bcs +
        lda #209
+       sta lnL
_cline  lda lnL
        cmp lnEnd
        bcs _done
        cmp #221
        bcs _done
        lda #220
        sec
        sbc lnL
        sta lnX
        jsr CannonAtBall
        lda lnP0
        beq +
        sta p0bl
        jsr _hit
+       lda lnP1
        beq +
        sta p1blEnd
        jsr _hit
+       inc lnL
        jmp _cline
_done   rts
; line lnL: something in front of the laser
_hit    lda lnL
; line A: the laser isn't shown there
_hide   sec
        sbc LaserTop
        bcc +
        cmp LaserN
        bcs +
        tay
        lda #0
        sta LaserRow,y
+       rts

; A = an X: the X of the last write at or below it (band k's positioning lines take
; X = C(k-1)-1 .. C(k-1)-3; band 0's 163-165)
WriteX:
        cmp #163
        bcc +
        lda #162
        rts
+       sta tmp                 ; (X in Ck-3 .. Ck-1: Ck - 4; bands 0 and 1)
        lda bC
        sec
        sbc tmp
        beq +
        bcc +
        cmp #4
        bcs +
        lda bC
        sec
        sbc #4
        sta tmp
+       lda bC+1
        sec
        sbc tmp
        beq +
        bcc +
        cmp #4
        bcs +
        lda bC+1
        sec
        sbc #4
        sta tmp
+       lda tmp
        rts

; A = a write's X: its line
XLine:
        cmp bC+2
        bcc +
        eor #$ff                ; 217 - X
        sec
        adc #217
        rts
+       eor #$ff                ; 220 - X
        sec
        adc #220
        rts

; Which players' spans the laser's column crosses in the cannon band: c0m/c1m/c1r (the
; graphics bit for that column; c1r for a reflected player 1). lowBall: the laser in pixels
; 0-7 (the HMOVE blank). (The demon bands' m0/m1: Under, for the bands the laser reaches.)
AnyUnder:
        lda #0
        ldx bx
        cpx #8
        rol
        eor #1
        sta lowBall
        lda bx                  ; the cannon band (8 wide)
        sec
        sbc cX0
        bcs +
        adc #160
+       ldy #0
        cmp #8
        bcs +
        tax
        ldy BitHi,x
+       sty c0m
        lda bx
        sec
        sbc cX1
        bcs +
        adc #160
+       ldy #0
        sty c1r
        cmp #8
        bcs +
        tax
        lda BitLo,x
        sta c1r
        ldy BitHi,x
+       sty c1m
        rts
; ... band X's: m0/m1 (X kept)
Under:
        lda bx
        sec
        sbc bX0,x
        bcs +
        adc #160
+       cmp bW,x
        bcs _n0
        ldy bSh,x               ; (four times as wide: a bit per four pixels)
        beq +
        lsr
        lsr
+       tay
        lda BitHi,y
        .byte $2c               ; (skips the next)
_n0     lda #0
        sta m0,x
        lda bx
        sec
        sbc bX1,x
        bcs +
        adc #160
+       cmp bW,x
        bcs _n1
        ldy bSh,x
        beq +
        lsr
        lsr
+       tay
        lda BitLo,y
        .byte $2c
_n1     lda #0
        sta m1,x
        rts

; lnL -> lnZone (0 nothing there, 1 a demon band row: band, lnRow; 2 the cannon band:
; lnX), lnNotch (an HMOVE line)
ZoneLine:
        lda #0
        sta lnZone
        sta lnNotch
        lda lnL
        cmp demonEnd
        bcs _below
        lda #217
        sec
        sbc lnL
        sta lnX
        ldx #0
        ldy #166
        cmp bC
        bcs _found
        inx
        ldy bC
        cmp bC+1
        bcs _found
        inx
        ldy bC+1
_found  stx band
        tya
        sec
        sbc #3
        cmp lnX
        beq _notch
        bcc _rts
        lda lnX
        sec
        sbc bC,x
        cmp #8
        bcs _rts
        sta lnRow
        inc lnZone
        rts
_below  lda #220
        sec
        sbc lnL
        sta lnX
        lda #220
        sec
        sbc bC+2
        cmp lnL
        beq _notch
        bcs _rts
        lda #2
        sta lnZone
        rts
_notch  inc lnNotch
_rts    rts

; What happens to the ball on line lnL. -> lnWrite (an ENABL write), lnOn (its value:
; 1 on), lnSp (the pixel it lands on), lnZone (0 nothing to hit, 1 a demon band row:
; band, lnRow; 2 the cannon band: lnX), lnNotch (an HMOVE line)
ClassifyLine:
        lda #0
        sta lnWrite
        sta lnZone
        sta lnNotch
        lda lnL
        cmp #221
        bcc +
        rts                     ; below the cannon band
+
        cmp demonEnd
        bcs _below
        lda #217                ; a demon band: X = 217 - line, band k: the lowest with X >= Ck
        sec
        sbc lnL
        sta lnX
        ldx #0
        ldy #166                ; (above band 0: its positioning lines, X 163-165)
        cmp bC
        bcs _found
        inx
        ldy bC
        cmp bC+1
        bcs _found
        inx
        ldy bC+1
_found  stx band
        tya                     ; the band's positioning lines: X = prev-1 .. prev-3 (HMOVE)
        sec
        sbc #3
        cmp lnX
        beq _notch
        bcc _rts
        inc lnWrite             ; a band line: drawing if X - C < 8
        lda lnX                 ; (the laser on by this line's write: 1)
        sec
        sbc LaserY
        and #$f8
        cmp #1
        lda #0
        rol
        eor #1
        sta lnOn
        lda lnX
        sec
        sbc bC,x
        cmp #8
        bcs _nodraw
        sta lnRow
        inc lnZone
        lda #103                ; ENABL lands at pixel 103 (off) or 106 (on) ...
        bne _sp
_nodraw lda #28                 ; ... 28 / 31 on lines without a demon row
_sp     ldy lnOn
        beq +
        clc
        adc #3
+       sta lnSp
        rts
_below  lda #220                ; band 3's positioning lines (HMOVE on 220 - C7), then the
        sec                     ; cannon band: X = 220 - line
        sbc lnL
        sta lnX
        lda #220
        sec
        sbc bC+2
        cmp lnL
        beq _notch
        bcs _rts
        jmp CannonLine
_notch  inc lnNotch
_rts    rts

; a cannon-band line: X in lnX
CannonLine:
        lda #2
        sta lnZone
        inc lnWrite
        lda lnX                 ; (the laser on by this line's write: 1)
        sec
        sbc LaserY
        and #$f8
        cmp #1
        lda #0
        rol
        eor #1
        sta lnOn
        lda cMode
        cmp #1
        beq _small
        bcs _boom
        ldx lnOn                ; bullets: written at pixel -2 / 1, or 16 / 19 on the cannon's lines
        lda lnX
        cmp #12
        bcs +
        inx
        inx
+       lda BulSp,x
        sta lnSp
        rts
_boom   ldx #1                  ; the explosion: 1 / 4
        lda lnOn
        beq +
        ldx #4
+       stx lnSp
        rts
_small  ldx #0                  ; the small demon: depends on the cannon and the demon
        lda lnX
        cmp #12
        bcc +
        ldx #4
+       lda lnX
        sec
        sbc SmallY
        cmp #8
        bcs +
        inx
        inx
+       txa
        ora lnOn
        tax
        lda SmallSp,x
        sta lnSp
        rts
BulSp:      .byte 0, 1, 16, 19
; split pixels (off, on): cannon & no row, cannon & row, no cannon & no row, no cannon & row
SmallSp:    .byte 58, 61, 103, 106, 40, 43, 85, 88

; The cannon band's players under the laser (pixel bx) on line X = lnX -> lnP0, lnP1
CannonAtBall:
        lda #0
        sta lnP1
        lda c0m                 ; player 0: the cannon (lines 11-0) or a piece
        beq _p1
        lda cMode
        cmp #2
        bne +
        lda lnX
        jsr PieceAt
        jmp ++
+       lda #0
        ldx lnX
        cpx #12
        bcs +
        lda CannonGfx,x
+       and c0m
_p1     sta lnP0
        lda c1m                 ; player 1
        beq _rts
        lda cMode
        cmp #1
        beq _sm
        bcs _pc
        lda lnX                 ; bullets: left of where GRP1 is written, the line above's
        jsr LaserOnX            ; (Z set: on; LDX would change the flags)
        php
        ldx #100
        plp
        bne +
        ldx #103
+       lda lnX
        cmp #12
        bcs +
        txa
        adc #18
        tax
+       stx tmp
        lda bx
        cmp tmp
        lda lnX
        bcs +
        adc #1                  ; (carry clear)
+       jsr BulletRow
        and c1m
        sta lnP1
_rts    rts
_sm     ldx #10                 ; small demon: GRP1 written at pixel 10, 28 on the cannon's lines;
        lda lnX                 ; left of it, the line above's row (on lines that draw no
        cmp #12                 ; row, both are blank)
        bcs +
        ldx #28
+       stx tmp
        lda bx
        cmp tmp
        lda lnX
        bcs +
        adc #1                  ; (carry clear)
+       jsr SmallAt
        and c1m
        sta lnP1
        rts
_pc     lda lnX                 ; the pieces: reflected, but not right of pixel 136 on line 0
        jsr PieceAt
        ldx lnX
        bne +
        ldx bx
        cpx #136
        bcc +
        and c1m                 ; unreflected
        sta lnP1
        rts
+       and c1r
        sta lnP1
        rts

; ------------------------------------------------------------ helpers
; A = pixel offset into a player: the graphics bit for it (/4 when four times as wide: Y = 2)
ShiftDown:
        cpy #0
        beq +
        lsr
        lsr
+       rts

; Can two objects oW wide, the second oD pixels after the first (mod 160), touch?
; -> carry set: yes
CanTouch:
        lda oD
        cmp oW
        bcc _yes
        lda #160
        sec
        sbc oW
        cmp oD
        bcc _yes
        clc
        rts
_yes    sec
        rts

; A (pixel order) = the pixels of an 8-wide object at pixel A that lie left of pixel X
; (pixel (A + i) mod 160: the ones wrapped round to the left edge count too)
Split8:
        sta smX
        stx smS
        lda #0
        sta smR
        lda smX
        cmp smS
        bcs _wrap
        lda smS                 ; the first split - x pixels
        sec
        sbc smX
        cmp #8
        bcc +
        lda #8
+       tax
        lda LeftMask,x
        sta smR
_wrap   lda smX
        cmp #153
        bcc _done
        lda #160                ; pixels 160 - x .. are at 0 ..: those left of the split
        sec
        sbc smX
        tax
        clc
        adc smS
        cmp #8
        bcc +
        lda #8
+       tay
        lda LeftMask,x
        eor #$ff
        and LeftMask,y
        ora smR
        sta smR
_done   lda smR
        rts

; oA / oB (4 bytes, pixel order) from graphics byte A: as it is (Y = 0), or each bit four
; pixels (Y = 2: NUSIZ 7)
ExpandA:
        ldx #oA
        bne Expand
ExpandB:
        ldx #oB
Expand:
        cpy #0
        bne _quad
        sta $00,x
        lda #0
        sta $01,x
        sta $02,x
        sta $03,x
        rts
_quad   tay
        lda Quad0,y
        sta $00,x
        lda Quad1,y
        sta $01,x
        lda Quad2,y
        sta $02,x
        lda Quad3,y
        sta $03,x
        rts

; Do two 8-pixel objects share a pixel? oA, and oB oD pixels after it (mod 160).
; -> A non-zero (Z clear): yes
Overlap8:
        lda oD
        cmp #8
        bcs _back
        tax
        lda oB
        cpx #0
        beq +
-       lsr
        dex
        bne -
+       and oA
        rts
_back   lda #160
        sec
        sbc oD
        cmp #8
        bcs _no
        tax
        lda oA
-       lsr
        dex
        bne -
        and oB
        rts
_no     lda #0
        rts

; The same for 32-pixel objects (oA, oB: 4 bytes each, oD pixels apart, oW wide)
Overlap:
        lda oD
        cmp oW
        bcs _back
        ldx #3                  ; the second starts oD pixels in: shift it right by oD
-       lda oB,x
        sta osh,x
        lda oA,x
        sta oth,x
        dex
        bpl -
        lda oD
        jmp _shift
_back   ldx #3                  ; the first starts 160 - oD pixels after the second
-       lda oA,x
        sta osh,x
        lda oB,x
        sta oth,x
        dex
        bpl -
        lda #160
        sec
        sbc oD
_shift  tay                     ; shift osh right by A pixels
        lsr
        lsr
        lsr
        beq _bits
        cmp #4
        bcs _none
        tax
-       lda osh+2
        sta osh+3
        lda osh+1
        sta osh+2
        lda osh
        sta osh+1
        lda #0
        sta osh
        dex
        bne -
_bits   tya
        and #7
        beq _and
        tax
-       lsr osh
        ror osh+1
        ror osh+2
        ror osh+3
        dex
        bne -
_and    lda osh
        and oth
        sta tmp
        lda osh+1
        and oth+1
        ora tmp
        sta tmp
        lda osh+2
        and oth+2
        ora tmp
        sta tmp
        lda osh+3
        and oth+3
        ora tmp
        rts
_none   lda #0
        rts
