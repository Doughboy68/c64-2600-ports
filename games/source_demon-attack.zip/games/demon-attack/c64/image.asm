; ======================================================= the 2600 program
; The original 4K ROM at $1000, where Imagic assembled it, with these changes:
;   $124E  NOP                   (was TXS: keep the C64's stack)
;   $1251  JSR ClearZP           clear the 2600 RAM, not the C64's zero page
;   $1279  STA $02               (was STA VBLANK: $01 is the C64's memory map)
;   $1282  STA $02               (was STA VSYNC: $00 is the C64's CPU port)
;   $1393  STA $02               (was STA VSYNC)
;   $1877  JMP KernelHook        stop where the 2600 would draw the picture
;   $1C11  JMP Digits2           (a score byte's digit pointers: by table, see main.asm)
; The ticks start at $124B (power-on, after its SEI) and at $187A (after the picture).
ROM = "../build/original.a26"     ; extracted from roms_port by build.cmd
GameImage:
        .binary ROM, $0000, $024e
        nop
        .binary ROM, $024f, $0251-$024f
        jsr ClearZP
        nop
        nop
        .binary ROM, $0256, $027a-$0256
        .byte $02
        .binary ROM, $027b, $0283-$027b
        .byte $02
        .binary ROM, $0284, $0394-$0284
        .byte $02
        .binary ROM, $0395, $0877-$0395
        jmp KernelHook
        .binary ROM, $087a, $0c11-$087a
        jmp Digits2
        .binary ROM, $0c14, $1000-$0c14
        .cerror * - GameImage != $1000, "the 2600 image must be 4K"
        .cerror GameImage != $1000, "the 2600 image must be at $1000"
