; ================================================================== input
; Joystick in port 2: the 2600's left joystick (player 1); port 1: the right one (player 2,
; in two-player games). Keys A / D (left, right) and Space (fire) work as either joystick
; (the players take turns, so whoever is up has them). Console: F1 Game Reset, F2 (F1 with
; shift) power off and on, F3 Game Select, F5 colour/B&W (Demon Attack doesn't read it),
; F7 / F8 left / right difficulty (A: the demons attack more aggressively). Fire starts a
; game by itself in Demon Attack.
ReadInput:
        lda #$ff
        sta $dc02               ; port A output, port B input
        lda #0
        sta $dc03
        lda #$ff
        sta $dc00
        lda $dc00
        sta joyb                ; port 2
        lda $dc01
        sta joyb+1              ; port 1
        eor #$1f                ; (keyboard rows: ignore lines a port 1 joystick pulls low)
        and #$1f
        sta tmp
        lda #$fe
        sta $dc00
        lda $dc01
        ora tmp
        sta Keys+0
        lda #$fd
        sta $dc00
        lda $dc01
        ora tmp
        sta Keys+1
        lda #$fb
        sta $dc00
        lda $dc01
        ora tmp
        sta Keys+2
        lda #$bf
        sta $dc00
        lda $dc01
        ora tmp
        sta Keys+6
        lda #$7f
        sta $dc00
        lda $dc01
        ora tmp
        sta Keys+7
        lda #$ff
        sta $dc00
        ; SWCHA: player 1 (port 2) high nibble, player 2 (port 1) low: up, down, left
        ; (or A), right (or D), 0 = pressed; INPT4 / INPT5 bit 7: fire (or Space)
        lda Keys+1              ; A (row 1, bit 2) -> bit 2, D (row 2, bit 2) -> bit 3
        and #4
        sta tmp
        lda Keys+2
        and #4
        asl
        ora tmp
        ora #$f3
        sta tmp
        lda joyb
        and tmp
        asl
        asl
        asl
        asl
        sta tmp2
        lda joyb+1
        and tmp
        and #$0f
        ora tmp2
        and DbgSWCHA            ; debug overrides, poked from the VICE monitor by tools
        sta SWCHA
        lda Keys+7              ; Space: row 7, bit 4
        and #$10
        sta tmp
        lda joyb
        and tmp
        beq +
        lda #$80
+       and DbgINPT4
        sta INPT4
        lda joyb+1
        and tmp
        beq +
        lda #$80
+       and DbgINPT4
        sta INPT5

        ; console switches (when an F key is down, or was last time: else only SWCHB)
        lda Keys+0
        and PrevKeys
        and #$78
        cmp #$78
        bne _keys
        lda Keys+0
        sta PrevKeys
        lda switches            ; (reset and select up)
        ora #3
        and DbgSWCHB
        sta SWCHB
        rts
_keys   lda Keys+0              ; F5: colour / B&W (on key-down)
        and #$40
        bne +
        lda PrevKeys
        and #$40
        beq +
        lda switches
        eor #$08
        sta switches
+       lda Keys+0              ; F7 / F8: difficulty
        and #$08
        bne +
        lda PrevKeys
        and #$08
        beq +
        lda Keys+1              ; with either shift key (F8): right difficulty
        bpl _right
        lda Keys+6
        and #$10
        beq _right
        lda #$40                ; F7: left difficulty
        bne _tog
_right  lda #$80
_tog    eor switches
        sta switches
+       lda Keys+0
        sta PrevKeys
        jsr PowerKey
        lda switches            ; reset (F1) and select (F3) are held buttons
        and #$fc
        sta tmp
        lda f2now               ; F1 is Game Reset (F2, on the same key, is the power switch)
        bne _rup
        lda Keys+0
        and #$10
        beq _f3
_rup    inc tmp                 ; bit 0 up
_f3     lda Keys+0
        and #$20
        beq +
        lda tmp
        ora #2
        sta tmp
+       lda tmp
        and DbgSWCHB
        sta SWCHB
        rts

; F2 (F1 with either shift key): ask for a power cycle on key-down. f2now = F2 held.
PowerKey:
        lda #0
        sta f2now
        lda Keys+0
        and #$10
        bne _up                 ; F1 key up
        lda Keys+1              ; left shift
        bpl _down
        lda Keys+6              ; right shift
        and #$10
        bne _up
_down   inc f2now
        lda PrevF2
        bne _up
        lda #1
        sta PowerReq
_up     lda f2now
        sta PrevF2
        rts


