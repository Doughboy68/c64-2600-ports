; ================================================================== tables
CharLo:     .for n = 0, n < 256, n += 1     ; character n's data: + 8n (high byte ORed in)
            .byte <(8 * n)
            .next
CharHi:     .for n = 0, n < 256, n += 1
            .byte >(8 * n)
            .next
RowLo:      .for r = 0, r < 25, r += 1      ; screen rows (buffer 0)
            .byte <(SCREEN0 + 40 * r)
            .next
RowHi:      .for r = 0, r < 25, r += 1
            .byte >(SCREEN0 + 40 * r)
            .next
DblHi:      .for g = 0, g < 256, g += 1     ; a graphics byte with each bit two pixels wide
            .byte (g & $80 ? $c0 : 0) | (g & $40 ? $30 : 0) | (g & $20 ? $0c : 0) | (g & $10 ? $03 : 0)
            .next
DblLo:      .for g = 0, g < 256, g += 1
            .byte (g & $08 ? $c0 : 0) | (g & $04 ? $30 : 0) | (g & $02 ? $0c : 0) | (g & $01 ? $03 : 0)
            .next
Mul9:       .byte 0, 9, 18
BitHi:      .byte $80, $40, $20, $10, $08, $04, $02, $01
BitLo:      .byte $01, $02, $04, $08, $10, $20, $40, $80
LeftMask:   .byte $00, $80, $c0, $e0, $f0, $f8, $fc, $fe, $ff   ; the first n pixels
; a graphics byte with each bit four pixels wide (NUSIZ 7), pixel order: bytes 0-3
Quad0:      .for g = 0, g < 256, g += 1
            .byte (g & $80 ? $f0 : 0) | (g & $40 ? $0f : 0)
            .next
Quad1:      .for g = 0, g < 256, g += 1
            .byte (g & $20 ? $f0 : 0) | (g & $10 ? $0f : 0)
            .next
Quad2:      .for g = 0, g < 256, g += 1
            .byte (g & $08 ? $f0 : 0) | (g & $04 ? $0f : 0)
            .next
Quad3:      .for g = 0, g < 256, g += 1
            .byte (g & $02 ? $f0 : 0) | (g & $01 ? $0f : 0)
            .next

; ------------------------------------------------------- variables (RAM)
DbgSWCHA:   .byte $ff           ; AND masks applied to the inputs (testing aid)
DbgINPT4:   .byte $ff
DbgSWCHB:   .byte $ff
DbgBorder:  .byte 0             ; non-zero: colour the border while drawing / running the game
DbgLoops:   .word 0             ; main loop passes
DbgLate:    .word 0             ; ... that found more than one frame gone by
DbgTops:    .byte 0             ; frame tops the interrupt has done
DbgFrames:  .word 0             ; ... (16 bits)
DbgLateRun: .byte 0
DbgMaxOn:   .byte 0             ; non-zero: keep these (they cost about 200 cycles a pass):
DbgRMax:    .word 0             ; the most cycles one pass spent drawing,
DbgTMax:    .word 0             ; ... running the game,
DbgPMax:    .word 0             ; ... in all
dbgT0:      .word 0
dbgT1:      .word 0
dbgNow:     .word 0
dbgTmp:     .word 0
FreqTab:    .word SidFreqLo     ; PAL or NTSC frequency tables
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
SndLast:    .fill 6, $ff

; collisions (collide.asm)
band:       .byte 0
midPP:      .byte 0             ; P0-P1 in the demon bands
endPP:      .byte 0             ; ... anywhere
p0bl:       .byte 0             ; P0-laser
p1blMid:    .byte 0             ; P1-laser in the demon bands
p1blEnd:    .byte 0             ; ... in the cannon band
bX0:        .fill 3             ; per band: player 0's and 1's pixel columns,
bX1:        .fill 3
bW:         .fill 3             ; ... width (8, or 32: materializing),
bSh:        .fill 3             ; ... 0, or 2 (pixels per graphics bit: 4)
bC          = DemonY            ; ... the demon's line ($C5-$C7, as it is),
bGrow:      .byte $fe          ; (the band bW / bSh were set for)
smAny:      .byte 0             ; BandPP: player 1 has pixels left of pixel 19
bP0:        .fill 3             ; ... and its graphics (low bytes into page $1E)
bP1:        .fill 3
r0:         .byte 0
r1:         .byte 0
prev1:      .byte 0
cX0:        .byte 0             ; cannon band: player 0's and 1's pixel columns
cX1:        .byte 0
cMode:      .byte 0             ; 0 bullets, 1 small demon, 2 explosion
oD:         .byte 0             ; Overlap: the second object oD pixels after the first
oW:         .byte 0             ; ... both oW wide
osh:        .fill 4
oth:        .fill 4
tq:         .fill 4
sm:         .fill 4             ; SplitMask's answer
smX:        .byte 0
smW:        .byte 0
smS:        .byte 0
smR:        .byte 0
rowIdx:     .byte 0
cnt:        .byte 0
bx:         .byte 0             ; the laser's pixel column
lowBall:    .byte 0             ; the laser in pixels 0-7
m0:         .fill 3             ; per band: the graphics bit under the laser (0: none)
m1:         .fill 3
c0m:        .byte 0             ; ... in the cannon band
c1m:        .byte 0
c1r:        .byte 0             ; (player 1 reflected)
demonEnd:   .byte 0             ; the first line below the demon bands
lnL:        .byte 0             ; BallLines: the line, ...
lnEnd:      .byte 0
lnI:        .byte 0
lnX:        .byte 0
lnRow:      .byte 0
lnZone:     .byte 0
lnWrite:    .byte 0
lnOn:       .byte 0
lnSp:       .byte 0
lnVis:      .byte 0
lnHit:      .byte 0
lnNotch:    .byte 0
lnP0:       .byte 0
lnP1:       .byte 0
prevC:      .byte 0
scoreE7:    .byte 0             ; $E7 before the kernel (the last digit's pointer)
kernelY:    .byte 0             ; Y as the kernel leaves it
LaserTop:   .byte 0             ; the laser sprite: first line, rows, and what each shows
LaserN:     .byte 0
LaserRow:   .fill 21

; render
SchedRas:   .fill 2 * NSCHED
SchedType:  .fill 2 * NSCHED
SchedArg:   .fill 2 * NSCHED
RunFirst:   .fill 2 * NRUNS     ; colour runs: first line's entry, lines,
RunCnt:     .fill 2 * NRUNS
RunSkip:    .fill 2 * NRUNS     ; ... (the ground) the lines it skips at the start
RunJLo:     .fill 2 * NRUNS     ; ... its code (the variant for its registers),
RunJHi:     .fill 2 * NRUNS
RunRegA:    .fill 2 * NRUNS     ; ... the registers of its even and odd lines,
RunRegB:    .fill 2 * NRUNS
RunSetReg:  .fill 2 * NRUNS     ; ... and a register to set first
RunSetVal:  .fill 2 * NRUNS
NRUN        = 8
RunRas:     .fill 2 * NRUN      ; the ground's colour writes: raster, value
RunVal:     .fill 2 * NRUN
PairX:      .fill 2 * NPAIRS    ; demon sprite pairs moved down (NPAIRS * buffer + record:
PairY:      .fill 2 * NPAIRS    ; 0 band 2 and 1 the cannon band without a plan, then the
                                ; plan's): X, Y of each, blocks, X bit 8, sprites, their bits
PairY2:     .fill 2 * NPAIRS
PairPtr:    .fill 2 * NPAIRS, BLK_BLANK
PairPtr2:   .fill 2 * NPAIRS, BLK_BLANK
PairMsb:    .fill 2 * NPAIRS
PairN:      .for b = 0, b < 2, b += 1
            .byte SPR_PAIR0, SPR_PAIR1
            .fill NPAIRS - 2
            .next
PairBitsR:  .for b = 0, b < 2, b += 1
            .byte $30, $c0
            .fill NPAIRS - 2
            .next
PairRec:    .fill 2             ; the record each pair's next use goes into ($ff: staged)
recI:       .byte 0             ; the plan's next record
ItK:        .fill 4             ; the plan (Classify): each band's kind (and the cannon band's
ItL:        .fill 4             ; demon: 1 drawn), first line, pairs (0-2), pair ($ff: none),
ItN:        .fill 4
ItP:        .fill 4
MoveRas:    .fill 8             ; ... the pairs' moves (raster; after item j, pair p: 2j + p)
plDyn:      .byte 0             ; ... 1: on (else the pairs as always)
plSplit:    .byte 0
plExp:      .byte 0
plConv:     .byte 0             ; ... split bands that may take both pairs (bits), one (a half),
plHalf:     .byte 0
plTaken:    .byte 0             ; ... those that took any, both
plTakenF:   .byte 0
plJ:        .byte 0
plLast:     .fill 2             ; ... each pair's last start (0: none),
plItem:     .fill 2             ; ... its item ($ff: none)
plGap:      .byte 0
plMove:     .byte 0
spPair:     .byte 0             ; the sprite pair being drawn (0: 4-5, 1: 6-7, $ff: none)
runDual:    .byte 0             ; SchedColourRun: 6 both pairs (a split band's), else 0
hfA:        .byte 0             ; a split band's pair for player 0
RunXL:      .fill 2 * NRUNS     ; ... its run's halves' first pixels, left and right (checks)
RunXR:      .fill 2 * NRUNS
hfP:        .byte 0             ; SprHalf: player 0 / 1,
hfPv:       .byte 0             ; ... its pixels in the previous line's colour,
hfG:        .byte 0             ; ... its graphics, its pixels left of 19 (player 1),
hfUp:       .byte 0
HfRow:      .fill 8             ; ... its rows by line
HfDirty:    .fill 6             ; per buffer and band: bytes 1-2 of its blocks' rows drawn
NSETS       = 16
SetReg:     .fill 2 * NSETS
SetVal:     .fill 2 * NSETS
StD018:     .byte D018_0, D018_1
StD021:     .fill 2
StD022:     .fill 2
StD023:     .fill 2
StEn:       .fill 2
StMsb:      .fill 2
StX:        .fill 16            ; sprites 0-7 at the frame top (8 * buffer + sprite)
StY:        .fill 16
StPtr:      .fill 16, BLK_BLANK
StCol:      .fill 16
BulY:       .fill 8             ; bullet segments 2 and 3 (4 * buffer + segment)
BulPtr:     .fill 8

; drawing (render.asm)
DbgDrop:    .byte 0             ; characters or cells that ran out (testing aid)
lic:        .byte 0             ; line within the character row
plL:        .byte 0             ; PlotLine: line, first pixel, bytes, ...
plX:        .byte 0
plN:        .byte 0
plA:        .fill 7             ; ... pixels drawn "01",
plB:        .fill 6             ; ... and "10"
plM:        .byte 0
plC:        .byte 0
plK:        .byte 0
plover:     .byte 0             ; clear the pixels under it first (player 0)
mc:         .fill 14            ; multicolour bytes of the line being drawn
mo:         .fill 14            ; ... and the pixels they cover ("11")
bandL:      .byte 0
bandG:      .byte 0
bandG1:     .byte 0
bandN:      .byte 0
bandPrev:   .byte 0
bandSh:     .byte 0
bandC:      .byte 0
bandAsl:    .byte 0
bunkN:      .byte 0
bunkRow:    .byte 0
bunkG:      .byte 0
bunkX:      .byte 0
bunkC:      .byte 0
bunkS:      .byte 0
spAll:      .fill 8             ; colour split masks: player 0's, player 1's
sp0         = spAll
sp1         = spAll + 4
spOfs:      .byte 0
bulRow:     .byte 0
ScoreKey:   .fill 24            ; the score pointers each buffer's characters show
BunkKey:    .fill 2             ; ... and the bunkers
rstN:       .byte 0             ; cells borrowed this frame (Restore puts them back)
RstLimit:   .byte 0
RstEnd:     .byte 0, NRST
RstLo:      .fill 2 * NRST
RstHi:      .fill 2 * NRST
RstVal:     .fill 2 * NRST
schedI:     .byte 0             ; schedule being built: next entry, first entry
schedB:     .byte 0
runI:       .byte 0
runH:       .byte 0
setI:       .byte 0
saR:        .byte 0
saT:        .byte 0
saA:        .byte 0
in0:        .fill 3             ; SprDemon: each player's pixels in the window,
in1:        .fill 3
pv0:        .fill 3             ; ... those showing the previous line's colour,
pv1:        .fill 3
left19:     .fill 3             ; ... player 1's showing the line above's graphics
swUp:       .byte 0             ; ... any (SprDemon)
SmL19:      .fill 6             ; the small demon's left19 and pv1: on the cannon's lines,
SmPv1:      .fill 6             ; ... and the others (3 bytes each)
smSet:      .byte 0             ; ... which left19 / pv1 hold
pw:         .fill 3             ; Place's answer
p0w:        .fill 3
p1w:        .fill 3
pa:         .fill 4             ; the two sprites' row (+1 spare)
pb:         .fill 3
swX0:       .byte 0
swX1:       .byte 0
swG0:       .byte 0
swG1:       .byte 0
swSmall:    .byte 0
swS:        .byte 0             ; the window's first pixel
swO0:       .byte 0             ; players' offsets in it
swO1:       .byte 0
swBlk:      .byte 0
swR0:       .byte 0
swR1:       .byte 0
swRow:      .byte 0
swL:        .byte 0
spUse:      .byte 0             ; sprite pair use: 0-2 bands, 3 the cannon band
runReg:     .byte 0
tmp4:       .byte 0
prev1b:     .byte 0
sbS0:       .byte 0             ; SmallBand: player 0's pixels left of its colour split,
sbS1:       .byte 0             ; ... player 1's,
sbG:        .byte 0             ; ... player 1's left of pixel 19
sbB1:       .byte 0             ; ... the pixels drawn "10" this line: player 1's,
sbB0:       .byte 0             ; ... player 0's
sbI:        .byte 0
sbN:        .byte 0
sbK:        .byte 0
sbC1:       .byte 0
sbC0:       .byte 0
sbCol:      .byte 0
sbCnt:      .byte 0
hfC:        .byte 0             ; OneBand: the player (0 / 1), its first pixel,
sbX:        .byte 0
sbCo:       .byte 0             ; ... the cell's first and end lines in OneL
sbE2:       .byte 0
OneL:       .fill 24            ; ... its lines, 8 a column (3 columns)
OneM:       .fill 24            ; ... what player 0 doesn't cover
sbW1:       .byte 0             ; ... the columns each player covers (2-3)
sbW0:       .byte 0
sbLN:       .byte 0             ; ... the cells with pixels: how many,
SbLCol:     .fill 6             ; ... their columns,
SbLK1:      .fill 6             ; ... player 1's slices,
SbLK0:      .fill 6             ; ... player 0's
SbAny1:     .fill 3             ; ... any pixels in each slice: player 1's,
            .byte 0             ; (slice 3: none)
SbAny0:     .fill 3             ; ... player 0's
            .byte 0
            .fill (* & $ff) > $100 - 96 ? $100 - (* & $ff) : 0   ; (the slices in one page)
SbP1:       .fill 24            ; ... each line's pixels, three columns of 8 lines a player,
            .fill 8, 0
SbP0:       .fill 24
            .fill 8, 0
SbM0:       .fill 24            ; ... and what player 0 covers, inverted
            .fill 8, $ff
k0:         .byte 0             ; SprAligned: the players' bytes in the window, ...
k1:         .byte 0
pv0b:       .byte 0
pv1b:       .byte 0
l19b:       .byte 0
g0b:        .byte 0
g1b:        .byte 0
pr0:        .byte 0
pr1:        .byte 0
cu0:        .byte 0
cu1:        .byte 0
MapColRev:  .fill 8             ; the demons' colours (C64) this frame, rows 7..0
swBlk2:     .byte 0             ; the pair's second block
bulLim:     .byte 0             ; DrawBullets: the first X without bullets
bulSm:      .fill 4             ; ... the masks left of where GRP1 lands (100, 103, 118, 121)
bulSmX:     .byte $ff           ; the bullets' column bulSm is for ($ff: none yet)
bulSmK:     .byte 2             ; ... bulSm all clear (0), all set (1), mixed (2)
bulMO:      .byte 0             ; ... the dashes: $ff the odd / even groups shown
bulME:      .byte 0
bulRi:      .byte 0             ; ... the row
bulKB:      .byte 0             ; ... this buffer's first key
bulVo:      .byte 0             ; ... the row's groups' values, and their first lines
bulVe:      .byte 0
bulF1:      .byte 0
bulF2:      .byte 0
lnX0:       .byte 0
BulKo:      .fill 20            ; ... what each buffer's rows show
BulKe:      .fill 20
BulK1:      .fill 20
BulK2:      .fill 20
BulKP:      .fill 20, 1         ; ... (1: not those values, drawn line by line)
BulKZ:      .fill 20, 0         ; ... (1: blank)
fbS16:      .byte 0             ; table index bases,
fbS32:      .byte 0
FbGmAny:    .byte 0             ; any cell left of the graphics split
FbCol:      .fill 18            ; each player's cells: column,
FbAny:      .fill 18            ; any pixels on the band's lines
FbHi:       .fill 9             ; the rows' table indexes
FbLo:       .fill 9
FbLitA:     .fill 171           ; the cells' lines (162-170: blank)
FbU:        .fill 9             ; a column's lines (1-8), put together (FbLitA + 171)
        .cerror FbU != FbLitA + 171
FbKeepA:    .fill 81            ; player 0's: what they leave
            .fill 9, $ff        ; (81-89: all)
fbS1:       .word 0             ; the writers' sources
fbS2:       .word 0
fbX1:       .byte 0
fbY0:       .byte 0
fbOdd:      .byte 0             ; the lines doubled to "10": 1 odd j, 0 even, 2 none (FbU)
fbSrc:      .byte 0
fbPB:       .byte 0
fbPx:       .byte 0             ; FbColumn: the pair (cell)
fbBad:      .byte 0             ; (either row off the screen)
fbCached:   .byte 0             ; FatBand: the cells' lines ready-made (FbCache),
CellIn:     .fill 18            ; each cell's lines in FbLitA (1), or ready-made (FbFromCache)
            .byte 1, 1          ; (18: blank, 19: FbU)
fbCB1:      .word 0             ; the ready-made lines: player 1's block,
fbCB1s:     .word 0             ; ... a row up,
fbCB0:      .word 0             ; player 0's (81 back),
fbLitA:     .word FbLitA        ; (and FbLitA's: in this order)
fbAdj1:     .word 0             ; the same + 1 - fbL0 (FbSrc)
fbAdj1s:    .word 0
fbAdj0:     .word 0
fbAdjL:     .word 0
fbFX:       .byte 0
fbQ:        .byte $ff           ; FbColumn: player 0's cell where both players are ($ff: none)
fbFY:       .byte 0
c64Y:       .byte 0             ; (Digits2)
LaserLast:  .byte 0, 0          ; the laser's lines each buffer's sprite holds (DrawLaser)
gndRun:     .byte 0             ; the ground's run (SchedGroundAdd)
fatI:       .byte 0
FatN:       .byte 0, 0          ; per buffer: cells the pairs took,
FatL0:      .byte 0, 0          ; ... the band's fbL0 (0: one row),
FatR1Lo:    .byte 0, 0          ; ... their rows
FatR1Hi:    .byte 0, 0
FatR2Lo:    .byte 0, 0
FatR2Hi:    .byte 0, 0
            .fill (* & $ff) > $100 - 2 * 18 ? $100 - (* & $ff) : 0   ; (FatCol in one page: FbRun)
FatCol:     .fill 2 * 18        ; ... their columns
            .fill (* & $ff) > $100 - 2 * 18 ? $100 - (* & $ff) : 0   ; (PairL0 in one page: FbFastSet)
PairL0:     .fill 2 * 18, $ff   ; per buffer and cell: the fbL0 its pair was last drawn with
K0Ext:      .fill 9, $ff        ; player 0's cells k - 9 to k + 17: k if it has pixels, else $ff
K0Of:       .fill 9, $ff        ; ... (K0Of + k, FbFlush; the rest always $ff)
            .fill 9, $ff
fbD9:       .byte 0             ; player 0's cell in player 1's cell k's column: k + fbD9 - 9 (0: none)
fbPrev:     .byte 0             ; FbFlush: the band's fbL0 when this buffer was last drawn
fbKf:       .byte 0             ; FbFast: the next cell
fbKw:       .byte 0             ; FbFast1: the cells before column 0 (9: none wrap round)
fbFast:     .byte 0             ; FbFast on
fbGen:      .byte 0             ; FbGenSet done
fbFilled:   .byte 0             ; FbFill: CellIn set (FatBand: back to none after),
FbFilledL:  .fill 18            ; ... which
fbN:        .byte 0
fbCm:       .byte 0
fbPar:      .byte 0
fbT:        .byte 0
fbT2:       .byte 0
fbI:        .byte 0
fbCc:       .byte 0
fbK1:       .byte 0
fbK0:       .byte 0
fbL0:       .byte 0
fbBad1:     .byte 0
fbBad2:     .byte 0
fbRow1:     .word 0
fbRow2:     .word 0
ScD0:       .fill 66            ; the score digits' rows, by line - 40 (11 bytes per digit)
ScD1 = ScD0 + 11
ScD2 = ScD0 + 22
ScD3 = ScD0 + 33
ScD4 = ScD0 + 44
ScD5 = ScD0 + 55
PcN:        .byte $ff, $ff      ; DrawPieces: rows drawn into each buffer's blocks ($ff: unknown)
PcDirty:    .byte 1, 1          ; ... rows 8-20 may hold some
PcOfs:      .fill 18            ; ... their offsets (bit 7: sprite 7's block)
pcL:        .byte 0
pcB:        .byte 0
pcI:        .byte 0
mapKey:     .word $ffff         ; the colour table MapColRev holds
GndKey:     .fill 6, $ff        ; the colours each buffer's ground run holds
mapL:       .byte 0             ; the last line of a demon colour run that changes a register (2-7, or 0)
runPrev:    .byte 0             ; SchedColourRun: 0 the band has previous-colour pixels, 64 not
RunBand:    .fill 2 * NRUNS     ; a demon run's first line
RunPrevF:   .fill 2 * NRUNS     ; ... 0 if it waits for pixel 52 (the checks read it)
RunValB:    .fill 16            ; each buffer's demon colours, rows 7..0
fbOr:       .byte 0             ; FatBand: the bits of all a player's rows on the band
