; Demon Attack (Atari 2600, Imagic 1982) running on the Commodore 64.
;
; The original 2600 program runs almost unchanged at $1000, where Imagic assembled it
; (the 2600 sees the cartridge at every $x000 with bit 12 set; on the C64 $1000-$1FFF is
; plain RAM). Patches: see GameImage in data.asm. This file and the others supply what
; the 2600 hardware used to do:
;
;   - display (render.asm): laid out line for line like the 2600 picture (one 2600 pixel
;     = one multicolour pixel = two C64 pixels, one 2600 line = one C64 line). The score,
;     demons, the small diving demon, the cannon's explosion and the bunkers are
;     multicolour characters drawn afresh each frame; the laser, the cannon and the
;     demons' bullets are sprites. The demons' colours change every line, as on the 2600:
;     the raster interrupt writes one colour register at the start of each such line.
;   - collisions (collide.asm): worked out from the rules in tools/model.js, which match
;     the 2600 pixel for pixel, timing quirks included, and handed to the game as the TIA
;     collision registers (and the two the kernel reads part-way down the screen)
;   - input (input.asm): keyboard and joysticks mapped onto the 2600 ports and switches
;   - sound (data.asm): the game's TIA sound registers translated to the SID
;
; The game's TIA writes land harmlessly in zero page $02-$2C; it reads the TIA at the
; mirrors $30-$3D, where we put the collisions and the fire buttons. Its RIOT accesses
; ($0280-$0297) hit plain C64 RAM, which we fill in each frame.
;
; Build: build.cmd (64tass -C -a -o build/demonattack-c64.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM
Scores      = $81       ; BCD, high byte first: player 1 $81/$83/$85, player 2 $82/$84/$86
P0Pos       = $8D       ; 4: player 0 position codes, bands 0-2 and the cannon (3)
P1Pos       = $91       ; 4: player 1 position codes, bands 0-2 and bullets / small demon (3)
LaserY      = $95       ; the laser's lowest kernel line (3: on the cannon)
LaserX      = $96       ; its position code
Growing     = $97       ; band whose demon is materializing (drawn four times as wide)
Dying       = $99       ; non-zero: the cannon has been hit (explosion, flashes)
P0Shape     = $9D       ; 3: player 0 graphics per band (8 bytes each from $1E00)
P1Shape     = $A1       ; 3: player 1 graphics per band
Bullets     = $A5       ; 10: the bullets, a row of 8 lines each from the bottom
SmallShape  = $B3       ; the small diving demon's graphics
SplitFlags  = $B6       ; 3: per band, the demon has split in two
BgColour    = $BC       ; background colour (flashes when the cannon is hit)
Frame       = $BD       ; frame counter
DemonY      = $C5       ; 3: each band's demon: its bottom row's kernel line
SmallY      = $C8       ; the small demon's bottom row
ColourPtr   = $CD       ; 2: the demons' colours, a byte per row
ColourMask  = $D1       ; $FF, or $F3 when the attract mode dims the colours
ScoreColour = $D2
CannonColour = $D3
BunkerColour = $D4
DigitPtr    = $DD       ; 6 pointers: the score's digits
KernelTemp  = $BF       ; (scratch the kernel and the score's digits use)
KernelRow   = $DC
WaveFlags   = $EB       ; bit 7: the demons shoot bullets (else a small demon dives)
DashMask    = $EC       ; 4: the bullets are dashed
Player      = $ED       ; whose turn it is
Lives       = $F2       ; 2: bunkers per player
GroundColour = $F7
CoOp        = $F8       ; bit 7: a co-op game (shared bunkers)

; ------------------------------- 2600 hardware: TIA writes land in zero page
COLUPF      = $08
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
; the game reads the TIA at $30-$3D: we fill these in
CXP0FB      = $32       ; bit 6: P0-BL
CXP1FB      = $33       ; bit 6: P1-BL
CXPPMM      = $37       ; bit 7: P0-P1
INPT4       = $3C       ; bit 7 clear: fire (left joystick)
INPT5       = $3D       ; ... right joystick
; RIOT
SWCHA       = $0280     ; joysticks (high nibble: left, low nibble: right)
SWCHB       = $0282     ; console switches
INTIM       = $0284     ; timer (kept at 0 so the game never waits)

; ------------------------------------------------ 2600 program addresses
PowerOn     = $124B     ; Reset, after its SEI
Overscan    = $187A     ; where the game continues after drawing a picture
DemonGfx    = $1E00     ; demons' graphics, 8 bytes each, bottom row first
DigitGfx    = $1F00
CannonGfx   = $1D88     ; 12 bytes, bottom row first
BunkerGfx   = $1D9C
BunkerNus0  = $1DAE     ; NUSIZ0 / NUSIZ1 by the number of bunkers
BunkerNus1  = $1DB5
PiecePtr    = $1DBC     ; the explosion's pieces (pointers into page $1D) ...
PieceColour = $1DEC     ; ... and their colours

; ------------------------------------------------------------ C64 layout
VICBANK     = $C000     ; the VIC sees $C000-$FFFF
SCREEN0     = $C000     ; two screens and two character sets: one shown, one being drawn
SCREEN1     = $C400
SPRDATA     = $C800     ; sprite blocks
CHARS0      = $E000
CHARS1      = $E800
COLRAM      = $D800
D018_0      = $08       ; screen $C000, characters $E000
D018_1      = $1A       ; screen $C400, characters $E800
SPRBASE     = (SPRDATA - VICBANK) / 64
BLK_BLANK   = SPRBASE           ; always empty
BLK_SET     = SPRBASE + 1       ; per buffer: laser, cannon, 4 bullet segments, 4 demon pairs
NBLK        = 14
B_LASER     = 0
B_CANNON    = 1
B_BULLETS   = 2
B_DEMONS    = 6                 ; bands 0-2 and the cannon band: two blocks each
        .cerror SPRDATA + 64 * (1 + 2 * NBLK) > $d000, "sprite blocks overflow"

; 2600 line L is raster line L + LINE2RAS (lines 40-239 fill the 200-line display window;
; the ground's plain colour below line 239 is cut short), screen pixel row L - 40, and
; sprite Y register value L + SPRYOFS.
LINE2RAS    = 11
SPRYOFS     = 10
TOPRASTER   = 30        ; frame start: before the first line of the picture
ENDRASTER   = 252       ; frame end: after the last one

; sprites: 0 laser (behind the characters' foreground, so the HMOVE marks hide it),
; 1 cannon, 2 and 3 the bullets (taking turns down their column), 4-5 and 6-7 the demons
; (bands 0 and 2: 4-5, band 1 and the cannon band: 6-7)
SPR_LASER   = 0
SPR_CANNON  = 1
SPR_BUL     = 2
SPR_PAIR0   = 4
SPR_PAIR1   = 6

; schedule entry types for the raster interrupt
S_TOP       = 0         ; frame start: sprites, colours, screen and character set
S_RUN       = 2         ; a run of colour writes, each at the start of its line (arg: run)
S_SET       = 4         ; write a colour register now (arg: index into SetReg/SetVal)
S_BUL       = 6         ; bullets: move sprite 2 or 3 down to its next segment (arg: segment)
S_END       = 8         ; frame end
S_PAIR      = 10        ; move a pair of demon sprites down to their next use (arg: pair record)
S_GND       = 12        ; the ground's run (arg: run)
NSCHED      = 24

; ------------------------------------------------------- zero page ($40+)
; $02-$2C take the game's TIA writes and $30-$3D are its TIA reads, so ours start at $40.
        .virtual $40
ptrA        .word ?
ptrB        .word ?
ptrC        .word ?
tmp         .byte ?
tmp2        .byte ?
tmp3        .byte ?
frameFlag   .byte ?     ; frames counted by the raster interrupt
frames      .byte ?
isPal       .byte ?
tickAcc     .byte ?
ahead       .byte ?     ; game steps run ahead of time (0 / 1)
firstTick   .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)
outv        .fill 3     ; SWCHA, INPT4, INPT5 being built
switches    .byte ?     ; SWCHB toggles
curBuf      .byte ?     ; raster interrupt: frame buffer in use (0/1)
pending     .byte ?     ; a new frame is ready in the other buffer
irqIdx      .byte ?
irqN        .byte ?
irqR        .byte ?     ; the raster a colour run waits for
irqCnt      .byte ?     ; ... the writes it has left
irqSkip     .byte ?     ; ... (the ground) the line it starts at
v0          .byte ?
v1          .byte ?
v2          .byte ?
; render
rbuf        .byte ?     ; buffer being drawn (0/1)
chrHi       .byte ?     ; high byte of its character set
nextChar    .byte ?     ; next free character this frame
rowPtr      .word ?     ; screen row being drawn into
dstPtr      .word ?     ; character data being drawn into
imgPtr      .word ?     ; a ready-made demon row
srcP        = imgPtr    ; (FatBand: a cell's lines)
; collisions
oA          .fill 4     ; Overlap: player 0, player 1 (pixel order)
oB          .fill 4
sdPtr       .word ?     ; the small demon's graphics
pcPtr       .word ?     ; the explosion pieces
RunZ        .fill 8     ; the demons' colours (rows 7..0) of the buffer shown (from RunValB)
irqA        .byte ?     ; the raster interrupt's registers
irqX        .byte ?
irqY        .byte ?
        .cerror * > $80, "zero page overflow"
        .endv

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title, credits and controls.
; (Lower case here: 64tass -a turns it into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " demon attack"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600 (imagic 1982)"
Bas30   .word Bas40, 30
        .null $8f, " programmed by rob fulop"
Bas40   .word Bas50, 40
        .null $8f, " version 1.1"
Bas50   .word Bas60, 50
        .null $8f, " ported by claude and doughboy68"
Bas60   .word Bas70, 60
        .null $8f, " joy port 2 (player 2: port 1)"
Bas70   .word Bas80, 70
        .null $8f, " or a d move, space fire"
Bas80   .word Bas90, 80
        .null $8f, " f1 or fire-start f2-power off/on"
Bas90   .word BasEnd, 90
        .null $8f, " f3-select f7/f8-difficulty"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #$ff
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01
        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -
        lda #<Nmi               ; our vectors (the 2600 program is already at $1000)
        sta $fffa
        lda #>Nmi
        sta $fffb
        lda #<Irq
        sta $fffe
        lda #>Irq
        sta $ffff

        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #0
        sta INTIM
        lda #$80
        sta INPT4
        sta INPT5
        lda #1
        sta firstTick
        jsr InitVideo
        jsr InitSound
        jsr DetectPal
        lda #$ff                ; CIA 2 timer A free-running (testing aid: DbgTime)
        sta $dd04
        sta $dd05
        lda #%00010001
        sta $dd0e
        jmp StartIrq

        .include "split.asm"    ; (split demons' sprite pairs: room here)
        .cerror * > $1000, "the start-up code runs into the 2600 program"

; ======================================================= the 2600 program
        * = $1000
        .include "image.asm"    ; (it must be at $1000)

; ================================================================ main loop
StartIrq:
        ldx #0                  ; start the raster interrupt on an empty frame
        stx curBuf
        stx irqIdx
        lda #TOPRASTER
        sta SchedRas
        sta SchedRas+NSCHED
        lda #S_TOP
        sta SchedType
        sta SchedType+NSCHED
        lda #ENDRASTER
        sta SchedRas+1
        sta SchedRas+NSCHED+1
        lda #S_END
        sta SchedType+1
        sta SchedType+NSCHED+1
        lda #TOPRASTER
        sta $d012
        lda #$1b
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

MainLoop:
-       lda frameFlag           ; frames since we last got here (set by the raster interrupt)
        beq -
        sei
        lda frameFlag
        ldx #0
        stx frameFlag
        cli
        cmp #2                  ; (testing aid: passes that came late)
        bcc +
        inc DbgLate
        bne +
        inc DbgLate+1
+       cmp #3                  ; if we fell behind, catch up at most 3 frames
        bcc +
        lda #3
+       sta frames
        lda DbgMaxOn            ; (testing aid: the most cycles drawing, ticking, both)
        beq +
        jsr DbgTime
        stx dbgT0
        sty dbgT0+1
+       lda DbgBorder           ; testing aid: the border shows where the time goes
        beq +
        lda #2
        sta $d020
+       lda pending             ; the last picture not shown yet (it was finished after
        bne _drawn              ; this frame's top): don't draw over it, just catch up
        inc DbgLoops            ; (testing aid: pictures drawn)
        bne +
        inc DbgLoops+1
+       jsr Render              ; draw the state the last tick produced
_drawn  jsr ReadInput
        lda PowerReq            ; F2: the power switch
        beq +
        jsr PowerCycle
+       lda DbgMaxOn
        beq +
        jsr DbgTime
        stx dbgT1
        sty dbgT1+1
        lda dbgT0               ; drawing
        ldx dbgT0+1
        ldy #0
        jsr DbgMax
+       lda DbgBorder
        beq _frame
        lda #5
        sta $d020
_frame  lda isPal               ; PAL: 6 game ticks every 5 frames keeps 2600 speed
        beq _ntsc
        lda tickAcc
        clc
        adc #6
        sta tickAcc
-       lda tickAcc
        cmp #5
        bcc _done
        sbc #5
        sta tickAcc
        jsr DueTick
        jmp -
_ntsc   jsr DueTick
_done   dec frames
        bne _frame
        lda pending             ; NTSC: the picture waits for the frame top: the next game
        beq +                   ; step now, instead of waiting (on PAL it doesn't pay)
        lda isPal
        bne +
        lda ahead
        cmp #2
        bcs +
        inc ahead
        jsr Tick
+       lda DbgMaxOn
        beq +
        jsr DbgTime
        lda dbgT1               ; the ticks (from the end of drawing)
        ldx dbgT1+1
        ldy #2
        jsr DbgMax
        lda dbgT0               ; the whole pass
        ldx dbgT0+1
        ldy #4
        jsr DbgMax
+       jsr UpdateSound
        lda DbgBorder
        beq +
        lda #0
        sta $d020
+       jmp MainLoop

; Testing aid: CIA 2 timer A counts down freely. DbgTime: dbgNow (and X/Y) = its value.
DbgTime:
-       ldy $dd05
        ldx $dd04
        cpy $dd05
        bne -
        stx dbgNow
        sty dbgNow+1
        rts
; DbgMax: cycles from the time in A/X (low/high) to dbgNow; keep the largest at
; DbgRMax+Y (Y = 0 drawing, 2 ticks, 4 the whole pass).
DbgMax:
        sec                     ; (the timer counts down: start - now)
        sbc dbgNow
        sta dbgTmp
        txa
        sbc dbgNow+1
        sta dbgTmp+1
        cmp DbgRMax+1,y
        bcc _keep
        bne _new
        lda dbgTmp
        cmp DbgRMax,y
        bcc _keep
_new    lda dbgTmp
        sta DbgRMax,y
        lda dbgTmp+1
        sta DbgRMax+1,y
_keep   rts

; A game step that's due, unless it was run ahead
DueTick:
        lda ahead
        beq +
        dec ahead
        rts
+       jmp Tick

; One 2600 frame of game logic: the original code from the end of the picture to the
; start of the next one, where it jumps to KernelHook.
Tick:
        lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp PowerOn             ; the very first frame starts at power-on
+       ldx #$ff                ; the registers as the kernel leaves them: the game uses Y
        ldy kernelY             ; (the bunkers count) on one path before setting it
        jmp Overscan

KernelHook:                     ; the game would draw the picture now
        jmp Collide             ; what the TIA would have seen (returns to whoever called Tick)

; F2: the power switch off and on. The TIA is cleared and the next tick starts at the
; power-on code, which clears the 2600 RAM (game 1); the console switches stay as they
; are set, as on a real 2600. The display catches up by itself.
PowerCycle:
        lda #0
        sta PowerReq
        ldx #2                  ; the TIA registers ($02-$2C) and our copies of its reads
-       sta $00,x
        inx
        cpx #$3e
        bne -
        sta INTIM
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        sta INPT5
        lda #1
        sta firstTick
        rts

; Replaces the power-on "sta $00,x / inx / bne" (A = 0, X = 0): clear the 2600 RAM,
; but not the C64 zero page below $80. Leaves X = 0 like the original loop.
ClearZP:
        ldx #$80
-       sta $00,x
        inx
        bne -
        rts

; One of the 2600 program's helpers by table (c64/tables.inc), leaving the RAM, the registers
; and the flags its callers use as the original leaves them:
; $1C11: BCD byte A -> two digit pointers' offsets (x 10) at DigitPtr,x and +2,x; KernelRow =
; A, KernelTemp = the low digit x 2, A = its x 10, X + 4 (and its flags), carry clear; Y kept
Digits2:
        sta KernelRow
        sty c64Y
        tay
        lda Dig10Hi,y
        sta DigitPtr,x
        lda Dig2Lo,y
        sta KernelTemp
        lda Dig10Lo,y
        sta DigitPtr+2,x
        ldy c64Y
        inx
        inx
        inx
        inx
        clc
        rts

; =========================================================== interrupts
; Each frame is a short schedule of raster lines (SchedRas/SchedType/SchedArg), built by
; Render into the buffer the display isn't using. At the top of the frame the interrupt
; switches to a newly finished buffer, so a half-drawn frame is never shown. The entries:
;   S_TOP     sprites, colours, screen and character set
;   S_RUN     a run of colour register writes, each at the start of its line
;   S_SET     a colour register write that needn't wait for an exact line
;   S_BUL     the bullets: move sprite 2 or 3 down to its next segment
;   S_END     frame end: let the main loop draw the next one
Irq:
        sta irqA                ; (the registers: in zero page, the interrupt isn't re-entered)
        stx irqX
        sty irqY
        cld                     ; the game uses decimal mode now and then
_next   ldx irqIdx
        ldy SchedType,x
        lda IrqJump,y
        sta _jmp+1
        lda IrqJump+1,y
        sta _jmp+2
_jmp    jmp $ffff
_done   inc irqIdx              ; next entry; run it now if its line has passed already
        ldx irqIdx
        lda SchedRas,x
        sta $d012
        ldy #1                  ; (acknowledged here: this one, and a raster match from while
        sty $d019               ; this entry ran, for one run straight after it)
        sec
        sbc #2
        cmp $d012
        bcc _next
_out    lda irqA
        ldx irqX
        ldy irqY
        rti
_top    inc irqIdx              ; (after the frame top's work, done at the frame end: the next
        ldx irqIdx              ; frame's first entry, later on)
        lda SchedRas,x
        sta $d012
        lda #1
        sta $d019
        jmp _out
IrqJump:    .word ITop, IRun, ISet, IBul, IEnd, IPair, IGround

ITop:   inc DbgTops             ; (testing aid: frames)
        inc DbgFrames
        bne +
        inc DbgFrames+1
+
        lda pending             ; switch to a newly finished frame
        beq +
        lda curBuf
        eor #1
        sta curBuf
        lda #0
        sta pending
+       inc frameFlag           ; (a frame for the main loop, from the top: after the swap)
        ldy curBuf
        lda StD018,y
        sta $d018
        lda StD021,y
        sta $d021
        lda StD022,y
        sta $d022
        lda StD023,y
        sta $d023
        lda StEn,y
        sta $d015
        lda StMsb,y
        sta $d010
        cpy #0                  ; this buffer's schedule, entry 0, and its staged sprites
        beq +                   ; (pointers in its own screen)
        jmp _top1
+
        lda #0
        sta irqIdx
        lda RunValB+0
        sta RunZ+0
        lda RunValB+1
        sta RunZ+1
        lda RunValB+2
        sta RunZ+2
        lda RunValB+3
        sta RunZ+3
        lda RunValB+4
        sta RunZ+4
        lda RunValB+5
        sta RunZ+5
        lda RunValB+6
        sta RunZ+6
        lda RunValB+7
        sta RunZ+7
        lda StPtr+0
        sta SCREEN0+$3f8+0
        lda StCol+0
        sta $d027+0
        lda StPtr+1
        sta SCREEN0+$3f8+1
        lda StCol+1
        sta $d027+1
        lda StPtr+2
        sta SCREEN0+$3f8+2
        lda StCol+2
        sta $d027+2
        lda StPtr+3
        sta SCREEN0+$3f8+3
        lda StCol+3
        sta $d027+3
        lda StPtr+4
        sta SCREEN0+$3f8+4
        lda StCol+4
        sta $d027+4
        lda StPtr+5
        sta SCREEN0+$3f8+5
        lda StCol+5
        sta $d027+5
        lda StPtr+6
        sta SCREEN0+$3f8+6
        lda StCol+6
        sta $d027+6
        lda StPtr+7
        sta SCREEN0+$3f8+7
        lda StCol+7
        sta $d027+7
        lda StX+0
        sta $d000+0
        lda StY+0
        sta $d001+0
        lda StX+1
        sta $d000+2
        lda StY+1
        sta $d001+2
        lda StX+2
        sta $d000+4
        lda StY+2
        sta $d001+4
        lda StX+3
        sta $d000+6
        lda StY+3
        sta $d001+6
        lda StX+4
        sta $d000+8
        lda StY+4
        sta $d001+8
        lda StX+5
        sta $d000+10
        lda StY+5
        sta $d001+10
        lda StX+6
        sta $d000+12
        lda StY+6
        sta $d001+12
        lda StX+7
        sta $d000+14
        lda StY+7
        sta $d001+14
        jmp Irq._top
_top1   lda #NSCHED
        sta irqIdx
        lda RunValB+8
        sta RunZ+0
        lda RunValB+9
        sta RunZ+1
        lda RunValB+10
        sta RunZ+2
        lda RunValB+11
        sta RunZ+3
        lda RunValB+12
        sta RunZ+4
        lda RunValB+13
        sta RunZ+5
        lda RunValB+14
        sta RunZ+6
        lda RunValB+15
        sta RunZ+7
        lda StPtr+8
        sta SCREEN1+$3f8+0
        lda StCol+8
        sta $d027+0
        lda StPtr+9
        sta SCREEN1+$3f8+1
        lda StCol+9
        sta $d027+1
        lda StPtr+10
        sta SCREEN1+$3f8+2
        lda StCol+10
        sta $d027+2
        lda StPtr+11
        sta SCREEN1+$3f8+3
        lda StCol+11
        sta $d027+3
        lda StPtr+12
        sta SCREEN1+$3f8+4
        lda StCol+12
        sta $d027+4
        lda StPtr+13
        sta SCREEN1+$3f8+5
        lda StCol+13
        sta $d027+5
        lda StPtr+14
        sta SCREEN1+$3f8+6
        lda StCol+14
        sta $d027+6
        lda StPtr+15
        sta SCREEN1+$3f8+7
        lda StCol+15
        sta $d027+7
        lda StX+8
        sta $d000+0
        lda StY+8
        sta $d001+0
        lda StX+9
        sta $d000+2
        lda StY+9
        sta $d001+2
        lda StX+10
        sta $d000+4
        lda StY+10
        sta $d001+4
        lda StX+11
        sta $d000+6
        lda StY+11
        sta $d001+6
        lda StX+12
        sta $d000+8
        lda StY+12
        sta $d001+8
        lda StX+13
        sta $d000+10
        lda StY+13
        sta $d001+10
        lda StX+14
        sta $d000+12
        lda StY+14
        sta $d001+12
        lda StX+15
        sta $d000+14
        lda StY+15
        sta $d001+14
        jmp Irq._top

; A run of colour writes, one per line, 8 lines. SchedArg = the run (RunFirst: its first
; entry in RunRas/RunReg/RunVal/RunDly; RunSetReg/RunSetVal: a register to set first, the
; colour the line before the run had, which its first line's pixels left of the 2600's
; colour write still show). The entry comes 2 lines early; the lines are unrolled, each
; waits for its raster line or a later one (it can't hang), and takes less than a line, so
; each catches the next line's start.
; Demon runs: each line's colour is written during the line before it (RunRas), after its
; "previous colour" pixels (left of 52) are out: the register written is the one that line
; used only there. The poll sees the line on cycle e (0-9, later when sprites are fetched),
; the write lands on e + 10 + 5 * RunDly: RunDly 4 (30 on), or 1 when the band has no such
; pixels or the line is a bad line (the VIC stops the CPU from cycle 12 to 54: the write
; lands at 57-68, before the next line's first pixel). Short delays keep a line's work
; (with sprite fetches) inside its 63 cycles, so the writes don't drift later down a run.
; The ground (RunDly 0): $D021 at the start of its own line, on cycle 6-12.
IRun:   ldy SchedArg,x          ; the run's header
        lda RunSetReg,y
        sta _sr+1
        ldx RunSetVal,y         ; (X: the dual runs' second register too)
_sr     stx $d000
        lda RunJLo,y            ; its code (by its registers, and whether it waits for pixel 52)
        sta _rj+1
        lda RunJHi,y
        sta _rj+2
        lda RunCnt,y            ; the writes it needs (after the last change, none)
        sta irqCnt
        lda RunBand,y           ; Y = its first line: the rasters and delays by line
        tay
_rj     jmp $ffff
; the runs' code: even lines write the first register, odd lines the other; P: waiting for
; pixel 52 (delay 4, 1 on a bad line), N: no previous-colour pixels (delay 1)
IRunP0:
        ldx DlyTab+0,y           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+1,y           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+2,y           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+3,y           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+4,y           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+5,y           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+6,y           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+7,y           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02c
        jmp Irq._done
IRunP1:
        ldx DlyTab+0,y           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+1,y           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+2,y           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+3,y           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+4,y           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+5,y           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+6,y           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+7,y           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02b
        jmp Irq._done
IRunP2:
        ldx DlyTab+0,y           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+1,y           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+2,y           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+3,y           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+4,y           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+5,y           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+6,y           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+7,y           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02e
        jmp Irq._done
IRunP3:
        ldx DlyTab+0,y           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+1,y           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+2,y           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+3,y           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+4,y           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+5,y           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+6,y           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+7,y           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02d
        jmp Irq._done
IRunP4:
        ldx DlyTab+0,y           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+1,y           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+2,y           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+3,y           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+4,y           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+5,y           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+6,y           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+7,y           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d023
        jmp Irq._done
IRunP5:
        ldx DlyTab+0,y           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+1,y           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+2,y           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+3,y           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+4,y           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+5,y           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+6,y           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx DlyTab+7,y           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d022
        jmp Irq._done
; split bands as sprites: both pairs, the same colour (a second store each line). With 8
; sprites on a line (their fetches hold the CPU until cycle 11 on the band's lines) the line's
; work is shorter: always all 8 lines (the writes after the last change write what the
; registers hold), delay 3 (DlyTabD; the first line's write, before the band, may come early)
IRunP6:
_sr2    stx $d02e             ; (the other pair's register: the colour before)
        ldx DlyTabD+0,y          ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02b
_x0     sta $d02d
        ldx DlyTabD+1,y          ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02c
_x1     sta $d02e
        ldx DlyTabD+2,y          ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02b
_x2     sta $d02d
        ldx DlyTabD+3,y          ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02c
_x3     sta $d02e
        ldx DlyTabD+4,y          ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02b
_x4     sta $d02d
        ldx DlyTabD+5,y          ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02c
_x5     sta $d02e
        ldx DlyTabD+6,y          ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02b
_x6     sta $d02d
        ldx DlyTabD+7,y          ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02c
_x7     sta $d02e
        jmp Irq._done
IRunP7:
_sr2    stx $d02d             ; (the other pair's register: the colour before)
        ldx DlyTabD+0,y          ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02c
_x0     sta $d02e
        ldx DlyTabD+1,y          ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02b
_x1     sta $d02d
        ldx DlyTabD+2,y          ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02c
_x2     sta $d02e
        ldx DlyTabD+3,y          ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02b
_x3     sta $d02d
        ldx DlyTabD+4,y          ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02c
_x4     sta $d02e
        ldx DlyTabD+5,y          ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02b
_x5     sta $d02d
        ldx DlyTabD+6,y          ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02c
_x6     sta $d02e
        ldx DlyTabD+7,y          ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02b
_x7     sta $d02d
        jmp Irq._done
; a split band with one half as a sprite pair (4-5: P8 / P9, waiting as the one-pair runs do;
; 6-7: P10 / P11, as the dual runs) and the other as characters ($D022 / $D023, written second)
IRunP8:
_sr2    stx $d023             ; (the characters' register: the colour before)
        ldx DlyTab+ 0,y          ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02b
_x0     sta $d022
        ldx DlyTab+ 1,y          ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02c
_x1     sta $d023
        ldx DlyTab+ 2,y          ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02b
_x2     sta $d022
        ldx DlyTab+ 3,y          ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02c
_x3     sta $d023
        ldx DlyTab+ 4,y          ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02b
_x4     sta $d022
        ldx DlyTab+ 5,y          ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02c
_x5     sta $d023
        ldx DlyTab+ 6,y          ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02b
_x6     sta $d022
        ldx DlyTab+ 7,y          ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02c
_x7     sta $d023
        jmp Irq._done
IRunP9:
_sr2    stx $d022             ; (the characters' register: the colour before)
        ldx DlyTab+ 0,y          ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02c
_x0     sta $d023
        ldx DlyTab+ 1,y          ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02b
_x1     sta $d022
        ldx DlyTab+ 2,y          ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02c
_x2     sta $d023
        ldx DlyTab+ 3,y          ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02b
_x3     sta $d022
        ldx DlyTab+ 4,y          ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02c
_x4     sta $d023
        ldx DlyTab+ 5,y          ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02b
_x5     sta $d022
        ldx DlyTab+ 6,y          ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02c
_x6     sta $d023
        ldx DlyTab+ 7,y          ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02b
_x7     sta $d022
        jmp Irq._done
IRunP10:
_sr2    stx $d023             ; (the characters' register: the colour before)
        ldx DlyTabD+0,y          ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02d
_x0     sta $d022
        ldx DlyTabD+1,y          ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02e
_x1     sta $d023
        ldx DlyTabD+2,y          ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02d
_x2     sta $d022
        ldx DlyTabD+3,y          ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02e
_x3     sta $d023
        ldx DlyTabD+4,y          ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02d
_x4     sta $d022
        ldx DlyTabD+5,y          ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02e
_x5     sta $d023
        ldx DlyTabD+6,y          ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02d
_x6     sta $d022
        ldx DlyTabD+7,y          ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02e
_x7     sta $d023
        jmp Irq._done
IRunP11:
_sr2    stx $d022             ; (the characters' register: the colour before)
        ldx DlyTabD+0,y          ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02e
_x0     sta $d023
        ldx DlyTabD+1,y          ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02d
_x1     sta $d022
        ldx DlyTabD+2,y          ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02e
_x2     sta $d023
        ldx DlyTabD+3,y          ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02d
_x3     sta $d022
        ldx DlyTabD+4,y          ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02e
_x4     sta $d023
        ldx DlyTabD+5,y          ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02d
_x5     sta $d022
        ldx DlyTabD+6,y          ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02e
_x6     sta $d023
        ldx DlyTabD+7,y          ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02d
_x7     sta $d022
        jmp Irq._done
IRunN0:
        ldx #1           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02c
        jmp Irq._done
IRunN1:
        ldx #1           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02b
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02c
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02b
        jmp Irq._done
IRunN2:
        ldx #1           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02e
        jmp Irq._done
IRunN3:
        ldx #1           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d02d
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d02e
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d02d
        jmp Irq._done
IRunN4:
        ldx #1           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d023
        jmp Irq._done
IRunN5:
        ldx #1           ; line 0: wait for its raster (or later), then a delay
        lda RasTab+0,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+0
_w0     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 1: wait for its raster (or later), then a delay
        lda RasTab+1,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+1
_w1     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 2: wait for its raster (or later), then a delay
        lda RasTab+2,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+2
_w2     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 3: wait for its raster (or later), then a delay
        lda RasTab+3,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+3
_w3     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 4: wait for its raster (or later), then a delay
        lda RasTab+4,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+4
_w4     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 5: wait for its raster (or later), then a delay
        lda RasTab+5,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+5
_w5     sta $d022
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 6: wait for its raster (or later), then a delay
        lda RasTab+6,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+6
_w6     sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+
        ldx #1           ; line 7: wait for its raster (or later), then a delay
        lda RasTab+7,y
-       cmp $d012
        beq +
        bcs -
+
-       dex
        bne -
        lda RunZ+7
_w7     sta $d022
        jmp Irq._done
RunVLo:     .byte <IRunP0, <IRunP1, <IRunP2, <IRunP3, <IRunP4, <IRunP5, <IRunP6, <IRunP7, <IRunP8, <IRunP9, <IRunP10, <IRunP11, <IRunN0, <IRunN1, <IRunN2, <IRunN3, <IRunN4, <IRunN5
RunVHi:     .byte >IRunP0, >IRunP1, >IRunP2, >IRunP3, >IRunP4, >IRunP5, >IRunP6, >IRunP7, >IRunP8, >IRunP9, >IRunP10, >IRunP11, >IRunN0, >IRunN1, >IRunN2, >IRunN3, >IRunN4, >IRunN5
; by line L (a run's first line + k): the raster of the line before it, and the delay for
; its write (the line before a bad line when L & 7 = 1); DlyTabD for the dual runs (sprites 4-7
; on the band's lines hold the CPU until cycle 11): 3, or 1 on a bad line. (Made at start-up,
; InitTables, in the C64's old screen at $0400, page-aligned: no page crossings.)
RasTab      = $0400
DlyTab      = $0500
DlyTabD     = $0600

; The ground's run, lines 223-229: odd lines show $D023 ("10" pixels), even ones $D021
; ("00"), so a line's colour can be written any time during the line before it (after the
; last pixel of the line before that, which shows the same register). Line 223's goes in
; at once; then from the first line whose colour changes (irqSkip, 1-6: line 223 + that,
; written during line 222 + that) to the last (irqCnt writes in all).
IGround:
        ldy SchedArg,x          ; the run's header
        lda RunSetReg,y
        sta _sr+1
        lda RunSetVal,y
_sr     sta $d000
        lda RunCnt,y
        sta irqCnt
        lda RunSkip,y
        sta irqSkip
        lda RunFirst,y
        tay
        lda RunRas,y
        sta irqR
        lda RunVal+0,y
        sta $d023
        dec irqCnt
        bne +
        jmp Irq._done
+       ldx irqSkip
        lda GJmpLo-1,x
        sta _gj+1
        lda GJmpHi-1,x
        sta _gj+2
        txa
        clc
        adc irqR
        tax                     ; (the raster of line 222 + j)
_gj     jmp $ffff
_g1     lda RunVal+1,y
-       cpx $d012
        beq +
        bcs -
+
        sta $d021
        inx
        dec irqCnt
        bne +
        jmp Irq._done
+       lda RunVal+2,y          ; line 225's write would fall on a bad line (raster 235: once
        ldx #7                  ; reached late, no time left in it), but its register shows
-       dex                     ; nothing on line 224: from line 224's write, early in raster
        bne -                   ; 234, 54 cycles on (after line 223's last pixel, cycle 57)
        sta $d023
        ldx #BUNKLINE+2+LINE2RAS   ; (line 226's raster)
        dec irqCnt
        bne _g3
        jmp Irq._done
_g2     lda RunVal+2,y
-       cpx $d012
        beq +
        bcs -
+
        sta $d023
        inx
        dec irqCnt
        bne +
        jmp Irq._done
+
_g3     lda RunVal+3,y
-       cpx $d012
        beq +
        bcs -
+
        sta $d021
        inx
        dec irqCnt
        bne +
        jmp Irq._done
+
_g4     lda RunVal+4,y
-       cpx $d012
        beq +
        bcs -
+
        sta $d023
        inx
        dec irqCnt
        bne +
        jmp Irq._done
+
_g5     lda RunVal+5,y
-       cpx $d012
        beq +
        bcs -
+
        sta $d021
        inx
        dec irqCnt
        bne +
        jmp Irq._done
+
_g6     lda RunVal+6,y
-       cpx $d012
        beq +
        bcs -
+
        sta $d023
        jmp Irq._done
GJmpLo:     .byte <_g1, <_g2, <_g3, <_g4, <_g5, <_g6
GJmpHi:     .byte >_g1, >_g2, >_g3, >_g4, >_g5, >_g6

ISet:   ldy SchedArg,x
        lda SetReg,y
        sta _st+1
        lda SetVal,y
_st     sta $d000
        jmp Irq._done

IBul:   ldy SchedArg,x          ; Y = 4 * buffer + segment (2 or 3)
        tya
        and #1
        ora #SPR_BUL
        tax                     ; its sprite, 2 or 3
        lda BulPtr,y
        sta SCREEN0+$3f8,x
        sta SCREEN1+$3f8,x
        txa
        asl
        tax
        lda BulY,y
        sta $d001,x
        jmp Irq._done

IPair:  ldy SchedArg,x          ; a pair record: sprites n, n+1 at the same place
        ldx PairN,y
        lda PairPtr,y
        sta SCREEN0+$3f8,x
        sta SCREEN1+$3f8,x
        lda PairPtr2,y
        sta SCREEN0+$3f9,x
        sta SCREEN1+$3f9,x
        lda PairMsb,y           ; X bit 8: both, or neither
        eor $d010
        and PairBitsR,y
        eor $d010
        sta $d010
        txa
        asl
        tax
        lda PairX,y
        sta $d000,x
        sta $d002,x
        lda PairY,y
        sta $d001,x
        lda PairY2,y
        sta $d003,x
        jmp Irq._done

IEnd:   jmp ITop                ; frame end: the next frame's top already (in the border below
                                ; the picture: one interrupt less a frame)

Nmi:    rti

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        txa                     ; the SID's pitch depends on the machine's clock
        bne +
        lda #<SidFreqLoN
        sta FreqTab
        lda #>SidFreqLoN
        sta FreqTab+1
+       rts

InitVideo:
        jsr InitTables
        lda $dd02               ; VIC bank 3 ($C000)
        ora #3
        sta $dd02
        lda $dd00
        and #$fc
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d017
        sta $d01c
        lda #1 << SPR_LASER     ; the laser behind the characters' foreground
        sta $d01b
        lda #$18                ; multicolour characters
        sta $d016
        lda #D018_0
        sta $d018
        lda #$ff                ; every sprite double width: one 2600 pixel = two C64 pixels
        sta $d01d

        ; clear $C000-$CFFF (screens, sprites) and $E000-$EFFF (characters)
        lda #>VICBANK
        jsr Clear4K
        lda #>CHARS0
        jsr Clear4K
        ldx #0                  ; colour RAM: multicolour, "11" pixels black (the HMOVE marks)
        lda #8
-       sta COLRAM,x
        sta COLRAM+$100,x
        sta COLRAM+$200,x
        sta COLRAM+$2e8,x
        inx
        bne -
        lda #BLK_BLANK          ; all sprites blank to start
        ldx #7
-       sta SCREEN0+$3f8,x
        sta SCREEN1+$3f8,x
        dex
        bpl -
        jmp InitRender

; Clear 4K from page A
Clear4K:
        sta ptrA+1
        lda #0
        sta ptrA
        ldx #16
        ldy #0
-       sta (ptrA),y
        iny
        bne -
        inc ptrA+1
        dex
        bne -
        rts

InitSound:
        ldx #$18
        lda #0
-       sta $d400,x
        dex
        bpl -
        lda #$0f                ; full volume
        sta $d418
        ldx #5
        lda #$ff
-       sta SndLast,x
        dex
        bpl -
        rts

        .include "input.asm"
        .include "collide.asm"
        .include "render.asm"
        .include "sound.asm"
        .include "tables.inc"
        .include "vars.asm"
        .cerror * > VICBANK, "the program runs into the video bank"
