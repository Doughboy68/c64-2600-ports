# Handoff: Demon Attack (split demons as sprite pairs done; next steps)

Newest first: where things stand, how split demons are drawn now, ideas for next, the prompt
for a new session; then the history of the speed work (2026-10-02).

## Where things stand (2026-10-03: version 1.1 published)

**Version 1.1** (all of the below) is on the web builder since 2026-10-03; 1.0 was commit
9486908. The next release would be 1.2 (the user decides when to publish). Lockstep / screencheck exact (seeds 3, 7, 11, 21, 45 cheat and
5 normal, 4000 frames each; lockstep normal, `--cheat --seed=21`, `--power=1500`).

| Timing model (`bench.js`, 48 games x 3000) | PAL | NTSC |
|---|---|---|
| normal, version 1.0 | 95.4% | 92.7% |
| normal, commit 14f3405 (split bands as pairs) | 95.3% | 92.5% |
| normal, now | 95.2% | 92.3% |
| later waves (`--cheat`), version 1.0 | 83.7% | 80.8% |
| later waves, commit 14f3405 | 89.7% | 86.4% |
| later waves, + the line 225 fix (3c60b94) | 89.6% | 86.2% |
| later waves, + half split bands (b4ac50e) | 89.9% | 86.3% |
| later waves, + room (SidRow, cbbddd3) | 90.0% | 86.4% |
| later waves, now (+ OneBand) | **90.4%** | **86.7%** |
| normal, now | 95.2% | 92.4% |

(Seeds 49-96 normal, at 14f3405: 1.0 95.5 / 92.7, then 95.4 / 92.5.) The line 225 fix costs
~0.1-0.2: the ground's interrupt waits about a line longer each frame. The halves gain little
(+0.3 / +0.1 in the later waves) until OneBand (+0.4 / +0.3 more): a half picture ~11.5K
(12.9K), OneBand ~2.4K of it (its line loop ~115 cycles a line, player 0's cover masks, ~5
GetCells).

vicecheck, 80 samples each (`--cheat`: new, the later waves):

| | PAL | NTSC | PAL `--cheat` | NTSC `--cheat` |
|---|---|---|---|---|
| version 1.0 | 5 differ | (0 of 40 before) | 9 differ | 0 differ |
| commit 14f3405 | 4 differ | 0 differ | 3 differ | 1 differ |
| (commit a60aa6c, the same interrupt code) | 2 differ | 0 differ | 4 differ | 1 differ |
| b4ac50e (line 225 fixed, halves) | 1 differ | 0 differ | 0 differ | 0 differ |
| now (OneBand) | 0 differ | 0 differ | 1 differ | 1 differ |

PAL `--cheat`, 160 samples: version 1.0 20 differ (14 of them line 225), the line 225 fix
alone 1 differ. Line 225 was pixels 0-7 in the previous colour: the ground run's write for it
is due during raster 235, a bad line, and came late (fixed in 3c60b94, see below). The others
are a demon colour run late on a few lines. The NTSC `--cheat` one: a character band 18
lines below a band on both pairs, whose sprites' fetches (rows 8-20 still run) made the
character band's run drift late (lines 155-160). (To look at a sample: its
s<n>.bin is VICE's memory with a 2-byte load address first.)

## How split demons are drawn now

- **Classify** (split.asm, called by Render before the bands): the game's SplitFlags ($B6-$B8)
  first — with no band split in two nothing more is done (normal waves: ~20 cycles) and the
  bands go as always (DrawBandF: bands 0 / 2 on sprites 4-5, band 1 / the cannon band on 6-7,
  SchedPair0 / SchedPair1, records 0-1 of each buffer). Else a quick |x1 - x0| scan, then each
  band's kind (ItK: 0 blank, 1 one pair, 2 split, 3 characters).
- **Plan** (with a split band): items = bands 0-2 and the cannon band's demon (small demon from
  213 - C8; the explosion from max(188, 221 - C7) if drawn), top to bottom (ItL). One greedy pass
  (PlanTry): one-pair items on a pair whose last start is 22+ lines up (27 for the explosion:
  its blocks have rows below 7, so its pair moves only after the 21 rows before); of two that
  fit, an unused one if just one is, else the one used last (the other stays free longer). A
  split band takes both pairs if both fit, else it is characters (SmallBand). If a later item
  then doesn't fit, the last split band taken is dropped and the pass runs again (plConv /
  plTaken); if nothing fits, as always (plDyn 0). Out: ItN (pairs), ItP (pair, $ff none),
  MoveRas (raster of pair p's move after item j: 2j + p). The pairs are staged blank at the
  frame top unless used there.
- **Moves**: SchedMoves after each band (raster order, as SchedPair0/1 did): PairMove takes the
  next record (2-6 of the buffer's NPAIRS = 7; PairN / PairBitsR set per record), PairRec[p] =
  where pair p's next use goes (SprPos / PairSet / BlankUse: $ff = staged at the frame top).
- **DrawBand** (the plan's) / **DrawBandF** (as always) share the drawing: `_split` (spPair $ff
  at `_sprite`): a dual colour run, then SprHalf for each player. The left half goes on sprites
  4-5 (hfA: player 0's pair), whose register the run writes first; player 0 in the band's own
  blocks, player 1 in a second set (Half2*: blocks 61-62 and chars 216-255 of both sets, which
  GetCell never hands out). HfDirty: bytes 1-2 of a band's blocks may hold a whole demon (marked
  by Classify / Plan where SprDemon may draw); SprHalf blanks them before using the blocks.
- **SprHalf**: usually all of a half is one colour (player 0 from 43, player 1 from 52, or all
  left of it) and player 1 isn't left of 19: rows straight from DemonGfx (Reverse for player 1)
  into one sprite line by line, the other's rows blanked. Else HfRow + masks (as SprDemon).
- **Dual runs** (main.asm IRunP6 / P7, RunVLo 6 / 7; SchedColourRun with runDual = 6): each line
  `sta` to both pairs' registers (_wk / _xk); the colour before goes to the second pair by the
  variant's `_sr2 stx` (IRun's header now loads RunSetVal into X). With 8 sprites on a line the
  normal run's line work overran it (writes drifting a line late), so the dual runs do all 8
  lines (no irqCnt: writes after the last change rewrite what the registers hold) and wait
  DlyTabD (3, 1 on a bad line): on the band's lines sprites 4-7's fetches hold the CPU until
  cycle ~11, so the writes still land after pixel 52; the first line's write (before the band)
  may come early, harmlessly. Always the P kind (waiting for pixel 52), runPrev forced 0.
- **Half split bands** (commit after 3c60b94): when only one pair fits, PlanTry gives a split
  band ItN 3: its left player on that pair (SprHalf), the right one as characters (SmallBand
  with the left player's shape set to 0 for the call: sbOne skips the blank player's work;
  slices without pixels are listed as none). One colour run for both: IRunP8 / P9 (pair 4-5,
  delays as the one-pair runs) and P10 / P11 (6-7, as the dual runs), the pair's register
  first, then $D022 / $D023 (RunVLo: P0-P11, N0-N5 from 12). The right half is OneBand: the
  one player's eight lines straight into OneL (8 a column, 2-3 columns), then each cell with
  pixels on a row's lines written (player 1 ORed in, player 0 over what it covers: OneM); the
  same pixels and colours as SmallBand gives (SmallBand also lists a slice without pixels as
  none now). A band below that doesn't fit
  steps the last split band taken down: both pairs -> a half -> characters (plConv, plHalf,
  plTaken, plTakenF). About 74-79% of split bands now take both pairs, 16-26% a half.
- **The ground (line 225)**: the ground run enters at line 220 (was 221: its setup takes ~1.7
  lines after the interrupt's entry), and line 225's $D023, due during raster 235 (a bad
  line: once reached late there is no time left in it), goes in a fixed 54 cycles after line
  224's write, after line 223's last pixel (its register shows nothing on line 224).
- **Room**: the split code is in split.asm, in the start-up area below the 2600 program
  ($0991-$0FE9, about 20 bytes left); InitImages moved there too. The main area ends at
  ~$BCFD (about 770 bytes left below $C000, after the SID frequency tables went from one per
  AUDC value to one per (waveform, divider) row: SidRow, 1K). RasTab, DlyTab, DlyTabD and Ident are made at
  start-up (InitTables) in the C64's old screen, $0400-$07FF (pages 4-7; $0300 is the test
  tools' call stub). Earlier: NRUN 8 (only the ground uses RunRas / RunVal), RunReg, RunDly,
  DlyPat, DbgRunIn, irqSt gone.
- **Checks** know about it: c64picture.js (dual runs, their write cycles: the second store 4
  later, lines after the first from cycle 11; and the VIC's 22-line sprite restart), c64run.js
  ("sprite pairs moved too late" — must be 0; dual runs' windows end at their half's first
  pixel, 16 + x / 4, from RunXL / RunXR; `--splitstat` prints "drawn as sprites"), vicecheck
  `--cheat` (pokes random waves, waves cut short, bunkers).

Per picture with split halves (NTSC seed 7 cheat, `c64run --passes --band=SprHalf`): ~12.9K
(14.3K at first): SprDemon ~2.0K (the other bands and the small diving demon), DrawBullets
~1.3K, SprHalf ~1.1K, PlanTry ~0.9K, SmallBand ~0.75K (split bands left as characters), Place
~0.6K, SprAligned ~0.55K. About 74% of split bands are drawn as sprites (`--splitstat`).

## Ideas for next (roughly by size)

- **Room**: ~770 bytes in the main area. More: $0400-$07FF's spare bytes (pages 4-6 use 240
  of 256), $FE10-$FFF9 (490 bytes, not loaded: generated data or code copied at start-up).
- **OneBand** (~2.4K a half picture): the cover masks only for the columns used, the any-pixel
  scan per column folded into the line loop.
- **The other bands in split pictures**: SprDemon + Place + SprAligned ~3.2K. The small diving
  demon (SmallRow) and bands whose players aren't on byte boundaries take the general path.
- **PlanTry** (~0.9K a planned picture, 1.2 passes): `_use` / `_fits` inline, fewer stores.
- **Character runs below a two-pair band**: a band of characters within 21 lines of a band on
  both pairs runs its colour writes with 4 more sprites' fetches each line; P4/P5's line of
  work (delay 4, irqCnt) then overruns and its writes drift (c64run counts: P4/P5 late writes
  ~90 per 3000 frames, 1.0 ~6-25). A lean P4/P5 for those runs (as P6/P7), or the plan keeping
  such a band off... (1 of 80 vicecheck samples).
- Normal waves lost ~0.1-0.2 points (~90 cycles a picture: Classify's SplitFlags test, PairRec,
  DrawBandF's pair, PairSet): small, but there.

## Prompt for a new session

> Continue the Demon Attack 2600→C64 port (games/demon-attack; version 1.1 is on the web builder
> since 2026-10-03: don't publish or push anything until I say so, and the next release will be
> 1.2). Read README.md, games/demon-attack/README.md, games/demon-attack/HANDOFF.md and the
> memory notes first. Commit as you go (only `git add games/demon-attack`: other sessions may
> have uncommitted work in this repo; build without touching site/, see HANDOFF "Checks").
>
> Task: pick from HANDOFF.md "Ideas for next". Keep the picture exact (screencheck --cheat on seeds 3, 7, 11, 21, 45 and a normal
> one: read the "all exact" lines) and the game exact (lockstep normal, --cheat --seed=21,
> --power=1500); measure with tools/bench.js and `bench.js --cheat` against a copy of the
> previous build (DA_BUILD); run vicecheck PAL and NTSC, normal and --cheat (80 samples, each its
> own --out=dir), and c64run's "sprite pairs moved too late" must stay 0.

## Split demons as sprite pairs: the plan, as written before doing it

The state then (version 1.0): later waves PAL 83.7%, NTSC 80.8%; split bands drawn as
characters (SmallBand, ~5.8K a band, pictures 12-17K). `c64run.js --splitstat` measured 75-88%
of split bands could have both pairs under the 22-line rule; the estimate was split pictures
~8-11K and NTSC later waves in the mid-to-high 80s (it came out at 86.4%, split pictures ~12.9K).
How the sprites worked before: band 0 on sprites 4-5 and band 1 on 6-7 staged for the frame
top, band 2 and the cannon band moved in (SchedPair0 / SchedPair1, records 2 x buffer + 0 / 1,
the reuse interrupt with ≥ 6 lines of lead); each demon a pair taking turns by line parity
("this line's colour" / "the previous line's": pixels left of 43 for player 0, 52 for player
1; player 1 left of 19 shows the row above); colour runs writing one register a line in a
~30-cycle window.

## Where things stand (2026-10-02, after shared cells moved into the fast loop)

- Timing model (`node tools/bench.js`: c64run --tickinput, 48 games x 3000 frames, ~30 s, noise
  about ±0.4): **PAL 94.5%, NTSC 91.3%** of frames get a new picture (92.0% / 88.7% before the
  fast loop; seeds 49-96: 94.6% / 91.3%). Without materializing demons drawn at all the model
  gave PAL 98.3%, NTSC 96.5%.
- A picture with a materializing band costs **~11.5K cycles** (NTSC seed 4: `c64run.js 6000 --ntsc
  --seed=4 --tickinput --passes --band`), 14.9K before; the band's own part is ~6.5K of it.
- vicecheck (40 samples): PAL 1 of 40 frames differ (one pixel on line 152), NTSC 0 of 40 (the
  build before: 0 and 1). VICE play
  test (c64test.js, 90 s, one random game each, same machine): before PAL 94% / NTSC 89%, now
  PAL 96% / NTSC 91% and 93% (two runs).
- c64run has `--band` (with `--passes`: the passes drawing a materializing band, routines on
  average) and `--hits=A,B._c` (how often labels are reached per such pass).

## How the materializing band is drawn now (render.asm)

- **Ready-made lines** (FbCacheInit, at $F000-$FE0F): cells 16 bytes apart, as the pairs are.
  Player 1's block b at FBCACHE1 + 144b: cell k at 16k (lines j = 0-8, FbAny at +9, "any a row
  up" at +10). Player 0's: two blocks interleaved per 144 bytes (block b at FBCACHE0 + 144 (b/2)
  + 8 (b&1), cell k at 16k: lines j = 1-8), FbAny at FBANY0 + 9b + k.
- **A pair of characters per cell** (not per column): cell x (0-8 player 1, 9-17 player 0) has
  FBCH + 2x (row 1) and + 1 (row 2); in a shared column player 1's cell's pair. PairL0 per
  buffer and cell (2 x 18). Pairs follow the demon sideways, so "the pair's last lines" (fbPrev,
  the band this buffer had last) usually still fit; wrapping round needs nothing special.
- **FbFlush**: K0Of (player 0's cell k if it has pixels, else $ff; K0Ext pads it with $ff 9 each
  side; player 0's cell in player 1's cell k's column is K0Ext + fbD9 + k), fbL0, FbZ's rts, fbAdj*,
  rows (one row: ptrB = row 2 = row 1), then **FbFastSet** (patches both runners for fbL0, this
  buffer's PairL0, the usual clearing from fbPrev) and **FbFast1** (player 1: runs of cells by
  FbRange: columns 0-3 a row up, column 4 left to the exact way, to 12 left of the colour
  split, then right; the cells past column 39 from column 0 again), the exact loop for what is
  left (skipped when nothing is), **FbFast0** (player 0: left to column 9, column 10 left to the
  exact way, right from 11; wrapping round), the exact loop again.
- **FbRunO / FbRunE** (a macro, "10" on odd / even j): per cell, X = cell: FbAny, column, both
  screen cells blank, K0Ext (player 0 there too, outside columns 10-12: `_sh`, below), take
  (PairCh1), record (`_qrec`: self-modified pointer into FatCol), PairL0 against the usual (else
  FbFastSC), clear by jumping into an unrolled block (`_qzj`), copy 8 lines with Y = FbT[l][x] =
  16k + l: one pair pointer (ptrC) and one source pointer (srcP) for a whole run. About 130
  cycles a cell of bookkeeping (empty cells and the loop included), ~110 for the copy.
- **Shared columns in FbRun**: `_sh` marks player 0's cell done (`_qso`: FbAny + fbD9 + X), sets
  the V flag (`bit FbV40`) and joins the usual take / record / clear; at the copy `bvs _or` takes
  an OR copy with player 0's lines through ptrA (fbAdj0 + 16 (fbD9 - 9): its cell at the same Y),
  which clears V again (FbRange clears it before each run; `_sc` keeps it with php / plp).
- **Exact path** (FbColumn, unchanged in principle) now only for: player 1's column 4 (graphics
  split; FbAbove goes straight to that cell), columns 10-12 where player 0 is (FbBuildSC: straight
  from the ready-made lines), a screen cell already in use or a row off the screen (_gen,
  GetCell; FbGenSet patches the general writers only then), shapes other than 1-4 (FbLitA).
- RestoreFat: both rows (one row: the same twice), 23 cycles a column.

Per materializing picture (NTSC seed 4): FbRunO+E 2733 (9.8 cells + 1.5 shared), FbFlush 915,
FbFromCache 385, RestoreFat 312, FbBuildSC 279 (0.38 calls), FbFastSet 254, FbFast1/0 325,
FbRange 190, FatBand 134, FbColumn 132 (0.62), FbCells 240, FbFastSC 122 (1.8 calls), FbAbove
120, FbZ 80.

## Later waves (split demons), 2026-10-02

- `node tools/bench.js --cheat` (random waves, as c64run --cheat): **PAL 81.7%, NTSC 78.7%**
  (74.2% / 72.3% before). vicecheck: 0 of 40 differ, PAL and NTSC.
- Split demons whose halves are too far apart for a sprite pair are characters: **SmallBand**
  (SlowBand for normal width; SlowBand itself now only for four-times-wide bands) works each
  line out once into column slices (SbP1, SbP0, SbM0: what player 0 covers, inverted; slice 3
  none) and fetches each cell once (SbCell, GetCell): ~19.6-26K cycles a picture became ~12-17K.
  Multicolour of a line = MC(g) + MC(pixels drawn "10"), that mask alternating each line.
- Sprite demons (SprDemon): LeftWin by table, player 1's row above placed only when the band
  has pixels left of 19 (swUp), the mix unrolled with the line parity chosen once a row.
- Then (commit adb6c9f): SmallBand's covered mask from player 0's shifted bytes (CoverInv),
  slices with no pixels skipped and the cells listed once per band (SbLCol/SbLK1/SbLK0), SbCell's
  lines ended by compare (`_qce`); a split band ~5.8K cycles (12-14K at first). The diving demon:
  SmallSetup works its left19 / pv1 masks out once per band (two sets: the cannon's lines and
  the others), SmallRow just stores its rows, SprDemon's mix for it on byte 0 only: such
  pictures 12.1K → 8.6K. bench --cheat: PAL 83.3%, NTSC 80.4% (seeds 49-96: 84.1 / 81.7).
  vicecheck PAL 80 samples: 2 differ (the build before: 4), NTSC 0 of 40.
- Left in later waves (NTSC seed 7 cheat, per frame): DrawBullets ~0.9K, SmallBand + SbCell +
  GetCell ~1.6K, collisions in the game step (BallLines, BandPP ~1.3K: a game step costs more
  than drawing, −6.2 NTSC points per 1K), SmallRow (the small diving demon) ~0.75K per such
  picture.

## Collisions (game step), 2026-10-02

- bench: normal **PAL 95.1%, NTSC 92.1%**, `--cheat` **PAL 82.7%, NTSC 79.8%**. Game step
  (lockstep, normal) ~3.78K cycles on average (3.95K before).
- BandPP, normal width: rows by Y through patched graphics addresses, the shift by a jump into
  seven lsr's (forward: player 1 >> oD; back: player 0 >> 160 - oD). Four times as wide with
  player 1 from pixel 19 to 128: on the graphics bytes, `(b >> q | (r ? b >> q+1 : 0)) & other`
  for d = 4q + r (checked against the pixel overlap for all bytes and d: no mismatch); else the
  old 32-pixel path (`_qold`).
- BallLines: in the cannon band, when only the cannon is in the laser's column (c1m 0, not the
  explosion), lines from 209 only (the cannon's lines 11-0).
- `node tools/lockstep.js N --tickprofile [--top=N]`: the game steps' routines only.
- Left in a step (normal game, cycles): 2600 program ~1.6K; BallLines ~0.56K, Collide ~0.3K,
  ReadInput ~0.3K, UpdateSound ~0.28K, ClassifyLine ~0.24K, Digits2 ~0.18K, BandSetup ~0.17K,
  WriteX ~0.11K, CannonSetup ~0.1K. Per frame the raster interrupt costs ~3K (Irq, ITop, IGround,
  IRunN0-3, IPair) and DrawBullets ~1.3K (already redraws only rows that changed).

## Bullets, 2026-10-02 (commit 0949d05)

- bench: normal **PAL 95.3%, NTSC 92.6%**, `--cheat` **PAL 83.7%, NTSC 80.8%**. vicecheck: PAL 3
  of 80 differ (earlier builds 2 and 4 of 80), NTSC 0 of 40.
- DrawBullets 1275 → 1079 cycles a frame (normal game): "any at all" by an unrolled OR, blank
  rows checked through a patched BulKZ address (`_qkz`), and the bullets' column classed once
  when it changes (bulSmK: 0 all of it right of where GRP1 lands, 1 all left, 2 mixed): the
  groups' first lines then take this line's or the line above's value without `_mix`.
- Left: the write path (`_wr`, ~185 cycles a changed row: cache + 8 sprite bytes), the cache
  compares, the bullets' positions and schedule entries (`_pos`, ~170 a picture with bullets).

## Materializing setup and the schedule, 2026-10-02 (last round)

- FbFromCache's row-up FbAny unrolled, fbAdj unrolled, the band's second row = first + 40 (no
  LineRow), the shared-column setup only when the players can share one, PairL0 in one page
  (low-byte patches): a materializing picture 11.19K → 10.97K. bench normal PAL 95.4%, NTSC
  92.7% (+0.1, noise level); `--cheat` 83.7% / 80.8%.
- The schedule (SchedAdd ~55 cycles an entry, SchedColourRun ~195 a run, ~0.95K a frame) is
  mostly stores the interrupt and the check tools need: left as it is.
- Where the limit is now: on NTSC a frame leaves roughly 8K cycles for drawing after the
  interrupt (~3K), the VIC's stalls and a game step (~3.8K). Pictures over that are the
  late ones: materializing (~11K) and split-demon pictures (~12-17K). Trimming no longer moves
  them under the line; that would take a different way of drawing them (e.g. sprites for the
  split halves), not more tuning.

## What is left (ideas, roughly by size)

- Fixed setup per picture is now the bulk (~3K): FbFlush (K0Of, fbAdj loop, two LineRow calls),
  FbFastSet (~250: two runners' patches; PairL0 of both buffers in one page and FbT split into
  page-aligned halves would cut hi-byte patches), FbRange/FbFast (~450), FbFromCache (the row-up
  FbAny loop when player 1 is left of pixel 19: ~185), FbCells (~240), FatBand.
- FbFastSC: the usual clearing misses ~1.8 times a picture (cells with no pixels last time,
  player 0's cells whose pair went unused in a shared column); its "p > fbL0" case clears to line 15 rather than to p + 7.
- DrawBullets costs ~1.4K in materializing pictures (~0.9K on average): not looked at.

## Tried and dropped (don't repeat blindly)

- Batching a player's 9 cells with one stride-16 pointer while also handling empty cells and its
  own checks (`FbFast`, before the ready-made lines): no faster. (Now it works: the ready-made
  lines have the same 16-byte stride, so Y serves source and pair alike.)
- Holding the band's character rows across pictures (no take/restore per column): rows change in
  about a third of pictures, release + take cost more (−1 point).
- Tables for the 2600's position-step loops ($1CCF/$1CDE): only ~4 steps per call, no gain.
- Run-ahead limits > 2, triple buffering: no gain.
- Colour runs entered 1 line before their first write instead of 2 (SchedColourRun's
  `LINE2RAS-3`): the handler's own setup takes ~1.6 lines, so writes left their windows (c64run
  "colour writes off their line or window" 4.5K → 20K NTSC, 26K PAL). The interrupt (~3K a
  frame) is mostly the runs' per-line waits, which the raster sets; the frame top's register
  copies and ~85 cycles per interrupt entry are close to minimal.

## Checks after every change (read the result lines!)

- Build: `.\build.cmd` (PowerShell) now also rewrites the web builder's profile
  (site/games/demon-attack.json) from the build: during development leave site/ uncommitted (or
  build with the assembler only: `node tools\mkc64tables.js`, then 64tass as in build.cmd, and
  c1541 for the .d64) — then
- `node tools/screencheck.js 4000 --cheat --seed=N` for several seeds (3, 7, 11, 21, 45) and a
  normal one: **"all exact"** (lockstep does NOT check the picture).
- `node tools/lockstep.js 6000`, `--cheat --seed=21`, `--power=1500`: "0 with differences".
- `node tools/bench.js` with `DA_BUILD=<copy dir>` (copy build\ first, so it can change meanwhile).
- Now and then `node tools/vicecheck.js 80` (and `--ntsc`, `--cheat` for the later waves):
  differing frames should stay a few in 80 (see the table at the top). Give parallel runs their own `--out=dir` (the default folder is shared:
  two runs at once overwrite each other's files).
- `node tools/c64run.js 3000 --ntsc --seed=7 --cheat --tickinput`: "sprite pairs moved too
  late: 0", and "colour writes off their line or window" not much above version 1.0's (a few
  thousand: mostly writes after a bad line landing a few cycles into the line).
- c64run.js lists self-modified instructions it accepts (`patchOK`: `_jmp|_sr|...|_q...` labels and
  the rts slots of FbW2/FbZ/LCopy0/1): add new patch sites there, or "writes into the code" shows.

## Pitfalls met

- After `git checkout` the sources are CRLF; LF-based patch scripts then fail silently. Prefer the
  Edit tool, or node scripts that throw when a pattern isn't found exactly once.
- 64tass: `#>A ^ >B` parses as `#>(A ^ >B)` — parenthesize (also in `.cerror`); branch ranges break
  often in this code; `cmp` that falls through leaves carry as compared.
- Variables move when code grows: FatCol must stay in one page (FbRun increments its pointer's low
  byte; vars.asm pads before it); patch both address bytes of anything else.
- Zero page $40-$7F is full (srcP is an alias of the unused imgPtr; ptrA is free during FbFlush).
- Never `taskkill /IM x64sc.exe` (it closes other sessions' VICE); stop only your own instance.
- Memory: the main area ends ~$BFA8 (about 85 bytes free below $C000); split.asm sits in the
  start-up area ($0991-$0EAA, about 340 bytes free below $1000); $F000-$FE0F holds the ready-made
  lines, $FE10-$FFF9 is free (not in the .prg: generated data only); sprite blocks 61-62 and the
  characters 216-255 of both sets hold split halves (Half2*), 63 is free.
- 64tass local labels belong to the last global label: code sharing locals across two entries
  needs `Global._local` (DrawBand jumps to DrawBandF._sprite).
- On the band's lines the sprite fetches decide the colour runs' timing: with all 8 sprites on, a
  run's line of work must stay under ~44 cycles (PAL), or its writes drift a line late.
