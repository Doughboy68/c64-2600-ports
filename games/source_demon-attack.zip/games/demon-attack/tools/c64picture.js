// The picture a C64 buffer shows (characters, sprites, the raster schedule with the cycle
// each colour write lands on), as C64 colours per 2600 pixel: shared by screencheck.js
// (against the 2600's picture) and vicecheck.js (against VICE's screen).
const NSCHED = 24, LINE2RAS = 11, FIRST = 40, LAST = 239;
const S = { TOP: 0, RUN: 2, SET: 4, BUL: 6, END: 8, PAIR: 10, GND: 12 };
// c64: a C64 (tools/c64sim.js) whose memory and I/O hold the state to draw
function picturer(c64) {
  const sym = n => c64.sym(n), M = c64.mem;
  // runs writing two registers a line: { variant's address: [second register's offset from the first, the delay
  // on the band's lines (3: sprites 4-7 on, hold the CPU to cycle 11; 4: as the one-pair runs)] }
  const dualAt = new Map([['IRunP6', 2, 3], ['IRunP7', 2, 3], ['IRunP8', 0x22 - 0x2b, 4], ['IRunP9', 0x22 - 0x2b, 4], ['IRunP10', 0x22 - 0x2d, 3], ['IRunP11', 0x22 - 0x2d, 3]]
    .map(([n, o, d]) => { try { return [sym(n), [o, d]]; } catch (e) { return [-1, null]; } }));
  // ---- the C64 frame drawn by buffer b, as C64 colours per 2600 pixel (160 x 262)
  function c64Picture(b) {
    const col = new Uint8Array(160 * 262).fill(255), what = new Uint8Array(160 * 262);   // what: 1 sprite, 2 char 10/11, 3 char 01
    const scr = [0xC000, 0xC400, 0xF800][b], chars = [0xE000, 0xE800, 0xF000][b];
    // registers as the frame goes: [raster, pixel (-1 = whole line), reg, value] writes
    const reg = { 0x21: M[sym('StD021') + b], 0x22: M[sym('StD022') + b], 0x23: M[sym('StD023') + b] };
    for (let n = 0; n < 8; n++) reg[0x27 + n] = M[sym('StCol') + 8 * b + n];
    const sp = [...Array(8)].map((_, n) => ({
      en: (M[sym('StEn') + b] >> n) & 1, x: M[sym('StX') + 8 * b + n] + ((M[sym('StMsb') + b] >> n) & 1) * 256,
      y: M[sym('StY') + 8 * b + n], ptr: M[sym('StPtr') + 8 * b + n], start: -1, last: -99,
    }));
    const writes = [];          // {ras, cyc, fn}
    for (let i = 1; i < NSCHED; i++) {
      const e = b * NSCHED + i, type = M[sym('SchedType') + e], ras = M[sym('SchedRas') + e], a = M[sym('SchedArg') + e];
      if (type === S.END) break;
      if (type === S.RUN || type === S.GND) {
        const first = M[sym('RunFirst') + a], cnt = M[sym('RunCnt') + a];
        // (a dual run, both sprite pairs (a split band): each write to the other pair's register too, 4 cycles later)
        const jl = M[sym('RunJLo') + a] | M[sym('RunJHi') + a] << 8, dual = dualAt.get(jl), d2 = dual ? dual[0] : 0;
        writes.push({ ras, cyc: 0, r: M[sym('RunSetReg') + a], v: M[sym('RunSetVal') + a] });
        if (dual) writes.push({ ras, cyc: 0, r: M[sym('RunSetReg') + a] + d2, v: M[sym('RunSetVal') + a] });
        const ground = type === S.GND, regA = M[sym('RunRegA') + a], regB = M[sym('RunRegB') + a];
        if (ground) {             // the ground: line 223's $D023 at once, then lines 223 + j (from
          const skip = M[sym('RunSkip') + a], base = M[sym('RunRas') + first];   // j = skip) during the line before
          writes.push({ ras, cyc: 0, r: 0x23, v: M[sym('RunVal') + first] });
          for (let n = 1; n < cnt; n++) { const j = skip + n - 1; writes.push({ ras: base + j, cyc: 7, r: j & 1 ? 0x21 : 0x23, v: M[sym('RunVal') + first + j] }); }
          continue;
        }
        const band = M[sym('RunBand') + a], prevPix = M[sym('RunPrevF') + a] === 0;
        for (let k = 0; k < cnt; k++) {
          const L = band + k, dly = prevPix && (L & 7) !== 1 ? (dual ? dual[1] : 4) : 1, wr = L + LINE2RAS - 1;
          const bad = (wr & 7) === 3 && wr >= 48 && wr <= 247;
          // earliest write: poll sees the line on cycle 0; d + 12 (no loop) or d + 10 + 5n; on a
          // bad line the CPU stops from cycle 12 to 54 (a write whose reads reach cycle 12 waits)
          // (a dual run's lines after its first: sprites 4-7 are on, their fetches hold the CPU to cycle 11)
          let cyc = dly === 0 ? (k === 2 ? 58 - 63 : 7) : (dual && k > 0 && dly === 3 ? 11 : 0) + 10 + 5 * dly;   // (the ground's line 224: at the end of line 223)
          if (bad && cyc - 1 >= 12) cyc += 43;
          writes.push({ ras: wr + (cyc >= 63 ? 1 : 0), cyc: cyc >= 63 ? cyc - 63 : cyc, r: k & 1 ? regB : regA, v: M[sym('RunValB') + 8 * b + k] });
          if (dual) { const c2 = cyc + 4; writes.push({ ras: wr + (c2 >= 63 ? 1 : 0), cyc: c2 >= 63 ? c2 - 63 : c2, r: (k & 1 ? regB : regA) + d2, v: M[sym('RunValB') + 8 * b + k] }); }
        }
      }
      if (type === S.SET) writes.push({ ras, cyc: 0, r: M[sym('SetReg') + a], v: M[sym('SetVal') + a] });
      if (type === S.BUL) writes.push({ ras, cyc: 0, fn: () => { const n = 2 + (a & 1); sp[n].ptr = M[sym('BulPtr') + a]; sp[n].y = M[sym('BulY') + a]; } });
      if (type === S.PAIR) writes.push({ ras, cyc: 0, fn: () => {
        const n = M[sym('PairN') + a], msb = M[sym('PairMsb') + a], bits = M[sym('PairBitsR') + a];
        for (const k of [0, 1]) {
          sp[n + k].ptr = M[sym(k ? 'PairPtr2' : 'PairPtr') + a]; sp[n + k].y = M[sym(k ? 'PairY2' : 'PairY') + a];
          sp[n + k].x = M[sym('PairX') + a] + ((msb & bits) & (1 << (n + k)) ? 256 : 0);
        }
      } });
    }
    writes.sort((p, q) => p.ras - q.ras || p.cyc - q.cyc);
    let wi = 0;
    for (let L = FIRST; L <= LAST; L++) {
      const ras = L + LINE2RAS;
      // the line's writes: those before it (and at its start) take effect for the whole line;
      // those part-way along it from pixel 4 * (cycle - 16)
      const mid = [];
      while (wi < writes.length && writes[wi].ras <= ras) {
        const w = writes[wi++];
        if (w.ras === ras && w.cyc > 16) mid.push(w);
        else if (w.fn) w.fn(); else reg[w.r] = w.v;
      }
      const regAt = (r, x) => { let v = reg[r]; for (const w of mid) if (!w.fn && w.r === r && x >= 4 * (w.cyc - 16)) v = w.v; return v; };
      const row = (L - 40) >> 3, li = (L - 40) & 7;
      const after = () => { for (const w of mid) if (w.fn) w.fn(); else reg[w.r] = w.v; };
      for (let x = 0; x < 160; x++) {
        const ch = M[scr + row * 40 + (x >> 2)], byte = M[chars + ch * 8 + li], pair = (byte >> (6 - 2 * (x & 3))) & 3;
        const i = L * 160 + x;
        if (pair === 3) { col[i] = c64.io[0x800 + row * 40 + (x >> 2)] & 7; what[i] = 2; }
        else if (pair === 2) { col[i] = regAt(0x23, x); what[i] = 2; }
        else if (pair === 1) { col[i] = regAt(0x22, x); what[i] = 3; }
        else col[i] = regAt(0x21, x);
      }
      for (let n = 7; n >= 0; n--) {               // (sprite 0 in front)
        const s = sp[n];
        if (!s.en) continue;
        if (s.start >= 0 && ras - s.start >= 21) { s.last = s.start; s.start = -1; }   // its 21 rows are done
        if (s.start < 0 && s.y + 1 === ras && !(ras - s.last < 22)) s.start = ras;     // (again only 22 lines after its last start)
        if (s.start < 0) continue;
        const r = ras - s.start, base = 0xC000 + s.ptr * 64 + 3 * r;
        for (let k = 0; k < 3; k++) for (let bit = 0; bit < 8; bit++) if (M[base + k] & (0x80 >> bit)) {
          const px = ((s.x - 24) >> 1) + 8 * k + bit;
          if (px < 0 || px >= 160) continue;
          const i = L * 160 + px;
          if (n === 0 && what[i] === 2) continue;                          // the laser: behind 10 / 11
          col[i] = regAt(0x27 + n, px); what[i] = 1; if (globalThis.dbgSpr) globalThis.dbgSpr[i] = n * 256 + r * 4 + k + 0x10000 * s.ptr;
        }
      }
      after();                                     // (the writes part-way along: from here on)
    }
    return { col, what };
  }
  return c64Picture;
}
module.exports = { picturer, NSCHED, LINE2RAS, FIRST, LAST, S };
