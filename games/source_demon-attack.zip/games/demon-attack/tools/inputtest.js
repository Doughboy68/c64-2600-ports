// Checks ReadInput: joysticks (port 2 = player 1, port 1 = player 2) and keys (A, D, Space)
// against the 2600 ports the game reads (SWCHA, INPT4, INPT5), and the console keys (F1-F8,
// a pass at a time) against SWCHB and the power switch, on the 6502 core with the CIA's
// keyboard matrix simulated.
//   node games/demon-attack/tools/inputtest.js
const { C64 } = require('./c64sim');
const c = new C64();
c.start();
const sym = n => c.sym(n);
// keys: [row, bit] in the matrix ($DC00 selects rows by a 0 bit, $DC01 reads columns)
const KEY = { A: [1, 2], D: [2, 2], SPACE: [7, 4], F1: [0, 4], F3: [0, 5], F5: [0, 6], F7: [0, 3], LSHIFT: [1, 7], RSHIFT: [6, 4] };
let port2 = 0x1F, port1 = 0x1F, keys = [];
const origRead = c.read.bind(c);
c.read = function (a) {
  a &= 0xFFFF;
  if (this.ioOn() && a === 0xDC00) return 0xE0 | port2;
  if (this.ioOn() && a === 0xDC01) {
    const sel = this.io[0xC00];
    let v = 0xFF & (0xE0 | port1);
    for (const [r, b] of keys) if (!(sel & (1 << r))) v &= ~(1 << b);
    return v;
  }
  return origRead(a);
};
// joystick bits: 0 up, 1 down, 2 left, 3 right, 4 fire (0 = pressed)
const J = { up: 1, down: 2, left: 4, right: 8, fire: 16 };
const cases = [
  ['nothing', {}, 0xFF, 0x80, 0x80],
  ['port 2 up', { p2: 'up' }, 0xEF, 0x80, 0x80],
  ['port 2 down', { p2: 'down' }, 0xDF, 0x80, 0x80],
  ['port 2 left', { p2: 'left' }, 0xBF, 0x80, 0x80],
  ['port 2 right', { p2: 'right' }, 0x7F, 0x80, 0x80],
  ['port 2 fire', { p2: 'fire' }, 0xFF, 0x00, 0x80],
  ['port 1 up', { p1: 'up' }, 0xFE, 0x80, 0x80],
  ['port 1 left', { p1: 'left' }, 0xFB, 0x80, 0x80],
  ['port 1 right', { p1: 'right' }, 0xF7, 0x80, 0x80],
  ['port 1 fire', { p1: 'fire' }, 0xFF, 0x80, 0x00],
  ['key A', { k: ['A'] }, 0xBB, 0x80, 0x80],
  ['key D', { k: ['D'] }, 0x77, 0x80, 0x80],
  ['Space', { k: ['SPACE'] }, 0xFF, 0x00, 0x00],
  ['A + Space', { k: ['A', 'SPACE'] }, 0xBB, 0x00, 0x00],
];
let bad = 0;
for (const [name, s, swcha, inpt4, inpt5] of cases) {
  port2 = 0x1F & ~(s.p2 ? J[s.p2] : 0); port1 = 0x1F & ~(s.p1 ? J[s.p1] : 0);
  keys = (s.k || []).map(k => KEY[k]);
  c.mem[sym('DbgSWCHA')] = 0xFF; c.mem[sym('DbgINPT4')] = 0xFF;
  c.call(sym('ReadInput'));
  const got = [c.mem[0x280], c.mem[0x3C] & 0x80, c.mem[0x3D] & 0x80];
  const ok = got[0] === swcha && got[1] === inpt4 && got[2] === inpt5;
  if (!ok) bad++;
  console.log(`${ok ? 'ok ' : 'BAD'} ${name.padEnd(14)} SWCHA ${got[0].toString(16)} (want ${swcha.toString(16)}), INPT4 ${got[1].toString(16)} (${inpt4.toString(16)}), INPT5 ${got[2].toString(16)} (${inpt5.toString(16)})`);
}
// the console keys, one pass after another: SWCHB (bits 0 reset, 1 select, 3 colour, 6 / 7
// difficulty) and the power switch (F2: F1 with shift, on key-down)
port2 = port1 = 0x1F;
const seq = [
  ['nothing', [], 0x0B, 0], ['F1 (reset)', ['F1'], 0x0A, 0], ['F1 held', ['F1'], 0x0A, 0], ['F1 up', [], 0x0B, 0],
  ['F3 (select)', ['F3'], 0x09, 0], ['F3 up', [], 0x0B, 0],
  ['F7 (left difficulty)', ['F7'], 0x4B, 0], ['F7 held', ['F7'], 0x4B, 0], ['F7 up', [], 0x4B, 0],
  ['F8 (right difficulty)', ['LSHIFT', 'F7'], 0xCB, 0], ['F8 up', [], 0xCB, 0],
  ['F5 (colour)', ['F5'], 0xC3, 0], ['F5 up', [], 0xC3, 0],
  ['F2 (power)', ['LSHIFT', 'F1'], 0xC3, 1], ['F2 held', ['LSHIFT', 'F1'], 0xC3, 0], ['F2 up', [], 0xC3, 0],
  ['F2 right shift', ['RSHIFT', 'F1'], 0xC3, 1], ['F2 up', [], 0xC3, 0], ['nothing', [], 0xC3, 0],
];
for (const [name, k, swchb, power] of seq) {
  keys = k.map(x => KEY[x]);
  c.mem[sym('PowerReq')] = 0;
  c.mem[sym('DbgSWCHB')] = 0xFF;
  c.call(sym('ReadInput'));
  const got = [c.mem[0x282], c.mem[sym('PowerReq')] ? 1 : 0];
  const ok = got[0] === swchb && got[1] === power;
  if (!ok) bad++;
  console.log(`${ok ? 'ok ' : 'BAD'} ${name.padEnd(22)} SWCHB ${got[0].toString(16)} (want ${swchb.toString(16)}), power ${got[1]} (${power})`);
}
console.log(bad ? `${bad} wrong` : 'all right');
process.exit(bad ? 1 : 0);
