// Pixel columns for the game's position codes (high nibble: fine motion for HMOVE, low
// nibble: coarse delay), measured by running the kernel's own positioning code in
// tools/vcs.js for every code. Writes tools/pos.json:
//   p0[v]  player 0 in a demon band (and the cannon, band 3)    ($8D-$90)
//   p1[v]  player 1 in a demon band (and the bullets / small demon) ($91-$94)
//   bl[v]  the ball (the laser) at the top of the frame          ($96)
//   node games/demon-attack/tools/mkpos.js
const fs = require('fs');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('b12a7f63787a6bb08e683837a8ed3f18');
function runTo(v, start, stop) {
  let g = 0;
  v.pc = start;
  while (v.pc !== stop) { v.step(); if (++g > 5000) throw new Error('lost at ' + v.pc.toString(16)); }
}
const p0 = [], p1 = [], bl = [];
for (let c = 0; c < 256; c++) {
  let v = new VCS(rom);
  v.ram[0xBF - 0x80] = 0xFF;                       // band 0
  v.ram[0x8D - 0x80] = c; v.ram[0x91 - 0x80] = c;
  runTo(v, 0x1095, 0x10C2);                        // two positioning lines and the HMOVE line
  p0.push(v.pos[0]); p1.push(v.pos[1]);
  v = new VCS(rom);
  v.ram[0x96 - 0x80] = c; v.x = 0;
  runTo(v, 0x1000, 0x103F);                        // the ball, then the HMOVE two lines down
  bl.push(v.pos[4]);
}
fs.writeFileSync(__dirname + '/pos.json', JSON.stringify({ p0, p1, bl }));
const show = (n, t) => console.log(n, [...Array(16)].map((_, lo) => [...Array(16)].map((_, hi) => t[hi << 4 | lo])).map((r, lo) => lo + ':' + r.join(',')).join('  '));
show('p0', p0); show('p1', p1); show('bl', bl);
