// What VICE really shows, against the picture the C64's own state says it should show.
// Plays the C64 build in VICE (random moves and fire, through its remote monitor, on a port
// of its own); now and then stops it at the frame's end (IEnd: the picture is complete, curBuf is
// the buffer it was drawn from), saves VICE's screen and the C64's memory, then draws that
// buffer's picture the way screencheck.js does (c64picture.js: ideal timing) and compares
// the two pixel for pixel. A difference is something the real timing got wrong (a colour
// write too late, a sprite moved at the wrong line ...).
//   node games/demon-attack/tools/vicecheck.js [samples] [--ntsc] [--cheat] [--out=dir] [--seconds=s]
// (DA_BUILD=dir: another copy of the build)
// (Any other VICE is left alone; only the one started here is closed.)
const fs = require('fs');
const net = require('net');
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const { startVice, stopVice } = require('./vicectl');
const { C64 } = require('./c64sim');
const { picturer, FIRST, LAST } = require('./c64picture');

const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? a.split('=')[1] : d; };
const samples = +(process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : 20);
const ntsc = process.argv.includes('--ntsc');
const cheat = process.argv.includes('--cheat');
const out = path.resolve(arg('out', path.join(os.tmpdir(), 'vicecheck')));
const between = +arg('seconds', 1.5);
const root = path.join(__dirname, '..');
fs.mkdirSync(out, { recursive: true });
const c64 = new C64();
const sym = n => c64.sym(n);
const hex = v => v.toString(16);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const slash = p => p.split(path.sep).join('/');
// the label at or before an address (the listing's global labels)
const labels = [...c64.lst.matchAll(/^.([0-9a-f]{4})\t[^\n]*\t([A-Z][A-Za-z0-9_]*)/gm)].map(m => [parseInt(m[1], 16), m[2]]).sort((p, q) => p[0] - q[0]);
const labelAt = a => { if (a >= 0x1000 && a < 0x2000) return ' (2600 program)'; let r = ''; for (const [v, n] of labels) if (v <= a) r = ` (${n} + ${a - v})`; return r; };

// ---- the monitor: one connection, commands answered by its prompt
let sock = null, buf = '';
const connect = () => new Promise((resolve, reject) => {
  sock = net.connect(vice.port, '127.0.0.1');
  buf = '';
  sock.on('data', d => { buf += d.toString('latin1'); });
  sock.on('error', reject);
  sock.on('connect', () => resolve());
});
const waitFor = async (re, ms = 20000) => {
  const t0 = Date.now();
  while (!re.test(buf)) { if (Date.now() - t0 > ms) throw new Error('monitor: no ' + re + ' in ' + JSON.stringify(buf.slice(-300))); await sleep(20); }
};
const cmd = async c => { buf = ''; sock.write(c + '\n'); await waitFor(/\(C:\$[0-9a-f]{4}\) $/i); return buf; };
const resume = async () => { sock.write('x\n'); await sleep(50); };
const close = async () => { if (sock) { sock.end(); sock = null; await sleep(100); } };
const poke = async (a, v) => { await connect(); await sleep(150); await cmd(`> ${hex(a)} ${v}`); await resume(); await close(); };

// ---- PNG (RGB / RGBA, 8 bits, no interlace)
function readPng(file) {
  const b = fs.readFileSync(file); let i = 8, w, h, ch; const idat = [];
  while (i < b.length) {
    const len = b.readUInt32BE(i), t = b.toString('ascii', i + 4, i + 8), d = b.slice(i + 8, i + 8 + len);
    if (t === 'IHDR') { w = d.readUInt32BE(0); h = d.readUInt32BE(4); ch = d[9] === 6 ? 4 : 3; }
    if (t === 'IDAT') idat.push(d);
    i += 12 + len;
  }
  const raw = zlib.inflateSync(Buffer.concat(idat)), st = w * ch, px = Buffer.alloc(h * st);
  let prev = Buffer.alloc(st);
  for (let y = 0; y < h; y++) {
    const f = raw[y * (st + 1)], line = raw.subarray(y * (st + 1) + 1, (y + 1) * (st + 1)), o = Buffer.alloc(st);
    for (let x = 0; x < st; x++) {
      const a = x >= ch ? o[x - ch] : 0, up = prev[x], c = x >= ch ? prev[x - ch] : 0;
      let v = line[x];
      if (f === 1) v += a; else if (f === 2) v += up; else if (f === 3) v += (a + up) >> 1;
      else if (f === 4) { const p = a + up - c, pa = Math.abs(p - a), pb = Math.abs(p - up), pc = Math.abs(p - c); v += pa <= pb && pa <= pc ? a : pb <= pc ? up : c; }
      o[x] = v & 255;
    }
    o.copy(px, y * st); prev = o;
  }
  return { w, h, rgb: (x, y) => { const k = (y * w + x) * ch; return [px[k], px[k + 1], px[k + 2]]; } };
}

let vice = null;
(async () => {
  vice = await startVice(require('../../../tools/buildname').files(path.join(process.env.DA_BUILD || path.join(root, 'build'))).prg, ntsc);
  await sleep(8000);
  await poke(sym('DbgINPT4'), '7f'); await sleep(400); await poke(sym('DbgINPT4'), 'ff');   // fire: start a game
  await sleep(1500);
  let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  let palette = null, bad = 0;
  const learnt = {};
  const badLines = {};
  for (let n = 0; n < samples; n++) {
    // play a while
    const t0 = Date.now();
    while (Date.now() - t0 < between * 1000) {
      const r = rnd();
      await connect(); await sleep(150);
      await cmd(`> ${hex(sym('DbgSWCHA'))} ${r < .4 ? 'bf' : r < .8 ? '7f' : 'ff'}`);
      await cmd(`> ${hex(sym('DbgINPT4'))} ${rnd() < .6 ? '7f' : 'ff'}`);
      await resume(); await close();
      // (--cheat: the later waves, as play.js's cheat: a random wave number now and then (from
      // the next wave on), waves cut short, bunkers kept; a connection of its own: the monitor
      // answers only a few commands per connection)
      if (cheat) {
        await connect(); await sleep(150);
        await cmd(rnd() < .3 ? `> be ${hex(Math.floor(rnd() * 24))}` : '> f2 03 03');
        if (rnd() < .2) await cmd('> 9b 07');
        await resume(); await close();
      }
      await sleep(300);
    }
    // stop at the frame's end: screen, memory, VIC registers, colour RAM
    await connect(); await sleep(150);
    await cmd(`break ${hex(sym('IEnd'))}`);
    buf = ''; sock.write('x\n');
    await waitFor(/\(C:\$[0-9a-f]{4}\) $/i);
    await cmd('delete');
    const regs = await cmd('r');
    fs.writeFileSync(path.join(out, `s${n}.regs.txt`), regs);
    const shotFile = path.join(out, `s${n}.png`), memFile = path.join(out, `s${n}.bin`);
    await cmd(`screenshot "${slash(shotFile)}" 2`);
    await sleep(800);
    await cmd('bank ram');
    await cmd(`save "${slash(memFile)}" 0 0000 ffff`);
    await cmd('bank io');
    const vic = await cmd('m d000 d03f'), cram = await cmd('m d800 dbff');
    await cmd('bank cpu');
    await resume(); await close();
    for (let t = 0; t < 50 && !fs.existsSync(memFile); t++) await sleep(100);
    await sleep(300);
    // the C64's state, and the picture it should show
    const mem = fs.readFileSync(memFile);
    c64.mem.set(mem.subarray(2, 2 + 0x10000));
    const parse = (o, base) => { for (const m of o.matchAll(/>C:([0-9a-f]{4})((?:\s+[0-9a-f]{2}){1,16})/gi)) { const a = parseInt(m[1], 16); m[2].trim().split(/\s+/).forEach((v, k) => { c64.io[a - 0xD000 + k] = parseInt(v, 16); }); } };
    parse(vic); parse(cram);
    const b = c64.mem[sym('curBuf')];
    // where the main program was: the interrupt pushed PC and P
    const sp = parseInt((regs.match(/\.;[0-9a-f]{4}\s+[0-9a-f]{2}\s+[0-9a-f]{2}\s+[0-9a-f]{2}\s+([0-9a-f]{2})/i) || [])[1] || '0', 16);
    const mainPC = c64.mem[0x100 + ((sp + 2) & 255)] | c64.mem[0x100 + ((sp + 3) & 255)] << 8;
    console.log(`  (main program at $${hex(mainPC)}${labelAt(mainPC)}; pictures ${c64.mem[sym('DbgLoops')] + 256 * c64.mem[sym('DbgLoops') + 1]}, frames ${c64.mem[sym('DbgFrames')] + 256 * c64.mem[sym('DbgFrames') + 1]}, game frame ${c64.mem[0xBD]})`);
    const { col } = picturer(c64)(b);
    // VICE's screen: find where the 2600's picture lies (2 pixels per 2600 pixel, a line per
    // line) by trying offsets; colours by the nearest of the palette (learnt from the matches)
    const img = readPng(shotFile);
    const PAL = [[0, 0, 0], [255, 255, 255], [0x96, 0x28, 0x2e], [0x5b, 0xd6, 0xce], [0x9f, 0x2d, 0xad], [0x41, 0xb9, 0x36], [0x27, 0x24, 0xc4], [0xef, 0xf3, 0x47],
      [0x9f, 0x48, 0x15], [0x5e, 0x35, 0x00], [0xda, 0x5f, 0x66], [0x47, 0x47, 0x47], [0x78, 0x78, 0x78], [0x91, 0xff, 0x84], [0x68, 0x64, 0xff], [0xae, 0xae, 0xae]];
    palette = palette || PAL;
    const idx = ([r, g, bl]) => { let best = 0, bd = 1e9; palette.forEach((p, k) => { const d = (p[0] - r) ** 2 + (p[1] - g) ** 2 + (p[2] - bl) ** 2; if (d < bd) { bd = d; best = k; } }); return best; };
    const cmpAt = (dx, dy, all) => {
      let diff = 0; const xs = [];
      for (let L = FIRST; L <= LAST; L += all ? 1 : 3) for (let x = 0; x < 160; x += all ? 1 : 2) {
        const sx = dx + 2 * x, sy = dy + L;
        if (sx < 0 || sy < 0 || sx >= img.w || sy >= img.h) { diff++; continue; }
        const want = col[L * 160 + x];
        if (want === 255) continue;
        if (idx(img.rgb(sx, sy)) !== want) { diff++; if (all) xs.push([L, x, want, idx(img.rgb(sx, sy))]); }
      }
      return all ? xs : diff;
    };
    let best = null;
    for (let dy = -60; dy <= 20; dy++) for (let dx = 20; dx <= 44; dx += 2) { const d = cmpAt(dx, dy, false); if (!best || d < best.d) best = { dx, dy, d }; }
    // the screen's own colours: each RGB value stands for the C64 colour it is most often
    // wanted as (learnt over all the frames so far; VICE's palette and filters vary)
    for (let L = FIRST; L <= LAST; L++) for (let x = 0; x < 160; x++) {
      const want = col[L * 160 + x]; if (want === 255) continue;
      const k = img.rgb(best.dx + 2 * x, best.dy + L).join(',');
      (learnt[k] = learnt[k] || new Array(16).fill(0))[want]++;
    }
    const seen = k => { const c = learnt[k]; return c ? c.indexOf(Math.max(...c)) : -1; };
    const diffs = [];
    for (let L = FIRST; L <= LAST; L++) for (let x = 0; x < 160; x++) {
      const want = col[L * 160 + x]; if (want === 255) continue;
      const got = seen(img.rgb(best.dx + 2 * x, best.dy + L).join(','));
      if (got !== want) diffs.push([L, x, want, got]);
    }
    if (diffs.length) {
      bad++;
      const lines = {};
      for (const [L] of diffs) { lines[L] = (lines[L] || 0) + 1; badLines[L] = (badLines[L] || 0) + 1; }
      console.log(`sample ${n} (buffer ${b}, offset ${best.dx},${best.dy}): ${diffs.length} pixels differ; lines ${Object.entries(lines).slice(0, 12).map(([l, k]) => l + ':' + k).join(' ')}; e.g. ${diffs.slice(0, 4).map(([L, x, w, g]) => `${L}/${x} want ${w} got ${g}`).join(', ')}`);
    } else console.log(`sample ${n} (buffer ${b}, offset ${best.dx},${best.dy}): exact`);
  }
  console.log(`${ntsc ? 'NTSC' : 'PAL'}: ${samples} frames compared, ${bad} differ` + (bad ? '; lines ' + Object.entries(badLines).sort((p, q) => q[1] - p[1]).slice(0, 15).map(([l, k]) => l + ':' + k).join(' ') : ''));
  console.log('screens and memory in', out);
})().catch(e => console.log('error:', e.message)).finally(() => {
  stopVice(vice);
});
