// Run the C64 version's game ticks (the patched 2600 program plus the collision code, from
// build/demonattack-<version>.prg) on a plain 6502 (tools/c64sim.js), side by side with the
// original game in tools/vcs.js, with the same inputs (tools/play.js). Once a frame both
// stop just after the picture (the 2600 has drawn it, the C64 has worked out what the TIA
// would have seen): the game RAM must be identical, and so must the collision registers.
// Any difference is a bug in a patch or in the collisions. Also runs Render each frame and
// reports the cycles both take.
//   node games/demon-attack/tools/lockstep.js [frames] [--seed=N] [--cheat] [--diff=B] [--ntsc]
//        [--power=N] [--verbose] [--profile | --tickprofile] [--top=N]
// --cheat: later waves too (tools/play.js); --power=N: at frame N press F2 (power off and
// on) on the C64, and switch on a new 2600.
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 3000);
const verbose = process.argv.includes('--verbose'), cheat = process.argv.includes('--cheat');

const c64 = new C64();
c64.start(!process.argv.includes('--ntsc'));
const sym = n => c64.sym(n);
// --profile: cycles per routine (by the nearest label before the PC)
const profile = process.argv.includes('--profile') || process.argv.includes('--tickprofile') ? {} : null;
const tickOnly = process.argv.includes('--tickprofile'); let inTick = false;   // (--tickprofile: the game steps only)
const topN = +((process.argv.find(a => a.startsWith('--top=')) || '=20').split('=')[1]);
const labels = [...c64.lst.matchAll(/^\.([0-9a-f]{4})\t.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[1], 16), m[2]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0x1000 && pc < 0x2000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
let frameProf = {}, worst = { tick: { cyc: 0 }, render: { cyc: 0 } };
if (profile) { const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc); if (!tickOnly || inTick) profile[k] = (profile[k] || 0) + this.cycles - c; frameProf[k] = (frameProf[k] || 0) + this.cycles - c; return r; }; }

// ---- the original: stop once a frame just after the picture ($187A)
let vcs, atEnd = false, endFrame = -1, cx = 0;
const hook = v => {
  v.hmoveBlank = true;                    // (as tools/model.js was checked)
  const os = v.step.bind(v);
  v.step = function () {
    if (this.pc === 0x187A && this.frames !== endFrame) { atEnd = true; endFrame = this.frames; cx = this.cx; }
    return os();
  };
};
vcs = new VCS(rom); hook(vcs);
const runToEnd = () => { atEnd = false; let g = 0; while (!atEnd) { vcs.step(); if (++g > 2e6) throw new Error('2600 never finished a picture'); } };

// Bytes the two may disagree on: the 2600's stack is the top of its RAM (the C64 keeps its own)
const IGNORE = new Set([0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF]);
const NAMES = {};
for (const [a, n, size] of require('../2600/symbols.js').ram) for (let i = 0; i < size; i++) NAMES[a + i] = size > 1 ? `${n}+${i}` : n;
const name = a => NAMES[a] || '$' + a.toString(16);

const play = require('./play')(arg('seed', 11), { diffB: arg('diff', 'A') === 'B' });
let bad = 0, done = 0, maxTick = 0, totalTick = 0, maxRender = 0, totalRender = 0;
const diffCount = {};
const powerAt = arg('power', -1);
for (let f = 0; f < frames; f++) {
  if (f === powerAt) {                            // F2: power off and on
    c64.call(sym('PowerCycle'));
    vcs = new VCS(rom); hook(vcs); endFrame = -1;
    console.log(`frame ${f}: power off and on`);
  }
  if (cheat && f > 0) { play.cheat(f, vcs.ram); for (let a = 0x80; a < 0x100; a++) c64.mem[a] = vcs.ram[a - 0x80]; }
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  c64.mem[0x0280] = p.swcha; c64.mem[0x0282] = p.swchb; c64.mem[0x3C] = c64.mem[0x3D] = p.fire ? 0 : 0x80;
  runToEnd();
  frameProf = {};
  inTick = true;
  const cyc = c64.call(sym('Tick'));
  inTick = false;
  if (profile && cyc > worst.tick.cyc) worst.tick = { cyc, f, prof: { ...frameProf } };
  maxTick = Math.max(maxTick, cyc); totalTick += cyc;
  c64.mem[sym('pending')] = 0;                    // draw it, as the main loop would
  c64.mem[sym('curBuf')] ^= 1;                    // (and show it)
  frameProf = {};
  const rc = c64.call(sym('Render'));
  if (profile && rc > worst.render.cyc) worst.render = { cyc: rc, f, prof: { ...frameProf } };
  maxRender = Math.max(maxRender, rc); totalRender += rc;
  done++;
  const diffs = [];
  for (let a = 0x80; a < 0x100; a++) if (!IGNORE.has(a) && vcs.ram[a - 0x80] !== c64.mem[a]) {
    diffs.push(`${name(a)} 2600 ${vcs.ram[a - 0x80].toString(16)} C64 ${c64.mem[a].toString(16)}`);
    diffCount[a] = (diffCount[a] || 0) + 1;
  }
  const want = [(cx >> 13 & 1) << 7, (cx >> 5 & 1) << 6, (cx >> 7 & 1) << 6], got = [c64.mem[0x37], c64.mem[0x32], c64.mem[0x33]];
  ['CXPPMM', 'CXP0FB', 'CXP1FB'].forEach((n, i) => { if (want[i] !== got[i]) { diffs.push(`${n} 2600 ${want[i].toString(16)} C64 ${got[i].toString(16)}`); diffCount[n] = (diffCount[n] || 0) + 1; } });
  if (diffs.length) {
    bad++;
    if (bad <= 5 || verbose) console.log(`frame ${f}: ${diffs.join(', ')}`);
    for (let a = 0x80; a < 0x100; a++) if (!IGNORE.has(a)) c64.mem[a] = vcs.ram[a - 0x80];   // resync and carry on
  }
}
if (bad) console.log('what differed (frames):', Object.entries(diffCount).map(([a, n]) => `${isNaN(+a) ? a : name(+a)} ${n}`).join(', '));
const show = w => `frame ${w.f}, ${w.cyc} cycles: ` + Object.entries(w.prof).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => `${k} ${v}`).join(', ');
if (profile) { console.log('worst tick: ' + show(worst.tick)); console.log('worst render: ' + show(worst.render)); }
if (profile) { const tot = Object.values(profile).reduce((a, b) => a + b, 0); for (const [k, v] of Object.entries(profile).sort((a, b) => b[1] - a[1]).slice(0, topN)) console.log(k.padEnd(16), String(Math.round(v / done)).padStart(7), (100 * v / tot).toFixed(1) + '%'); }
console.log(`${done} frames, ${bad} with differences; C64 tick ${Math.round(totalTick / done)} cycles on average, ${maxTick} at most; render ${Math.round(totalRender / done)} on average, ${maxRender} at most`);
