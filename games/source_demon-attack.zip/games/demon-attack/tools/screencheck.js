// Check the C64 picture against the 2600's. Runs the C64 version's ticks and Render (as in
// lockstep.js) next to tools/vcs.js, then draws the C64 frame in JavaScript from what Render
// staged (screen, characters, sprites, the raster schedule with its colour writes, sprites
// simulated line by line with the VIC's rule that a sprite can't start again until its 21
// rows are done), and compares it pixel by pixel, in C64 colours, with the picture the
// 2600 draws (lines 40-239, what the C64 shows).
// Colour writes are placed at the earliest cycle the interrupt can make them (the poll sees
// the raster line change on cycle 0): a write part-way along a line changes the pixels from
// there on (pixel x is output on cycle 16 + x/4).
//   node games/demon-attack/tools/screencheck.js [frames] [--seed=N] [--cheat] [--show=<frame>] [--png=dir]
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 1000);
const showFrame = arg('show', -1), pngDir = arg('png', null), cheat = process.argv.includes('--cheat');

const c64 = new C64();
c64.start(true);
const sym = n => c64.sym(n), M = c64.mem;
const NSCHED = 24, LINE2RAS = 11, FIRST = 40, LAST = 239;
const COLORMAP = sym('ColorMap');
const S = { TOP: 0, RUN: 2, SET: 4, BUL: 6, END: 8, PAIR: 10 };

const c64Picture = require('./c64picture').picturer(c64);

// ---- the 2600
const vcs = new VCS(rom);
vcs.hmoveBlank = true;
let atEnd = false, endFrame = -1;
const os = vcs.step.bind(vcs);
// (the kernel hands over to the game logic at the start of line 229, so lines 229-239 are
// drawn later: they're taken from the frame buffer once line 240 is reached, during the next
// frame's run, and compared then)
const TAIL = 229, tail = new Uint8Array(160 * (LAST + 1 - TAIL));
let tailDone = true;
vcs.step = function () {
  if (this.pc === 0x187A && this.frames !== endFrame) { atEnd = true; endFrame = this.frames; }
  if (!tailDone && this.line > LAST) { tail.set(this.fb.subarray(TAIL * 160, (LAST + 1) * 160)); tailDone = true; }
  return os();
};
const play = require('./play')(arg('seed', 11));
let checked = 0, bad = 0, firstBad = '', last = null;
const badLines = {};
function png(file, a, b) {           // the 2600 (left) and the C64 (right), C64 colours, 2x
  const PAL = ['000000', 'FFFFFF', '96282E', '5BD6CE', '9F2DAD', '41B936', '2724C4', 'EFF347', '9F4815', '5E3500', 'DA5F66', '474747', '787878', '91FF84', '6864FF', 'AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
  const W = 2 * 160 * 2 + 8, H = 2 * (LAST - FIRST + 1);
  const raw = Buffer.alloc((W * 3 + 1) * H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const L = FIRST + (y >> 1), side = x < 320 ? 0 : x >= 328 ? 1 : -1, px = side ? (x - 328) >> 1 : x >> 1;
    const c = side < 0 ? [255, 0, 255] : PAL[(side ? b : a)[L * 160 + px]] || [255, 0, 255];
    raw.set(c, y * (W * 3 + 1) + 1 + x * 3);
  }
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); let crc = -1; for (const v of td) { crc ^= v; for (let k = 0; k < 8; k++) crc = crc & 1 ? 0xEDB88320 ^ (crc >>> 1) : crc >>> 1; } c.writeUInt32BE((crc ^ -1) >>> 0); return Buffer.concat([l, td, c]); };
  const ih = Buffer.alloc(13); ih.writeUInt32BE(W, 0); ih.writeUInt32BE(H, 4); ih[8] = 8; ih[9] = 2;
  fs.writeFileSync(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
}
for (let f = 0; f < frames; f++) {
  if (cheat && f > 0) { play.cheat(f, vcs.ram); for (let a = 0x80; a < 0x100; a++) M[a] = vcs.ram[a - 0x80]; }
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  M[0x0280] = p.swcha; M[0x0282] = p.swchb; M[0x3C] = M[0x3D] = p.fire ? 0 : 0x80;
  atEnd = false; while (!atEnd) vcs.step();
  if (last) compare(last);                // (the frame before, now that its lines 229-239 are in)
  last = null; tailDone = false;
  c64.call(sym('Tick'));
  M[sym('pending')] = 0;
  M[sym('curBuf')] ^= 1;                  // (Render draws into the other one: this one)
  c64.call(sym('Render'));
  const b = M[sym('rbuf')];
  if (f < 2) continue;
  globalThis.dbgSpr = new Int32Array(160 * 262); const { col, what } = c64Picture(b);
  const want = new Uint8Array(160 * 262);
  for (let i = FIRST * 160; i < TAIL * 160; i++) want[i] = M[COLORMAP + vcs.fb[i]];
  last = { f, want, col, what };
}
if (last) { while (!tailDone) vcs.step(); compare(last); }
function compare({ f, want, col, what }) {
  for (let i = TAIL * 160; i < (LAST + 1) * 160; i++) want[i] = M[COLORMAP + tail[i - TAIL * 160]];
  checked++;
  let n = 0, first = '';
  for (let L = FIRST; L <= LAST; L++) for (let x = 0; x < 160; x++) {
    const i = L * 160 + x;
    if (want[i] !== col[i]) { n++; badLines[L] = (badLines[L] || 0) + 1; if (!first) first = `line ${L} x ${x}: 2600 ${want[i]} C64 ${col[i]}`; }
  }
  if (n) { bad++; if (!firstBad) firstBad = `frame ${f}: ${n} pixels, e.g. ${first}`; }
  if (f === showFrame || (pngDir && n && bad <= 5)) { if (pngDir) { fs.mkdirSync(pngDir, { recursive: true }); png(path.join(pngDir, `f${f}.png`), want, col); } }
  if (f === showFrame) { console.log(`frame ${f}: ${n} pixels differ`); for (let L = FIRST; L <= LAST; L++) { const xs = []; for (let x = 0; x < 160; x++) if (want[L * 160 + x] !== col[L * 160 + x]) xs.push(x + ':' + want[L * 160 + x] + '/' + col[L * 160 + x] + '(' + what[L * 160 + x] + (what[L * 160 + x] === 1 ? ' spr ' + (globalThis.dbgSpr[L * 160 + x] >> 8 & 255) + ' row ' + ((globalThis.dbgSpr[L * 160 + x] & 255) >> 2) + ' blk ' + (globalThis.dbgSpr[L * 160 + x] >> 16) : '') + ')'); if (xs.length) console.log('  line', L, xs.join(' ')); } }
}
console.log(`${checked} frames compared: ${bad ? `${bad} differ, e.g. ${firstBad}` : 'all exact'}`);
if (bad) console.log('lines with differences (pixels):', Object.entries(badLines).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([l, n]) => `${l}:${n}`).join(' '));
console.log(`characters dropped ${M[sym('DbgDrop')]}`);
