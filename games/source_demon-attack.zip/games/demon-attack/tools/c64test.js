// Play test of the C64 build in VICE (through its remote monitor): start it,
// watch the attract mode, start a game with fire, move about firing, save screenshots,
// and report how the main loop keeps up: passes, passes that found more than one frame
// gone by (late), colour writes the raster interrupt came too late for, characters that ran
// out, and with --maxima the most cycles a pass spent drawing / running the game / in all
// (measuring them costs about 200 cycles a pass).
//   node games/demon-attack/tools/c64test.js <outdir> [seconds-of-play] [--ntsc] [--game=N] [--maxima]
// (It uses a monitor port of its own; any other VICE is left alone, only the one started here
// is closed.)
const fs = require('fs');
const net = require('net');
const path = require('path');
const { startVice, stopVice } = require('./vicectl');

const out = path.resolve(process.argv[2] || '.');
const playSeconds = +(process.argv[3] || 20);
const ntsc = process.argv.includes('--ntsc');
const maxima = process.argv.includes('--maxima');
const gameArg = process.argv.find(a => a.startsWith('--game='));
const game = gameArg ? +gameArg.slice(7) : 0;
const root = path.join(__dirname, '..');
const build = process.env.DA_BUILD || path.join(root, 'build');   // (DA_BUILD: another copy of the build)
const lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(build)).lst, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return parseInt(m[1], 16);
};
const hex = v => v.toString(16);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const mon = cmds => new Promise((resolve, reject) => {
  const s = net.connect(vice.port, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d.toString('latin1'); }); s.on('error', reject);
  s.on('connect', async () => { await sleep(150); for (const c of cmds) { s.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 150); } s.write('x\n'); await sleep(100); s.end(); resolve(b); });
});
const poke = (a, v) => mon([`> ${hex(a)} ${v}`]);
const shot = name => mon([`screenshot "${path.join(out, name).split(path.sep).join('/')}" 2`]);
const peek = async (a, n) => {
  const o = await mon([`m ${hex(a)} ${hex(a + n - 1)}`]);
  const m = o.match(new RegExp(`>C:${hex(a).padStart(4, '0')}((?:\\s+[0-9a-f]{2}){${n}})`, 'i'));
  if (!m) throw new Error('unexpected monitor reply: ' + JSON.stringify(o.slice(0, 300)));
  return m[1].trim().split(/\s+/).map(x => parseInt(x, 16));
};
const w16 = async n => { const b = await peek(addr(n), 2); return b[0] + 256 * b[1]; };
const read = async () => ({ frames: await w16('DbgFrames'), passes: await w16('DbgLoops'), late: await w16('DbgLate'), draw: await w16('DbgRMax'), ticks: await w16('DbgTMax'),
  pass: await w16('DbgPMax'), lateRun: (await peek(addr('DbgLateRun'), 1))[0], drop: (await peek(addr('DbgDrop'), 1))[0] });
const reset = () => mon([`> ${hex(addr('DbgRMax'))} 0 0 0 0 0 0`]);
const report = (name, a, b) => console.log(`${ntsc ? 'NTSC' : 'PAL'} ${name}: ${(b.frames - a.frames) & 0xFFFF} frames, ${b.passes - a.passes} pictures (${Math.round(100 * (b.passes - a.passes) / (((b.frames - a.frames) & 0xFFFF) || 1))}%), ${b.late - a.late} late; ` +
  (maxima ? `most cycles: drawing ${b.draw}, ticks ${b.ticks}, whole pass ${b.pass} (a frame has ${ntsc ? '17095' : '19656'}); ` : '') +
  `colour writes missed ${(b.lateRun - a.lateRun) & 255}, characters short ${(b.drop - a.drop) & 255}`);

let vice = null;
(async () => {
  fs.mkdirSync(out, { recursive: true });
  vice = await startVice(require('../../../tools/buildname').files(path.join(build)).prg, ntsc);
  await sleep(8000);
  if (maxima) await poke(addr('DbgMaxOn'), '1');
  await reset();
  const a = await read();
  await sleep(3000);
  report('attract', a, await read());
  await shot('t0-attract.png');
  if (game) await poke(0xEA, (Math.floor(game / 10) * 16 + game % 10).toString(16));   // game number (BCD)
  await poke(addr('DbgINPT4'), '7f'); await sleep(400); await poke(addr('DbgINPT4'), 'ff');   // fire: start a game
  await sleep(1500);
  await shot('t1-start.png');
  await reset();
  const c = await read();
  let seed = 1; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const t0 = Date.now();
  let n = 0;
  while (Date.now() - t0 < playSeconds * 1000) {
    const r = rnd();
    await mon([`> ${hex(addr('DbgSWCHA'))} ${r < .4 ? 'bf' : r < .8 ? '7f' : 'ff'}`, `> ${hex(addr('DbgINPT4'))} ${rnd() < .6 ? '7f' : 'ff'}`]);
    await sleep(350);
    if (++n % 8 === 0) await shot(`t2-play${String(n / 8).padStart(2, '0')}.png`);
  }
  report('play', c, await read());
  await mon([`> ${hex(addr('DbgSWCHA'))} ff`, `> ${hex(addr('DbgINPT4'))} ff`]);
  await shot('t3-end.png');
})().catch(e => console.log(e.message)).finally(() => {   // close the VICE started here, whatever happened
  stopVice(vice);
});
