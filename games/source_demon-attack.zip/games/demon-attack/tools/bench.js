// Pictures per frame from the timing model (c64run.js --tickinput: every version plays the
// same games) over many seeds, PAL and NTSC, run in parallel, for comparing versions:
//   node games/demon-attack/tools/bench.js [frames] [seeds] [first seed] [jobs] [--cheat]
// (DA_BUILD=dir: a copy of the build to measure, so the build can change meanwhile.)
// 48 seeds x 3000 frames take about a minute; two sets of seeds differ by about 0.4%.
const { spawn } = require('child_process');
const os = require('os');
const path = require('path');
const cheat = process.argv.includes('--cheat'), num = process.argv.filter(a => !a.startsWith('--'));   // (--cheat: random waves, as c64run --cheat)
const frames = +(num[2] || 3000), seeds = +(num[3] || 48), first = +(num[4] || 1);
const jobs = +(num[5] || Math.max(1, os.cpus().length - 2));
const tasks = [], pics = { PAL: 0, NTSC: 0 };
for (const sys of ['PAL', 'NTSC']) for (let s = first; s < first + seeds; s++) tasks.push({ sys, s });
let next = 0, running = 0;
const start = () => {
  while (running < jobs && next < tasks.length) {
    const t = tasks[next++];
    running++;
    const p = spawn('node', [path.join(__dirname, 'c64run.js'), String(frames), `--seed=${t.s}`, '--tickinput', ...(t.sys === 'NTSC' ? ['--ntsc'] : []), ...(cheat ? ['--cheat'] : [])], { env: process.env });
    let out = '';
    p.stdout.on('data', d => { out += d; });
    p.on('close', () => {
      const m = out.match(/pictures (\d+)/);
      if (!m) { console.log(`${t.sys} seed ${t.s}: no result`); process.exit(1); }
      pics[t.sys] += +m[1];
      running--;
      if (next < tasks.length) start();
      else if (!running) console.log(`pictures per frame: PAL ${(100 * pics.PAL / (seeds * frames)).toFixed(1)}%, NTSC ${(100 * pics.NTSC / (seeds * frames)).toFixed(1)}% (${seeds} seeds x ${frames} frames)`);
    });
  }
};
start();
