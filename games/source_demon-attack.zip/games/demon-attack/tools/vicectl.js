// Starting and stopping our own VICE: a remote-monitor port no other VICE uses (so tools in
// other sessions can't talk to ours, nor ours to theirs), and closing only the VICE that
// listens on it.
const net = require('net');
const { execSync, spawn } = require('child_process');

const sleep = ms => new Promise(r => setTimeout(r, ms));
// is something listening on this port?
const inUse = port => new Promise(resolve => {
  const s = net.connect(port, '127.0.0.1');
  s.on('connect', () => { s.destroy(); resolve(true); });
  s.on('error', () => resolve(false));
});
const listener = port => {
  try {
    const out = execSync(`powershell -NoProfile -Command "(Get-NetTCPConnection -LocalPort ${port} -State Listen -ErrorAction SilentlyContinue).OwningProcess"`).toString().trim();
    return out ? +out.split(/\s+/)[0] : 0;
  } catch { return 0; }
};
// start x64sc with the program; -> { port, pid }
async function startVice(prg, ntsc) {
  let port = 0;
  for (let k = 0; k < 50 && !port; k++) { const p = 6600 + Math.floor(Math.random() * 300); if (!(await inUse(p))) port = p; }
  if (!port) throw new Error('no free monitor port');
  spawn('x64sc', ['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${port}`,
    '-autostartprgmode', '1', '-autostart', `"${prg}"`], { detached: true, stdio: 'ignore', shell: true }).unref();
  let pid = 0;
  for (let k = 0; k < 40 && !pid; k++) { await sleep(250); pid = listener(port); }
  if (!pid) throw new Error('VICE did not open its monitor on port ' + port);
  return { port, pid };
}
// close the VICE started above (only that process)
function stopVice(v) {
  if (v && v.pid) try { execSync(`powershell -NoProfile -Command "Stop-Process -Id ${v.pid} -ErrorAction SilentlyContinue"`); } catch { }
}
module.exports = { startVice, stopVice };
