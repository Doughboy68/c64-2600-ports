// The whole C64 program (start-up, main loop, raster interrupts) on the 6502 core with a
// model of the VIC's timing: raster lines of 63 cycles (PAL) or 65 (NTSC), 312 / 263 of
// them, the CPU stopped on bad lines (cycles 12-54) and for the sprites' fetches, raster
// interrupts. Joysticks and keys: the debug overrides (DbgSWCHA, DbgINPT4), from
// tools/play.js. Reports how the main loop keeps up (as c64test.js does in VICE) and what
// the interrupt did.
//   node games/demon-attack/tools/c64run.js [frames] [--ntsc] [--seed=N] [--cheat] [--trace=F]
//     [--profile [--top=N]] [--passes [--show=K] [--fine] [--band]] [--tickinput] [--maxima] [--splitstat]
// --profile: cycles per routine and frame; --passes: each main loop pass's drawing and
// ticks (without the interrupt), the costliest passes, and the routines of the K-th costliest
// (--fine: down to local labels; --band[=Routine]: the passes drawing a materializing band, or
// running that routine, on average)
// --trace=F: list the interrupt's entries during frame F (raster line, cycle, entry)
// --tickinput: the inputs go straight into the 2600's ports at each game step (as lockstep.js
// does), not through the C64's frames: every version then plays the same game, so timings
// compare without the noise of different games
const { C64 } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 600), ntsc = process.argv.includes('--ntsc'), cheat = process.argv.includes('--cheat');
const tickInput = process.argv.includes('--tickinput');
const traceFrame = arg('trace', -1);
const LINES = ntsc ? 263 : 312, CYC = ntsc ? 65 : 63;

const c = new C64();
const sym = n => c.sym(n), M = c.mem;
const symOr = n => { try { return c.sym(n); } catch (e) { return -1; } };
// time in cycles since power-on; the VIC's view
let t = 0, irqLine = false, rasterCmp = 0, frame = 0, lastRaster = -1;
const raster = () => Math.floor(t / CYC) % LINES;
const lineCyc = () => t % CYC;
const io = c.io;
const den = () => io[0x11] & 0x10, yscroll = () => io[0x11] & 7;
const badline = r => den() && r >= 48 && r <= 247 && (r & 7) === yscroll();
// the sprites displayed on raster r (for their fetch stalls): from the VIC registers
const spriteOn = new Array(8).fill(-1);
function spritesOnLine(r) {
  let n = 0;
  for (let i = 0; i < 8; i++) {
    if (!(io[0x15] & (1 << i))) { spriteOn[i] = -1; continue; }
    const y = io[1 + 2 * i];
    if (spriteOn[i] >= 0 && (r - spriteOn[i] + LINES) % LINES >= 21) spriteOn[i] = -1;
    if (spriteOn[i] < 0 && ((y + 1) & 255) === (r & 255) && r < 256 + 56) spriteOn[i] = r;
    if (spriteOn[i] >= 0) n++;
  }
  return n;
}
// I/O reads the program makes
const origRead = c.read.bind(c);
c.read = function (a) {
  a &= 0xFFFF;
  if (a >= 0xD000 && a < 0xE000 && this.ioOn()) {
    const r = raster();
    if (a === 0xD012) return r & 255;
    if (a === 0xD011) return (io[0x11] & 0x7F) | (r & 256 ? 0x80 : 0);
    if (a === 0xD019) return (irqLine ? 0x81 : 0);
    if (a === 0xDC00 || a === 0xDC01) return 0xFF;               // no keys, no joysticks
    if (a === 0xDD04 || a === 0xDD05) { const v = (0xFFFF - (t & 0xFFFF)); return a === 0xDD04 ? v & 255 : v >> 8; }
  }
  return origRead(a);
};
// The colour runs' writes: each on its line, in its window. A demon run writes the next
// line's colour during the line before, after pixel 52 is out (cycle 30) and before the
// next line's first pixel (cycle 16); the ground writes $D021 before its line's first
// pixel, or for a bad line at the end of the line before. (A STA's write lands on its
// last cycle: 3 after the instruction starts.)
var wLine = {}, runNAt = 0; let curPC = 0, groundK = 0, lateWrites = 0, runAt = -1, groundAt = -1, setAt = -1, runSr = -1, pairAt = -1, pairEnd = -1, lateMoves = 0;
const runSr2 = new Set(), lateMv = [], xStore = new Set();
let dualAt = -1, dualEnd = -1, curRun = 0;
const lateEx = [];
const origWrite = c.write.bind(c);
// writes into the program's code, other than its own patches (the operands of the
// instructions labelled _jmp, _sr, _w0-_w7, _gj, _st, _l1, _k0, _l0): a stray pointer
let codeEnd = 0, codeWrites = 0;
const patchOK = new Set(), codeEx = [];
c.write = function (a, v) {
  a &= 0xFFFF;
  if (a >= 0x2000 && a < codeEnd && !patchOK.has(a) && M[a] !== v) {
    codeWrites++;
    if (codeEx.length < 8) codeEx.push(`frame ${frame}: $${a.toString(16)} = ${v} by $${curPC.toString(16)} ${labelOf(curPC)}`);
  }
  if (a >= 0xD021 && a <= 0xD02E && this.ioOn() && frame >= 2 && runAt >= 0) {
    const w = t + 3, r = Math.floor(w / CYC) % LINES, cy = w % CYC;
    let bad = null;
    if (curPC >= runAt && curPC < groundAt && curPC !== runSr && !runSr2.has(curPC)) {
      // (line k of the run (its store _wk): during raster irqR + k; from cycle 30 unless its
      // delay is 1: a band without previous-colour pixels, or after a bad line)
      // (Y = the run's first line; the N variants have no previous-colour pixels to wait for)
      // (the dual runs (both pairs, a split band's halves): before the first pixel of the half
      // each store is for, 16 + x / 4, the left half's first)
      const k = wLine[curPC] || 0, L = c.y + k, T = (L + 10) % LINES, from = curPC >= runNAt || (L & 7) === 1 ? 0 : 30;
      // (and their first line's write may come early: the pairs show nothing on the line before)
      const dual = curPC >= dualAt && curPC < dualEnd, end = dual ? 16 + (M[sym(xStore.has(curPC) ? 'RunXR' : 'RunXL') + curRun] >> 2) : 16;
      if (!((r === T && (cy >= from || (dual && k === 0))) || (r === (T + 1) % LINES && cy < end))) bad = `run write for raster ${T + 1}`;
    } else if (curPC >= groundAt && curPC < setAt && a !== 0xD022) {
      // (line 223's $D023 first, before that line; then line 223 + j, j from irqSkip: after
      // the last pixel of the line two before it, before its own first pixel)
      const base = M[sym('irqR')], L = groundK === 0 ? base + 1 : base + 1 + M[sym('irqSkip')] + groundK - 1;
      const ok = groundK === 0 ? (r < L || (r === L && cy < 16)) : ((r === L - 2 && cy >= 57) || r === L - 1 || (r === L && cy < 16));
      if (!ok) bad = `ground write ${groundK} for raster ${L}`;
      groundK++;
    }
    if (bad) { lateWrites++; if (lateEx.length < 6) lateEx.push(`frame ${frame} raster ${r} cycle ${cy}: ${bad}`); }
  }
  // pair moves (IPair): a new Y must be written before the raster reaches it (the VIC
  // compares in cycle 55 of raster Y; the sprite shows from Y + 1)
  if (a >= 0xD001 && a <= 0xD00F && (a & 1) && curPC >= pairAt && curPC < pairEnd && this.ioOn() && frame >= 2 && v >= 40) {
    const w = t + 3, r = Math.floor(w / CYC) % LINES, cy = w % CYC;
    if (r > v || (r === v && cy >= 54)) { lateMoves++; if (lateMv.length < 6) lateMv.push(`frame ${frame} raster ${r} cycle ${cy}: sprite Y ${v}`); }
  }
  if (a >= 0xD000 && a < 0xE000 && this.ioOn()) {
    if (a === 0xD012) { rasterCmp = (rasterCmp & 256) | v; }
    if (a === 0xD011) rasterCmp = (rasterCmp & 255) | ((v & 0x80) << 1);
    if (a === 0xD019 && (v & 1)) irqLine = false;
  }
  return origWrite(a, v);
};
// one instruction, with the VIC's stalls; raster interrupts between instructions
const trace = [];
globalThis.gt = process.argv.includes('--ground');
const GIN = parseInt(c.lst.match(/^.([0-9a-f]{4})	.*	IGround:/m)?.[1] || '0', 16) + 0;
const lstAt = re => { const m = c.lst.match(re); return m ? parseInt(m[1], 16) : -1; };
const JMPAT = lstAt(/^.([0-9a-f]{4})	.*_jmp    jmp/m), LATEAT = -1;
let drawOver = 0, entries = 0, inIrq = false, mainT = 0, rStart = -1, tStart = -1, pprof = null, stallB = 0, stallS = 0;
const passes = process.argv.includes('--passes') ? [] : null;
codeEnd = sym('Mul9');                     // (the variables start with this table)
for (const m of c.lst.matchAll(/^.([0-9a-f]{4})\t[^\n]*\t(_jmp|_sr|_rj|_w[0-7]|_w2a|_w2b|_z[1-4]|_r1|_r2|_c|_gj|_st|_l1|_k0|_l0|_a1|_a0|_qck|_qend|_qrec|_qpl|_qpl3|_qcp|_ql1|_qzf|_qzj|_qly|_qy8|_qz5|_qzp|_qre|_qr2|_qso|_qa1|_qa0|_qp1|_qm0|_qp0|_qf1|_qf0|_qfj|_qb1|_qb0|_qbj|_qq0|_qq1|_qt0|_qt1|_qqj|_qqm|_qce|_qkz)\s/gm)) { const p = parseInt(m[1], 16); patchOK.add(p + 1); patchOK.add(p + 2); }
for (const n of ['LCopy0', 'LCopy1']) if (new RegExp('\\t' + n + ':').test(c.lst)) for (let k = 1; k < 21; k++) patchOK.add(sym(n) + 6 * k);   // (DrawLaser's rts)
if (/\tFbZ:/.test(c.lst)) for (let k = 0; k < 16; k++) { patchOK.add(sym('FbW2') + 5 * k); patchOK.add(sym('FbZ') + 3 * k); }   // (the rts FbFlush puts in)
runAt = sym('IRun'); groundAt = sym('IGround'); setAt = sym('ISet'); runSr = lstAt(/^.([0-9a-f]{4})\t.*_sr     stx \$d000/m);
for (const m of c.lst.matchAll(/^.([0-9a-f]{4})\t[^\n]*\t_sr2    stx/gm)) runSr2.add(parseInt(m[1], 16));   // (the dual runs' second set)
pairAt = sym('IPair'); pairEnd = sym('IEnd'); dualAt = symOr('IRunP6'); dualEnd = dualAt < 0 ? -1 : sym('IRunN0');   // (builds before split demons as sprites: none)
for (const m of c.lst.matchAll(/^.([0-9a-f]{4})\t[^\n]*\t_x[0-7]     sta/gm)) xStore.add(parseInt(m[1], 16));

for (const m of c.lst.matchAll(/^.([0-9a-f]{4})\t[^\n]*\t_[wx]([0-7])     sta/gm)) wLine[parseInt(m[1], 16)] = +m[2];   // (_x: the dual runs' second store)
runNAt = sym('IRunN0');
const RENDER = sym('Render'), RENDER_RET = lstAt(/^.([0-9a-f]{4})\t.*jsr Render/m) + 3, TICK = sym('Tick');
const TICK_RET = new Set([...c.lst.matchAll(/^.([0-9a-f]{4})\t[^\n]*jsr (?:DueTick|Tick)\b/gm)].map(m => parseInt(m[1], 16) + 3));   // (where game steps return to)
function step() {
  // the CPU stops while the VIC fetches: bad lines (cycles 12-54), sprites (2 cycles each
  // plus a few, at the end of the line before)
  const r = raster(), lc = lineCyc(), pcS = c.pc;
  if (badline(r) && lc >= 12 && lc < 55) { t += 55 - lc; if (frame >= 100) stallB += 55 - lc; }
  const before = c.cycles;
  if (irqLine && !(c.p & 4) && (io[0x1A] & 1)) {
    // take the interrupt: push PC and P, jump through $FFFE
    c.push(c.pc >> 8); c.push(c.pc & 255); c.push((c.p | 0x20) & ~0x10); c.p |= 4;
    c.pc = M[0xFFFE] | M[0xFFFF] << 8; c.cycles += 7; inIrq = true;
    entries++;
    if (frame >= traceFrame && frame < traceFrame + 3) { const ix = M[sym('irqIdx')], ty = M[sym('SchedType') + ix], ag = M[sym('SchedArg') + ix]; trace.push(`f${frame} ${raster()}:${lineCyc()} irq idx ${ix} type ${ty} arg ${ag} ras ${M[sym('SchedRas') + ix]}` + (ty === 2 ? ` run first ${M[sym('RunFirst') + ag]} cnt ${M[sym('RunCnt') + ag]} ras ${[...Array(M[sym('RunCnt') + ag])].map((_, k) => M[sym('RunRas') + M[sym('RunFirst') + ag] + k]).join(',')}` : '')); }
  } else {
    if (frame >= traceFrame && frame < traceFrame + 3 && c.pc === JMPAT) trace.push(`  f${frame} ${raster()}:${lineCyc()} dispatch idx ${M[sym('irqIdx')]}`);
    if (frame >= traceFrame && frame < traceFrame + 3 && c.pc === LATEAT) trace.push(`  f${frame} ${raster()}:${lineCyc()} late, Y ${c.y}`);
    if (globalThis.fine > 0) { globalThis.fine--; trace.push(`    ${frame} ${raster()}:${lineCyc()} pc ${c.pc.toString(16)} x ${c.x} a ${c.a}`); }
    if (frame === traceFrame && c.pc === JMPAT && M[sym('irqIdx')] === 26) globalThis.fine = 120;
    if (globalThis.gt && frame >= 300 && frame < 302 && (c.pc === GIN || c.pc === GOUT)) trace.push(`f${frame} ${raster()}:${lineCyc()} ${c.pc === GIN ? 'ground in, irqR ' + M[sym('irqR')] : 'ground out'}`);
    if (tickInput && c.pc === TICK) {
      if (cheat && f2600 > 0) play.cheat(f2600, M.subarray(0x80, 0x100));
      const p = play(f2600++, M.subarray(0x80, 0x100));
      M[0x0280] = p.swcha; M[0x0282] = p.swchb; M[0x3C] = M[0x3D] = p.fire ? 0 : 0x80;
    }
    const op = M[c.pc];
    curPC = c.pc;
    if (hitAt.size && hitAt.has(c.pc) && frame >= 100) hits[hitAt.get(c.pc)]++;
    if (c.pc === groundAt) groundK = 0;
    if (c.pc === runAt) curRun = M[sym('SchedArg') + M[sym('irqIdx')]];
    if (c.pc === RENDER && M[sym('pending')]) drawOver++;
    if (splitStat && c.pc === RENDER_RET) splitCheck();
    if (passes) {
      if (c.pc === RENDER) { rStart = mainT; pprof = {}; }
      if (c.pc === RENDER_RET && rStart >= 0) { passes.push({ f: frame, r: mainT - rStart, ram: M.slice(0x80, 0x100), prof: pprof }); rStart = -1; pprof = null; }
      if (c.pc === TICK) tStart = mainT;
      if (TICK_RET.has(c.pc) && tStart >= 0 && passes.length) { passes[passes.length - 1].t = (passes[passes.length - 1].t || 0) + mainT - tStart; tStart = -1; }
    }
    c.step();
    if (op === 0x40 && inIrq) inIrq = false;
  }
  if (!inIrq) { mainT += c.cycles - before; if (pprof) { const k = labelOf(pcS); pprof[k] = (pprof[k] || 0) + c.cycles - before; } }
  t += c.cycles - before;
  // raster changes: sprite fetch stalls, the raster interrupt
  const r2 = raster();
  if (r2 !== lastRaster) {
    for (let q = (lastRaster + 1) % LINES; ; q = (q + 1) % LINES) {
      if (q === rasterCmp && (io[0x1A] & 1)) irqLine = true;
      if (q === 0) frame++;
      const n = spritesOnLine(q);
      if (n) { t += 2 * n + 3; if (frame >= 100) stallS += 2 * n + 3; }
      if (q === r2) break;
    }
    lastRaster = r2;
  }
}
// --profile: cycles per routine
const prof = process.argv.includes('--profile') ? {} : null;
const labels = (() => {
  const fine = process.argv.includes('--fine'), out = [];
  let parent = '';
  for (const m of c.lst.matchAll(/^.([0-9a-f]{4})\t[^\n]*\t([A-Za-z_][A-Za-z0-9_]*)/gm)) {
    const n = m[2];
    if (/^[A-Z]/.test(n)) { parent = n; out.push([parseInt(m[1], 16), n]); } else if (fine && n[0] === '_') out.push([parseInt(m[1], 16), parent + '.' + n]);
  }
  return out.sort((a, b) => a[0] - b[0]);
})();
// --hits=A,B._c: how often those labels are reached (per pass drawing a materializing band)
const hitAt = new Map(), hits = {};
if (arg('hits', '')) {
  const want = new Set(String(arg('hits', '')).split(',')); let parent = '';
  for (const m of c.lst.matchAll(/^.([0-9a-f]{4})\t[^\n]*\t([A-Za-z_][A-Za-z0-9_]*)/gm)) {
    if (/^[A-Z]/.test(m[2])) parent = m[2];
    const n = m[2][0] === '_' ? parent + '.' + m[2] : m[2];
    if (want.has(n) && !hitAt.has(parseInt(m[1], 16))) { hitAt.set(parseInt(m[1], 16), n); hits[n] = 0; }
  }
}
// --splitstat: could the split demons' character bands be sprites, a pair for each half? Per
// picture: the bands (and the cannon band's pair) top to bottom, each sprite band keeping one
// of the two pairs (4-5, 6-7), a pair starting again only 22 lines after its last start; the
// most split bands that could take both pairs as well (frame >= 100); and how many the C64's
// plan (render.asm Classify / Plan) drew as sprites.
const splitStat = process.argv.includes('--splitstat') ? { pics: 0, picsSplit: 0, split: 0, conv: 0, picsAll: 0, base: 0 } : null;
function splitCheck() {
  if (frame < 100) return;
  const S = splitStat, bands = [];
  for (let k = 0; k < 3; k++) {
    const x0 = M[sym('bX0') + k], x1 = M[sym('bX1') + k], w = M[sym('bW') + k], p = M[sym('bP0') + k] | M[sym('bP1') + k];
    const L = 210 - M[0xC5 + k];
    if (!p || w !== 8) continue;   // (blank, or materializing: characters, no sprites)
    const sprite = x0 < 153 && x1 < 153 && Math.abs(x1 - x0) < 17;
    bands.push({ L, need: sprite ? 1 : 2 });
  }
  const cm = M[sym('cMode')];
  if (cm === 1) bands.push({ L: 213 - M[0xC8], need: 1 });
  else if (cm === 2) bands.push({ L: Math.max(188, 221 - M[0xC7]), need: 1 });
  bands.sort((a, b) => a.L - b.L);
  S.pics++;
  const splits = bands.filter(b => b.need === 2);
  const fits = use => {
    const rec = (i, lastA, lastB) => {
      if (i === bands.length) return true;
      const b = bands[i], n = b.need === 2 ? (use.has(b) ? 2 : 0) : 1;
      if (n === 0) return rec(i + 1, lastA, lastB);
      const okA = b.L - lastA >= 22, okB = b.L - lastB >= 22;
      if (n === 2) return okA && okB && rec(i + 1, b.L, b.L);
      return (okA && rec(i + 1, b.L, lastB)) || (okB && rec(i + 1, lastA, b.L));
    };
    return rec(0, -999, -999);
  };
  if (fits(new Set())) S.base++;
  if (!splits.length) return;
  S.picsSplit++; S.split += splits.length;
  let best = 0;
  for (let m = 0; m < 1 << splits.length; m++) {
    const use = new Set(splits.filter((_, i) => m >> i & 1));
    if (use.size > best && fits(use)) best = use.size;
  }
  S.conv += best;
  if (best === splits.length) S.picsAll++;
  // what the C64's plan made of them (Classify / Plan): split bands drawn as sprites
  if (symOr('plDyn') >= 0 && M[sym('plDyn')]) for (let k = 0; k < 3; k++) if (M[sym('ItK') + k] === 2) { const n = M[sym('ItN') + k]; if (n === 2) S.drawn = (S.drawn || 0) + 1; if (n === 3) S.half = (S.half || 0) + 1; }
}
const labelOf = pc => { if (pc >= 0x1000 && pc < 0x2000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
// start: as the C64 does after RUN
if (process.argv.includes('--maxima')) M[sym('DbgMaxOn')] = 1;   // (testing aid: the most cycles a pass spent)
c.pc = sym('Start');
c.s = 0xFF;
const play = require('./play')(arg('seed', 11));
const loops0 = () => M[sym('DbgLoops')] | M[sym('DbgLoops') + 1] << 8, late0 = () => M[sym('DbgLate')] | M[sym('DbgLate') + 1] << 8;
let lastFrame = -1, tops = 0, topsAt = 0, f2600 = 0;
const t0 = Date.now();
while (frame < frames) {
  const pc0 = c.pc, t1 = t;
  step();
  if (prof && frame >= 100) { const k = labelOf(pc0); prof[k] = (prof[k] || 0) + t - t1; }
  if (frame !== lastFrame) {
    lastFrame = frame;
    // inputs for the coming frame (through the debug overrides)
    if (!tickInput) {
      if (cheat && f2600 > 0) play.cheat(f2600, M.subarray(0x80, 0x100));
      const p = play(f2600++, M.subarray(0x80, 0x100));
      M[sym('DbgSWCHA')] = p.swcha; M[sym('DbgINPT4')] = p.fire ? 0x7F : 0xFF;
      M[sym('DbgSWCHB')] = p.swchb | 0xFC;        // (reset, select: the rest stays as set)
    }
    if (frame === 100) { tops = M[sym('DbgTops')]; topsAt = loops0(); }
  }
  if (Date.now() - t0 > 600000) throw new Error('too slow');
}
const w = n => M[sym(n)] | M[sym(n) + 1] << 8;
console.log(`${ntsc ? 'NTSC' : 'PAL'} ${frames} frames: pictures ${w('DbgLoops')}, late ${w('DbgLate')}; frame tops ${(M[sym('DbgTops')] - tops) & 255} in the last ${(frames - 100) & 255}...;`
  + (M[sym('DbgMaxOn')] ? ` most cycles: drawing ${w('DbgRMax')}, ticks ${w('DbgTMax')}, whole pass ${w('DbgPMax')};` : '') + ` colour writes missed ${M[sym('DbgLateRun')]}; interrupts ${entries}`);
console.log(`writes into the code: ${codeWrites}` + codeEx.map(x => '\n  ' + x).join(''));
console.log(`pictures started over one not yet shown: ${drawOver}; colour writes off their line or window: ${lateWrites}` + lateEx.map(x => '\n  ' + x).join(''));
console.log(`sprite pairs moved too late: ${lateMoves}` + lateMv.map(x => '\n  ' + x).join(''));
console.log(`stalls per frame: bad lines ${Math.round(stallB / (frames - 100))}, sprites ${Math.round(stallS / (frames - 100))}`);
if (passes) {
  const p = passes.filter(x => x.f >= (arg('frame', -1) >= 0 ? 0 : 100)), avg = k => Math.round(p.reduce((a, x) => a + (x[k] || 0), 0) / p.length);
  console.log(`passes ${p.length}: render avg ${avg('r')}, ticks avg ${avg('t')}`);
  const h = {}; for (const x of p) { const b = Math.floor(x.r / 2000) * 2; h[b] = (h[b] || 0) + 1; }
  console.log('render K histogram', JSON.stringify(h));
  const hex = (x, a, b) => [...x.ram.slice(a - 0x80, b - 0x80)].map(v => v.toString(16)).join(',');
  for (const x of [...p].sort((a, b) => b.r - a.r).slice(0, 8)) console.log(`  frame ${x.f} render ${x.r} ticks ${x.t} 97=${hex(x, 0x97, 0x98)} 9c=${hex(x, 0x9c, 0x9d)} af-b3=${hex(x, 0xaf, 0xb4)} c5-c8=${[...x.ram.slice(0x45, 0x49)].join(',')}`);
  const w = arg('frame', -1) >= 0 ? p.find(x => x.f >= arg('frame', 0)) : [...p].sort((a, b) => b.r - a.r)[arg('show', 0)];
  if (w) console.log(Object.entries(w.prof).sort((a, b) => b[1] - a[1]).slice(0, 30).map(([k, v]) => k + ' ' + v).join(', '));
  const bandArg = process.argv.find(a => a === '--band' || a.startsWith('--band='));
  if (bandArg) {   // (the passes drawing a materializing band, or --band=Routine: those running it; their routines on average)
    const bn = bandArg.includes('=') ? bandArg.split('=')[1] : 'FbFlush';
    const b = p.filter(x => Object.keys(x.prof).some(k => k === bn || k.startsWith(bn + '.'))), s = {};
    for (const x of b) for (const [k, v] of Object.entries(x.prof)) s[k] = (s[k] || 0) + v;
    console.log(`passes with ${bn} ${b.length} of ${p.length}: render avg ${Math.round(b.reduce((a, x) => a + x.r, 0) / b.length)}`);
    if (hitAt.size) console.log('hits per such pass: ' + Object.entries(hits).map(([k, v]) => k + ' ' + (v / b.length).toFixed(2)).join(', '));
    console.log(Object.entries(s).sort((a, c) => c[1] - a[1]).slice(0, arg('top', 40)).map(([k, v]) => k + ' ' + Math.round(v / b.length)).join(', '));
  }
}
if (trace.length) console.log(trace.join('\n'));
if (prof) { const tot = Object.values(prof).reduce((a, b) => a + b, 0); for (const [k, v] of Object.entries(prof).sort((a, b) => b[1] - a[1]).slice(0, arg('top', 25))) console.log(k.padEnd(16), String(Math.round(v / (frames - 100))).padStart(7), (100 * v / tot).toFixed(1) + '%'); }
if (splitStat) { const S = splitStat, pc = (a, b) => (100 * a / Math.max(1, b)).toFixed(1) + '%'; console.log(`split bands: pictures ${S.pics} (sprite bands placeable as now: ${S.base}), with split bands ${S.picsSplit}; split bands ${S.split}, could be sprites ${S.conv} (${pc(S.conv, S.split)}); pictures with all of them ${S.picsAll} (${pc(S.picsAll, S.picsSplit)}); drawn as sprites ${S.drawn || 0} (${pc(S.drawn || 0, S.split)}), half sprites half characters ${S.half || 0} (${pc(S.half || 0, S.split)})`); }
if (tickInput) console.log('game steps ' + f2600 + ', score ' + [...M.slice(0x81, 0x87)].map(v => v.toString(16)).join(''));
