// A random player for the checks (model.js, lockstep.js, screencheck.js): the same inputs
// from the same seed. Moves left and right, fires a lot; both joysticks get the same moves
// (player 2 in two-player games). Between games it waits a little, sometimes presses Game
// Select a few times (another of the 10 games), then Game Reset or fire. Difficulty switches:
// both A (aggressive) unless { diffB }.
//   const play = require('./play')(seed, { diffB });  play(frame, ram) -> { swcha, swchb, fire }
// play.cheat(frame, ram) (for --cheat): changes the game's RAM so the checks see the later
// waves: a random wave number now and then (it takes effect when the next wave starts),
// bunkers kept at 2 or more (now and then all 6), and waves cut short now and then. The checks apply it to both
// sides at the same moment, before the frame.
module.exports = function (seed, opts = {}) {
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const diff = opts.diffB ? 0 : 0xC0;
  let joy = 0xF, fire = false, between = 0, selects = 0, useFire = false, wasRunning = 0;
  const play = function (f, ram) {
    const R = a => ram[a - 0x80];
    let swchb = 0x0B | diff;
    if (f < 60) return { swcha: 0xFF, swchb, fire: false };        // the logo screen
    const running = R(0xF1) & 0x80;
    if (!running) {
      // between games: wait, Select a few times, then Reset (or fire: press and release)
      if (between === 0) { between = 40 + Math.floor(rnd() * 80); selects = Math.floor(rnd() * 4); useFire = rnd() < 0.5; }
      between--;
      if (between > 12 && selects && between % 10 < 5) swchb &= ~2;
      if (between > 12 && selects && between % 10 === 5) selects--;
      const press = between <= 6 && between > 2;
      if (press && !useFire) swchb &= ~1;
      return { swcha: 0xFF, swchb, fire: press && useFire };
    }
    between = 0;
    if (f % 10 === 0) {
      const r = rnd();
      joy = r < 0.4 ? 0xB : r < 0.8 ? 0x7 : 0xF;                    // left, right, still
      fire = rnd() < 0.7;
    }
    return { swcha: joy << 4 | joy, swchb, fire: fire && f % 6 < 4 };
  };
  play.cheat = function (f, ram) {
    const running = ram[0xF1 - 0x80] & 0x80;
    if (running && (!wasRunning || f % 600 === 0)) ram[0xBE - 0x80] = Math.floor(rnd() * 24);
    wasRunning = running;
    if (!running) return;
    for (const a of [0xF2, 0xF3]) if (ram[a - 0x80] < 2 || f % 900 === 450) ram[a - 0x80] = f % 900 === 450 ? 6 : 2;
    if (f % 200 === 0 && ram[0x9B - 0x80] < 7) ram[0x9B - 0x80] = 7;
  };
  return play;
};
