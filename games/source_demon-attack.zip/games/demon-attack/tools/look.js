// Play randomly (tools/play.js) and save pictures of chosen moments, 3x, for looking at.
//   node games/demon-attack/tools/look.js <frames> <dir> [--seed=N]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('b12a7f63787a6bb08e683837a8ed3f18'));
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const frames = +process.argv[2], dir = process.argv[3];
const play = require('./play')(arg('seed', 11));
vcs.cropTop = 20; vcs.cropHeight = 240;
const R = a => vcs.ram[a - 0x80];
const seen = {};
const want = {
  materialize: () => R(0x97) < 0x80,
  split: () => (R(0xB6) | R(0xB7) | R(0xB8)) & 0x80,
  smalldemon: () => !(R(0xEB) & 0x80) && R(0xF1),
  explode: () => R(0x99) && R(0x99) < 0x30,
  flash: () => R(0x99) >= 0x30,
};
for (let f = 0; f < frames; f++) {
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  vcs.runFrames(1);
  for (const [k, t] of Object.entries(want)) if (t() && (seen[k] || 0) < 3 && f % 7 === 0) {
    seen[k] = (seen[k] || 0) + 1;
    vcs.savePNG(`${dir}/${k}${seen[k]}-f${f}.png`, 2);
  }
}
console.log(seen);
