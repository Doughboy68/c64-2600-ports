// A model of what Demon Attack's kernel draws, built only from RAM (and two TIA values the
// game sets outside the kernel: the ball's colour and whether it is on), checked pixel by
// pixel, colours and collisions included, against tools/vcs.js over random games. The C64
// version draws and collides by the same rules, so this is where they are worked out.
//
// The kernel is followed line by line as a list of TIA writes, each at the pixel where it
// takes effect (worked out from the kernel's cycle counts: a write that ends on CPU cycle c
// of a line takes effect from pixel 3c - 68). The quirks come from those timings:
//   - in a demon band, GRP1 is written at pixel 19 and the colours at pixels 43 (COLUP0) and
//     52 (COLUP1): left of those, a demon shows the previous line's row and colour;
//   - the laser (the ball) is switched on or off part-way across each line (pixel 25-28 or
//     103-106 in the demon bands, 1-121 in the cannon band), and not at all on the three
//     lines where each band positions its objects, so it can stretch or shrink;
//   - in the cannon band the bullets' GRP1 is written at pixel 100-121 (they show a line
//     late left of that), the small demon's at 10 or 28 and its colour at 34 or 52;
//   - the cannon band counts its lines from one less, so things in it sit 3 lines lower.
//   node games/demon-attack/tools/model.js [frames] [--seed=N] [--cheat] [--verbose] [--show=frame]
// --cheat: later waves too (see tools/play.js). The first frame after power-on isn't checked
// (the TIA starts in a state no later frame has).
'use strict';
const ROMMD5 = 'b12a7f63787a6bb08e683837a8ed3f18';
const rom = require('../../../tools/rom').load(ROMMD5);
const POS = require('./pos.json');
const ROM = a => rom[a & 0xFFF];

const FIRST = 41, LAST = 228;            // lines that can show anything; the collisions cover these

// ---- the TIA, line by line: positions, registers, and writes part-way across a line
// Object bits as in tools/vcs.js: 1 P0, 2 P1, 16 BL. Colours are TIA values (as vcs.fb: >> 1).
const COPIES = [[0], [0, 16], [0, 32], [0, 16, 32], [0, 64], [0], [0, 32, 64], [0]];
function player(t, i, x) {
  const g = t.vdel[i] ? t.old[i] : t.grp[i];
  if (!g) return false;
  const nus = t.nusiz[i] & 7, scale = nus === 5 ? 2 : nus === 7 ? 4 : 1;
  const d = (x - t.pos[i] + 160) % 160;
  for (const c of COPIES[nus]) {
    const dd = d - c;
    if (dd >= 0 && dd < 8 * scale) {
      let bit = Math.floor(dd / scale);
      if (!(t.refp[i] & 8)) bit = 7 - bit;
      return ((g >> bit) & 1) === 1;
    }
  }
  return false;
}
function write(t, reg, v) {
  switch (reg) {
    case 'GRP0': t.grp[0] = v; t.old[1] = t.grp[1]; break;      // (vertical delay: see vcs.js)
    case 'GRP1': t.grp[1] = v; t.old[0] = t.grp[0]; break;
    case 'COLUP0': t.col[0] = v; break;
    case 'COLUP1': t.col[1] = v; break;
    case 'COLUBK': t.bk = v; break;
    case 'ENABL': t.bl = v & 2; break;
    case 'NUSIZ0': t.nusiz[0] = v; break;
    case 'NUSIZ1': t.nusiz[1] = v; break;
    case 'REFP1': t.refp[1] = v; break;
    case 'VDELP0': t.vdel[0] = v & 1; break;
    case 'VDELP1': t.vdel[1] = v & 1; break;
    case 'POS0': t.pos[0] = v; break;
    case 'POS1': t.pos[1] = v; break;
    default: throw new Error('register ' + reg);
  }
}
const PAIRS = [[1, 2, 7], [1, 16, 2], [2, 16, 3]];   // P0-P1 (CXPPMM bit 7), P0-BL (CXP0FB bit 6), P1-BL (CXP1FB bit 6)
// Draw line L with its writes [[px, reg, value]...]: object bits and colours; collisions into t.cx
function drawLine(t, out, L, writes) {
  writes.sort((a, b) => a[0] - b[0]);
  let w = 0;
  while (w < writes.length && writes[w][0] <= 0) { write(t, writes[w][1], writes[w][2]); w++; }
  for (let x = 0; x < 160; x++) {
    while (w < writes.length && writes[w][0] <= x) { write(t, writes[w][1], writes[w][2]); w++; }
    let o = 0;
    const blank = out.blank && out.blank.has(L) && x < 8;             // (the HMOVE blank, if drawn: black)
    if (!blank) {
      if (player(t, 0, x)) o |= 1;
      if (player(t, 1, x)) o |= 2;
      if (t.bl && x === t.blx) o |= 16;
    }
    for (const [a, b, bit] of PAIRS) if ((o & a) && (o & b) && !(t.cx & 1 << bit)) { t.cx |= 1 << bit; out.hits.push(out.kind); }
    out.ob[L * 160 + x] = o;
    out.fb[L * 160 + x] = blank ? 0 : (o & 1 ? t.col[0] : o & 2 ? t.col[1] : o & 16 ? t.colpf : t.bk) >> 1;
  }
  while (w < writes.length) { write(t, writes[w][1], writes[w][2]); w++; }
}

// ---- the kernel, from the state at its start ($1000): RAM and the ball's colour and enable.
// -> { ob, fb (lines FIRST..LAST), cx: collisions at the end (bits as above), cxMid (P0-P1 when
//      the cannon band starts: $DC), p1blMid (P1-BL then: $BF in the bullets kernel),
//      ram: the RAM the kernel leaves changed {addr: value} }
function model(s, opts = {}) {
  const R = a => s.ram[a - 0x80];
  const out = { ob: new Uint8Array(160 * 262), fb: new Uint8Array(160 * 262), blank: opts.hmoveBlank ? new Set() : null, hits: [], kind: 'score' };
  const t = { grp: [0, 0], old: [0, 0], vdel: [1, 1], nusiz: [3, 3], refp: [0, 0], col: [0, 0], bk: R(0xBC),
    colpf: s.colupf, bl: s.enabl & 2, blx: POS.bl[R(0x96)], pos: [55, 63], cx: 0 };
  const ram = {};
  const mask = R(0xD1);
  t.col[0] = t.col[1] = R(0xD2) & mask;
  // score: ten rows (9 down to 0) of six digits, the 48-pixel trick with vertical delay
  const ptr = i => R(0xDD + 2 * i) | R(0xDE + 2 * i) << 8;
  let pend = [[7, 'GRP0', ROM(ptr(0) + 9)]];
  drawLine(t, out, 40, pend);
  for (let y = 9, L = 41; y >= 0; y--, L++) {
    const d = i => ROM(ptr(i) + y);
    const w = [[-44, 'GRP1', d(1)], [-20, 'GRP0', d(2)], [64, 'GRP1', d(3)], [73, 'GRP0', d(4)], [82, 'GRP1', d(5)], [91, 'GRP0', d(5)]];
    if (y) w.push([148, 'GRP0', ROM(ptr(0) + y - 1)]);
    else w.push([127, 'GRP0', 0], [136, 'GRP1', 0], [145, 'VDELP0', 0], [154, 'VDELP1', 0]);
    drawLine(t, out, L, w);
  }
  ram[0xDC] = 0xFF;
  drawLine(t, out, 51, [[-56, 'REFP1', 8]]);       // (and the band counter starts)
  // the ball: on or off from where the write lands
  const ballWrite = (X, on, offPx, onPx) => [on ? onPx : offPx, 'ENABL', on ? 2 : 1];
  const ballOn = X => ((X - R(0x95)) & 0xF8) === 0;
  // three demon bands: two lines positioning P0 and P1, a line with HMOVE, then a line per X
  let L = 52, X = 165;
  const col = (R(0xCE) << 8) | R(0xCD);
  for (let k = 0; k < 4; k++) {
    const p0 = POS.p0[R(0x8D + k)], p1 = POS.p1[R(0x91 + k)];
    const p0px = 7 + 15 * (R(0x8D + k) & 15), p1px = 7 + 15 * (R(0x91 + k) & 15);   // RESPx lands here (before HMOVE)
    if (opts.hmoveBlank) out.blank.add(L + 2);
    out.kind = 'positioning';
    drawLine(t, out, L++, [[p0px, 'POS0', (p0px + 5 + 160) % 160]]);
    drawLine(t, out, L++, [[p1px, 'POS1', (p1px + 5 + 160) % 160]]);
    if (k === 3) break;
    const c4 = R(0xC5 + k), nus = k === R(0x97) ? 7 : 0;
    ram[0xBF] = k; ram[0xC0] = (R(0x9D + k) << 3) & 255; ram[0xC2] = (R(0xA1 + k) << 3) & 255; ram[0xC4] = c4;
    drawLine(t, out, L++, [[-59, 'POS0', p0], [-59, 'POS1', p1], [70, 'NUSIZ0', nus], [79, 'NUSIZ1', nus]]);
    X -= 3;
    out.kind = 'band';
    for (;;) {
      const y = (X - c4) & 255;
      if (y < 8) {
        const on = ballOn(X);
        drawLine(t, out, L++, [[-5, 'GRP0', ROM(0x1E00 + ram[0xC0] + y)], [19, 'GRP1', ROM(0x1E00 + ram[0xC2] + y)],
          [43, 'COLUP0', ROM(col + y)], [52, 'COLUP1', ROM(col + y)], ballWrite(X, on, 103, 106)]);
      } else drawLine(t, out, L++, [ballWrite(X, ballOn(X), 28, 31)]);   // (its branch crosses a page: a cycle more)
      X = (X - 1) & 255;
      if (X < c4) break;
    }
  }
  // the cannon band: line c (HMOVE), then lines X = C7-1 down to 0
  const p0 = POS.p0[R(0x90)], p1 = POS.p1[R(0x94)];
  ram[0xBF] = 3;
  const c = [[-59, 'POS0', p0], [-59, 'POS1', p1], [-17, 'COLUP0', R(0xD3) & mask]];
  const cxBefore = t.cx;               // (CXPPMM is read before this line's pixels: lines up to L-1)
  out.cxMid = cxBefore & 0x80;
  out.kind = 'cannon band';
  ram[0xDC] = out.cxMid;
  // (X is already C7-1: the cannon band doesn't subtract the positioning lines)
  const cannon = X => X < 12 ? [[X < 12 ? -35 : 0, 'GRP0', ROM(0x1D88 + X)]] : [];
  if (R(0x99)) {
    // the cannon exploding: pieces from page $1D, every eight lines
    const y = (R(0x99) & 0x38) >> 3;
    ram[0xC0] = ROM(0x1DBC + y); ram[0xC1] = 0x1D;
    c.push([34, 'NUSIZ0', 0], [43, 'NUSIZ1', 0]);
    drawLine(t, out, L++, c);
    let a = 0;
    for (;; X--) {
      const on = ballOn(X);
      const w = [[-59, 'GRP0', a], [-50, 'GRP1', a], ballWrite(X, on, 1, 4)];
      a = 0;
      if (!(X & 2) && !(X & 4) && (X >> 3) < 5) {
        const cl = ROM(0x1DEC + (X >> 3));
        w.push([on ? 79 : 76, 'COLUP0', cl], [on ? 88 : 85, 'COLUP1', cl]);
        a = ROM(0x1D00 + ram[0xC0] + (X >> 3));
      }
      if (X === 0) w.push([136, 'REFP1', 0]);         // (stx REFP1 after the loop, still on its last line)
      drawLine(t, out, L++, w);
      if (X === 0) break;
    }
  } else if (!(R(0xEB) & 0x80)) {
    // a small demon diving (player 1, at $C8), and the cannon
    ram[0xC0] = (R(0xB3) << 3) & 255;
    c.push([25, 'REFP1', 0], [34, 'NUSIZ0', 0], [43, 'NUSIZ1', 0]);
    drawLine(t, out, L++, c);
    for (;; X--) {
      const cn = X < 12, y = (X - R(0xC8)) & 255, on = ballOn(X), w = cannon(X);
      if (y < 8) {
        w.push([cn ? 28 : 10, 'GRP1', ROM(0x1E00 + ram[0xC0] + y)], [cn ? 52 : 34, 'COLUP1', ROM(col + y)]);
        w.push(ballWrite(X, on, cn ? 103 : 85, cn ? 106 : 88));
      } else w.push(ballWrite(X, on, cn ? 58 : 40, cn ? 61 : 43));
      drawLine(t, out, L++, w);
      if (X === 0) break;
    }
  } else {
    // the demons' bullets: player 1 at $94, one row of $A5-$AE every 8 lines, dashed
    c.push([25, 'REFP1', 0], [34, 'NUSIZ0', 0], [43, 'NUSIZ1', 0], [82, 'COLUP1', 0x4E]);
    out.p1blMid = (t.cx >> 3 & 1) << 6;           // CXP1FB, read part-way along line c (nothing new there)
    ram[0xBF] = out.p1blMid;
    drawLine(t, out, L++, c);
    for (;; X--) {
      const cn = X < 12, on = ballOn(X), w = cannon(X);
      const T = (cn ? 28 : 22) + (on ? 1 : 0);
      w.push([3 * T - 68, 'ENABL', on ? 2 : 1]);
      if (X < 0x50) w.push([3 * (T + 34) - 68, 'GRP1', ((~X ^ R(0xBD)) & R(0xEC)) ? 0 : R(0xA5 + (X >> 3))]);
      drawLine(t, out, L++, w);
      if (X === 0) break;
    }
  }
  // the bottom: reserve bunkers on the ground's colour bands
  const lives = R(0xF2 + (R(0xF8) & 0x80 ? 0 : R(0xED)));
  out.kind = 'bottom';
  const ground = R(0xF7) & mask;
  drawLine(t, out, L++, [[-59, 'GRP0', 0], [-50, 'GRP1', 0], [10, 'POS0', 15], [19, 'POS1', 24]]);
  if (opts.hmoveBlank) out.blank.add(L);
  drawLine(t, out, L++, [[-59, 'POS1', 23], [-30, 'NUSIZ0', ROM(0x1DAE + lives)], [-15, 'NUSIZ1', ROM(0x1DB5 + lives)],
    [-5, 'COLUP0', R(0xD4)], [-2, 'COLUP1', R(0xD4)]]);
  for (let i = 5, cb = ground; i >= -1; i--, cb = (cb - 2) & 255) {
    const w = [[-59, 'COLUBK', cb]];
    if (i >= 0 && lives) w.push([-14, 'GRP0', ROM(0x1D9C + i)]);
    if (i >= 0 && lives >= 2) w.push([7, 'GRP1', ROM(0x1D9C + i)]);
    drawLine(t, out, L++, w);
  }
  ram[0xE7] = (ground - 12) & 255;
  out.lastLine = L - 1;
  out.cx = t.cx;
  out.ram = ram;
  return out;
}

// ---- the state at the kernel's start, from a VCS stopped at $1000
function snap(v) {
  return { ram: Uint8Array.from(v.ram), colupf: v.r[0x08], enabl: v.r[0x1F] };
}
module.exports = { model, snap, POS, ROMMD5, rom };
if (require.main !== module) return;

// ---- check against tools/vcs.js
const { VCS } = require('../../../tools/vcs');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const frames = +(process.argv[2] || 2000), verbose = process.argv.includes('--verbose'), showAt = arg('show', -1);
const vcs = new VCS(rom);
vcs.hmoveBlank = true;
const play = require('./play')(arg('seed', 11));
let m = null, checked = 0, frame = 0;
const bad = {}, ex = {};
const fail = (k, msg) => { bad[k] = (bad[k] || 0) + 1; if (!ex[k] || verbose) ex[k] = `frame ${frame}: ${msg}`; if (verbose) console.log(k, ex[k]); };
const os = vcs.step.bind(vcs);
vcs.step = function () {
  const pc = this.pc;
  if (pc === 0x1000) { const sn = snap(this); m = model(sn, { hmoveBlank: true }); m.state = sn.ram; }
  if (m && pc === 0x111F && this.a !== m.cxMid) fail('CXPPMM in the bands', `2600 ${this.a.toString(16)} model ${m.cxMid.toString(16)}`);
  if (m && pc === 0x11B8 && this.a !== m.p1blMid) fail('CXP1FB in the bands', `2600 ${this.a.toString(16)} model ${m.p1blMid.toString(16)}`);
  if (m && pc === 0x187A) check();
  return os();
};
const seen = {};
function check() {
  if (frame < 1) return;
  checked++;
  const R = a => vcs.ram[a - 0x80], st = m.state;
  const cover = { 'cannon exploding': st[0x19] !== 0, 'small demon diving': !st[0x19] && !(st[0x6B] & 0x80),
    'bullets': !st[0x19] && (st[0x6B] & 0x80) && [...Array(10).keys()].some(i => st[0x25 + i]), 'split demon': (st[0x36] | st[0x37] | st[0x38]) & 0x80,
    'quad-width demon': st[0x17] < 3, 'laser in flight': st[0x1C] & 0x40, 'two players': st[0x75], 'co-op': st[0x78] & 0x80 };
  for (const [k, v] of Object.entries(cover)) if (v) seen[k] = (seen[k] || 0) + 1;
  for (const [name, bits] of [['P0', 1], ['P1', 2], ['ball', 16]]) {
    let n = 0, first = '';
    for (let L = FIRST; L <= LAST; L++) for (let x = 0; x < 160; x++) {
      const a = vcs.ob[L * 160 + x] & bits, b = m.ob[L * 160 + x] & bits;
      if (a !== b) { n++; if (!first) first = `line ${L} x ${x}: 2600 ${a ? 'on' : 'off'}`; }
    }
    if (n) fail(name, `${n} pixels, e.g. ${first}`);
  }
  let n = 0, first = '';
  for (let L = FIRST; L <= LAST; L++) for (let x = 0; x < 160; x++)
    if (vcs.fb[L * 160 + x] !== m.fb[L * 160 + x]) { n++; if (!first) first = `line ${L} x ${x}: 2600 ${vcs.fb[L * 160 + x].toString(16)} model ${m.fb[L * 160 + x].toString(16)}`; }
  if (n) fail('colours', `${n} pixels, e.g. ${first}`);
  const want = vcs.cx & (1 << 13 | 1 << 5 | 1 << 7), got = (m.cx >> 7 & 1) << 13 | (m.cx >> 2 & 1) << 5 | (m.cx >> 3 & 1) << 7;
  if (want !== got) fail('collisions', `2600 ${want.toString(2)} model ${got.toString(2)}`);
  for (const [a, v] of Object.entries(m.ram)) if (+a !== 0xDC && +a !== 0xBF && vcs.ram[a - 0x80] !== v) fail('kernel RAM', `$${(+a).toString(16)} 2600 ${vcs.ram[a - 0x80].toString(16)} model ${v.toString(16)}`);
  for (const k of m.hits) if (k !== 'band' && k !== 'cannon band') fail('collision outside the objects', k + ' line');
  for (let k = 0; k < 3; k++) for (const a of [0x9D, 0xA1]) if (rom[0xE00 + ((st[a + k - 0x80] << 3) & 255)]) fail('demon row 0 not blank', 'band ' + k);
  if (frame === showAt) show();
}
function show() {
  for (let L = FIRST; L <= LAST; L++) {
    let r = '', any = false;
    for (let x = 0; x < 160; x++) { const a = vcs.ob[L * 160 + x], b = m.ob[L * 160 + x]; r += a === b ? (a ? '#' : '.') : a ? 'A' : 'm'; if (a || b) any = true; }
    if (any) console.log(String(L).padStart(3), r);
  }
}
for (frame = 0; frame < frames; frame++) {
  if (process.argv.includes('--cheat')) play.cheat(frame, vcs.ram);
  const p = play(frame, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  vcs.runFrames(1);
}
console.log(`${checked} frames checked; seen: ${Object.entries(seen).map(([k, v]) => `${k} ${v}`).join(', ')}`);
for (const k of ['P0', 'P1', 'ball', 'colours', 'collisions', 'CXPPMM in the bands', 'CXP1FB in the bands', 'kernel RAM', 'collision outside the objects', 'demon row 0 not blank'])
  console.log(k.padEnd(20), bad[k] ? `${bad[k]} frames differ, e.g. ${ex[k]}` : 'exact');
