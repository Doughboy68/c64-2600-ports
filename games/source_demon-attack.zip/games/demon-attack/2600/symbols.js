// Names for Demon Attack's RAM and routines, worked out by reading the code and
// watching RAM in tools/vcs.js. Used by tools/disasm.js to label the source and to
// write RAM-MAP.md. "?" marks something not yet confirmed.
//
// Imagic assembled the game at $1000-$1FFF (the 2600 sees the cartridge at any
// $x000 with bit 12 set), so its own addresses are $1xxx: game.banks says so.

const game = { title: 'Demon Attack', from: 'Imagic, 1982', md5: 'b12a7f63787a6bb08e683837a8ed3f18', asm: 'demonattack.asm', banks: [0x1000] };

const ram = [
  [0x80, 'WaveMod', 1, 'Wave number reduced for the tables (set from Wave)?'],
  [0x81, 'Scores', 6, 'Scores, BCD, high byte first: player 1 $81/$83/$85, player 2 $82/$84/$86'],
  [0x87, 'MotionAcc', 6, 'Movement accumulators (demons, bands)?'],
  [0x8D, 'P0Pos', 4, 'Player 0 position codes: bands 0-2 and the cannon (3)'],
  [0x91, 'P1Pos', 4, 'Player 1 position codes: bands 0-2 and the bullets / small demon (3)'],
  [0x95, 'LaserY', 1, 'The laser: its lowest kernel line (3: resting on the cannon)'],
  [0x96, 'LaserX', 1, 'The laser: position code'],
  [0x97, 'Growing', 1, 'Band whose demon is materializing (drawn four times as wide, NUSIZ 7)'],
  [0x98, 'LowestY', 1, 'Lowest demon line?'],
  [0x99, 'Dying', 1, 'Non-zero: the cannon has been hit (explosion, flashing background)'],
  [0x9A, 'BulletTimer', 1, 'Bullet timing?'],
  [0x9B, 'Killed', 1, 'Demons destroyed in this wave'],
  [0x9C, 'Flags', 1, 'State flags?'],
  [0x9D, 'P0Shape', 4, 'Player 0 graphics per band (index of 8 bytes from $1E00); +3 the cannon band'],
  [0xA1, 'P1Shape', 4, 'Player 1 graphics per band; +3 the cannon band'],
  [0xA5, 'Bullets', 10, 'The bullets: one graphics byte per 8-line row of the cannon band, from the bottom'],
  [0xAF, 'DemonState', 3, "Per band: the demon's state (splitting, exploding)?"],
  [0xB2, 'SmallState', 1, 'The small diving demon: state?'],
  [0xB3, 'SmallShape', 1, 'The small diving demon: graphics'],
  [0xB4, 'Unknown_B4', 1, '?'],
  [0xB5, 'SoundSel', 1, 'Sounds: low nibble channel 0, high nibble channel 1 (jump tables T12A1 / T12EF)'],
  [0xB6, 'SplitFlags', 3, 'Per band: the demon has split in two?'],
  [0xB9, 'Unknown_B9', 3, '?'],
  [0xBC, 'BgColour', 1, 'Background colour (flashes when the cannon is hit)'],
  [0xBD, 'Frame', 1, 'Frame counter'],
  [0xBE, 'Wave', 1, 'Wave number'],
  [0xBF, 'KernelTemp', 1, 'Kernel: band counter, or CXP1FB as read when the cannon band starts (bullets)'],
  [0xC0, 'KernelPtrs', 5, "Kernel: graphics pointers for the cannon band ($C0/$C1, $C2/$C3) and the last band's line ($C4)"],
  [0xC5, 'DemonY', 3, "Per band: the kernel line of the demon's bottom row"],
  [0xC8, 'SmallY', 1, "The small demon's bottom row"],
  [0xC9, 'Unknown_C9', 4, '?'],
  [0xCD, 'ColourPtr', 2, "The demons' colour table: a colour per row ($1FAE + 8 x (wave mod 7))"],
  [0xCF, 'SoundTemp', 2, 'Sound state?'],
  [0xD1, 'ColourMask', 1, '$FF, or less when the attract mode dims the colours'],
  [0xD2, 'ScoreColour', 1, 'Score colour'],
  [0xD3, 'CannonColour', 1, 'Cannon colour'],
  [0xD4, 'BunkerColour', 1, "Bunkers' colour"],
  [0xD5, 'Random', 1, 'Random number (shifted with feedback)'],
  [0xD6, 'SplitMotion', 6, "Split demons' movement?"],
  [0xDC, 'KernelRow', 1, 'Kernel: the score row counter, then CXPPMM as read when the cannon band starts'],
  [0xDD, 'DigitPtr', 12, "The score's six digit pointers ($E7 is reused by the kernel for the ground colours)"],
  [0xE9, 'SelectTimer', 1, 'Game Select repeat delay?'],
  [0xEA, 'GameNumber', 1, 'Selected game, BCD'],
  [0xEB, 'WaveFlags', 1, 'Bit 7: the demons shoot bullets (else a small demon dives)'],
  [0xEC, 'DashMask', 1, '4: the bullets are dashed'],
  [0xED, 'Player', 1, 'Whose turn it is'],
  [0xEE, 'LaserSpeed', 1, 'Laser speed?'],
  [0xEF, 'Unknown_EF', 1, '?'],
  [0xF0, 'Level', 1, 'Difficulty level?'],
  [0xF1, 'Running', 1, 'Bit 7: a game is running?'],
  [0xF2, 'Lives', 2, 'Bunkers (lives) per player'],
  [0xF4, 'WaveEnd', 1, 'Timer at the end of a wave?'],
  [0xF5, 'TwoPlayer', 1, 'Two-player game?'],
  [0xF6, 'Tracer', 1, 'Tracer shots (the laser follows the joystick)?'],
  [0xF7, 'GroundColour', 1, 'Ground colour (the kernel draws 7 lines, two shades darker each)'],
  [0xF8, 'CoOp', 1, 'Bit 7: a co-op game (shared bunkers)'],
  [0xF9, 'FireLast', 1, 'Fire button last frame?'],
  [0xFA, 'Stack', 6, 'Stack'],
];

const labels = {
  0x1000: ['Kernel', 'The picture: laser and score positions, score (48-pixel trick), demon bands, cannon band, bunkers, ground'],
  0x1049: ['KernelTop', 'Wait for the timer, VBLANK off, clear the collisions'],
  0x105A: ['ScoreRows', 'The score, rows 9-0'],
  0x124A: ['Reset', 'Power on'],
  0x187A: ['Overscan', 'After the picture: the game logic, sounds, then the next frame'],
};

// Code the tracer can't reach on its own (jump tables, pushed return addresses)
const code = [
  0x12B2, 0x12CC,                   // channel 0 sound, by the low nibble of $B5 (table T12A1, pushed and RTS)
  0x12F7, 0x134F, 0x135C,           // channel 1 sound, by the high nibble of $B5 (table T12EF)
];

module.exports = { game, ram, labels, code };
