# Demon Attack (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80` | WaveMod | 1 | Wave number reduced for the tables (set from Wave)? |
| `$81-$86` | Scores | 6 | Scores, BCD, high byte first: player 1 $81/$83/$85, player 2 $82/$84/$86 |
| `$87-$8C` | MotionAcc | 6 | Movement accumulators (demons, bands)? |
| `$8D-$90` | P0Pos | 4 | Player 0 position codes: bands 0-2 and the cannon (3) |
| `$91-$94` | P1Pos | 4 | Player 1 position codes: bands 0-2 and the bullets / small demon (3) |
| `$95` | LaserY | 1 | The laser: its lowest kernel line (3: resting on the cannon) |
| `$96` | LaserX | 1 | The laser: position code |
| `$97` | Growing | 1 | Band whose demon is materializing (drawn four times as wide, NUSIZ 7) |
| `$98` | LowestY | 1 | Lowest demon line? |
| `$99` | Dying | 1 | Non-zero: the cannon has been hit (explosion, flashing background) |
| `$9A` | BulletTimer | 1 | Bullet timing? |
| `$9B` | Killed | 1 | Demons destroyed in this wave |
| `$9C` | Flags | 1 | State flags? |
| `$9D-$A0` | P0Shape | 4 | Player 0 graphics per band (index of 8 bytes from $1E00); +3 the cannon band |
| `$A1-$A4` | P1Shape | 4 | Player 1 graphics per band; +3 the cannon band |
| `$A5-$AE` | Bullets | 10 | The bullets: one graphics byte per 8-line row of the cannon band, from the bottom |
| `$AF-$B1` | DemonState | 3 | Per band: the demon's state (splitting, exploding)? |
| `$B2` | SmallState | 1 | The small diving demon: state? |
| `$B3` | SmallShape | 1 | The small diving demon: graphics |
| `$B4` | Unknown_B4 | 1 | ? |
| `$B5` | SoundSel | 1 | Sounds: low nibble channel 0, high nibble channel 1 (jump tables T12A1 / T12EF) |
| `$B6-$B8` | SplitFlags | 3 | Per band: the demon has split in two? |
| `$B9-$BB` | Unknown_B9 | 3 | ? |
| `$BC` | BgColour | 1 | Background colour (flashes when the cannon is hit) |
| `$BD` | Frame | 1 | Frame counter |
| `$BE` | Wave | 1 | Wave number |
| `$BF` | KernelTemp | 1 | Kernel: band counter, or CXP1FB as read when the cannon band starts (bullets) |
| `$C0-$C4` | KernelPtrs | 5 | Kernel: graphics pointers for the cannon band ($C0/$C1, $C2/$C3) and the last band's line ($C4) |
| `$C5-$C7` | DemonY | 3 | Per band: the kernel line of the demon's bottom row |
| `$C8` | SmallY | 1 | The small demon's bottom row |
| `$C9-$CC` | Unknown_C9 | 4 | ? |
| `$CD-$CE` | ColourPtr | 2 | The demons' colour table: a colour per row ($1FAE + 8 x (wave mod 7)) |
| `$CF-$D0` | SoundTemp | 2 | Sound state? |
| `$D1` | ColourMask | 1 | $FF, or less when the attract mode dims the colours |
| `$D2` | ScoreColour | 1 | Score colour |
| `$D3` | CannonColour | 1 | Cannon colour |
| `$D4` | BunkerColour | 1 | Bunkers' colour |
| `$D5` | Random | 1 | Random number (shifted with feedback) |
| `$D6-$DB` | SplitMotion | 6 | Split demons' movement? |
| `$DC` | KernelRow | 1 | Kernel: the score row counter, then CXPPMM as read when the cannon band starts |
| `$DD-$E8` | DigitPtr | 12 | The score's six digit pointers ($E7 is reused by the kernel for the ground colours) |
| `$E9` | SelectTimer | 1 | Game Select repeat delay? |
| `$EA` | GameNumber | 1 | Selected game, BCD |
| `$EB` | WaveFlags | 1 | Bit 7: the demons shoot bullets (else a small demon dives) |
| `$EC` | DashMask | 1 | 4: the bullets are dashed |
| `$ED` | Player | 1 | Whose turn it is |
| `$EE` | LaserSpeed | 1 | Laser speed? |
| `$EF` | Unknown_EF | 1 | ? |
| `$F0` | Level | 1 | Difficulty level? |
| `$F1` | Running | 1 | Bit 7: a game is running? |
| `$F2-$F3` | Lives | 2 | Bunkers (lives) per player |
| `$F4` | WaveEnd | 1 | Timer at the end of a wave? |
| `$F5` | TwoPlayer | 1 | Two-player game? |
| `$F6` | Tracer | 1 | Tracer shots (the laser follows the joystick)? |
| `$F7` | GroundColour | 1 | Ground colour (the kernel draws 7 lines, two shades darker each) |
| `$F8` | CoOp | 1 | Bit 7: a co-op game (shared bunkers) |
| `$F9` | FireLast | 1 | Fire button last frame? |
| `$FA-$FF` | Stack | 6 | Stack |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$1000` | Kernel | The picture: laser and score positions, score (48-pixel trick), demon bands, cannon band, bunkers, ground |
| `$1049` | KernelTop | Wait for the timer, VBLANK off, clear the collisions |
| `$105A` | ScoreRows | The score, rows 9-0 |
| `$124A` | Reset | Power on |
| `$187A` | Overscan | After the picture: the game logic, sounds, then the next frame |
