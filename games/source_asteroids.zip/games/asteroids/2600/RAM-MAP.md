# Asteroids (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80` | GameMode | 1 | Selected game and its options: bit 7 attract mode (no game), bit 6 Select held, bit 5 two players, bits 3-4 the special feature (hyperspace, shields, flip, none), bits 1-2 bonus ship score, bit 0 asteroid speed? |
| `$81-$82` | Random | 2 | Random number generator state (NextRandom) |
| `$83-$94` | AstY | 18 | Asteroid slots: row of the top of each asteroid (negative: partly above the top); $E0 ends a list. Slots 0-8 player 0, 9-17 player 1 |
| `$95-$A6` | AstX | 18 | Asteroid slots: X code |
| `$A7-$B8` | AstType | 18 | Asteroid slots: bits 0-2 colour, bits 4-6 shape (size and variant; also the offset of its graphics), bit 3 and bit 7 direction?, bit 6 hit |
| `$B9` | FrameCount | 1 | Frame counter; bit 0 set: this frame shows the asteroids, clear: the ship, UFO and shots |
| `$BA` | FrameCountHi | 1 | Frame counter, high byte (game over colour cycle, attract timing) |
| `$BB` | AstAnim | 1 | Asteroid animation / motion phase? |
| `$BC` | ShipsDir | 1 | Current player: ships left (high nibble), ship direction 0-15 (low nibble) |
| `$BD-$BE` | Score | 2 | Current player's score, BCD (thousands and hundreds, tens; the last digit is always 0) |
| `$BF-$C1` | OtherPlayer | 3 | The other player's ShipsDir and Score (swapped when the turn passes) |
| `$C2` | SplitFlag | 1 | An asteroid was hit and must be split / removed this frame? |
| `$C3` | SoundTimer0 | 1 | Sound timer (explosions)? |
| `$C4` | SoundTimer1 | 1 | Sound timer (thrust, UFO, extra ship)? |
| `$C5` | SoundFlags | 1 | Which sounds are playing |
| `$C6` | Timer | 1 | Copyright screen frame count at power-on; later the UFO timer |
| `$C7` | Flags | 1 | Bit 7 player 2 up, bit 6 no game (attract or game over), bit 5 UFO rather than satellite, bit 4 fire held, bit 3 UFO exploding, bits 1-2 UFO direction |
| `$C8` | ShipFlags | 1 | Bit 0 no game running, bit 1 ship exploding, bit 2 hyperspace / feature used, bit 6 shields or hyperspace active, bit 7 flip done? |
| `$C9` | ShipX | 1 | Ship X code |
| `$CA` | ShipY | 1 | Ship row; $E0 when not on screen |
| `$CB-$CC` | ShipFrac | 2 | Ship position fractions (X, Y)? |
| `$CD-$D0` | ShipVel | 4 | Ship velocity: X and Y high bytes, then low bytes |
| `$D1` | UfoX | 1 | UFO / satellite X code |
| `$D2` | UfoY | 1 | UFO / satellite row; $E0 when none |
| `$D3-$D5` | ShotX | 3 | Shots: X codes (missile 0, missile 1: the ship's; the ball: the UFO's) |
| `$D6-$D8` | ShotY | 3 | Shots: rows ($E0 none) |
| `$D9-$DB` | ShotState | 3 | Shots: time left (high nibble) and direction (low nibble); 0 = no shot |
| `$DC` | Slot0 | 1 | Kernel: player 0's current asteroid slot (0-8) |
| `$DD` | Slot1 | 1 | Kernel: player 1's current asteroid slot (9-17) |
| `$DE` | ShipState | 1 | Ship: bit 7 exploding (counts up), else frames until it may reappear |
| `$DF` | ShipStartY | 1 | Row the ship reappears at |
| `$E0` | ColourMask | 1 | EORed into the score colour (game over: the background cycles) |
| `$E1` | CheckPhase | 1 | Which objects are checked for hits this frame (a 4-frame cycle)? |
| `$E2` | Temp | 1 | Scratch (hit tests) |
| `$E3-$E4` | P0Vector | 2 | Asteroid kernel: player 0 thread's next routine (low byte: $C0 wait, $0E / $46 position, $83 draw) |
| `$E5-$E6` | P1Vector | 2 | Asteroid kernel: player 1 thread's next routine ($CF, $0B / $45, $88). Ship frame: +1 = $E6 the UFO graphics pointer |
| `$E7` | Coarse0 | 1 | Asteroid kernel: coarse delay for player 0 (ship frame: page of the UFO graphics) |
| `$E8` | Coarse1 | 1 | Asteroid kernel: coarse delay for player 1 (ship frame: the ball's colour) |
| `$E9` | Pos0 | 1 | Asteroid kernel: X code being positioned for player 0 (ship frame: ship colour) |
| `$EA` | Pos1 | 1 | Asteroid kernel: X code for player 1 (ship frame: UFO colour) |
| `$EB-$EC` | Gfx0 | 2 | Asteroid kernel: player 0 graphics pointer (ship frame: $EB REFP0/VDELP0, $EC VDELP1) |
| `$ED-$EE` | Gfx1 | 2 | Asteroid kernel: player 1 graphics pointer (ship frame: the ship's graphics pointer) |
| `$EF-$F0` | Move0 | 2 | Asteroid kernel: player 0 motion/size pointer (each row: HMP0 and NUSIZ0; 0 ends the shape). Ship frame: $EF the ship's top row |
| `$F1-$F2` | Move1 | 2 | Asteroid kernel: player 1 motion/size pointer. Ship frame: $F1 the ship shape, $F2 the UFO shape |
| `$F3` | Temp2 | 1 | Scratch |
| `$F4-$F6` | Temp3 | 3 | Scratch; score kernel: digit pointer ($F4 row, $F5 page $DD) ... |
| `$F7-$F8` | BankJump | 2 | Where the bank switch stub jumps; score kernel: digit offsets $F6-$FB |
| `$F9-$FB` | Temp4 | 3 | Scratch; score kernel: digit offsets |
| `$FC-$FF` | ScorePF | 4 | Score kernel: the next row's PF0, PF1, PF2 (left) and PF2 (right) |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$D000` | AsteroidKernel | Asteroid field kernel: the shared line starts (P1 line at $D003, P0 line at $D100) and the two threads' routines |
| `$D00E` | P0PosEarly | Player 0 thread: position the next asteroid (early routine), coarse delay Coarse0 |
| `$D046` | P0PosLate | Player 0 thread: position the next asteroid (late routine) |
| `$D083` | P0Draw | Player 0 thread: draw a row (motion/size byte, graphics); a 0 byte ends the asteroid |
| `$D0C0` | P0Wait | Player 0 thread: wait for the next asteroid's row |
| `$D100` | P0Line | Line start for player 0: WSYNC, HMOVE, GRP0, NUSIZ0, then the player 1 thread |
| `$D10B` | P1PosEarly | Player 1 thread: position the next asteroid (early routine) |
| `$D145` | P1PosLate | Player 1 thread: position the next asteroid (late routine) |
| `$D188` | P1Draw | Player 1 thread: draw a row |
| `$D1CF` | P1Wait | Player 1 thread: wait for the next asteroid's row |
| `$D21B` | ScoreKernel | Picture: the score band (five 2-line rows of playfield digits), then the asteroid or ship kernel |
| `$D2A1` | AsteroidStart | Start the asteroid kernel (colours of the first slots) |
| `$D2F3` | ShipKernel | Ship frame: position the ship and the UFO, then draw them and the shots (PHP onto ENABL/ENAM1/ENAM0) |
| `$D42B` | KernelEnd | End of the picture: graphics and shots off, back to bank 1 |
| `$D43C` | PrepareScore | Before the picture: the score's digits (or the game number), sprites for the score band |
| `$D57E` | WaitPicture | Wait for the timer, then draw the picture |
| `$D591` | Reset0 | Power on in bank 0: go to bank 1's reset |
| `$D600` | StepX | Move X code $95,X by A pixels (carry: direction) with the $D700 / $D800 tables |
| `$D900` | ReadMove0 | Read the first motion byte of player 0's asteroid (for bank 1) |
| `$D90F` | ReadMove1 | Read the first motion byte of player 1's asteroid (for bank 1) |
| `$DB00` | TitleScreen | Power on: "(c) 1981 Atari, Inc." for 256 frames (48-pixel text kernel) |
| `$DFF0` | ToBank1 | Switch to bank 1 and jump to BankJump |
| `$F000` | Overscan | After the picture: console switches (Reset, Select), then the game logic |
| `$F07D` | GameLogic | Each frame: find the ends of the asteroid lists, splits, hit tests |
| `$F20F` | Sound | Sound effects |
| `$F316` | FrameSync | Wait for the timer, vertical sync; then the asteroid or ship frame's setup |
| `$F35D` | AsteroidFrame | Asteroid frame: move the asteroids, set up the kernel threads (partly hidden asteroids at the top) |
| `$F5D7` | ShipFrame | Ship frame: joystick, fire, thrust, move the ship, the UFO and the shots, position the shots |
| `$F9DA` | Reset1 | Power on: clear RAM, start the copyright screen |
| `$FA03` | NewGame | Start a game |
| `$FA3B` | MoveAsteroidX | Move asteroid X sideways (speed from its type) |
| `$FAC2` | CallStepX | Call StepX in bank 0 |
| `$FACE` | SwapPlayers | Swap the current and the other player's ships and score |
| `$FAE2` | NextRandom | Next random number (A) |
| `$FAF0` | HitTest | Does object X (at A, Y) hit an asteroid? |
| `$FBA9` | Overlap | Do two objects overlap? (boxes from the tables at $FF33 / $FF3E) |
| `$FCCA` | XCodeToPixel | X code -> pixel column (tables $FF15 / $FF25) |
| `$FCE7` | SplitAsteroids | Split or remove the asteroids that were hit |
| `$FDF3` | NewWave | A new wave of asteroids |
| `$FF97` | ToPicture | Go to bank 0 to draw the picture |
| `$FFF0` | ToBank0 | Switch to bank 0 and jump to BankJump |
