// Names for Asteroids' RAM and routines, worked out by reading the code and watching RAM
// in tools/vcs.js. Used by tools/disasm.js to label the source and to write RAM-MAP.md.
// "?" marks something not yet confirmed.
//
// Conventions found in the code:
//   - The cartridge is 8K in two banks (F8). Bank 0 ($D000) holds the kernels and the graphics,
//     bank 1 ($F000) the game logic. Every switch goes through the stub at $xFF0:
//     "sta SelectBankN / jmp ($F7)", with the target in BankJump.
//   - Rows: the field is $59 (89) rows of 2 lines; Y positions count rows from the top.
//     $E0 in a Y position means "nothing there" (and ends the asteroid lists).
//   - X positions are kept the way the kernel needs them ("X codes"): bits 1-3 a coarse delay
//     (15 pixels a step), bit 0 picks the early or late positioning routine, bits 4-7 the fine
//     motion for HMOVE. Tables at $D700/$D800 step a code one pixel left / right.
//   - Asteroids are two lists of 9 slots, sorted top to bottom: slots 0-8 are drawn with player 0,
//     slots 9-17 with player 1 (two kernel "threads" on alternate lines).
//   - Frames alternate: the asteroids on one, the ship, UFO and shots on the next (FrameCount
//     bit 0). The game never reads the TIA's collision registers; it works out all hits itself.

const game = {
  title: 'Asteroids', from: 'Atari 2600, 1981', md5: 'dd7884b4f93cab423ac471aa1935e3df', asm: 'asteroids.asm',
  banks: [0xD000, 0xF000],
};

const ram = [
  [0x80, 'GameMode', 1, 'Selected game and its options: bit 7 attract mode (no game), bit 6 Select held, bit 5 two players, bits 3-4 the special feature (hyperspace, shields, flip, none), bits 1-2 bonus ship score, bit 0 asteroid speed?'],
  [0x81, 'Random', 2, 'Random number generator state (NextRandom)'],
  [0x83, 'AstY', 18, 'Asteroid slots: row of the top of each asteroid (negative: partly above the top); $E0 ends a list. Slots 0-8 player 0, 9-17 player 1'],
  [0x95, 'AstX', 18, 'Asteroid slots: X code'],
  [0xA7, 'AstType', 18, 'Asteroid slots: bits 0-2 colour, bits 4-6 shape (size and variant; also the offset of its graphics), bit 3 and bit 7 direction?, bit 6 hit'],
  [0xB9, 'FrameCount', 1, 'Frame counter; bit 0 set: this frame shows the asteroids, clear: the ship, UFO and shots'],
  [0xBA, 'FrameCountHi', 1, 'Frame counter, high byte (game over colour cycle, attract timing)'],
  [0xBB, 'AstAnim', 1, 'Asteroid animation / motion phase?'],
  [0xBC, 'ShipsDir', 1, 'Current player: ships left (high nibble), ship direction 0-15 (low nibble)'],
  [0xBD, 'Score', 2, 'Current player\'s score, BCD (thousands and hundreds, tens; the last digit is always 0)'],
  [0xBF, 'OtherPlayer', 3, 'The other player\'s ShipsDir and Score (swapped when the turn passes)'],
  [0xC2, 'SplitFlag', 1, 'An asteroid was hit and must be split / removed this frame?'],
  [0xC3, 'SoundTimer0', 1, 'Sound timer (explosions)?'],
  [0xC4, 'SoundTimer1', 1, 'Sound timer (thrust, UFO, extra ship)?'],
  [0xC5, 'SoundFlags', 1, 'Which sounds are playing'],
  [0xC6, 'Timer', 1, 'Copyright screen frame count at power-on; later the UFO timer'],
  [0xC7, 'Flags', 1, 'Bit 7 player 2 up, bit 6 no game (attract or game over), bit 5 UFO rather than satellite, bit 4 fire held, bit 3 UFO exploding, bits 1-2 UFO direction'],
  [0xC8, 'ShipFlags', 1, 'Bit 0 no game running, bit 1 ship exploding, bit 2 hyperspace / feature used, bit 6 shields or hyperspace active, bit 7 flip done?'],
  [0xC9, 'ShipX', 1, 'Ship X code'],
  [0xCA, 'ShipY', 1, 'Ship row; $E0 when not on screen'],
  [0xCB, 'ShipFrac', 2, 'Ship position fractions (X, Y)?'],
  [0xCD, 'ShipVel', 4, 'Ship velocity: X and Y high bytes, then low bytes'],
  [0xD1, 'UfoX', 1, 'UFO / satellite X code'],
  [0xD2, 'UfoY', 1, 'UFO / satellite row; $E0 when none'],
  [0xD3, 'ShotX', 3, 'Shots: X codes (missile 0, missile 1: the ship\'s; the ball: the UFO\'s)'],
  [0xD6, 'ShotY', 3, 'Shots: rows ($E0 none)'],
  [0xD9, 'ShotState', 3, 'Shots: time left (high nibble) and direction (low nibble); 0 = no shot'],
  [0xDC, 'Slot0', 1, 'Kernel: player 0\'s current asteroid slot (0-8)'],
  [0xDD, 'Slot1', 1, 'Kernel: player 1\'s current asteroid slot (9-17)'],
  [0xDE, 'ShipState', 1, 'Ship: bit 7 exploding (counts up), else frames until it may reappear'],
  [0xDF, 'ShipStartY', 1, 'Row the ship reappears at'],
  [0xE0, 'ColourMask', 1, 'EORed into the score colour (game over: the background cycles)'],
  [0xE1, 'CheckPhase', 1, 'Which objects are checked for hits this frame (a 4-frame cycle)?'],
  [0xE2, 'Temp', 1, 'Scratch (hit tests)'],
  [0xE3, 'P0Vector', 2, 'Asteroid kernel: player 0 thread\'s next routine (low byte: $C0 wait, $0E / $46 position, $83 draw)'],
  [0xE5, 'P1Vector', 2, 'Asteroid kernel: player 1 thread\'s next routine ($CF, $0B / $45, $88). Ship frame: +1 = $E6 the UFO graphics pointer'],
  [0xE7, 'Coarse0', 1, 'Asteroid kernel: coarse delay for player 0 (ship frame: page of the UFO graphics)'],
  [0xE8, 'Coarse1', 1, 'Asteroid kernel: coarse delay for player 1 (ship frame: the ball\'s colour)'],
  [0xE9, 'Pos0', 1, 'Asteroid kernel: X code being positioned for player 0 (ship frame: ship colour)'],
  [0xEA, 'Pos1', 1, 'Asteroid kernel: X code for player 1 (ship frame: UFO colour)'],
  [0xEB, 'Gfx0', 2, 'Asteroid kernel: player 0 graphics pointer (ship frame: $EB REFP0/VDELP0, $EC VDELP1)'],
  [0xED, 'Gfx1', 2, 'Asteroid kernel: player 1 graphics pointer (ship frame: the ship\'s graphics pointer)'],
  [0xEF, 'Move0', 2, 'Asteroid kernel: player 0 motion/size pointer (each row: HMP0 and NUSIZ0; 0 ends the shape). Ship frame: $EF the ship\'s top row'],
  [0xF1, 'Move1', 2, 'Asteroid kernel: player 1 motion/size pointer. Ship frame: $F1 the ship shape, $F2 the UFO shape'],
  [0xF3, 'Temp2', 1, 'Scratch'],
  [0xF4, 'Temp3', 3, 'Scratch; score kernel: digit pointer ($F4 row, $F5 page $DD) ...'],
  [0xF7, 'BankJump', 2, 'Where the bank switch stub jumps; score kernel: digit offsets $F6-$FB'],
  [0xF9, 'Temp4', 3, 'Scratch; score kernel: digit offsets'],
  [0xFC, 'ScorePF', 4, 'Score kernel: the next row\'s PF0, PF1, PF2 (left) and PF2 (right)'],
];

const labels = {
  0xD000: ['AsteroidKernel', 'Asteroid field kernel: the shared line starts (P1 line at $D003, P0 line at $D100) and the two threads\' routines'],
  0xD00E: ['P0PosEarly', 'Player 0 thread: position the next asteroid (early routine), coarse delay Coarse0'],
  0xD046: ['P0PosLate', 'Player 0 thread: position the next asteroid (late routine)'],
  0xD083: ['P0Draw', 'Player 0 thread: draw a row (motion/size byte, graphics); a 0 byte ends the asteroid'],
  0xD0C0: ['P0Wait', 'Player 0 thread: wait for the next asteroid\'s row'],
  0xD100: ['P0Line', 'Line start for player 0: WSYNC, HMOVE, GRP0, NUSIZ0, then the player 1 thread'],
  0xD10B: ['P1PosEarly', 'Player 1 thread: position the next asteroid (early routine)'],
  0xD145: ['P1PosLate', 'Player 1 thread: position the next asteroid (late routine)'],
  0xD188: ['P1Draw', 'Player 1 thread: draw a row'],
  0xD1CF: ['P1Wait', 'Player 1 thread: wait for the next asteroid\'s row'],
  0xD21B: ['ScoreKernel', 'Picture: the score band (five 2-line rows of playfield digits), then the asteroid or ship kernel'],
  0xD2A1: ['AsteroidStart', 'Start the asteroid kernel (colours of the first slots)'],
  0xD2F3: ['ShipKernel', 'Ship frame: position the ship and the UFO, then draw them and the shots (PHP onto ENABL/ENAM1/ENAM0)'],
  0xD42B: ['KernelEnd', 'End of the picture: graphics and shots off, back to bank 1'],
  0xD43C: ['PrepareScore', 'Before the picture: the score\'s digits (or the game number), sprites for the score band'],
  0xD57E: ['WaitPicture', 'Wait for the timer, then draw the picture'],
  0xD591: ['Reset0', 'Power on in bank 0: go to bank 1\'s reset'],
  0xD600: ['StepX', 'Move X code $95,X by A pixels (carry: direction) with the $D700 / $D800 tables'],
  0xD900: ['ReadMove0', 'Read the first motion byte of player 0\'s asteroid (for bank 1)'],
  0xD90F: ['ReadMove1', 'Read the first motion byte of player 1\'s asteroid (for bank 1)'],
  0xDB00: ['TitleScreen', 'Power on: "(c) 1981 Atari, Inc." for 256 frames (48-pixel text kernel)'],
  0xDFF0: ['ToBank1', 'Switch to bank 1 and jump to BankJump'],
  0xF000: ['Overscan', 'After the picture: console switches (Reset, Select), then the game logic'],
  0xF07D: ['GameLogic', 'Each frame: find the ends of the asteroid lists, splits, hit tests'],
  0xF20F: ['Sound', 'Sound effects'],
  0xF316: ['FrameSync', 'Wait for the timer, vertical sync; then the asteroid or ship frame\'s setup'],
  0xF35D: ['AsteroidFrame', 'Asteroid frame: move the asteroids, set up the kernel threads (partly hidden asteroids at the top)'],
  0xF5D7: ['ShipFrame', 'Ship frame: joystick, fire, thrust, move the ship, the UFO and the shots, position the shots'],
  0xF9DA: ['Reset1', 'Power on: clear RAM, start the copyright screen'],
  0xFA03: ['NewGame', 'Start a game'],
  0xFA3B: ['MoveAsteroidX', 'Move asteroid X sideways (speed from its type)'],
  0xFAC2: ['CallStepX', 'Call StepX in bank 0'],
  0xFACE: ['SwapPlayers', 'Swap the current and the other player\'s ships and score'],
  0xFAE2: ['NextRandom', 'Next random number (A)'],
  0xFAF0: ['HitTest', 'Does object X (at A, Y) hit an asteroid?'],
  0xFBA9: ['Overlap', 'Do two objects overlap? (boxes from the tables at $FF33 / $FF3E)'],
  0xFCCA: ['XCodeToPixel', 'X code -> pixel column (tables $FF15 / $FF25)'],
  0xFCE7: ['SplitAsteroids', 'Split or remove the asteroids that were hit'],
  0xFDF3: ['NewWave', 'A new wave of asteroids'],
  0xFF97: ['ToPicture', 'Go to bank 0 to draw the picture'],
  0xFFF0: ['ToBank0', 'Switch to bank 0 and jump to BankJump'],
};

// Code the tracer can't reach on its own: the targets of the bank switches (JMP ($F7)) and of
// the asteroid kernel's threads (JMP ($E3) / JMP ($E5)); found by tools/coverage.js
const code = [0xD00E, 0xD046, 0xD083, 0xD0C0, 0xD10B, 0xD145, 0xD188, 0xD1CF, 0xD43C, 0xD600, 0xD900, 0xD90F, 0xDB00,
  0xF000, 0xF40C, 0xF480, 0xFA07, 0xFACD];

module.exports = { game, ram, labels, code };
