; =================================================================== sound
; The game's TIA sound registers, translated to SID voices 1 and 2 once a frame.
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        beq _off
        ldy v1
        lda SidWave,y
        beq _off2
        sta tmp                 ; waveform
        lda v1                  ; frequency index = AUDC * 32 + AUDF
        lsr
        lsr
        lsr
        sta ptrA+1
        lda v1
        asl
        asl
        asl
        asl
        asl
        ora v2
        clc
        adc FreqTab
        sta ptrA
        lda ptrA+1
        adc FreqTab+1
        sta ptrA+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d400,y
        inc ptrA+1
        inc ptrA+1
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d401,y
        lda #0
        sta $d402,y
        sta $d405,y
        lda #8
        sta $d403,y
        lda v0                  ; volume becomes the sustain level
        asl
        asl
        asl
        asl
        sta $d406,y
        lda v0                  ; retrigger only when volume or waveform changes
        cmp SndLast,x
        bne +
        lda v1
        cmp SndLast+2,x
        beq _save
+       lda tmp
        sta $d404,y
        ora #1
        sta $d404,y
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts

; ================================================================== tables
Bit:        .byte $01, $02, $04, $08, $10, $20, $40, $80
SidVoice:   .byte 0, 7
ScrLo:      .byte <SCREEN0, <SCREEN1        ; per buffer: screen, characters, $D018,
ScrHi:      .byte >SCREEN0, >SCREEN1        ; first schedule entry
ChrLo:      .byte <CHARS0, <CHARS1
ChrHi:      .byte >CHARS0, >CHARS1
BufD018:    .byte D018_0, D018_1
SchedBase:  .byte 0, NSCHED
RowOfsLo:   .for r = 0, r < 25, r += 1
            .byte <(40 * r)
            .next
RowOfsHi:   .for r = 0, r < 25, r += 1
            .byte >(40 * r)
            .next

        .include "tables.inc"
        .include "shapes.asm"

; ------------------------------------------------------- variables (RAM)
DbgSWCHA:   .byte $ff           ; AND masks applied to the inputs (testing aid)
DbgINPT4:   .byte $ff
DbgSWCHB:   .byte $ff
DbgBorder:  .byte 0             ; non-zero: colour the border while drawing / running the game
DbgLoops:   .word 0             ; main loop passes
DbgLate:    .word 0             ; ... that found more than one frame gone by
DbgTops:    .byte 0             ; frame tops the interrupt has done
DbgRMax:    .word 0             ; the most cycles one pass spent drawing,
DbgTMax:    .word 0             ; ... running the game,
DbgPMax:    .word 0             ; ... in all
DbgDrop:    .byte 0             ; objects left out (no sprite free)
DbgSched:   .byte 0             ; schedule full
DbgOdd:     .byte 0             ; a kernel thread in a state not handled
DbgBadP:    .byte 0             ; an asteroid drawn from outside a shape
DbgWide:    .byte 0             ; a shape row wider than a sprite
DbgSprLate: .byte 0             ; sprite reuses written after their first line had begun
DbgShown:   .fill 4             ; frames shown: copyright, asteroids, ship frame, both
BufShow:    .fill 2             ; what each buffer shows (0 copyright, 1 asteroids, 2 ship, 3 both)
dbgT0:      .word 0
dbgT1:      .word 0
dbgNow:     .word 0
dbgTmp:     .word 0
FreqTab:    .word SidFreqLo     ; PAL or NTSC frequency tables
Flicker:    .byte 1             ; 1: asteroids and ship on alternate frames like the 2600 (key F)
PrevKeyF:   .byte $ff
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
SndLast:    .fill 6, $ff
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0

; capture: what the last tick of each kind would have drawn
Resume:     .word 0             ; where the game continues next tick
LastType:   .byte 2             ; 0 asteroid frame, 1 ship frame, 2 copyright screen
CBk:        .byte 0             ; COLUBK
CScoreCol:  .byte 0             ; COLUPF
CScore:     .fill 20            ; score rows 0-4: PF0, PF1, PF2, right PF2
CScoreKey:  .fill 6, $ff        ; the digit offsets they were made from
CScoreVer:  .byte 0             ; counts their changes
CAN:        .fill 2             ; asteroid objects per thread (at 0 and 9):
CALine:     .fill 18            ; first visible line
CAX:        .fill 18            ; sprite X (2600 pixel + 32)
CAP:        .fill 18            ; the kernel's pointer: shape * $10 + first row
CARows:     .fill 18            ; rows
CACol:      .fill 18            ; 2600 colour
CSCol:      .fill 2             ; ship frame: colours of the ship and the UFO,
CSColBL:    .byte 0             ; the ball,
CSRefl:     .fill 2             ; reflection (bit 3),
CSX:        .fill 2             ; sprite X,
CSSegLine:  .fill 4             ; parts (ship 0-1, UFO 2-3): first line,
CSSegRows:  .fill 4             ; rows,
CSSegData:  .fill 32            ; graphics (8 per part)
CSShotLine: .fill 3             ; shots: first line (0: none),
CSShotX:    .fill 3             ; pixel

; shapes (InitShapes)
RowsLeft:   .fill 128           ; rows from kernel pointer p (0: not inside a shape)
Shift:      .fill 128           ; sprite left = positioned x + Shift
ShapeN:     .fill 8             ; rows
ShapeW:     .fill 8             ; width in pixels
MBuf:       .fill 16
RelBuf:     .fill 16
imgB2:      .byte 0
ShapeImg:   .fill 512           ; the images, copied into the sprite blocks
TitleChars: .fill 512

; render
MAXOBJ      = 40
showMode:   .byte 0
scrBase:    .word 0
chrBase:    .word 0
bkc:        .byte 0             ; the background's C64 colour
shotChr:    .byte 0
pixMask:    .byte 0
ScrMode:    .fill 2, $ff        ; per buffer: what its screen holds (1 game, 2 copyright)
ShotN:      .fill 2             ; per buffer: screen cells with shots (6 each)
ShotLo:     .fill 12
ShotHi:     .fill 12
R2N:        .fill 2             ; ... and row 2 character lines with shots
R2Lo:       .fill 12
R2Hi:       .fill 12
ScKeyType:  .fill 2, $ff        ; per buffer: the score its characters show
ScKey:      .fill 40
ScVer:      .fill 2, $ff        ; ... and the CScoreVer it was made for
aStr:       .byte 0
aCur:       .byte 0
aEndS:      .byte 0
sRas:       .byte 0
sType:      .byte 0
sArg:       .byte 0
sBase:      .byte 0
sOfs:       .byte 0
sChg:       .byte 0
sReg:       .byte 0
sN:         .byte 0
sRow:       .fill 5
sLit:       .fill 5
sQ:         .fill 4
nObj:       .byte 0
StrBeg:     .fill 4
StrEnd:     .fill 4
OTop:       .fill MAXOBJ        ; objects: first line,
OVis:       .fill MAXOBJ        ; last visible line,
OX:         .fill MAXOBJ        ; sprite X (2600 pixel + 32),
OBlk:       .fill MAXOBJ        ; block,
OCol:       .fill MAXOBJ        ; C64 colour
sprUsed:    .byte 0
SprBusy:    .fill 8             ; a sprite's last use: busy until, last visible line
SprVis:     .fill 8
aObj:       .byte 0
aBest:      .byte 0
aBestVis:   .byte 0
aX:         .byte 0
aMsb:       .byte 0
aEnt:       .byte 0
aIdx:       .byte 0
aEnd:       .byte 0
aShape:     .byte 0
aRefl:      .byte 0
pK:         .byte 0
dTmp:       .byte 0
kOfs:       .byte 0
pR:         .byte 0
pIdx:       .byte 0
DynKey:     .fill 10 * 2 * NDYN, $ff  ; per dynamic block: rows, then what they were made from
schedN:     .byte 0
reN:        .byte 0

; staged frames (two buffers): sprites' first uses, colours ...
StX:        .fill 16
StY:        .fill 16
StPtr:      .fill 16
StCol:      .fill 16
StMsb:      .fill 2
StEn:       .fill 2
StBg:       .fill 2
StD018:     .fill 2, D018_0
StD022:     .fill 2
StD023:     .fill 2
FlD022:     .fill 2             ; the field's shot colours
FlD023:     .fill 2
; ... sprite reuses (32 per buffer), and the schedule
RNum:       .fill 64
RX:         .fill 64
RMsb:       .fill 64
RY:         .fill 64
RPtr:       .fill 64
RCol:       .fill 64
SchedRas:   .fill 2 * NSCHED
SchedType:  .fill 2 * NSCHED
SchedArg:   .fill 2 * NSCHED

; ======================================================= the 2600 program
; The original 8K ROM, copied at start-up: bank 0 to $D000, bank 1 to $F000, with these changes:
;   $D57E  JMP KernelHook        stop where the 2600 would draw the picture
;   $DB66  JMP TitleHook         ... and a frame of the copyright screen
;   $DB55, $DB57, $DB5F, $DB74,  VBLANK / VSYNC writes go to $03 instead (writing $00 / $01
;   $F31D, $F31F, $F327, $F329   ... would remap the C64's memory)
;   $DFF0, $FFF0  JMP ($F7)      bank switches: both banks are in memory (was STA $FFF9 / $FFF8)
;   $F002, $F9DE  NOP            (was TXS: keep the C64's stack)
;   $F9DA  NOP                   (was SEI: keep our interrupts)
;   $F9E1  JSR ClearZP           clear the 2600 RAM, not the C64's zero page
ROM = "../build/original.a26"     ; extracted from roms_port by build.cmd
GameImage:
        .binary ROM, $0000, $057e
        jmp KernelHook
        .binary ROM, $0581, $0b56-$0581
        .byte $03
        .binary ROM, $0b57, 1
        .byte $03
        .binary ROM, $0b59, $0b60-$0b59
        .byte $03
        .binary ROM, $0b61, $0b66-$0b61
        jmp TitleHook
        .binary ROM, $0b69, $0b75-$0b69
        .byte $03
        .binary ROM, $0b76, $0ff0-$0b76
        jmp ($00f7)
        .binary ROM, $0ff3, $1002-$0ff3
        nop
        .binary ROM, $1003, $131e-$1003
        .byte $03
        .binary ROM, $131f, 1
        .byte $03
        .binary ROM, $1321, $1328-$1321
        .byte $03
        .binary ROM, $1329, 1
        .byte $03
        .binary ROM, $132b, $19da-$132b
        nop
        .binary ROM, $19db, $19de-$19db
        nop
        .binary ROM, $19df, $19e1-$19df
        jsr ClearZP
        nop
        nop
        .binary ROM, $19e6, $1ff0-$19e6
        jmp ($00f7)
        .binary ROM, $1ff3, $2000-$1ff3
        .cerror * - GameImage != $2000, "the 2600 image must be 8K"
