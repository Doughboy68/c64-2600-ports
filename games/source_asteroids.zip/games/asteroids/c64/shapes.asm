; ============================================================ start-up
; Sprite images and characters made from the game's own graphics (so no game data is in
; this program). InitShapes and InitTitle run while all RAM is visible (bank 0 is under
; the I/O area); InitChars and CopyShapes put the results into video memory.

; The eight asteroid shapes. Shape s is the 16 bytes at $10 * s in the motion page ($DE00:
; HMP in the high nibble, NUSIZ in the low; 0 ends the shape) and the graphics page ($DF00).
; The kernel applies a row's motion at the HMOVE that starts the row, so row r is drawn at
; x - (m0 + .. + mr), single or double width. Baked into one sprite image per shape; for each
; starting offset p (= $10 * s + k, the kernel's pointer) the tables give the rows from there
; (RowsLeft, 0 if p isn't inside a shape) and where the image goes for an asteroid drawn
; from row k: sprite left = its positioned x + Shift (the kernel moves row k by mk, and row
; k sits at its offset in the image).
InitShapes:
        ldx #127
        lda #0
-       sta RowsLeft,x
        dex
        bpl -
        ldx #0
_shape  stx v0
        txa
        asl
        asl
        asl
        asl
        sta v1                  ; base
        lda #0
        sta tmp                 ; rel (x of the row, relative to the positioned x)
        sta tmp2                ; the smallest rel
        lda #$7f
        sta tmp2
        ldy #0
_r      cpy #16
        bcs _end
        tya
        clc
        adc v1
        tax
        lda MovePage,x
        beq _end
        lsr                     ; m: the signed high nibble (left is positive)
        lsr
        lsr
        lsr
        eor #8
        sec
        sbc #8
        sta MBuf,y
        eor #$ff                ; rel -= m
        sec
        adc tmp
        sta tmp
        sta RelBuf,y
        sec                     ; signed: rel < smallest?
        sbc tmp2
        bvc +
        eor #$80
+       bpl +
        lda tmp
        sta tmp2
+       iny
        bne _r
_end    sty v2                  ; rows
        ldx v0
        tya
        sta ShapeN,x
        lda #0
        sta ShapeW,x
        lda v0                  ; image: ShapeImg + 64 * s
        lsr
        lsr
        sta ptrB+1
        lda v0
        ror
        ror
        ror
        and #$c0
        sta ptrB
        lda ptrB+1
        clc
        adc #>ShapeImg
        sta ptrB+1
        lda ptrB
        clc
        adc #<ShapeImg
        sta ptrB
        bcc +
        inc ptrB+1
+       ldy #0                  ; row r
_img    cpy v2
        bcc +
        jmp _next
+
        sty tmp3
        lda RelBuf,y            ; offset in the image
        sec
        sbc tmp2
        sta tmp4
        tya
        clc
        adc v1
        tax                     ; p = base + r
        lda v2                  ; rows from here
        sec
        sbc tmp3
        sta RowsLeft,x
        lda MBuf,y              ; Shift = -m - offset
        clc
        adc tmp4
        eor #$ff
        clc
        adc #1
        sta Shift,x
        ldy GfxPage,x           ; the row's bits: double width?
        lda MovePage,x
        and #7
        cmp #5
        bne _single
        lda DblHi,y
        sta ptrC
        lda DblLo,y
        sta ptrC+1
        lda #16
        bne _shift
_single sty ptrC
        lda #0
        sta ptrC+1
        lda #8
_shift  clc
        adc tmp4
        ldx v0
        cmp ShapeW,x
        bcc +
        sta ShapeW,x
+       cmp #25
        bcc +
        inc DbgWide             ; (doesn't happen: a row wider than a sprite)
+       lda #0
        sta imgB2            ; (third byte)
        ldx tmp4
        beq _store
-       lsr ptrC
        ror ptrC+1
        ror imgB2
        dex
        bne -
_store  lda tmp3                ; row r at 3 * r
        asl
        adc tmp3
        tay
        lda ptrC
        sta (ptrB),y
        iny
        lda ptrC+1
        sta (ptrB),y
        iny
        lda imgB2
        sta (ptrB),y
        ldx v0
        lda ShapeN,x
        sta v2
        ldy tmp3
        iny
        jmp _img
_next   ldx v0
        inx
        cpx #8
        beq +
        jmp _shape
+       rts

; "(c) 1981 Atari, Inc.": six 8-pixel columns of 26 lines from page $DA (column c at 26 * c,
; the bottom line first), drawn from 2600 pixel 54 on lines 124-149 (as tools/model.js finds).
; As multicolour characters ("10" pixels): screen rows 11-14, columns 13-25.
TITLEX      = 54
TITLETOP    = 124
TITLECOL    = 13
TITLEROW    = 11
NTITLE      = 13
InitTitle:
        ldx #0
        txa
-       sta TitleChars,x
        sta TitleChars+256,x
        inx
        bne -
        lda #0
        sta v0                  ; column c
_col    lda #0
        sta v1                  ; line i
_line   lda v0                  ; the byte: TitlePage + 26 * c + i
        asl
        sta tmp
        asl
        asl
        adc tmp                 ; 10 * c
        sta tmp
        lda v0
        asl
        asl
        asl
        asl
        adc tmp                 ; 26 * c
        adc v1
        tax
        lda TitlePage,x
        sta tmp4
        lda #TITLETOP + 25 - 30 ; its row position: line 124 + 25 - i, less 30
        sec
        sbc v1
        sta tmp3
        lda v0                  ; x of its first pixel
        asl
        asl
        asl
        adc #TITLEX
        sta tmp2
        ldy #8
-       asl tmp4
        bcc +
        jsr _pixel
+       inc tmp2
        dey
        bne -
        inc v1
        lda v1
        cmp #26
        bne _line
        inc v0
        lda v0
        cmp #6
        bne _col
        rts
_pixel  sty v2                  ; set pixel (tmp2, row position tmp3)
        lda tmp3                ; character: (row - 11) * 13 + (x / 4 - 13)
        lsr
        lsr
        lsr
        sec
        sbc #TITLEROW
        sta tmp
        asl
        adc tmp                 ; * 3
        asl
        asl                     ; * 12
        adc tmp                 ; * 13
        sta tmp
        lda tmp2
        lsr
        lsr
        sec
        sbc #TITLECOL
        clc
        adc tmp                 ; character n (0-51): at TitleChars + 8 * n + line
        sta tmp
        lsr
        lsr
        lsr
        lsr
        lsr
        sta ptrC+1
        lda tmp
        asl
        asl
        asl
        sta ptrC
        lda tmp3
        and #7
        ora ptrC
        sta ptrC
        lda #<TitleChars
        clc
        adc ptrC
        sta ptrC
        lda #>TitleChars
        adc ptrC+1
        sta ptrC+1
        lda tmp2
        and #3
        tax
        ldy #0
        lda (ptrC),y
        ora TitleBit,x
        sta (ptrC),y
        ldy v2
        rts
TitleBit:   .byte $80, $20, $08, $02    ; "10" in multicolour pixel 0-3

; Both character sets: the mask (black), the copyright text, and the black HMOVE blank in
; screen row 2's field lines (2600 lines 50-53, columns 0-1).
InitChars:
        lda #<CHARS0
        ldx #>CHARS0
        jsr _set
        lda #<CHARS1
        ldx #>CHARS1
_set    sta ptrB
        stx ptrB+1
        ldy #8 * CH_MASK
-       lda #$ff
        sta (ptrB),y
        iny
        cpy #8 * CH_MASK + 8
        bne -
        lda ptrB                ; screen row 2, columns 0-1: lines 4-7
        clc
        adc #<(8 * CH_SCORE2)
        sta ptrC
        lda ptrB+1
        adc #>(8 * CH_SCORE2)
        sta ptrC+1
        ldy #4
        jsr _mask4
        ldy #12
        jsr _mask4
        lda ptrB+1              ; title characters at CH_TITLE (8 * 128 = $400 on)
        clc
        adc #4
        sta ptrC+1
        lda ptrB
        sta ptrC
        ldy #0
-       lda TitleChars,y
        sta (ptrC),y
        lda TitleChars+256,y
        inc ptrC+1
        sta (ptrC),y
        dec ptrC+1
        iny
        bne -
        rts
_mask4  ldx #4
        lda #$ff
-       sta (ptrC),y
        iny
        dex
        bne -
        rts

; The asteroid images into their sprite blocks.
CopyShapes:
        ldx #0
-       lda ShapeImg,x
        sta SPRDATA + 64 * (BLK_SHAPE - SPRBASE),x
        lda ShapeImg+256,x
        sta SPRDATA + 64 * (BLK_SHAPE - SPRBASE) + 256,x
        inx
        bne -
        rts
