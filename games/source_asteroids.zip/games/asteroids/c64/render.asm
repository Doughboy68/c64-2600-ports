; ================================================================= render
; Draw the last capture into the frame buffer the display isn't using (screen, character
; set, sprite values, raster schedule), then hand it over (pending).
;
; Flicker on (the 2600's way): the asteroids or the ship frame, whichever the last tick
; drew. Off: both, each as last captured.
;
; Sprites are given out in screen order from a pool per kind of object (player 0's objects
; get the lower numbers, which the VIC draws in front, as the 2600 draws player 0 over
; player 1). A sprite is used again further down when its last use has finished: a
; Y-expanded sprite starts again only SPRBUSY lines after its last start (see below), and the
; interrupt that moves it must
; come after its last visible line. What can't be placed is dropped (DbgDrop).
; The VIC-II turns a sprite's DMA off in cycle 16 of the line after its last (the 42nd, Y-
; expanded), and looks for a new start in cycle 55: a sprite that started showing on line L
; can show again from L + 43 on, not L + 42 (then it would be skipped for the whole frame,
; which the asteroids' 21-row spacing from the second wave on hit every frame). One line spare.
SPRBUSY     = 44
; The interrupt that moves a sprite comes after the last use's last visible line, and at least
; SPRLEAD lines before the new use's first (several can queue, badlines slow them down: a move
; written too late is skipped by the VIC for the whole frame), at most SPREARLY lines before.
; Early is safe: what the VIC still shows of the last use then (rows 16-20) is blank in every image.
SPRLEAD     = 6
SPREARLY    = 12
        .cerror SPRBUSY - SPREARLY < 32, "a move that early would show the new image's rows"

Render:
        lda pending             ; the last frame hasn't been shown yet
        beq +
        rts
+       lda curBuf
        eor #1
        sta rbuf
        tax
        lda #0
        sta StEn,x
        sta StMsb,x
        sta sprUsed
        sta schedN
        sta reN
        lda BufD018,x
        sta StD018,x
        lda SchedBase,x         ; schedule: entry 0 is the frame top
        tay
        lda #TOPRASTER
        sta SchedRas,y
        lda #S_TOP
        sta SchedType,y
        lda ScrLo,x             ; this buffer's screen and characters
        sta scrBase
        lda ScrHi,x
        sta scrBase+1
        lda ChrLo,x
        sta chrBase
        lda ChrHi,x
        sta chrBase+1
        lda LastType
        cmp #2
        bne _game
        ldx rbuf
        lda #0
        sta BufShow,x
        jsr TitleFrame
        jmp _end
_game   lda #3                  ; what to show: 1 asteroids, 2 ship frame, 3 both
        ldx Flicker
        beq +
        ldx LastType
        lda ShowMode,x
+       sta showMode
        ldx rbuf                ; (testing aid: what each buffer shows)
        sta BufShow,x
        jsr GameScreen
        lda showMode
        and #2
        beq +
        jsr Shots
+       jsr Objects
        lda #FIELDRASTER
        ldx #S_FIELD
        ldy #0
        jsr SchedAdd
_end    lda #ENDRASTER
        ldx #S_END
        ldy #0
        jsr SchedAdd
        lda #1
        sta pending
        rts
ShowMode:   .byte 1, 2          ; flicker on: asteroid frame, ship frame

; Add a schedule entry (A raster, X type, Y argument), keeping them in raster order.
SchedAdd:
        sta sRas
        stx sType
        sty sArg
        lda schedN
        cmp #NSCHED - 2
        bcc +
        inc DbgSched            ; (full)
        rts
+       ldx rbuf
        lda SchedBase,x
        sta sBase
        clc
        adc schedN
        tax                     ; the last entry so far
-       cpx sBase
        beq _put
        lda SchedRas,x
        cmp sRas
        bcc _put
        beq _put
        lda SchedRas,x          ; move it down one
        sta SchedRas+1,x
        lda SchedType,x
        sta SchedType+1,x
        lda SchedArg,x
        sta SchedArg+1,x
        dex
        jmp -
_put    lda sRas
        sta SchedRas+1,x
        lda sType
        sta SchedType+1,x
        lda sArg
        sta SchedArg+1,x
        inc schedN
        rts

; ---------------------------------------------------------------- the copyright screen
TitleFrame:
        ldx rbuf
        lda ScrMode,x
        cmp #2
        beq +
        lda #2
        sta ScrMode,x
        jsr ClearScreen
        ldx #TITLEROW           ; the text's characters
        lda #CH_TITLE
        sta tmp
-       jsr RowPtr
        ldy #TITLECOL
-       lda tmp
        sta (ptrA),y
        inc tmp
        iny
        cpy #TITLECOL + NTITLE
        bne -
        inx
        cpx #TITLEROW + 4
        bne --
+       ldx rbuf
        lda #0
        sta StBg,x
        sta StD022,x
        lda #$44 >> 1
        tay
        lda ColorMap,y
        sta StD023,x
        rts

; ptrA = this buffer's screen row X
RowPtr:
        lda scrBase
        clc
        adc RowOfsLo,x
        sta ptrA
        lda scrBase+1
        adc RowOfsHi,x
        sta ptrA+1
        rts

ClearScreen:
        lda scrBase
        sta ptrA
        lda scrBase+1
        sta ptrA+1
        ldx #4
        ldy #0
        tya
-       sta (ptrA),y
        iny
        bne -
        inc ptrA+1
        dex
        bne -
        lda #BLK_BLANK          ; (the sprite pointers at its end)
        ldy #$f8
        dec ptrA+1
-       sta (ptrA),y
        iny
        bne -
        rts

; ---------------------------------------------------------------- the game's screen
; Row 0 empty; rows 1-2 one character per column (the score band, and in row 2 the field's
; first lines); rows 3-24 the field: columns 0-1 the black HMOVE blank, the rest empty or shots.
GameScreen:
        ldx rbuf
        lda ScrMode,x
        cmp #1
        beq _built
        lda #1
        sta ScrMode,x
        lda #0
        sta ShotN,x
        sta R2N,x
        lda #$ff                ; (score characters to be made)
        sta ScKeyType,x
        jsr ClearScreen
        ldx #1                  ; rows 1 and 2: a character per column
        jsr RowPtr
        ldy #0
-       tya
        clc
        adc #CH_SCORE1
        sta (ptrA),y
        iny
        cpy #40
        bne -
        ldx #2
        jsr RowPtr
        ldy #0
-       tya
        clc
        adc #CH_SCORE2
        sta (ptrA),y
        iny
        cpy #40
        bne -
        ldx #3
-       jsr RowPtr
        ldy #0
        lda #CH_MASK
        sta (ptrA),y
        iny
        sta (ptrA),y
        inx
        cpx #25
        bne -
_built  jsr ClearShots
        jsr ScoreChars
        ldx rbuf
        lda CBk                 ; colours
        lsr
        tay
        lda ColorMap,y
        sta StBg,x
        sta bkc
        lda CScoreCol
        lsr
        tay
        lda ColorMap,y
        sta StD023,x
        lda #0
        sta StD022,x
        lda CSCol+1             ; the field: shots in the UFO's colour ("01": M1, behind the
        lsr                     ; sprites) and the ship's ("10": M0 and the ball, in front)
        tay
        lda ColorMap,y
        sta FlD022,x
        lda CSCol
        lsr
        tay
        lda ColorMap,y
        sta FlD023,x
        rts

; ---------------------------------------------------------------- score band
; Characters CH_SCORE1 + column (lines 38-45: score rows 4, 3, 2 from line 40) and
; CH_SCORE2 + column (lines 46-49: rows 1 and 0; lines 50-53 are the field). Each lit
; playfield cell is "10" ($D023, the score's colour) across the character. Only the columns
; of the registers whose bytes changed are made again. Line 49 has two timing quirks: on
; asteroid frames pixel 79 already shows the right half's PF2 bit 7; on ship frames PF2 is
; cleared from pixel 151, so cell 37 loses its last pixel and cells 38-39 go dark.
ScoreChars:
        ldx rbuf
        lda CScoreVer           ; (nothing new captured, the same frame type: nothing to do)
        cmp ScVer,x
        bne +
        lda LastType
        cmp ScKeyType,x
        bne +
        rts
+       lda CScoreVer
        sta ScVer,x
        lda Mul20,x
        sta sOfs                ; this buffer's key: the 20 bytes it shows
        lda #0
        sta sChg                ; bit g: register g changed (0 PF0, 1 PF1, 2 PF2, 3 right PF2)
        lda LastType
        cmp ScKeyType,x
        beq +
        sta ScKeyType,x
        lda #$80                ; (only line 49's quirks change)
        sta sChg
+       ldy #0                  ; Y = 4 * row + register
_key    tya
        clc
        adc sOfs
        tax
        lda CScore,y
        cmp ScKey,x
        beq _same
        sta ScKey,x
        tya
        and #3
        tax
        lda Bit,x
        ora sChg
        sta sChg
_same   iny
        cpy #20
        bne _key
        lda sChg
        bne +
        rts
+       ldx #0
-       lda sChg
        and Bit,x
        beq +
        stx sReg
        jsr ScoreReg
        ldx sReg
+       inx
        cpx #4
        bne -
        ; line 49 (character CH_SCORE2 + column, line 3) of columns 19, 37-39: lit from row 0
        ; (PF2 bit 7, right PF2 bits 5-7), then the frame type's quirk
        lda CScore+2
        and #$80
        jsr _lit
        sta sQ
        lda CScore+3
        and #$20
        jsr _lit
        sta sQ+1
        lda CScore+3
        and #$40
        jsr _lit
        sta sQ+2
        lda CScore+3
        and #$80
        jsr _lit
        sta sQ+3
        lda LastType
        bne _ship
        lda sQ                  ; asteroid frames: pixel 79 shows the right half's bit 7
        and #$fc
        sta sQ
        lda sQ+3
        and #$03
        ora sQ
        sta sQ
        jmp _put
_ship   lda sQ+1                ; ship frames: PF2 cleared from pixel 151
        and #$fc
        sta sQ+1
        lda #0
        sta sQ+2
        sta sQ+3
_put    ldx #3
-       lda QuirkChar,x
        jsr _chr
        lda sQ,x
        ldy #3
        sta (ptrA),y
        dex
        bpl -
        rts
_lit    beq +                   ; Z clear -> $AA
        lda #$aa
+       rts
_chr    sta ptrA                ; ptrA = character A
        lda #0
        asl ptrA
        rol
        asl ptrA
        rol
        asl ptrA
        rol
        sta ptrA+1
        lda ptrA
        clc
        adc chrBase
        sta ptrA
        lda ptrA+1
        adc chrBase+1
        sta ptrA+1
        rts
QuirkChar:  .byte CH_SCORE2 + 19, CH_SCORE2 + 37, CH_SCORE2 + 38, CH_SCORE2 + 39

; Make the characters of register sReg's columns: each lit cell is "10" ($D023) across.
; CH_SCORE1 + column: lines 0-1 empty, 2-3 row 4, 4-5 row 3, 6-7 row 2;
; CH_SCORE2 + column: lines 0-1 row 1, 2-3 row 0 (4-7: the field).
ScoreReg:
        ldy sReg                ; the five rows' bytes: sRow + row
        ldx #0
-       lda CScore,y
        sta sRow,x
        tya
        clc
        adc #4
        tay
        inx
        cpx #5
        bne -
        lda sReg                ; PF0: bits 4-7
        bne +
        ldx #4
-       lsr sRow,x
        lsr sRow,x
        lsr sRow,x
        lsr sRow,x
        dex
        bpl -
+       ldx sReg
        lda RegFirst,x
        pha
        clc
        adc #CH_SCORE2
        jsr ScoreChars._chr
        lda ptrA
        sta ptrB
        lda ptrA+1
        sta ptrB+1
        pla
        clc
        adc #CH_SCORE1
        jsr ScoreChars._chr
        lda RegCells,x
        sta sN
_cell   ldx #4                  ; this cell's bit of each row: Lit5 + row
-       lda sReg
        cmp #1
        bne +
        asl sRow,x              ; PF1: bit 7 first
        jmp ++
+       lsr sRow,x              ; the others: bit 0 first
+       lda #0
        bcc +
        lda #$aa
+       sta sLit,x
        dex
        bpl -
        ldy #0
        tya
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        lda sLit+4
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        lda sLit+3
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        lda sLit+2
        sta (ptrA),y
        iny
        sta (ptrA),y
        ldy #0
        lda sLit+1
        sta (ptrB),y
        iny
        sta (ptrB),y
        iny
        lda sLit
        sta (ptrB),y
        iny
        sta (ptrB),y
        lda ptrA                ; next column
        clc
        adc #8
        sta ptrA
        bcc +
        inc ptrA+1
+       lda ptrB
        clc
        adc #8
        sta ptrB
        bcc +
        inc ptrB+1
+       dec sN
        bne _cell
        rts
RegFirst:   .byte 0, 4, 12, 32  ; each register's first column and columns
RegCells:   .byte 4, 8, 8, 8

; ---------------------------------------------------------------- shots
; Undo the last frame's shots in this buffer: screen cells back to empty, row 2's lines cleared.
ClearShots:
        ldx rbuf
        lda ShotN,x
        beq _r2
        sta tmp
        lda Mul6,x
        tax
-       lda ShotLo,x
        sta ptrA
        lda ShotHi,x
        sta ptrA+1
        ldy #0
        tya
        sta (ptrA),y
        inx
        dec tmp
        bne -
        ldx rbuf
        lda #0
        sta ShotN,x
_r2     lda R2N,x
        beq _done
        sta tmp
        lda Mul6,x
        tax
-       lda R2Lo,x
        sta ptrA
        lda R2Hi,x
        sta ptrA+1
        ldy #0
        tya
        sta (ptrA),y
        inx
        dec tmp
        bne -
        ldx rbuf
        lda #0
        sta R2N,x
_done   lda #CH_SHOT
        sta shotChr
        rts

; Each shot: one pixel on two lines, in characters. The 2600 draws player 0 and missile 0 over
; player 1 and missile 1, over the ball. M1 (the ship's second shot, in the UFO's colour) is
; "01", behind the sprites, so the ship covers it; M0 and the ball (the UFO's shot), in the
; ship's colour, are "10", in front: right for M0, but the UFO's shot shows over the UFO where
; they meet (on the 2600 the UFO covers it). Drawn ball, M1, M0, each replacing the pixel.
; Pixels 0-7 are under the HMOVE blank.
Shots:
        ldx #2
_shot   lda CSShotLine,x
        beq _next
        sta v0
        lda CSShotX,x
        cmp #8
        bcc _next
        lsr
        lsr
        sta v1                  ; column
        lda CSShotX,x
        and #3
        tay
        lda PixMask,y
        sta pixMask
        and ShotPat,x
        sta v2                  ; the pixel's bits
        stx tmp4
        jsr _pix
        inc v0
        jsr _pix
        ldx tmp4
_next   dex
        bpl _shot
        rts
_pix    lda v0                  ; line - 30: screen row and line in the character
        sec
        sbc #30
        tay
        and #7
        sta tmp3
        tya
        lsr
        lsr
        lsr
        tax
        cpx #2
        bne _field
        lda v1                  ; row 2: its own character per column
        clc
        adc #CH_SCORE2
        jsr _addr
        ldx rbuf                ; (cleared next time)
        lda R2N,x
        cmp #6
        bcs +
        inc R2N,x
        adc Mul6,x
        tax
        lda ptrA
        sta R2Lo,x
        lda ptrA+1
        sta R2Hi,x
+       jmp _or
_field  jsr RowPtr
        ldy v1
        lda (ptrA),y
        bne _have
        lda shotChr             ; an empty cell: a fresh shot character
        cmp #CH_SHOT + 6
        bcs _skip
        inc shotChr
        sta (ptrA),y
        pha
        tya                     ; remember the cell
        clc
        adc ptrA
        sta tmp
        lda ptrA+1
        adc #0
        sta tmp2
        ldx rbuf
        lda ShotN,x
        inc ShotN,x
        clc
        adc Mul6,x
        tax
        lda tmp
        sta ShotLo,x
        lda tmp2
        sta ShotHi,x
        pla
        pha
        jsr _addr0              ; clear it
        ldy #7
        lda #0
-       sta (ptrA),y
        dey
        bpl -
        pla
        bne _chr
_have   cmp #CH_SHOT            ; (another shot's character, or not ours to change)
        bcc _skip
        cmp #CH_SHOT + 6
        bcs _skip
_chr    jsr _addr
_or     ldy #0
        lda pixMask
        eor #$ff
        and (ptrA),y
        ora v2
        sta (ptrA),y
_skip   rts
_addr   jsr _addr0              ; ptrA = character A, line tmp3
        lda ptrA
        clc
        adc tmp3
        sta ptrA
        bcc +
        inc ptrA+1
+       rts
_addr0  sta ptrA
        lda #0
        asl ptrA
        rol
        asl ptrA
        rol
        asl ptrA
        rol
        sta ptrA+1
        lda ptrA
        clc
        adc chrBase
        sta ptrA
        lda ptrA+1
        adc chrBase+1
        sta ptrA+1
        rts
PixMask:    .byte $c0, $30, $0c, $03
Mul20:      .byte 0, 20
ShotPat:    .byte $aa, $55, $aa
Mul6:       .byte 0, 6

; ---------------------------------------------------------------- sprites
; Objects in four streams, each in screen order: player 0's asteroids, player 1's, the ship's
; parts, the UFO's. Each object: first line, last visible line, sprite X (2600 pixel + 32),
; block, colour. Each stream has its own sprites, so each is given them in its own order.
Objects:
        lda #0
        sta nObj
        ldx #0
_str    stx v0                  ; stream
        lda nObj
        sta StrBeg,x
        lda showMode
        and StreamShow,x
        beq _done
        cpx #2
        bcs _ship
        jsr AstStream
        jmp _done
_ship   jsr ShipStream
_done   ldx v0
        lda nObj
        sta StrEnd,x
        inx
        cpx #4
        bne _str
        ; each stream's objects in screen order, from the stream's own pool of sprites
        ldy #0
_strm   sty aStr
        lda showMode
        asl
        asl
        ora aStr
        tax
        lda PoolLo,x
        sta v1
        lda PoolHi,x
        sta v2
        lda StrEnd,y
        sta aEndS
        ldx StrBeg,y
_obj    cpx aEndS
        bcs _nexts
        stx aCur
        jsr Allocate
        ldx aCur
        inx
        jmp _obj
_nexts  ldy aStr
        iny
        cpy #4
        bne _strm
        ldx rbuf                ; the sprites used
        lda sprUsed
        sta StEn,x
        rts
StreamShow: .byte 1, 1, 2, 2
; pools (first, last sprite) by show mode (1 asteroids, 2 ship frame, 3 both) and stream; with
; both, the ship and the UFO (given theirs last) take whatever the asteroids left
PoolLo:     .byte 0, 0, 0, 0,  0, 4, 0, 0,  0, 0, 0, 4,  0, 4, 0, 0
PoolHi:     .byte 0, 0, 0, 0,  3, 7, 0, 0,  0, 0, 3, 7,  3, 7, 7, 7

; Give object X a sprite from v1..v2.
Allocate:
        stx aObj
        lda #$ff
        sta aBest
        sta aBestVis
        ldy v1
_try    lda sprUsed
        and Bit,y
        bne _used
        sty aBest               ; unused: take it
        jmp _take
_used   ldx aObj                ; reuse: its last use over (SPRBUSY), and room for the interrupt
        lda OTop,x
        cmp SprBusy,y
        bcc _no
        sec
        sbc #SPRLEAD + 1
        bcc _no
        cmp SprVis,y
        bcc _no
        sty aBest
        jmp _take
_no     iny
        cpy v2
        beq _try
        bcc _try
        lda aBest
        cmp #$ff
        bne _take
        inc DbgDrop
        rts
_take   ldx aObj
        lda OX,x                ; X register: 2 * xs - 40 (9 bits)
        asl
        sta aX
        lda #0
        rol
        sta aMsb
        lda aX
        sec
        sbc #40
        sta aX
        lda aMsb
        sbc #0
        sta aMsb
        ldy aBest
        lda sprUsed
        and Bit,y
        bne _reuse
        lda sprUsed             ; the sprite's first use: set at the frame top
        ora Bit,y
        sta sprUsed
        lda rbuf
        asl
        asl
        asl
        ora aBest
        tay                     ; 8 * buffer + sprite
        lda aX
        sta StX,y
        lda OTop,x
        clc
        adc #SPRY
        sta StY,y
        lda OBlk,x
        sta StPtr,y
        lda OCol,x
        sta StCol,y
        lda aMsb
        bne +
        jmp _mark
+       ldy rbuf
        ldx aBest
        lda StMsb,y
        ora Bit,x
        sta StMsb,y
        jmp _mark
_reuse  lda reN                 ; a reuse further down: staged for the interrupt
        cmp #32
        bcc +
        inc DbgSched
        rts
+       ldy rbuf
        beq +
        lda #32
        clc
        adc reN
+       tay
        inc reN
        sty aEnt
        lda aBest
        sta RNum,y
        lda aX
        sta RX,y
        lda #0
        ldx aMsb
        beq +
        ldx aBest
        lda Bit,x
+       sta RMsb,y
        ldx aObj
        lda OTop,x
        clc
        adc #SPRY
        sta RY,y
        lda OBlk,x
        sta RPtr,y
        lda OCol,x
        sta RCol,y
        ldy aBest               ; when: after the last use's last line, at most SPREARLY lines early
        lda OTop,x
        sec
        sbc #SPREARLY
        cmp SprVis,y
        beq +
        bcs ++
+       lda SprVis,y
        clc
        adc #1
+       clc
        adc #LINE2RAS
        ldx #S_SPR
        ldy aEnt
        jsr SchedAdd
_mark   ldx aObj
        ldy aBest
        lda OTop,x
        clc
        adc #SPRBUSY
        bcc +
        lda #$ff
+       sta SprBusy,y
        lda OVis,x
        sta SprVis,y
        rts

; Add an object: v0 line, A last visible line... (see AstStream / ShipStream): fields in
; tmp (line), tmp2 (rows), tmp3 (X), tmp4 (block), v2 (colour). Rows run to line 229 at most.
AddObj:
        ldx nObj
        cpx #MAXOBJ
        bcs _full
        lda tmp
        sta OTop,x
        lda tmp2
        asl
        clc
        adc tmp
        bcs +
        cmp #230
        bcc ++
+       lda #230
+       sec
        sbc #1
        sta OVis,x
        lda tmp3
        sta OX,x
        lda tmp4
        sta OBlk,x
        lda v2
        sta OCol,x
        inc nObj
        rts
_full   inc DbgDrop
        rts

; C64 colour for 2600 colour A, not the background's
SprColour:
        lsr
        tay
        lda ColorMap,y
        cmp bkc
        bne +
        tay
        lda AltColor,y
+       rts

; Player 0's (v0 = 0) or player 1's (1) asteroids
AstStream:
        lda v0
        beq +
        lda #9
+       sta aIdx
        clc
        ldx v0
        adc CAN,x
        sta aEnd
_obj    lda aIdx
        cmp aEnd
        bcc +
        rts
+       tax
        lda CACol,x
        jsr SprColour
        sta v2
        ldx aIdx
        lda CALine,x
        sta tmp
        lda CARows,x
        sta tmp2
        lda CAX,x
        sta tmp3
        lda CAP,x
        lsr
        lsr
        lsr
        lsr
        sta aShape
        clc
        adc #BLK_SHAPE
        sta tmp4
        lda CAP,x
        and #15
        beq +
        jsr Partial             ; drawn from row k: a copy of the shape from there
+       lda tmp3                ; (a sprite so far left that nothing of it shows: only its copy)
        cmp #20
        bcc +
        jsr AddObj
+       ldx aShape              ; copies where the 2600 wraps the object round the edge:
        lda tmp3
        cmp #32                 ; left of 0: its pixels on the right
        bcs +
        adc #160
        sta tmp3
        jsr AddObj
        jmp _nxt
+       clc
        adc ShapeW,x            ; past pixel 168: its pixels from 8 on, on the left
        bcs +
        cmp #201
        bcc _nxt
+       lda tmp3
        sec
        sbc #160
        cmp #20
        bcc _nxt
        sta tmp3
        jsr AddObj
_nxt    inc aIdx
        jmp _obj

; The shape's image from row k (CAP,x & 15) on, into this buffer's block for the thread
; (made again only when the row or the number of rows changes).
Partial:
        and #15
        sta pK
        lda v0
        clc
        adc #D_PART
        sta pIdx
        jsr DynBlock            ; ptrB = the block, A = its number
        sta tmp4
        lda pIdx
        jsr DynKeyOfs
        lda tmp2
        cmp DynKey,x
        bne +
        ldy aIdx                ; (the object: its kernel pointer)
        lda CAP,y
        cmp DynKey+1,x
        bne +
        rts
+       lda DynKey,x            ; clear the rows drawn last time
        cmp #22
        bcc +
        lda #21
+       sta pR
        asl
        adc pR
        tay
        lda #0
-       dey
        cpy #$ff
        beq +
        sta (ptrB),y
        jmp -
+       lda tmp2
        sta DynKey,x
        ldy aIdx
        lda CAP,y
        sta DynKey+1,x
        lda aShape              ; ptrC = the whole shape's image, at row k
        clc
        adc #BLK_SHAPE - SPRBASE
        jsr BlockAddr
        lda pK
        asl
        adc pK
        clc
        adc ptrC
        sta ptrC
        bcc +
        inc ptrC+1
+       lda tmp2                ; rows * 3 bytes
        asl
        adc tmp2
        sta pR
        ldy #0
-       lda (ptrC),y
        sta (ptrB),y
        iny
        cpy pR
        bne -
        rts

; X = the cache key offset of this buffer's dynamic block A
DynKeyOfs:
        sta dTmp
        lda rbuf
        beq +
        lda #NDYN
+       clc
        adc dTmp
        tax
        lda Mul10,x
        tax
        rts
Mul10:      .for i = 0, i < 2 * NDYN, i += 1
            .byte 10 * i
            .next

; ptrB = this buffer's dynamic block A (0 .. NDYN - 1); A = its block number
DynBlock:
        sta dTmp
        lda rbuf
        beq +
        lda #NDYN
+       clc
        adc dTmp
        adc #BLK_DYN - SPRBASE
        pha
        jsr BlockAddr
        lda ptrC
        sta ptrB
        lda ptrC+1
        sta ptrB+1
        pla
        clc
        adc #SPRBASE
        rts
; ptrC = address of block number A - SPRBASE
BlockAddr:
        sta ptrC+1
        lda #0
        lsr ptrC+1
        ror
        lsr ptrC+1
        ror
        sta ptrC
        lda ptrC+1
        clc
        adc #>SPRDATA
        sta ptrC+1
        rts

; The ship's (v0 = 2) or the UFO's (3) parts
ShipStream:
        lda v0
        sec
        sbc #2
        sta aShape              ; record 0 ship, 1 UFO
        tax
        lda CSCol,x
        jsr SprColour
        sta v2
        lda aShape
        asl
        sta aIdx                ; part 2 * record, then + 1
        jsr _part
        inc aIdx
_part   ldx aIdx
        lda CSSegRows,x
        bne +
        rts
+       sta tmp2
        lda CSSegLine,x
        sta tmp
        ldx aShape
        lda CSX,x
        sta tmp3
        lda CSRefl,x
        and #8
        sta aRefl
        lda aIdx                ; block: D_SHIP + part
        jsr DynBlock
        sta tmp4
        lda aIdx                ; the same rows as last time in this block? (rows, reflection, bytes)
        jsr DynKeyOfs
        stx kOfs
        lda tmp2
        cmp DynKey,x
        bne _new
        lda aRefl
        cmp DynKey+1,x
        bne _new
        lda aIdx
        asl
        asl
        asl
        tay
        lda tmp2
        sta pR
-       lda CSSegData,y
        cmp DynKey+2,x
        bne _new
        inx
        iny
        dec pR
        bne -
        jmp _add
_new    ldx kOfs                ; clear the rows drawn last time (only their first byte is used)
        lda DynKey,x
        cmp #22
        bcc +
        lda #21
+       sta pR
        asl
        adc pR
        tay
        lda #0
-       dey
        dey
        dey
        bmi +
        sta (ptrB),y
        jmp -
+       lda tmp2
        sta DynKey,x
        lda aRefl
        sta DynKey+1,x
        lda #0                  ; the rows (reflected for REFP0), and the key
        sta pR
        ldy #0
_row    lda aIdx
        asl
        asl
        asl
        clc
        adc pR
        tax
        lda CSSegData,x
        pha
        lda kOfs
        clc
        adc pR
        tax
        pla
        sta DynKey+2,x
        ldx aRefl
        beq +
        tax
        lda Reverse,x
+       sta (ptrB),y
        iny
        iny
        iny
        inc pR
        lda pR
        cmp tmp2
        bne _row
_add    ldx aIdx
        lda CSSegRows,x
        sta tmp2
        jmp AddObj
