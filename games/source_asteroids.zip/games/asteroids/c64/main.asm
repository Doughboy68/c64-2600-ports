; Asteroids (Atari 2600, 1981) running on the Commodore 64.
;
; The original 8K program runs almost unchanged: its two 4K banks are copied to the RAM
; at $D000 (bank 0, under the I/O area) and $F000 (bank 1, under the KERNAL), where they
; were written to run, so a bank switch is just the indirect jump the game makes anyway
; (patches: see GameImage at the end). The game's ticks run with all RAM visible ($01 = $34);
; our interrupts switch the I/O in while they run. This file supplies everything the 2600
; hardware used to do:
;
;   - display: the asteroids, the ship and the UFO as sprites, the score band and the shots
;     as multicolour characters, laid out line for line like the 2600 picture (one 2600 pixel
;     = two C64 pixels = one multicolour pixel, one 2600 line = one C64 line). The rules come
;     from tools/model.js, which matches the 2600 pixel for pixel.
;   - input: keyboard and joysticks mapped onto the 2600 joystick and switch ports
;   - sound: the game's TIA sound registers translated to the SID
;
; The 2600 game works out every hit itself (it never reads the TIA's collision registers),
; so the picture is all the C64 code has to produce.
;
; The game's TIA writes land harmlessly in zero page $02-$2C; it reads the TIA at the mirrors
; $30-$3D, where we put the fire buttons. Its RIOT accesses ($0280-$0297) hit plain C64 RAM,
; which we fill in each frame.
;
; Build: build.cmd (64tass -C -a -o build/asteroids-c64.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM
GameMode    = $80
AstY        = $83       ; 18 slots: rows ($E0 ends a list); 0-8 player 0, 9-17 player 1
AstX        = $95       ; 18 X codes
AstType     = $A7       ; 18: colour (bits 0-2), shape (bits 4-6)
FrameCount  = $B9       ; bit 0: asteroid frame
ShipFlags   = $C8
ShipX       = $C9
UfoX        = $D1
UfoY        = $D2
ShotX       = $D3       ; 3: M0, M1, ball
ShotY       = $D6       ; 3
Slot0       = $DC       ; kernel: the threads' current slots
Slot1       = $DD
P0Vector    = $E3       ; kernel: the threads' next routines (low bytes)
P1Vector    = $E5
Pos0        = $E9       ; kernel: X codes being positioned
Pos1        = $EA
Gfx0        = $EB       ; kernel: graphics pointers (the motion pointers $EF/$F1 match them)
Gfx1        = $ED
ScoreDigits = $F6       ; 6: digit offsets in page $DD for the score band

; ------------------------------- 2600 hardware: TIA writes land in zero page
COLUPF      = $08
COLUBK      = $09
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
INPT4       = $3C       ; bit 7 clear: fire (left joystick)
INPT5       = $3D       ; ... (right joystick)
; RIOT
SWCHA       = $0280     ; joysticks (high nibble: left, low nibble: right)
SWCHB       = $0282     ; console switches
INTIM       = $0284     ; timer (kept at 0 so the game never waits)

; ------------------------------------------------ 2600 program addresses
Reset1      = $F9DA     ; power on
AfterKernel = $D586     ; where the game continues after drawing a picture
AfterTitle  = $DBA5     ; ... and after a frame of the copyright screen
DigitPage   = $DD00     ; score digit graphics (playfield bytes)
MovePage    = $DE00     ; asteroid rows: motion (HMP, high nibble) and size (NUSIZ) per row
AstColours  = $DE75     ; asteroid colours, by type & 7
GfxPage     = $DF00     ; asteroid, ship and UFO graphics
TitlePage   = $DA00     ; "(c) 1981 Atari, Inc."

; ------------------------------------------------------------ C64 layout
VICBANK     = $8000     ; the VIC sees $8000-$BFFF (it sees the character ROM at $9000-$9FFF: unused)
SCREEN0     = $8000     ; two screens and two character sets: the frame being shown
SCREEN1     = $8400     ; and the one being drawn
CHARS0      = $8800
CHARS1      = $a000
SPRDATA     = $a800
SPRBASE     = (SPRDATA - VICBANK) / 64
COLRAM      = $D800
D018_0      = $02       ; screen +$0000, characters +$0800
D018_1      = $18       ; screen +$0400, characters +$2000

; characters (multicolour: 00 background, 01 $D022, 10 $D023, 11 colour RAM = black)
CH_BLANK    = 0
CH_MASK     = 1         ; black: the HMOVE blank (2600 pixels 0-7 of every field line)
CH_SHOT     = 2         ; 2-7: shots
CH_SCORE1   = 8         ; 8-47: screen row 1 (lines 38-45), one character per column
CH_SCORE2   = 48        ; 48-87: row 2 (lines 46-53: the score's last rows, the field's first)
CH_TITLE    = 128       ; 128-179: the copyright text (screen rows 11-14, columns 13-25)

; sprite blocks
BLK_BLANK   = SPRBASE
BLK_SHAPE   = SPRBASE + 1           ; 8: the asteroid shapes, whole
BLK_DYN     = SPRBASE + 9           ; per buffer 6: ship (2 parts), UFO (2), partly hidden asteroids (2)
NDYN        = 6
D_SHIP      = 0
D_UFO       = 2
D_PART      = 4
        .cerror SPRDATA + 64 * (BLK_DYN - SPRBASE + 2 * NDYN) > $c000, "sprite blocks overflow"

; 2600 line L is raster L + LINE2RAS: line 229, the field's last, is the display's last
; (raster 250), so the border hides whatever reaches below it. Screen row r covers lines
; 30 + 8r to 37 + 8r. Sprite Y register = raster - 1.
LINE2RAS    = 21
SPRY        = LINE2RAS - 1
TOPRASTER   = 4         ; frame start (in the vertical blank: the 8565 VIC-II shows a grey dot
                        ; where a colour register is written, and nothing is shown here)
FIELDRASTER = 49 + LINE2RAS     ; the line before the field: the shots' colours (handler waits for the next line)
ENDRASTER   = 251       ; frame end (bottom border)

; schedule entry types for the raster interrupt
S_TOP       = 0         ; frame start: all sprites' first uses, colours, character set
S_SPR       = 2         ; reuse a sprite further down
S_FIELD     = 4         ; the field starts: colours for the shots
S_END       = 6         ; frame end
NSCHED      = 40

; ------------------------------------------------------- zero page ($40+)
; $02-$2C take the game's TIA writes and $30-$3D are its TIA reads, so ours start at $40.
        .virtual $40
ptrA        .word ?
ptrB        .word ?
ptrC        .word ?
tmp         .byte ?
tmp2        .byte ?
tmp3        .byte ?
tmp4        .byte ?
frameFlag   .byte ?     ; frames counted by the raster interrupt
frames      .byte ?
isPal       .byte ?
tickAcc     .byte ?
firstTick   .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)
outv        .byte ?, ?, ?       ; SWCHA, INPT4, INPT5 being built
switches    .byte ?     ; SWCHB toggles
curBuf      .byte ?     ; raster interrupt: frame buffer in use (0/1)
pending     .byte ?     ; a new frame is ready in the other buffer
irqIdx      .byte ?
irqTmp      .byte ?
irqPort     .byte ?     ; $01 as the interrupt found it
rbuf        .byte ?     ; render: buffer being drawn
v0          .byte ?
v1          .byte ?
v2          .byte ?
cK          .byte ?     ; capture: the thread's kernel row
cSlot       .byte ?
cCode       .byte ?
cP          .byte ?
cLast       .byte ?
        .cerror * > $80, "zero page overflow"
        .endv

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title, credits and controls.
; (Lower case here: 64tass -a turns it into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " asteroids"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600"
Bas30   .word Bas40, 30
        .null $8f, " programmed by brad stewart"
Bas40   .word Bas50, 40
        .null $8f, " version 1.3"
Bas50   .word Bas60, 50
        .null $8f, " ported by claude and doughboy68"
Bas60   .word Bas70, 60
        .null $8f, " joy port 2 (player 2: port 1)"
Bas70   .word Bas80, 70
        .null $8f, " or a/d-turn w-thrust space-fire"
Bas80   .word Bas90, 80
        .null $8f, " s-hyperspace/shields/flip"
Bas90   .word Bas100, 90
        .null $8f, " f1 or fire-start f2-power off/on"
Bas100  .word Bas110, 100
        .null $8f, " f3-select f7/f8-difficulty (a: ufos)"
Bas110  .word BasEnd, 110
        .null $8f, " f-flicker on/off"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #$ff
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01

        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -

        ; copy the patched 2600 program: bank 0 to $D000-$DFFF (under the I/O: written
        ; with all RAM visible), bank 1 to $F000-$FFFF
        lda #$34
        sta $01
        lda #<GameImage
        sta ptrA
        lda #>GameImage
        sta ptrA+1
        lda #0
        sta ptrB
        lda #$d0
        sta ptrB+1
        ldx #32
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        lda ptrB+1
        cmp #$e0                ; (bank 1 goes to $F000)
        bne +
        lda #$f0
        sta ptrB+1
+       dex
        bne -
        lda #<Nmi               ; our vectors replace the 2600's
        sta $fffa
        lda #>Nmi
        sta $fffb
        lda #<Irq
        sta $fffe
        lda #>Irq
        sta $ffff
        jsr InitShapes          ; (reads the game's graphics: all RAM still visible)
        jsr InitTitle
        lda #$35
        sta $01

        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #0
        sta INTIM
        lda #$80
        sta INPT4
        sta INPT5
        lda #1
        sta firstTick

        jsr InitVideo
        jsr InitSound
        jsr DetectPal
        lda #$ff                ; CIA 2 timer A free-running (testing aid: DbgTime)
        sta $dd04
        sta $dd05
        lda #%00010001
        sta $dd0e

        ldx #0                  ; start the raster interrupt on an empty frame
        stx curBuf
        stx irqIdx
        lda #TOPRASTER
        sta SchedRas
        sta SchedRas+NSCHED
        lda #S_TOP
        sta SchedType
        sta SchedType+NSCHED
        lda #ENDRASTER
        sta SchedRas+1
        sta SchedRas+NSCHED+1
        lda #S_END
        sta SchedType+1
        sta SchedType+NSCHED+1
        lda #TOPRASTER
        sta $d012
        lda #$1b
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

; ================================================================ main loop
MainLoop:
-       lda frameFlag           ; frames since we last got here (set by the raster interrupt)
        beq -
        sei
        lda frameFlag
        ldx #0
        stx frameFlag
        cli
        inc DbgLoops            ; (testing aid: passes, and frames that came late)
        bne +
        inc DbgLoops+1
+       cmp #2
        bcc +
        inc DbgLate
        bne +
        inc DbgLate+1
+       cmp #3                  ; if we fell behind, catch up at most 3 frames
        bcc +
        lda #3
+       sta frames
        jsr DbgTime             ; (testing aid: the most cycles drawing, ticking, both)
        stx dbgT0
        sty dbgT0+1
        lda DbgBorder           ; testing aid: the border shows where the time goes
        beq +
        lda #2
        sta $d020
+       jsr Render              ; draw the state the last tick produced
        jsr ReadInput
        lda PowerReq            ; F2: the power switch
        beq +
        jsr PowerCycle
+       jsr DbgTime
        stx dbgT1
        sty dbgT1+1
        lda dbgT0               ; drawing
        ldx dbgT0+1
        ldy #0
        jsr DbgMax
        lda DbgBorder
        beq _frame
        lda #5
        sta $d020
_frame  lda isPal               ; PAL: 6 game ticks every 5 frames keeps 2600 speed
        beq _ntsc
        lda tickAcc
        clc
        adc #6
        sta tickAcc
-       lda tickAcc
        cmp #5
        bcc _done
        sbc #5
        sta tickAcc
        jsr Tick
        jmp -
_ntsc   jsr Tick
_done   dec frames
        bne _frame
        jsr DbgTime
        lda dbgT1               ; the ticks (from the end of drawing)
        ldx dbgT1+1
        ldy #2
        jsr DbgMax
        lda dbgT0               ; the whole pass
        ldx dbgT0+1
        ldy #4
        jsr DbgMax
        jsr UpdateSound
        lda DbgBorder
        beq +
        lda #0
        sta $d020
+       jmp MainLoop

; Testing aid: CIA 2 timer A counts down freely. DbgTime: dbgNow (and X/Y) = its value.
DbgTime:
-       ldy $dd05
        ldx $dd04
        cpy $dd05
        bne -
        stx dbgNow
        sty dbgNow+1
        rts
; DbgMax: cycles from the time in A/X (low/high) to dbgNow; keep the largest at
; DbgRMax+Y (Y = 0 drawing, 2 ticks, 4 the whole pass).
DbgMax:
        sec                     ; (the timer counts down: start - now)
        sbc dbgNow
        sta dbgTmp
        txa
        sbc dbgNow+1
        sta dbgTmp+1
        cmp DbgRMax+1,y
        bcc _keep
        bne _new
        lda dbgTmp
        cmp DbgRMax,y
        bcc _keep
_new    lda dbgTmp
        sta DbgRMax,y
        lda dbgTmp+1
        sta DbgRMax+1,y
_keep   rts

; One 2600 frame of game logic: the original code from the end of the picture to the
; start of the next one, where it jumps to KernelHook (or TitleHook). All RAM visible
; while it runs (bank 0 is under the I/O area).
Tick:
        lda #$34
        sta $01
        lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp Reset1              ; the very first frame starts at power-on
+       jmp (Resume)

KernelHook:                     ; the game would draw the picture now
        lda #<AfterKernel
        ldx #>AfterKernel
        jsr Capture             ; what to show
        jmp HookBack
TitleHook:                      ; ... a frame of the copyright screen
        lda #<AfterTitle
        ldx #>AfterTitle
        jsr CaptureTitle
HookBack:
        lda #$35
        sta $01
        rts                     ; (returns to whoever called Tick)

; Replaces the 2600's "sta $00,x / inx / bne" clearing loop at power-on (A = 0): clear the
; 2600 RAM, but not the C64's zero page below $80.
ClearZP:
        ldx #$80
-       sta $00,x
        inx
        bne -
        rts

; F2: power off and on. Clear the TIA (our copies of its registers) and start again from the
; game's power-on code; the console switches stay as they are.
PowerCycle:
        lda #0
        sta PowerReq
        ldx #2                  ; the TIA's registers ($02-$2C) and our copies of its reads
-       sta $00,x
        inx
        cpx #$3e
        bne -
        sta INTIM
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        sta INPT5
        lda #1
        sta firstTick
        rts

; =========================================================== interrupts
; Each frame is a short schedule of raster lines (SchedRas/SchedType/SchedArg), built by
; Render into the buffer the display isn't using. At the end of the frame the interrupt
; switches to a newly finished buffer, so a half-drawn frame is never shown. The entries:
;   S_TOP     sprites' first uses, colours, screen and character set
;   S_SPR     reuse a sprite further down the screen
;   S_FIELD   the field starts: the shots' colours
;   S_END     frame end: let the main loop draw the next one
; The game's ticks run with the I/O switched out: the interrupt switches it in.
Irq:
        pha
        lda $01
        sta irqPort
        lda #$35
        sta $01
        txa
        pha
        tya
        pha
        cld                     ; the game uses decimal mode now and then
        lda $d019
        sta $d019
_next   ldx irqIdx
        ldy SchedType,x
        lda IrqJump,y
        sta _jmp+1
        lda IrqJump+1,y
        sta _jmp+2
_jmp    jmp $ffff
_done   inc irqIdx              ; next entry; run it now if its line has passed already
        ldx irqIdx
        lda SchedRas,x
        sta $d012
        sec
        sbc #2
        cmp $d012
        bcc _next
_out    pla
        tay
        pla
        tax
        lda irqPort
        sta $01
        pla
        rti
IrqJump:    .word ITop, ISpr, IField, IEnd

ITop:   inc DbgTops             ; (testing aid)
        ldx curBuf              ; (testing aid: count the asteroid / ship frames shown)
        lda BufShow,x
        tax
        inc DbgShown,x
+       lda curBuf
        asl
        asl
        asl
        sta irqTmp              ; 8 * buffer: staged sprite values
        lda curBuf              ; 40 * buffer: this buffer's schedule, entry 0
        beq +
        lda #NSCHED
+       sta irqIdx
        ldy irqTmp
        ldx #0
-       lda StPtr,y
        sta SPRPTR0,x
        sta SPRPTR1,x
        lda StCol,y
        sta $d027,x
        iny
        inx
        cpx #8
        bne -
        ldy irqTmp
        ldx #0
-       lda StX,y
        sta $d000,x
        lda StY,y
        sta $d001,x
        iny
        inx
        inx
        cpx #16
        bne -
        ldy curBuf
        lda StMsb,y
        sta $d010
        lda StEn,y
        sta $d015
        lda StBg,y
        sta $d021
        sta $d020
        lda StD018,y
        sta $d018
        lda StD022,y
        sta $d022
        lda StD023,y
        sta $d023
        jmp Irq._done

ISpr:   ldy SchedArg,x          ; Y = 32 * buffer + entry
        ldx RNum,y              ; the sprite
        lda RPtr,y
        sta SPRPTR0,x
        sta SPRPTR1,x
        lda RCol,y              ; (only if it changes: see TOPRASTER)
        cmp $d027,x
        beq +
        sta $d027,x
+       lda Bit,x               ; X position bit 8
        eor #$ff
        and $d010
        ora RMsb,y
        sta $d010
        txa
        asl
        tax
        lda RX,y
        sta $d000,x
        lda RY,y
        sta $d001,x
        cmp $d012               ; (testing aid: too late, the raster is on the line before its first)
        beq _late
        bcs +
_late   inc DbgSprLate
+       jmp Irq._done

IField:                         ; (entered on the line before: wait for the field's first line)
        ldy curBuf
        lda $d012
-       cmp $d012
        beq -
        lda FlD022,y
        sta $d022
        lda FlD023,y
        sta $d023
        jmp Irq._done

IEnd:   inc frameFlag           ; frame end: the next interrupt is the frame top
        lda pending             ; a newly finished frame: shown from the next frame top. (Swapped
        beq +                   ; here, just before the main loop draws the next one: at the
        lda curBuf              ; frame top, an NTSC frame's drawing would always just miss it
        eor #1                  ; and every other frame would go undrawn, always the same kind.)
        sta curBuf
        lda #0
        sta pending
+       lda curBuf
        beq +
        lda #NSCHED
+       sta irqIdx
        lda #TOPRASTER
        sta $d012
        jmp Irq._out

Nmi:    rti

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        txa                     ; the SID's pitch depends on the machine's clock
        bne +
        lda #<SidFreqLoN
        sta FreqTab
        lda #>SidFreqLoN
        sta FreqTab+1
+       rts

SPRPTR0     = SCREEN0 + $3f8
SPRPTR1     = SCREEN1 + $3f8

InitVideo:
        lda $dd02               ; VIC bank 2 ($8000)
        ora #3
        sta $dd02
        lda $dd00
        and #$fc
        ora #1
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d01c               ; sprites: one colour,
        lda #$ff
        sta $d017               ; Y-expanded (a 2600 row is 2 lines),
        sta $d01d               ; X-expanded (one 2600 pixel = two C64 pixels),
        sta $d01b               ; behind the characters' foreground (the HMOVE blank)
        lda #$18                ; multicolour characters
        sta $d016
        lda #D018_0
        sta $d018
        lda #0
        sta $d022
        sta $d023

        ldx #0                  ; colour RAM: multicolour, "11" pixels black
        lda #8
-       sta COLRAM,x
        sta COLRAM+$100,x
        sta COLRAM+$200,x
        sta COLRAM+$2e8,x
        inx
        bne -
        lda #<SCREEN0           ; clear the screens, character sets and sprite blocks ($8000-$BFFF)
        sta ptrB
        lda #>SCREEN0
        sta ptrB+1
        ldx #64
        ldy #0
        tya
-       sta (ptrB),y
        iny
        bne -
        inc ptrB+1
        dex
        bne -
        jsr InitChars
        jsr CopyShapes
        lda #BLK_BLANK          ; all sprites blank to start
        ldx #7
-       sta SPRPTR0,x
        sta SPRPTR1,x
        sta StPtr,x
        sta StPtr+8,x
        dex
        bpl -
        rts

InitSound:
        ldx #$18
        lda #0
-       sta $d400,x
        dex
        bpl -
        lda #$0f                ; full volume
        sta $d418
        ldx #5
        lda #$ff
-       sta SndLast,x
        dex
        bpl -
        rts

        .include "input.asm"
        .include "capture.asm"
        .include "render.asm"
        .include "data.asm"
        .cerror * > VICBANK, "the program runs into the video bank"
