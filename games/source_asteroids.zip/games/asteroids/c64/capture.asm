; =========================================================== capture
; The end of a game tick, where the 2600 would draw its picture: work out what that picture
; holds (the rules of tools/model.js) and keep it for Render, one record for asteroid frames
; and one for ship frames (with flicker off, Render shows the last of each). This runs with all
; RAM visible, so it copies what it needs from bank 0 (graphics, digits) as it goes.
; A/X: where the game continues next tick.
Capture:
        sta Resume
        stx Resume+1
        lda COLUBK
        sta CBk
        lda COLUPF
        sta CScoreCol
        jsr CaptureScore
        lda FrameCount
        lsr
        bcc _ship
        lda #0
        sta LastType
        ldx #0
        jsr CaptureThread
        ldx #1
        jmp CaptureThread
_ship   lda #1
        sta LastType
        jmp CaptureShip

CaptureTitle:
        sta Resume
        stx Resume+1
        lda #2
        sta LastType
        rts

; ---------------------------------------------------------------- score band
; Five rows (r = 0 bottom .. 4 top) of playfield bytes: PF0, PF1, PF2 of the left half and
; PF2 of the right half, from the digit offsets $F6-$FB (two digits ORed into PF1 and PF2).
CaptureScore:
        ldx #5                  ; (the same digits as last time: nothing to do)
-       lda ScoreDigits,x
        cmp CScoreKey,x
        bne +
        dex
        bpl -
        rts
+       inc CScoreVer
        ldx #5
-       lda ScoreDigits,x
        sta CScoreKey,x
        dex
        bpl -
        ldy #0                  ; Y = 4 * r
        ldx #0                  ; X = r
_row    stx tmp
        txa
        clc
        adc ScoreDigits
        tax
        lda DigitPage,x
        sta CScore,y            ; PF0
        lda tmp
        clc
        adc ScoreDigits+1
        tax
        lda DigitPage,x
        sta tmp2
        lda tmp
        clc
        adc ScoreDigits+2
        tax
        lda DigitPage,x
        ora tmp2
        sta CScore+1,y          ; PF1
        lda tmp
        clc
        adc ScoreDigits+3
        tax
        lda DigitPage,x
        sta tmp2
        lda tmp
        clc
        adc ScoreDigits+4
        tax
        lda DigitPage,x
        ora tmp2
        sta CScore+2,y          ; PF2
        lda tmp
        clc
        adc ScoreDigits+5
        tax
        lda DigitPage,x
        sta CScore+3,y          ; PF2 of the right half
        iny
        iny
        iny
        iny
        ldx tmp
        inx
        cpx #5
        bne _row
        rts

; ---------------------------------------------------------------- the asteroid field
; One kernel thread (X = 0: player 0, slots 0-8; X = 1: player 1, slots 9-17), as objects:
; each asteroid's first visible line, sprite X (2600 pixel + 32), shape and first row, rows,
; colour. The thread's code runs once a row (cK: $FF, then 0 .. $58); it waits for a slot's
; row, positions the asteroid on the next row (kp), draws a row on each following one until
; the shape's motion byte is 0, then moves to the next slot. Rows beyond the field don't
; matter (the border hides them).
CaptureThread:
        stx tmp4                ; thread
        lda #0
        sta CAN,x
        txa                     ; output index: 9 * thread
        beq +
        lda #9
+       sta cLast
        lda Slot0,x
        sta cSlot
        lda Pos0,x
        sta cCode
        txa
        asl
        tax
        lda Gfx0,x
        sta cP
        lda P0Vector,x
        ldx tmp4
        cmp WaitState,x
        beq _wait0
        cmp PosState1,x
        beq _pos0
        cmp PosState2,x
        beq _pos0
        inc DbgOdd              ; (not seen: a thread starting mid-asteroid)
        rts
_pos0   lda #$ff                ; positioned on the first line: an asteroid partly above the top
        sta cK                  ; (cK = the row it is positioned on)
        ldy cSlot
        lda AstType,y
        and #7
        sta tmp3                ; (its colour: the kernel takes slot 0's / 9's)
        jmp _place
_wait0  lda #$ff
        sta cK
        ; ---- waiting at row cK for slot cSlot's row (cK = $FF: the first line, then 0 ..)
_wait   ldy cSlot
        lda AstY,y
        ldx cK
        cpx #$ff
        bne +
        cmp #$ff                ; the first line is row $FF
        beq _match
        ldx #0
+       stx cK
        cmp cK
        bcc _xout               ; already passed: never drawn
        cmp #$59
        bcc _match
_xout   jmp _out
_match  sta cK
        lda AstType,y
        and #$70
        sta cP
        lda AstType,y
        and #7
        sta tmp3
        inc cK                  ; positioned on the next row
        lda cK
        ldx tmp4
        cmp LastPosRow,x        ; (no rows left for it)
        bcs _out
        ; ---- placed on row cK (or $FF), drawn from the next row
_place  ldy cP
        bmi _bad
        lda RowsLeft,y
        beq _bad
        ldx cLast
        sta CARows,x
        lda cK                  ; first visible line: 2 * (kp + 1) + 53 (player 1: + 54)
        clc
        adc #1
        asl
        adc #53
        adc tmp4
        sta CALine,x
        ldy cCode
        lda PosX,y
        ldy cP
        clc
        adc Shift,y
        clc
        adc #32
        sta CAX,x
        tya
        sta CAP,x
        ldy tmp3
        lda AstColours,y
        sta CACol,x
        inc cLast
        ldy tmp4
        lda CAN,y
        clc
        adc #1
        sta CAN,y
        ; the next slot: its wait starts 2 + rows after the positioning row
        lda cK                  ; (kp + 1: row $FF counts as -1)
        clc
        adc #1
        ldy cP
        clc
        adc RowsLeft,y
        bcs _out
        adc #1
        cmp #$59
        bcs _out
        sta cK
        inc cSlot
        ldy cSlot
        lda AstX,y
        sta cCode
        jmp _wait
_bad    inc DbgBadP             ; (not seen: drawing from outside a shape)
_out    rts

WaitState:  .byte $c0, $cf      ; the threads' states (low bytes of $E3 / $E5): wait,
PosState1:  .byte $0e, $0b      ; position (early, late)
PosState2:  .byte $46, $45
LastPosRow: .byte $58, $57      ; positioned on this row or later: no rows drawn

; ---------------------------------------------------------------- the ship frame
; The ship (player 0) and the UFO (player 1) are graphics streams: from the pointer the
; frame starts with until a $FF (the part wrapped round from the bottom), then from the
; shape's start at its top row (if the first part ended by then) until a $FF. Shots: one
; row each.
CaptureShip:
        lda $e9                 ; colours: ship (and M0, the ball), UFO (and M1)
        sta CSCol
        lda $ea
        sta CSCol+1
        lda $e8
        sta CSColBL
        lda $eb                 ; ship: reflected (bit 3), delayed a line (bit 0)
        sta CSRefl
        and #1
        sta tmp3
        ldy ShipX
        lda PosX,y
        clc
        adc #32
        sta CSX
        ldx #$ed                ; stream pointer, page, start, top row
        lda #$ee
        ldy #$f1
        sta tmp
        lda $ef
        sta tmp2
        lda #0                  ; record 0: the ship, first line 53
        jsr Stream
        lda $ec                 ; UFO: delayed a line (bit 0)
        and #1
        sta tmp3
        lda #0
        sta CSRefl+1
        ldy UfoX
        lda PosX,y
        clc
        adc #32
        sta CSX+1
        ldx #$e6
        lda #$e7
        ldy #$f2
        sta tmp
        lda UfoY
        sta tmp2
        lda #1                  ; record 1: the UFO, first line 54
        jsr Stream
        ldx #2                  ; shots
-       lda ShotY,x
        cmp #$59
        bcs _none
        asl
        adc #52
        sta CSShotLine,x
        ldy ShotX,x
        lda MisX,y
        sta CSShotX,x
        dex
        bpl -
        rts
_none   lda #0
        sta CSShotLine,x
        dex
        bpl -
        rts

; Stream A (0 ship, 1 UFO): X = zero page pointer, tmp = its page's address, Y = the start's
; address, tmp2 = top row, tmp3 = 1 if delayed. Fills CSSeg* for the two parts.
Stream:
        sta v0
        asl
        sta v1                  ; 2 * record: its parts
        lda 0,y
        sta v2                  ; start
        lda 0,x
        sta ptrA                ; the first part: from the frame's pointer
        ldx tmp
        lda 0,x
        and #$0f
        ora #$d0                ; (bank 0, whatever mirror the game used)
        sta ptrA+1
        lda v1
        tax
        lda #0                  ; first line 53 (+1 UFO, +1 delayed)
        jsr _part
        lda CSSegRows,x         ; the second part (at the top row) if the first ended by then
        cmp tmp2
        beq +
        bcs _no
+       lda tmp2
        cmp #$59
        bcs _no
        lda v2
        sta ptrA
        inx
        lda tmp2
        jmp _part
_no     lda #0
        sta CSSegRows+1,x
        rts
_part   asl                     ; A = row: first line = 2 * row + 53 + record + delay
        clc
        adc #53
        adc v0
        adc tmp3
        sta CSSegLine,x
        txa                     ; rows into CSSegData + 8 * part (up to 8)
        asl
        asl
        asl
        sta tmp4
        ldy #0
-       lda (ptrA),y
        cmp #$ff
        beq +
        stx cSlot
        ldx tmp4
        sta CSSegData,x
        inc tmp4
        ldx cSlot
        iny
        cpy #8
        bne -
+       tya
        sta CSSegRows,x
        rts
