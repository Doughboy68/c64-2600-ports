// A random player for the checks (model.js, lockstep.js, screencheck.js): the same inputs
// from the same seed. Mostly turns and fires, thrusts now and then, uses the special
// feature (hyperspace, shields or flip) now and then. Both difficulty switches are on A
// (UFOs and satellites) unless --diff=B. Between games it presses Game Select a few times
// (another of the 66 games) and then Game Reset.
//   const play = require('./play')(seed, { diffB });  play(frame, ram) -> { swcha, swchb, fire }
module.exports = function (seed, opts = {}) {
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const diff = opts.diffB ? 0 : 0xC0;
  let swcha = 0xFF, fire = false, between = 0, selects = 0;
  return function (f, ram) {
    const R = a => ram[a - 0x80];
    let swchb = 0x0B | diff;
    if (f < 300) return { swcha: 0xFF, swchb, fire: false };       // the copyright screen
    const noGame = R(0xC8) & 1;
    if (noGame) {
      // between games: wait a little, Select a few times, then Reset
      if (between === 0) { between = 30 + Math.floor(rnd() * 60); selects = Math.floor(rnd() * 4); }
      between--;
      if (between > 10 && selects && between % 8 < 4) swchb &= ~2;
      if (between > 10 && selects && between % 8 === 4) selects--;
      if (between <= 4) swchb &= ~1;
      return { swcha: 0xFF, swchb, fire: false };
    }
    between = 0;
    if (f % 12 === 0) {
      const r = rnd();
      // left / right turns, a little thrust, rarely the special feature (down)
      swcha = r < 0.35 ? 0xBF : r < 0.7 ? 0x7F : r < 0.82 ? 0xEF : r < 0.85 ? 0xDF : r < 0.9 ? 0xAF : 0xFF;
      fire = rnd() < 0.6;
    }
    // the second player's joystick (two-player games) mirrors the first
    return { swcha: (swcha & 0xF0) | (swcha >> 4), swchb, fire: fire && f % 4 < 2 };
  };
};
