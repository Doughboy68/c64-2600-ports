// Run the C64 version's game ticks (the patched 2600 program plus the capture code, from
// build/asteroids-<version>.prg) on a plain 6502 (tools/c64sim.js), side by side with the original
// game in tools/vcs.js, with the same inputs (tools/play.js). Once a frame both stop where
// the picture would be drawn: the game RAM must be identical. Any difference is a bug in a
// patch. Also runs Render each frame and reports the cycles both take.
//   node games/asteroids/tools/lockstep.js [frames] [--seed=N] [--diff=B] [--ntsc] [--noflicker] [--power=N] [--verbose] [--profile]
// --power=N: at frame N press F2 (power off and on) on the C64, and switch on a new 2600.
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 3000);
const verbose = process.argv.includes('--verbose');

const c64 = new C64();
c64.start(!process.argv.includes('--ntsc'));
if (process.argv.includes('--noflicker')) c64.mem[c64.sym('Flicker')] = 0;
const sym = n => c64.sym(n);
// --profile: cycles per routine (by the nearest label before the PC)
const profile = process.argv.includes('--profile') ? {} : null;
const labels = [...c64.lst.matchAll(/^\.([0-9a-f]{4})\t.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[1], 16), m[2]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xD000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
let frameProf = {}, worstRender = { cyc: 0 };
if (profile) { const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc); profile[k] = (profile[k] || 0) + this.cycles - c; frameProf[k] = (frameProf[k] || 0) + this.cycles - c; return r; }; }

// ---- the original: stop once a frame where the picture starts (or the copyright screen's)
let vcs = new VCS(rom);
let atKernel = false, kernelFrame = -1;
const hook = v => {
  const origStep = v.step.bind(v);
  v.step = function () {
    if ((this.pc === 0xD57E || this.pc === 0xDB66) && this.frames !== kernelFrame) { atKernel = true; kernelFrame = this.frames; }
    return origStep();
  };
};
hook(vcs);
const runToKernel = () => { atKernel = false; let g = 0; while (!atKernel) { vcs.step(); if (++g > 2e6) throw new Error('2600 never reached the picture'); } };

// Bytes the two may disagree on: the asteroid kernel's thread states ($E3, $E5), graphics
// pointers ($EB, $ED) and motion pointers ($EF, $F1), which the 2600's kernel leaves changed
// and which are set again before they're used (the C64 doesn't run the kernels; after a Game
// Reset two asteroid frames run back to back, and the second starts with the first's leftovers). They are not copied across
// either, so if the game ever did depend on them, the rest of the RAM would show it.
const IGNORE = new Set([0xE3, 0xE5, 0xEB, 0xED, 0xEF, 0xF1, ...process.argv.filter(a => a.startsWith('--ignore=')).flatMap(a => a.slice(9).split(',').map(x => parseInt(x, 16)))]);
const NAMES = {};
for (const [a, n, size] of require('../2600/symbols.js').ram) for (let i = 0; i < size; i++) NAMES[a + i] = size > 1 ? `${n}+${i}` : n;

const play = require('./play')(arg('seed', 11), { diffB: process.argv.includes('--diff=B') });
const spikes = [];
let bad = 0, done = 0, maxTick = 0, totalTick = 0, maxRender = 0, totalRender = 0;
const diffCount = {};
const powerAt = arg('power', -1);
for (let f = 0; f < frames; f++) {
  if (f === powerAt) {                            // F2: power off and on
    c64.call(sym('PowerCycle'));
    vcs = new VCS(rom); hook(vcs); kernelFrame = -1;
    console.log(`frame ${f}: power off and on`);
  }
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  c64.mem[0x0280] = p.swcha; c64.mem[0x0282] = p.swchb; c64.mem[0x3C] = c64.mem[0x3D] = p.fire ? 0 : 0x80;
  runToKernel();
  const cyc = c64.call(sym('Tick'));
  maxTick = Math.max(maxTick, cyc); totalTick += cyc;
  c64.mem[sym('pending')] = 0;                    // draw it, as the main loop would
  c64.mem[sym('curBuf')] ^= 1;                    // (and show it)
  frameProf = {};
  const rc = c64.call(sym('Render'));
  if (profile && f >= 300 && rc > worstRender.cyc) worstRender = { cyc: rc, f, prof: { ...frameProf } };
  if (f >= 300) { maxRender = Math.max(maxRender, rc); if (rc > 9000) spikes.push(f + ':' + rc); }
  totalRender += rc;
  done++;
  const diffs = [];
  for (let a = 0x80; a < 0x100; a++) if (!IGNORE.has(a) && vcs.ram[a - 0x80] !== c64.mem[a]) {
    diffs.push(`${NAMES[a] || '$' + a.toString(16)} 2600 ${vcs.ram[a - 0x80].toString(16)} C64 ${c64.mem[a].toString(16)}`);
    diffCount[a] = (diffCount[a] || 0) + 1;
  }
  if (diffs.length) {
    bad++;
    if (bad <= 5 || verbose) console.log(`frame ${f} (${vcs.ram[0x39] & 1 ? 'asteroids' : 'ship'}): ${diffs.join(', ')}`);
    for (let a = 0x80; a < 0x100; a++) if (!IGNORE.has(a)) c64.mem[a] = vcs.ram[a - 0x80];   // resync and carry on
  }
}
if (bad) console.log('bytes that differed (frames):', Object.entries(diffCount).map(([a, n]) => `${NAMES[a] || '$' + (+a).toString(16)} ${n}`).join(', '));
const dbg = ['DbgDrop', 'DbgSched', 'DbgOdd', 'DbgBadP', 'DbgWide'].map(n => `${n} ${c64.mem[sym(n)]}`).join(', ');
if (profile) console.log(`worst render: frame ${worstRender.f}, ${worstRender.cyc} cycles: ` + Object.entries(worstRender.prof).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => `${k} ${v}`).join(', '));
if (profile) { const tot = Object.values(profile).reduce((a, b) => a + b, 0); for (const [k, v] of Object.entries(profile).sort((a, b) => b[1] - a[1]).slice(0, 20)) console.log(k.padEnd(16), String(Math.round(v / done)).padStart(7), (100 * v / tot).toFixed(1) + '%'); }
if (spikes.length) console.log('renders over 9000 cycles (frame:cycles):', spikes.slice(0, 20).join(' '), spikes.length > 20 ? `... ${spikes.length} in all` : '');
console.log(`${done} frames, ${bad} with differences; C64 tick ${Math.round(totalTick / done)} cycles on average, ${maxTick} at most; render ${Math.round(totalRender / done)} on average, ${maxRender} at most after the copyright screen; ${dbg}`);
