// Scripted play test of the C64 build in VICE (through the remote monitor):
// start it, wait out the copyright screen, press fire, turn about firing, and save screenshots.
//   node games/asteroids/tools/c64test.js <outdir> [seconds-of-play] [--timing] [--ntsc] [--still] [--noflicker] [--diffA]
const fs = require('fs');
const net = require('net');
const path = require('path');
const { execSync, spawn } = require('child_process');

const out = path.resolve(process.argv[2] || '.');
const playSeconds = +(process.argv[3] || 20);
const timing = process.argv.includes('--timing');
const ntsc = process.argv.includes('--ntsc');
const still = process.argv.includes('--still');
const root = path.join(__dirname, '..');
const lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(root, 'build')).lst, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return m[1];
};
const A = { swcha: addr('DbgSWCHA'), inpt4: addr('DbgINPT4'), swchb: addr('DbgSWCHB'), border: addr('DbgBorder'), flicker: addr('Flicker'), switches: addr('switches') };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
let vice = null;              // the VICE this run started (only that one is closed)
let PORT = 0;                 // our own monitor port (another session's VICE may have 6510)

function mon(cmds) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(PORT, '127.0.0.1');
    let buf = '';
    sock.on('data', d => { buf += d.toString('latin1'); });
    sock.on('error', reject);
    sock.on('connect', async () => {
      await sleep(150);
      for (const c of cmds) { sock.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 150); }
      sock.write('x\n');
      await sleep(100);
      sock.end();
      resolve(buf.replace(/\(C:\$[0-9a-f]{4}\) /g, ''));
    });
  });
}
const poke = (a, v) => mon([`> ${a} ${v}`]);
const shot = name => mon([`screenshot "${path.join(out, name).replace(/\\/g, '/')}" 2`]);

(async () => {
  fs.mkdirSync(out, { recursive: true });
  // (any VICE already running is left alone; only the one started here is closed at the end)
  await sleep(500);
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', require('../../../tools/buildname').files(path.join(root, 'build')).prg]);
  await sleep(6000);
  if (!await runsOurs(mon, require('../../../tools/buildname').files(path.join(root, 'build')).prg)) throw new Error(`the VICE on port ${PORT} isn't running our build: stopping`);
  if (timing) await poke(A.border, '1');
  await shot('t0-copyright.png');
  await sleep(5000);
  await shot('t0-attract.png');
  if (process.argv.includes('--noflicker')) await poke(A.flicker, '0');
  if (process.argv.includes('--diffA')) await poke(A.switches, 'cb');      // both difficulties A: UFOs
  await poke(A.inpt4, '7f'); await sleep(600); await poke(A.inpt4, 'ff');   // fire: start a game
  await sleep(2500);
  await shot('t1-start.png');
  let seed = 1;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const t0 = Date.now();
  let n = 0;
  const DIRS = ['7f', 'bf', 'ef', 'df', 'ff'];
  while (Date.now() - t0 < playSeconds * 1000) {
    if (!still) await poke(A.swcha, DIRS[Math.floor(rnd() * DIRS.length)]);
    await sleep(500);
    if (!still && rnd() < 0.5) { await poke(A.inpt4, '7f'); await sleep(150); await poke(A.inpt4, 'ff'); }
    if (++n % (still ? 3 : 6) === 0) await shot(`t2-play${String(n / 6).padStart(2, '0')}.png`);
  }
  await poke(A.swcha, 'ff');
  await shot('t3-end.png');
  await sleep(500);
  stopVice(vice);
})().catch(e => { console.log(e.message); stopVice(vice); });
