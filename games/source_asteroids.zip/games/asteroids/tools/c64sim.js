// The C64 version's code on a plain 6502 (the 6502 core of tools/vcs.js) with 64K of RAM,
// for lockstep.js and screencheck.js. $D000-$DFFF is I/O when the CPU port ($01) says so
// (bank 0 of the game lives in the RAM under it); I/O writes land in `io`.
// Set up like Start: the patched game copied to $D000 / $F000, the shapes and video set up.
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const ROMMD5 = 'dd7884b4f93cab423ac471aa1935e3df';
const rom = require('../../../tools/rom').load(ROMMD5);
const build = path.join(__dirname, '..', 'build');

class C64 extends VCS {
  constructor() {
    super(rom);
    this.mem = new Uint8Array(65536);
    this.io = new Uint8Array(4096);
    const prg = fs.readFileSync(require('../../../tools/buildname').files(path.join(build)).prg);
    this.lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(build)).lst, 'latin1');
    this.mem.set(prg.subarray(2), prg.readUInt16LE(0));
  }
  ioOn() { return (this.mem[1] & 3) !== 0 && (this.mem[1] & 4) !== 0; }
  read(a) { a &= 0xFFFF; return a >= 0xD000 && a < 0xE000 && this.ioOn() ? this.io[a - 0xD000] : this.mem[a]; }
  write(a, v) { a &= 0xFFFF; if (a >= 0xD000 && a < 0xE000 && this.ioOn()) this.io[a - 0xD000] = v; else this.mem[a] = v; }
  commit() {} flush() {} tick(n) { this.cycles += n; }
  sym(name) {
    const m = this.lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
    if (!m) throw new Error('no symbol ' + name);
    return parseInt(m[1], 16);
  }
  call(addr, limit = 3e6) {      // JSR addr from a stub, run until it returns
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    const start = this.cycles;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error('runaway at $' + this.pc.toString(16)); }
    return this.cycles - start;
  }
  // what Start does that matters here
  start(pal = true) {
    const m = this.mem, img = this.sym('GameImage');
    this.s = 0xFF;
    m[1] = 0x34;
    m.copyWithin(0xD000, img, img + 0x1000);
    m.copyWithin(0xF000, img + 0x1000, img + 0x2000);
    const w = (a, v) => { m[a] = v & 255; m[a + 1] = v >> 8; };
    w(0xFFFA, this.sym('Nmi')); w(0xFFFE, this.sym('Irq'));
    this.call(this.sym('InitShapes'));
    this.call(this.sym('InitTitle'));
    m[1] = 0x35;
    m[0x0280] = 0xFF; m[0x0282] = 0x0B; m[0x0284] = 0; m[0x3C] = m[0x3D] = 0x80;
    m[this.sym('firstTick')] = 1;
    m[this.sym('switches')] = 0x0B;
    m[this.sym('isPal')] = pal ? 1 : 0;
    this.call(this.sym('InitVideo'));
  }
}
module.exports = { C64, rom, ROMMD5 };
