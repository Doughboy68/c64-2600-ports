// Check the C64 picture against the 2600's. Runs the C64 version's ticks and Render (as in
// lockstep.js) next to tools/vcs.js, then draws the C64 frame in JavaScript from what Render
// staged (screen, characters, sprite registers, the raster schedule, sprites simulated line
// by line with the VIC's rule that a sprite can't start again until its 21 rows are done),
// and compares it pixel by pixel, in C64 colours, with the picture the 2600 draws.
// Lines 30-229 (what the C64 shows). Flicker on (the 2600's way); with --noflicker the C64
// frame is checked against the last asteroid frame and the last ship frame together: every
// object of either must show in one of its colours, and everything else as the 2600 draws it.
//   node games/asteroids/tools/screencheck.js [frames] [--seed=N] [--diff=B] [--noflicker] [--show=<frame>] [--png=dir]
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 1000);
const showFrame = arg('show', -1), pngDir = arg('png', null);

const c64 = new C64();
c64.start(true);
const noflicker = process.argv.includes('--noflicker');
if (noflicker) c64.mem[c64.sym('Flicker')] = 0;
const last = [null, null];               // (--noflicker) the last 2600 picture of each kind
const sym = n => c64.sym(n), M = c64.mem;
const COLORMAP = sym('ColorMap'), NSCHED = 40, LINE2RAS = 21;

// ---- the C64 frame (buffer b) as 160 x 262 C64 colours, plus what drew each pixel
function c64Picture(b) {
  const col = new Uint8Array(160 * 262).fill(255), what = new Uint8Array(160 * 262);   // what: 1 sprite, 2 char fg, 3 char 01
  const spr = new Uint8Array(160 * 262).fill(255);                                       // which sprite
  const scr = b ? 0x8400 : 0x8000, chars = b ? 0xA000 : 0x8800;
  const bg = M[sym('StBg') + b];
  let fieldRas = 999;                             // the S_FIELD entry: shot colours from the next line
  for (let i = 1; i < NSCHED; i++) { const e = b * NSCHED + i; if (M[sym('SchedType') + e] === 4) fieldRas = M[sym('SchedRas') + e] + 1; if (M[sym('SchedType') + e] === 6) break; }
  const d022 = L => L + LINE2RAS < fieldRas ? M[sym('StD022') + b] : M[sym('FlD022') + b];
  const d023 = L => L + LINE2RAS < fieldRas ? M[sym('StD023') + b] : M[sym('FlD023') + b];
  // sprites: registers, changed by the schedule's entries as the raster passes them
  let lostStart = 0;
  const regs = [...Array(8)].map((_, n) => ({
    en: (M[sym('StEn') + b] >> n) & 1, x: M[sym('StX') + 8 * b + n] + ((M[sym('StMsb') + b] >> n) & 1) * 256,
    y: M[sym('StY') + 8 * b + n], ptr: M[sym('StPtr') + 8 * b + n], col: M[sym('StCol') + 8 * b + n], start: -1,
  }));
  const changes = [];
  for (let i = 1; i < NSCHED; i++) {
    const e = b * NSCHED + i, type = M[sym('SchedType') + e], ras = M[sym('SchedRas') + e];
    if (type === 6) break;
    if (type === 2) { const a = M[sym('SchedArg') + e]; changes.push({ ras, n: M[sym('RNum') + a], x: M[sym('RX') + a] + (M[sym('RMsb') + a] ? 256 : 0), y: M[sym('RY') + a], ptr: M[sym('RPtr') + a], col: M[sym('RCol') + a] }); }
  }
  let ci = 0;
  for (let L = 30; L <= 229; L++) {
    const ras = L + LINE2RAS;
    while (ci < changes.length && changes[ci].ras < ras) { const c = changes[ci++]; Object.assign(regs[c.n], { x: c.x, y: c.y, ptr: c.ptr, col: c.col }); }
    const row = (L - 30) >> 3, li = (L - 30) & 7;
    for (let x = 0; x < 160; x++) {
      const ch = M[scr + row * 40 + (x >> 2)], byte = M[chars + ch * 8 + li], pair = (byte >> (6 - 2 * (x & 3))) & 3;
      const i = L * 160 + x;
      if (pair >= 2) { col[i] = pair === 2 ? d023(L) : c64.io[0x800 + row * 40 + (x >> 2)] & 7; what[i] = 2; }
      else { col[i] = pair ? d022(L) : bg; what[i] = pair ? 3 : 0; }
    }
    for (let n = 7; n >= 0; n--) {               // (sprite 0 in front)
      const s = regs[n];
      if (!s.en) continue;
      // the VIC looks for a start (Y = the line before) in that line's cycle 55; the DMA of the
      // last start (42 lines shown) is only off by then from its 43rd line on
      if (s.y + 1 === ras && (s.start < 0 || ras - 1 - s.start >= 42)) s.start = ras;
      else if (s.start >= 0 && ras - s.start >= 42) { s.done = s.start; s.start = -1; }
      if (s.start < 0 && s.done !== undefined && s.y + 1 === ras && ras - 1 - s.done < 42) lostStart++;
      if (s.start < 0) continue;
      const r = (ras - s.start) >> 1, base = (b ? 0 : 0) + 0x8000 + s.ptr * 64 + 3 * r;
      for (let k = 0; k < 3; k++) for (let bit = 0; bit < 8; bit++) if (M[base + k] & (0x80 >> bit)) {
        const px = ((s.x - 24) >> 1) + 8 * k + bit;
        if (px < 0 || px >= 160) continue;
        const i = L * 160 + px;
        if (what[i] === 2) continue;                                      // behind the characters' foreground
        col[i] = s.col; what[i] = 1; spr[i] = n;
      }
    }
  }
  return { col, what, spr, regs: changes };
}

// ---- the 2600
const vcs = new VCS(rom);
vcs.hmoveBlank = true;
let atKernel = false, kernelFrame = -1, picture = null;
const origStep = vcs.step.bind(vcs);
vcs.step = function () {
  if ((this.pc === 0xD57E || this.pc === 0xDB66) && this.frames !== kernelFrame) { atKernel = true; kernelFrame = this.frames; }
  return origStep();
};
vcs.onFrame = v => { picture = { fb: Uint8Array.from(v.fb), ob: Uint8Array.from(v.ob) }; };
const runToKernel = () => { atKernel = false; let g = 0; while (!atKernel) { vcs.step(); if (++g > 2e6) throw new Error('2600 never reached the picture'); } };

// ---- PNG (C64 colours, 2 pixels per 2600 pixel)
const PEPTO = ['000000', 'FFFFFF', '96282E', '5BD6CE', '9F2DAD', '41B936', '2724C4', 'EFF347', '9F4815', '5E3500', 'DA5F66', '474747', '787878', '91FF84', '6864FF', 'AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; return c; });
const crc32 = buf => { let c = -1; for (const x of buf) c = CRC[(c ^ x) & 0xFF] ^ (c >>> 8); return (c ^ -1) >>> 0; };
function png(file, pics) {          // pics side by side, lines 30-229
  const W = 320 * pics.length + 8 * (pics.length - 1), H = 200 * 2, raw = Buffer.alloc((W * 3 + 1) * H);
  for (let y = 0; y < H; y++) for (let p = 0; p < pics.length; p++) for (let x = 0; x < 320; x++) {
    const c = pics[p][(30 + (y >> 1)) * 160 + (x >> 1)];
    raw.set(PEPTO[c === 255 ? 0 : c], y * (W * 3 + 1) + 1 + (p * 328 + x) * 3);
  }
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc32(td)); return Buffer.concat([l, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2;
  fs.writeFileSync(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
}
if (pngDir) fs.mkdirSync(pngDir, { recursive: true });

// ---- run
const play = require('./play')(arg('seed', 11), { diffB: process.argv.includes('--diff=B') });
const KINDS = { obj: 'players', shot: 'shots', pf: 'playfield', bg: 'background', extra: 'C64 only', ufoshot: "known: the UFO's shot over the UFO" };
const bad = {}, ex = {};
let pending = null, checked = 0, types = [0, 0, 0];
for (let f = 0; f <= frames; f++) {
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  M[0x0280] = p.swcha; M[0x0282] = p.swchb; M[0x3C] = M[0x3D] = p.fire ? 0 : 0x80;
  runToKernel();                                    // (the 2600 finished the last frame's picture)
  if (pending && picture) {
    const { c64p, frame, type } = pending, cmap = i => M[COLORMAP + picture.fb[i]];
    checked++; types[type]++;
    if (type < 2) last[type] = picture;
    const both = noflicker && type < 2 && last[0] && last[1];
    const want = new Uint8Array(160 * 262);
    const n = {};
    let first = {};
    for (let L = 30; L <= 229; L++) for (let x = 0; x < 160; x++) {
      const i = L * 160 + x;
      let w = cmap(i), o = picture.ob[i];
      if (both) {                                   // either frame's object, in either's colour
        const oa = last[0].ob[i] & 3, os = last[1].ob[i] & 31;
        if (oa || os) {
          const ca = M[COLORMAP + last[0].fb[i]], cs = M[COLORMAP + last[1].fb[i]];
          if ((oa && c64p.col[i] === ca) || (os && c64p.col[i] === cs)) { want[i] = c64p.col[i]; continue; }
          w = oa ? ca : cs; o = oa | os;
        }
      }
      want[i] = w;
      if (w === c64p.col[i]) continue;
      // (known: where the UFO's shot crosses the UFO, the C64 draws the shot in front)
      const k = (o & 18) === 18 && !(o & 1) && c64p.what[i] !== 1 ? 'ufoshot' : o & 3 ? 'obj' : o & 28 ? 'shot' : o & 32 ? 'pf' : c64p.what[i] ? 'extra' : 'bg';
      n[k] = (n[k] || 0) + 1;
      if (!first[k]) first[k] = `line ${L} x ${x}: 2600 colour ${w}, C64 ${c64p.col[i]}`;
      if (frame === showFrame && n[k] <= 8) console.log(`  line ${L} x ${x}: 2600 objects ${o.toString(2)} colour ${w}; C64 colour ${c64p.col[i]} sprite ${c64p.spr[i]}`);
    }
    for (const k of Object.keys(n)) { bad[k] = (bad[k] || 0) + 1; if (!ex[k]) ex[k] = `frame ${frame} (${['asteroids', 'ship', 'copyright'][type]}): ${n[k]} pixels, ${first[k]}`; }
    if (frame === showFrame) {
      for (let L = 30; L <= 229; L++) { let r = ''; let any = false; for (let x = 0; x < 160; x++) { const i = L * 160 + x, a = want[i] !== want[30 * 160], c = c64p.col[i] !== want[30 * 160]; r += want[i] === c64p.col[i] ? (a ? '#' : '.') : a && c ? 'X' : a ? 'A' : 'c'; any = any || a || c; } if (any) console.log(String(L).padStart(3), r); }
    }
    if (pngDir && (frame === showFrame || (Object.keys(n).length && Object.keys(bad).length <= 3) || frame % 500 === 0)) png(path.join(pngDir, `f${String(frame).padStart(5, '0')}.png`), [want, c64p.col]);
  }
  c64.call(sym('Tick'));
  M[sym('pending')] = 0;
  M[sym('curBuf')] ^= 1;
  c64.call(sym('Render'));
  pending = { c64p: c64Picture(M[sym('curBuf')] ^ 1), frame: f, type: M[sym('LastType')] };
}
console.log(`${checked} frames checked (${types[0]} asteroid frames, ${types[1]} ship frames, ${types[2]} copyright); C64 ${['DbgDrop', 'DbgSched', 'DbgOdd', 'DbgBadP'].map(k => `${k} ${M[sym(k)]}`).join(', ')}`);
for (const k of Object.keys(KINDS)) console.log(KINDS[k].padEnd(11), bad[k] ? `${bad[k]} frames differ, e.g. ${ex[k]}` : 'exact');
