// How tight the sprite reuses are: for each sprite moved by the raster interrupt, the lines
// between the interrupt and the object's first line (lead), and between the sprite's
// previous first line and the new one (gap; the VIC needs 42 or more, Y-expanded).
//   node games/asteroids/tools/reusestats.js [frames] [--seed=N] [--noflicker]
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const c64 = new C64(); c64.start(false);
const M = c64.mem, sym = n => c64.sym(n);
if (process.argv.includes('--noflicker')) M[sym('Flicker')] = 0;
const vcs = new VCS(rom);
let at = false, kf = -1; const os = vcs.step.bind(vcs);
vcs.step = function () { if ((this.pc === 0xD57E || this.pc === 0xDB66) && this.frames !== kf) { at = true; kf = this.frames; } return os(); };
const play = require('./play')(arg('seed', 11), {});
const lead = {}, gap = {};
let reuses = 0, frames = 0, maxReuse = 0;
for (let f = 0; f < arg('frames', 3000); f++) {
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  M[0x280] = p.swcha; M[0x282] = p.swchb; M[0x3C] = M[0x3D] = p.fire ? 0 : 0x80;
  at = false; while (!at) vcs.step();
  c64.call(sym('Tick')); M[sym('pending')] = 0; M[sym('curBuf')] ^= 1; c64.call(sym('Render'));
  const b = M[sym('curBuf')] ^ 1;
  const top = [...Array(8)].map((_, n) => M[sym('StY') + 8 * b + n] + 1);    // each sprite's last first line (raster)
  let n = 0;
  for (let i = 1; i < 40; i++) {
    const e = b * 40 + i, type = M[sym('SchedType') + e];
    if (type === 6) break;
    if (type !== 2) continue;
    const a = M[sym('SchedArg') + e], s = M[sym('RNum') + a], first = M[sym('RY') + a] + 1, ras = M[sym('SchedRas') + e];
    lead[first - ras] = (lead[first - ras] || 0) + 1;
    gap[first - top[s]] = (gap[first - top[s]] || 0) + 1;
    top[s] = first; n++; reuses++;
  }
  if (f >= 300) frames++;
  maxReuse = Math.max(maxReuse, n);
}
const show = h => Object.keys(h).map(Number).sort((x, y) => x - y).slice(0, 8).map(k => `${k}: ${h[k]}`).join(', ');
console.log(`${reuses} reuses in ${frames} frames (at most ${maxReuse} in a frame)`);
console.log('lead, lines (smallest):', show(lead));
console.log('gap, lines (smallest):', show(gap));
