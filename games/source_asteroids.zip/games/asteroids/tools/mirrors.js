// Which instructions read the ROM at an address of the other bank's range ($Fxxx from
// bank 0, $Dxxx from bank 1)? On the 2600 that reads the selected bank's own bytes; on the
// C64, with bank 0 at $D000 and bank 1 at $F000, it would read the other bank.
//   node games/asteroids/tools/mirrors.js [frames]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('dd7884b4f93cab423ac471aa1935e3df'));
const frames = +(process.argv[2] || 3000);
const found = new Map();
const rd = vcs.read.bind(vcs);
let fetching = false;
vcs.read = function (a) {
  if (!fetching && (a & 0x1000)) {
    const home = this.bank ? 0xF000 : 0xD000;
    if ((a & 0xF000) !== home) {
      const k = `$${this.lastPc.toString(16)} (bank ${this.bank}) reads $${(a & 0xF000).toString(16)} page`;
      found.set(k, (found.get(k) || 0) + 1);
    }
  }
  return rd(a);
};
const st = vcs.step.bind(vcs);
vcs.step = function () {                  // (instruction and operand fetches are not data reads)
  fetching = true; this.read(this.pc); this.read(this.pc + 1); this.read(this.pc + 2); fetching = false;
  return st();
};
let seed = 3;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
for (let f = 0; f < frames; f++) {
  if (f % 20 === 0) {
    vcs.swcha = [0x7F, 0xBF, 0xEF, 0xDF, 0xFF, 0x6F, 0x5F, 0xAF, 0x9F][Math.floor(rnd() * 9)];
    vcs.fire[0] = rnd() < .5;
    vcs.swchb = rnd() < .05 ? 0x0A : rnd() < .2 ? 0x4B : 0x0B;   // Game Reset now and then; difficulty A (UFOs)
  }
  vcs.runFrames(1);
}
for (const [k, n] of [...found].sort()) console.log(k, 'x' + n);
