// Play random games in tools/vcs.js and list where the bank-switching JMP ($F7) goes
// and the kernel's other indirect jumps
// (code the disassembler can't trace by itself), plus executed code it didn't find.
//   node games/asteroids/tools/coverage.js [frames] [executed.json]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('dd7884b4f93cab423ac471aa1935e3df'));
const frames = +(process.argv[2] || 20000);
const targets = new Map(), kernel = new Map(), executed = new Set();
const st = vcs.step.bind(vcs);
vcs.step = function () {
  executed.add(this.pc);
  if ((this.pc & 0xFFF) === 0xFF3) { const t = this.ram[0x77] | this.ram[0x78] << 8; targets.set(t, (targets.get(t) || 0) + 1); }
  if (this.rom[this.bank * 4096 + (this.pc & 0xFFF)] === 0x6C) {      // JMP (zp): the kernel's threads
    const z = this.rom[this.bank * 4096 + (this.pc & 0xFFF) + 1], t = this.ram[z & 0x7F] | this.ram[(z + 1) & 0x7F] << 8;
    if (z !== 0xF7) kernel.set(t, (kernel.get(t) || 0) + 1);
  }
  return st();
};
let seed = 5;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
for (let f = 0; f < frames; f++) {
  if (f % 20 === 0) {
    vcs.swcha = [0x7F, 0xBF, 0xEF, 0xDF, 0xFF, 0x6F, 0x5F, 0xAF, 0x9F][Math.floor(rnd() * 9)];
    vcs.fire[0] = rnd() < .5;
    vcs.swchb = rnd() < .05 ? 0x0A : rnd() < .03 ? 0x09 : 0x0B;   // now and then Game Reset or Select
  }
  vcs.runFrames(1);
}
console.log('JMP ($F7) targets:', [...targets].sort((a, b) => a[0] - b[0]).map(([a, n]) => `$${a.toString(16)}x${n}`).join(' '));
console.log('other JMP () targets:', [...kernel].sort((a, b) => a[0] - b[0]).map(([a, n]) => `${a.toString(16)}x${n}`).join(' '));
console.log('executed', executed.size, 'addresses');
if (process.argv[3]) require('fs').writeFileSync(process.argv[3],JSON.stringify([...executed].sort((a, b) => a - b)));
