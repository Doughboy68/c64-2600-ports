// A model of what Asteroids' kernels draw, built only from RAM (and the colours the game set
// before the picture), checked pixel by pixel against tools/vcs.js over random games:
// the objects in each pixel and the colour. The C64 version draws from the same rules, so this
// is where its geometry is worked out and proven.
//
// The game never reads the TIA's collision registers (it works out every hit itself), so the
// picture is all there is to get right.
//
//   node games/asteroids/tools/model.js [frames] [--seed=N] [--diff=B] [--verbose] [--show=<frame>]
// (the inputs come from tools/play.js)
//
// The picture (2600 lines, counted from the end of VSYNC):
//   40-49    score band: five 2-line rows of playfield digits (score left, lives right)
//   50-229   the field, 89 rows of 2 lines; one of two kernels, on alternate frames:
//            asteroids: two "threads", player 0 for asteroid slots 0-8 and player 1 for 9-17;
//                       P0's code runs on the even lines, P1's on the odd ones
//            ship:      player 0 the ship, player 1 the UFO / satellite, M0 and M1 the ship's
//                       shots and the ball the UFO's
//   every field line starts with HMOVE, so its first 8 pixels are blank (the HMOVE "comb")
// The background colour (COLUBK) is changed by the game logic around VSYNC, so lines outside
// the picture may show the old or the new one; colours are checked on lines 38-229.
// At power-on the game first shows "(c) 1981 Atari, Inc." for 256 frames (its own kernel).
'use strict';
const { VCS } = require('../../../tools/vcs');
const ROMMD5 = 'dd7884b4f93cab423ac471aa1935e3df';
const rom = require('../../../tools/rom').load(ROMMD5);

const KERNEL = 0xD57E;          // the game waits for its timer here, then draws the picture
const TITLE = 0xDB66;           // ... and here in the copyright screen's loop (after its VSYNC)
const B0 = a => rom[a & 0xFFF];                 // bank 0 (the kernels' tables)
const B1 = a => rom[0x1000 + (a & 0xFFF)];      // bank 1
const COLOURS = 0xDE75;         // asteroid colours, by A7 & 7
const sgn = v => ((v >> 4) ^ 8) - 8;           // HMxx: how far left the next HMOVE moves an object

// Where each positioning routine's RESPx/RESMx puts an object, from an X code (the $95,x
// format: bits 1-3 coarse delay, bit 0 early/late routine, bits 4-7 fine motion for the HMOVE).
// (Players appear 5 pixels after the reset, missiles 4.)
const coarse = code => {
  const c = (code >> 1) & 7, late = !(code & 1);
  return late ? 96 + 15 * (Math.min(Math.max(c, 1), 5) - 1) : 9 + 15 * (Math.min(Math.max(c, 1), 6) - 1);
};
const playerX = code => (coarse(code) - sgn(code) + 160) % 160;     // after its HMOVE
const missileX = code => (coarse(code) + 2 - sgn(code) + 160) % 160;

// ---- snapshot: RAM and the TIA registers as the picture starts
function snap(v, title = false) {
  return { ram: Uint8Array.from(v.ram), r: Uint8Array.from(v.r), title };
}

// The TIA's player pixel rules (as tools/vcs.js)
const COPIES = [[0], [0, 16], [0, 32], [0, 16, 32], [0, 64], [0], [0, 32, 64], [0]];
function playerPixels(g, nusiz, pos, refl, put) {
  if (!g) return;
  const scale = (nusiz & 7) === 5 ? 2 : (nusiz & 7) === 7 ? 4 : 1;
  for (const c of COPIES[nusiz & 7]) for (let i = 0; i < 8 * scale; i++) {
    let bit = Math.floor(i / scale);
    if (!(refl & 8)) bit = 7 - bit;
    if ((g >> bit) & 1) put((pos + c + i) % 160);
  }
}

// ---- the model: { ob, col } for 160 x 262 pixels (ob bits: 1 P0, 2 P1, 4 M0, 8 M1, 16 BL, 32 PF)
function model(s) {
  const R = a => s.ram[a - 0x80];
  const ob = new Uint8Array(160 * 262), col = new Uint8Array(160 * 262);
  const bk = s.r[9];
  col.fill(bk);
  if (s.title) return titleModel(s, ob, col);

  // ---------------------------------------------------------------- score band
  // Rows r = 4..0 on lines 40+2(4-r) and +1: left half PF0/PF1/PF2 = $FC/$FD/$FE, right half
  // 0/0/$FF, built from the digit pointers $F6-$FB into page $DD (two digits ORed per byte).
  const pfcol = s.r[8];
  const dig = (p, r) => B0(0xDD00 + ((p + r) & 0xFF));
  const pfLine = (y, left, right, from = 0, to = 160) => {
    for (let x = from; x < to; x++) {
      const half = x < 80 ? left : right, c = (x % 80) >> 2;
      const on = c < 4 ? (half[0] >> (4 + c)) & 1 : c < 12 ? (half[1] >> (11 - c)) & 1 : (half[2] >> (c - 12)) & 1;
      if (on) { ob[y * 160 + x] |= 32; col[y * 160 + x] = pfcol; }
    }
  };
  for (let r = 4; r >= 0; r--) {
    const left = [dig(R(0xF6), r), dig(R(0xF7), r) | dig(R(0xF8), r), dig(R(0xF9), r) | dig(R(0xFA), r)];
    const right = [0, 0, dig(R(0xFB), r)];
    const y = 40 + 2 * (4 - r);
    pfLine(y, left, right);
    // the last row's second line: PF2 is cleared at clock 219, so pixels 151-159 lose it
    pfLine(y + 1, left, right, 0, r ? 160 : 151);
    if (!r) pfLine(y + 1, left, [0, 0, 0], 151, 160);
  }

  const shipFrame = !(R(0xB9) & 1);
  // On asteroid frames the right half's PF2 is written at clock 147 on line 49: the left
  // half's last pixel (79) already shows it.
  if (!shipFrame) {
    const i = 49 * 160 + 79, on = (dig(R(0xFB), 0) >> 7) & 1;
    ob[i] = on ? ob[i] | 32 : ob[i] & ~32; col[i] = on ? pfcol : bk;
  }
  const lines = [];      // per field line: { g0, g1, n0, n1, p0, p1, c0, c1, en: [m0, m1, bl], cut }
  if (!shipFrame) asteroidKernel(s, R, lines); else shipKernel(s, R, lines);

  // ---------------------------------------------------------------- draw the field
  const mx = shipFrame ? [missileX(R(0xD3)), missileX(R(0xD4)), missileX(R(0xD5))] : [];
  const blcol = shipFrame ? R(0xE8) : 0;
  for (const L of lines) {
    const y = L.y;
    const put = bit => x => { if (x >= 8) ob[y * 160 + x] |= bit; };     // (0-7: the HMOVE blank)
    playerPixels(L.g1, L.n1, L.p1, L.refl1, put(2));
    playerPixels(L.g0, L.n0, L.p0, L.refl0, put(1));
    if (L.en) L.en.forEach((on, k) => { if (on && mx[k] >= 8) ob[y * 160 + mx[k]] |= [4, 8, 16][k]; });
    for (let x = 0; x < 160; x++) {      // colour: P0/M0 over P1/M1 over the ball
      const o = ob[y * 160 + x], i = y * 160 + x;
      col[i] = x < 8 ? 0 : o & 5 ? L.c0 : o & 10 ? L.c1 : o & 16 ? blcol : o & 32 ? col[i] : bk;   // (the blank is black)
    }
  }
  return { ob, col, shipFrame };
}

// ---------------------------------------------------------------- the asteroid field
// The kernel's two threads, row by row, as the 6502 code runs them (states are the low bytes
// of the jump vectors $E3 (P0) and $E5 (P1)).
function asteroidKernel(s, R, lines) {
  const z = new Uint8Array(256);
  for (let a = 0x80; a < 0x100; a++) z[a] = R(a);
  // the kernel's entry (line 49): each thread's first colour from slots 0 and 9
  let c0 = B0(COLOURS + (z[0xA7] & 7)), c1 = B0(COLOURS + (z[0xB0] & 7));
  z[0xF8] = z[0xA7] & 7; z[0xF9] = z[0xB0] & 7;
  let p0 = 0, p1 = 0, hm0 = 0, hm1 = 0;
  let g0 = 0, g1 = 0, n0 = 0, n1 = 0, ng0 = 0, nn0 = 0, ng1 = 0, nn1 = 0;
  for (let y = 50; y <= 229; y++) {
    p0 = (p0 - sgn(hm0) + 160) % 160; p1 = (p1 - sgn(hm1) + 160) % 160;     // HMOVE
    if (y & 1) { g0 = ng0; n0 = nn0; } else { g1 = ng1; n1 = nn1; }
    const line = { y, g0, g1, n0, n1, p0, p1, c0, c1 };
    lines.push(line);
    if (!(y & 1)) {
      // ---- player 0's code, row k = (y - 52) / 2
      const k = ((y - 52) >> 1) & 0xFF;
      hm1 = 0;
      switch (z[0xE3]) {
        case 0xC0: {                             // waiting for the next asteroid's row
          const x = z[0xDC];
          z[0xEB] = z[0xEF] = z[0x83 + x + 0x24] & 0x70; z[0xF8] = z[0x83 + x + 0x24] & 7;
          hm0 = 0; ng0 = 0; nn0 = 0;
          if (k === z[0x83 + x]) z[0xE3] = z[0xE9] & 1 ? 0x46 : 0x0E;
          break;
        }
        case 0x0E: case 0x46:                    // position it: RESP0, fine motion next line
          p0 = coarse(z[0xE9] & 0xF1 | Math.min(z[0xE7], 7) << 1) % 160;
          if (z[0xE7] === 0) throw new Error('coarse 0');
          hm0 = z[0xE9]; z[0xE3] = 0x83; ng0 = 0; nn0 = 0;
          break;
        case 0x83: {                             // draw a row
          const m = B0(z[0xF0] << 8 | z[0xEF]);
          if (!m) {
            const x = ++z[0xDC];
            z[0xE9] = z[0x95 + x]; z[0xE7] = (z[0xE9] >> 1) & 7; z[0xE3] = 0xC0;
            hm0 = 0; ng0 = 0; nn0 = 0;
          } else {
            hm0 = m; c0 = B0(COLOURS + z[0xF8]); ng0 = B0(z[0xEC] << 8 | z[0xEB]); nn0 = m;
            z[0xEB]++; z[0xEF]++;
          }
          break;
        }
        default: throw new Error('P0 state ' + z[0xE3].toString(16));
      }
    } else {
      // ---- player 1's code, row k = (y - 53) / 2
      const k = ((y - 53) >> 1) & 0xFF;
      hm0 = 0;
      let end = false;
      switch (z[0xE5]) {
        case 0xCF: {
          const x = z[0xDD];
          z[0xED] = z[0xF1] = z[0x83 + x + 0x24] & 0x70; z[0xF9] = z[0x83 + x + 0x24] & 7;
          hm1 = 0; ng1 = 0; nn1 = 0;
          if (k === z[0x83 + x]) z[0xE5] = z[0xEA] & 1 ? 0x45 : 0x0B;
          end = k + 1 === 0x59;
          break;
        }
        case 0x0B: case 0x45:
          end = k + 1 === 0x59;
          if (end && z[0xE5] === 0x0B) break;    // (the early routine checks before positioning)
          p1 = coarse(z[0xEA] & 0xF1 | Math.min(z[0xE8], 7) << 1) % 160;
          hm1 = z[0xEA]; z[0xE5] = 0x88; ng1 = 0; nn1 = 0;
          break;
        case 0x88: {
          const m = B0(z[0xF2] << 8 | z[0xF1]);
          if (!m) {
            const x = ++z[0xDD];
            z[0xEA] = z[0x95 + x]; z[0xE8] = (z[0xEA] >> 1) & 7; z[0xE5] = 0xCF;
            hm1 = 0; ng1 = 0; nn1 = 0;
          } else {
            hm1 = m; c1 = B0(COLOURS + z[0xF9]); ng1 = B0(z[0xEE] << 8 | z[0xED]); nn1 = m;
            z[0xED]++; z[0xF1]++;
          }
          end = k + 1 === 0x59;
          break;
        }
        default: throw new Error('P1 state ' + z[0xE5].toString(16));
      }
      if (end) break;
    }
  }
}

// ---------------------------------------------------------------- the ship frame
function shipKernel(s, R, lines) {
  const z = new Uint8Array(256);
  for (let a = 0x80; a < 0x100; a++) z[a] = R(a);
  const p0 = playerX(z[0xC9]), p1 = playerX(z[0xD1]);
  const vdel0 = z[0xEB] & 1, refl0 = z[0xEB] & 8, vdel1 = z[0xEC] & 1;
  const c0 = z[0xE9], c1 = z[0xEA];
  let g0 = 0, g1 = 0, old0 = 0, old1 = 0, en = [0, 0, 0];
  const wGRP0 = v => { g0 = v; old1 = g1; }, wGRP1 = v => { g1 = v; old0 = g0; };
  const show = y => lines.push({ y, g0: vdel0 ? old0 : g0, g1: vdel1 ? old1 : g1, n0: 0, n1: 0, p0, p1, c0, c1,
    refl0, refl1: 0, en: en.slice() });
  // lines 50-51 position the two players (graphics off); line 49 wrote GRP0, GRP1, GRP0 = 0
  wGRP0(0); wGRP1(0); wGRP0(0);
  show(50); show(51);
  let u = 0;
  const stream = (ptr, page, start, top, k) => {          // the ship's / UFO's graphics stream
    for (;;) {
      const a = B0(z[page] << 8 | z[ptr]);
      if (a !== 0xFF) { z[ptr]++; return a; }
      if (k !== z[top]) return 0;
      z[ptr] = z[start];
    }
  };
  for (let k = 0; k < 0x59; k++) {
    wGRP1(u);
    en = [k === z[0xD6], k === z[0xD7], k === z[0xD8]];
    show(52 + 2 * k);
    const sh = stream(0xED, 0xEE, 0xF1, 0xEF, k);
    wGRP0(sh);
    show(53 + 2 * k);
    u = stream(0xE6, 0xE7, 0xF2, 0xD2, k);
  }
}

// ---------------------------------------------------------------- the copyright screen
// 26 lines of six 8-pixel columns (players 0 and 1, three close copies each, both delayed)
// from page $DA, the 48-pixel text trick.
function titleModel(s, ob, col) {
  const R = a => s.ram[a - 0x80];
  const x0 = 54, top = 124;
  for (let i = 0; i <= 0x19; i++) {
    const y = top + (0x19 - i);
    for (let c = 0; c < 6; c++) {
      const g = B0(0xDA00 + R(0xF4 + 2 * c) + i);
      for (let b = 0; b < 8; b++) if ((g >> (7 - b)) & 1) {
        const x = x0 + 8 * c + b, k = y * 160 + x;
        ob[k] |= c & 1 ? 2 : 1; col[k] = 0x44;
      }
    }
  }
  return { ob, col, title: true };
}

module.exports = { model, snap, playerX, missileX, coarse, sgn, KERNEL, TITLE };
if (require.main !== module) return;

// ================================================================ the check
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const frames = +(process.argv[2] || 3000);
const verbose = process.argv.includes('--verbose');
const showFrame = arg('show', -1);
const vcs = new VCS(rom);
vcs.hmoveBlank = true;
let state = null;
const st = vcs.step.bind(vcs);
vcs.step = function () {
  if (this.pc === KERNEL || this.pc === TITLE) state = snap(this, this.pc === TITLE);
  return st();
};
const NAMES = { 1: 'P0', 2: 'P1', 4: 'M0', 8: 'M1', 16: 'BL', 32: 'PF' };
const bad = {}, ex = {};
let checked = 0, kinds = { title: 0, ship: 0, asteroids: 0 };
const seen = { ufo: 0, shots: 0, shipWrap: 0, partial: 0, background: 0 };
function picture(a, b, bit) {
  let y0 = 999, y1 = -1;
  for (let y = 0; y < 262; y++) for (let x = 0; x < 160; x++) if ((a[y * 160 + x] | b[y * 160 + x]) & bit) { y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
  for (let y = Math.max(0, y0 - 1); y <= Math.min(261, y1 + 1); y++) {
    let r = '';
    for (let x = 0; x < 160; x++) { const p = !!(a[y * 160 + x] & bit), q = !!(b[y * 160 + x] & bit); r += p && q ? '#' : p ? 'A' : q ? 'm' : '.'; }
    if (/[#Am]/.test(r)) console.log(String(y).padStart(3), r);
  }
}
vcs.onFrame = v => {
  if (!state) return;
  const s = state; state = null;
  let m;
  try { m = model(s); } catch (e) { bad.error = (bad.error || 0) + 1; ex.error = ex.error || `frame ${v.frames}: ${e.message}`; return; }
  checked++; kinds[m.title ? 'title' : m.shipFrame ? 'ship' : 'asteroids']++;
  const R = a => s.ram[a - 0x80];
  if (!m.title) {
    if (m.shipFrame && R(0xD2) !== 0xE0) seen.ufo++;
    if (m.shipFrame && R(0xCA) !== 0xE0 && R(0xCA) & 0x80) seen.shipWrap++;
    if (m.shipFrame && [0xD6, 0xD7, 0xD8].some(a => R(a) < 0x59)) seen.shots++;
    if (!m.shipFrame && (R(0xE3) !== 0xC0 || R(0xE5) !== 0xCF)) seen.partial++;
    if (s.r[9]) seen.background++;
  }
  for (const bit of [1, 2, 4, 8, 16, 32]) {
    let n = 0, first = null;
    for (let i = 0; i < 160 * 262; i++) {
      const a = !!(v.ob[i] & bit), b = !!(m.ob[i] & bit);
      if (a !== b) { n++; if (!first) first = `line ${Math.floor(i / 160)} x ${i % 160}: 2600 ${a ? 'on' : 'off'}`; }
    }
    if (n) { const k = NAMES[bit]; bad[k] = (bad[k] || 0) + 1; if (!ex[k] || verbose) ex[k] = `frame ${v.frames} (${m.shipFrame ? 'ship' : 'asteroids'}): ${n} pixels, ${first}`; if (verbose) console.log(k, ex[k]); }
    if (v.frames === showFrame && (n || verbose)) { console.log(NAMES[bit]); picture(v.ob, m.ob, bit); }
  }
  let n = 0, first = null;
  for (let i = 38 * 160; i < 230 * 160; i++) if (v.fb[i] !== m.col[i] >> 1) { n++; if (!first) first = `line ${Math.floor(i / 160)} x ${i % 160}: 2600 ${(v.fb[i] * 2).toString(16)} model ${m.col[i].toString(16)}`; }
  if (n) { bad.colour = (bad.colour || 0) + 1; if (!ex.colour || verbose) ex.colour = `frame ${v.frames}: ${n} pixels, ${first}`; }
};
const play = require('./play')(arg('seed', 11), { diffB: process.argv.includes('--diff=B') });
for (let f = 0; f < frames; f++) {
  const p = play(f, vcs.ram);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  vcs.runFrames(1);
}
console.log(`${checked} frames checked (${kinds.asteroids} asteroid frames, ${kinds.ship} ship frames, ${kinds.title} copyright)`);
console.log(`  with a UFO or satellite ${seen.ufo}, shots ${seen.shots}, the ship wrapping ${seen.shipWrap}, asteroids partly above the top ${seen.partial}, a coloured background ${seen.background}`);
for (const k of ['P0', 'P1', 'M0', 'M1', 'BL', 'PF', 'colour', 'error']) console.log(k.padEnd(6), bad[k] ? `${bad[k]} frames differ, e.g. ${ex[k]}` : 'exact');
