; =================================================================== sound
; The game's TIA sound registers, translated to SID voices 1 and 2 once a frame (Stargate's
; mapping: the TIA circuit's periods and duties; the envelope restarted only when the volume
; rises; very quiet starts left silent).
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   stx v3
        lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        bne _on
        jmp _off
_on     cmp #3
        bcs +
        lda SndOn,x
        bne +
        jmp _off
+       ldy v1
        lda SidWave,y
        bne +
        jmp _off2
+
        cpx #0                  ; (sync / ring, bits 1-2: only voice 1, by voice 3)
        beq +
        and #$f9
+       sta tmp                 ; waveform
        jsr Sync3
        lda v1                  ; frequency index = AUDC * 32 + AUDF
        lsr
        lsr
        lsr
        sta ptrA+1
        lda v1
        asl
        asl
        asl
        asl
        asl
        ora v2
        clc
        adc FreqTab
        sta ptrA
        lda ptrA+1
        adc FreqTab+1
        sta ptrA+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d400,y
        inc ptrA+1
        inc ptrA+1
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d401,y
        ldy v1                  ; the pulse width (the TIA waveform's duty)
        lda SidPWHi,y
        pha
        lda SidPWLo,y
        ldy tmp2
        sta $d402,y
        pla
        sta $d403,y
        lda v0                  ; volume becomes the sustain level (doubled for a narrow
        ldy v1                  ; pulse, SidBoost)
        ldx SidBoost,y
        beq +
        asl
        cmp #16
        bcc +
        lda #15
+       asl
        asl
        asl
        asl
        ldy tmp2
        sta $d406,y
        ldx v3                  ; (the channel)
        lda SndLast,x           ; the envelope restarted only when the volume rises
        cmp v0
        bcs +
        lda tmp
        sta $d404,y
+       lda tmp
        ora #1
        sta $d404,y
        lda #1
        sta SndOn,x
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
        sta SndOn,x
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts

; Sync3: waveform A with sync or ring (bits 1-2): voice 3 at its frequency for AUDC 15, AUDF v2
; (it restarts or ring-modulates voice 1)
Sync3:
        and #6
        beq _r
        ldy v2
        lda isPal
        beq +
        lda SyncLo,y
        sta $d40e
        lda SyncHi,y
        sta $d40f
        rts
+       lda SyncLoN,y
        sta $d40e
        lda SyncHiN,y
        sta $d40f
_r      rts


; Testing aid (tools/c64late.js): with DbgAuto set the C64 plays by itself, the inputs by the
; tick (the same game on PAL and NTSC, whatever the timing): steers for the middle of the water
; ahead of the plane, changes speed now and then, fires often, keeps the fuel up, Game Reset
; when no game is running. From tick AutoFrom to AutoTo the counters run; then they are kept
; in DbgAutoRes and DbgAuto becomes $80 (the inputs left alone).
AutoInput:
        lda DbgAuto
        bpl +
        rts
+       inc AutoT
        bne +
        inc AutoT+1
+       lda AutoT
        cmp AutoFrom
        bne +
        lda AutoT+1
        cmp AutoFrom+1
        bne +
        ldx #DbgAutoN - 1       ; AutoFrom: the counters from 0
        lda #0
-       sta DbgLoops,x
        dex
        bpl -
+       lda AutoT
        cmp AutoTo
        bne +
        lda AutoT+1
        cmp AutoTo+1
        bne +
        ldx #DbgAutoN - 1       ; AutoTo: the counters kept, the inputs left alone
-       lda DbgLoops,x
        sta DbgAutoRes,x
        dex
        bpl -
        lda #$80
        sta DbgAuto
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        sta INPT5
        rts
+       lda firstTick           ; (the power-on tick: the 2600's RAM not set up yet)
        beq +
        rts
+       lda AutoR               ; a random number (an 8-bit shift register)
        asl
        bcc +
        eor #$1d
+       sta AutoR
        lda State               ; no game: Game Reset after a while
        cmp #$ff
        bne _play
        inc AutoOver
        lda AutoOver
        cmp #60
        bcc +
        lda #0
        sta AutoOver
        lda SWCHB
        and #$fe
        sta SWCHB
+       lda #$ff
        sta SWCHA
        rts
_play   lda Fuel                ; the fuel kept up
        bmi +
        lda #$c0
        sta Fuel
+       lda AutoR               ; speed: now and then another
        and #$3f
        bne +
        lda AutoR
        and #$30
        ora #$c0
        sta AutoSpeed           ; ($C0 none, $D0 slow, $E0 fast, $F0 none)
+       lda AutoT               ; steer every fourth tick (the stick kept between)
        and #3
        beq +
        lda AutoStick
        jmp _st2
+       lda #160                ; steer: the water run under the plane on line 160
        jsr LineBO              ; (Collide's blocks: the last tick's)
        jsr PFRow
        lda PlaneX
        clc
        adc #4
        lsr
        lsr
        tax
        stx tmp                 ; (the plane's cell; at most 6 cells looked at either way)
        jsr Land
        beq _w                  ; land under it: the nearest water, left or right
        ldx tmp
        ldy #6
-       inx
        cpx #39
        bcs _left
        stx tmp2
        lda CellSel,x
        tax
        lda pfb,x
        ldx tmp2
        and CellMask,x
        beq _right
        dey
        bne -
_left   lda #$b0
        bne _st
_right  lda #$70
        bne _st
_w      ldx tmp                 ; water: its run's ends
        lda #6
        sta tmp3
-       dex
        bmi +
        stx tmp2
        lda CellSel,x
        tax
        lda pfb,x
        ldx tmp2
        and CellMask,x
        bne +
        dec tmp3
        bne -
+       stx tmp2
        ldx tmp
        lda #6
        sta tmp3
-       inx
        cpx #40
        bcs +
        stx tmp4
        lda CellSel,x
        tax
        lda pfb,x
        ldx tmp4
        and CellMask,x
        bne +
        dec tmp3
        bne -
+       txa                     ; the middle: (left + right) / 2 against the plane's cell
        clc
        adc tmp2
        ror a
        sec
        sbc tmp
        beq _mid
        bmi _left
        lda #$70
        bne _st
_mid    lda #$f0
_st     and AutoSpeed
        ora #$0f
        sta AutoStick
_st2    sta SWCHA
        lda AutoR               ; fire: often
        and #3
        bne +
        lda #0
        .byte $2c
+       lda #$80
        sta INPT4
        rts

SidVoice:   .byte 0, 7
FreqTab:    .word SidFreqLo     ; PAL or NTSC frequency tables
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0
outv:       .fill 3             ; ReadInput: SWCHA, INPT4, INPT5 being built
FireIn:     .byte $80, $80      ; ... INPT4, INPT5 as read (TickIn stores them again)
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
SndLast:    .fill 6, $ff
SndOn:      .fill 2
DbgSWCHA:   .byte $ff           ; testing aids: inputs poked from the VICE monitor (ANDed in)
DbgINPT4:   .byte $ff
DbgSWCHB:   .byte $ff
