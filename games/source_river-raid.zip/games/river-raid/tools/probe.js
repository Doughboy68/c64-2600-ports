// Records what the TIA shows on each line of a frame in tools/vcs.js: the registers sampled at
// pixel 47 (after the kernel's writes for the line), plus the RAM at the frame's start.
//   const probe = require('./probe'); probe.attach(vcs) -> vcs.lines[] after each frame
'use strict';
function attach(vcs, sampleAt = 47) {
  let cur = [], ramAtStart = null;
  const orig = vcs.pixel.bind(vcs);
  vcs.pixel = x => {
    if (x === sampleAt && vcs.line < 262) {
      const r = vcs.r;
      cur[vcs.line] = {
        pf0: r[0x0D], pf1: r[0x0E], pf2: r[0x0F], colupf: r[0x08], colubk: r[0x09], ctrlpf: r[0x0A],
        grp1: (r[0x26] & 1) ? vcs.grpOld[1] : r[0x1C], colup1: r[0x07], p1: vcs.pos[1], nusiz1: r[0x05], refp1: r[0x0C],
        grp0: (r[0x25] & 1) ? vcs.grpOld[0] : r[0x1B], colup0: r[0x06], p0: vcs.pos[0], nusiz0: r[0x04], refp0: r[0x0B],
        enam0: r[0x1D], m0: vcs.pos[2], vblank: r[0x01],
      };
    }
    orig(x);
  };
  const prev = vcs.onFrame;
  vcs.onFrame = v => {
    v.lines = cur; v.ramStart = ramAtStart; cur = [];
    if (prev) prev(v);
  };
  return vcs;
}
module.exports = { attach };
