// A player for the checks, deterministic from a seed. Random: steers left and right, speeds up
// and slows down, fires often. Smart (opts.smart, the default): looks at the 2600's last picture
// (vcs.ob, the objects drawn on each pixel) a little above the plane and steers for the middle of
// the water there, so it flies on down the river; now and then it steers for an object or the
// bank instead, or lets go, so every kind of collision happens. Presses Game Reset some time
// after a game ends (and Game Select now and then).
//   const play = require('./play')(seed, opts); each frame: play.step(vcs)
//   sets vcs.swcha / fire / swchb (SWCHA high nibble, active low: $7F right, $BF left, $DF down, $EF up)
module.exports = function (seed = 1, opts = {}) {
  let s = seed * 16807 % 2147483647 || 1;
  const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
  const smart = opts.smart !== false;
  const DIRS = [0x7F, 0xBF, 0xFF, 0xEF, 0xDF, 0x6F, 0xAF, 0x5F, 0x9F];
  let hold = 0, dir = 0xFF, fireLeft = 0, resetLeft = 0, selectLeft = 0, frame = 0, over = 0;
  let mode = 'water', modeLeft = 0, speed = 0xF0, speedLeft = 0;
  return {
    step(vcs) {
      frame++;
      const ram = a => (vcs.ram ? vcs.ram[a - 0x80] : vcs.mem[a]);
      vcs.swchb |= 3;
      if (ram(0xC6) === 0xFF) over++; else over = 0;
      if (over === 100 && rnd() < 0.2) selectLeft = 3;
      if (over > 150 || frame === 5) { resetLeft = 3; over = 0; }
      if (selectLeft-- > 0) vcs.swchb &= ~2;
      else if (resetLeft-- > 0) vcs.swchb &= ~1;
      if (fireLeft <= -2 && rnd() < (opts.fire ?? 0.3)) fireLeft = 1 + Math.floor(rnd() * 3);
      vcs.fire[0] = fireLeft-- > 0;
      if (!smart || !vcs.ob) {
        if (hold-- <= 0) { hold = 5 + Math.floor(rnd() * 40); dir = DIRS[Math.floor(rnd() * DIRS.length)]; }
        vcs.swcha = dir | 0x0F;
        return;
      }
      if (modeLeft-- <= 0) {
        const r = rnd();
        mode = r < 0.8 ? 'water' : r < 0.9 ? 'object' : r < 0.96 ? 'bank' : 'free';
        modeLeft = 20 + Math.floor(rnd() * 100);
      }
      if (speedLeft-- <= 0) { speed = [0xF0, 0xF0, 0xE0, 0xD0][Math.floor(rnd() * 4)]; speedLeft = 10 + Math.floor(rnd() * 80); }
      const px = ram(0xB3) + 4;
      const ob = (L, x) => vcs.ob[L * 160 + x];
      let target = px;
      const L = 165 + Math.floor(rnd() * 10);
      if (mode === 'object') {
        let best = -1;
        for (let y = 120; y < 180; y++) for (let x = 8; x < 160; x++) if (ob(y, x) & 2 && (best < 0 || Math.abs(x - px) < Math.abs(best - px))) best = x;
        if (best >= 0) target = best;
      } else if (mode === 'water' || mode === 'bank') {
        // the water runs on the line, the one nearest the plane
        let runs = [], a = -1;
        for (let x = 8; x <= 160; x++) {
          const w = x < 160 && !(ob(L, x) & 32);
          if (w && a < 0) a = x;
          if (!w && a >= 0) { runs.push([a, x - 1]); a = -1; }
        }
        let near = null;
        for (const r of runs) if (!near || Math.min(Math.abs(r[0] - px), Math.abs(r[1] - px)) < Math.min(Math.abs(near[0] - px), Math.abs(near[1] - px))) near = r;
        if (near) target = mode === 'water' ? (near[0] + near[1]) >> 1 : (rnd() < 0.5 ? near[0] - 2 : near[1] + 2);
      }
      let d = mode === 'free' ? 0 : target - px;
      dir = Math.abs(d) < 3 ? 0xF0 : d > 0 ? 0x70 : 0xB0;
      if (mode === 'free' && hold-- <= 0) { hold = 5 + Math.floor(rnd() * 30); dir = DIRS[Math.floor(rnd() * DIRS.length)] & 0xF0; }
      vcs.swcha = (dir & speed) | 0x0F;
    },
  };
};
