// Run the C64 port's game ticks (the patched 2600 program plus our collision code, from
// build/riverraid-<version>.prg) on a plain 6502 with 64K of memory, side by side with the
// original game in tools/vcs.js, with the same inputs. Every frame the two must have:
//   - the same 2600 RAM where the kernel starts ($F12E; the C64 at KernelHook), and
//   - after the picture ($F489; the C64 when its tick returns) the same collision results and
//     the RAM the kernel leaves.
// Any difference is a bug in a patch or in the collisions. Render runs each frame too (crashes,
// cycles).
//   node games/river-raid/tools/lockstep.js [frames] [--seed=N] [--power=F] [--verbose]
//        [--profile[=Label]] [--slow=cycles] [--bw (black and white, F5)] [--diff=A (both difficulties A)]
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('393948436d1f4cc3192410bb918f9724');
const build = process.env.RR_BUILD || path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 3000);
const WATCH = arg('watch', 0);
const verbose = process.argv.includes('--verbose');

// ---- the C64 side: the VCS 6502 core on a flat 64K memory
class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) {
    a &= 0xFFFF;
    // the 2600 program must keep out of the C64's zero page: $00 / $01 and ours at $40-$7F
    if (this.pc >= 0xF000 && (a < 2 || (a >= 0x40 && a < 0x80))) throw new Error(`the 2600 code at $${this.pc.toString(16)} wrote $${a.toString(16)}`);
    if (WATCH && a === WATCH && this.pc < 0xF000) console.log(`write ${a.toString(16)} = ${v} at ${this.pc.toString(16)} (${labelOf(this.pc)})`);
    this.mem[a] = v;
  }
  commit() {}
  flush() {}
  tick(n) { this.cycles += n; }
  call(addr, limit = 2e6) {      // JSR addr from a stub, run until it returns
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    const start = this.cycles;
    const ring = [];
    for (let i = 0; this.pc !== STUB + 3; i++) { ring[i & 31] = this.pc; this.step(); if (i > limit) throw new Error(`runaway at $${this.pc.toString(16)}; last PCs ${ring.map(p => p.toString(16)).join(' ')}; X ${this.x} Y ${this.y} A ${this.a}`); }
    return this.cycles - start;
  }
}
const c64 = new C64();
const labels = [...lst.matchAll(/^[.>]([0-9a-f]{4})\t(?:([0-9a-f]{4})\t)?.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[2] || m[1], 16), m[3]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xF000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
const profile = process.argv.some(a => a === '--profile' || a.startsWith('--profile=')) ? {} : null;
const profLabel = arg('profile', null);
const pcProfile = typeof profLabel === 'string' ? {} : null;
const slow = arg('slow', 0);
const frameProf = slow ? {} : null;
const HOOK = sym('KernelHook');
const TRACE = arg('trace', null) ? new Set(String(arg('trace')).split(',').map(n => /^[0-9a-f]{4}$/.test(n) ? parseInt(n, 16) : sym(n))) : null;
let curF = 0;
let hookRam = null;
{ const st = c64.step.bind(c64);
  c64.step = function () {
    const pc = this.pc, c = this.cycles;
    if (pc === HOOK && !hookRam) hookRam = this.mem.slice(0x80, 0x100);
    if (TRACE && TRACE.has(pc) && curF >= arg('from', 0)) console.log(`  ${labelOf(pc)} ${pc.toString(16)} A ${this.a.toString(16)} X ${this.x.toString(16)} Y ${this.y.toString(16)}`);
    const r = st();
    if (profile || frameProf) { const k = labelOf(pc), d = this.cycles - c;
      if (profile) { profile[k] = (profile[k] || 0) + d; if (pcProfile && k === profLabel) pcProfile[pc] = (pcProfile[pc] || 0) + d; }
      if (frameProf) frameProf[k] = (frameProf[k] || 0) + d; }
    return r;
  }; }
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
// what Start does that matters here: the program's parts (the 2600 image at $F000 among them)
// where they run, the working variables cleared, the RIOT ports, the fire buttons
c64.call(sym('Relocate'));
for (let a = 0xC000; a < 0xD000; a++) c64.mem[a] = 0;
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x0C] = 0x80; c64.mem[0x0D] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));
if (lst.includes('\tPreObj:')) c64.call(sym('PreObj'));   // (the objects' images made ahead, as Start does)

// ---- the original
const vcs = new VCS(rom);
const runTo = pc => { let g = 0; do { vcs.step(); if (++g > 2e6) throw new Error('2600 never got there'); } while (vcs.pc !== pc); };

const NAMES = {};
for (const [a, n, size] of require('../2600/symbols.js').ram) for (let i = 0; i < size; i++) NAMES[a + i] = size > 1 ? `${n}+${i}` : n;
// at the kernel's start: the 2600's stack holds the kernel's entry ($FE / $FF), ours is the C64's
const IGNORE_A = new Set([0xFE, 0xFF]);

const play = require('./play')(arg('seed', 1));
const power = arg('power', 0);
const perFrame = [];
let maxCycles = 0, totalCycles = 0, bad = 0, done = 0, maxRender = 0, totalRender = 0;
const hits = { e2: 0, e4: 0, e6: 0, e8: 0, p1f: 0 };
for (let f = 0; f < frames; f++) {
  curF = f;
  play.step(vcs);
  if (process.argv.includes('--bw')) vcs.swchb &= ~8;          // (F5: black and white)
  if (arg('diff', '') === 'A') vcs.swchb |= 0xC0;               // (F7 / F8: both difficulties A)
  c64.mem[0x0280] = vcs.swcha; c64.mem[0x0C] = vcs.fire[0] ? 0 : 0x80; c64.mem[0x0D] = vcs.fire[1] ? 0 : 0x80; c64.mem[0x0282] = vcs.swchb;
  if (power && f === power) { c64.call(sym('PowerCycle')); vcs.pc = 0xF000; vcs.s = 0xFD; }   // F2 on both
  runTo(0xF12E);
  const ramA = vcs.ram.slice(), tiaA = vcs.r.slice();
  runTo(0xF489);
  if (frameProf) for (const k in frameProf) delete frameProf[k];
  hookRam = null;
  const cyc = c64.call(sym('Tick'));
  maxCycles = Math.max(maxCycles, cyc); totalCycles += cyc;
  const rc = c64.call(sym('Render'));
  c64.mem[sym('curBuf')] = c64.mem[sym('rbuf')];
  maxRender = Math.max(maxRender, rc); totalRender += rc;
  if (f > 10) perFrame.push(cyc + rc);
  if (slow && cyc + rc > slow && f > 5) console.log(`frame ${f}: tick ${cyc} + render ${rc}: ` + Object.entries(frameProf).filter(e => e[1] > 200).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([k, v]) => k + ' ' + v).join(', '));
  done++;
  const diffs = [];
  if (!hookRam) diffs.push('the C64 tick never reached KernelHook');
  else for (let a = 0x80; a < 0x100; a++) if (!IGNORE_A.has(a) && ramA[a - 0x80] !== hookRam[a - 0x80])
    diffs.push(`${NAMES[a] || '$' + a.toString(16)} 2600 ${ramA[a - 0x80].toString(16)} C64 ${hookRam[a - 0x80].toString(16)}`);
  const v = a => vcs.ram[a - 0x80];
  const flagsMask = a => { if (a < 0x8E || a > 0x94) return 0xFF; if (a === 0x94) return 0xDF; const t = v(0xA0 + a - 0x8E); return t >= 5 && t <= 7 ? 0xFF : 0xDF; };
  for (let a = 0x80; a < 0x100; a++) if ((v(a) ^ c64.mem[a]) & flagsMask(a)) diffs.push(`after: ${NAMES[a] || '$' + a.toString(16)} 2600 ${v(a).toString(16)} C64 ${c64.mem[a].toString(16)}`);
  for (let b = 0; b < 6; b++) {
    const t = v(0xA0 + b);
    if (t >= 5 && t <= 7 && (v(0x8E + b) & 0x20)) hits.p1f++;
  }
  for (const k of ['e2', 'e4', 'e6', 'e8']) if (v(parseInt(k.slice(1), 16) + 0xE0) !== 0xFF) hits[k]++;
  if (diffs.length) {
    bad++;
    if (bad <= 3 || verbose) console.log(`frame ${f} (Scroll ${ramA[0x0B]}): ${diffs.join(', ')}`);
    if (process.argv.includes('--why')) { const model = require('./model'); const kr = new Uint8Array(256); kr.set(ramA, 0x80); const ls = model.lines(kr); const cx = model.collide(kr, ls, tiaA); { const M = (n, k = 1) => [...c64.mem.slice(sym(n), sym(n) + k)].map(q => q.toString(16)).join(','); console.log('  C64 PHN', M('PHN'), 'PHL', M('PHL', 18), 'PHA', M('PHA', 18), 'PHB', M('PHB', 18), 'PHP', M('PHP', 18), 'SHN', M('SHN'), 'OHN', M('OHN'), 'p0x', M('p0x'), 'PComb', M('PComb'), 'PSel', M('PSel', 3), 'PMask', M('PMask', 3)); }
      { const col = new Uint8Array(160), ob = new Uint8Array(160); const pl = []; for (const q of ls) { model.linePixels(q, tiaA, col, ob); const xs = []; for (let x = 0; x < 160; x++) if ((ob[x] & 2) && (ob[x] & 32)) xs.push(x); if (xs.length) pl.push(`${q.line}(b${q.b} o${q.o}):${xs.join('/')} g${q.grp1.toString(16)}@${q.p1}`); } console.log('  P1F pixels', pl.join(' '), 'types', [...ramA.slice(0x20, 0x26)].join(','), 'flags', [...ramA.slice(0x0E, 0x14)].map(q => q.toString(16)).join(',')); }
      console.log('  model', JSON.stringify(cx), 'plane lines', ls.filter(q => q.grp0 && q.grp1).map(q => `${q.line}:${q.grp0.toString(16)}@${q.p0}/${q.grp1.toString(16)}@${q.p1}n${q.nusiz1}`).join(' ')); }
    if (bad === 3 && !verbose) { console.log('... stopping'); break; }
    for (let a = 0x80; a < 0x100; a++) c64.mem[a] = vcs.ram[a - 0x80];   // resync and carry on
  }
}
if (profile) {
  const tot = Object.values(profile).reduce((a, b) => a + b, 0);
  for (const [k, v] of Object.entries(profile).sort((a, b) => b[1] - a[1]).slice(0, 30)) console.log(k.padEnd(16), String(Math.round(v / done)).padStart(7), (100 * v / tot).toFixed(1) + '%');
  if (pcProfile) for (const [pc, v] of Object.entries(pcProfile).sort((a, b) => a[0] - b[0])) console.log('  $' + (+pc).toString(16), Math.round(v / done));
}
console.log(`${done} frames, ${bad} with differences; hits seen ${JSON.stringify(hits)}; C64 tick: ${Math.round(totalCycles / done)} cycles on average, ${maxCycles} at most; render: ${Math.round(totalRender / done)} on average, ${maxRender} at most`);
{ const q = perFrame.slice().sort((a, b) => a - b), at = x => q[Math.min(q.length - 1, Math.floor(x * q.length))];
  if (q.length) console.log(`tick + render per frame: median ${at(0.5)}, 90% ${at(0.9)}, 99% ${at(0.99)}, 99.9% ${at(0.999)}, most ${q[q.length - 1]}`); }
process.exit(bad ? 1 : 0);
