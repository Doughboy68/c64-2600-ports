// The raster interrupt in VICE: starts its own VICE (PAL, or NTSC with --ntsc), runs the build's
// self-playing game for a while, turns on DbgBorder (the interrupt logs its entry and exit lines
// in DbgLog) for a moment, then prints the log's last frames beside the shown buffer's events.
// Closes only the VICE it started.
//   node games/river-raid/tools/c64irq.js [--ntsc] [--at=seconds] [--keep]
const net = require('net');
const fs = require('fs');
const path = require('path');
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
const ntsc = process.argv.includes('--ntsc'), keep = process.argv.includes('--keep');
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const build = process.env.RR_BUILD || path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const lst = fs.readFileSync(files.lst, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return parseInt(m[2] || m[1], 16);
};
const hex = n => n.toString(16);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let PORT = 0, vice = null;
const mon = cmds => new Promise((resolve, reject) => {
  const s = net.connect(PORT, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d.toString('latin1'); }); s.on('error', reject);
  s.on('connect', async () => {
    await sleep(150);
    for (const c of cmds) { s.write(c + '\n'); await sleep(400); }
    s.write('x\n'); await sleep(100); s.end(); resolve(b);
  });
});
const dump = async (lo, hi) => {
  const o = await mon([`m ${hex(lo)} ${hex(hi)}`]);
  const mem = {};
  for (const m of o.matchAll(/>C:([0-9a-f]{4})((?:\s+[0-9a-f]{2}\b)+)/gi))
    m[2].trim().split(/\s+/).forEach((x, k) => { mem[parseInt(m[1], 16) + k] = parseInt(x, 16); });
  return mem;
};

(async () => {
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound',
    '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', files.prg]);
  let ok = false;
  for (let t = 0; t < 40 && !ok; t++) { await sleep(1000); try { ok = await runsOurs(mon, files.prg); } catch { /* not up yet */ } }
  if (!ok) throw new Error(`the VICE on port ${PORT} isn't running ${path.basename(files.prg)}: stopping`);
  await sleep(1000);
  const A = { auto: addr('DbgAuto'), t: addr('AutoT'), power: addr('PowerReq'), from: addr('AutoFrom'), border: addr('DbgBorder'),
    log: addr('DbgLog'), logi: addr('DbgLogI'), ras: addr('EvRas'), reg: addr('EvReg'), val: addr('EvVal'), cur: addr('curBuf'), base: addr('EvBaseOf') };
  await mon([`> ${hex(A.t)} 0 0`, `> ${hex(A.from)} 60 ea 61 ea`, `> ${hex(A.auto)} 1`, `> ${hex(A.power)} 1`]);
  await sleep(1000 * +opt('at', 8));
  await mon([`> ${hex(A.border)} 81`]);
  await sleep(60);
  const out = await mon([`> ${hex(A.border)} 0`,
    `m ${hex(A.log)} ${hex(A.log + 255)}`, `m ${hex(A.logi)} ${hex(A.logi)}`, `m ${hex(A.cur)} ${hex(A.cur)}`,
    `m ${hex(A.ras)} ${hex(A.val + 48 * 3 - 1)}`, `m ${hex(A.base)} ${hex(A.base + 2)}`]);
  const mem = {};
  for (const m of out.matchAll(/>C:([0-9a-f]{4})((?:\s+[0-9a-f]{2}\b)+)/gi))
    m[2].trim().split(/\s+/).forEach((x, k) => { mem[parseInt(m[1], 16) + k] = parseInt(x, 16); });
  const n = mem[A.logi], log = [];
  for (let i = 0; i + 1 < n; i += 2) log.push([mem[A.log + i], mem[A.log + i + 1]]);
  // frames: a new frame where the entry line goes down
  let s = '', lines = 0, frames = 0;
  for (let i = 0; i < log.length; i++) {
    if (i && log[i][0] < log[i - 1][0] && log[i][0] < 30) { console.log(s + `  | ${lines} lines`); s = ''; lines = 0; frames++; }
    const d = (log[i][1] - log[i][0] + 256) % 256;
    lines += d;
    s += ` ${log[i][0]}-${log[i][1]}`;
  }
  console.log(s);
  const cur = mem[A.cur], base = mem[A.base + cur];
  const ev = [];
  for (let i = base; i < base + 48; i++) {
    ev.push(`${mem[A.ras + i]}:${hex(mem[A.reg + i])}=${hex(mem[A.val + i])}`);
    if (mem[A.ras + i] === 251) break;
  }
  console.log(`buffer ${cur}'s events:`, ev.join(' '));
  if (keep) console.log(`VICE left running: monitor port ${PORT}, pid ${vice.pid}`);
  else stopVice(vice);
})().catch(e => { console.log(e.message); stopVice(vice); });
