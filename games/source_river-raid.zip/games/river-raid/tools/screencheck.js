// Draws the C64 picture from what the C64 code set up for a frame and compares it, in C64
// colours, with the 2600's (tools/vcs.js, its colours through the port's ColorMap), over a game
// played by tools/play.js (the C64 code run on the 6502 core as lockstep.js does).
// The C64 side, line by line from raster 0: the buffer's registers as FrameTop sets them, then its
// events in order (register writes; a block's stage code run in the 6502 core on its line, its
// register and sprite pointer writes taking effect from the next line; the panel's and the
// logo's); multicolour characters with the VIC's badlines (YSCROLL; a badline restarts the row's
// line counter, so the panel's rows come again from 216), the display window (24 rows, 25 from
// the panel's event), colour RAM all "black, multicolour"; multicolour sprites with the VIC's
// restart rule (an unexpanded sprite starts again only 22 lines after its last start), X
// expansion, behind "10" / "11" where $D01B says, the lower numbered in front.
// The logo is two lines higher on the C64 (its last line would be in the bottom border): its
// lines are compared with the 2600's two lines lower.
//   node games/river-raid/tools/screencheck.js [frames] [--seed=N] [--from=F] [--lines=A-B (37-232)]
//        [--events=F (that frame's events and what each block's stage code writes)]
//        [--png=dir (each differing frame: 2600 left, C64 right)] [--show=F] [--verbose]
//        [--bw (black and white, F5)] [--diff=A (both difficulties A, F7 / F8)]
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('393948436d1f4cc3192410bb918f9724');
const build = process.env.RR_BUILD || path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  let m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?\\t*${name}\\s*$`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
const cst = name => {
  const m = lst.match(new RegExp(`^=(\\$?)([0-9a-f]+)\\t+${name}\\s+=`, 'm'));
  if (!m) throw new Error('no constant ' + name);
  return parseInt(m[2], m[1] ? 16 : 10);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 1000);
const verbose = process.argv.includes('--verbose');
const pngDir = arg('png', null), showFrame = arg('show', -1), fromFrame = arg('from', 3);
const [LFIRST, LLAST] = String(arg('lines', '37-232')).split('-').map(Number);

let io = null;     // (the stage code's register writes, while it runs)
class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) { a &= 0xFFFF; if (io && a >= 0xD000 && a < 0xD400) { io.push([a, v]); return; } if (io && a < 0xD000 && a >= 0x4000 && a < 0x8000) io.push([a, v]); this.mem[a] = v; }
  commit() {} flush() {} tick(n) { this.cycles += n; }
  call(addr, limit = 3e6) {
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error('runaway at $' + this.pc.toString(16)); }
  }
  runTo(addr, stop, limit = 5000) {   // from addr until the PC is stop (an interrupt handler's code)
    this.pc = addr;
    for (let i = 0; this.pc !== stop; i++) { this.step(); if (i > limit) throw new Error('stage code runaway at $' + this.pc.toString(16)); }
  }
}
const c64 = new C64();
c64.mem.fill(0xAA);     // (RAM the program doesn't load or clear: junk, as on a real C64)
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
c64.call(sym('Relocate'));
for (let a = 0xC000; a < 0xD000; a++) c64.mem[a] = 0;
for (let a = 2; a < 0x100; a++) c64.mem[a] = 0;      // (as Start)
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x0C] = 0x80; c64.mem[0x0D] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));
if (lst.includes('\tPreObj:')) c64.call(sym('PreObj'));
const M = a => c64.mem[a];
const S = {};
for (const n of ['StScr', 'StD018', 'StD011', 'StStat', 'StD021', 'StD022', 'StDigit', 'StX0', 'StY0', 'StX1', 'StY1', 'StMsb', 'StEn',
  'StCol0', 'StCol1', 'StPtr0', 'StPtr1', 'StPanelBg', 'StGauge', 'StNeedle', 'EvBaseOf', 'EvRas', 'EvArm', 'EvLo', 'EvHi', 'EvReg', 'EvVal',
  'ScrPtrHi', 'ColorMap', 'curBuf', 'rbuf', 'irqT', 'irqP', 'irqPM', 'irqPE', 'IrqNextEv',
  'IrqWrite', 'IrqBad', 'IrqStat', 'IrqLogo', 'IrqEnd']) S[n] = sym(n);
const NEV = cst('NEV'), LINEOFS = cst('LINEOFS'), LOGOY = cst('LOGOY');

const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
const runTo = pc => { let g = 0; do { vcs.step(); if (++g > 2e6) throw new Error('2600 never got there'); } while (vcs.pc !== pc); };

// the VIC's registers, kept from frame to frame (as the real ones: what FrameTop doesn't set stays)
const R = new Uint8Array(0x40);
R[0x16] = 0x18; R[0x17] = 0; R[0x20] = 0;

// The C64 picture of buffer buf: a C64 colour per 2600 pixel by raster line, and what drew it
function c64Picture(buf, frame) {
  const show = frame === arg('events', -1);
  const col = new Uint8Array(160 * 312), src = new Array(160 * 312).fill('');
  // FrameTop
  const st = n => M(S[n] + buf);
  R[0x11] = st('StD011'); R[0x18] = st('StD018'); R[0x21] = st('StD021'); R[0x22] = st('StD022'); R[0x23] = st('StDigit');
  R[0x1c] = 0xff; R[0x1b] = 0xff; R[0x1d] = 0;
  R[0x00] = st('StX0'); R[0x01] = st('StY0'); R[0x02] = st('StX1'); R[0x03] = st('StY1'); R[0x10] = st('StMsb'); R[0x15] = st('StEn');
  R[0x27] = st('StCol0'); R[0x28] = st('StCol1');
  const ptrBase = M(S.ScrPtrHi + st('StScr')) << 8 | 0xF8;
  c64.mem[ptrBase] = st('StPtr0'); c64.mem[ptrBase + 1] = st('StPtr1');
  c64.mem[cst('STATA') + 0x3fa] = c64.mem[cst('STATB') + 0x3fa] = cst('BLK_BLANK');
  c64.mem[S.irqP] = 0xF8; c64.mem[S.irqP + 1] = ptrBase >> 8; c64.mem[S.irqPM] = st('StMsb'); c64.mem[S.irqPE] = st('StEn');
  // the events: [first line it shows on, apply()]
  const evs = [];
  const base = M(S.EvBaseOf + buf);
  for (let i = base; i < base + NEV; i++) {
    const h = M(S.EvLo + i) | M(S.EvHi + i) << 8, ras = M(S.EvRas + i), reg = M(S.EvReg + i), val = M(S.EvVal + i);
    if (h === S.IrqEnd) break;
    if (h === S.IrqWrite || h === S.IrqBad) evs.push([ras, () => { R[reg & 0x3f] = val; }]);
    else if (h === S.IrqStat) {
      evs.push([ras + 1, () => { R[0x11] = 0x18; R[0x18] = st('StStat'); R[0x21] = st('StPanelBg'); R[0x22] = st('StGauge'); }]);
    }
    else if (h === S.IrqLogo) evs.push([ras + 1, () => {
      R[0x23] = st('StNeedle'); R[0x27] = R[0x28] = st('StDigit'); R[0x00] = 24 + 2 * 56; R[0x02] = 24 + 2 * 80; R[0x01] = R[0x03] = LOGOY;
      c64.mem[cst('STATA') + 0x3fa] = c64.mem[cst('STATB') + 0x3fa] = cst('BLK_COMB');
      R[0x04] = 24; R[0x05] = cst('COMBY'); R[0x29] = 0;
      R[0x10] = 0; R[0x1b] = 0; R[0x1c] = 0xf8; R[0x1d] = 3; R[0x15] = 7; }]);
    else evs.push([ras + 1, () => {      // a block's stage: its code, run as the interrupt would
      c64.mem[S.irqT] = ras; c64.mem[0xD012] = ras;
      const sv = [c64.a, c64.x, c64.y, c64.s, c64.p];
      io = [];
      c64.runTo(h, S.IrqNextEv);
      for (const [a, v] of io) if (a >= 0xD000 && a < 0xD400) R[a & 0x3f] = v;
      if (show) console.log(`  line ${ras}: stage at $${h.toString(16)}: ` + io.map(([a, v]) => `${a.toString(16)}=${v}`).join(" "));
      io = null;
      [c64.a, c64.x, c64.y, c64.s, c64.p] = sv;
    }]);
  }
  for (let k = 0; k < M(sym('FoldN') + buf); k++) { const j = 3 * buf + k, v = M(sym('FoldV') + j); evs.push([M(sym('FoldL') + j), () => { R[0x22] = v; }]); }   // (the panel's interrupt's)
  evs.sort((a, b) => a[0] - b[0]);
  if (show) for (let i = base; i < base + NEV; i++) { const h = M(S.EvLo + i) | M(S.EvHi + i) << 8; console.log(`  event ${i - base}: line ${M(S.EvRas + i)} armed ${M(S.EvArm + i)} handler $${h.toString(16)} reg ${M(S.EvReg + i).toString(16)} value ${M(S.EvVal + i)}`); if (h === S.IrqEnd) break; }
  // the raster lines
  let ei = 0, vcbase = 0, vc = 0, rc = 0, display = false, row = new Uint8Array(40);
  const sp = [...Array(8)].map(() => ({ start: -100, row: -1 }));
  for (let r = 0; r < 251 + 1; r++) {
    while (ei < evs.length && evs[ei][0] <= r) evs[ei++][1]();
    const yscroll = R[0x11] & 7;
    const bad = r >= 48 && r <= 247 && (r & 7) === yscroll;
    if (bad) { vc = vcbase; rc = 0; display = true; const scr = 0x4000 + (R[0x18] >> 4) * 0x400; for (let c = 0; c < 40; c++) row[c] = M(scr + vc + c); }
    // sprite starts: the Y compare on the line before; a running sprite can't start again
    // until 22 lines after its start
    for (let n = 0; n < 8; n++) {
      const s = sp[n];
      if (((R[0x15] >> n) & 1) && R[1 + 2 * n] === r - 1 && r - s.start >= 22) s.start = r;
      s.row = r - s.start < 21 ? r - s.start : -1;
    }
    const top = (R[0x11] & 8) ? 51 : 55, bottom = (R[0x11] & 8) ? 251 : 247;
    if (r >= LFIRST + LINEOFS && r <= LLAST + LINEOFS) {
      const L = r - LINEOFS, cs = 0x4000 + ((R[0x18] >> 1) & 7) * 0x800;
      const scrP = 0x4000 + (R[0x18] >> 4) * 0x400 + 0x3F8;
      for (let x = 0; x < 160; x++) {
        let colour, who, cls = 0;
        if (r < top || r >= bottom) { colour = R[0x20] & 15; who = 'border'; }
        else {
          if (display) {
            const byte = M(cs + row[x >> 2] * 8 + rc);
            cls = (byte >> (6 - 2 * (x & 3))) & 3;
            colour = cls === 0 ? R[0x21] & 15 : cls === 1 ? R[0x22] & 15 : cls === 2 ? R[0x23] & 15 : M(0xD800) & 7;
          } else {   // (idle: the bank's last byte, as hires pixels: 1 black, 0 the background)
            const bit = (M(0x7FFF) >> (7 - ((2 * x) & 7))) & 1;
            colour = bit ? 0 : R[0x21] & 15; cls = 0;
          }
          who = 'c' + cls;
          for (let n = 0; n < 8; n++) {
            const s = sp[n];
            if (s.row < 0) continue;
            if (cls >= 2 && ((R[0x1b] >> n) & 1)) continue;   // (behind "10" and "11")
            const sx = R[2 * n] + ((R[0x10] >> n) & 1) * 256, ex = (R[0x1d] >> n) & 1;
            const d = (24 + 2 * x - sx) >> ex;                  // (its hires pixel, unexpanded)
            if (d < 0 || d >= 24) continue;
            const data = M(0x4000 + M(scrP + n) * 64 + s.row * 3 + (d >> 3));
            let c;
            if ((R[0x1c] >> n) & 1) { const pr = (data >> (6 - 2 * ((d & 7) >> 1))) & 3; c = pr === 0 ? -1 : pr === 1 ? R[0x25] : pr === 2 ? R[0x27 + n] : R[0x26]; }
            else c = (data >> (7 - (d & 7))) & 1 ? R[0x27 + n] : -1;
            if (c >= 0) { colour = c & 15; who = 's' + n; break; }
          }
        }
        col[L * 160 + x] = colour; src[L * 160 + x] = who;
      }
    }
    // the line's end: the row's last line done, its next row's start
    if (display) { if (rc === 7) { vcbase = vc + 40; display = false; } rc = (rc + 1) & 7; }
  }
  return { col, src };
}

const PAL = ['000000', 'FFFFFF', '96282E', '5BD6CE', '9F2DAD', '41B936', '2724C4', 'EFF347', '9F4815', '5E3500', 'DA5F66', '474747', '787878', '91FF84', '6864FF', 'AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
const png = (file, a, b) => {
  const NL = LLAST - LFIRST + 1, W = 160 * 2 * 2 + 8, H = NL * 2;
  const raw = Buffer.alloc((W * 3 + 1) * H);
  for (let y = 0; y < H; y++) {
    raw[y * (W * 3 + 1)] = 0;
    for (let x = 0; x < W; x++) {
      const L = LFIRST + (y >> 1), side = x < 320 ? a : x >= 328 ? b : null, px = x < 320 ? x >> 1 : (x - 328) >> 1;
      const c = side ? PAL[side[L * 160 + Math.min(159, px)]] : [128, 0, 128];
      raw.set(c, y * (W * 3 + 1) + 1 + x * 3);
    }
  }
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const cr = Buffer.alloc(4); let c = -1; for (const v of td) { c ^= v; for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xEDB88320 & -(c & 1)); } cr.writeUInt32BE((c ^ -1) >>> 0); return Buffer.concat([l, td, cr]); };
  const ih = Buffer.alloc(13); ih.writeUInt32BE(W, 0); ih.writeUInt32BE(H, 4); ih[8] = 8; ih[9] = 2;
  fs.writeFileSync(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
};

const play = require('./play')(arg('seed', 1));
let bad = 0, done = 0, last = null;
const byWho = {};
for (let f = 0; f <= frames; f++) {
  play.step(vcs);
  if (process.argv.includes('--bw')) vcs.swchb &= ~8;          // (F5: black and white)
  if (arg('diff', '') === 'A') vcs.swchb |= 0xC0;               // (F7 / F8: both difficulties A)
  c64.mem[0x0280] = vcs.swcha; c64.mem[0x0C] = vcs.fire[0] ? 0 : 0x80; c64.mem[0x0D] = vcs.fire[1] ? 0 : 0x80; c64.mem[0x0282] = vcs.swchb;
  runTo(0xF12E);
  // the 2600's last frame is complete now (its picture from the kernel on, the panel after it)
  if (last && last.f >= fromFrame) {
    done++;
    const want = new Uint8Array(160 * 312);
    // (the logo: two lines higher on the C64, its lines 225-232 the 2600's 227-234)
    // (the road's grey, white in the table, light grey in colour on the C64: its playfield pixels
    // of colour $08 with the colour masks 0 / $FF)
    const roadGrey = vcs.ram[0x05] === 0 && vcs.ram[0x06] === 0xFF;
    for (let L = LFIRST; L <= LLAST; L++) { const L2 = L >= 225 ? L + 2 : L; for (let x = 0; x < 160; x++) { const c = vcs.fb[L2 * 160 + x]; want[L * 160 + x] = roadGrey && c === 4 && (vcs.ob[L2 * 160 + x] & 32) && L2 <= 197 ? 15 : M(S.ColorMap + c) & 15; } }
    const diffs = [];
    // (scroll 7 is drawn as 6: the river a line up, on purpose; its lines aren't compared then)
    const skip = L => (last.scroll & 7) === 7 && L <= 197;
    for (let L = LFIRST; L <= LLAST; L++) if (!skip(L)) for (let x = 0; x < 160; x++) if (want[L * 160 + x] !== last.col[L * 160 + x]) diffs.push([L, x]);
    if (diffs.length) {
      bad++;
      for (const [L, x] of diffs) { const k = last.src[L * 160 + x]; byWho[k] = (byWho[k] || 0) + 1; }
      if (bad <= 5 || verbose) console.log(`frame ${last.f} (Scroll ${last.scroll}): ${diffs.length} pixels differ; first at ` + diffs.slice(0, 6).map(([L, x]) => `(${x},${L}) 2600 ${want[L * 160 + x]} C64 ${last.col[L * 160 + x]} ${last.src[L * 160 + x]}`).join(' '));
      if (pngDir && bad <= 20) { fs.mkdirSync(pngDir, { recursive: true }); png(path.join(pngDir, `f${last.f}.png`), want, last.col); }
    }
    if (last.f === showFrame && pngDir) { fs.mkdirSync(pngDir, { recursive: true }); png(path.join(pngDir, `show${last.f}.png`), want, last.col); }
  }
  if (f === frames) break;
  runTo(0xF489);
  c64.call(sym('Tick'));
  c64.call(sym('Render'));
  const rb = M(S.rbuf);
  c64.mem[S.curBuf] = rb;
  last = { f, scroll: vcs.ram[0x0B], ...c64Picture(rb, f) };
  for (let a = 0x80; a < 0x100; a++) c64.mem[a] = vcs.ram[a - 0x80];   // (lockstep's job: keep going whatever)
}
console.log(`${done} frames, ${bad} with differences; by source: ${Object.entries(byWho).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([k, v]) => k + ' ' + v).join(', ')}`);
process.exit(bad ? 1 : 0);
