// Checks ReadInput: joysticks (port 2 = player 1, port 1 = player 2) and keys (W A S D, Space:
// either player's, the players take turns) against the 2600 ports the game reads (SWCHA, INPT4,
// INPT5), and the console keys (F1-F8, a pass at a time) against SWCHB and the power switch, on
// the 6502 core with the CIA's keyboard matrix simulated.
//   node games/river-raid/tools/inputtest.js
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('393948436d1f4cc3192410bb918f9724');
const files = require('../../../tools/buildname').files(process.env.RR_BUILD || path.join(__dirname, '..', 'build'));
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
// keys: [row, bit] in the matrix ($DC00 selects rows by a 0 bit, $DC01 reads columns)
const KEY = { W: [1, 1], A: [1, 2], S: [1, 5], D: [2, 2], SPACE: [7, 4], F1: [0, 4], F3: [0, 5], F5: [0, 6], F7: [0, 3], LSHIFT: [1, 7], RSHIFT: [6, 4] };
let port2 = 0x1F, port1 = 0x1F, keys = [];
class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) {
    a &= 0xFFFF;
    if (a === 0xDC00) return 0xE0 | port2;
    if (a === 0xDC01) {
      const sel = this.mem[0xDC00];
      let v = 0xE0 | port1;
      for (const [r, b] of keys) if (!(sel & (1 << r))) v &= ~(1 << b);
      return v;
    }
    return this.mem[a];
  }
  write(a, v) { this.mem[a & 0xFFFF] = v; }
  commit() {} flush() {} tick(n) { this.cycles += n; }
  call(addr, limit = 1e6) {
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error('runaway at $' + this.pc.toString(16)); }
  }
}
const c = new C64();
c.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c.s = 0xFF;
c.call(sym('Relocate'));
for (let a = 0xC000; a < 0xD000; a++) c.mem[a] = 0;
c.mem[sym('switches')] = 0x0B;   // (as Start: colour, both difficulties B)
for (const n of ['DbgSWCHA', 'DbgINPT4', 'DbgSWCHB']) c.mem[sym(n)] = 0xFF;
const SWCHA = 0x280, SWCHB = 0x282, INPT4 = 0x0C, INPT5 = 0x0D, STATE = 0xC6;
// joystick bits: 0 up, 1 down, 2 left, 3 right, 4 fire (0 = pressed)
const J = { up: 1, down: 2, left: 4, right: 8, fire: 16 };
const cases = [
  ['nothing', {}, 0xFF, 0x80, 0x80],
  ['port 2 up', { p2: 'up' }, 0xEF, 0x80, 0x80],
  ['port 2 down', { p2: 'down' }, 0xDF, 0x80, 0x80],
  ['port 2 left', { p2: 'left' }, 0xBF, 0x80, 0x80],
  ['port 2 right', { p2: 'right' }, 0x7F, 0x80, 0x80],
  ['port 2 fire', { p2: 'fire' }, 0xFF, 0x00, 0x80],
  ['port 1 up', { p1: 'up' }, 0xFE, 0x80, 0x80],
  ['port 1 down', { p1: 'down' }, 0xFD, 0x80, 0x80],
  ['port 1 left', { p1: 'left' }, 0xFB, 0x80, 0x80],
  ['port 1 right', { p1: 'right' }, 0xF7, 0x80, 0x80],
  ['port 1 fire', { p1: 'fire' }, 0xFF, 0x80, 0x00],
  ['key W', { k: ['W'] }, 0xEE, 0x80, 0x80],
  ['key S', { k: ['S'] }, 0xDD, 0x80, 0x80],
  ['key A', { k: ['A'] }, 0xBB, 0x80, 0x80],
  ['key D', { k: ['D'] }, 0x77, 0x80, 0x80],
  ['Space', { k: ['SPACE'] }, 0xFF, 0x00, 0x00],
  ['A + W + Space', { k: ['A', 'W', 'SPACE'] }, 0xAA, 0x00, 0x00],
  ['port 1 left, key D', { p1: 'left', k: ['D'] }, 0xFB, 0x80, 0x80],   // (D's column is the line port 1 holds low: not seen)
  ['port 1 left, key W', { p1: 'left', k: ['W'] }, 0xEA, 0x80, 0x80],
];
let bad = 0;
for (const [name, s, swcha, inpt4, inpt5] of cases) {
  port2 = 0x1F & ~(s.p2 ? J[s.p2] : 0); port1 = 0x1F & ~(s.p1 ? J[s.p1] : 0);
  keys = (s.k || []).map(k => KEY[k]);
  c.call(sym('ReadInput'));
  const got = [c.mem[SWCHA], c.mem[INPT4] & 0x80, c.mem[INPT5] & 0x80];
  const ok = got[0] === swcha && got[1] === inpt4 && got[2] === inpt5;
  if (!ok) bad++;
  console.log(`${ok ? 'ok ' : 'BAD'} ${name.padEnd(22)} SWCHA ${got[0].toString(16)} (want ${swcha.toString(16)}), INPT4 ${got[1].toString(16)} (${inpt4.toString(16)}), INPT5 ${got[2].toString(16)} (${inpt5.toString(16)})`);
}
// the console keys, one pass after another: SWCHB (bits 0 reset, 1 select, 3 colour, 6 / 7
// difficulty) and the power switch (F2: F1 with shift, on key-down); fire starts a game only
// when none is running
port2 = port1 = 0x1F;
const seq = [
  ['nothing', [], 0x0B, 0], ['F1 (reset)', ['F1'], 0x0A, 0], ['F1 held', ['F1'], 0x0A, 0], ['F1 up', [], 0x0B, 0],
  ['F3 (select)', ['F3'], 0x09, 0], ['F3 up', [], 0x0B, 0],
  ['F7 (left difficulty)', ['F7'], 0x4B, 0], ['F7 held', ['F7'], 0x4B, 0], ['F7 up', [], 0x4B, 0],
  ['F8 (right difficulty)', ['LSHIFT', 'F7'], 0xCB, 0], ['F8 up', [], 0xCB, 0],
  ['F8 right shift', ['RSHIFT', 'F7'], 0x4B, 0], ['F8 up', [], 0x4B, 0],
  ['F7 again', ['F7'], 0x0B, 0], ['F7 up', [], 0x0B, 0],
  ['F5 (colour)', ['F5'], 0x03, 0], ['F5 up', [], 0x03, 0], ['F5 again', ['F5'], 0x0B, 0], ['F5 up', [], 0x0B, 0],
  ['F2 (power)', ['LSHIFT', 'F1'], 0x0B, 1], ['F2 held', ['LSHIFT', 'F1'], 0x0B, 0], ['F2 up', [], 0x0B, 0],
  ['F2 right shift', ['RSHIFT', 'F1'], 0x0B, 1], ['F2 up', [], 0x0B, 0],
  ['Space in a game', ['SPACE'], 0x0B, 0, 0x00], ['Space, no game', ['SPACE'], 0x0A, 0, 0xFF],
  ['nothing, no game', [], 0x0B, 0, 0xFF],
];
for (const [name, k, swchb, power, state = 0] of seq) {
  keys = k.map(x => KEY[x]);
  c.mem[sym('PowerReq')] = 0;
  c.mem[STATE] = state;
  c.call(sym('ReadInput'));
  const got = [c.mem[SWCHB], c.mem[sym('PowerReq')] ? 1 : 0];
  const ok = got[0] === swchb && got[1] === power;
  if (!ok) bad++;
  console.log(`${ok ? 'ok ' : 'BAD'} ${name.padEnd(22)} SWCHB ${got[0].toString(16)} (want ${swchb.toString(16)}), power ${got[1]} (${power})`);
}
console.log(bad ? `${bad} wrong` : 'all right');
process.exit(bad ? 1 : 0);
