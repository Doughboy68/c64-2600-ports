// Drive VICE's text remote monitor: start x64sc with a C64 build, then run monitor commands
// and print their output. VICE's usual monitor port is 6510, but other sessions may have a
// VICE using it: --start picks a free port of its own, prints it and remembers it (in the
// temp folder), and the commands go to --port=N or to the port it remembered, never to 6510
// by default.
//   node tools/vice.js --start [prg] [--port=N]            (launch VICE with the remote monitor on)
//   node tools/vice.js [--port=N] "<cmd>; <cmd>; ..."      (connect to that VICE)
//   node tools/vice.js --stop                              (close the VICE --start started, only that one)
const net = require('net');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { freePort, startVice } = require('./vicemon');

const PORTFILE = path.join(os.tmpdir(), 'c64-2600-ports-vice-port.txt');
const portArg = process.argv.find(a => a.startsWith('--port='));
const args = process.argv.slice(2).filter(a => !a.startsWith('--port='));

(async () => {
  if (args[0] === '--start') {
    const prg = path.resolve(args[1] || path.join(__dirname, '..', 'games', 'space-invaders', 'build', 'spaceinvaders-c64.prg'));
    const port = portArg ? +portArg.slice(7) : await freePort();
    const child = startVice(['-default', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${port}`,
      '-autostartprgmode', '1', '-autostart', prg]);
    fs.writeFileSync(PORTFILE, `${port} ${child.pid}`);
    console.log(`VICE started with ${prg}, monitor port ${port}`);
    process.exit(0);
  }

  const [savedPort, savedPid] = fs.existsSync(PORTFILE) ? fs.readFileSync(PORTFILE, 'utf8').split(' ').map(Number) : [0, 0];
  if (args[0] === '--stop') {
    try { process.kill(savedPid); console.log(`closed VICE (process ${savedPid})`); } catch { console.log('that VICE is not running'); }
    fs.rmSync(PORTFILE, { force: true });
    process.exit(0);
  }
  const port = portArg ? +portArg.slice(7) : savedPort;
  if (!port) { console.error('which VICE? start one with --start, or give --port=N'); process.exit(1); }
  const cmds = args.join(' ').split(';').map(s => s.trim()).filter(Boolean);
  const sock = net.connect(port, '127.0.0.1');
  let buf = '';
  sock.on('data', d => { buf += d.toString('latin1'); });
  sock.on('error', e => { console.error(`cannot reach the VICE monitor on port ${port}:`, e.message); process.exit(1); });
  sock.on('connect', async () => {
    const wait = ms => new Promise(r => setTimeout(r, ms));
    await wait(300);
    for (const c of cmds) {
      buf = '';
      if (c.startsWith('sleep ')) { await wait(+c.slice(6)); continue; }
      sock.write(c + '\n');
      await wait(c.startsWith('screenshot') ? 1500 : 400);
      process.stdout.write(`> ${c}\n${buf.replace(/\(C:\$[0-9a-f]{4}\) /g, '')}\n`);
    }
    sock.write('x\n');   // leave the monitor, emulation continues
    await wait(200);
    sock.end();
  });
})();
