// Helpers for the games' VICE test tools: a monitor port of our own (another VICE, from another
// session, may already be using the usual 6510; ours would then fail to open it and we'd talk
// to theirs), a check that the VICE answering there runs our .prg before anything is poked,
// and starting / closing exactly our own VICE.
const net = require('net');
const fs = require('fs');
const { execSync, spawn } = require('child_process');

// A free local port for VICE's remote monitor
async function freePort() {
  for (;;) {
    const p = 6600 + Math.floor(Math.random() * 300);
    const ok = await new Promise(r => {
      const s = net.createServer().once('error', () => r(false)).once('listening', () => s.close(() => r(true)));
      s.listen(p, '127.0.0.1');
    });
    if (ok) return p;
  }
}

// Does the VICE behind mon() (a function sending monitor commands, returning the text) run
// this .prg? Compares the first bytes at its load address.
async function runsOurs(mon, prgFile) {
  const prg = fs.readFileSync(prgFile), load = prg.readUInt16LE(0), n = 32;
  const out = await mon([`m ${load.toString(16)} ${(load + n - 1).toString(16)}`]);
  const bytes = [...out.matchAll(/>C:[0-9a-f]{4}((?:\s+[0-9a-f]{2}\b)+)/gi)].flatMap(m => m[1].trim().split(/\s+/).map(x => parseInt(x, 16)));
  return bytes.length >= n && bytes.slice(0, n).every((b, i) => b === prg[2 + i]);
}

// Start our own VICE (the x64sc on the PATH, started directly so we know its process) ...
function startVice(args) {
  const exe = execSync('where x64sc').toString().split(/\r?\n/).map(l => l.trim()).find(l => /x64sc(\.exe)?$/i.test(l));
  const child = spawn(exe, args, { stdio: 'ignore', detached: true });   // (lives on after the script, if left open)
  child.unref();
  return child;
}
// ... and close exactly that one: never a VICE another session started.
function stopVice(child) { try { if (child) child.kill(); } catch { /* already gone */ } }

module.exports = { freePort, runsOurs, startVice, stopVice };
