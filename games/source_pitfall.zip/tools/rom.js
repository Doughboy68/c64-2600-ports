// Find an original ROM dump on this machine. ROMs are never in the repository:
// they live in roms_port/ (or "prg contributed/"), as .a26/.bin files or inside .zips,
// under any file name. They're found by MD5, or by the name of the .a26 itself.
//   const rom = require('./rom').load('72ffbef6504b75e69ee1045af9075f66')   -> Buffer
//   node tools/rom.js <md5-or-name> [out.a26]      (print where it is, or extract it)
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

const root = path.join(__dirname, '..');
const DIRS = ['roms_port', 'prg contributed', '.'].map(d => path.join(root, d));
const isRom = n => /\.(a26|bin)$/i.test(n);
const md5 = b => crypto.createHash('md5').update(b).digest('hex');

// Every ROM-looking file in a .zip -> [{name, data}]
function unzip(buf) {
  const out = [];
  let e = buf.length - 22;
  while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) return out;
  let p = buf.readUInt32LE(e + 16);
  for (let i = buf.readUInt16LE(e + 10); i > 0; i--) {
    const method = buf.readUInt16LE(p + 10), size = buf.readUInt32LE(p + 20);
    const nameLen = buf.readUInt16LE(p + 28), extra = buf.readUInt16LE(p + 30), comment = buf.readUInt16LE(p + 32);
    const name = buf.toString('latin1', p + 46, p + 46 + nameLen);
    const local = buf.readUInt32LE(p + 42);
    const start = local + 30 + buf.readUInt16LE(local + 26) + buf.readUInt16LE(local + 28);
    if (isRom(name)) {
      const raw = buf.subarray(start, start + size);
      out.push({ name: path.basename(name), data: method === 8 ? zlib.inflateRawSync(raw) : Buffer.from(raw) });
    }
    p += 46 + nameLen + extra + comment;
  }
  return out;
}

// All ROMs found -> [{name, data, md5, from}]
function all() {
  const found = [];
  for (const dir of DIRS) {
    if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir)) {
      const file = path.join(dir, f);
      if (isRom(f)) found.push({ name: f, data: fs.readFileSync(file), from: file });
      else if (/\.zip$/i.test(f)) for (const z of unzip(fs.readFileSync(file))) found.push({ ...z, from: file });
    }
  }
  for (const r of found) r.md5 = md5(r.data);
  return found;
}

// The ROM with this MD5 (or this .a26 file name) -> {name, data, md5, from}
function find(key) {
  const k = key.toLowerCase();
  const r = all().find(r => r.md5 === k || r.name.toLowerCase() === k);
  if (!r) throw new Error(`ROM not found: ${key} (put the dump, or its .zip, in roms_port/)`);
  return r;
}
const load = key => find(key).data;

module.exports = { find, load, all, unzip, md5 };

if (require.main === module) {
  const [key, out] = process.argv.slice(2);
  if (!key) { for (const r of all()) console.log(`${r.md5}  ${r.name}  (${path.relative(root, r.from)})`); return; }
  try {
    const r = find(key);
    if (out) fs.writeFileSync(out, r.data);
    console.log(`${r.md5}  ${r.name}  (${path.relative(root, r.from)})${out ? ' -> ' + out : ''}`);
  } catch (e) { console.error(e.message); process.exit(1); }
}
