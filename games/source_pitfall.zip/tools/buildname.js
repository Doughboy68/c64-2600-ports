// A game's build file names: <short name>-<version>.prg / .d64 / .lst, the version from the
// BASIC listing in the game's c64/main.asm (" version 1.4", or Zeiche's ports' " beta 0.0.3":
// in file names just the number). A name (without .prg) must fit a C64 file name: at most 16
// characters (on a C64 drive, SD2IEC or 1541 Ultimate, longer ones get cut short).
//   node tools/buildname.js <game folder> <short name>   prints the name (for build.cmd)
//   require('tools/buildname').files(buildDir) -> { prg, lst, d64 }: the build in that folder
//     (the one versioned .prg there; else an older <game>-c64.prg)
const fs = require('fs');
const path = require('path');

// the version as the BASIC listing gives it ("1.4", "beta 0.0.3")
function version(gameDir) {
  const asm = fs.readFileSync(path.join(gameDir, 'c64', 'main.asm'), 'latin1');
  const m = asm.match(/"\s*version ([\d.]+)"/i) || asm.match(/"\s*(beta [\d.]+)"/i);
  if (!m) throw new Error(`no version in ${gameDir}/c64/main.asm`);
  return m[1];
}
// ... as file names give it: just the number
const fileVersion = v => String(v).match(/[\d.]*\d/)[0];

function name(gameDir, short) {
  const n = `${short}-${fileVersion(version(gameDir))}`;
  if (n.length > 16) throw new Error(`${n}: longer than a C64 file name (16 characters)`);
  return n;
}

function files(buildDir) {
  const prgs = fs.readdirSync(buildDir).filter(f => /\.prg$/i.test(f));
  const pick = prgs.filter(f => /-\d[\d.]*\.prg$/i.test(f))
    .sort((a, b) => fs.statSync(path.join(buildDir, b)).mtimeMs - fs.statSync(path.join(buildDir, a)).mtimeMs)[0]
    || prgs.find(f => /-c64\.prg$/i.test(f));
  if (!pick) throw new Error(`no build in ${buildDir}`);
  const base = path.join(buildDir, pick.slice(0, -4));
  return { prg: base + '.prg', lst: base + '.lst', d64: base + '.d64' };
}

module.exports = { version, fileVersion, name, files };
if (require.main === module) {
  try { console.log(name(path.resolve(process.argv[2] || '.'), process.argv[3])); } catch (e) { console.error(e.message); process.exit(1); }
}
