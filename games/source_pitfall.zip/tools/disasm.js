// Tracing 6502 disassembler: turns an Atari 2600 ROM into 64tass source that
// reassembles to the identical binary. A 4K ROM is mapped at $F000; a bank-switched
// one (8K F8: two 4K banks) lists the address each bank runs at in symbols.js
// (game.banks, e.g. [0xD000, 0xF000]) and each bank is traced from its own vectors.
// Names and notes come from the game's 2600/symbols.js, which also gives its title and
// ROM MD5 (the ROM is found by tools/rom.js). Writes 2600/<asm> and 2600/RAM-MAP.md.
// symbols.code lists entry points reached only through jump tables; symbols.always lists
// conditional branches that are always taken (the bytes after them aren't code).
// game.crossBank (F8): an instruction that touches the other bank's hotspot ($xFF8/$xFF9)
// carries on in that bank, at the next instruction's offset (Stargate switches that way).
//   node tools/disasm.js games/<game>
const fs = require('fs');
const path = require('path');
const Disasm = require('../src/web/disasm-core.js');
const gameDir = path.resolve(process.argv[2] || '.');
const symbols = require(path.join(gameDir, '2600', 'symbols.js'));
const { game } = symbols;
const outPath = path.join(gameDir, '2600', game.asm), mapPath = path.join(gameDir, '2600', 'RAM-MAP.md');
const rel = p => path.relative(path.join(__dirname, '..'), p).split(path.sep).join('/');
const rom = require('./rom').load(game.md5);
const { asm, ramMap, lines, labels } = Disasm.disassemble(rom, symbols);   // (src/web/disasm-core.js)
fs.writeFileSync(outPath, asm);
console.log(`wrote ${rel(outPath)}: ${lines} lines, ${labels} labels`);
fs.writeFileSync(mapPath, ramMap);
console.log(`wrote ${rel(mapPath)}`);
