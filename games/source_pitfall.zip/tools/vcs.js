// Small scriptable Atari 2600 emulator used to study the game: 6502 core,
// RIOT timer/IO, and a TIA that renders frames and reports collisions.
// Accuracy target is "good enough to see what the game is doing", not Stella.
// ROMs: 4K, or 8K with F8 bank switching (touching $1FF8 / $1FF9 selects bank 0 / 1).
// Set vcs.wideDelay = true for the real TIA's one pixel delay of double and quad width players.
// Set vcs.respDelay = true for the real TIA's reset rule: a player reset (RESP0/1) part-way across
// a line doesn't draw its main copy until the next line (its other copies still show).
// Set vcs.superChip = true for the cartridge's extra 128 bytes of RAM (Atari's SuperChip, "F8SC"):
// written at $1000-$107F, read at $1080-$10FF (vcs.xram).
// Set vcs.hmoveBlank = true for the HMOVE blank: an HMOVE early in a line (in the horizontal
// blank) keeps the blank on for the line's first 8 pixels (the black "comb" at the left edge).
'use strict';
const fs = require('fs');
const zlib = require('zlib');

// ---------------------------------------------------------------- 6502 core
const T = `00BRK.imp 01ORA.izx 05ORA.zp 06ASL.zp 08PHP.imp 09ORA.imm 0aASL.acc 0dORA.abs 0eASL.abs 10BPL.rel 11ORA.izy 15ORA.zpx 16ASL.zpx 18CLC.imp 19ORA.aby 1dORA.abx 1eASL.abx
20JSR.abs 21AND.izx 24BIT.zp 25AND.zp 26ROL.zp 28PLP.imp 29AND.imm 2aROL.acc 2cBIT.abs 2dAND.abs 2eROL.abs 30BMI.rel 31AND.izy 35AND.zpx 36ROL.zpx 38SEC.imp 39AND.aby 3dAND.abx 3eROL.abx
40RTI.imp 41EOR.izx 45EOR.zp 46LSR.zp 48PHA.imp 49EOR.imm 4aLSR.acc 4cJMP.abs 4dEOR.abs 4eLSR.abs 50BVC.rel 51EOR.izy 55EOR.zpx 56LSR.zpx 58CLI.imp 59EOR.aby 5dEOR.abx 5eLSR.abx
60RTS.imp 61ADC.izx 65ADC.zp 66ROR.zp 68PLA.imp 69ADC.imm 6aROR.acc 6cJMP.ind 6dADC.abs 6eROR.abs 70BVS.rel 71ADC.izy 75ADC.zpx 76ROR.zpx 78SEI.imp 79ADC.aby 7dADC.abx 7eROR.abx
81STA.izx 84STY.zp 85STA.zp 86STX.zp 88DEY.imp 8aTXA.imp 8cSTY.abs 8dSTA.abs 8eSTX.abs 90BCC.rel 91STA.izy 94STY.zpx 95STA.zpx 96STX.zpy 98TYA.imp 99STA.aby 9aTXS.imp 9dSTA.abx
a0LDY.imm a1LDA.izx a2LDX.imm a4LDY.zp a5LDA.zp a6LDX.zp a8TAY.imp a9LDA.imm aaTAX.imp acLDY.abs adLDA.abs aeLDX.abs b0BCS.rel b1LDA.izy b4LDY.zpx b5LDA.zpx b6LDX.zpy b8CLV.imp b9LDA.aby baTSX.imp bcLDY.abx bdLDA.abx beLDX.aby
c0CPY.imm c1CMP.izx c4CPY.zp c5CMP.zp c6DEC.zp c8INY.imp c9CMP.imm caDEX.imp ccCPY.abs cdCMP.abs ceDEC.abs d0BNE.rel d1CMP.izy d5CMP.zpx d6DEC.zpx d8CLD.imp d9CMP.aby ddCMP.abx deDEC.abx
e0CPX.imm e1SBC.izx e4CPX.zp e5SBC.zp e6INC.zp e8INX.imp e9SBC.imm eaNOP.imp ecCPX.abs edSBC.abs eeINC.abs f0BEQ.rel f1SBC.izy f5SBC.zpx f6INC.zpx f8SED.imp f9SBC.aby fdSBC.abx feINC.abx`;
const OPS = [];
for (const t of T.split(/\s+/)) OPS[parseInt(t.slice(0, 2), 16)] = [t.slice(2, 5), t.slice(6)];
const RMW = new Set(['ASL', 'LSR', 'ROL', 'ROR', 'INC', 'DEC']);
const STORE = new Set(['STA', 'STX', 'STY']);
const BASE = { imp: 2, acc: 2, imm: 2, zp: 3, zpx: 4, zpy: 4, abs: 4, abx: 4, aby: 4, izx: 6, izy: 5, rel: 2, ind: 5 };

// NTSC palette: hue in the high nibble, luminance in bits 1-3 (YIQ approximation)
const PALETTE = [];
for (let c = 0; c < 128; c++) {
  const hue = c >> 3, lum = c & 7;
  const y = 0.08 + lum * 0.13;
  let i = 0, q = 0;
  if (hue) { const a = (hue - 1) * (2 * Math.PI / 15) + 2.6; i = 0.22 * Math.cos(a); q = 0.22 * Math.sin(a); }
  const cl = v => Math.max(0, Math.min(255, Math.round(v * 255)));
  PALETTE.push([cl(y + 0.956 * i + 0.621 * q), cl(y - 0.272 * i - 0.647 * q), cl(y - 1.106 * i + 1.703 * q)]);
}

class VCS {
  constructor(rom) {
    this.rom = rom;
    this.bank = rom.length / 4096 - 1;   // F8: starts in the last bank
    this.ram = new Uint8Array(128);
    this.superChip = false; this.xram = new Uint8Array(128);
    // CPU
    this.a = 0; this.x = 0; this.y = 0; this.s = 0xFD; this.p = 0x24;
    this.pc = rom.readUInt16LE(rom.length - 4);
    this.cycles = 0;
    // RIOT
    this.swcha = 0xFF;          // joysticks, active low (P0: bit7 R, bit6 L, bit5 D, bit4 U)
    this.swchb = 0x0B;          // console switches: bit0 reset, bit1 select (active low), bit3 colour
    this.fire = [false, false];
    this.timer = { val: 0xFF, interval: 1024, sub: 1024, flag: 0 };
    // TIA
    this.r = new Uint8Array(64);
    this.clock = 0;             // colour clock within line (0..227, 68 = first visible)
    this.line = 0;              // lines since end of VSYNC
    this.pos = [0, 0, 0, 0, 0]; // P0 P1 M0 M1 BL horizontal positions (0..159)
    this.grpOld = [0, 0]; this.blOld = 0;
    this.cx = 0;                // 15 collision latches, bit order as in collisionBits()
    this.fb = new Uint8Array(160 * 262);
    this.ob = new Uint8Array(160 * 262); // which objects drew each pixel: 1 P0, 2 P1, 4 M0, 8 M1, 16 BL, 32 PF
    this.frames = 0;
    this.onFrame = null;
    this.watch = null;          // optional (addr, value, pc) callback on RAM writes
    this.pendingWrites = [];
    this.hmoveBlank = false;
    this.wideDelay = false;  // opt-in: double and quad width players start a pixel later (real TIA)
    this.respDelay = false;  // opt-in: no main copy on the line of a mid-line player reset (real TIA)
    this.resetLine = [-1, -1];
    this.hmoveLine = -1;     // line whose first 8 pixels the HMOVE blank covers
  }

  // ------------------------------------------------------------ bus
  read(addr) {
    addr &= 0x1FFF;
    if (addr & 0x1000) {
      if (this.superChip && (addr & 0xF80) === 0x080) return this.xram[addr & 0x7F];
      this.hotspot(addr); return this.rom[this.bank * 4096 + (addr & 0xFFF)]; }
    if (!(addr & 0x80)) return this.tiaRead(addr & 0x0F);
    if (!(addr & 0x200)) return this.ram[addr & 0x7F];
    switch (addr & 0x287) {
      case 0x280: return this.swcha;
      case 0x281: return 0;
      case 0x282: return this.swchb;
      case 0x283: return 0;
      case 0x284: case 0x286: return this.timer.val;
      default: { const f = this.timer.flag; this.timer.flag &= ~0x40; return f; }
    }
  }
  write(addr, v) { this.pendingWrites.push(addr & 0x1FFF, v); }
  hotspot(addr) { if (this.rom.length === 8192 && (addr & 0xFFE) === 0xFF8) this.bank = addr & 1; }
  commit(addr, v) {
    if (addr & 0x1000) {
      if (this.superChip && (addr & 0xF80) === 0) { if (this.xwatch) this.xwatch(addr & 0x7F, v, this.lastPc); this.xram[addr & 0x7F] = v; return; }
      return this.hotspot(addr);
    }
    if (!(addr & 0x80)) return this.tiaWrite(addr & 0x3F, v);
    if (!(addr & 0x200)) { if (this.watch) this.watch(0x80 | (addr & 0x7F), v, this.lastPc); this.ram[addr & 0x7F] = v; return; }
    if ((addr & 0x294) === 0x294) {
      const iv = [1, 8, 64, 1024][addr & 3];
      this.timer = { val: v, interval: iv, sub: iv, flag: 0 };
    }
  }

  // ------------------------------------------------------------ timing
  tick(n) {
    for (let i = 0; i < n; i++) {
      const t = this.timer;
      if (--t.sub <= 0) {
        t.val = (t.val - 1) & 0xFF;
        t.sub = t.interval;
        if (t.val === 0xFF) { t.interval = 1; t.sub = 1; t.flag = 0xC0; }
      }
      this.cycles++;
      for (let k = 0; k < 3; k++) this.colourClock();
    }
  }
  colourClock() {
    if (this.clock >= 68) this.pixel(this.clock - 68);
    if (++this.clock === 228) { this.clock = 0; this.line++; }
  }

  // ------------------------------------------------------------ TIA
  tiaRead(a) {
    const c = this.cx, b = (i) => (c >> i) & 1;
    switch (a) {
      case 0x0: return (b(0) << 7) | (b(1) << 6);  // CXM0P: M0-P1, M0-P0
      case 0x1: return (b(2) << 7) | (b(3) << 6);  // CXM1P: M1-P0, M1-P1
      case 0x2: return (b(4) << 7) | (b(5) << 6);  // CXP0FB: P0-PF, P0-BL
      case 0x3: return (b(6) << 7) | (b(7) << 6);  // CXP1FB: P1-PF, P1-BL
      case 0x4: return (b(8) << 7) | (b(9) << 6);  // CXM0FB
      case 0x5: return (b(10) << 7) | (b(11) << 6); // CXM1FB
      case 0x6: return b(12) << 7;                  // CXBLPF
      case 0x7: return (b(13) << 7) | (b(14) << 6); // CXPPMM: P0-P1, M0-M1
      case 0xC: return this.fire[0] ? 0x00 : 0x80;
      case 0xD: return this.fire[1] ? 0x00 : 0x80;
      default: return 0x80;
    }
  }
  tiaWrite(a, v) {
    const r = this.r;
    const hpos = () => this.clock - 68;
    switch (a) {
      case 0x00: // VSYNC: frame ends when the sync bit drops
        if ((r[0] & 2) && !(v & 2)) this.endFrame();
        break;
      case 0x02: // WSYNC: stall until the start of the next line
        while (this.clock !== 0) this.tick(1);
        break;
      case 0x10: case 0x11: case 0x12: case 0x13: case 0x14: {
        const h = hpos();
        const isPlayer = a < 0x12;
        this.pos[a - 0x10] = h < 0 ? (isPlayer ? 3 : 2) : (h + (isPlayer ? 5 : 4)) % 160;
        if (isPlayer && h >= 0) this.resetLine[a - 0x10] = this.line;
        break;
      }
      case 0x1B: this.grpOld[1] = r[0x1C]; break; // writing GRP0 latches the old GRP1
      case 0x1C: this.grpOld[0] = r[0x1B]; this.blOld = r[0x1F]; break;
      case 0x2A: // HMOVE
        if (this.clock < 68) this.hmoveLine = this.line;
        [0x20, 0x21, 0x22, 0x23, 0x24].forEach((hm, i) => {
          const m = (r[hm] >> 4) ^ 8; // signed nibble, positive = move left
          this.pos[i] = (this.pos[i] - (m - 8) + 160) % 160;
        });
        break;
      case 0x2B: r[0x20] = r[0x21] = r[0x22] = r[0x23] = r[0x24] = 0; break;
      case 0x2C: this.cx = 0; break;
      case 0x28: case 0x29: if (v & 2) this.pos[a - 0x26] = this.pos[a - 0x28]; break; // RESMPx
    }
    r[a] = v;
  }
  playerBit(i, x) {
    const r = this.r;
    const nus = r[4 + i] & 7;
    const g = (r[0x25 + i] & 1) ? this.grpOld[i] : r[0x1B + i];
    if (!g) return false;
    let d = (x - this.pos[i] - (this.wideDelay && (nus === 5 || nus === 7) ? 1 : 0) + 160) % 160;
    const copies = [[0], [0, 16], [0, 32], [0, 16, 32], [0, 64], [0], [0, 32, 64], [0]][nus];
    const scale = nus === 5 ? 2 : nus === 7 ? 4 : 1;
    for (const c of copies) {
      if (c === 0 && this.respDelay && this.resetLine[i] === this.line) continue;
      const dd = d - c;
      if (dd >= 0 && dd < 8 * scale) {
        let bit = Math.floor(dd / scale);
        if (!(r[0xB + i] & 8)) bit = 7 - bit;
        return ((g >> bit) & 1) === 1;
      }
    }
    return false;
  }
  missileBit(i, x) {
    const r = this.r;
    if (!(r[0x1D + i] & 2) || (r[0x28 + i] & 2)) return false;
    const w = 1 << ((r[4 + i] >> 4) & 3);
    const nus = r[4 + i] & 7;
    const d = (x - this.pos[2 + i] + 160) % 160;
    const copies = [[0], [0, 16], [0, 32], [0, 16, 32], [0, 64], [0], [0, 32, 64], [0]][nus];
    return copies.some(c => d - c >= 0 && d - c < w);
  }
  ballBit(x) {
    const r = this.r;
    const en = (r[0x27] & 1) ? this.blOld : r[0x1F];
    if (!(en & 2)) return false;
    const w = 1 << ((r[0xA] >> 4) & 3);
    const d = (x - this.pos[4] + 160) % 160;
    return d < w;
  }
  pfBit(x) {
    const r = this.r;
    let c = x >> 2; // 40 playfield cells
    if (c >= 20) c = (r[0xA] & 1) ? 39 - c : c - 20;
    if (c < 4) return (r[0xD] >> (4 + c)) & 1;
    if (c < 12) return (r[0xE] >> (11 - c)) & 1;
    return (r[0xF] >> (c - 12)) & 1;
  }
  pixel(x) {
    const r = this.r;
    if (this.hmoveBlank && x < 8 && this.hmoveLine === this.line) {   // (nothing drawn, nothing collides)
      if (this.line < 262) { this.fb[this.line * 160 + x] = 0; this.ob[this.line * 160 + x] = 0; }
      return;
    }
    const p0 = this.playerBit(0, x), p1 = this.playerBit(1, x);
    const m0 = this.missileBit(0, x), m1 = this.missileBit(1, x);
    const bl = this.ballBit(x), pf = !!this.pfBit(x);
    const pairs = [[m0, p1], [m0, p0], [m1, p0], [m1, p1], [p0, pf], [p0, bl], [p1, pf], [p1, bl],
      [m0, pf], [m0, bl], [m1, pf], [m1, bl], [bl, pf], [p0, p1], [m0, m1]];
    pairs.forEach(([u, w], i) => { if (u && w) this.cx |= 1 << i; });
    if (this.line >= 262) return;
    let col = r[0x9];
    const pfCol = (r[0xA] & 2) ? (x < 80 ? r[6] : r[7]) : r[8];
    if (r[0xA] & 4) { // playfield priority
      if (p1 || m1) col = r[7];
      if (p0 || m0) col = r[6];
      if (pf || bl) col = pfCol;
    } else {
      if (pf || bl) col = pfCol;
      if (p1 || m1) col = r[7];
      if (p0 || m0) col = r[6];
    }
    if (r[1] & 2) col = 0; // VBLANK
    this.fb[this.line * 160 + x] = col >> 1;
    this.ob[this.line * 160 + x] = (r[1] & 2) ? 0 : (p0 | p1 << 1 | m0 << 2 | m1 << 3 | bl << 4 | pf << 5);
  }
  endFrame() {
    this.frames++;
    if (this.onFrame) this.onFrame(this);
    this.line = 0;
  }

  // ------------------------------------------------------------ CPU
  setNZ(v) { this.p = (this.p & 0x7D) | (v & 0x80) | (v ? 0 : 2); return v; }
  push(v) { this.write(0x100 | this.s, v); this.s = (this.s - 1) & 0xFF; }
  pull() { this.s = (this.s + 1) & 0xFF; return this.read(0x100 | this.s); }
  pullFlush() { this.flush(); return this.pull(); }
  flush() { const w = this.pendingWrites; this.pendingWrites = []; for (let i = 0; i < w.length; i += 2) this.commit(w[i], w[i + 1]); }
  adc(v) {
    const c = this.p & 1;
    if (this.p & 8) {
      let lo = (this.a & 0xF) + (v & 0xF) + c, hi = (this.a >> 4) + (v >> 4);
      if (lo > 9) { lo -= 10; hi++; }
      const bin = (this.a + v + c) & 0xFF;
      this.p = (this.p & 0x3C) | (hi > 9 ? 1 : 0) | (bin ? 0 : 2);
      if (hi > 9) hi -= 10;
      this.a = ((hi << 4) | lo) & 0xFF;
      this.p |= this.a & 0x80;
    } else {
      const t = this.a + v + c;
      this.p = (this.p & 0x3C) | (t > 0xFF ? 1 : 0) | ((~(this.a ^ v) & (this.a ^ t) & 0x80) ? 0x40 : 0);
      this.a = this.setNZ(t & 0xFF);
    }
  }
  sbc(v) {
    if (this.p & 8) {
      const c = this.p & 1;
      let lo = (this.a & 0xF) - (v & 0xF) - (1 - c), hi = (this.a >> 4) - (v >> 4);
      if (lo < 0) { lo += 10; hi--; }
      const t = this.a - v - (1 - c);
      this.p = (this.p & 0x3C) | (hi >= 0 ? 1 : 0);
      if (hi < 0) hi += 10;
      this.a = ((hi << 4) | lo) & 0xFF;
      this.p |= (this.a & 0x80) | (((t & 0xFF) === 0) ? 2 : 0);
    } else this.adc(v ^ 0xFF);
  }
  step() {
    const pc = this.pc; this.lastPc = pc;
    if (this.hooks && this.hooks[pc]) this.hooks[pc](this);
    const opc = this.read(pc);
    const op = OPS[opc];
    if (!op) throw new Error(`illegal opcode ${opc.toString(16)} at ${pc.toString(16)}`);
    const [mn, mode] = op;
    let cyc = BASE[mode], ea = 0, cross = false;
    const b1 = this.read(pc + 1), w = b1 | (this.read(pc + 2) << 8);
    const len = { imp: 1, acc: 1, imm: 2, zp: 2, zpx: 2, zpy: 2, izx: 2, izy: 2, rel: 2, abs: 3, abx: 3, aby: 3, ind: 3 }[mode];
    this.pc = (pc + len) & 0xFFFF;
    switch (mode) {
      case 'zp': ea = b1; break;
      case 'zpx': ea = (b1 + this.x) & 0xFF; break;
      case 'zpy': ea = (b1 + this.y) & 0xFF; break;
      case 'abs': ea = w; break;
      case 'abx': ea = (w + this.x) & 0xFFFF; cross = (ea & 0xFF00) !== (w & 0xFF00); break;
      case 'aby': ea = (w + this.y) & 0xFFFF; cross = (ea & 0xFF00) !== (w & 0xFF00); break;
      case 'izx': { const z = (b1 + this.x) & 0xFF; ea = this.read(z) | (this.read((z + 1) & 0xFF) << 8); break; }
      case 'izy': { const base = this.read(b1) | (this.read((b1 + 1) & 0xFF) << 8); ea = (base + this.y) & 0xFFFF; cross = (ea & 0xFF00) !== (base & 0xFF00); break; }
      case 'ind': ea = this.read(w) | (this.read((w & 0xFF00) | ((w + 1) & 0xFF)) << 8); break;
    }
    if (RMW.has(mn) && mode !== 'acc') cyc = { zp: 5, zpx: 6, abs: 6, abx: 7 }[mode];
    else if (STORE.has(mn)) { if (mode === 'abx' || mode === 'aby') cyc = 5; if (mode === 'izy') cyc = 6; }
    else if (cross) cyc++;
    const val = () => mode === 'imm' ? b1 : this.read(ea);
    const branch = (cond) => {
      if (cond) { const t = (this.pc + ((b1 << 24) >> 24)) & 0xFFFF; cyc += ((t & 0xFF00) !== (this.pc & 0xFF00)) ? 2 : 1; this.pc = t; }
    };
    const rmw = (f) => {
      if (mode === 'acc') this.a = this.setNZ(f(this.a));
      else this.write(ea, this.setNZ(f(this.read(ea))));
    };
    switch (mn) {
      case 'LDA': this.a = this.setNZ(val()); break;
      case 'LDX': this.x = this.setNZ(val()); break;
      case 'LDY': this.y = this.setNZ(val()); break;
      case 'STA': this.write(ea, this.a); break;
      case 'STX': this.write(ea, this.x); break;
      case 'STY': this.write(ea, this.y); break;
      case 'TAX': this.x = this.setNZ(this.a); break;
      case 'TAY': this.y = this.setNZ(this.a); break;
      case 'TXA': this.a = this.setNZ(this.x); break;
      case 'TYA': this.a = this.setNZ(this.y); break;
      case 'TSX': this.x = this.setNZ(this.s); break;
      case 'TXS': this.s = this.x; break;
      case 'PHA': this.push(this.a); cyc = 3; break;
      case 'PHP': this.push(this.p | 0x30); cyc = 3; break;
      case 'PLA': this.a = this.setNZ(this.pullFlush()); cyc = 4; break;
      case 'PLP': this.p = (this.pullFlush() & 0xEF) | 0x20; cyc = 4; break;
      case 'AND': this.a = this.setNZ(this.a & val()); break;
      case 'ORA': this.a = this.setNZ(this.a | val()); break;
      case 'EOR': this.a = this.setNZ(this.a ^ val()); break;
      case 'ADC': this.adc(val()); break;
      case 'SBC': this.sbc(val()); break;
      case 'CMP': case 'CPX': case 'CPY': {
        const reg = mn === 'CMP' ? this.a : mn === 'CPX' ? this.x : this.y;
        const t = reg - val();
        this.p = (this.p & 0xFE) | (t >= 0 ? 1 : 0); this.setNZ(t & 0xFF); break;
      }
      case 'BIT': { const v = val(); this.p = (this.p & 0x3D) | (v & 0xC0) | ((this.a & v) ? 0 : 2); break; }
      case 'INC': rmw(v => (v + 1) & 0xFF); break;
      case 'DEC': rmw(v => (v - 1) & 0xFF); break;
      case 'INX': this.x = this.setNZ((this.x + 1) & 0xFF); break;
      case 'INY': this.y = this.setNZ((this.y + 1) & 0xFF); break;
      case 'DEX': this.x = this.setNZ((this.x - 1) & 0xFF); break;
      case 'DEY': this.y = this.setNZ((this.y - 1) & 0xFF); break;
      case 'ASL': rmw(v => { this.p = (this.p & 0xFE) | (v >> 7); return (v << 1) & 0xFF; }); break;
      case 'LSR': rmw(v => { this.p = (this.p & 0xFE) | (v & 1); return v >> 1; }); break;
      case 'ROL': rmw(v => { const c = this.p & 1; this.p = (this.p & 0xFE) | (v >> 7); return ((v << 1) | c) & 0xFF; }); break;
      case 'ROR': rmw(v => { const c = this.p & 1; this.p = (this.p & 0xFE) | (v & 1); return (v >> 1) | (c << 7); }); break;
      case 'JMP': this.pc = ea; cyc = mode === 'abs' ? 3 : 5; break;
      case 'JSR': { const ret = (pc + 2) & 0xFFFF; this.push(ret >> 8); this.push(ret & 0xFF); this.pc = w; cyc = 6; break; }
      case 'RTS': { this.flush(); const lo = this.pull(), hi = this.pull(); this.pc = ((hi << 8) | lo) + 1 & 0xFFFF; cyc = 6; break; }
      case 'RTI': { this.flush(); this.p = (this.pull() & 0xEF) | 0x20; const lo = this.pull(), hi = this.pull(); this.pc = (hi << 8) | lo; cyc = 6; break; }
      case 'BRK': throw new Error(`BRK at ${pc.toString(16)}`);
      case 'BPL': branch(!(this.p & 0x80)); break;
      case 'BMI': branch(this.p & 0x80); break;
      case 'BVC': branch(!(this.p & 0x40)); break;
      case 'BVS': branch(this.p & 0x40); break;
      case 'BCC': branch(!(this.p & 1)); break;
      case 'BCS': branch(this.p & 1); break;
      case 'BNE': branch(!(this.p & 2)); break;
      case 'BEQ': branch(this.p & 2); break;
      case 'CLC': this.p &= ~1; break; case 'SEC': this.p |= 1; break;
      case 'CLI': this.p &= ~4; break; case 'SEI': this.p |= 4; break;
      case 'CLD': this.p &= ~8; break; case 'SED': this.p |= 8; break;
      case 'CLV': this.p &= ~0x40; break;
      case 'NOP': break;
    }
    this.tick(cyc);
    this.flush();
  }

  runFrames(n) {
    const target = this.frames + n;
    let guard = 0;
    while (this.frames < target) { this.step(); if (++guard > 5e6) throw new Error('no VSYNC seen'); }
  }

  // Save the current framebuffer as a PNG (each 2600 pixel drawn 2x wide)
  savePNG(file, scale = 2) {
    const top = this.cropTop ?? 30, h = this.cropHeight ?? 200;
    const W = 160 * scale * 2, H = h * scale;
    const raw = Buffer.alloc((W * 3 + 1) * H);
    for (let yy = 0; yy < H; yy++) {
      const row = yy * (W * 3 + 1);
      raw[row] = 0;
      const src = (top + Math.floor(yy / scale)) * 160;
      for (let xx = 0; xx < W; xx++) {
        const c = PALETTE[this.fb[src + Math.floor(xx / (scale * 2))]];
        raw.set(c, row + 1 + xx * 3);
      }
    }
    const chunk = (type, data) => {
      const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
      const td = Buffer.concat([Buffer.from(type), data]);
      const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
      return Buffer.concat([len, td, crc]);
    };
    const ihdr = Buffer.alloc(13);
    ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2;
    fs.writeFileSync(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
      chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
  }
}

const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; return c; });
function crc32(buf) { let c = -1; for (const b of buf) c = CRC[(c ^ b) & 0xFF] ^ (c >>> 8); return (c ^ -1) >>> 0; }

module.exports = { VCS, PALETTE };
