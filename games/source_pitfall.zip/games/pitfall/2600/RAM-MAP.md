# Pitfall! (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80` | Lives | 1 | Lives left, as marks: the bits shown left of the clock ($A0 at the start: two marks; shifted left two bits per life lost) |
| `$81` | Room | 1 | The room: a random number stepped as Harry leaves a room (bits 0-2 object, 3-5 scene, 6-7 trees) |
| `$82` | Random | 1 | A second random number, stepped every frame (the objects' animation) |
| `$83` | Joystick | 1 | SWCHA >> 4 this frame (bits: 0 up, 1 down, 2 left, 3 right; 0 = pushed) |
| `$84` | FireLast | 1 | INPT4 bit 7 last frame (a jump starts on a press) |
| `$85` | CollTop | 1 | Kernel: CXP0FB at line 151 (bit 6: Harry touches the vine; bit 7 the trees) |
| `$86` | CollGround | 1 | Kernel: collisions at line 167 (bit 7 Harry-object, 6 Harry-playfield, 5 Harry-ball); not read |
| `$87` | ColourEor | 1 | Colour mask: eor (attract mode: the colours cycle) |
| `$88` | ColourAnd | 1 | Colour mask: and ($FF colour, $0F B&W; bit 3 cleared in attract mode) |
| `$89-$91` | Colours | 9 | The picture's colours: score, -, canopy (COLUPF), sky (COLUBK), tunnel (black), trees, earth, ground, pit (water) |
| `$92` | VineLen | 1 | The vine's length: it is drawn down to line 151 - this |
| `$93` | Object | 1 | The room's object (Room bits 0-2): logs, fire, cobra; treasures in scene 5; vine in crocodile rooms (bit 1) |
| `$94` | Scene | 1 | The room's scene (Room bits 3-5): 0 one hole, 1 three holes (with ladder and wall), 2 tar pit and vine, 3 swamp and vine, 4 crocodiles, 5 shifting tar and treasure, 6 shifting tar and vine, 7 shifting quicksand |
| `$95-$97` | PosFine | 3 | Kernel: fine motion (HM) for Harry, the object, the tunnel object (from LF388) |
| `$98-$9A` | PosCoarse | 3 | Kernel: coarse position loop counts for Harry, the object, the tunnel object |
| `$9B-$9C` | BranchPos | 2 | Kernel: the branches' positions (players 0 and 1, from the tree pattern) |
| `$9D` | Ladder | 1 | $FF: the room has holes, a ladder and a wall (scenes 0-1); 0 otherwise |
| `$9E` | Frozen | 1 | Non-zero: no play (before the first move, dying, game over): counts down |
| `$9F` | HolePF | 1 | Kernel: PF2 for the earth between the ground and the tunnel (the ladder's hole) |
| `$A0-$A6` | PitPF | 7 | Kernel: PF2 per line of the ground (the pit's shape), lines 153-159 from $A6 down |
| `$A7-$AD` | ObjColRows | 7 | Kernel: the object's colours, rows 8-14 |
| `$AE-$B4` | ObjRows | 7 | Kernel: the object's shape, rows 8-14 |
| `$B5-$B6` | HarryPtr | 2 | Harry's shape (page $FB) |
| `$B7-$B8` | ObjPtr | 2 | The object's shape (page $FD) |
| `$B9-$BA` | HarryColPtr | 2 | Harry's colours (page $FC) |
| `$BB-$BC` | ObjColPtr | 2 | The object's colours (page $FE) |
| `$BD-$C4` | TunPtr | 8 | The tunnel object: shape and colours of the upper 16 lines ($BD, $BF), the lower 16 ($C1, $C3): the wall, or the scorpion |
| `$C5-$D0` | DigitPtr | 12 | Six digit pointers (page $FF): the score; the kernel sets the clock's and the logo's |
| `$D1` | IdleHi | 1 | Frames without input (high byte): attract mode when bit 7 is set |
| `$D2` | IdleLo | 1 | Frames without input (low byte) |
| `$D3` | FrameCount | 1 | Frame counter while playing |
| `$D4` | ObjNusiz | 1 | NUSIZ1 for the object (copies of logs and crocodiles) |
| `$D5-$D7` | Score | 3 | Score, BCD ($D5 high) |
| `$D8` | ClockMin | 1 | Clock: minutes, BCD ($20 at the start) |
| `$D9` | ClockSec | 1 | Clock: seconds, BCD |
| `$DA` | ClockFrames | 1 | Clock: frames left in this second |
| `$DB` | VineAcc | 1 | Kernel: the vine's accumulator (the ball moves a pixel on each carry) |
| `$DC` | VineSlope | 1 | The vine's slope (added once a line) |
| `$DD` | VineDir | 1 | The vine's HMBL: $F0 swinging right, $10 left |
| `$DE-$DF` | VineSwing | 2 | The vine's swing (angle and speed) |
| `$E0` | Sound | 1 | Sound effect: index into the tune table at $FC35 (0: none) |
| `$E1` | HarryX | 1 | Harry's X |
| `$E2` | ObjX | 1 | The object's X |
| `$E3` | TunX | 1 | The tunnel object's X (the wall, or the scorpion) |
| `$E4` | HarryFrame | 1 | Harry's picture (0-8: running, standing, jumping, climbing...) |
| `$E5` | HarryReflect | 1 | REFP0: Harry facing left ($08) |
| `$E6` | TunReflect | 1 | REFP1: the scorpion facing left ($08) |
| `$E7` | JumpTime | 1 | Jump in progress (counts up; 0: not jumping) |
| `$E8` | JumpDir | 1 | The joystick at the jump's start (the jump keeps its direction) |
| `$E9` | HarryY | 1 | Harry's Y ($20 on the ground, $56 in the tunnel) |
| `$EA` | OnVine | 1 | Harry holds the vine |
| `$EB` | Trees | 1 | The tree pattern (Room bits 6-7) |
| `$EC` | OnLadder | 1 | Harry on the ladder (its rung) |
| `$ED-$F0` | Treasures | 4 | Treasures taken: one bit per treasure room |
| `$F1` | TreasuresLeft | 1 | Treasures left - 1 |
| `$F2` | Bounce | 1 | Harry knocked back by a log (lines added to his Y) |
| `$F3` | SoundStep | 1 | Sound: frames to the next note |
| `$F4` | PitEdge | 1 | The pit's edge (the shifting pits) |
| `$F5` | LetGo | 1 | Harry let go of the vine |
| `$F6-$F8` | Temp | 3 | Scratch (the kernel uses all three) |
| `$F9-$FD` | Unused | 5 | (the stack is at the top) |
| `$FE-$FF` | Stack | 2 | The stack |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$F000` | Reset | Power on: clear the RAM (and the TIA) and set up |
| `$F004` | ClearRam | Clear the RAM from X up (Game Reset comes in here with X = $D1) |
| `$F00F` | FrameTop | Vertical blank: colours, pointers, the object's rows |
| `$F0CE` | Kernel | The picture (lines 41-232): the C64 port hands over to its own code here |
| `$F30A` | SixDigits | Draw six digits (the score, the clock, the logo) |
| `$F372` | HarryRow | Harry's next row and colour |
| `$F388` | PosConvert | X position -> coarse count (Y) and fine motion (A) |
| `$F3A6` | VineStep | The vine's accumulator: HMBL |
| `$F3B6` | DigitPtrs | Two digit pointers from a BCD byte |
| `$F3CD` | LoseScore | Take 100 off the score |
| `$F3D3` | SubScore | Take A (BCD) off the score |
| `$F405` | Earth | Kernel: the earth with the hole and the ladder |
| `$F4DB` | TunnelTop | Kernel: the tunnel, upper 16 lines |
| `$F508` | TunnelBottom | Kernel: the tunnel, lower 16 lines |
| `$F546` | Floor | Kernel: the floor and the logo |
| `$F591` | Overscan | After the picture: the logic (the C64 port's ticks start here) |
| `$F658` | WaitVSync | Wait for the timer, VSYNC, the switches and the joystick |
| `$F6C6` | Play | The game: the clock, Harry, collisions, the vine, the ladder |
| `$F9DC` | RoomGfx | Object and pit graphics for this frame |
| `$FA75` | NewGame | Start a game: score, clock, lives, the first room |
| `$FAAB` | RoomLeft | Step the room number back X+1 times (Harry left the room to the left) |
| `$FABE` | RoomSetup | Set up a room from its number |
| `$FCA9` | TreasureBit | Is this room's treasure taken? (Z: no) |
| `$FCBF` | ScoreDigits | The score's digit pointers |
| `$FCCC` | Die | Harry dies |
| `$FEAD` | RoomRight | Step the room number on X+1 times (Harry left the room to the right) |
