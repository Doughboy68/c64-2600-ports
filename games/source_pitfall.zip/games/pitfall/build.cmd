@echo off
rem Build Pitfall!:
rem   build\pitfall.a26     the 2600 ROM rebuilt from source (checked against the original)
rem   build\pitfall-V.prg   the Commodore 64 version
rem   build\pitfall-V.d64   the C64 version on a disk image
rem   build\pitfall-V.crt   the C64 version as an EasyFlash cartridge (..\..\tools\mkcrt.js)
rem The original ROM (or its .zip) must be in roms_port\ (found by MD5, any file name).
rem (V: the version in the BASIC listing; file names at most 16 characters: ..\..\tools\buildname.js)
cd /d "%~dp0"
set TASS=..\..\tools\64tass\64tass.exe
set MD5=3e90cf23106f2e08b2781e41299de556
if not exist build mkdir build
if not exist 2600\pitfall.asm node ..\..\tools\disasm.js . || exit /b 1
set NAME=
for /f %%n in ('node ..\..\tools\buildname.js . pitfall') do set NAME=%%n
if "%NAME%"=="" (echo no build name: see tools\buildname.js & exit /b 1)

node ..\..\tools\rom.js %MD5% build\original.a26 >nul || exit /b 1
%TASS% -q --nostart -o build\pitfall.a26 2600\pitfall.asm || exit /b 1
fc /b build\original.a26 build\pitfall.a26 >nul && (echo OK: build\pitfall.a26 matches the original ROM) || (echo DIFFERENT: build differs from the original ROM & exit /b 1)

node tools\mkc64tables.js >nul || exit /b 1
del /q build\pitfall-*.prg build\pitfall-*.d64 build\pitfall-*.crt build\pitfall-*.lst 2>nul
%TASS% -q -C -a -o build\%NAME%.prg -L build\%NAME%.lst c64\main.asm || exit /b 1
echo OK: build\%NAME%.prg
node ..\..\tools\mkcrt.js build\%NAME%.prg build\%NAME%.crt "Pitfall!" || exit /b 1


where c1541 >nul 2>&1 || (echo c1541 not found, skipping the disk image & exit /b 0)
if exist build\%NAME%.d64 del build\%NAME%.d64
c1541 -format "pitfall,pf" d64 build\%NAME%.d64 -write build\%NAME%.prg "pitfall" >nul || exit /b 1
echo OK: build\%NAME%.d64
