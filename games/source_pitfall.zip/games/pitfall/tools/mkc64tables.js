// Generate lookup tables for the Pitfall! C64 port: c64/tables.inc (no game data in them)
//   node games/pitfall/tools/mkc64tables.js
const fs = require('fs');
const out = [];
const bytes = (label, arr, comment) => {
  out.push('', `; ${comment}`, `${label}:`);
  for (let i = 0; i < arr.length; i += 16)
    out.push('        .byte ' + arr.slice(i, i + 16).map(v => '$' + (v & 255).toString(16).padStart(2, '0')).join(', '));
};

// ---- 2600 NTSC colour -> C64 colour, indexed by (colour >> 1) = hue * 8 + luminance.
// Nearest C64 colour to the standard 2600 NTSC palette, brightened to match how the game
// looks on a TV, compared in YUV with extra weight on hue. Clearly coloured 2600 colours never
// map to the C64's greys. (As in the other ports.)
const NTSC = `000000 404040 6C6C6C 909090 B0B0B0 C8C8C8 DCDCDC ECECEC
444400 646410 848424 A0A034 B8B840 D0D050 E8E85C FCFC68
702800 844414 985C28 AC783C BC8C4C CCA05C DCB468 ECC878
841800 983418 AC5030 C06848 D0805C E09470 ECA880 FCBC94
880000 9C2020 B03C3C C05858 D07070 E08888 ECA0A0 FCB4B4
78005C 8C2074 A03C88 B0589C C070B0 D084C0 DC9CD0 ECB0E0
480078 602090 783CA4 8C58B8 A070CC B484DC C49CEC D4B0FC
140084 302098 4C3CAC 6858C0 7C70D0 9488E0 A8A0EC BCB4FC
000088 1C209C 3840B0 505CC0 6874D0 7C8CE0 90A4EC A4B8FC
00187C 1C3890 3854A8 5070BC 6888CC 7C9CDC 90B4EC A4C8FC
002C5C 1C4C78 386890 5084AC 689CC0 7CB4D4 90CCE8 A4E0FC
003C2C 1C5C48 387C64 509C80 68B494 7CD0AC 90E4C0 A4FCD4
003C00 205C20 407C40 5C9C5C 74B474 8CD08C A4E4A4 B8FCB8
143800 345C1C 507C38 6C9850 84B468 9CCC7C B4E490 C8FCA4
2C3000 4C501C 687034 848C4C 9CA864 B4C078 CCD488 E0EC9C
442800 644818 846830 A08444 B89C58 D0B46C E8CC7C FCE08C`.split(/\s+/).map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
// C64 colours as VICE shows them by default (its 'colodore' palette)
const PEPTO = ['000000','FFFFFF','96282E','5BD6CE','9F2DAD','41B936','2724C4','EFF347','9F4815','5E3500','DA5F66','474747','787878','91FF84','6864FF','AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
const BOOST = 1.3, CHROMA = 2.5, GREYS = [0, 1, 11, 12, 15];
const yuv = c => { const [r, g, b] = c; const y = 0.299 * r + 0.587 * g + 0.114 * b; return [y, 0.492 * (b - y), 0.877 * (r - y)]; };
const dist = (a, b) => { const p = yuv(a), q = yuv(b); return (p[0] - q[0]) ** 2 + CHROMA * ((p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2); };
const map = NTSC.map(c => {
  const lit = c.map(v => Math.min(255, v * BOOST));
  const mx = Math.max(...c), mn = Math.min(...c), sat = mx ? (mx - mn) / mx : 0;
  let best = -1;
  PEPTO.forEach((p, i) => {
    if (sat > 0.2 && GREYS.includes(i)) return;
    if (best < 0 || dist(lit, p) < dist(lit, PEPTO[best])) best = i;
  });
  return best;
});
// Pitfall's colours where the nearest match looks wrong: the earth ($14, dark olive) would
// become the ground's yellow: brown (chosen by eye against orange); the crocodiles ($D0, very dark green) brown; the fire's flames
// ($1E, $2E, $3E) and the gold bar ($1E) would be the ground's yellow too: orange, light red, white;
// Harry's shirt ($C8) would be the light green behind the trees ($D6), and his trousers' green ($D2,
// the canopy's too) would make a jumpsuit of it: cyan
const OVERRIDE = { 0x14: 9, 0xD0: 5, 0x1E: 8, 0x2E: 10, 0x3E: 1, 0xC8: 3 };
for (const [c, v] of Object.entries(OVERRIDE)) map[c >> 1] = v;
bytes('ColorMap', map, '2600 colour (value >> 1) -> C64 colour');

// ---- TIA sound -> SID (Stargate's mapping: the TIA circuit's periods and duties)
const TIA_CLOCK = 3579545 / 114;
const SID_CLOCKS = { '': 985248, N: 1022727 };
const AUDC = [
  [0x00, 1, 2048], [0x40, 15, 1092], [0x40, 465, 2185], [0x80, 2, 2048], [0x40, 2, 2048], [0x40, 2, 2048],
  [0x40, 31, 2380], [0x40, 31, 2113], [0x80, 1, 2048], [0x40, 31, 2113], [0x40, 31, 2380], [0x00, 1, 2048],
  [0x40, 6, 2048], [0x40, 6, 2048], [0x40, 93, 2159], [0x40, 93, 2068],
];
// AUDC 1 (the 4-bit pattern: the jump's chirp) as a 4/15 pulse, not its 8/15 duty: the pattern's
// harmonics are all equally strong, and the narrower pulse sounds sharper, closer (by ear)
bytes('SidPWLo', AUDC.map(a => a[2] & 255), 'SID pulse width per AUDC value (low byte)');
bytes('SidPWHi', AUDC.map(a => a[2] >> 8), '... high nibble');
bytes('SidWave', AUDC.map(a => a[0]), 'SID waveform per AUDC value (0 = silent)');
for (const [suffix, clock] of Object.entries(SID_CLOCKS)) {
  const flo = [], fhi = [];
  for (const [wave, div] of AUDC) for (let f = 0; f < 32; f++) {
    let hz = TIA_CLOCK / (f + 1) / div;
    if (wave === 0x80) hz /= 16;
    const reg = Math.min(0xFFFF, Math.round(hz * 16777216 / clock));
    flo.push(reg & 255); fhi.push(reg >> 8);
  }
  const sys = suffix ? 'NTSC' : 'PAL';
  bytes('SidFreqLo' + suffix, flo, `SID frequency low byte (${sys}), index AUDC * 32 + AUDF`);
  bytes('SidFreqHi' + suffix, fhi, `SID frequency high byte (${sys}), must follow the low bytes directly`);
}

// ---- bits
bytes('Reverse', [...Array(256).keys()].map(v => { let r = 0; for (let i = 0; i < 8; i++) if (v & (1 << i)) r |= 0x80 >> i; return r; }), 'the byte with its bits in reverse order (REFP0 / REFP1)');
// a nibble's 4 pixels as multicolour pairs: each bit twice (AND with $55 / $AA / $FF for "01" / "10" / "11")
bytes('Dbl', [...Array(16).keys()].map(v => { let r = 0; for (let i = 0; i < 4; i++) if (v & (1 << i)) r |= 3 << (2 * i); return r; }), 'a nibble with each bit doubled');
// the score's pixels over the playfield: a set bit "10" (the digits), a clear one "01" (the canopy)
bytes('NibDigit', [...Array(16).keys()].map(v => { let r = 0; for (let i = 0; i < 4; i++) r |= ((v & (1 << i)) ? 2 : 1) << (2 * i); return r; }), 'a nibble of digit pixels over the playfield ("10" set, "01" clear)');
// $FF >> n and its complement, n = 0..8 (pixel masks from a pixel on)
bytes('MaskFrom', [...Array(9).keys()].map(n => 0xFF >> n), 'pixels n..7 of a byte (bit 7 = pixel 0)');
bytes('Bit7', [0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01], 'pixel n of a byte (bit 7 = pixel 0)');
bytes('McPix', [0xC0, 0x30, 0x0C, 0x03], 'multicolour pixel n of a char byte (both bits)');
bytes('McPix01', [0x40, 0x10, 0x04, 0x01], 'multicolour pixel n of a char byte as "01"');

// ---- playfield cells: cell c (0..39, reflected on the right) is PF reg PfReg[c], bit PfMask[c]
const reg = [], mask = [];
for (let c = 0; c < 40; c++) {
  const k = c >= 20 ? 39 - c : c;
  if (k < 4) { reg.push(0); mask.push(1 << (4 + k)); }
  else if (k < 12) { reg.push(1); mask.push(1 << (11 - k)); }
  else { reg.push(2); mask.push(1 << (k - 12)); }
}
bytes('PfReg', reg, 'playfield cell (reflected) -> PF register 0-2');
bytes('PfMask', mask, 'playfield cell -> its bit in that register');
// 8 pixels from x = 4c + p: three cells' bits (b0 b1 b2 = cells c, c+1, c+2) -> pixel byte
bytes('PfWin', [...Array(32).keys()].map(i => { const p = i >> 3, b = i & 7; let w = 0; for (let k = 0; k < 8; k++) { const cell = (p + k) >> 2; if ((b >> (2 - cell)) & 1) w |= 0x80 >> k; } return w; }), 'PfWin[p * 8 + cells]: the playfield byte for 8 pixels from pixel p of the first of three cells');

// ---- char rows: 2600 line 41 + 8 r is the first line of row r
bytes('Mul13', [...Array(4).keys()].map(r => r * 13), '13 * n');

fs.writeFileSync(__dirname + '/../c64/tables.inc', '; Generated by games/pitfall/tools/mkc64tables.js - do not edit\n' + out.join('\n') + '\n');
console.log('wrote games/pitfall/c64/tables.inc');
