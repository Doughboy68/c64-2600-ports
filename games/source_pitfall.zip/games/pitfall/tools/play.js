// A random player for the checks: runs left or right for a while, jumps now and then, climbs
// ladders, and presses Game Reset some time after the game ends. Deterministic from a seed.
// To see many rooms (Harry rarely gets far by chance), every so often it puts Harry at a screen
// edge, running out of it: `poke(addr, value)` writes the 2600 RAM (both machines in lockstep).
//   const play = require('./play')(seed, { bias, hop }); each frame: play.step(vcs, poke)
//   sets vcs.swcha / fire / swchb (SWCHA high nibble, active low: $7F right, $BF left, $DF down, $EF up)
module.exports = function (seed = 1, opts = {}) {
  let s = seed * 16807 % 2147483647 || 1;
  const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
  const DIRS = [0x7F, 0x7F, 0xBF, 0xBF, 0xFF, 0xDF, 0xEF, 0x5F, 0x9F];  // right, left, none, down, up, down-right, down-left
  const hop = opts.hop ?? 100;
  let hold = 0, dir = opts.dir ?? 0x7F, fireLeft = 0, resetLeft = 0, frame = 0, still = 0, lastHop = 0, under = 0;
  return {
    step(vcs, poke) {
      frame++;
      const ram = a => (vcs.ram ? vcs.ram[a - 0x80] : vcs.mem[a]);
      vcs.swchb |= 1;
      // the game is over (or stuck) for a while: Game Reset
      if (ram(0x9E) !== 0 && ram(0xD8) !== 0x20) still++; else still = 0;
      if (still > 400) { resetLeft = 3; still = 0; }
      if (resetLeft-- > 0) vcs.swchb &= ~1;
      if (hold-- <= 0) {
        hold = 20 + Math.floor(rnd() * 120);
        dir = opts.bias && rnd() < 0.6 ? opts.bias : DIRS[Math.floor(rnd() * DIRS.length)];
      }
      // to the next room: Harry at an edge, running out (on the ground, alive, not on the vine)
      if (poke && hop && frame - lastHop >= hop && ram(0x9E) === 0 && (ram(0xE9) === 0x20 || ram(0xE9) === 0x56) && !ram(0xEA) && !ram(0xEC)) {
        const right = rnd() < (opts.rightHops ?? 0.9);
        lastHop = frame;
        poke(0xE1, right ? 0x92 : 0x0A);
        dir = right ? 0x7F : 0xBF; hold = 60;
      }
      // --drop: now and then Harry high up mid-screen, falling (his top rows on lines 106-126)
      if (poke && opts.drop && frame % opts.drop === 0 && ram(0x9E) === 0 && ram(0xE9) === 0x20 && !ram(0xEA)) { poke(0xE9, 2 + Math.floor(rnd() * 12)); poke(0xE1, 70 + Math.floor(rnd() * 40)); }
      // (lives kept topped up while hopping, so the game goes on)
      if (poke && hop && opts.keepLives !== false && ram(0x80) !== 0xA0 && ram(0x9E) === 0) poke(0x80, 0xA0);
      // long in the tunnel (walls block the way): back to the ground
      if (ram(0xE9) >= 0x40) under++; else under = 0;
      if (poke && hop && under > 400 && ram(0x9E) === 0 && !ram(0xEC)) { poke(0xE9, 0x20); under = 0; }
      if (fireLeft <= 0 && rnd() < (opts.jumps ?? 0.03)) fireLeft = 2 + Math.floor(rnd() * 4);
      vcs.swcha = dir;
      vcs.fire[0] = fireLeft-- > 0;
    },
  };
};
