// The palette side by side: rooms of different kinds as the 2600 shows them (the NTSC palette
// tools/mkc64tables.js matches against) and as the C64 version colours them (c64/tables.inc's ColorMap, in VICE's
// default colours), one pair per row, then a swatch per colour used: 2600 | C64.
//   node games/pitfall/tools/palsheet.js <out.png> [frames]
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('3e90cf23106f2e08b2781e41299de556');
// the 2600 NTSC palette mkc64tables.js matches against (its table, read from there)
const PALETTE = fs.readFileSync(path.join(__dirname, 'mkc64tables.js'), 'latin1').split('const NTSC = `')[1].split('`')[0].split(/\s+/).map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
const tab = fs.readFileSync(path.join(__dirname, '..', 'c64', 'tables.inc'), 'latin1');
const cm = tab.split('ColorMap:')[1].split(/\n\s*\n|;/)[0].match(/\$[0-9a-f]{2}/g).map(h => parseInt(h.slice(1), 16));
const VICE = ['000000', 'FFFFFF', '96282E', '5BD6CE', '9F2DAD', '41B936', '2724C4', 'EFF347', '9F4815', '5E3500', 'DA5F66', '474747', '787878', '91FF84', '6864FF', 'AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
const out = process.argv[2], frames = +(process.argv[3] || 6000);
const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
const play = require('./play')(5, { hop: 40 });
const poke = (a, v) => { vcs.ram[a - 0x80] = v; };
const shots = [], seen = new Set(), used = new Map();
for (let f = 0; f < frames && shots.length < 6; f++) {
  play.step(vcs, f > 0 ? poke : null);
  let g = 0; do { vcs.step(); if (++g > 2e6) throw new Error('stuck'); } while (vcs.pc !== 0xF591);
  for (let L = 41; L <= 240; L++) for (let x = 0; x < 160; x++) { const c = vcs.fb[L * 160 + x]; used.set(c, (used.get(c) || 0) + 1); }
  const kind = vcs.ram[0x94 - 0x80] * 8 + (vcs.ram[0x93 - 0x80] & 7);     // scene and object
  if (f > 100 && f % 50 === 0 && !seen.has(kind)) { seen.add(kind); shots.push(vcs.fb.slice(41 * 160, 241 * 160)); }
}
// rows: [2600 | gap | C64], 2 px per 2600 pixel across, 1 per line
const W = 160 * 2 * 2 + 16, H = shots.length * 204 + 40;
const img = Buffer.alloc(W * H * 3, 0x30);
const put = (x, y, c) => { const o = (y * W + x) * 3; img[o] = c[0]; img[o + 1] = c[1]; img[o + 2] = c[2]; };
shots.forEach((fb, k) => {
  for (let L = 0; L < 200; L++) for (let x = 0; x < 160; x++) {
    const c = fb[L * 160 + x];
    for (let d = 0; d < 2; d++) { put(x * 2 + d, k * 204 + L, PALETTE[c]); put(320 + 16 + x * 2 + d, k * 204 + L, VICE[cm[c]]); }
  }
});
const cols = [...used.entries()].filter(([, n]) => n > frames).map(([c]) => c).sort((a, b) => a - b);
cols.forEach((c, i) => {
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { put(i * 20 + x, shots.length * 204 + 4 + y, PALETTE[c]); put(i * 20 + x, shots.length * 204 + 20 + y, VICE[cm[c]]); }
});
console.log('colours used (2600 -> C64 index):', cols.map(c => '$' + (c * 2).toString(16).padStart(2, '0') + '->' + cm[c]).join(' '));
const raw = Buffer.alloc((W * 3 + 1) * H);
for (let y = 0; y < H; y++) img.copy(raw, y * (W * 3 + 1) + 1, y * W * 3, (y + 1) * W * 3);
const chunk = (type, data) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]); const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td)); return Buffer.concat([len, td, crc]); };
const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; return c; });
function crc32(buf) { let c = -1; for (const b of buf) c = CRC[(c ^ b) & 0xFF] ^ (c >>> 8); return (c ^ -1) >>> 0; }
const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2;
fs.writeFileSync(out, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
console.log(`wrote ${out}: ${shots.length} rooms`);
