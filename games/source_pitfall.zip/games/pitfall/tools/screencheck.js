// Draws the C64 frame from what the C64 code set up (the buffer's screen and characters, the
// colour registers as the raster interrupts change them down the screen, the staged sprites
// with the VIC's real restart rule: a sprite starts again only 22 lines after its last start)
// and compares it, in C64 colours, with the 2600's picture (tools/vcs.js, its colours mapped
// by the port's own table), over a random game. Runs the C64 code on the 6502 core as
// lockstep.js does.
//   node games/pitfall/tools/screencheck.js [frames] [--seed=N] [--drop=N] [--hop=N] [--show=F]
//        [--png=dir (each differing frame, and --show's: 2600 left, C64 right)] [--verbose]
const fs = require('fs');
const path = require('path');
const NBUF = +fs.readFileSync(path.join(__dirname, '..', 'c64', 'main.asm'), 'latin1').match(/^NBUF\s*=\s*(\d+)/m)[1];   // buffers (c64/main.asm)
const zlib = require('zlib');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('3e90cf23106f2e08b2781e41299de556');
const build = process.env.PF_BUILD || path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));   // (in a .logical block: the address it runs at, the second)   // (a label: it starts the source column)
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 1000);
const verbose = process.argv.includes('--verbose');
const showFrame = arg('show', -1), pngDir = arg('png', null);

class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) { this.mem[a & 0xFFFF] = v; }
  commit() {} flush() {} tick(n) { this.cycles += n; }
  call(addr, limit = 3e6) {
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error('runaway at $' + this.pc.toString(16)); }
  }
}
const c64 = new C64();
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
c64.mem.set(c64.mem.subarray(sym('GameImage'), sym('GameImage') + 0x1000), 0xF000);
c64.mem.set(c64.mem.subarray(sym('HighImage'), sym('HighImage') + sym('HighEnd') - 0x8000), 0x8000);   // (the renderer)
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x3C] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));
const M = a => c64.mem[a];
const S = {};
for (const n of ['StX', 'StY', 'StCol', 'StMsb', 'StEn', 'StBg', 'StPf', 'StDig', 'StBranch', 'StTrees', 'StGround', 'StPit', 'StEarth', 'StTunBg', 'StBlack', 'StMc1', 'StMc2',
  'VnPtr', 'ObX', 'ObPtr', 'ObCol', 'ObMsb', 'ObEn', 'TnMc1', 'TnMc2', 'TnCol', 'TnX', 'TnY', 'TnPtr', 'TnMsb', 'TnEn', 'curBuf', 'ColorMap']) S[n] = sym(n);
const VICBANK = 0x4000, CHARS = 0x4000, SCREEN = 0x5800, LINEOFS = 10, SPRYOFS = 9;

const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
const AFTER = 0xF591;
const runTick = () => { let g = 0; do { vcs.step(); if (++g > 2e6) throw new Error('2600 never got through a frame'); } while (vcs.pc !== AFTER); };

// The C64 picture of buffer `buf`: a C64 colour per 2600 pixel, lines 41-240; and which source
// drew it ('c' characters, 's0'-'s7' sprites)
function c64Picture(buf) {
  const col = new Uint8Array(160 * 262), src = new Array(160 * 262).fill('');
  const scr = SCREEN + 0x400 * buf, chs = CHARS + 0x800 * buf;
  const reg = { d021: M(S.StBg + buf), d022: M(S.StPf + buf), d023: M(S.StDig + buf), d025: M(S.StMc1 + buf), d026: M(S.StMc2 + buf) };
  // the frame top: Harry 0-4 (hires, X-expanded, behind the foreground), the vine 5-7 (hires,
  // X-expanded, in front)
  const sp = [...Array(8)].map((_, n) => ({
    n, x: M(S.StX + 8 * buf + n) + ((M(S.StMsb + buf) >> n) & 1) * 256, y: M(S.StY + 8 * buf + n), col: M(S.StCol + 8 * buf + n),
    en: (M(S.StEn + buf) >> n) & 1, ptr: n < 5 ? M(scr + 0x3F8 + n) : M(S.VnPtr + buf + NBUF * (n - 5)),
    start: -100, row: -1, mc: false, xexp: true, front: n >= 5,
  }));
  for (let L = 41; L <= 240; L++) {
    const raster = L + LINEOFS;
    // the raster interrupts' changes, at the start of these lines
    if (L === 66) reg.d023 = M(S.StBranch + buf);
    if (L === 100) { reg.d022 = M(S.StTrees + buf); sp[5].col = M(S.StTrees + buf); }
    if (L === 143) {                                     // the objects on the ground
      for (const k of [0, 1, 2]) {
        const s = sp[5 + k];
        s.mc = true; s.xexp = false; s.front = false; s.col = M(S.ObCol + buf);
        s.x = M(S.ObX + buf + NBUF * k) + ((M(S.ObMsb + buf) >> (5 + k)) & 1) * 256;
        s.y = 153 + SPRYOFS; s.en = (M(S.ObEn + buf) >> (5 + k)) & 1; s.ptr = M(S.ObPtr + buf + NBUF * k);
      }
    }
    if (L === 152) { reg.d022 = M(S.StGround + buf); reg.d021 = M(S.StPit + buf); }
    if (L === 167) reg.d023 = M(S.StEarth + buf);   // (EvEarth: during line 167)
    if (L === 168) { reg.d022 = M(S.StEarth + buf); reg.d021 = M(S.StTunBg + buf); }
    if (L === 174) {
      reg.d025 = M(S.TnMc1 + buf); reg.d026 = M(S.TnMc2 + buf);
      for (const k of [0, 1]) {
        const s = sp[5 + k];
        s.col = M(S.TnCol + buf); s.x = M(S.TnX + buf + NBUF * k) + ((M(S.TnMsb + buf) >> (5 + k)) & 1) * 256;
        s.y = M(S.TnY + buf + NBUF * k); s.en = (M(S.TnEn + buf) >> (5 + k)) & 1; s.ptr = M(S.TnPtr + buf + NBUF * k);
      }
    }
    if (L === 218) reg.d023 = M(S.StDig + buf);    // (EvFloor: from line 218)
    if (L === 221) reg.d022 = M(S.StBlack + buf);
    // characters
    const r = (L - 41) >> 3, lr = (L - 41) & 7;
    for (let x = 0; x < 160; x++) {
      const c = x >> 2, code = M(scr + 40 * r + c), byte = M(chs + 8 * code + lr), v = (byte >> (6 - 2 * (x & 3))) & 3;
      col[L * 160 + x] = [reg.d021, reg.d022, reg.d023, 0][v];
      src[L * 160 + x] = v >= 2 ? 'cF' : 'c';            // (foreground: in front of the sprites)
    }
    // sprites: a Y match starts one (if 22 lines have passed since its last start); 21 rows
    for (const s of sp) {
      if (s.en && s.y === raster - 1 && raster - s.start >= 22) { s.start = raster; }
    }
    // the VIC: the lowest-numbered sprite with a pixel there wins; then its own priority bit
    // decides against the characters' foreground ("10", "11")
    const win = new Array(160).fill(null);
    for (const s of [...sp].reverse()) {
      const row = raster - s.start;
      if (row < 0 || row >= 21 || !s.en) continue;
      const blk = VICBANK + 64 * s.ptr + 3 * row;
      const bytes = [M(blk), M(blk + 1), M(blk + 2)];
      const px0 = (s.x - 24) / 2;
      if (s.mc) {
        for (let i = 0; i < 12; i++) {
          const v = (bytes[i >> 2] >> (6 - 2 * (i & 3))) & 3;
          if (!v) continue;
          const x = px0 + i; if (x < 0 || x >= 160) continue;
          win[x] = { s, c: [0, reg.d025, s.col, reg.d026][v] };
        }
      } else {
        for (let i = 0; i < (s.xexp ? 24 : 12); i++) {
          if (!((bytes[i >> 3] >> (7 - (i & 7))) & 1)) continue;
          const x = px0 + i; if (x < 0 || x >= 160) continue;
          win[x] = { s, c: s.col };
        }
      }
    }
    for (let x = 0; x < 160; x++) {
      const w = win[x];
      if (!w || (src[L * 160 + x] === 'cF' && !w.s.front)) continue;
      col[L * 160 + x] = w.c;
      src[L * 160 + x] = 's' + w.s.n;
    }
  }
  return { col, src };
}

// colodore palette, for pictures
const PAL = ['000000','FFFFFF','96282E','5BD6CE','9F2DAD','41B936','2724C4','EFF347','9F4815','5E3500','DA5F66','474747','787878','91FF84','6864FF','AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
function savePng(file, a, b) {
  const W = 2 * 320 + 8, H = 200, raw = Buffer.alloc((W * 3 + 1) * H);
  for (let y = 0; y < H; y++) {
    raw[y * (W * 3 + 1)] = 0;
    for (let x = 0; x < W; x++) {
      let c = [40, 40, 40];
      if (x < 320) c = PAL[a[(41 + y) * 160 + (x >> 1)]];
      else if (x >= 328) c = PAL[b[(41 + y) * 160 + ((x - 328) >> 1)]];
      raw.set(c, y * (W * 3 + 1) + 1 + x * 3);
    }
  }
  const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; return c; });
  const crc32 = buf => { let c = -1; for (const v of buf) c = CRC[(c ^ v) & 0xFF] ^ (c >>> 8); return (c ^ -1) >>> 0; };
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc32(td)); return Buffer.concat([l, td, c]); };
  const ih = Buffer.alloc(13); ih.writeUInt32BE(W, 0); ih.writeUInt32BE(H, 4); ih[8] = 8; ih[9] = 2;
  fs.writeFileSync(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
}

const bias = { right: 0x7F, left: 0xBF }[arg('bias', '')];
const play = require('./play')(arg('seed', 1), { bias, drop: arg('drop', 0), hop: arg('hop', 100) });
const poke = (a, v) => { vcs.ram[a - 0x80] = v; c64.mem[a] = v; };
let bad = 0, done = 0, pngs = 0;
const bySrc = {};
for (let f = 0; f < frames; f++) {
  play.step(vcs, f > 0 ? poke : null);
  c64.mem[0x0280] = vcs.swcha; c64.mem[0x3C] = vcs.fire[0] ? 0 : 0x80; c64.mem[0x0282] = vcs.swchb;
  runTick();
  c64.call(sym('Tick'));
  // as the main loop and the frame top would: drawn into a buffer neither shown nor waiting,
  // queued; the frame top shows the oldest once two wait (so all three buffers take turns)
  const rc = c64.call(sym('Render'));
  const rb = c64.mem[sym('rbuf')], qa = sym('Queue'), qc = sym('QCount');
  c64.mem[qa + c64.mem[qc]] = rb; c64.mem[qc]++;
  if (c64.mem[qc] === NBUF - 1) { c64.mem[sym('curBuf')] = c64.mem[qa]; c64.mem[qa] = c64.mem[qa + 1]; c64.mem[qc] = NBUF - 2; }
  const buf = rb;                                       // (the picture Render drew)
  if (f < 2) continue;
  for (let a = 0x80; a < 0xF9; a++) if (vcs.ram[a - 0x80] !== c64.mem[a]) { console.log(`frame ${f}: RAM differs at $${a.toString(16)} (2600 ${vcs.ram[a - 0x80]} C64 ${c64.mem[a]}): run lockstep.js`); for (let b = 0x80; b < 0x100; b++) c64.mem[b] = vcs.ram[b - 0x80]; break; }
  const pic = c64Picture(buf);
  const want = new Uint8Array(160 * 262);
  const diffs = [];
  for (let L = 41; L <= 240; L++) for (let x = 0; x < 160; x++) {
    const w = M(S.ColorMap + vcs.fb[L * 160 + x]);
    want[L * 160 + x] = w;
    if (w !== pic.col[L * 160 + x]) diffs.push({ L, x, w, g: pic.col[L * 160 + x], s: pic.src[L * 160 + x], o: vcs.ob[L * 160 + x] });
  }
  done++;
  if (diffs.length) {
    bad++;
    for (const d of diffs) { const k = (d.s || '?') + '/' + (d.o & 1 ? 'P0' : d.o & 2 ? 'P1' : d.o & 16 ? 'BL' : d.o & 32 ? 'PF' : 'BK'); bySrc[k] = (bySrc[k] || 0) + 1; }
    if (verbose || bad <= 5) console.log(`frame ${f}: ${diffs.length} pixels differ; first ${diffs.slice(0, 6).map(d => `(${d.x},${d.L}) want ${d.w} got ${d.g} [${d.s}; 2600 ob ${d.o}]`).join(' ')}`);
    if (pngDir && pngs < 20) { savePng(path.join(pngDir, `diff-${f}.png`), want, pic.col); pngs++; }
  }
  if (f === showFrame && pngDir) savePng(path.join(pngDir, `show-${f}.png`), want, pic.col);
}
console.log(`${done} frames, ${bad} with differences` + (bad ? '; pixels by (C64 source / 2600 object): ' + Object.entries(bySrc).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([k, v]) => `${k} ${v}`).join(', ') : ''));
process.exit(bad ? 1 : 0);
