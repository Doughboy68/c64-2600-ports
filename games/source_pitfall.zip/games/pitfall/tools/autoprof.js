// The build's self-playing game (DbgAuto, as tools/c64late.js runs it in VICE: from power-on,
// the inputs by the tick count) on the plain 6502 of tools/lockstep.js: each tick's and each
// picture's cycles, replayed against frames of --budget cycles (what a frame leaves to the main
// loop) by the main loop's rules (c64/main.asm): the frames with no new picture, by situation
// and by routine. Pick the budget that gives VICE's count (c64late.js), then see where they come
// from. NTSC (a tick a frame); --pal: 6 ticks every 5 frames.
//   node games/pitfall/tools/autoprof.js --budget=N [--pal] [--profile] [--list]
const fs = require('fs');
const path = require('path');
const NBUF = +fs.readFileSync(path.join(__dirname, '..', 'c64', 'main.asm'), 'latin1').match(/^NBUF\s*=\s*(\d+)/m)[1];
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('3e90cf23106f2e08b2781e41299de556');
const build = process.env.PF_BUILD || path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));   // (in a .logical block: the address it runs at, the second)
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const budget = arg('budget', 13500), pal = process.argv.includes('--pal'), list = process.argv.includes('--list');

class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) { this.mem[a & 0xFFFF] = v; }
  commit() {}
  flush() {}
  tick(n) { this.cycles += n; }
  call(addr, limit = 2e6) {
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    const start = this.cycles;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error(`runaway at $${this.pc.toString(16)}`); }
    return this.cycles - start;
  }
}
const c64 = new C64();
const profile = process.argv.includes('--profile') ? {} : null;
const labels = [...lst.matchAll(/^\.([0-9a-f]{4})\t(?:([0-9a-f]{4})\t)?.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[2] || m[1], 16), m[3]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xF000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
if (profile) { const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc); profile[k] = (profile[k] || 0) + this.cycles - c; return r; }; }
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
c64.mem.set(c64.mem.subarray(sym('GameImage'), sym('GameImage') + 0x1000), 0xF000);
c64.mem.set(c64.mem.subarray(sym('HighImage'), sym('HighImage') + sym('HighEnd') - 0x8000), 0x8000);   // (the renderer)
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x3C] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[sym('switches')] = 0x0B;                  // (as Start: colour, both difficulties B)
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));
c64.call(sym('PowerCycle'));                       // (c64late.js: F2, then the self-playing game)
c64.mem[sym('AutoT')] = c64.mem[sym('AutoT') + 1] = 0;
c64.mem[sym('DbgAuto')] = 1;

// each frame: its ticks (PAL: 6 every 5 frames), its picture
const A = { auto: sym('DbgAuto'), q: sym('Queue'), qc: sym('QCount'), cur: sym('curBuf'), rbuf: sym('rbuf'), room: 0x81 };
const frames = [];
let acc = 0, counting = false;
const snap = () => profile ? { ...profile } : null;
const diff = (a, b) => a ? Object.fromEntries(Object.entries(b).map(([k, v]) => [k, v - (a[k] || 0)]).filter(e => e[1] > 0)) : null;
c64.mem.fill(0xff, 0xdc00, 0xdc10);                // (no keys down, no joystick)
for (let f = 0; c64.mem[A.auto] !== 0x80; f++) {
  if (f > 20000) throw new Error('the self-playing run never finished');
  const p0 = snap();
  let n = 1;
  if (pal) { acc += 6; n = 0; while (acc >= 5) { acc -= 5; n++; } }
  const inp = c64.call(sym('ReadInput'));          // (as the main loop: the inputs first)
  let tick = 0;
  for (let i = 0; i < n; i++) tick += c64.call(sym('Tick'));
  const p1 = snap();
  const render = c64.call(sym('Render')) + inp + c64.call(sym('UpdateSound'));   // (a pass: the inputs, the picture, the sound)
  const rb = c64.mem[A.rbuf];
  c64.mem[A.q + c64.mem[A.qc]] = rb; c64.mem[A.qc]++;
  if (c64.mem[A.qc] === NBUF - 1) { c64.mem[A.cur] = c64.mem[A.q]; c64.mem[A.q] = c64.mem[A.q + 1]; c64.mem[A.qc] = NBUF - 2; }
  const t = c64.mem[sym('AutoT')] + 256 * c64.mem[sym('AutoT') + 1];
  if (t >= 300 && c64.mem[A.auto] !== 0x80) counting = true;
  if (counting && c64.mem[A.auto] !== 0x80) frames.push({ f, t, tick, render, prof: profile ? diff(p0, profile) : null,
    room: c64.mem[0x81], vine: c64.mem[sym('VineEnd')] !== 0, hy: c64.mem[0xe9] });
}

// the main loop against the frame tops (as lockstep.js --budget)
let t = 0, top = budget, credit = NBUF - 1, q = 0, i = 0, repeats = 0, skipped = 0;
const blame = {}, at = [], bySit = {};
const doTop = pass => {
  if (q > 0) q--;
  else {
    repeats++;
    if (pass) {
      at.push(pass.cs[0].t);
      const sit = pass.cs.some(c => c.room !== pass.cs[0].room) || (i > 0 && frames[i - 1] && frames[i - 1].room !== pass.cs[0].room) ? 'room change' : pass.cs[0].vine ? 'vine room' : 'other';
      bySit[sit] = (bySit[sit] || 0) + 1;
      const bl = blame[sit] = blame[sit] || {};
      for (const c of pass.cs) for (const [k, v] of Object.entries(c.prof || {})) bl[k] = (bl[k] || 0) + v;
    }
  }
  credit++; top += budget;
};
while (i < frames.length) {
  while (credit <= 0 || q >= NBUF - 1) { t = top; doTop(null); }
  const owed = Math.min(credit, 4), n = Math.max(1, owed - (NBUF - 2));
  credit = owed - n; skipped += n - 1;
  const cs = frames.slice(i, i + n);
  const cost = cs.reduce((a, c) => a + c.tick, 0) + cs[cs.length - 1].render;
  const end = t + cost;
  while (top <= end) doTop({ cs });
  t = end; q++; i += n;
}
const avg = k => Math.round(frames.reduce((a, c) => a + c[k], 0) / frames.length);
console.log(`${pal ? 'PAL' : 'NTSC'} ${frames.length} frames: tick ${avg('tick')} + render ${avg('render')} cycles on average; budget ${budget}: ${repeats} frames with no new picture, ${skipped} pictures skipped`);
console.log('  by situation: ' + Object.entries(bySit).map(([k, v]) => `${k} ${v}`).join(', '));
if (list) { console.log('  at ticks: ' + at.join(' ')); const R = []; for (let i = 0; i + 2 < 252; i += 3) { const m = c64.mem, k = 0xcf00 + i; if (!(m[k] | m[k + 1] | m[k + 2])) break; R.push((m[k] + 256 * m[k + 1]) + ':' + m[k + 2].toString(16)); } console.log('  rooms: ' + R.join(' ')); }
if (profile) for (const [sit, bl] of Object.entries(blame)) console.log(`  ${sit}: their passes: ` + Object.entries(bl).sort((a, b) => b[1] - a[1]).slice(0, 14).map(([k, v]) => k + ' ' + v).join(', '));
