// A model of what Pitfall!'s kernel draws, built only from RAM (and the ROM's tables), checked
// pixel by pixel against tools/vcs.js over a random game: which objects draw each pixel, the
// collisions the game reads, and the RAM the kernel leaves behind. The C64 version draws and
// collides by the same rules, so this is where its geometry is worked out and proven.
//   node games/pitfall/tools/model.js [frames] [--seed=N] [--verbose] [--show=frame] [--bias=right|left]
//
// The kernel (2600 lines 41-232; x in 2600 pixels, 0-159; every line starts with an HMOVE, so the
// first 8 pixels are blank on every line):
//   44-51     score: six digits at x 21 + 8i (players 0 and 1, three copies each, VDEL)
//   57-64     lives (marks) and the clock, the same way
//   69-99     the canopy: playfield all on, its lower edge from the tree pattern on 92-99, and the
//             branches (players 0 and 1, two copies 32 apart) on 92-99, behind the playfield
//   100-151   the trees (playfield, one cell each), the vine (the ball, moved by an accumulator:
//             x = 78 + d * floor((L - 68) * slope / 256)), Harry (player 0, from line 106)
//   152-167   the ground (playfield, with the pits in PF2 from RAM $A0-$A6), the objects (player 1
//             with copies; rows 14-8 from RAM, 7-0 from the ROM), Harry down to line 159
//   168-182   the earth between, with the hole (PF2 = $9F) and the ladder (the ball, 4 wide)
//   183-214   the tunnel: the wall or the scorpion (player 1), the ladder, Harry
//   215-221   the floor; 224-231 the Activision logo or the copyright line (players, as the score)
// Harry's shape changes part-way across a line on 106-126 (no VDEL there; his GRP0 is written at
// pixel 85-97), on 152 (pixel 34) and 170 (pixel 40); a row is skipped between 170 and 171.
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('3e90cf23106f2e08b2781e41299de556');
const T = a => rom[(a & 0xFFFF) - 0xF000];
const P0 = 1, P1 = 2, BL = 16, PF = 32;
const sgn = h => (h < 8 ? h : h - 16);          // an HM nibble: moves left by this much

// Where the positioning code puts an object from its coarse count and fine values (lines
// 101-106 for players 0 and 1, 169-172 for the tunnel's player 1): coarse c -> pixel 15c + 6
// (0: pixel 12, then 6 more to the left from the $60 the kernel adds), then the fine moves.
function objX(coarse, hm1, hm2) {
  let x = coarse ? 15 * coarse + 6 : 12;
  x -= sgn(hm1 >> 4);
  x -= sgn(hm2 >> 4);
  return (x + 160) % 160;
}
// The kernel's conversion of an X position into coarse count and fine value (LF388)
function posOf(x) {
  let y = (x + 1) & 0xFF;
  const lo = y & 15;
  let c = y >> 4;
  let a = lo + c;
  if (a >= 15) { a -= 15; c++; }
  return { coarse: c, hm: ((a ^ 7) << 4) & 0xFF };
}

// The whole picture: ob[line * 160 + x] = the objects drawing that pixel; plus the collision
// latches the game reads and the RAM bytes the kernel leaves.
function model(ram) {
  const R = a => ram[a - 0x80];
  const W = a => R(a) | (R(a + 1) << 8);
  const ob = new Uint8Array(160 * 262);
  const ev = [];                        // per line: [pixel, key, value], applied in pixel order
  for (let l = 0; l < 262; l++) ev.push([]);
  const at = (line, px, key, v) => ev[line].push([px, key, v]);
  const eb = R(0xEB) & 3;

  // ---- score rows and the logo: six 8-pixel digits from pointers (drawn directly)
  const digits = [];                    // [line, x, byte, bit]
  const sixDigits = (top, ptrs, f8) => {
    for (let y = 7; y >= 0; y--) for (let i = 0; i < 6; i++) {
      let b = T(ptrs[i] + y);
      if (i === 0) b |= f8;
      digits.push([top + 7 - y, 21 + 8 * i, b, i & 1 ? P1 : P0]);
    }
  };
  sixDigits(44, [0, 1, 2, 3, 4, 5].map(i => W(0xC5 + 2 * i)), 0);
  const d8 = R(0xD8), d9 = R(0xD9);
  const lo2 = [0x58, (d8 >> 4) * 8 || 0x58, (d8 & 15) * 8, 0x50, (d9 >> 4) * 8, (d9 & 15) * 8];
  sixDigits(57, lo2.map((v, i) => v | (R(0xC6 + 2 * i) << 8)), R(0x80));
  let ly = 8, la = R(0xE0) ? 0 : R(0x9E);
  la >>= 3;
  if (la < 0x14) { ly = 0; if (la >= 0x0C) ly = la - 0x0C; }
  const logoLo = [0, 1, 2, 3, 4, 5].map(i => (ly + 0xA8 - 0x10 * (5 - i)) & 0xFF);
  sixDigits(224, logoLo.map((v, i) => v | (R(0xC6 + 2 * i) << 8)), 0);

  // ---- the playfield
  const pfv = [0xFF, 0xFF, 0xFF];
  for (const j of [0, 1, 2, 3]) { const v = T(0xF3EF + 4 * eb + j); at(92 + 2 * j, -8, 'pf', [v, v, v]); }
  at(100, -50, 'pf1', T(0xFBCE + eb)); at(100, 10, 'pf0', 0); at(100, 19, 'pf2', T(0xFBD2 + eb));
  at(152, -17, 'pf', [0xFF, 0xFF, 0xFF]);
  for (let l = 153; l <= 159; l++) at(l, 13, 'pf2', R(0xA0 + 159 - l));
  for (let l = 160; l <= 166; l++) at(l, 7, 'pf2', R(0xA0 + l - 160));
  at(168, -2, 'pf1', 0xFF); at(168, 16, 'pf2', R(0x9F));
  at(183, -23, 'pf0', 0); at(183, 10, 'pf1', 0); at(183, 19, 'pf2', 0);
  at(215, -50, 'pf', [0xFF, 0xFF, 0xFF]);

  // ---- the branches (lines 92-99): players 0 and 1, two copies 32 apart
  const bx0 = objX(T(0xFBD6 + eb) & 15, 0, T(0xFBD6 + eb)) - 0;  // (see below: positioned on line 67)
  const branch = branchPos(eb);

  // ---- Harry (player 0): the row shown on each line, with where it changes
  const harry = [];                     // per line: [[pixel, byte], ...]
  for (let l = 0; l < 262; l++) harry.push([]);
  const hptr = W(0xB5);
  const row = y => (y < 0x16 ? T(hptr + y) : 0);
  let Y = R(0xE9) + R(0xF2);
  Y = (Y + 0x15 + (Y > 0xFF ? 1 : 0)) & 0xFF;
  let g0n = 0, shown = 0;
  const show = (l, px, v) => { harry[l].push([px, v]); shown = v; };
  const slope = R(0xDC);
  const carry = k => (Math.floor(k * slope / 256) - Math.floor((k - 1) * slope / 256)) > 0;
  for (let l = 106; l <= 126; l++) {            // no VDEL: the write shows from its pixel on
    Y = (Y - 1) & 0xFF;
    const c = carry(l - 67), inR = Y < 0x16;     // (this line's vine step: the 39th to 59th of the frame)
    g0n = inR ? row(Y) : 0;
    show(l, inR ? (c ? 97 : 91) : (c ? 91 : 85), g0n);
  }
  for (let l = 127; l <= 151; l++) {            // VDEL: last line's write, from the line start
    show(l, -20, g0n);
    Y = (Y - 1) & 0xFF; g0n = Y < 0x16 ? row(Y) : 0;
  }
  const inR151 = Y < 0x16;
  show(152, 34, g0n);
  for (let l = 152; l <= 158; l++) { Y = (Y - 1) & 0xFF; g0n = Y < 0x16 ? row(Y) : 0; show(l + 1, -10, g0n); }
  const f6 = (Y - 8) & 0xFF;
  show(160, -26, 0);
  Y = f6; g0n = Y < 0x16 ? row(Y) : 0;
  show(169, -23, g0n);
  Y = (Y - 1) & 0xFF;
  if (Y < 0x16) { g0n = row(Y); show(170, 40, g0n); }
  Y = (Y - 2) & 0xFF; g0n = Y < 0x16 ? row(Y) : 0;
  for (let l = 171; l <= 182; l++) { show(l, -35, g0n); Y = (Y - 1) & 0xFF; g0n = Y < 0x16 ? row(Y) : 0; }
  let X = Y;                                     // (F4A1: $F6 = Y)
  show(183, -50, g0n);
  for (let l = 184; l <= 214; l++) { X = (X - 1) & 0xFF; show(l, -30, X < 0x16 ? row(X) : 0); }
  show(215, 1, 0);
  const hx = objX(R(0x98), R(0x95), R(0x98) ? 0 : 0x60);
  const href = R(0xE5) & 8;

  // ---- objects (player 1): rows per line
  const obj = [];
  for (let l = 0; l < 262; l++) obj.push([]);
  for (let l = 153; l <= 159; l++) obj[l].push([-10, R(0xAE + 159 - l)]);
  for (let l = 160; l <= 167; l++) obj[l].push([-26, T(W(0xB7) + 167 - l)]);
  obj[168].push([-17, 0]);
  obj[183].push([-50, T(W(0xBD) + 15)]);
  for (let l = 184; l <= 198; l++) obj[l].push([-29, T(W(0xBD) + 198 - l)]);
  for (let l = 199; l <= 214; l++) obj[l].push([-29, T(W(0xC1) + 214 - l)]);
  obj[215].push([1, 0]);
  const ox = objX(R(0x99), R(0x96), R(0x99) ? 0 : 0x60);
  const ux = objX(R(0x9A), R(0x97), R(0x9A) ? 0 : 0x60);
  const nus1 = R(0xD4), ref1 = R(0xE6) & 8;

  // ---- the ball: the vine (1 wide), then the ladder (4 wide, x 78)
  const ball = [];                      // per line: [[pixel, on, x, w], ...]
  for (let l = 0; l < 262; l++) ball.push([]);
  const sc = R(0x94);
  let blOn = !!(T(0xFCA1 + sc) & 2);
  if (T(0xFFEE + sc)) blOn = !!(R(0x93) & 2);
  const dd = -sgn(R(0xDD) >> 4);
  let bx = 78;
  for (let l = 41; l <= 168; l++) {
    if (l >= 69 && l <= 151) bx = (78 + dd * Math.floor((l - 68) * slope / 256) + 1600) % 160;
    else if (l > 151 && carry(83)) bx = (bx + dd + 160) % 160;
    if (l >= 128 && l <= 151 && (151 - l) < R(0x92)) blOn = false;
    ball[l].push([-60, blOn, bx, 1]);
  }
  ball[168].push([25, blOn, bx, 4], [67, blOn, 71, 4]);
  const lad = v => !!(v & R(0x9D) & 2);
  ball[169].push([-60, blOn, 78, 4]); ball[170].push([-60, blOn, 78, 4]);
  for (let l = 171; l <= 182; l++) ball[l].push([-5, (blOn = lad(T(0xFC95 + 182 - l))), 78, 4]);
  ball[183].push([37, (blOn = !!(R(0x9D) & 2)), 78, 4]);
  for (let l = 184; l <= 198; l++) ball[l].push([34, lad(T(0xFC95 + 198 - l)), 78, 4]);
  for (let l = 199; l <= 214; l++) ball[l].push([37, lad(T(0xFC95 + 214 - l)), 78, 4]);
  ball[215].push([-17, false, 78, 4]);

  // ---- draw
  const playerBits = (g, x, px, nus, ref) => {
    const copies = [[0], [0, 16], [0, 32], [0, 16, 32], [0, 64], [0], [0, 32, 64], [0]][nus & 7];
    const d = (px - x + 160) % 160;
    for (const c of copies) { const dd2 = d - c; if (dd2 >= 0 && dd2 < 8) return (g >> (ref ? dd2 : 7 - dd2)) & 1; }
    return 0;
  };
  const byPx = list => list.slice().sort((p, q) => p[0] - q[0]);
  let pf = [0xFF, 0xFF, 0xFF];
  let hv = 0, ov = 0, bst = [false, 78, 1];   // (each carried from line to line)
  for (let l = 41; l <= 232; l++) {
    const e = byPx(ev[l]), ht = byPx(harry[l]), ot = byPx(obj[l]), bt = byPx(ball[l]);
    let ei = 0, hi = 0, oi = 0, bi = 0;
    for (let x = 0; x < 160; x++) {
      while (ei < e.length && e[ei][0] <= x) {
        const [, k, v] = e[ei++];
        if (k === 'pf') pf = v.slice(); else pf[+k[2]] = v;
      }
      while (hi < ht.length && ht[hi][0] <= x) hv = ht[hi++][1];
      while (oi < ot.length && ot[oi][0] <= x) ov = ot[oi++][1];
      while (bi < bt.length && bt[bi][0] <= x) bst = bt[bi++].slice(1);
      if (x < 8) continue;                  // HMOVE blank
      let o = 0;
      let c = x >> 2;
      if (c >= 20) c = 39 - c;
      const pfOn = c < 4 ? (pf[0] >> (4 + c)) & 1 : c < 12 ? (pf[1] >> (11 - c)) & 1 : (pf[2] >> (c - 12)) & 1;
      if (pfOn) o |= PF;
      if (bst[0] && (x - bst[1] + 160) % 160 < bst[2]) o |= BL;
      if (l >= 106 && l <= 215 && hv && playerBits(hv, hx, x, 0, href)) o |= P0;
      if (ov) {                             // (REFP1 changes at pixel 88 of line 167, NUSIZ1 at 109 of 182)
        const ref = l < 167 || (l === 167 && x < 88) ? 0 : ref1;
        const nus = l < 182 || (l === 182 && x < 109) ? nus1 : 0;
        if (playerBits(ov, l <= 168 ? ox : ux, x, nus, ref)) o |= P1;
      }
      if (l >= 92 && l <= 99) {
        const g = T(0xFBC5 + 100 - l);
        if (playerBits(g, branch[0], x, 2, 0)) o |= P0;
        if (playerBits(g, branch[1], x, 2, 0)) o |= P1;
      }
      ob[l * 160 + x] = o;
    }
  }
  for (const [l, x, b, bit] of digits) for (let i = 0; i < 8; i++) if ((b >> (7 - i)) & 1 && x + i >= 8) ob[l * 160 + x + i] |= bit;

  // ---- collisions: latched from line 106 (CXCLR) to where the game reads them
  const latch = (l1, p1, a, b) => {      // any pixel with both a and b, from line 106 to (l1, p1)
    for (let l = 106; l <= l1; l++) for (let x = 0; x < (l === l1 ? Math.max(0, Math.min(160, p1)) : 160); x++) {
      const o = ob[l * 160 + x]; if ((o & a) && (o & b)) return 1;
    }
    return 0;
  };
  const enab151 = R(0x92) > 0;
  const p151 = (inR151 ? 106 : 76) + (enab151 ? 6 : 0);
  const k85 = (latch(151, p151, P0, PF) << 7) | (latch(151, p151, P0, BL) << 6);
  const z9a = R(0x9A) === 0;
  const k86 = (latch(167, z9a ? 34 : 31, P0, P1) << 7) | (latch(167, z9a ? 49 : 46, P0, PF) << 6) | (latch(167, z9a ? 49 : 46, P0, BL) << 5);
  const cxppmm = latch(232, 160, P0, P1) << 7;
  const logoF6 = T(logoLo[5] | (R(0xD0) << 8));
  const kram = { 0x85: k85, 0x86: k86, 0xDB: (83 * slope) & 0xFF, 0xF6: logoF6, 0xF7: 0xFF, 0xF8: 0 };
  logoLo.forEach((v, i) => { kram[0xC5 + 2 * i] = v; });
  return { ob, k85, k86, cxppmm, kram, hx, ox, ux, branch };
}
// The branches' positions (line 67-68, from the tree pattern): RESP0 after a loop of the
// pattern's count, RESP1 after a second loop, then a fine move each
function branchPos(eb) {
  const a = T(0xFBD6 + eb), b = T(0xFBDA + eb);
  const n = a & 15, m = b & 15;
  const x0 = (15 * n + 36 - 68 + 5) - sgn(a >> 4);
  const x1 = (15 * n + 15 * m + 93 - 68 + 5) - sgn(b >> 4);
  return [(x0 + 160) % 160, (x1 + 160) % 160];
}

module.exports = { model, objX, posOf, branchPos, T, sgn };

// ------------------------------------------------------------------ check
if (require.main === module) {
  const vcs = new VCS(rom);
  if (!process.argv.includes('--plain')) vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
  const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 2000);
  const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
  const verbose = process.argv.includes('--verbose');
  const showFrame = +opt('show', -1);
  const bias = { right: 0x7F, left: 0xBF, down: 0xDF }[opt('bias', '')];
  const play = require('./play')(+opt('seed', 1), { bias, drop: +opt('drop', 0) });
  const KERNEL = 0xF0CE, AFTER = 0xF591, CX = 0xF73A;
  let bad = 0, checked = 0, cxBad = 0, ramBad = 0;
  const names = { 1: 'P0', 2: 'P1', 16: 'BL', 32: 'PF' };
  const seen = { vine: 0, ladder: 0, under: 0, harryUnder: 0, p0p1: 0, p0bl: 0, rooms: new Set() };
  let snap = null, cxAtRead = null, pending = null;
  for (let f = 0; f < frames; f++) {
    play.step(vcs, (a, v) => { vcs.ram[a - 0x80] = v; });
    // run to the kernel's start (leaving its wait loop first), snapshot, then to the end of it
    while (vcs.pc >= KERNEL && vcs.pc < KERNEL + 5) vcs.step();
    let g = 0;
    while (vcs.pc !== KERNEL) {
      if (vcs.pc === 0xF5BA && pending) pending.cxppmm = 0;      // (the logic clears the latches when Harry comes back after a death)
      if (vcs.pc === CX) cxAtRead = (vcs.cx >> 13) & 1;
      vcs.step(); if (++g > 2e6) throw new Error('no kernel');
    }
    // the previous frame's CXPPMM (read in this tick's logic) against the previous model
    if (pending && cxAtRead !== null && f > 2) { if ((pending.cxppmm >> 7) !== cxAtRead) { cxBad++; if (cxBad <= 5) console.log(`frame ${vcs.frames - 1}: CXPPMM vcs ${cxAtRead} model ${pending.cxppmm >> 7}`); } if (cxAtRead) seen.p0p1++; }
    cxAtRead = null;
    snap = vcs.ram.slice();
    const f0 = vcs.frames;
    while (vcs.pc !== AFTER) { vcs.step(); if (++g > 4e6) throw new Error('no kernel end'); }
    const m = model(snap);
    pending = m;
    if (f < 3) continue;
    checked++;
    seen.rooms.add(snap[0x81 - 0x80]);
    if (snap[0x9D - 0x80]) seen.ladder++;
    if (m.k85 & 0x40) seen.p0bl++;
    // the RAM the kernel left
    const rd = [];
    for (const [a, v] of Object.entries(m.kram)) if (vcs.ram[a - 0x80] !== v) rd.push(`$${(+a).toString(16)} vcs ${vcs.ram[a - 0x80].toString(16)} model ${v.toString(16)}`);
    if (rd.length) { ramBad++; if (ramBad <= 5) console.log(`frame ${f0}: kernel RAM differs: ${rd.join(', ')}`); }
    const diffs = [];
    for (let y = 41; y <= 232; y++) for (let x = 0; x < 160; x++) {
      const a = vcs.ob[y * 160 + x] & (P0 | P1 | BL | PF), b = m.ob[y * 160 + x];
      if (a !== b) diffs.push({ y, x, a, b });
    }
    if (diffs.length) {
      bad++;
      if (verbose || bad <= 5) {
        const byBit = {};
        for (const d of diffs) for (const bit of [1, 2, 16, 32]) if ((d.a ^ d.b) & bit) { const k = names[bit] + (d.a & bit ? '-' : '+'); byBit[k] = (byBit[k] || 0) + 1; }
        console.log(`frame ${f0}: ${diffs.length} pixels differ: ${Object.entries(byBit).map(([k, v]) => k + ' ' + v).join(', ')}; first at ` +
          diffs.slice(0, 6).map(d => `(${d.x},${d.y}) vcs ${d.a} model ${d.b}`).join(' '));
      }
    }
    if (f0 === showFrame || (showFrame === -2 && diffs.length && bad === 1)) {
      for (let y = 41; y <= 232; y++) {
        let s = '';
        for (let x = 0; x < 160; x++) { const a = vcs.ob[y * 160 + x] & 51, b = m.ob[y * 160 + x]; s += a === b ? (a ? (a & P0 ? '0' : a & P1 ? '1' : a & BL ? 'b' : '#') : '.') : (a ? 'V' : 'M'); }
        console.log(String(y).padStart(3), s);
      }
    }
  }
  console.log(`${checked} frames, ${bad} differ in pixels, ${ramBad} in kernel RAM, ${cxBad} in CXPPMM; ${seen.rooms.size} rooms, ladder frames ${seen.ladder}, vine grabbed ${seen.p0bl}, Harry hit ${seen.p0p1}`);
  process.exit(bad || ramBad || cxBad ? 1 : 0);
}
