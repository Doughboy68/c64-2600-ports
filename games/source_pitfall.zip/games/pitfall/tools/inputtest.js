// Test the C64 version's controls (ReadInput, c64/input.asm) on a plain 6502 with an emulated
// keyboard matrix and joysticks: the 2600 ports it fills in for each key (README.md, "Standard
// controls"; Pitfall! is for one player: joystick port 2 or 1, W A S D and space).
//   node games/pitfall/tools/inputtest.js
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('3e90cf23106f2e08b2781e41299de556');
const files = require('../../../tools/buildname').files(path.join(__dirname, '..', 'build'));
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
// C64 keyboard: [row (CIA 1 port A bit), column (port B bit)]
const KEYS = { F1: [0, 4], F3: [0, 5], F5: [0, 6], F7: [0, 3], LSHIFT: [1, 7], RSHIFT: [6, 4], W: [1, 1], A: [1, 2], S: [1, 5], D: [2, 2], SPACE: [7, 4] };
let held = [], joy2 = 0xFF, joy1 = 0xFF, portA = 0xFF;
class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) {
    a &= 0xFFFF;
    if (a === 0xDC00) return portA & joy2;
    if (a === 0xDC01) {
      let v = 0xFF;
      for (const k of held) { const [r, c] = KEYS[k]; if (!(portA & (1 << r))) v &= ~(1 << c); }
      return v & joy1;
    }
    return this.mem[a];
  }
  write(a, v) { a &= 0xFFFF; if (a === 0xDC00) portA = v; this.mem[a] = v; }
  commit() {}
  flush() {}
  tick(n) { this.cycles += n; }
  call(addr) {
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > 1e6) throw new Error('runaway'); }
  }
}
const c64 = new C64(), M = c64.mem;
M.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
M[sym('switches')] = 0x0B;                      // (as Start: colour, both difficulties B)
const FROZEN = 0x9E, CLOCKMIN = 0xD8, CLOCKSEC = 0xD9, SOUND = 0xE0;
const read = (keys, j2 = 0xFF, j1 = 0xFF) => {
  held = keys; joy2 = j2; joy1 = j1;
  c64.call(sym('ReadInput'));
  return { swcha: M[0x280], swchb: M[0x282], inpt4: M[0x3C], power: M[sym('PowerReq')] };
};
const hex = v => '$' + v.toString(16).padStart(2, '0');
let fails = 0;
const check = (name, got, want) => {
  const bad = Object.keys(want).filter(k => got[k] !== want[k]);
  if (bad.length) fails++;
  console.log(`${bad.length ? 'FAIL' : 'ok  '} ${name}${bad.length ? ': ' + bad.map(k => `${k} ${hex(got[k])} (want ${hex(want[k])})`).join(', ') : ''}`);
};
M[FROZEN] = 0;                                  // a game running
check('nothing', read([]), { swcha: 0xFF, swchb: 0x0B, inpt4: 0x80, power: 0 });
check('W: up', read(['W']), { swcha: 0xEF });
check('S: down', read(['S']), { swcha: 0xDF });
check('A: left', read(['A']), { swcha: 0xBF });
check('D: right', read(['D']), { swcha: 0x7F });
check('Space: fire (jump)', read(['SPACE']), { inpt4: 0x00, swcha: 0xFF });
check('W + D: up and right', read(['W', 'D']), { swcha: 0x6F });
check('joystick port 2: up', read([], 0xFE), { swcha: 0xEF });
check('joystick port 2: right + fire', read([], 0xE7), { swcha: 0x7F, inpt4: 0x00 });
check('joystick port 1: left', read([], 0xFF, 0xFB), { swcha: 0xBF });
check('joystick port 1: down + fire', read([], 0xFF, 0xED), { swcha: 0xDF, inpt4: 0x00 });
check('port 1 fire (a key line pulled low): not F1 or space', read([], 0xFF, 0xEF), { swcha: 0xFF, swchb: 0x0B, inpt4: 0x00 });
check('F1: Game Reset (held)', read(['F1']), { swchb: 0x0A, power: 0 });
check('F1 released', read([]), { swchb: 0x0B });
check('F3: Game Select (held)', read(['F3']), { swchb: 0x09 });
check('F5: B&W', (read(['F5']), read([])), { swchb: 0x03 });
check('F5 again: colour', (read(['F5']), read([])), { swchb: 0x0B });
check('F7: left difficulty A', (read(['F7']), read([])), { swchb: 0x4B });
check('F8 (shift + F7): right difficulty A', (read(['LSHIFT', 'F7']), read([])), { swchb: 0xCB });
check('F7, F8 again: both B', (read(['F7']), read([]), read(['RSHIFT', 'F7']), read([])), { swchb: 0x0B });
check('F2 (shift + F1): power off and on, not Game Reset', read(['LSHIFT', 'F1']), { power: 1, swchb: 0x0B });
M[sym('PowerReq')] = 0;
check('F2 held: once', (read(['RSHIFT', 'F1'])), { power: 0 });
read([]);
M[FROZEN] = 0xFF; M[CLOCKMIN] = 0x20; M[CLOCKSEC] = 0;     // the start: frozen at 20:00
check('fire at the start: a push up (starts the game)', read(['SPACE']), { swcha: 0xEF, inpt4: 0x00, swchb: 0x0B });
M[CLOCKMIN] = 0x12; M[CLOCKSEC] = 0x34; M[SOUND] = 0;    // over: frozen, no tune playing
check('fire after the game: Game Reset', read(['SPACE']), { swchb: 0x0A });
M[SOUND] = 5;
check('fire while the tune plays: nothing more', read(['SPACE']), { swchb: 0x0B });
console.log(fails ? `${fails} failed` : 'all passed');
process.exit(fails ? 1 : 0);
