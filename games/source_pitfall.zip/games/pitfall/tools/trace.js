// Trace the TIA writes of one frame in tools/vcs.js: for each scan line, the registers written
// (with the colour clock and value), to see how the kernel is built.
//   node games/pitfall/tools/trace.js <frame> [--fire | --seed=N (the random player)] [--lines=a-b] [--regs=GRP0,RESP0,...]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('3e90cf23106f2e08b2781e41299de556'));
const NAMES = 'VSYNC VBLANK WSYNC RSYNC NUSIZ0 NUSIZ1 COLUP0 COLUP1 COLUPF COLUBK CTRLPF REFP0 REFP1 PF0 PF1 PF2 RESP0 RESP1 RESM0 RESM1 RESBL AUDC0 AUDC1 AUDF0 AUDF1 AUDV0 AUDV1 GRP0 GRP1 ENAM0 ENAM1 ENABL HMP0 HMP1 HMM0 HMM1 HMBL VDELP0 VDELP1 VDELBL RESMP0 RESMP1 HMOVE HMCLR CXCLR'.split(' ');
const frame = +(process.argv[2] || 100);
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const [l0, l1] = opt('lines', '0-262').split('-').map(Number);
const only = opt('regs', '') ? new Set(opt('regs', '').split(',')) : null;
const seed = +opt('seed', 0);
if (seed) { const play = require('./play')(seed); while (vcs.frames < frame - 1) { play.step(vcs); vcs.runFrames(1); } }
if (process.argv.includes('--fire')) { vcs.runFrames(10); vcs.fire[0] = true; vcs.runFrames(5); vcs.fire[0] = false; }
vcs.runFrames(frame - vcs.frames - 1);
const lines = new Map();
const orig = vcs.tiaWrite.bind(vcs);
vcs.tiaWrite = (a, v) => {
  const name = NAMES[a & 0x3F] || `$${(a & 0x3F).toString(16)}`;
  if (!only || only.has(name)) {
    const l = vcs.line;
    if (!lines.has(l)) lines.set(l, []);
    lines.get(l).push(`${name}=${v.toString(16).padStart(2, '0')}@${vcs.clock}`);
  }
  orig(a, v);
};
vcs.runFrames(1);
for (const [l, w] of [...lines].sort((a, b) => a[0] - b[0])) if (l >= l0 && l <= l1) console.log(String(l).padStart(3), w.join(' '));
