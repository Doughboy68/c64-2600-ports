// The 2600 colours Pitfall! shows (by what draws them: Harry P0, objects P1, vine BL, playfield,
// background), how many pixels, and the C64 colour c64/tables.inc maps each to. Plays the
// original through many rooms (tools/play.js) in tools/vcs.js.
//   node games/pitfall/tools/colours.js [frames]
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('3e90cf23106f2e08b2781e41299de556');
const frames = +(process.argv[2] || 20000);
const tab = fs.readFileSync(path.join(__dirname, '..', 'c64', 'tables.inc'), 'latin1');
const cm = tab.split('ColorMap:')[1].split(/\n\s*\n|;/)[0].match(/\$[0-9a-f]{2}/g).map(h => parseInt(h.slice(1), 16));
const C64 = ['black', 'white', 'red', 'cyan', 'purple', 'green', 'blue', 'yellow', 'orange', 'brown', 'light red', 'dark grey', 'grey', 'light green', 'light blue', 'light grey'];
const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
const play = require('./play')(3, { hop: 60 });
const poke = (a, v) => { vcs.ram[a - 0x80] = v; };
const use = {};
const AFTER = 0xF591;
for (let f = 0; f < frames; f++) {
  play.step(vcs, f > 0 ? poke : null);
  let g = 0; do { vcs.step(); if (++g > 2e6) throw new Error('stuck'); } while (vcs.pc !== AFTER);
  for (let L = 41; L <= 240; L++) for (let x = 8; x < 160; x++) {
    const i = L * 160 + x, o = vcs.ob[i];
    const who = o & 1 ? 'Harry' : o & 2 ? 'object' + (vcs.ram[0x93 - 0x80] & 7) + (L > 170 ? 't' : '') : o & 16 ? 'vine' : o & 32 ? 'playfield' : 'background';
    const k = who + ' ' + vcs.fb[i];
    use[k] = (use[k] || 0) + 1;
  }
}
const rows = Object.entries(use).map(([k, n]) => { const [who, c] = k.split(' '); return { who, c: +c, n }; }).filter(r => r.n > (process.env.MIN || 2) * frames / 1000);
rows.sort((a, b) => a.who.localeCompare(b.who) || b.n - a.n);
for (const r of rows) console.log(`${r.who.padEnd(11)} $${(r.c * 2).toString(16).padStart(2, '0')}  ${String(Math.round(r.n / frames)).padStart(6)} px/frame  -> ${C64[cm[r.c]]}`);
