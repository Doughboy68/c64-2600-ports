// Run the C64 port's game ticks (the patched 2600 program plus our collision code, from
// build/pitfall-<version>.prg) on a plain 6502 with 64K of memory, side by side with the
// original game in tools/vcs.js, with the same joystick inputs. After every frame the two must
// have the same 2600 RAM at the same point: just after the picture (the 2600 has drawn it; the
// C64 side has worked out its collisions and the RAM the kernel leaves). Any difference is a
// bug in a patch or in the collisions. Also: the C64's CXPPMM against what the 2600 latched
// for the same picture, read in the next tick. Render runs each frame too (crashes, cycles).
//   node games/pitfall/tools/lockstep.js [frames] [--seed=N] [--drop=N] [--hop=N] [--power=F]
//        [--verbose] [--profile[=Label]] [--slow=cycles] [--budget=cycles]
// --budget: the main loop's passes replayed against frames of that many cycles (what the frame
// leaves to the main loop; NTSC: a tick a frame): frames with no new picture, and (with
// --profile) what the passes they came during spent their time on
const fs = require('fs');
const path = require('path');
const NBUF = +fs.readFileSync(path.join(__dirname, '..', 'c64', 'main.asm'), 'latin1').match(/^NBUF\s*=\s*(\d+)/m)[1];   // buffers (c64/main.asm)
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('3e90cf23106f2e08b2781e41299de556');
const build = process.env.PF_BUILD || path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));   // (in a .logical block: the address it runs at, the second)   // (a label: it starts the source column)
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 3000);
const verbose = process.argv.includes('--verbose');

// ---- the C64 side: the VCS 6502 core on a flat 64K memory
class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) {
    a &= 0xFFFF;
    // the 2600 program must keep out of the C64's zero page: $00 / $01 and ours at $40-$7F
    if (this.pc >= 0xF000 && (a < 2 || (a >= 0x40 && a < 0x80))) throw new Error(`the 2600 code at $${this.pc.toString(16)} wrote $${a.toString(16)}`);
    this.mem[a] = v;
  }
  commit() {}
  flush() {}
  tick(n) { this.cycles += n; }
  call(addr, limit = 2e6) {      // JSR addr from a stub, run until it returns
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    const start = this.cycles;
    const ring = [];
    for (let i = 0; this.pc !== STUB + 3; i++) { ring[i & 31] = this.pc; this.step(); if (i > limit) throw new Error(`runaway at $${this.pc.toString(16)}; last PCs ${ring.map(p => p.toString(16)).join(' ')}; X ${this.x} Y ${this.y} A ${this.a}`); }
    return this.cycles - start;
  }
}
const c64 = new C64();
const profile = process.argv.some(a => a === '--profile' || a.startsWith('--profile=')) ? {} : null;
const labels = [...lst.matchAll(/^\.([0-9a-f]{4})\t(?:([0-9a-f]{4})\t)?.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[2] || m[1], 16), m[3]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xF000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
const profLabel = arg('profile', null);
const vineOnly = process.argv.includes('--vineonly');
const slowProf = arg('slowprof', 0);
const pcProfile = typeof profLabel === 'string' ? {} : null;
if (profile) { const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc), d = this.cycles - c; profile[k] = (profile[k] || 0) + d; if (pcProfile && k === profLabel) pcProfile[pc] = (pcProfile[pc] || 0) + d; return r; }; }
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
// what Start does that matters here: the 2600 image at $F000, the RIOT ports, our work RAM
c64.mem.set(c64.mem.subarray(sym('GameImage'), sym('GameImage') + 0x1000), 0xF000);
c64.mem.set(c64.mem.subarray(sym('HighImage'), sym('HighImage') + sym('HighEnd') - 0x8000), 0x8000);   // (the renderer)
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x3C] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));

// ---- the original: run from the end of one picture ($F591) to the end of the next
const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
const AFTER = 0xF591, CXREAD = 0xF73A;
let cxRead = null, kernelRam = null, c64Read = null;
const origStep = vcs.step.bind(vcs);
vcs.step = function () { if (this.pc === CXREAD) cxRead = (this.cx >> 13) & 1; if (this.pc === 0xF0CE && !kernelRam) kernelRam = this.ram.slice(); return origStep(); };
// (the C64's CXPPMM as its tick reads it: the game may have cleared it on the way)
{ const st = c64.step.bind(c64); c64.step = function () { if (this.pc === CXREAD) c64Read = this.mem[0x37] >> 7; return st(); }; }
const runTick = () => { let g = 0; do { vcs.step(); if (++g > 2e6) throw new Error('2600 never got through a frame'); } while (vcs.pc !== AFTER); };

const NAMES = {};
for (const [a, n, size] of require('../2600/symbols.js').ram) for (let i = 0; i < size; i++) NAMES[a + i] = size > 1 ? `${n}+${i}` : n;
// bytes the two may legitimately disagree on: the stack (on the 2600 it is page zero's top;
// $F9-$FF are never used as variables)
const IGNORE = new Set([0xF9, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF]);

const bias = { right: 0x7F, left: 0xBF }[arg('bias', '')];
const play = require('./play')(arg('seed', 1), { bias, drop: arg('drop', 0), hop: arg('hop', 100) });
const poke = (a, v) => { vcs.ram[a - 0x80] = v; c64.mem[a] = v; };
const power = arg('power', 0), slow = arg('slow', 0);
let vineN = 0, vineSum = 0;
const budget = +arg('budget', 0), costs = [];
let maxCycles = 0, totalCycles = 0, bad = 0, done = 0, maxRender = 0, totalRender = 0, cxSeen = 0;
const rooms = new Set();
for (let f = 0; f < frames; f++) {
  play.step(vcs, f > 0 ? poke : null);
  c64.mem[0x0280] = vcs.swcha; c64.mem[0x3C] = vcs.fire[0] ? 0 : 0x80; c64.mem[0x0282] = vcs.swchb;
  if (power && f === power) { c64.call(sym('PowerCycle')); vcs.pc = 0xF000; vcs.s = 0xFD; }   // F2 on both
  cxRead = null; c64Read = null; kernelRam = null;
  const profBefore = profile && (vineOnly || slowProf || budget) ? { ...profile } : null;
  runTick();
  const cyc = c64.call(sym('Tick'));
  const cP0P1 = c64Read;                                 // the C64's CXPPMM for the last picture
  maxCycles = Math.max(maxCycles, cyc); totalCycles += cyc;
  // as the main loop and the frame top would: drawn into a buffer neither shown nor waiting,
  // queued; the frame top shows the oldest once two wait (so all three buffers take turns)
  const rc = c64.call(sym('Render'));
  const rb = c64.mem[sym('rbuf')], qa = sym('Queue'), qc = sym('QCount');
  c64.mem[qa + c64.mem[qc]] = rb; c64.mem[qc]++;
  if (c64.mem[qc] === NBUF - 1) { c64.mem[sym('curBuf')] = c64.mem[qa]; c64.mem[qa] = c64.mem[qa + 1]; c64.mem[qc] = NBUF - 2; }
  maxRender = Math.max(maxRender, rc); totalRender += rc;
  if (budget) costs.push({ f, tick: cyc, render: rc, prof: profBefore ? Object.fromEntries(Object.entries(profile).map(([k, v]) => [k, v - (profBefore[k] || 0)]).filter(e => e[1] > 0)) : null });
  if (slowProf && cyc + rc > slowProf && profBefore) {     // --slowprof=N: what a frame over N cycles spent its time on
    const d = Object.entries(profile).map(([k, v]) => [k, v - (profBefore[k] || 0)]).filter(e => e[1] > 300).sort((a, b) => b[1] - a[1]);
    console.log(`frame ${f}: ${cyc + rc}: ${d.slice(0, 8).map(([k, v]) => k + ' ' + v).join(', ')}`);
  }
  if (slow && cyc + rc > slow) console.log(`frame ${f}: tick ${cyc} + render ${rc} cycles (vine to ${c64.mem[sym('VineEnd')]}, Harry ${c64.mem[sym('UpLo')] + 106}-${c64.mem[sym('UpHi')] + 105})`);
  if (c64.mem[sym('VineEnd')]) { vineN++; vineSum += cyc + rc; }
  else if (profBefore) { for (const k in profile) delete profile[k]; Object.assign(profile, profBefore); done--; }   // (--vineonly: profile the vine's frames only)
  done++;
  rooms.add(vcs.ram[0x01]);
  const diffs = [];
  for (let a = 0x80; a < 0x100; a++) if (!IGNORE.has(a) && vcs.ram[a - 0x80] !== c64.mem[a])
    diffs.push(`${NAMES[a] || '$' + a.toString(16)} 2600 ${vcs.ram[a - 0x80].toString(16)} C64 ${c64.mem[a].toString(16)}`);
  if (cxRead) cxSeen++;
  if (f > 0 && cxRead !== null && cxRead !== cP0P1 && !(f === power + 1 && power)) diffs.push(`CXPPMM: 2600 ${cxRead} C64 ${cP0P1}`);
  if (diffs.length) {
    bad++;
    if (bad <= 3 || verbose) {
      const h2 = n => vcs.ram[n - 0x80].toString(16);
      console.log(`frame ${f}: ${diffs.join(', ')}  (HarryX ${h2(0xE1)} Y ${h2(0xE9)} scene ${h2(0x94)} object ${h2(0x93)})`);
      if (kernelRam) {                    // Harry's lines: the model's (the 2600's) against the C64's
        const m = require('./model').model(kernelRam);
        const hpat = sym('HPat'), hcol = sym('HCol');
        console.log(`  model hx ${m.hx} ox ${m.ox} ux ${m.ux} k86 ${m.k86.toString(16)}; C64 hx ${c64.mem[sym('hx')]} obj ${c64.mem[sym('ObjXPix')]} tun ${c64.mem[sym('TunXPix')]} lines ${c64.mem[sym('HLo')] + 106}-${c64.mem[sym('HHi')] + 105}`);
        for (let l = 106; l <= 214; l++) {
          let mb = 0; for (let i = 0; i < 8; i++) { const x = m.hx + i; if (x < 160 && (m.ob[l * 160 + x] & 1)) mb |= 0x80 >> i; }
          const cb = c64.mem[hpat + l - 106] & c64.mem[sym('vm')];
          if (mb || cb) console.log(`  line ${l}: model ${mb.toString(2).padStart(8, '0')} C64 ${cb.toString(2).padStart(8, '0')} col ${c64.mem[hcol + l - 106].toString(16)}${mb !== cb ? '  <--' : ''}`);
        }
      }
    }
    if (bad === 3 && !verbose) { console.log('... stopping'); break; }
    for (let a = 0x80; a < 0x100; a++) c64.mem[a] = vcs.ram[a - 0x80];   // resync and carry on
  }
}
if (profile) {
  const tot = Object.values(profile).reduce((a, b) => a + b, 0);
  for (const [k, v] of Object.entries(profile).sort((a, b) => b[1] - a[1]).slice(0, 25)) console.log(k.padEnd(16), String(Math.round(v / done)).padStart(7), (100 * v / tot).toFixed(1) + '%');
  if (pcProfile) for (const [pc, v] of Object.entries(pcProfile).sort((a, b) => a[0] - b[0])) console.log('  $' + (+pc).toString(16), Math.round(v / done));
}
if (budget) {
  // the main loop (c64/main.asm): passes while frames are owed and a buffer is free; behind more
  // than the lead (NBUF - 2), the rest of the owed frames' ticks at once; the frame top shows the
  // next picture waiting, if any
  let t = 0, top = budget, credit = NBUF - 1, q = 0, i = 0, repeats = 0, skipped = 0;
  const blame = {}, frames = [];
  const doTop = pass => { if (q > 0) q--; else { repeats++; if (pass) { frames.push(pass.f); for (const c of pass.cs) for (const [k, v] of Object.entries(c.prof || {})) blame[k] = (blame[k] || 0) + v; } } credit++; top += budget; };
  while (i < costs.length) {
    while (credit <= 0 || q >= NBUF - 1) { t = top; doTop(null); }
    const owed = Math.min(credit, 4), n = Math.max(1, owed - (NBUF - 2));
    credit = owed - n; skipped += n - 1;
    const cs = costs.slice(i, i + n);
    const cost = cs.reduce((a, c) => a + c.tick, 0) + cs[cs.length - 1].render;
    const end = t + cost;
    while (top <= end) doTop({ f: cs[0].f, cs });
    t = end; q++; i += n;
  }
  console.log(`budget ${budget}: ${repeats} frames with no new picture, ${skipped} pictures skipped; during frames ${frames.slice(0, 40).join(' ')}`);
  if (profile) console.log('  their passes: ' + Object.entries(blame).sort((a, b) => b[1] - a[1]).slice(0, 14).map(([k, v]) => k + ' ' + v).join(', '));
}
if (vineN) console.log(`frames with the vine: ${vineN}, tick + render ${Math.round(vineSum / vineN)} cycles on average`);
console.log(`${done} frames, ${rooms.size} rooms, ${bad} with differences (CXPPMM set in ${cxSeen}); C64 tick: ${Math.round(totalCycles / done)} cycles on average, ${maxCycles} at most; render: ${Math.round(totalRender / done)} on average, ${maxRender} at most`);
process.exit(bad ? 1 : 0);
