// Record the C64 build's sound in VICE (its own monitor port; the sound to a .wav, not the
// speakers): start a game, jump a few times (DbgINPT4), and report how loud each stretch is.
//   node games/pitfall/tools/soundtest.js <out.wav> [--ntsc] [--run] [--prg=file]   (--run: Harry runs right meanwhile)
const fs = require('fs');
const net = require('net');
const path = require('path');
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
const files = require('../../../tools/buildname').files(path.join(__dirname, '..', 'build'));
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const prg = opt('prg', files.prg);
const lst = fs.readFileSync(prg.replace(/\.prg$/, '.lst'), 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return m[2] || m[1];
};
const wav = path.resolve(process.argv[2]);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let PORT = 0, vice = null;
const mon = cmds => new Promise((resolve, reject) => {
  const s = net.connect(PORT, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d.toString('latin1'); }); s.on('error', reject);
  s.on('connect', async () => { await sleep(150); for (const c of cmds) { s.write(c + '\n'); await sleep(300); } s.write('x\n'); await sleep(100); s.end(); resolve(b); });
});
(async () => {
  PORT = await freePort();
  vice = startVice(['-default', ...(process.argv.includes('--ntsc') ? ['-ntsc'] : []), '-sounddev', 'wav', '-soundarg', wav,
    '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prg]);
  let ok = false;
  for (let t = 0; t < 30 && !ok; t++) { await sleep(1000); try { ok = await runsOurs(mon, prg); } catch { /* not up yet */ } }
  if (!ok) throw new Error('VICE not running our build');
  await sleep(2000);
  const fire = addr('DbgINPT4');
  await mon([`> ${fire} 7f`]); await sleep(300); await mon([`> ${fire} ff`]);   // start
  await sleep(1500);
  if (process.argv.includes('--run')) await mon([`> ${addr('DbgSWCHA')} 7f`]);   // running right
  for (let i = 0; i < 8; i++) { await mon([`> ${fire} 7f`]); await sleep(300); await mon([`> ${fire} ff`]); await sleep(1500); }
  stopVice(vice);
  await sleep(1500);
  const b = fs.readFileSync(wav);
  const rate = b.readUInt32LE(24), ch = b.readUInt16LE(22);
  let p = 12; while (b.toString('latin1', p, p + 4) !== 'data') p += 8 + b.readUInt32LE(p + 4);
  const d = b.subarray(p + 8);
  const n = Math.floor(d.length / 2 / ch), win = rate / 4, out = [];
  for (let s = 0; s + win <= n; s += win) { let m = 0; for (let i = s; i < s + win; i++) m = Math.max(m, Math.abs(d.readInt16LE(i * 2 * ch))); out.push(m); }
  console.log(`${rate} Hz, ${(n / rate).toFixed(1)} s; peak per quarter second: ${out.join(' ')}`);
})().catch(e => { console.log(e.message); stopVice(vice); });
