﻿; Pitfall! (Atari 2600, Activision 1982) running on the Commodore 64.
;
; The original 2600 program runs almost unchanged at $F000, in the RAM under the C64 KERNAL
; (patches: see GameImage in data.asm). This file and the others supply everything the 2600
; hardware used to do:
;   - display: laid out line for line like the 2600 picture (one 2600 pixel = two C64 pixels,
;     one 2600 line = one C64 line; 2600 line L is raster line L + 10). The playfield (canopy,
;     trees, ground, pits, earth, tunnel, floor), the vine and the ladder (the ball), the branches,
;     the score, the clock and the logo are multicolour characters: "01" = the playfield's colour
;     ($D022), "10" = the second colour ($D023: digits, branches; the earth where it hides Harry),
;     "11" = black (the HMOVE comb at the left edge, which also hides sprites behind it). The
;     colours change at fixed lines (raster interrupts). Harry is up to five sprites (0-4), one
;     per colour band (X-expanded: a sprite pixel is a 2600 pixel). Sprites 5-7 are the vine
;     (the ball: three X-expanded sprites from line 92, 113 and 121, done by line 141), then
;     from line 143 the objects on the ground (logs, crocodiles, fire, cobra, treasure; one
;     multicolour sprite per copy), then from line 174 (5-6) the tunnel's wall or scorpion.
;     Everything is drawn into one of three buffers (screen + character set + sprite blocks)
;     while another is shown and the third may wait its turn (the main loop works a frame ahead,
;     so a slow pass is absorbed by the picture already waiting).
;   - collisions: Harry against the vine, the playfield and the objects, worked out in software
;     from the rules in tools/model.js, which match the 2600 pixel for pixel
;   - input: keyboard and joysticks mapped onto the 2600 joystick and switch ports
;   - sound: the game's TIA sound registers translated to the SID
;
; The game's TIA writes land harmlessly in zero page $02-$2C; it reads the TIA at $37 and $3C
; (patched from $07 and $0C, which its writes share), where we put the collisions and the fire
; button. Its RIOT accesses ($0280-$0297) hit plain C64 RAM, which we fill in each frame.
;
; Build: build.cmd (64tass -C -a -o build/pitfall-V.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM (see 2600/symbols.js)
Lives       = $80
Room        = $81
Joystick    = $83
CollTop     = $85
CollGround  = $86
ColourEor   = $87
ColourAnd   = $88
ColScore    = $89       ; the picture's colours (already masked): the digits and logo,
ColCanopy   = $8B       ; the canopy (COLUPF at the top),
ColSky      = $8C       ; the sky behind the trees (COLUBK),
ColBlack    = $8D       ; the tunnel (COLUBK), the logo's playfield,
ColTrees    = $8E       ; the trees, the branches, the vine,
ColEarth    = $8F       ; the earth, the ladder, the floor,
ColGround   = $90       ; the ground,
ColPit      = $91       ; the pit (COLUBK on the ground lines)
VineLen     = $92
Object      = $93
Scene       = $94
PosFine     = $95       ; Harry, the object, the tunnel object
PosCoarse   = $98
Ladder      = $9D
Frozen      = $9E
HolePF      = $9F
PitPF       = $A0       ; 7
ObjColRows  = $A7       ; 7
ObjRows     = $AE       ; 7
HarryPtr    = $B5
ObjPtr      = $B7
HarryColPtr = $B9
ObjColPtr   = $BB
TunShapeA   = $BD       ; the tunnel object's upper 16 lines: shape, colours
TunColA     = $BF
TunShapeB   = $C1       ; ... lower 16 lines
TunColB     = $C3
DigitPtr    = $C5       ; 6 pointers
ObjNusiz    = $D4
ClockMin    = $D8
ClockSec    = $D9
VineAcc     = $DB
VineSlope   = $DC
VineDir     = $DD
Sound       = $E0
HarryReflect = $E5
TunReflect  = $E6
HarryY      = $E9
Trees       = $EB
Bounce      = $F2
Temp6       = $F6
Temp7       = $F7
Temp8       = $F8

; ------------------------------- 2600 hardware: TIA writes land in zero page
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
CXPPMM      = $37       ; (read at $F73A, patched from $07) bit 7 P0-P1: Harry touched an object
INPT4       = $3C       ; (read at $F817, patched from $0C) bit 7 clear: fire
; RIOT
SWCHA       = $0280     ; joystick (high nibble: player 0)
SWCHB       = $0282     ; console switches
INTIM       = $0284     ; timer (kept at 0 so the game never waits)

; ------------------------------------------------ 2600 program addresses
PowerOn     = $F000
FrameEnd    = $F591     ; where the game continues after drawing a picture
KernelStart = $F0CE     ; patched: the game hands over here instead of drawing

; ------------------------------------------------------------ C64 layout
VICBANK     = $4000     ; the VIC sees $4000-$7FFF (no character ROM there)
NBUF        = 3         ; buffers: one shown, one waiting, one being drawn
CHARS       = $4000     ; three character sets ($4000, $4800, $5000), one per buffer
SCREEN      = $5800     ; three screens ($5800, $5C00, $6000)
SPRDATA     = $6400     ; sprite blocks
BLK_BLANK   = (SPRDATA - VICBANK) / 64
BLK_SET     = BLK_BLANK + 1     ; per buffer NBLK blocks: Harry 0-4, the objects 5-7, the tunnel 8-9,
NBLK        = 13                ; the vine 10-12
        .cerror SPRDATA + 64 * (1 + NBUF * NBLK) > $8000, "sprite blocks overflow"

LINEOFS     = 10        ; 2600 line L is raster line L + LINEOFS (line 41: raster 51, the first
SPRYOFS     = 9         ; text row), and sprite Y register value L + SPRYOFS
TOPRASTER   = 30        ; frame start: above the picture
WORKRAM     = $c000     ; our working variables (data.asm)
HIGHCODE    = $8000     ; the renderer (render.asm), copied there by Start
DigMid      = $c800     ; tables built at start-up: the digits' cell bytes (InitDigitTabs)
DigShA      = $c900
DigShB      = $ca00
HSDSTLO     = $cb00     ; where each of Harry's lines is drawn, by set (110 each: HarrySame)
HSDSTHI     = $cc80
DbgRoomLog  = $cf00     ; testing aid: the self-playing game's rooms and when it came to them
DbgRepLog   = $ce00     ; testing aid: the tick each of the first 128 frames with no new picture came at
CANCACHE    = $e000     ; the canopy's characters for each tree pattern (InitCanopy: 4 x 608)

; character codes (both sets the same): fixed patterns, then unique cells by region
C_BG        = 0         ; background
C_PF        = 1         ; playfield ("01")
C_COMB      = 2         ; black ("11": colour RAM black)
C_PFFG      = 3         ; playfield in front of sprites ("10")
C_ROW13     = 4         ; trees' gaps above the ground: 7 lines of sky, the ground's first line
C_ROW21     = 5         ; the tunnel's last 6 lines, the floor's first 2
C_ROW17     = 6         ; earth 6 lines, tunnel 2 ("01")
C_ROW17FG   = 7         ; ... ("10": the earth hides Harry where there is no ladder)
C_ROW15     = 149       ; the ground's lines, its last (168) "10": the earth's colour (EvEarth)
C_SCORE     = 8         ; rows 0-2, columns 5-17: 39
C_LOGO      = 47        ; rows 22-23, columns 5-17: 26
C_CANOPY    = 73        ; rows 6-7, columns 2-39: 76
C_GROUND    = 160       ; rows 14-17, columns 12-27: 64 (128-byte aligned: GLine)
C_LADDER    = 224       ; rows 18-21, columns 19-20: 8

; sprites: 0-4 Harry (hires, X-expanded, one colour each); 5-7 the vine (hires, X-expanded, in
; front of the characters), from line 143 the objects (multicolour), from 174 (5-6) the tunnel's
NHARRY      = 5
VINEA       = 92        ; the vine's sprites: their first lines (C's rows above 134 stay blank)
VINEB       = 113
VINEC       = 121
VINELAST    = 141       ; (VINEC + 20: then free for the objects on line 153, 22 lines on)

; ------------------------------------------------------- zero page ($40+)
; $02-$2C take the game's TIA writes, $2E its VSYNC / VBLANK writes (patched), $37 and $3C are
; its TIA reads, so ours start at $40.
        .virtual $40
ptrA        .word ?
ptrB        .word ?
ptrC        .word ?
ptrD        .word ?
tmp         .byte ?
tmp2        .byte ?
tmp3        .byte ?
v0          .byte ?
v1          .byte ?
v2          .byte ?
v3          .byte ?
v4          .byte ?
v5          .byte ?
frameFlag   .byte ?     ; frames counted by the raster interrupt, the main loop's yet to do
FOwed       .byte ?     ; main loop: the frames owed, those this pass does
FNow        .byte ?
frames      .byte ?
isPal       .byte ?
tickAcc     .byte ?
firstTick   .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)
switches    .byte ?     ; SWCHB toggles
curBuf      .byte ?     ; raster interrupt: the buffer shown (0-2)
QCount      .byte ?     ; buffers drawn, waiting to be shown (0-2), in Queue
evIdx       .byte ?     ; the raster interrupt's next event
rbuf        .byte ?     ; render: the buffer being drawn (0-2)
scr         .word ?     ; ... its screen
chs         .word ?     ; ... its character set
hx          .byte ?     ; collide: Harry's pixel X
hy          .byte ?     ; ... the kernel's Y counter
vm          .byte ?     ; ... Harry's pixels that show (not in the HMOVE blank)
g0n         .byte ?     ; ... the row written last (as shown: reflected)
shown       .byte ?     ; ... the row shown
colA        .byte ?     ; ... the colour for the next line
acc         .byte ?     ; vine accumulator
line        .byte ?     ; a 2600 line
cx          .byte ?     ; collision flags being gathered
pfw         .byte ?     ; a playfield window
code        .byte ?     ; render: a character code
cell        .byte ?     ; ... a cell
lrow        .byte ?     ; ... a line within its row
vacc        .byte ?     ; the vine's sprites: accumulator, x + 8
vx8         .byte ?
        .cerror * > $80, "zero page overflow"
        .endv

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title, credits and controls.
; (Lower case here: 64tass -a turns it into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " pitfall!"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600, activision 1982"
Bas30   .word Bas40, 30
        .null $8f, " programmed by david crane"
Bas40   .word Bas50, 40
        .null $8f, " version 1.0"
Bas50   .word Bas60, 50
        .null $8f, " ported by claude and doughboy68"
Bas60   .word Bas70, 60
        .null $8f, " joy port 2/1 or wasd, space-jump"
Bas70   .word Bas80, 70
        .null $8f, " f1 or fire-start f2-power off/on"
Bas80   .word BasEnd, 80
        .null $8f, " f5-colour/b&w"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #$ff
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01

        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -
        ldx #0                  ; and our working variables
-       .for i := 0, i < 8, i += 1
        sta WORKRAM + i * $100,x
        .endfor
        inx
        bne -

        ; copy the patched 2600 program to $F000-$FFFF
        lda #<GameImage
        sta ptrA
        lda #>GameImage
        sta ptrA+1
        lda #0
        sta ptrB
        lda #$f0
        sta ptrB+1
        ldx #16
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        lda #<HighImage         ; the renderer to HIGHCODE
        sta ptrA
        lda #>HighImage
        sta ptrA+1
        lda #<HIGHCODE
        sta ptrB
        lda #>HIGHCODE
        sta ptrB+1
        ldx #(HighEnd - HIGHCODE + 255) >> 8
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        lda #<Nmi               ; our vectors replace the 2600's
        sta $fffa
        lda #>Nmi
        sta $fffb
        lda #<Irq
        sta $fffe
        lda #>Irq
        sta $ffff

        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #0
        sta INTIM
        lda #$80
        sta INPT4
        lda #1
        sta firstTick

        jsr InitVideo
        jsr InitSound
        jsr DetectPal

        lda #0                  ; start the raster interrupt at the frame top
        sta curBuf
        sta QCount
        sta evIdx
        lda #NBUF - 1           ; (the main loop runs ahead: one picture waiting)
        sta frameFlag
        lda #TOPRASTER
        sta $d012
        lda #$1b                ; text mode, 25 rows, YSCROLL 3, raster bit 8 clear
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

; ================================================================ main loop
; Each pass: the game's ticks for a frame (PAL: 6 every 5 frames), then the picture drawn into a
; buffer neither shown nor waiting, queued for the frame top. The passes run ahead of the display
; (frameFlag, the frames they may do, starts at NBUF - 1), so one picture waits at each frame top
; and a slow pass (a room change, many redraws at once) is absorbed by it. Behind (more frames
; owed than that lead), a pass does the ticks of the rest at once, skipping pictures to keep the
; game's speed (at most 4 frames owed: further behind, the game slows).
MainLoop:
-       lda frameFlag           ; frames to do (the raster interrupt adds one each frame)
        bne +
        inc DbgIdle             ; (testing aid: the time waiting, 15 cycles a count)
        bne -
        inc DbgIdle+1
        bne -
        inc DbgIdle+2
        jmp -
+       sei
        lda frameFlag
        cmp #5
        bcc +
        lda #4
+       sta FOwed
        sec                     ; this pass: all owed but the lead (NBUF - 2), at least one
        sbc #NBUF - 2
        beq +
        bcs ++
+       lda #1
+       sta FNow
        eor #$ff
        sec
        adc FOwed
        sta frameFlag
        cli
        ldx FNow
        inc DbgLoops            ; (testing aid: passes, and passes that skipped pictures)
        bne +
        inc DbgLoops+1
+       cpx #2
        bcc +
        inc DbgLate
        bne +
        inc DbgLate+1
+       lda DbgBorder           ; testing aid: the border shows where the time goes
        beq +
        lda #5
        sta $d020
+       jsr ReadInput
        lda PowerReq            ; F2: the power switch
        beq _frame
        jsr PowerCycle
_frame  lda isPal               ; PAL: 6 game ticks every 5 frames keeps 2600 speed
        beq _ntsc
        lda tickAcc
        clc
        adc #6
        sta tickAcc
-       lda tickAcc
        cmp #5
        bcc _next
        sbc #5
        sta tickAcc
        jsr Tick
        jmp -
_ntsc   jsr Tick
_next   dec FNow
        bne _frame
_draw   lda DbgBorder
        beq +
        lda #0
        sta $d020
+
-       lda QCount              ; a buffer free (one shown, at most one waiting)
        cmp #NBUF - 1
        bcc +
        inc DbgIdleQ            ; (testing aid: the time waiting, 17 cycles a count)
        bne -
        inc DbgIdleQ+1
        bne -
        inc DbgIdleQ+2
        jmp -
+
        lda DbgBorder
        beq +
        lda #2
        sta $d020
+       jsr Render              ; draw the state the ticks produced
        sei                     ; ... queued for the frame top
        ldx QCount
        lda rbuf
        sta Queue,x
        inc QCount
        cli
        jsr UpdateSound
        lda DbgBorder
        beq +
        lda #0
        sta $d020
+       jmp MainLoop

; One 2600 frame of game logic: the original code from the end of the picture to the start
; of the next one, where it jumps to KernelHook.
Tick:
        lda DbgAuto             ; (testing aid: the inputs by the tick count)
        beq +
        jsr AutoInput
+       lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp PowerOn             ; the very first frame starts at power-on
+       jmp FrameEnd

KernelHook:                     ; the game would draw the picture now
        jsr Collide             ; what the TIA would have seen, and the RAM the kernel leaves
        rts                     ; (returns to whoever called Tick)

; F2: the power switch off and on. The TIA is cleared and the next tick starts at the 2600's
; power-on code, which clears its RAM; the console switches, the joystick and the fire button
; stay as they are, as on a real 2600. The display catches up by itself.
PowerCycle:
        lda INPT4
        pha
        lda #0
        sta PowerReq
        ldx #2                  ; the TIA's registers ($02-$2E) and our copies of its reads
-       sta $00,x
        inx
        cpx #$3e
        bne -
        sta INTIM
        pla
        sta INPT4
        lda #1
        sta firstTick
        lda DbgAuto             ; (testing aid: the self-playing game from its start, whenever
        beq +                   ; the power cycle came: the same game every time)
        lda #0
        sta AutoT
        sta AutoT+1
        sta AutoHold
        sta AutoHop
        sta AutoUnder
        sta AutoRoomN
        lda #1
        sta AutoR
        lda #$ff
        sta AutoDir
+       rts

; Replaces the 2600's "sta $00,x / txs / inx / bne" clearing loop (power-on, X = 0, and Game
; Reset, X = $D1; A = 0): clear the 2600 RAM from X up, but not the C64's zero page below $80.
ClearZP:
        cpx #$80
        bcs +
        ldx #$80
+
-       sta $00,x
        inx
        bne -
        rts

; =========================================================== interrupts
; A fixed schedule of events down the screen (EvTrig: the raster line each is armed at). The
; colour changes at the playfield's boundaries happen exactly at a line's start: the interrupt
; comes 3 lines ahead, loads the value, waits for the line or a later one (never an exact match:
; on a badline with sprites the CPU may get no cycle to see it), then stores (in the left border
; or, a few cycles late, over the black comb at the left edge, where no colour register shows).
Irq:
        pha
        txa
        pha
        tya
        pha
        cld                     ; the game uses decimal mode now and then
        lda $d019
        sta $d019
_run    ldx evIdx
        lda EvLo,x
        sta _j+1
        lda EvHi,x
        sta _j+2
        ldy curBuf
_j      jmp $0000

; every event ends here: arm the next (one whose line has passed is run at once)
IrqNext:
        inc evIdx
        ldx evIdx
        cpx #NEVENT
        bcc +
        ldx #0                  ; (after the frame end: the next frame's top)
        stx evIdx
        lda #TOPRASTER
        sta $d012
        jmp _out
+       lda EvTrig,x
        sta $d012
        cmp $d012               ; the line already reached or passed: now
        beq +
        bcs _out
+       lda #$ff
        sta $d019
        jmp Irq._run
_out    pla
        tay
        pla
        tax
        pla
        rti

Nmi:    rti

; Testing aid (tools/c64late.js): with DbgAuto set the C64 plays by itself, the inputs by the
; tick count (the same game on PAL and NTSC, whatever the timing): runs left and right, jumps, now
; and then Harry at the right edge running out (to the next room), lives kept, back up from the
; tunnel after a while. From tick AUTOFROM to AUTOTO the counters run; then they are kept in
; DbgAutoRes and DbgAuto becomes $80 (the inputs left alone).
AUTOFROM    = 300
AUTOTO      = AUTOFROM + 3600
AutoInput:
        lda DbgAuto
        bpl +
        rts
+       inc AutoT
        bne +
        inc AutoT+1
+       lda AutoT
        cmp #<AUTOFROM
        bne +
        lda AutoT+1
        cmp #>AUTOFROM
        bne +
        ldx #DbgAutoN - 1       ; AUTOFROM: the counters from 0
        lda #0
-       sta DbgLoops,x
        dex
        bpl -
+       lda AutoT
        cmp #<AUTOTO
        bne +
        lda AutoT+1
        cmp #>AUTOTO
        bne +
        ldx #DbgAutoN - 1       ; AUTOTO: the counters kept, the inputs left alone
-       lda DbgLoops,x
        sta DbgAutoRes,x
        dex
        bpl -
        lda #$80
        sta DbgAuto
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        rts
+       lda firstTick           ; (the power-on tick: the 2600's RAM not set up yet)
        beq +
        jmp _in
+
        lda Room                ; (the rooms it comes to, and when: DbgRoomLog)
        cmp AutoRoom
        beq +
        sta AutoRoom
        ldx AutoRoomN
        cpx #252
        bcs +
        sta DbgRoomLog+2,x
        lda AutoT
        sta DbgRoomLog,x
        lda AutoT+1
        sta DbgRoomLog+1,x
        inx
        inx
        inx
        stx AutoRoomN
+       lda AutoR               ; a random number (an 8-bit shift register)
        asl
        bcc +
        eor #$1d
+       sta AutoR
        lda Lives               ; (lives kept)
        cmp #$a0
        beq +
        lda Frozen
        bne +
        lda #$a0
        sta Lives
+       dec AutoHold            ; a new direction now and then: right, left, none, down, up
        bpl +
        lda AutoR
        and #63
        clc                     ; (the same whatever the RAM held before the power cycle)
        adc #20
        sta AutoHold
        lda AutoR
        and #7
        tax
        lda AutoDirs,x
        sta AutoDir
+       lda HarryY              ; long in the tunnel: back up
        cmp #$40
        bcc +
        inc AutoUnder
        lda AutoUnder
        cmp #200
        bcc ++
        lda #$20
        sta HarryY
+       lda #0
        sta AutoUnder
+       inc AutoHop             ; every 240 ticks, on the ground: to the right edge, running out
        lda AutoHop
        cmp #240
        bcc _in
        lda Frozen
        bne _in
        lda HarryY
        cmp #$20
        bne _in
        lda $ea                 ; (not on the vine)
        bne _in
        lda #0
        sta AutoHop
        lda #$92
        sta $e1
        lda #$7f
        sta AutoDir
        lda #40
        sta AutoHold
_in     lda AutoDir
        sta SWCHA
        lda #$80                ; a jump now and then
        ldx AutoR
        cpx #8
        bcs +
        lda #0
+       sta INPT4
        rts
AutoDirs:   .byte $7f, $bf, $7f, $bf, $ff, $df, $ef, $7f

NEVENT      = 9
EVDELAY     = 9         ; colour events: the wait from the line before's start to its end (5 cycles each)
EvTrig:     .byte TOPRASTER, 66 + LINEOFS, 100 + LINEOFS - 3, 143 + LINEOFS, 152 + LINEOFS - 3
            .byte 168 + LINEOFS - 3, 174 + LINEOFS, 221 + LINEOFS - 3, 233 + LINEOFS
EvLo:       .byte <EvTop, <EvBranch, <EvTrees, <EvObjects, <EvGround, <EvEarth, <EvTunnel, <EvFloor, <EvEnd
EvHi:       .byte >EvTop, >EvBranch, >EvTrees, >EvObjects, >EvGround, >EvEarth, >EvTunnel, >EvFloor, >EvEnd

; Frame top: switch to a newly finished buffer; its screen, characters, sprites and colours
EvTop:
        inc DbgTops             ; (testing aid)
        bne +
        inc DbgTops+1
+       lda QCount              ; the next picture waiting, if any (else the same again)
        beq _rep
        lda Queue
        sta curBuf
        lda Queue+1
        sta Queue
        dec QCount
        jmp _shown
_rep    ldx DbgRepeat           ; (testing aid: counted, and the tick each came at)
        cpx #128
        bcs +
        lda DbgRepeat+1
        bne +
        txa
        asl
        tax
        lda AutoT
        sta DbgRepLog,x
        lda AutoT+1
        sta DbgRepLog+1,x
+       inc DbgRepeat
        bne _shown
        inc DbgRepeat+1
_shown  ldy curBuf
        lda D018Val,y
        sta $d018
        lda StBg,y              ; (every frame: the ground and the earth change it lower down;
        sta $d021               ; here the beam is in the border: no grey dot)
        lda StPf,y
        sta $d022
        lda StDig,y
        sta $d023
        lda StMc1,y
        sta $d025
        lda StMc2,y
        sta $d026
        lda StMsb,y
        sta $d010
        lda StEn,y
        sta $d015
        lda #0                  ; sprites: none multicolour (the vine's 5-7 hires), all X-expanded,
        sta $d01c               ; Harry's behind the foreground, the vine's in front
        lda #$ff
        sta $d01d
        lda #$1f
        sta $d01b
        tya                     ; 8 * buffer: staged sprite values
        asl
        asl
        asl
        tay
        ldx #0
-       lda StCol,y
        sta $d027,x
        iny
        inx
        cpx #8
        bne -
        tya
        sec
        sbc #8
        tay
        ldx #0
-       lda StX,y
        sta $d000,x
        lda StY,y
        sta $d001,x
        iny
        inx
        inx
        cpx #16
        bne -
        ldy curBuf              ; the vine's blocks (the objects' and the tunnel's events change them)
        ldx ScrHi,y
        stx _p+2
        stx _p2+2
        stx _p3+2
        lda VnPtr,y
_p      sta SCREEN + $3fd
        lda VnPtr+NBUF,y
_p2     sta SCREEN + $3fe
        lda VnPtr+2*NBUF,y
_p3     sta SCREEN + $3ff
        jmp IrqNext

; Line 66 (between the clock and the branches): the second colour becomes the branches'
EvBranch:
        lda StBranch,y
        sta $d023
        jmp IrqNext

; Line 100: the playfield's colour becomes the trees' (and the vine's first sprite's). The colour
; events write at the end of the line before, in the border (the C64C's VIC shows a grey dot
; where a colour register is written while its colour shows under the beam), the values in A
; and X (the stores back to back), the one that may show earliest first.
EvTrees:
        ldx StTrees,y
        ldy #100 - 1 + LINEOFS  ; the line before: its end (the right border)
        cpy $d012               ; (already past it: late, testing aid)
        bcs +
        inc DbgEvLate
+
-       cpy $d012
        beq +
        bcs -
+       cpy $d012               ; (on it: to its end; past it already: now)
        bne +
        ldy #EVDELAY
-       dey
        bne -
+
        stx $d022
        stx $d02c
        jmp IrqNext

; Line 143 (the vine's sprites have finished: the last started on line 121): sprites 5-7 to the
; objects on the ground (from line 153): multicolour, not expanded, behind the foreground
EvObjects:
        lda #$e0
        sta $d01c
        lda #$1f
        sta $d01d
        lda #$ff
        sta $d01b
        lda ObCol,y
        sta $d02c
        sta $d02d
        sta $d02e
        lda ObX,y
        sta $d00a
        lda ObX+NBUF,y
        sta $d00c
        lda ObX+2*NBUF,y
        sta $d00e
        lda #153 + SPRYOFS
        sta $d00b
        sta $d00d
        sta $d00f
        lda $d010
        and #$1f
        ora ObMsb,y
        sta $d010
        lda $d015
        and #$1f
        ora ObEn,y
        sta $d015
        ldx ScrHi,y
        stx _o+2
        stx _o2+2
        stx _o3+2
        lda ObPtr,y
_o      sta SCREEN + $3fd
        lda ObPtr+NBUF,y
_o2     sta SCREEN + $3fe
        lda ObPtr+2*NBUF,y
_o3     sta SCREEN + $3ff
        jmp IrqNext

; Line 152: the ground's colour; the pits' background (not shown on this line: all playfield)
EvGround:
        lda StPit,y
        ldx StGround,y
        ldy #152 - 1 + LINEOFS  ; the line before: its end (the right border)
        cpy $d012               ; (already past it: late, testing aid)
        bcs +
        inc DbgEvLate
+
-       cpy $d012
        beq +
        bcs -
+       cpy $d012               ; (on it: to its end; past it already: now)
        bne +
        ldy #EVDELAY
-       dey
        bne -
+
        stx $d022
        sta $d021
        jmp IrqNext

; Line 168: the earth's colour (both playfield classes); the tunnel's background (shown in the
; ladder's hole from pixel 76). Line 168 is drawn in the second class ("10"), none of which shows
; on 167: $D023 becomes the earth's colour on line 167; then early in 168, $D021 (before pixel
; 76) and $D022 (not shown on 168, the earth's from 169).
EvEarth:
        ldx StEarth,y
        lda StTunBg,y
        ldy #168 - 1 + LINEOFS  ; line 167
        cpy $d012               ; (already past it: late, testing aid)
        bcs +
        inc DbgEvLate
+
-       cpy $d012
        beq +
        bcs -
+       stx $d023
        ldy #168 + LINEOFS      ; line 168
-       cpy $d012
        beq +
        bcs -
+       sta $d021
        stx $d022
        jmp IrqNext

; Line 174 (the objects' sprites have finished: they started on line 153): sprites 5 and 6 to
; the tunnel object (the wall's upper and lower parts, or the scorpion)
EvTunnel:
        lda TnMc1,y
        sta $d025
        lda TnMc2,y
        sta $d026
        lda TnCol,y
        sta $d02c
        sta $d02d
        lda TnX,y
        sta $d00a
        lda TnX+NBUF,y
        sta $d00c
        lda TnY,y
        sta $d00b
        lda TnY+NBUF,y
        sta $d00d
        lda $d010
        and #$9f
        ora TnMsb,y
        sta $d010
        lda $d015
        and #$9f
        ora TnEn,y
        sta $d015
        ldx ScrHi,y
        stx _t+2
        stx _t2+2
        lda TnPtr,y
_t      sta SCREEN + $3fd
        lda TnPtr+NBUF,y
_t2     sta SCREEN + $3fe
        jmp IrqNext

; Line 221: the floor's playfield turns black, the second colour becomes the logo's: that one at
; once (no "10" shows on lines 218-223), the first at line 221's start (a store just after it,
; in the left border: a short wait, the value in X)
EvFloor:
        lda StDig,y
        sta $d023
        ldx StBlack,y
        ldy #221 - 1 + LINEOFS  ; (already past line 220: late, testing aid)
        cpy $d012
        bcs +
        inc DbgEvLate
+
-       cpy $d012           ; (to line 221)
        bcs -
        stx $d022
        jmp IrqNext

; After the picture: the main loop may draw the next frame
EvEnd:
        inc frameFlag
        jmp IrqNext

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        txa                     ; the SID's pitch depends on the machine's clock
        bne +
        lda #<SidFreqLoN
        sta FreqTab
        lda #>SidFreqLoN
        sta FreqTab+1
+       rts

InitVideo:
        lda $dd02               ; VIC bank 1 ($4000)
        ora #3
        sta $dd02
        lda $dd00
        and #$fc
        ora #2
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d017
        lda #$ff                ; all sprites behind the foreground ("10" and "11")
        sta $d01b
        lda #$e0                ; 5-7 multicolour (the objects), 0-4 X-expanded (Harry)
        sta $d01c
        lda #$1f
        sta $d01d
        lda #$18                ; multicolour characters
        sta $d016
        lda D018Val
        sta $d018
        ldx #0                  ; colour RAM: multicolour, "11" black
        lda #8
-       sta $d800,x
        sta $d900,x
        sta $da00,x
        sta $dae8,x
        inx
        bne -
        lda #<SPRDATA           ; the sprite blocks cleared
        sta ptrB
        lda #>SPRDATA
        sta ptrB+1
        ldx #(64 * (1 + NBUF * NBLK) + 255) / 256
        ldy #0
        tya
-       sta (ptrB),y
        iny
        bne -
        inc ptrB+1
        dex
        bne -
        lda #BLK_BLANK
        ldx #7
-       sta SCREEN + $3f8,x
        sta SCREEN + $7f8,x
        sta SCREEN + $bf8,x
        dex
        bpl -
        jsr InitDigitTabs
        jsr InitCanopy
        jsr InitLadder
        ldx #NBUF - 1           ; every buffer: everything to be drawn
-       stx rbuf
        jsr InitBuffer
        dex
        bpl -
        rts

InitSound:
        ldx #$18
        lda #0
-       sta $d400,x
        dex
        bpl -
        lda #$0f                ; full volume
        sta $d418
        ldx #5
        lda #$ff
-       sta SndLast,x
        dex
        bpl -
        rts

        .include "input.asm"
        .include "collide.asm"
        .include "data.asm"

; The renderer runs at HIGHCODE ($8000-$BFFF, free RAM): in the file after the 2600 image, copied
; there by Start
HighImage:
        .logical HIGHCODE
        .include "render.asm"
HighEnd:
        .here
        .cerror HighEnd > $c000, "the renderer runs past $BFFF"
        .cerror * > $c000, "the program runs into the working variables"
