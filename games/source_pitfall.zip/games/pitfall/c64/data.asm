﻿; =================================================================== sound
; The game's TIA sound registers, translated to SID voices 1 and 2 once a frame (Stargate's
; mapping: the TIA circuit's periods and duties; the envelope restarted only when the volume
; rises; very quiet starts left silent).
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        bne _on
        jmp _off
_on     cmp #3
        bcs +
        lda SndOn,x
        beq _off
+       ldy v1
        lda SidWave,y
        beq _off2
        sta tmp                 ; waveform
        lda v1                  ; frequency index = AUDC * 32 + AUDF
        lsr
        lsr
        lsr
        sta ptrA+1
        lda v1
        asl
        asl
        asl
        asl
        asl
        ora v2
        clc
        adc FreqTab
        sta ptrA
        lda ptrA+1
        adc FreqTab+1
        sta ptrA+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d400,y
        inc ptrA+1
        inc ptrA+1
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d401,y
        ldy v1                  ; the pulse width (the TIA waveform's duty)
        lda SidPWHi,y
        pha
        lda SidPWLo,y
        ldy tmp2
        sta $d402,y
        pla
        sta $d403,y
        lda v0                  ; volume becomes the sustain level
        asl
        asl
        asl
        asl
        sta $d406,y
        lda SndLast,x           ; the envelope restarted only when the volume rises
        cmp v0
        bcs +
        lda tmp
        sta $d404,y
+       lda tmp
        ora #1
        sta $d404,y
        lda #1
        sta SndOn,x
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
        sta SndOn,x
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts

; ================================================================== tables
Bit:        .byte $01, $02, $04, $08, $10, $20, $40, $80
SidVoice:   .byte 0, 7
Mul15:      .byte 0, 15, 30, 45, 60, 75, 90, 105, 120, 135, 150, 165
Mul3:       .byte range(0, 63, 3)
Mul5:       .byte 0, 5, 10
MulNB:      .byte 0, NBLK, 2 * NBLK
MulNBUF:    .byte 0, NBUF, 2 * NBUF
Mul7:       .byte range(0, 7 * 3 * NBUF, 7)    ; (DigKeys: 7 * (NBUF * row + buffer))
CanLo:      .byte <(CANCACHE + range(4) * 608)
CanHi:      .byte >(CANCACHE + range(4) * 608)
DigCode:    .byte C_SCORE, C_SCORE + 26, C_LOGO        ; the digit rows' first character rows' cell 0
DigOff0:    .byte 106, 105, 104, 7, 6, 5, 4, 3    ; ... each line's offset from it, bottom first
DigOff1:    .byte 7, 6, 5, 4, 3, 2, 1, 0    ; (lines 44-51, 57-64, 224-231: from lines 3, 0, 7 of
DigOff2:    .byte 110, 109, 108, 107, 106, 105, 104, 7    ; a character row; past it 13 cells on)
DigOffLo:   .byte <DigOff0, <DigOff1, <DigOff2
DigOffHi:   .byte >DigOff0, >DigOff1, >DigOff2
DigZero:    .fill 8, 0          ; (no digit)
RowOf8:     .byte range(0, 240, 40)     ; rows 8-13 from row 8's start
Mul64:      .byte 0, 64, 128
VnFrom:     .byte 0, VINEB - VINEA, VINELAST - 7 - VINEA  ; the vine's sprites: lines (from 92)
VnTo:       .byte VINEB - VINEA, VINEB - VINEA + 21, VINELAST + 1 - VINEA
VnRow0L:    .byte VINEA, VINEB, VINEC                        ; ... the line of row 0
VnStartOfs: .byte 0, 0, (VINELAST - 7 - VINEC) * 3               ; ... the offset of its first row drawn
VnQuant:    .byte $fc, $fc, $f0
VnLean:     .byte 20, 20, 7
PosB0:      .byte $80, $40, $20, $10, $08, $04, $02, $01, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
PosB1:      .byte 0, 0, 0, 0, 0, 0, 0, 0, $80, $40, $20, $10, $08, $04, $02, $01, 0, 0, 0, 0, 0, 0, 0, 0
PosB2:      .byte 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, $80, $40, $20, $10, $08, $04, $02, $01
Bit7And7:   .byte $80, $40, $20, $10, $08, $04, $02, $01, $80, $40, $20, $10, $08, $04, $02, $01
            .byte $80, $40, $20, $10, $08, $04, $02, $01
VnY:        .byte VINEA + SPRYOFS, VINEB + SPRYOFS, VINEC + SPRYOFS
AddHM:      .byte 8, 7, 6, 5, 4, 3, 2, 1, 16, 15, 14, 13, 12, 11, 10, 9 ; 8 - an HM nibble's move left
CopyN:      .byte 1, 2, 2, 3, 2, 1, 3, 1        ; player copies per NUSIZ
CopyOff:    .byte 0, 0, 0, 0, 16, 0, 0, 32, 0, 0, 16, 32, 0, 64, 0, 0, 0, 0, 0, 32, 64, 0, 0, 0
McPixN:     .byte $3f, $cf, $f3, $fc            ; multicolour pixel n cleared
McPix10:    .byte $80, $20, $08, $02            ; ... as "10"
SlotMask:   .byte $aa, $55, $ff                 ; sprite colour slots: own, $D025, $D026
D018Val:    .byte ((SCREEN + range(NBUF) * $400 - VICBANK) / $400) << 4 | ((CHARS + range(NBUF) * $800 - VICBANK) / $800) << 1
ScrHi:      .byte >(SCREEN + range(NBUF) * $400 + $3f8)
ScrBaseHi:  .byte >(SCREEN + range(NBUF) * $400)
ChsBaseHi:  .byte >(CHARS + range(NBUF) * $800)
BlkLo:      .byte <(SPRDATA + range(1 + NBUF * NBLK) * 64)
BlkHi:      .byte >(SPRDATA + range(1 + NBUF * NBLK) * 64)
HKBLo:      .byte <HKeyB0, <HKeyB1, <HKeyB2
HKBHi:      .byte >HKeyB0, >HKeyB1, >HKeyB2
HSPatLo:    .byte <HSPat0, <HSPat1, <HSPat2
HSPatHi:    .byte >HSPat0, >HSPat1, >HSPat2
HSColLo:    .byte <HSCol0, <HSCol1, <HSCol2
HSColHi:    .byte >HSCol0, >HSCol1, >HSCol2
HSDLo:      .byte <(HSDSTLO + range(NBUF) * 110), >(HSDSTLO + range(NBUF) * 110)   ; where each set's lines are drawn
HSDHi:      .byte <(HSDSTHI + range(NBUF) * 110), >(HSDSTHI + range(NBUF) * 110)
RowLo:      .byte <(range(25) * 40)
RowHi:      .byte >(range(25) * 40)
FixedChars: .fill 8, $00                        ; C_BG
            .fill 8, $55                        ; C_PF
            .fill 8, $ff                        ; C_COMB
            .fill 8, $aa                        ; C_PFFG
            .byte 0, 0, 0, 0, 0, 0, 0, $55      ; C_ROW13
            .byte 0, 0, 0, 0, 0, 0, $55, $55    ; C_ROW21
            .byte $55, $55, $55, $55, $55, $55, 0, 0 ; C_ROW17
            .byte $aa, $aa, $aa, $aa, $aa, $aa, 0, 0 ; C_ROW17FG
Row15Char:  .byte $55, $55, $55, $55, $55, $55, $55, $aa ; C_ROW15
U_DIGITS    = 1
U_CANOPY    = 2
U_GROUND    = 3
U_LADDER    = 4
RowFill:    .byte C_PF, C_PF, C_PF, C_PF, C_PF, C_PF, C_PF, C_PF            ; rows 0-7
            .byte C_BG, C_BG, C_BG, C_BG, C_BG, C_ROW13                     ; 8-13
            .byte C_PF, C_ROW15, C_PF, C_ROW17, C_BG, C_BG, C_BG, C_ROW21   ; 14-21
            .byte C_PF, C_PF, C_COMB                                        ; 22-24
RowUniq:    .byte U_DIGITS, U_DIGITS, U_DIGITS, 0, 0, 0, U_CANOPY, U_CANOPY
            .byte 0, 0, 0, 0, 0, 0
            .byte U_GROUND, U_GROUND, U_GROUND, U_GROUND, U_LADDER, U_LADDER, U_LADDER, U_LADDER
            .byte U_DIGITS, U_DIGITS, 0
RowBase:    .byte C_SCORE - 5, C_SCORE - 5 + 13, C_SCORE - 5 + 26, 0, 0, 0
            .byte C_CANOPY - 2, C_CANOPY - 2 + 38, 0, 0, 0, 0, 0, 0
            .byte C_GROUND - 12, C_GROUND - 12 + 16, C_GROUND - 12 + 32, C_GROUND - 12 + 48
            .byte C_LADDER - 19, C_LADDER - 19 + 2, C_LADDER - 19 + 4, C_LADDER - 19 + 6
            .byte C_LOGO - 5, C_LOGO - 5 + 13, 0
        .include "tables.inc"

; ------------------------------------------------------- variables (RAM)
DbgSWCHA:   .byte $ff           ; AND masks applied to the inputs (testing aid)
DbgINPT4:   .byte $ff
DbgSWCHB:   .byte $ff
DbgBorder:  .byte 0             ; non-zero: colour the border while drawing / running the game
DbgLoops:   .word 0             ; main loop passes
DbgLate:    .word 0             ; ... that skipped pictures (more than one frame owed)
DbgTops:    .word 0             ; frame tops the interrupt has done
DbgEvLate:  .word 0             ; colour changes whose interrupt came after their line
DbgRepeat:  .word 0             ; frame tops with no new picture waiting (the last shown again)
DbgIdle:    .fill 3             ; the main loop waiting for a frame (15 cycles a count)
DbgIdleQ:   .fill 3             ; ... for a buffer (17 cycles a count)
DbgAutoN    = DbgIdleQ + 3 - DbgLoops
DbgAuto:    .byte 0             ; testing aid: non-zero: the C64 plays by itself (AutoInput)
DbgAutoRes: .fill DbgAutoN      ; ... the counters over its ticks AUTOFROM-AUTOTO
AutoT:      .word 0
AutoR:      .byte 1
AutoHold:   .byte 0
AutoDir:    .byte $ff
AutoHop:    .byte 0
AutoUnder:  .byte 0
AutoRoom:   .byte 0
AutoRoomN:  .byte 0
DbgHarryOver: .byte 0           ; frames with more colour runs for Harry than his 5 sprites
DbgMcOver:  .byte 0             ; frames with more than 3 colours for an object
FreqTab:    .word SidFreqLo     ; PAL or NTSC frequency tables
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0
FireReset:  .byte $ff           ; fire as Game Reset (after the game): $FE
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
SndLast:    .fill 6, $ff
SndOn:      .fill 2

; working variables in free RAM at $C000 (not in the program file; cleared at start-up)
        .virtual WORKRAM
; collide
ScorePtr:   .fill 12            ; the score's digit pointers (every other byte)
ObjXPix:    .byte 0             ; the object's pixel, the tunnel object's
TunXPix:    .byte 0
HRef:       .byte 0             ; REFP0 ($08: Harry reflected)
UpLo:       .byte 0             ; Harry's lines drawn (by line - 106): above the ground,
UpHi:       .byte 0             ; UpLo .. UpHi - 1; below it, LwLo .. LwHi - 1
LwLo:       .byte 0
LwHi:       .byte 0
hrow:       .byte 0
MulA:       .byte 0
MulLo:      .byte 0
RangeHi:    .byte 0
UpEnd:      .byte 0
VineAtLine: .byte 0             ; VineAt: the line, its accumulator, its pixel
VineAtAcc:  .byte 0
VineAtX:    .byte 0
HPat:       .fill 109           ; Harry's pixels shown per line (106-214)
HCol:       .fill 109           ; ... and the 2600 colour
Inr151:     .byte 0
UpFirst:    .byte 0
UpLast:     .byte 0
UpPrevR:    .byte 0
UpPrevC:    .byte 0
UpCurR:     .byte 0
UpCurC:     .byte 0
UpIn:       .byte 0
VcAcc:      .byte 0
F6v:        .byte 0
LowLast:    .byte 0
PfR:        .fill 3             ; PF0, PF1, PF2
TreeWin:    .byte 0
Mask151:    .byte 0
VineEnd:    .byte 0             ; the line after the vine's last (0: no vine)
VineStep:   .byte 0
fPfA:       .byte 0             ; collisions: playfield, vine to line 151's part (CollTop) and
fPfB:       .byte 0             ; to line 167 (CollGround); the objects on the ground, in the
fBlA:       .byte 0             ; tunnel
fBlB:       .byte 0
fP1G:       .byte 0
fP1T:       .byte 0
CopyD:      .fill 3
TunD:       .byte 0
TunRefl:    .byte 0
ShRow:      .byte 0
ShAcc:      .byte 0
LineIdx:    .byte 0

; render
RoomKey:    .fill NBUF             ; what each buffer shows: the trees and the ladder,
DigKeys:    .fill 7 * 3 * NBUF            ; the digit rows' pointers and first digit's bits (7 per row, buffer),
DigCell:    .fill 13            ; (DigitRow: the cells to draw)
TreeCols:   .fill 16            ; each tree pattern's four tree columns (InitCanopy)
InitT:      .byte 0
LadderOn:   .fill 64            ; the ladder's characters with it and without (InitLadder)
LadderOff:  .fill 64
PitVals:    .fill 8 * NBUF            ; the pits' values and the hole,
HoleKey:    .fill NBUF             ; the hole and the ladder
HoleLad:    .fill NBUF
PitDirty:   .fill NBUF             ; (1: to be drawn whatever the keys say)
HoleDirty:  .fill NBUF
VnEnd:      .fill 3 * NBUF      ; the vine's sprites: the end of the rows drawn (3 per set)
VnNew:      .fill 3             ; ... this time
SetOf:                          ; the set of blocks each buffer uses: the vine's, Harry's
VnSet:      .fill NBUF
HSetOf:     .fill NBUF
OSetOf:     .fill NBUF          ; (the objects')
TSetOf:     .fill NBUF          ; (the tunnel's)
OSet:       .byte 0             ; the objects' set being used
OKC0:       .fill NBUF          ; ... each set: its copies' places against pixel 88 (ObjSprites)
OKC1:       .fill NBUF
OKC2:       .fill NBUF
OPx:        .fill 3             ; the copies' pixels, places
OCls:       .fill 3
OBuild:     .byte 0             ; (the set being built)
TSet:       .byte 0             ; the tunnel's set being used
TSY:        .fill 2 * NBUF      ; ... each set's registers: Y (sprites 5, 6), enable
TSEn:       .fill NBUF
ShowB:      .byte 0             ; render: the buffer shown, the one waiting ($FF: none)
WaitB:      .byte 0
FsA:        .byte 0
FsB:        .byte 0
RPass:      .byte 0             ; Render: passes, the pass each buffer was last drawn in
RDrawn:     .fill NBUF
DigIn:      .fill 15            ; ScoreChars' inputs last time, their version, each buffer's
DigVer:     .byte 0
DigBufVer:  .fill NBUF
ColIn:      .fill 8             ; Colours' (the same)
ColVer:     .byte 0
ColBufVer:  .fill NBUF
HSet:       .byte 0             ; Harry's set being used
HSx:        .byte 0             ; (HarrySame)
HSy:        .byte 0
HSr:        .byte 0
HSk:        .byte 0
HSs:        .byte 0
HSVer:      .fill NBUF          ; ... each set's version (one more each time it changes)
HBVer:      .fill NBUF          ; ... the version each buffer's registers and pointers are from
HSY:        .fill 5 * NBUF      ; ... each set's registers: Y, colour
HSC:        .fill 5 * NBUF
VnT:        .byte 0             ; (the set being drawn)
VKey:       .fill 4             ; this frame's vine: slope, step, end, trees
SetKey:     .fill 4 * NBUF             ; each set's vine (4 bytes each), whether it holds one,
SetValid:   .fill NBUF             ; its sprites' X, MSB and enable bits
SetX:       .fill 3 * NBUF
SetMsb:     .fill NBUF
SetEn:      .fill NBUF
VY:         .byte 0
VEnd:       .byte 0
BrX4:       .fill 4
VnPtr:      .fill 3 * NBUF             ; the vine's sprite pointers (buffer + 2 * sprite)
ObX:        .fill 3 * NBUF             ; the objects' (EvObjects): X, pointer (buffer + 2 * copy),
ObPtr:      .fill 3 * NBUF             ; colour, MSB and enable bits (5-7)
ObCol:      .fill NBUF
ObMsb:      .fill NBUF
ObEn:       .fill NBUF
DbgVineCut: .byte 0
Queue:      .fill NBUF - 1      ; the buffers drawn, waiting to be shown (QCount of them)
DigLo:      .fill 12
DigF8:      .byte 0
BrX:        .fill 2
GrndTmp:    .fill 8
BallL:      .byte 0
BallR:      .byte 0
HUsed:      .fill 5 * NBUF            ; rows drawn in Harry's blocks (5 per buffer)
HSUpLo:     .fill NBUF             ; Harry's lines as each buffer's blocks hold them: where the parts
HSLwLo:     .fill NBUF             ; above and below the ground start, their lengths, the gap,
HSN1:       .fill NBUF             ; the lines (both parts, one after the other)
HSN2:       .fill NBUF
HSGap:      .fill NBUF
HKey:       .fill 12            ; what Harry's lines depend on (Collide), and what each buffer's
HKeyB0:     .fill 12            ; blocks were drawn for
HKeyB2:     .fill 12
HKeyPrev:   .fill 12            ; (and what the lines were made for last tick)
HasUp:      .byte 0
NoCopy:     .byte 0
HKeyB1:     .fill 12
HSi:        .byte 0
LastRow:    .byte 0
HSa:        .byte 0
HSb:        .byte 0
HSc:        .byte 0
HSEn:       .fill NBUF
HSPat0:     .fill 109
HSCol0:     .fill 109
HSPat1:     .fill 109
HSCol1:     .fill 109
HSPat2:     .fill 109
HSCol2:     .fill 109
RunCol:     .byte 0
GRow:       .byte 0             ; GLine: the character row its stores are set for
GKey:       .fill 3             ; ... PF2, class, ball its bytes are for
GT:         .fill 9             ; ... the cells' bytes (cells 0-6 mirrored, 7, 8)
RunRaw:     .byte 0
RunStart:   .byte 0
RunRows:    .byte 0
HXLo:       .byte 0
HXHi:       .byte 0
OKeyP:      .fill NBUF             ; what each buffer's objects' block holds: shape, colours,
OKeyC:      .fill NBUF             ; colour masks
OKeyE:      .fill NBUF
OKeyA:      .fill NBUF
OCol0:      .fill NBUF             ; ... and its own colour
TKeyA:      .fill NBUF             ; ... the tunnel's
TKeyB:      .fill NBUF
TKeyCA:     .fill NBUF
TKeyCB:     .fill NBUF
TKeyR:      .fill NBUF
TKeyM:      .fill NBUF
HEnBits:    .byte 0
HMsbBits:   .byte 0
ORow:       .fill 32            ; an object's rows, colours, colour slots
OCol:       .fill 32
OSlot:      .fill 32
SlotCol:    .fill 3
GSKey:      .fill 3             ; the objects' colour slots: for which colours, by line, the colours
GSlot:      .fill 15
GSlotCol:   .fill 3
TSKey:      .fill 3             ; ... the tunnel's
TSlot:      .fill 32
TSlotCol:   .fill 3

StBg:       .fill NBUF             ; staged registers per buffer: colours,
StPf:       .fill NBUF
StDig:      .fill NBUF
StBranch:   .fill NBUF
StTrees:    .fill NBUF
StGround:   .fill NBUF
StPit:      .fill NBUF
StEarth:    .fill NBUF
StTunBg:    .fill NBUF
StBlack:    .fill NBUF
StMc1:      .fill NBUF
StMc2:      .fill NBUF
StMsb:      .fill NBUF             ; sprites (8 per buffer)
StEn:       .fill NBUF
StCol:      .fill 8 * NBUF
StX:        .fill 8 * NBUF
StY:        .fill 8 * NBUF
TnMc1:      .fill NBUF             ; the tunnel's sprites 5 and 6 (X, Y, pointer: 5 at [buffer],
TnMc2:      .fill NBUF             ; 6 at [buffer + 2])
TnCol:      .fill NBUF
TnX:        .fill 2 * NBUF
TnY:        .fill 2 * NBUF
TnPtr:      .fill 2 * NBUF
TnMsb:      .fill NBUF
TnEn:       .fill NBUF
        .cerror * > WORKRAM + $800, "working variables overflow"
        .endv

; ---------------------------------------------------- the 2600 program
; The original ROM with the patches the C64 needs (see the top of main.asm):
;   $F000 power-on: no SEI (our interrupts run the display)
;   $F006 the RAM clear (power-on, and Game Reset from $D1): from $80 only (JSR ClearZP), the
;         stack pointer left to the C64 (no TXS)
;   $F0CE the kernel's wait for the timer: "jmp KernelHook" instead of drawing the picture
;   $F5A4 "stx VBLANK", $F663 "sty VSYNC", $F66B "sta VSYNC": they would hit the C64's $01 /
;         $00 (to $2E instead)
;   $F5BA "sta CXCLR" (when Harry comes back after a death): clears our CXPPMM ($37) instead
;   $F73A "lda CXPPMM" ($07), $F817 "lda INPT4" ($0C): from $37 / $3C (the TIA's mirrors on the
;         2600; on the C64 the game's own writes to COLUP1 / REFP1 land at $07 / $0C)
ROM     = "../build/original.a26"
        .cerror * > VICBANK, "the program runs into the video bank"
; (the 2600 image itself may load into the video bank: Start copies it to $F000 before the
; video bank is set up)
GameImage:
        nop                     ; F000: (sei)
        .binary ROM, $0001, $0006-$0001
        jsr ClearZP             ; F006: (sta $00,x / txs / inx / bne)
        nop
        nop
        nop
        .binary ROM, $000c, $00ce-$000c
        jmp KernelHook          ; F0CE: (lda INTIM / bne)
        nop
        nop
        .binary ROM, $00d3, $05a4-$00d3
        stx $2e                 ; F5A4: (stx VBLANK)
        .binary ROM, $05a6, $05ba-$05a6
        sta CXPPMM              ; F5BA: (sta CXCLR)
        .binary ROM, $05bc, $0663-$05bc
        sty $2e                 ; F663: (sty VSYNC)
        .binary ROM, $0665, $066b-$0665
        sta $2e                 ; F66B: (sta VSYNC)
        .binary ROM, $066d, $073a-$066d
        lda CXPPMM              ; F73A: (lda $07)
        .binary ROM, $073c, $0817-$073c
        lda INPT4               ; F817: (lda $0C)
        .binary ROM, $0819, $1000-$0819
        .cerror * - GameImage != $1000, "the 2600 image must be 4K"
