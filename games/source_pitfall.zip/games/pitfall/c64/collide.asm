; ================================================================ collide
; KernelHook's work, from RAM as the kernel would see it (the rules: tools/model.js):
;   - Harry's lines as the kernel draws them: HPat / HCol by line - 106 (lines 106-214): the
;     pixels shown (reflected; bit 7 = his leftmost) and the 2600 colour, in two ranges (above
;     the ground UpLo..UpHi-1, below it LwLo..LwHi-1); Render uses them too
;   - the collisions the game reads: CollTop ($85, CXP0FB at line 151: bit 7 Harry-playfield,
;     6 Harry-vine), CollGround ($86, at line 167: bit 7 Harry-object, 6 Harry-playfield,
;     5 Harry-vine) and CXPPMM ($37, read by the next tick: bit 7 Harry-object, from line 106)
;   - the RAM the kernel leaves: the vine's accumulator, its temporaries, the logo's pointers
;
; Harry's rows: the kernel counts Y down one a line from Y = HarryY + Bounce + $15 (after line
; L's step, 106-158: Y = hy + 105 - L) and draws row Y where Y < $16, so rows are written on
; lines hy + 84 .. hy + 105. Without VDEL (106-126) a row shows from its write part-way across
; the line (pixel 85 / 91, +6 when in range); with VDEL (127-159) a line shows the row written
; the line before; line 152 changes at pixel 34. Below the ground (160-168) nothing; then from
; F6 = Y - 8 (hy - 61): line 169 row F6, 170 row F6-1 from pixel 40, 171-214 row F6 + 168 - L
; (row F6-2 is skipped).

Collide:
        cld
        ldx #10                 ; the score's digit pointers, before the logo's replace them
-       lda DigitPtr,x
        sta ScorePtr,x
        dex
        dex
        bpl -
        ; ---- positions
        lda PosCoarse
        ldy PosFine
        jsr ObjX
        sta hx
        lda PosCoarse+1
        ldy PosFine+1
        jsr ObjX
        sta ObjXPix
        lda PosCoarse+2
        ldy PosFine+2
        jsr ObjX
        sta TunXPix
        lda #$ff                ; Harry's pixels that show: not in the HMOVE blank (0-7) nor
        ldx hx                  ; wrapped past 159 (into it)
        cpx #8
        bcs +
        lda #8
        sec
        sbc hx
        tax
        lda MaskFrom,x
+       sta vm
        lda hx
        cmp #153
        bcc +
        lda #160
        sec
        sbc hx
        tax
        lda MaskFrom,x
        eor #$ff
        and vm
        sta vm
+       lda HarryReflect
        and #8
        sta HRef
        jsr VineSetup
        ; ---- what Harry's lines depend on: his Y counter, the parts' first and last lines
        lda #0
        sta Inr151
        sta HasUp
        clc
        lda HarryY
        adc Bounce
        adc #$15
        sta hy
        beq _f6                 ; (rows written on lines hy + 84 .. hy + 105: none for hy 0 or
        cmp #75                 ; > 74)
        bcs _f6
        inc HasUp
        adc #84                 ; first line written: max(106, hy + 84)
        cmp #106
        bcs +
        lda #106
+       sta UpFirst
        lda hy
        clc
        adc #105                ; last: min(158, hy + 105)
        cmp #158
        bcc +
        lda #158
+       sta UpLast
        cmp #151                ; line 151's row in range? (it sets where CollTop is read)
        bcc _f6
        lda UpFirst
        cmp #152
        bcs _f6
        lda #1
        sta Inr151
_f6     lda hy                  ; the lower part (lines 169-214): F6 = hy - 61
        sec
        sbc #61
        sta F6v
        jsr HarryKey
        ldx #11                 ; the same as the last tick's: the same lines (HPat / HCol kept)
-       lda HKey,x
        cmp HKeyPrev,x
        bne _new
        dex
        bpl -
        jmp _same
_new    ldx #11
-       lda HKey,x
        sta HKeyPrev,x
        dex
        bpl -
        lda #0                  ; ---- the lines drawn last time cleared
        ldx UpLo
        cpx UpHi
        bcs +
-       sta HPat,x
        inx
        cpx UpHi
        bcc -
+       ldx LwLo
        cpx LwHi
        bcs +
-       sta HPat,x
        inx
        cpx LwHi
        bcc -
+       sta UpLo
        sta UpHi
        sta LwLo
        sta LwHi
        lda HasUp               ; ---- the upper part (lines 106-159), the lower (169-214)
        beq +
        jsr UpperLines
+       jsr LowerLines
_same
        jsr Collisions
        ; ---- the RAM the kernel leaves
        lda VineSlope           ; the vine's accumulator after its 83 steps: 83 * slope
        sta tmp
        asl
        sta tmp2                ; *2
        asl
        asl
        asl
        clc
        adc tmp2
        sta tmp2                ; *18
        lda tmp
        asl
        asl
        asl
        asl
        asl
        asl                     ; *64
        clc
        adc tmp2
        clc
        adc tmp                 ; *83
        sta VineAcc
        ldy #8                  ; the logo's pointers: Activision, or the copyright line while
        lda Frozen              ; the game waits (Frozen / 8 from 20 down to 12: scrolling;
        ldx Sound               ; Activision while a tune plays)
        beq +
        lda #0
+       lsr
        lsr
        lsr
        cmp #$14
        bcs +
        ldy #0
        cmp #$0c
        bcc +
        sbc #$0c
        tay
+       tya
        clc
        adc #$58
        ldx #0
-       sta DigitPtr,x
        clc
        adc #$10
        inx
        inx
        cpx #12
        bcc -
        ldy #0
        lda (DigitPtr+10),y     ; the last byte the logo's loop read
        sta Temp6
        lda #$ff
        sta Temp7
        lda #0
        sta Temp8
        rts

; HarryKey: HKey = everything Harry's lines (HPat / HCol) depend on: his Y, shape and colour
; pointers, the colour masks, the reflection; and for the lines that change part-way across
; (152 at pixel 34, 170 at 40, 106-126 at 85-97) his X, clamped to where it matters (left of the
; change by 8 or more: the old row; right of it: the new), and the vine's slope (it times the
; changes on 106-126). Render redraws his sprites only when it changes.
HarryKey:
        lda hy
        sta HKey
        lda HarryPtr
        sta HKey+1
        lda HarryPtr+1
        sta HKey+2
        lda HarryColPtr
        sta HKey+3
        lda HarryColPtr+1
        sta HKey+4
        lda ColourEor
        sta HKey+5
        lda ColourAnd
        sta HKey+6
        lda HRef
        sta HKey+7
        lda #0
        sta HKey+8
        sta HKey+9
        sta HKey+10
        sta HKey+11
        lda HasUp               ; the upper part's lines: 152 (rows of 150 or 151), 106-126
        beq _low
        lda UpLast
        cmp #150
        bcc +
        lda UpFirst
        cmp #152
        bcs +
        ldx #26
        ldy #34
        jsr _clamp
        sta HKey+8
+       lda UpFirst
        cmp #127
        bcs _low
        ldx #77
        ldy #97
        jsr _clamp
        sta HKey+10
        cmp #77                 ; (the slope only when he is where the changes are: else all
        beq _low                ; the old rows, or all the new)
        cmp #97
        beq _low
        lda VineSlope
        sta HKey+11
_low    lda F6v                 ; 170
        cmp #$17
        bcs +
        ldx #32
        ldy #40
        jsr _clamp
        sta HKey+9
+       rts
; hx clamped to X .. Y
_clamp  stx tmp
        lda hx
        cmp tmp
        bcs +
        lda tmp
+       sty tmp
        cmp tmp
        bcc +
        lda tmp
+       rts

; A = coarse count, Y = fine motion (HM) -> A = the object's pixel, as the kernel positions it
; (coarse c: pixel 15c + 6; 0: pixel 12, and 6 more to the left from the kernel's $60; then
; the fine move: HM's signed high nibble, to the left)
ObjX:
        tax
        beq +
        lda Mul15,x
        clc
        adc #6
        bne ++
+       lda #6
+       sta tmp
        tya
        lsr
        lsr
        lsr
        lsr
        tax
        lda tmp
        clc
        adc AddHM,x             ; (+ 8 - the move: positive throughout)
        cmp #8
        bcs +
        adc #160
+       sec
        sbc #8
        cmp #160
        bcc +
        sbc #160
+       rts

; A * X -> A (high byte), MulLo (low byte)
Mul8:
        sta MulA
        stx MulLo
        lda #0
        ldx #8
        lsr MulLo
-       bcc +
        clc
        adc MulA
+       ror
        ror MulLo
        dex
        bne -
        rts

; A = the old pattern, tmp = the new, X = the pixel the new one shows from -> A
MixFrom:
        sta tmp2
        txa
        sec
        sbc hx                  ; Harry's pixels from (p - hx) on are new
        bcc _all
        cmp #8
        bcs _none
        tax
        lda tmp2
        eor tmp
        and MaskFrom,x
        eor tmp2
        rts
_all    lda tmp
        rts
_none   lda tmp2
        rts

; Lines UpFirst .. UpLast + 1 (at most 159). Lines up to 127 (no VDEL there: Harry high up,
; rare) one by one (UpperSlow); 128-151 and 153-159 show the row written the line before (a copy
; row by row: UpperCopy); 152 line 150's row until pixel 34, then line 151's.
UpperLines:
        lda UpFirst
        sec
        sbc #106
        sta UpLo
        lda UpLast
        sec
        sbc #104                ; (UpLast + 1 - 106, + 1)
        sta UpHi
        lda UpFirst
        cmp #128
        bcs +
        jsr UpperSlow
+       lda UpFirst             ; 128-151
        clc
        adc #1
        cmp #128
        bcs +
        lda #128
+       sta v0
        lda UpLast
        clc
        adc #1
        cmp #152
        bcc +
        lda #151
+       sta v1
        jsr UpperCopy
        lda #150                ; 152
        jsr RowAt
        sta v2
        lda #151
        jsr RowAt
        sta tmp
        stx v3
        ora v2
        beq +
        lda v2
        ldx #34
        jsr MixFrom
        sta HPat + 152 - 106
        lda v3
        sta HCol + 152 - 106
+       lda UpFirst             ; 153-159
        clc
        adc #1
        cmp #153
        bcs +
        lda #153
+       sta v0
        lda UpLast
        clc
        adc #1
        sta v1
        jmp UpperCopy

; UpperCopy: lines v0 .. v1 (none if v0 > v1): the row of the line before (y = hy + 106 - L)
UpperCopy:
        lda v1
        cmp v0
        bcs +
        rts
+       lda hy
        clc
        adc #106
        sec
        sbc v0
        tay
        ldx v0
        lda HRef
        bne _refl
-       lda (HarryColPtr),y
        eor ColourEor
        and ColourAnd
        sta HCol-106,x
        lda (HarryPtr),y
        sta HPat-106,x
        dey
        inx
        cpx v1
        bcc -
        beq -
        rts
_refl   lda (HarryColPtr),y
        eor ColourEor
        and ColourAnd
        sta HCol-106,x
        lda (HarryPtr),y
        sty tmp3
        tay
        lda Reverse,y
        ldy tmp3
        sta HPat-106,x
        dey
        inx
        cpx v1
        bcc _refl
        beq _refl
        rts

; RowAt: A = a line -> A = the row written on it (shown), X = its colour (0, 0 if none)
RowAt:
        cmp UpFirst
        bcc _z
        cmp UpLast
        beq +
        bcs _z
+       sta tmp3
        lda hy
        clc
        adc #105
        sec
        sbc tmp3
        tay
        jmp HarryRowCol
_z      lda #0
        tax
        rts

; UpperSlow: lines UpFirst .. 127 (at most UpLast + 1). UpPrevR / UpPrevC: the row written on
; the line before and its colour (0 before the first); hrow: this line's row (counting down)
UpperSlow:
        lda #0
        sta UpPrevR
        sta UpPrevC
        lda UpFirst
        sta line
        lda hy
        clc
        adc #105
        sec
        sbc UpFirst
        sta hrow
        lda UpFirst             ; the vine's accumulator before line UpFirst's step: (L - 68) *
        sec                     ; slope
        sbc #68
        ldx VineSlope
        jsr Mul8
        lda MulLo
        sta VcAcc
_l      lda #0
        sta UpCurR
        sta UpCurC
        ldx #0                  ; (X: in range)
        lda line
        cmp UpLast
        beq +
        bcs _sect               ; past the last row written: none this line
+       ldy hrow
        jsr HarryRowCol
        sta UpCurR
        stx UpCurC
        ldx #1
_sect   lda line
        cmp #127
        bcs _vdel
        ; 106-126: the row shows from its write: pixel 85, +6 if this line's vine step carried,
        ; +6 if the row is in range
        stx tmp3
        lda VcAcc               ; (this line's vine step: the accumulator kept from line to line)
        clc
        adc VineSlope
        sta VcAcc
        lda #85
        bcc +
        lda #91
+       ldx tmp3
        beq +
        clc
        adc #6
+       tax
        lda UpCurR
        sta tmp
        lda UpPrevR
        jsr MixFrom
        ldy UpPrevC
        ldx line                ; (line 106's colour is the branches': COLUP0 from line 66)
        cpx #106
        bne _st
        ldy ColTrees
        jmp _st
_vdel   lda UpPrevR             ; 127: the row written the line before
        ldy UpPrevC
_st     ldx line                ; store: pattern A, colour Y
        sta HPat-106,x
        tya
        sta HCol-106,x
        lda UpCurR
        sta UpPrevR
        lda UpCurC
        sta UpPrevC
        dec hrow
        cpx #127                ; on to 127 (at most the line after the last row)
        bcs _end
        cpx UpLast
        beq _more
        bcs _end
_more   inc line
        jmp _l
_end    rts

; Lines 169-214 (F6v = the kernel's $F6 at the earth)
LowerLines:
        lda F6v
        cmp #$17
        bcs _rest               ; (rows F6 and F6-1 both out of range)
        lda #169 - 106
        sta LwLo
        lda #171 - 106
        sta LwHi
        ldy F6v                 ; 169: row F6
        lda #0
        sta UpCurR
        sta UpCurC
        cpy #$16
        bcs +
        jsr HarryRowCol
        sta UpCurR
        stx UpCurC
+       lda UpCurR
        sta HPat + 169 - 106
        lda UpCurC
        sta HCol + 169 - 106
        ldy F6v                 ; 170: row F6-1 from pixel 40 (if in range; else as 169)
        dey
        cpy #$16
        bcs _same
        jsr HarryRowCol
        sta tmp
        stx HCol + 170 - 106
        lda UpCurR
        ldx #40
        jsr MixFrom
        sta HPat + 170 - 106
        jmp _rest
_same   lda UpCurR
        sta HPat + 170 - 106
        lda UpCurC
        sta HCol + 170 - 106
_rest   lda F6v                 ; 171-214: row F6 + 168 - L, in range on F6 + 147 .. F6 + 168
        cmp #68
        bcs _done
        clc
        adc #147
        cmp #171
        bcs +
        lda #171
+       sta line
        sec
        sbc #106
        ldx LwHi                ; (the range: from 169 if those were done)
        bne +
        sta LwLo
+       lda F6v
        clc
        adc #168
        cmp #215
        bcc +
        lda #214
+       sta LowLast
        lda F6v                 ; the first line's row
        clc
        adc #168
        sec
        sbc line
        sta hrow
        ldy hrow                ; (all in range: rows hrow down to 0 at most)
        ldx line
        lda HRef
        bne _lr
-       lda (HarryColPtr),y
        eor ColourEor
        and ColourAnd
        sta HCol-106,x
        lda (HarryPtr),y
        sta HPat-106,x
        dey
        inx
        cpx LowLast
        bcc -
        beq -
        bcs _lw
_lr     lda (HarryColPtr),y
        eor ColourEor
        and ColourAnd
        sta HCol-106,x
        lda (HarryPtr),y
        sty tmp3
        tay
        lda Reverse,y
        ldy tmp3
        sta HPat-106,x
        dey
        inx
        cpx LowLast
        bcc _lr
        beq _lr
_lw     lda LowLast
        sec
        sbc #106 - 1
        sta LwHi
_done   rts

; Y = a row -> A = Harry's row as shown (reflected), X = its colour (masked as the kernel does)
HarryRowCol:
        lda (HarryColPtr),y
        eor ColourEor
        and ColourAnd
        tax
        lda (HarryPtr),y
        pha
        lda HRef
        beq +
        pla
        sty tmp3
        tay
        lda Reverse,y
        ldy tmp3
        rts
+       pla
        rts

; ---- the collisions, over Harry's lines (both ranges). Each flag is looked for only until found.
Collisions:
        lda #0
        sta fPfA
        sta fPfB
        sta fBlA
        sta fBlB
        sta fP1G
        sta fP1T
        ldx Trees               ; the trees' playfield under Harry (lines 106-151): PF1, PF2
        lda #0                  ; from the ROM's tables
        sta PfR
        lda $fbce,x
        sta PfR+1
        lda $fbd2,x
        sta PfR+2
        jsr PfWindow
        sta TreeWin
        ldx #76                 ; line 151's part read for CollTop: pixels below 106 (76 if
        lda Inr151              ; its row is out of range), + 6 if the vine's ENABL write
        beq +                   ; came first (VineLen not 0)
        ldx #106
+       lda VineLen
        beq +
        txa
        clc
        adc #6
        tax
+       txa
        sec
        sbc hx
        bcc _none               ; (p <= hx: none of Harry before it)
        cmp #8
        bcs _all
        tax
        lda MaskFrom,x
        eor #$ff
        jmp +
_none   lda #0
        beq +
_all    lda #$ff
+       sta Mask151
        jsr CopySetup
        jsr CollUpper
        jsr CollLower
        ; the flags into the game's bytes
        lda #0                  ; CollTop: bit 7 playfield, 6 vine (to line 151's part)
        ldx fPfA
        beq +
        ora #$80
+       ldx fBlA
        beq +
        ora #$40
+       sta CollTop
        lda #0                  ; CollGround: 7 objects, 6 playfield, 5 vine (to line 167)
        ldx fP1G
        beq +
        ora #$80
+       ldx fPfB
        beq +
        ora #$40
+       ldx fBlB
        beq +
        ora #$20
+       sta CollGround
        lda fP1G                ; CXPPMM for the next tick: the objects, ground and tunnel
        ora fP1T
        beq +
        lda #$80
+       sta CXPPMM
        rts

; ---- above the ground (UpLo .. UpHi - 1): the trees, the vine, the ground, the objects. Each
; region only where something can touch Harry; each flag looked for until found.
CollUpper:
        lda UpHi                ; (UpEnd: the index after the last line, at most 151's + 1)
        cmp #152 - 106
        bcc +
        lda #152 - 106
+       sta UpEnd
        ; the trees (106-151; line 151 up to its part): if any are in Harry's columns
        lda TreeWin
        and vm
        beq _vine
        sta v1
        ldx UpLo
-       cpx UpEnd
        bcs _vine
        lda HPat,x
        and v1
        beq _tn
        sta fPfB
        cpx #151 - 106
        bcc _ta
        and Mask151
        beq _tn
_ta     sta fPfA
        jmp _vine               ; (both found)
_tn     inx
        jmp -
_vine   lda VineEnd             ; the vine (lines below VineEnd, at most 151)
        beq _152
        sec
        sbc #106
        cmp UpEnd
        bcc +
        lda UpEnd
+       sta v2                  ; (the index after its last line here)
        lda #$ff
        sta VineAtLine
        ldx UpLo
-       cpx v2
        bcs _152
        lda HPat,x
        and vm
        beq _vn
        sta v0
        stx LineIdx
        txa
        clc
        adc #106
        sta line
        jsr VineAt              ; A = its pixel - Harry's (>= 8: not on him)
        ldx LineIdx
        cmp #8
        bcs _vn
        tay
        lda Bit7,y
        and v0
        beq _vn
        sta fBlB
        cpx #151 - 106
        bcc _va
        and Mask151
        beq _vn
_va     sta fBlA
        jmp _152
_vn     inx
        jmp -
_152    lda UpHi                ; 152: all playfield
        cmp #152 - 106 + 1
        bcc _done
        lda UpLo
        cmp #152 - 106 + 1
        bcs +
        lda HPat + 152 - 106
        and vm
        beq +
        sta fPfB
+       ldx #153 - 106          ; 153-159: the ground's playfield (PF2 the pit's), the objects
        cpx UpLo
        bcs +
        ldx UpLo
+
-       cpx UpHi
        bcs _done
        lda HPat,x
        and vm
        beq _gn
        sta v0
        stx LineIdx
        lda fPfB
        bne _go
        lda #159 - 106          ; (PitPF + 159 - L)
        sec
        sbc LineIdx
        tax
        lda PitPF,x
        sta PfR+2
        lda #$ff
        sta PfR
        sta PfR+1
        jsr PfWindow
        and v0
        sta fPfB
_go     lda fP1G
        ora NoCopy              ; (no copy under Harry: nothing to find)
        bne _gx
        lda #159 - 106
        sec
        sbc LineIdx
        tax
        lda ObjRows,x
        beq _gx
        jsr CopyWin
        and v0
        sta fP1G
_gx     ldx LineIdx
_gn     inx
        jmp -
_done   rts

; ---- below the ground (LwLo .. LwHi - 1): the tunnel object (lines 183-214)
CollLower:
        lda TunD
        cmp #$ff
        beq _done
        ldx #183 - 106
        cpx LwLo
        bcs +
        ldx LwLo
+
-       cpx LwHi
        bcs _done
        lda HPat,x
        and vm
        beq _n
        sta v0
        stx LineIdx
        txa                     ; its row: 183 the upper part's 15, 184-198 its 14..0,
        clc                     ; 199-214 the lower part's 15..0
        adc #106
        ldy #15
        cmp #184
        bcc _ua
        sta tmp
        lda #198
        sec
        sbc tmp
        bcc _ub
        tay
_ua     lda (TunShapeA),y
        jmp +
_ub     adc #16                 ; (carry clear: 214 - L)
        tay
        lda (TunShapeB),y
+       beq _x
        ldy TunRefl
        beq +
        tay
        lda Reverse,y
+       jsr TunWin
        and v0
        beq _x
        sta fP1T
        rts
_x      ldx LineIdx
_n      inx
        jmp -
_done   rts

; PfR (PF0, PF1, PF2) -> A = the playfield under Harry's 8 pixels (bit 7 = his first)
PfWindow:
        lda hx
        lsr
        lsr
        sta cell
        lda #0
        sta tmp
        ldx cell
        jsr _bit
        inx
        jsr _bit
        inx
        jsr _bit
        lda hx
        and #3
        asl
        asl
        asl
        ora tmp
        tax
        lda PfWin,x
        rts
_bit    asl tmp                 ; (cell X on: bit 0 of tmp)
        cpx #40
        bcs +
        ldy PfReg,x
        lda PfR,y
        and PfMask,x
        beq +
        inc tmp
+       rts

; The vine: VineEnd = the line after its last (0: no vine; it is drawn from line 69 while ENABL
; is on: to 151 - VineLen), VineStep its move per carry (+1 / -1)
VineSetup:
        lda #0
        sta VineEnd
        ldx Scene
        lda $fca1,x             ; ENABL at the frame's start: the scene's, or in the crocodile
        ldy $ffee,x             ; rooms the object's bit 1
        beq +
        lda Object
+       and #2
        beq _off
        ldx #152                ; drawn while (151 - L) >= VineLen on lines 128-151
        lda VineLen
        beq +
        ldx #128
        cmp #24
        bcs +
        lda #152
        sec
        sbc VineLen
        tax
+       stx VineEnd
        lda VineDir             ; the step: HMBL's nibble ($F0 right, $10 left)
        lsr
        lsr
        lsr
        lsr
        tax
        lda AddHM,x
        sec
        sbc #8
        sta VineStep
_off    rts

; VineAt: A = (the vine's pixel on line `line`) - hx, mod 160 (>= 8: not on Harry).
; x = 78 + step * floor((L - 68) * slope / 256): the first call works it out, later ones (the
; lines only go down) step it on
VineAt:
        lda VineAtLine
        cmp #$ff
        bne _on
        lda line                ; (L - 68) * slope: the count of carries, the accumulator
        sec
        sbc #68
        ldx VineSlope
        jsr Mul8
        sta tmp
        lda MulLo
        sta VineAtAcc
        lda #78                 ; x = 78 +/- the count, mod 160
        ldx VineStep
        bmi +
        clc
        adc tmp
        cmp #160
        bcc ++
        sbc #160
        jmp ++
+       sec
        sbc tmp
        bcs +
        adc #160
+       sta VineAtX
        lda line
        sta VineAtLine
        jmp _x
_on     cmp line                ; step on to this line
        bcs _x
        inc VineAtLine
        lda VineAtAcc
        clc
        adc VineSlope
        sta VineAtAcc
        bcc _on2
        lda VineAtX
        clc
        adc VineStep
        cmp #160                ; (past 159: 0 going right, 159 going left)
        bcc +
        lda #0
        ldx VineStep
        bpl +
        lda #159
+       sta VineAtX
_on2    lda VineAtLine
        jmp _on
_x      lda VineAtX             ; (- Harry's, mod 160)
        sec
        sbc hx
        bcs +
        adc #160
+       rts

; For each copy of the object on the ground (CopyD) and the tunnel object (TunD): how it lies
; against Harry's pixels: 0-7 = it starts that many pixels right of his first; $81-$87 = that
; many to the left; $FF = no overlap
CopySetup:
        lda ObjNusiz
        and #7
        tax
        lda CopyN,x
        sta tmp2
        lda Mul3,x
        tay
        ldx #0
-       lda #$ff
        cpx tmp2
        bcs +
        lda ObjXPix
        clc
        adc CopyOff,y
        jsr Overlap
+       sta CopyD,x
        iny
        inx
        cpx #3
        bne -
        lda CopyD               ; (NoCopy: none of them under Harry)
        and CopyD+1
        and CopyD+2
        eor #$ff
        bne +
        lda #1
        bne ++
+       lda #0
+       sta NoCopy
        lda TunReflect
        and #8
        sta TunRefl
        lda TunXPix
        jsr Overlap
        sta TunD
        rts
; A = an object's pixel (maybe past 159) -> the code above
Overlap:
        cmp #160
        bcc +
        sbc #160
+       sec
        sbc hx
        bcs +
        adc #160
+       cmp #8
        bcc _r
        cmp #153
        bcs +
        lda #$ff
        rts
+       eor #$ff                ; 160 - d, with bit 7 set
        sec
        adc #160
        ora #$80
_r      rts

; A = an object row -> A = its copies' pixels under Harry's 8
CopyWin:
        sta ShRow
        lda #0
        sta ShAcc
        ldx #2
-       lda CopyD,x
        cmp #$ff
        beq +
        jsr Shift
        ora ShAcc
        sta ShAcc
+       dex
        bpl -
        lda ShAcc
        rts

; A = the tunnel object's row (shown) -> A = its pixels under Harry's 8
TunWin:
        sta ShRow
        lda TunD
        cmp #$ff
        bne Shift
        lda #0
        rts

; A = a shift code (0-7 right, $81-$87 left), ShRow = the row -> A (X kept)
Shift:
        tay
        bmi _l
        lda ShRow
        cpy #0
        beq +
-       lsr
        dey
        bne -
+       rts
_l      and #$7f
        tay
        lda ShRow
-       asl
        dey
        bne -
        rts
