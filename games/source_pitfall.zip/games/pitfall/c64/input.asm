; ================================================================== input
; Keyboard: W A S D + Space; a joystick in port 2 or port 1 (Pitfall! is for one player).
; F1 Game Reset, F2 power off/on, F3 Game Select, F5 colour/B&W, F7 / F8 difficulties (the game
; reads Game Reset and colour/B&W only). Pitfall! starts when the joystick moves; fire starts it
; too (it pushes the joystick up for that frame: up does nothing at the start), and after the
; game is over (no lives, time up, or every treasure found) fire is Game Reset. No flicker: no F.
ReadInput:
        lda #$ff
        sta $dc02               ; port A output, port B input
        lda #0
        sta $dc03
        lda #$ff
        sta $dc00
        lda $dc00
        sta joyb                ; port 2
        lda $dc01
        sta joyb+1              ; port 1
        eor #$1f                ; (the lines a port 1 joystick is pulling low: ignored)
        and #$1f
        sta tmp2
        lda #0                  ; any key down? (all rows at once)
        sta $dc00
        lda $dc01
        ora tmp2
        cmp #$ff
        bne _scan
        sta Keys                ; none
        sta Keys+1
        sta Keys+2
        sta Keys+6
        sta Keys+7
        bne _map
_scan   ldx #7                  ; the rows used: 0 (F keys), 1 (W A S, left shift), 2 (D),
-       lda KeySelect,x         ; 6 (right shift), 7 (space)
        sta $dc00
        lda $dc01
        ora tmp2
        sta Keys,x
        dex
        cpx #6
        bcs -
        ldx #2
-       lda KeySelect,x
        sta $dc00
        lda $dc01
        ora tmp2
        sta Keys,x
        dex
        bpl -
_map    lda #$ff
        sta $dc00
        lda joyb                ; SWCHA / INPT4: either port (0 = pressed: bits 0-4 up, down,
        and joyb+1              ; left, right, fire), or the keys W S A D, space
        sta tmp
        lda Keys+1
        and #$02                ; W
        bne +
        lda tmp
        and #$fe
        sta tmp
+       lda Keys+1
        and #$20                ; S
        bne +
        lda tmp
        and #$fd
        sta tmp
+       lda Keys+1
        and #$04                ; A
        bne +
        lda tmp
        and #$fb
        sta tmp
+       lda Keys+2
        and #$04                ; D
        bne +
        lda tmp
        and #$f7
        sta tmp
+       lda Keys+7
        and #$10                ; space
        bne +
        lda tmp
        and #$ef
        sta tmp
+       lda tmp
        asl
        asl
        asl
        asl
        ora #$0f
        and DbgSWCHA            ; debug overrides, poked from the VICE monitor by tools
        sta SWCHA
        lda tmp
        asl
        asl
        asl
        and #$80
        and DbgINPT4
        sta INPT4
        lda #$ff
        sta FireReset
        lda INPT4               ; fire while the game is frozen: at the start (the clock at
        bmi _fx                 ; 20:00) a push up; once it is over (no tune playing) Game Reset
        lda Frozen
        beq _fx
        lda ClockMin
        cmp #$20
        bne _over
        lda ClockSec
        bne _over
        lda SWCHA
        and #$ef
        sta SWCHA
        jmp _fx
_over   lda Sound
        bne _fx
        lda #$fe
        sta FireReset
_fx

        ; console switches
        lda Keys+0              ; F5: colour / B&W (on key-down)
        and #$40
        bne +
        lda PrevKeys
        and #$40
        beq +
        lda switches
        eor #$08
        sta switches
+       lda Keys+0              ; F7 / F8: difficulty
        and #$08
        bne +
        lda PrevKeys
        and #$08
        beq +
        lda Keys+1              ; with either shift key (F8): right difficulty
        bpl _right
        lda Keys+6
        and #$10
        beq _right
        lda #$40                ; F7: left difficulty
        bne _tog
_right  lda #$80
_tog    eor switches
        sta switches
+       lda Keys+0
        sta PrevKeys
        jsr PowerKey
        lda switches            ; reset (F1) and select (F3) are held buttons
        and #$fc
        sta tmp
        lda f2now               ; F1 is Game Reset (F2, on the same key, is the power switch)
        bne _rup
        lda Keys+0
        and #$10
        beq _f3
_rup    inc tmp                 ; bit 0 up
_f3     lda Keys+0
        and #$20
        beq +
        lda tmp
        ora #2
        sta tmp
+       lda tmp
        and FireReset
        and DbgSWCHB
        sta SWCHB
        rts

; F2 (F1 with either shift key): ask for a power cycle on key-down. f2now = F2 held.
PowerKey:
        lda #0
        sta f2now
        lda Keys+0
        and #$10
        bne _up                 ; F1 key up
        lda Keys+1              ; left shift
        bpl _down
        lda Keys+6              ; right shift
        and #$10
        bne _up
_down   inc f2now
        lda PrevF2
        bne _up
        lda #1
        sta PowerReq
_up     lda f2now
        sta PrevF2
        rts

KeySelect:  .byte $fe, $fd, $fb, $f7, $ef, $df, $bf, $7f
