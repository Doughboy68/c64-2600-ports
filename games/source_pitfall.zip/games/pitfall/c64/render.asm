; ================================================================= render
; Draw the state the last tick left into a buffer neither shown nor waiting (rbuf): its screen, character set
; and sprite blocks, and the register values the raster interrupt puts in (St*, Tn*). What
; only changes with the room, the score or the pits is redrawn when its key changes (per
; buffer); the vine every frame.
;
; Screen rows (2600 line 41 + 8r is row r's first): 0-2 the score and the clock (digits in
; columns 5-17), 3-5 the canopy (all playfield), 6-7 its lower edge, the branches and the trees'
; tops (unique cells), 8-13 the trees, 14-15 the ground (the pits: columns 12-27 unique),
; 16-17 the earth (the hole: columns 12-27 unique), 18-21 the tunnel (the ladder: columns 19-20
; unique), 21-22 the floor, 22-23 the logo (columns 5-17), 24 below the picture. Columns 0-1
; are the HMOVE comb (black) throughout.

Render:
        cld
        sei                     ; the buffers shown and waiting (ShowB, WaitB: $FF none; while
        lda curBuf              ; this draws, the frame top can only show the one waiting)
        sta ShowB
        ldy #$ff
        lda QCount
        beq +
        ldy Queue
+       sty WaitB
        cli
        inc RPass               ; the buffer: neither of them (the main loop made sure there is
        lda #0                  ; one), the one drawn longest ago (each is drawn at least every
        sta tmp                 ; NBUF passes: what the buffers and the sets were drawn from
        ldy #0                  ; never grows stale)
        ldx #NBUF - 1
-       cpx ShowB
        beq _n
        cpx WaitB
        beq _n
        lda RPass
        sec
        sbc RDrawn,x
        cmp tmp
        bcc _n
        sta tmp
        txa
        tay
_n      dex
        bpl -
        sty rbuf
        lda RPass
        sta RDrawn,y
        jsr BufPtrs
        jsr RoomChars
        jsr ScoreChars
        jsr GroundChars
        jsr Colours
        jsr HarrySprites
        jsr ObjSprites
        jsr TunSprites
        jsr VineSprites
        lda #1
        rts

; scr / chs for buffer rbuf
BufPtrs:
        ldx rbuf
        lda #<SCREEN
        sta scr
        lda ScrBaseHi,x
        sta scr+1
        lda #<CHARS
        sta chs
        lda ChsBaseHi,x
        sta chs+1
        rts

; ptrC = chs + A * 8 (character A's first byte)
CharPtr:
        sta ptrC
        lda #0
        asl ptrC
        rol
        asl ptrC
        rol
        asl ptrC
        rol
        clc
        adc chs+1
        sta ptrC+1
        lda ptrC
        clc
        adc chs
        sta ptrC
        bcc +
        inc ptrC+1
+       rts

; ptrB = scr + row A * 40
RowPtr:
        tax
        lda RowLo,x
        clc
        adc scr
        sta ptrB
        lda RowHi,x
        adc scr+1
        sta ptrB+1
        rts

; ---------------------------------------------------------------- set-up
; InitDigitTabs: the digits' cell bytes by font byte: the middle cell (bits 4-1), the shared
; cell (bits 7-5, after the digit before's last bit: clear, set)
InitDigitTabs:
        ldx #0
-       txa
        lsr
        and #15
        tay
        lda NibDigit,y
        sta DigMid,x
        txa
        lsr
        lsr
        lsr
        lsr
        lsr
        tay
        lda NibDigit,y
        sta DigShA,x
        lda NibDigit+8,y
        sta DigShB,x
        inx
        bne -
        rts

; InitBuffer: buffer rbuf from scratch: the fixed characters, the screen's layout, every key
; reset (all to be drawn)
InitBuffer:
        txa
        pha
        jsr BufPtrs
        ldy #0                  ; the fixed characters 0-7
-       lda FixedChars,y
        sta (chs),y
        iny
        cpy #64
        bcc -
        lda #C_ROW15            ; (C_ROW15)
        jsr CharPtr
        ldy #7
-       lda Row15Char,y
        sta (ptrC),y
        dey
        bpl -
        lda #C_SCORE            ; the score's and the logo's characters: playfield
        jsr CharPtr
        ldx #(C_CANOPY - C_SCORE) * 8 / 8
        lda #$55
-       ldy #7
-       sta (ptrC),y
        dey
        bpl -
        pha
        lda ptrC
        clc
        adc #8
        sta ptrC
        bcc +
        inc ptrC+1
+       pla
        dex
        bne --
        ldx #0                  ; the screen's layout: per row its usual cell (RowFill) and
_row    stx v0                  ; which unique cells it has (RowUniq)
        txa
        jsr RowPtr
        ldy #0
_col    lda #C_COMB
        cpy #2
        bcc _put
        ldx v0
        lda RowUniq,x
        beq _fill
        cmp #U_DIGITS
        bne _nd
        cpy #5                  ; digits: columns 5-17 (rows 0-2 the score, 22-23 the logo)
        bcc _fill
        cpy #18
        bcs _fill
        lda RowBase,x
        jmp _add
_nd     cmp #U_CANOPY
        bne _ng
        lda RowBase,x           ; canopy rows 6-7: columns 2-39
        jmp _add
_ng     cmp #U_GROUND
        bne _nl
        cpy #12                 ; ground / earth rows 14-17: columns 12-27
        bcc _fill
        cpy #28
        bcs _fill
        lda RowBase,x
        jmp _add
_nl     cpy #19                 ; tunnel rows 18-21: columns 19-20
        bcc _fill
        cpy #21
        bcs _fill
        lda RowBase,x
_add    sty tmp                 ; RowBase: the code of column 0 (as if it had one)
        clc
        adc tmp
        jmp _put
_fill   ldx v0
        lda RowFill,x
_put    sta (ptrB),y
        iny
        cpy #40
        bcc _col
        ldx v0
        inx
        cpx #25
        bcc _row
        ldx rbuf                ; every key: to be drawn
        lda #$ff
        sta RoomKey,x
        sta DigBufVer,x
        sta ColBufVer,x
        ldy #2                  ; (the digit rows: no pointer is $FF)
-       lda MulNBUF,y
        clc
        adc rbuf
        tax
        lda Mul7,x
        tax
        lda #$ff
        sta DigKeys,x
        sta DigKeys+1,x
        sta DigKeys+2,x
        sta DigKeys+3,x
        sta DigKeys+4,x
        sta DigKeys+5,x
        sta DigKeys+6,x
        dey
        bpl -
        ldx rbuf
        sta OKeyE,x             ; (no eor mask is $FF; no reflection either)
        sta HSN1,x              ; (no part is 255 lines long)
        lda HKBLo,x             ; (no reflection is $FF)
        sta ptrB
        lda HKBHi,x
        sta ptrB+1
        ldy #7
        lda #$ff
        sta (ptrB),y
        sta TKeyR,x
        lda #1
        sta PitDirty,x
        sta HoleDirty,x
        pla
        tax
        rts

; ------------------------------------------------------------------ room
; RoomChars: the trees (rows 6-13) and the earth's class (rows 16-17) when the room's trees or
; ladder changed for this buffer
RoomChars:
        lda Ladder
        and #$80
        ora Trees
        ldx rbuf
        cmp RoomKey,x
        bne +
        rts
+       sta RoomKey,x
        lda #8                  ; the trees (rows 8-13): sky (row 13: its last line the ground),
        jsr RowPtr              ; then the pattern's four tree columns (the rows' columns 2-39
        lda ptrB
        clc
        adc #2
        sta _r0+1
        lda ptrB+1
        adc #0
        sta _r0+2
        lda ptrB
        clc
        adc #42
        sta _r1+1
        lda ptrB+1
        adc #0
        sta _r1+2
        lda ptrB
        clc
        adc #82
        sta _r2+1
        lda ptrB+1
        adc #0
        sta _r2+2
        lda ptrB
        clc
        adc #122
        sta _r3+1
        lda ptrB+1
        adc #0
        sta _r3+2
        lda ptrB
        clc
        adc #162
        sta _r4+1
        lda ptrB+1
        adc #0
        sta _r4+2
        lda ptrB
        clc
        adc #202
        sta _r5+1
        lda ptrB+1
        adc #0
        sta _r5+2
        ldx #37                 ; through the stores below)
-       lda #C_BG
_r0     sta $ffff,x
_r1     sta $ffff,x
_r2     sta $ffff,x
_r3     sta $ffff,x
_r4     sta $ffff,x
        lda #C_ROW13
_r5     sta $ffff,x
        dex
        bpl -
        lda Trees
        asl
        asl
        tax
        lda TreeCols,x          ; (the columns: into the stores below)
        sta _t0+1
        lda TreeCols+1,x
        sta _t1+1
        lda TreeCols+2,x
        sta _t2+1
        lda TreeCols+3,x
        sta _t3+1
        ldx #5
-       lda RowOf8,x            ; (row 8 + x: its offset from row 8's start)
        clc
        adc ptrB
        sta ptrA
        lda ptrB+1
        adc #0
        sta ptrA+1
        lda #C_PF
_t0     ldy #0
        sta (ptrA),y
_t1     ldy #0
        sta (ptrA),y
_t2     ldy #0
        sta (ptrA),y
_t3     ldy #0
        sta (ptrA),y
        dex
        bpl -
        ; the earth beside the hole (rows 16-17, columns 2-11 and 28-39): in front of Harry
        ; where there is no ladder (the kernel's playfield priority)
        lda #16
        jsr RowPtr
        lda ptrB                ; (columns 2 and 28 of both rows: into the stores below)
        clc
        adc #2
        sta _e0+1
        lda ptrB+1
        adc #0
        sta _e0+2
        lda ptrB
        clc
        adc #42
        sta _e1+1
        lda ptrB+1
        adc #0
        sta _e1+2
        lda ptrB
        clc
        adc #28
        sta _e2+1
        lda ptrB+1
        adc #0
        sta _e2+2
        lda ptrB
        clc
        adc #68
        sta _e3+1
        lda ptrB+1
        adc #0
        sta _e3+2
        lda #C_PF
        ldx #C_ROW17
        bit Ladder
        bmi +
        lda #C_PFFG
        ldx #C_ROW17FG
+       sta tmp
        stx tmp2
        ldx #9                  ; columns 2-11
-       lda tmp
_e0     sta $ffff,x
        lda tmp2
_e1     sta $ffff,x
        dex
        bpl -
        ldx #11                 ; columns 28-39
-       lda tmp
_e2     sta $ffff,x
        lda tmp2
_e3     sta $ffff,x
        dex
        bpl -
        lda #C_CANOPY           ; the canopy's characters: the pattern's, from the cache
        jsr CharPtr
        ldx Trees
        lda CanLo,x
        sta ptrA
        lda CanHi,x
        sta ptrA+1
        ldx #0                  ; (eight parts of 76 bytes at once: their addresses into the copy)
        ldy #0
-       lda ptrA
        clc
        adc CanSegLo,x
        sta _cl+1,y
        lda ptrA+1
        adc CanSegHi,x
        sta _cl+2,y
        lda ptrC
        clc
        adc CanSegLo,x
        sta _cl+4,y
        lda ptrC+1
        adc CanSegHi,x
        sta _cl+5,y
        tya
        clc
        adc #6
        tay
        inx
        cpx #8
        bcc -
        ldx #75
_cl
        .rept 8
        lda $ffff,x
        sta $ffff,x
        .endrept
        dex
        bpl _cl
        rts
CanSegLo:   .byte <range(0, 608, 76)
CanSegHi:   .byte >range(0, 608, 76)

; InitCanopy: the canopy's 76 characters for each tree pattern, into the cache (CanopyChars,
; drawn in buffer 0's set and copied), and each pattern's four tree columns (TreeCols)
InitCanopy:
        lda #0
        sta rbuf
        jsr BufPtrs
        lda #3
        sta InitT
_t      lda InitT
        sta Trees               ; (the 2600's RAM, zero at start-up: put back below)
        jsr CanopyChars
        lda #C_CANOPY
        jsr CharPtr
        ldx InitT
        lda CanLo,x
        sta ptrA
        lda CanHi,x
        sta ptrA+1
        ldx #(76 * 8) >> 8
        ldy #0
-       lda (ptrC),y
        sta (ptrA),y
        iny
        bne -
        inc ptrA+1
        inc ptrC+1
        dex
        bne -
-       lda (ptrC),y
        sta (ptrA),y
        iny
        cpy #(76 * 8) & 255
        bcc -
        lda #0                  ; the tree columns: cells with the playfield on (PF1, PF2)
        sta PfR
        ldx InitT
        lda $fbce,x
        sta PfR+1
        lda $fbd2,x
        sta PfR+2
        lda InitT
        asl
        asl
        sta tmp2
        ldx #0
-       jsr CellOn
        bcc +
        txa
        ldy tmp2
        sta TreeCols,y
        inc tmp2
+       inx
        cpx #40
        bcc -
        dec InitT
        bpl _t
        lda #0
        sta Trees
        rts

; CellOn: X = a cell (0-39) -> C set if the playfield PfR has it on
CellOn:
        lda PfReg,x
        sty tmp3
        tay
        lda PfR,y
        ldy tmp3
        and PfMask,x
        beq +
        sec
        rts
+       clc
        rts

; CanopyChars: rows 6-7 (lines 89-104): the canopy's edge (lines 92-99: the tree pattern's four
; values, two lines each, in all three PF registers), the branches behind it (players 0 and 1,
; two copies 32 apart; in front from pixel 55 of line 99), line 100's PF0 left over for pixels
; 8-9, the trees below
CanopyChars:
        lda #89
        sta line
_ln     lda line                ; this line's playfield
        cmp #92
        bcs +
        lda #$ff                ; 89-91: all on
        sta PfR
        sta PfR+1
        sta PfR+2
        jmp _cells
+       cmp #100
        bcs +
        sec                     ; 92-99: the edge
        sbc #92
        lsr
        sta tmp
        lda Trees
        asl
        asl
        ora tmp
        tax
        lda $f3ef,x
        sta PfR
        sta PfR+1
        sta PfR+2
        jmp _cells
+       lda #0                  ; 100-104: the trees
        sta PfR
        ldx Trees
        lda $fbce,x
        sta PfR+1
        lda $fbd2,x
        sta PfR+2
_cells  lda line                ; the line's byte in each cell's character (columns 2-39)
        sec
        sbc #89
        sta lrow                ; (0-15: row 6's lines, then row 7's)
        ldx #2
_c      stx cell
        jsr CellOn
        lda #0
        bcc +
        lda #$55
+       pha
        lda cell
        jsr CanopyByte          ; ptrC -> the cell's byte for this line
        pla
        ldy #0
        sta (ptrC),y
        ldx cell
        inx
        cpx #40
        bcc _c
        lda line                ; line 100: pixels 8-9 still from line 98's PF0
        cmp #100
        bne _br
        lda Trees
        asl
        asl
        tax
        lda $f3ef+3,x
        and #$40                ; (PF0 bit 6: cell 2)
        beq _br
        lda #2
        jsr CanopyByte
        ldy #0
        lda (ptrC),y
        ora #$50                ; (pixels 0-1 of cell 2: "01")
        sta (ptrC),y
_br     lda line                ; the branches, lines 92-99
        cmp #92
        bcc _nl
        cmp #100
        bcs _nl
        lda #100
        sec
        sbc line
        tax
        lda $fbc5,x             ; (their shape on this line)
        sta v2
        ldx Trees
        jsr BranchPos
        lda BrX
        jsr _draw
        lda BrX
        clc
        adc #32
        jsr _draw
        lda BrX+1
        jsr _draw
        lda BrX+1
        clc
        adc #32
        jsr _draw
_nl     inc line
        lda line
        cmp #105
        bcs +
        jmp _ln
+       rts
; one copy of the branches at pixel A: "10" where its bits are, except behind the canopy
_draw   sta v3
        lda #8
        sta v4
        lda v2
        sta v5
-       asl v5
        bcc _skip
        lda v3
        cmp #160
        bcc +
        sbc #160
+       cmp #8
        bcc _skip
        sta tmp2                ; the pixel
        lsr
        lsr
        jsr CanopyByte
        lda tmp2
        and #3
        tax
        ldy #0
        lda (ptrC),y
        and McPix,x
        beq _set                ; (nothing there: the branch shows)
        lda line                ; the canopy there: in front up to line 98, and on 99 left of 55
        cmp #99
        bcc _skip
        lda tmp2
        cmp #55
        bcc _skip
_set    lda (ptrC),y
        ora McPix,x
        eor McPix01,x           ; ("11" -> "10")
        sta (ptrC),y
_skip   inc v3
        dec v4
        bne -
        rts

; CanopyByte: A = a cell (2-39), lrow = the line (0-15 from line 89) -> ptrC = its byte
CanopyByte:
        sec
        sbc #2
        ldx lrow
        cpx #8
        bcc +
        clc
        adc #38
+       clc
        adc #C_CANOPY
        jsr CharPtr
        lda lrow
        and #7
        clc
        adc ptrC
        sta ptrC
        bcc +
        inc ptrC+1
+       rts

; BranchPos: X = the tree pattern -> BrX, BrX+1: the branches' pixels (players 0 and 1 on line
; 67: RESP0 after a loop of the pattern's count, RESP1 after another; then a fine move each)
BranchPos:
        lda $fbd6,x
        and #15
        tay
        lda Mul15,y
        clc
        adc #<(36 - 68 + 5 + 8)
        sta tmp
        lda $fbd6,x
        lsr
        lsr
        lsr
        lsr
        tay
        lda tmp
        clc
        adc AddHM,y
        sec
        sbc #16
        jsr Mod160
        sta BrX
        lda $fbd6,x
        and #15
        tay
        lda Mul15,y
        sta tmp
        lda $fbda,x
        and #15
        tay
        lda Mul15,y
        clc
        adc tmp
        adc #93 - 68 + 5 + 8
        sta tmp
        lda $fbda,x
        lsr
        lsr
        lsr
        lsr
        tay
        lda tmp
        clc
        adc AddHM,y
        sec
        sbc #16
        jsr Mod160
        sta BrX+1
        rts

Mod160:
        cmp #160
        bcc +
        sbc #160
+       rts

; ----------------------------------------------------------------- digits
; ScoreChars: the score (lines 44-51), the lives and the clock (57-64), the logo (224-231):
; six digits at pixels 21 + 8i over the playfield ("10" over "01"). Each buffer keeps the six
; pointers (and the bits added to the first) it shows per row; only the cells of digits that
; changed are redrawn.
ScoreChars:
        lda ScorePtr
        cmp DigIn+0
        bne _chg
        lda ScorePtr+2
        cmp DigIn+1
        bne _chg
        lda ScorePtr+4
        cmp DigIn+2
        bne _chg
        lda ScorePtr+6
        cmp DigIn+3
        bne _chg
        lda ScorePtr+8
        cmp DigIn+4
        bne _chg
        lda ScorePtr+10
        cmp DigIn+5
        bne _chg
        lda DigitPtr
        cmp DigIn+6
        bne _chg
        lda DigitPtr+2
        cmp DigIn+7
        bne _chg
        lda DigitPtr+4
        cmp DigIn+8
        bne _chg
        lda DigitPtr+6
        cmp DigIn+9
        bne _chg
        lda DigitPtr+8
        cmp DigIn+10
        bne _chg
        lda DigitPtr+10
        cmp DigIn+11
        bne _chg
        lda ClockMin
        cmp DigIn+12
        bne _chg
        lda ClockSec
        cmp DigIn+13
        bne _chg
        lda Lives
        cmp DigIn+14
        bne _chg
        ldx rbuf                ; (the inputs as last time: if this buffer was drawn from them,
        lda DigVer              ; nothing to do)
        cmp DigBufVer,x
        bne _draw
        rts
_chg
        lda ScorePtr
        sta DigIn+0
        lda ScorePtr+2
        sta DigIn+1
        lda ScorePtr+4
        sta DigIn+2
        lda ScorePtr+6
        sta DigIn+3
        lda ScorePtr+8
        sta DigIn+4
        lda ScorePtr+10
        sta DigIn+5
        lda DigitPtr
        sta DigIn+6
        lda DigitPtr+2
        sta DigIn+7
        lda DigitPtr+4
        sta DigIn+8
        lda DigitPtr+6
        sta DigIn+9
        lda DigitPtr+8
        sta DigIn+10
        lda DigitPtr+10
        sta DigIn+11
        lda ClockMin
        sta DigIn+12
        lda ClockSec
        sta DigIn+13
        lda Lives
        sta DigIn+14
        inc DigVer
_draw   ldx rbuf
        lda DigVer
        sta DigBufVer,x
        ldx #10                 ; the score: the pointers the tick left (saved by Collide)
-       lda ScorePtr,x
        sta DigLo,x
        dex
        dex
        bpl -
        lda #0
        sta DigF8
        lda #0                  ; (row 0: lines 44-51)
        jsr DigitRow
        lda #$58                ; the lives (marks) and the clock: blank, minutes (a leading 0
        sta DigLo               ; blank), colon, seconds
        lda ClockMin
        lsr
        lsr
        lsr
        lsr
        asl
        asl
        asl
        bne +
        lda #$58
+       sta DigLo+2
        lda ClockMin
        and #15
        asl
        asl
        asl
        sta DigLo+4
        lda #$50
        sta DigLo+6
        lda ClockSec
        lsr
        lsr
        lsr
        lsr
        asl
        asl
        asl
        sta DigLo+8
        lda ClockSec
        and #15
        asl
        asl
        asl
        sta DigLo+10
        lda Lives
        sta DigF8
        lda #1                  ; (row 1: lines 57-64)
        jsr DigitRow
        ldx #10                 ; the logo: its pointers as the tick left them (Collide)
-       lda DigitPtr,x
        sta DigLo,x
        dex
        dex
        bpl -
        lda #0
        sta DigF8
        lda #2                  ; (row 2: lines 224-231)
        jmp DigitRow

; DigitRow: A = which of the three digit rows; DigLo / DigF8 = what it should show. Compared with
; what buffer rbuf shows there (DigKeys: 7 bytes per row and buffer), the digits that changed are
; redrawn.
DigitRow:
        sta v3
        tax                     ; (DigKeys: 7 * (NBUF * row + buffer))
        lda MulNBUF,x
        clc
        adc rbuf
        tax
        lda Mul7,x
        tax
        lda #0
        sta v4                  ; (the digits that changed: bit i)
        lda DigF8               ; the first digit's added bits
        cmp DigKeys+6,x
        beq +
        sta DigKeys+6,x
        lda #1
        sta v4
+
        .for i := 0, i < 6, i += 1
        lda DigLo + 2 * i
        cmp DigKeys + i,x
        beq +
        sta DigKeys + i,x
        lda v4
        ora #1 << i
        sta v4
+
        .next
        lda v4
        bne +
        rts
+       ldx #12                 ; the cells to draw: digit i's are 2i, 2i + 1, 2i + 2
-       lda #0
        sta DigCell,x
        dex
        bpl -
        ldx #0
-       lsr v4
        bcc +
        lda #1
        sta DigCell,x
        sta DigCell+1,x
        sta DigCell+2,x
+       inx
        inx
        cpx #12
        bcc -
        ldx v3                  ; the row's cell 0 (its first line's character row), the lines'
        lda DigOffLo,x          ; offsets from there (DigOff: the 8 lines, bottom first)
        sta _om8+1
        sta _os8+1
        lda DigOffHi,x
        sta _om8+2
        sta _os8+2
        lda DigCode,x
        jsr CharPtr
        lda #0
        sta v5                  ; cell 0-12
_cell   ldx v5
        lda DigCell,x
        bne +
        jmp _next
+       txa                     ; its address: cell 0's + 8 * cell
        asl
        asl
        asl
        clc
        adc ptrC
        sta _qm+1
        sta _qs+1
        lda ptrC+1
        adc #0
        sta _qm+2
        sta _qs+2
        txa
        lsr
        tay                     ; Y = the digit (odd cells: its middle; even: shared with the one
        bcc _shared             ; before)
        jsr _dig                ; (its bytes: _pm, the first digit's added bits)
        sta _pm+1
        stx _pm+2
        sty _om+1
        ldx #7                  ; (the digit's bytes from the bottom)
_m
_pm     lda $ff00,x
_om     ora #0
        tay
        lda DigMid,y
_om8    ldy $ffff,x
_qm     sta $ffff,y
        dex
        bpl _m
        jmp _next
_shared jsr _dig                ; this digit (none past the last)
        sta _ps+1
        stx _ps+2
        sty _os+1
        ldy v5
        dey
        dey
        tya
        bmi +
        lsr
        tay
        jsr _dig                ; the one before (none before the first)
        jmp ++
+       lda #<DigZero
        ldx #>DigZero
        ldy #0
+       sta _pp+1
        stx _pp+2
        sty _op+1
        ldx #7
_s
_pp     lda $ff00,x
_op     ora #0
        lsr
_ps     lda $ff00,x
_os     ora #0
        tay
        bcc +
        lda DigShB,y
        bcs ++
+       lda DigShA,y
+
_os8    ldy $ffff,x
_qs     sta $ffff,y
        dex
        bpl _s
_next   inc v5
        lda v5
        cmp #13
        bcs +
        jmp _cell
+       rts
; Y = a digit (0-5; 6: none) -> A / X = its bytes' address, Y = the bits added (DigF8, digit 0's)
_dig    cpy #6
        bcs _none
        tya
        asl
        tax
        lda #0
        cpy #0
        bne +
        lda DigF8
+       tay
        lda DigLo,x
        ldx #$ff
        rts
_none   lda #<DigZero
        ldx #>DigZero
        ldy #0
        rts

; ----------------------------------------------------------------- ground
; GroundChars: rows 14-17 columns 12-27 (lines 153-184: the pits, the hole) and rows 18-21
; columns 19-20 (185-216: the ladder), when the pits' values, the hole or the ladder change
GroundChars:
        ldx rbuf                ; the pits (lines 153-168)
        ldy #0
        sty v4
        txa
        asl
        asl
        asl
        tax                     ; (8 per buffer)
-       lda PitPF,y
        cmp PitVals,x
        beq +
        sta PitVals,x
        inc v4
+       inx
        iny
        cpy #7
        bcc -
        lda HolePF
        cmp PitVals,x
        beq +
        sta PitVals,x
        inc v4
+       ldx rbuf
        lda PitDirty,x
        ora v4
        beq +
        lda #0
        sta PitDirty,x
        jsr PitLines
+       ldx rbuf                ; the earth's hole and the ladder (lines 169-216)
        lda HoleDirty,x
        bne _hole
        lda HolePF
        cmp HoleKey,x
        bne _hole
        lda Ladder
        and #$80
        cmp HoleLad,x
        beq +
_hole   lda HolePF
        sta HoleKey,x
        lda Ladder
        and #$80
        sta HoleLad,x
        lda #0
        sta HoleDirty,x
        jsr HoleLines
+       rts

; PitLines: lines 153-168: PF2 per line (columns 12-19, mirrored in 20-27): 153-159 PitPF+6..0,
; 160 PitPF+0, 161-166 +1..6, 167 +6, 168 HolePF
PitLines:
        lda #$ff                ; (GLine: no row, no bytes yet)
        sta GRow
        sta GKey+1
        lda #153
        sta line
-       lda line
        cmp #160
        bcs +
        lda #159
        sec
        sbc line
        jmp _v
+       cmp #167
        bcs +
        sec
        sbc #160
        jmp _v
+       bne +
        lda #6
_v      tax
        lda PitPF,x
        jmp _w
+       lda HolePF              ; (168: the second class, "10": EvEarth)
        ldx #$aa
        bne _g
_w      ldx #$55
_g      jsr GLine
        inc line
        lda line
        cmp #169
        bcc -
        rts

; HoleLines: lines 169-216: the earth (PF2 = HolePF, its class) with the hole, the ladder (the
; ball at pixels 78-81 on its rungs' lines, ladder rooms only), the tunnel, the floor
HoleLines:
        lda #$ff                ; (GLine: no row, no bytes yet)
        sta GRow
        sta GKey+1
        lda #169
        sta line
-       lda line
        cmp #183
        bcs +
        lda HolePF
        ldx #$55
        bit Ladder
        bmi _w
        ldx #$aa
        bne _w
+       cmp #185
        bcs _lad
        lda #0                  ; 183-184: the tunnel (rows 17's last lines)
        ldx #$55
_w      jsr GLine
        inc line
        bne -                   ; (always)
_lad    lda #C_LADDER           ; 185-216 (rows 18-21, columns 19-20): the ladder's characters,
        jsr CharPtr             ; with or without it, from the copies built at start-up
        ldy #63
        bit Ladder
        bmi +
-       lda LadderOff,y
        sta (ptrC),y
        dey
        bpl -
        rts
+
-       lda LadderOn,y
        sta (ptrC),y
        dey
        bpl -
        rts

; InitLadder: the ladder's characters with the ladder (LadderOn) and without (LadderOff)
InitLadder:
        lda #0
        sta rbuf
        jsr BufPtrs
        lda #$ff
        sta Ladder              ; (the 2600's RAM, zero at start-up: put back below)
        jsr _lines
        ldy #63
-       lda (ptrC),y
        sta LadderOn,y
        dey
        bpl -
        lda #0
        sta Ladder
        jsr _lines
        ldy #63
-       lda (ptrC),y
        sta LadderOff,y
        dey
        bpl -
        rts
_lines  lda #185
        sta line
-       jsr LadderLine
        inc line
        lda line
        cmp #217
        bcc -
        lda #C_LADDER
        jmp CharPtr

; GLine: A = PF2, X = the class ($55 / $AA), line = 153..184 -> that line's byte in the 16 cells
; of columns 12-27 (PF2 bits 0-7 in 12-19, mirrored in 27-20), the ladder's ball added in columns
; 19-20 (decimal mode off). The cells' addresses are set when the character row changes (GRow),
; their bytes worked out when PF2, the class or the ball change (GKey: callers set GRow and GKey+1
; to $FF first).
GLine:
        sta v2
        stx v3
        lda line                ; its character row, its line in it
        sec
        sbc #41
        tax
        and #7
        sta lrow
        txa
        lsr
        lsr
        lsr
        cmp GRow
        beq +
        jsr GAddr
+       lda #0                  ; the ball (ladder rooms, its rungs' lines)
        sta v4
        bit Ladder
        bpl +
        jsr Rung
        bcc +
        inc v4
+       lda v2                  ; the cells' bytes, if PF2, the class or the ball changed
        cmp GKey
        bne _new
        lda v3
        cmp GKey+1
        bne _new
        lda v4
        cmp GKey+2
        bne _new
        jmp _put
_new    lda v2
        sta GKey
        lda v3
        sta GKey+1
        lda v4
        sta GKey+2
        ldx lrow                ; bit i: the class where on (carry set: 0 + $FF + 1 = 0, eor ->
                                ; $FF; clear: $FF, eor -> 0), stored as worked out (and kept)
        lsr v2
        lda #0
        adc #$ff
        eor #$ff
        and v3
        sta GT+0
_k0     sta $ff00,x
_k15    sta $ff00,x
        lsr v2
        lda #0
        adc #$ff
        eor #$ff
        and v3
        sta GT+1
_k1     sta $ff00,x
_k14    sta $ff00,x
        lsr v2
        lda #0
        adc #$ff
        eor #$ff
        and v3
        sta GT+2
_k2     sta $ff00,x
_k13    sta $ff00,x
        lsr v2
        lda #0
        adc #$ff
        eor #$ff
        and v3
        sta GT+3
_k3     sta $ff00,x
_k12    sta $ff00,x
        lsr v2
        lda #0
        adc #$ff
        eor #$ff
        and v3
        sta GT+4
_k4     sta $ff00,x
_k11    sta $ff00,x
        lsr v2
        lda #0
        adc #$ff
        eor #$ff
        and v3
        sta GT+5
_k5     sta $ff00,x
_k10    sta $ff00,x
        lsr v2
        lda #0
        adc #$ff
        eor #$ff
        and v3
        sta GT+6
_k6     sta $ff00,x
_k9     sta $ff00,x
        lsr v2
        lda #0
        adc #$ff
        eor #$ff
        and v3
        sta GT+7
        sta GT+8
        ldy v4                  ; (the ball: cells 7, 8)
        beq +
        ora #$05
        sta GT+7
        lda GT+8
        ora #$50
        sta GT+8
        lda GT+7
+
_k7     sta $ff00,x
        lda GT+8
_k8     sta $ff00,x
        rts
_put    ldx lrow
        lda GT+0
_c0     sta $ff00,x
_c15    sta $ff00,x
        lda GT+1
_c1     sta $ff00,x
_c14    sta $ff00,x
        lda GT+2
_c2     sta $ff00,x
_c13    sta $ff00,x
        lda GT+3
_c3     sta $ff00,x
_c12    sta $ff00,x
        lda GT+4
_c4     sta $ff00,x
_c11    sta $ff00,x
        lda GT+5
_c5     sta $ff00,x
_c10    sta $ff00,x
        lda GT+6
_c6     sta $ff00,x
_c9     sta $ff00,x
        lda GT+7
_c7     sta $ff00,x
        lda GT+8
_c8     sta $ff00,x
        rts

; GAddr: A = a character row (14-17) -> GLine's stores set to its 16 cells
GAddr:
        sta GRow
        sec                     ; the row's 16 cells: one high byte (128-byte aligned)
        sbc #14
        asl
        asl
        asl
        asl
        clc
        adc #C_GROUND
        jsr CharPtr
        lda ptrC+1
        sta GLine._c0+2
        sta GLine._k0+2
        sta GLine._c1+2
        sta GLine._k1+2
        sta GLine._c2+2
        sta GLine._k2+2
        sta GLine._c3+2
        sta GLine._k3+2
        sta GLine._c4+2
        sta GLine._k4+2
        sta GLine._c5+2
        sta GLine._k5+2
        sta GLine._c6+2
        sta GLine._k6+2
        sta GLine._c7+2
        sta GLine._k7+2
        sta GLine._c8+2
        sta GLine._k8+2
        sta GLine._c9+2
        sta GLine._k9+2
        sta GLine._c10+2
        sta GLine._k10+2
        sta GLine._c11+2
        sta GLine._k11+2
        sta GLine._c12+2
        sta GLine._k12+2
        sta GLine._c13+2
        sta GLine._k13+2
        sta GLine._c14+2
        sta GLine._k14+2
        sta GLine._c15+2
        sta GLine._k15+2
        lda ptrC
        clc
        sta GLine._c0+1
        sta GLine._k0+1
        adc #8
        sta GLine._c1+1
        sta GLine._k1+1
        adc #8
        sta GLine._c2+1
        sta GLine._k2+1
        adc #8
        sta GLine._c3+1
        sta GLine._k3+1
        adc #8
        sta GLine._c4+1
        sta GLine._k4+1
        adc #8
        sta GLine._c5+1
        sta GLine._k5+1
        adc #8
        sta GLine._c6+1
        sta GLine._k6+1
        adc #8
        sta GLine._c7+1
        sta GLine._k7+1
        adc #8
        sta GLine._c8+1
        sta GLine._k8+1
        adc #8
        sta GLine._c9+1
        sta GLine._k9+1
        adc #8
        sta GLine._c10+1
        sta GLine._k10+1
        adc #8
        sta GLine._c11+1
        sta GLine._k11+1
        adc #8
        sta GLine._c12+1
        sta GLine._k12+1
        adc #8
        sta GLine._c13+1
        sta GLine._k13+1
        adc #8
        sta GLine._c14+1
        sta GLine._k14+1
        adc #8
        sta GLine._c15+1
        sta GLine._k15+1
        rts

; BallBits: the ladder's ball on line `line` -> BallL (cell 19's bits), BallR (cell 20's)
; (pixels 78-81, "01"; nothing where there is no ladder)
BallBits:
        lda #0
        sta BallL
        sta BallR
        bit Ladder
        bpl _r
        jsr Rung
        bcc _r
        lda #$05
        sta BallL
        lda #$50
        sta BallR
_r      rts

; Rung: the ball (the ladder) on line `line`? -> C. 171-182: $FC95+(182 - L); 183 on;
; 184-198: $FC95+(198 - L); 199-214: $FC95+(214 - L); otherwise off
Rung:
        lda line
        cmp #171
        bcc _off
        cmp #183
        bcc _a
        beq _on
        cmp #199
        bcc _b
        cmp #215
        bcs _off
        lda #214
        bne _t
_b      lda #198
        bne _t
_a      lda #182
_t      sec
        sbc line
        tax
        lda $fc95,x
        and #2
        beq _off
_on     sec
        rts
_off    clc
        rts

; LadderLine: line 185-216 -> the bytes of rows 18-21's columns 19-20: the tunnel's background
; or the floor (215-216), the ball
LadderLine:
        lda line
        sec
        sbc #41
        tax
        and #7
        sta lrow
        txa
        lsr
        lsr
        lsr
        sec
        sbc #18
        asl
        clc
        adc #C_LADDER
        jsr CharPtr
        lda ptrC
        clc
        adc lrow
        sta ptrC
        bcc +
        inc ptrC+1
+       lda line
        cmp #215
        bcc +
        lda #$55                ; the floor
        ldy #0
        sta (ptrC),y
        ldy #8
        sta (ptrC),y
        rts
+       jsr BallBits
        ldy #0
        lda BallL
        sta (ptrC),y
        ldy #8
        lda BallR
        sta (ptrC),y
        rts

; ------------------------------------------------------------------- vine
; VineSprites: the vine (the ball, lines 92 to VineEnd - 1, at most VINELAST) as sprites 5-7:
; A lines 92-112, B 113-133, C 134-141 (placed at 121, its upper rows blank). Two sets of blocks
; (buffer 0's and 1's 10-12) hold vines, each with its key (slope, direction, length, trees): a
; buffer uses the set already holding this frame's vine if there is one (the slope often stays
; the same from frame to frame), else the set the buffer shown doesn't use is drawn anew.
VineSprites:
        ldx rbuf
        lda StEn,x              ; (sprites 5-7 off unless drawn)
        and #$1f
        sta StEn,x
        lda StMsb,x
        and #$1f
        sta StMsb,x
        lda VineEnd
        bne +
        rts
+       cmp #VINELAST + 1
        bcc +
        inc DbgVineCut          ; (the vine longer than the sprites reach: never in play)
        lda #VINELAST + 1
+       sta VEnd
        sta VKey+2
        lda VineSlope
        sta VKey
        lda VineStep
        sta VKey+1
        lda Trees
        sta VKey+3
        ldx #NBUF - 1           ; a set already holding this vine
-       jsr SetMatch
        bcs _use
        dex
        bpl -
        lda #VnSet - SetOf      ; none: draw one the buffers shown and waiting don't use
        jsr FreeSet
        stx VnT
        jsr VineDraw
        ldx VnT
_use    txa                     ; buffer rbuf uses set X: its sprites' registers
        ldy rbuf
        sta VnSet,y
        sta tmp2
        lda #0
        sta v4
_reg    ldx tmp2
        lda SetEn,x
        ldy v4
        and Bit+5,y
        beq _rn
        lda rbuf                ; X, Y, colour
        asl
        asl
        asl
        clc
        adc #5
        adc v4
        tay
        lda Mul3,x
        clc
        adc v4
        tax
        lda SetX,x
        sta StX,y
        ldx v4
        lda VnY,x
        sta StY,y
        lda ColTrees            ; (A: the canopy's colour, the trees' from line 100)
        cpx #0
        bne +
        lda ColCanopy
+       lsr
        tax
        lda ColorMap,x
        sta StCol,y
        ldx tmp2                ; its pointer (VnPtr by buffer + 2 * sprite)
        lda MulNB,x
        clc
        adc #BLK_SET + 10
        adc v4
        pha
        lda rbuf
        ldy v4
        clc
        adc MulNBUF,y
        tay
        pla
        sta VnPtr,y
_rn     inc v4
        lda v4
        cmp #3
        bcc _reg
        ldx tmp2                ; enable and MSB bits
        ldy rbuf
        lda SetEn,x
        ora StEn,y
        sta StEn,y
        lda SetMsb,x
        ora StMsb,y
        sta StMsb,y
        rts

; SetMatch: X = a set -> C set if it holds the vine VKey describes (X kept)
SetMatch:
        lda SetValid,x
        beq _no
        txa
        asl
        asl
        tay
        lda SetKey,y
        cmp VKey
        bne _no
        lda SetKey+1,y
        cmp VKey+1
        bne _no
        lda SetKey+2,y
        cmp VKey+2
        bne _no
        lda SetKey+3,y
        cmp VKey+3
        bne _no
        sec
        rts
_no     clc
        rts

; VineDraw: the vine into set VnT: x = 78 + step * floor((L - 68) * slope / 256), stepped on line
; by line (kept as x + 8). A sprite's X: its first line's x (leaning right), or 20 pixels left of
; it (leaning left: 21 lines move it at most 20). Each line writes its whole sprite row (3 bytes);
; pixels in the HMOVE blank or past 159, and on line 99 those from pixel 55 behind a branch (in
; front there), are left out (a sprite whose pixels all show: a faster loop, the pixel's place in
; the row stepped). Rows below the last drawn that the set held before are cleared.
VineDraw:
        lda VineSlope           ; (the fast loop: the slope, the step)
        sta _sl+1
        lda #$e8                ; inx
        ldx VineStep
        bpl +
        lda #$ca                ; dex
+       sta _st
        ldx VnT                 ; the key, the set's registers so far
        txa
        asl
        asl
        tay
        lda VKey
        sta SetKey,y
        lda VKey+1
        sta SetKey+1,y
        lda VKey+2
        sta SetKey+2,y
        lda VKey+3
        sta SetKey+3,y
        lda #1
        sta SetValid,x
        lda #0
        sta SetEn,x
        sta SetMsb,x
        ldy #2                  ; (rows drawn this time: none yet)
-       lda VnStartOfs,y
        sta VnNew,y
        dey
        bpl -
        lda MulNB,x             ; the set's three blocks
        clc
        adc #11
        jsr BlkPtr
        lda #91 - 68            ; on line 91: 23 steps (lines 69-91) done
        ldx VineSlope
        jsr Mul8
        sta tmp
        lda MulLo
        sta vacc
        lda #78 + 8
        ldx VineStep
        bmi +
        clc
        adc tmp
        jmp ++
+       sec
        sbc tmp
+       sta vx8
        lda #0
        sta v4                  ; sprite 0-2 (5-7)
_spr    ldx v4
        lda VnFrom,x            ; its lines: line .. v1 - 1
        clc
        adc #92
        sta line
        lda VnTo,x
        clc
        adc #92
        cmp VEnd
        bcc +
        lda VEnd
+       sta v1
        cmp line
        beq +
        bcs ++
+       jmp _off                ; (nothing on its lines: off)
+       lda Mul64,x             ; its first row: (line - its row 0's line) * 3
        sta tmp
        lda line
        sec
        sbc VnRow0L,x
        tay
        lda Mul3,y
        clc
        adc tmp
        tay
        lda vacc                ; X: from this first line's x
        clc
        adc VineSlope
        lda vx8
        bcc +
        adc VineStep            ; (carry set: + step + 1 - 1 below)
        sec
        sbc #1
+       ldx VineStep
        bpl +
        sec
        sbc #20
        bcs +
        lda #0
+       sta v3
        lda vx8                 ; all its pixels shown (x + 8 16-167 over the 21 lines)? fast
        ldx VineStep
        bmi _fl
        cmp #8 + 8
        bcc _ln
        adc #21                 ; (+ 22)
        cmp #160 + 8
        bcc _fast
        bcs _ln
_fl     cmp #160 + 8
        bcs _ln
        sbc #21                 ; (- 22)
        bcc _ln
        cmp #8 + 8
        bcs _fast
_ln     lda vacc                ; this line's step
        clc
        adc VineSlope
        sta vacc
        bcc +
        lda vx8
        clc
        adc VineStep
        sta vx8
+       lda vx8                 ; shown? (8-159)
        cmp #8 + 8
        bcc _blank
        cmp #160 + 8
        bcs _blank
        sec                     ; its row: the pixel x - the sprite's X
        sbc v3
        tax
        lda PosB0,x
        sta (ptrA),y
        iny
        lda PosB1,x
        sta (ptrA),y
        iny
        lda PosB2,x
        sta (ptrA),y
        iny
        jmp _nx
_blank  lda #0
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
_nx     inc line
        lda line
        cmp v1
        bcc _ln
        jmp _done
_fast   lda v1                  ; the fast loop: Y up to its rows' end, X the pixel - the sprite's X
        sec
        sbc line
        sta tmp
        asl
        adc tmp
        sta tmp
        tya
        clc
        adc tmp
        sta _cy+1
        lda vx8
        sec
        sbc v3
        tax
_f      lda vacc
        clc
_sl     adc #0
        sta vacc
        bcc +
_st     inx
+       lda PosB0,x
        sta (ptrA),y
        iny
        lda PosB1,x
        sta (ptrA),y
        iny
        lda PosB2,x
        sta (ptrA),y
        iny
_cy     cpy #0
        bcc _f
        txa                     ; (the last line's x + 8)
        clc
        adc v3
        sta vx8
_done   tya                     ; (the end of this sprite's rows, in its block)
        ldx v4
        sec
        sbc Mul64,x
        sta VnNew,x
        ldx v4                  ; line 99 (sprite A): a branch in front of the vine from pixel 55?
        bne _regs
        lda v1
        cmp #100
        bcc _regs
        jsr Vine99
_regs   ldx VnT                 ; the set's registers: X, MSB, enable
        lda Mul3,x
        clc
        adc v4
        tay
        lda v3                  ; X = 24 + 2 x = 2 (x + 8) + 8
        asl
        php
        clc
        adc #8
        sta SetX,y
        lda #0
        rol
        plp
        adc #0
        ldy v4
        cmp #0
        beq +
        lda Bit+5,y
        ora SetMsb,x
        sta SetMsb,x
+       lda Bit+5,y
        ora SetEn,x
        sta SetEn,x
_off    inc v4
        lda v4
        cmp #3
        bcs _clear
        jmp _spr
; rows the set held before past this time's end: cleared (each sprite)
_clear  ldx VnT
        lda MulNB,x
        clc
        adc #11
        jsr BlkPtr
        lda #0
        sta v4
_c      ldx v4
        lda Mul64,x
        sta tmp
        lda VnT
        asl
        adc VnT                 ; (3 * set + sprite)
        adc v4
        tay
        lda VnEnd,y             ; last time's end
        pha
        lda VnNew,x
        sta VnEnd,y
        clc
        adc tmp
        tay                     ; from this time's end
        pla
        clc
        adc tmp
        sta tmp2                ; to last time's
        lda #0
-       cpy tmp2
        bcs +
        sta (ptrA),y
        iny
        bne -
+       inc v4
        lda v4
        cmp #3
        bcc _c
        rts

; Vine99: line 99's row in sprite A (row 7): its pixel removed if a branch (players 0 and 1, two
; copies 32 apart, their shape $7E there) has a pixel there from pixel 55 on
Vine99:
        lda #99 - 68            ; the vine's x + 8 on line 99
        ldx VineSlope
        jsr Mul8
        sta tmp
        lda #78 + 8
        ldx VineStep
        bmi +
        clc
        adc tmp
        jmp ++
+       sec
        sbc tmp
+       cmp #55 + 8
        bcc _r
        cmp #160 + 8
        bcs _r
        sec
        sbc #8
        sta tmp2
        ldx Trees
        jsr BranchPos
        lda BrX
        sta BrX4
        clc
        adc #32
        jsr Mod160
        sta BrX4+1
        lda BrX+1
        sta BrX4+2
        clc
        adc #32
        jsr Mod160
        sta BrX4+3
        ldx #3
-       lda tmp2
        sec
        sbc BrX4,x
        bcs +
        adc #160
+       cmp #8
        bcs _n
        tay
        lda Bit7,y
        and #$7e
        bne _y
_n      dex
        bpl -
_r      rts
_y      lda #0                  ; (row 7 of sprite A)
        ldy #7 * 3
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        sta (ptrA),y
        rts

; ---------------------------------------------------------------- colours
; Colours: the register values for the frame (C64 colours from the game's, already masked)
Colours:
        lda ColSky
        cmp ColIn+0
        bne _chg
        lda ColCanopy
        cmp ColIn+1
        bne _chg
        lda ColScore
        cmp ColIn+2
        bne _chg
        lda ColTrees
        cmp ColIn+3
        bne _chg
        lda ColGround
        cmp ColIn+4
        bne _chg
        lda ColPit
        cmp ColIn+5
        bne _chg
        lda ColEarth
        cmp ColIn+6
        bne _chg
        lda ColBlack
        cmp ColIn+7
        bne _chg
        ldx rbuf                ; (the colours as last time: if this buffer has them, nothing to
        lda ColVer              ; do)
        cmp ColBufVer,x
        bne _draw
        rts
_chg
        lda ColSky
        sta ColIn+0
        lda ColCanopy
        sta ColIn+1
        lda ColScore
        sta ColIn+2
        lda ColTrees
        sta ColIn+3
        lda ColGround
        sta ColIn+4
        lda ColPit
        sta ColIn+5
        lda ColEarth
        sta ColIn+6
        lda ColBlack
        sta ColIn+7
        inc ColVer
_draw   ldx rbuf
        lda ColVer
        sta ColBufVer,x
        lda ColSky
        jsr Map
        sta StBg,x
        lda ColCanopy
        jsr Map
        sta StPf,x
        lda ColScore
        jsr Map
        sta StDig,x
        lda ColTrees
        jsr Map
        sta StBranch,x
        sta StTrees,x
        lda ColGround
        jsr Map
        sta StGround,x
        lda ColPit
        jsr Map
        sta StPit,x
        lda ColEarth
        jsr Map
        sta StEarth,x
        lda ColBlack
        jsr Map
        sta StTunBg,x
        sta StBlack,x
        rts

; A = a 2600 colour -> the C64's (X kept)
Map:
        lsr
        tay
        lda ColorMap,y
        rts

; ---------------------------------------------------------------- sprites
; FreeSet: A = the kind's table in SetOf -> X = a set the buffers shown and waiting don't use
FreeSet:
        sta tmp
        ldy #$ff
        lda ShowB
        clc
        adc tmp
        tax
        lda SetOf,x
        sta FsA
        lda WaitB
        bmi +
        clc
        adc tmp
        tax
        ldy SetOf,x
+       sty FsB
        ldx #NBUF - 1
-       cpx FsA
        beq _n
        cpx FsB
        bne _r
_n      dex
        bpl -
        ldx #0                  ; (none: can't happen)
_r      rts

; HarrySprites: Harry's lines (HPat / HCol from Collide, in its two ranges) in runs of one
; colour, at most 21 lines each, one sprite per run (0-4). His blocks are a pool of NBUF sets
; (HSet), each remembering the key it was drawn for (HKeyB*), its registers (HSY, HSC, HSEn)
; and its lines (HS*, and where each is drawn, HSDst): a set drawn for this key is used as it is;
; else a free one is patched and moved (lines of the same colours, blank or not as before, maybe
; up or down: only the patterns that differ written) or rebuilt. The buffer gets the set's
; registers and pointers, X.
HarrySprites:
        lda hx                  ; X: the same for all
        asl
        sta HXLo
        lda #0
        rol
        sta tmp
        lda HXLo
        clc
        adc #24
        sta HXLo
        lda tmp
        adc #0
        sta HXHi
        ldx #NBUF - 1           ; a set drawn for this key (Y first: the most likely to differ)
_find   stx HSet
        jsr HKPtr
        ldy #0
        lda HKey
        cmp (ptrB),y
        bne +
        ldy #11
-       lda HKey,y
        cmp (ptrB),y
        bne +
        dey
        bne -
        jmp _use
+       ldx HSet
        dex
        bpl _find
        lda #HSetOf - SetOf     ; none: a free one
        jsr FreeSet
        stx HSet
        jsr HarrySame           ; the same lines but for patterns, maybe moved up or down?
        bcs +
        jmp _rebuild
+       jsr HKSave
        ldx HSet                ; (patched) Y moved
        lda HSN1,x
        beq +
        lda UpLo
        sec
        sbc HSUpLo,x
        jmp ++
+       lda LwLo
        sec
        sbc HSLwLo,x
+       sta tmp2                ; (the lines moved)
        lda UpLo
        sta HSUpLo,x
        lda LwLo
        sta HSLwLo,x
        lda HSEn,x
        sta tmp3
        ldy Mul5,x
-       lsr tmp3
        bcc +
        lda HSY,y
        clc
        adc tmp2
        sta HSY,y
+       iny
        lda tmp3
        bne -
        ldx HSet
        inc HSVer,x
_use    ldx rbuf                ; the buffer: the set's registers and pointers (unless it has
        ldy HSet                ; them: the same set, as it was), X
        lda HSEn,y
        sta StEn,x
        lda HXHi
        beq +
        lda HSEn,y
+       sta StMsb,x
        txa
        asl
        asl
        asl
        sta tmp
        lda HSVer,y
        cmp HBVer,x
        bne _regs
        tya
        cmp HSetOf,x
        bne _regs
        ldx tmp                 ; (X only)
        lda HXLo
        ldy #NHARRY
-       sta StX,x
        inx
        dey
        bne -
        rts
_regs   lda HSVer,y
        sta HBVer,x
        tya
        sta HSetOf,x
        tax
        lda Mul5,x
        sta tmp2
        lda MulNB,x
        clc
        adc #BLK_SET
        sta tmp3
        lda #<(SCREEN + $3f8)   ; (the sprite pointers, in this buffer's screen)
        sta ptrD
        lda scr+1
        clc
        adc #3
        sta ptrD+1
        ldy #0
-       ldx tmp2
        lda HSY,x
        pha
        lda HSC,x
        ldx tmp
        sta StCol,x
        pla
        sta StY,x
        lda HXLo
        sta StX,x
        lda tmp3
        sta (ptrD),y
        inc tmp
        inc tmp2
        inc tmp3
        iny
        cpy #NHARRY
        bcc -
        rts
_rebuild
        jsr HKSave
        ldx HSet                ; what the blocks will hold (for HarrySame): where the parts start,
        lda UpLo                ; their lengths, the gap; the lines are saved as they are drawn
        sta HSUpLo,x
        lda LwLo
        sta HSLwLo,x
        lda UpHi
        sec
        sbc UpLo
        sta HSN1,x
        lda LwHi
        sec
        sbc LwLo
        sta HSN2,x
        lda LwLo
        sec
        sbc UpLo
        sta HSGap,x
        jsr HSPtrs              ; (the lines' copies: into the stores below)
        lda ptrB
        sta _sp+1
        lda ptrB+1
        sta _sp+2
        lda ptrC
        sta _sc+1
        lda ptrC+1
        sta _sc+2
        ldy HSet                ; (where each line is drawn: HSDst, the saved line's index - 1)
        lda HSDLo,y
        sec
        sbc #1
        sta _dl+1
        lda HSDLo+NBUF,y
        sbc #0
        sta _dl+2
        lda HSDHi,y
        sec
        sbc #1
        sta _dh+1
        lda HSDHi+NBUF,y
        sbc #0
        sta _dh+2
        lda #0
        sta HSi
        sta HEnBits
        lda #$ff                ; the runs
        sta v4                  ; (the sprite being filled: none yet)
        sta RunRaw              ; (no 2600 colour is odd)
        ldx UpLo
        ldy UpHi
        jsr _range
        ldx LwLo
        ldy LwHi
        jsr _range
        jsr _close
        inc v4                  ; sprites not used this time: their rows cleared
-       lda v4
        cmp #NHARRY
        bcs +
        lda #0
        sta LastRow
        jsr _clear
        inc v4
        jmp -
+       ldx HSet
        lda HEnBits
        sta HSEn,x
        inc HSVer,x
        jmp _use

; lines X .. Y - 1 (each saved for HarrySame as it goes)
_range  sty RangeHi
_ln     cpx RangeHi
        bcc +
        rts
+       ldy HSi
        lda HCol,x
_sc     sta $ffff,y
        lda HPat,x
_sp     sta $ffff,y
        iny
        sty HSi
        tay                     ; (blank: nothing to draw)
        bne +
        inx
        bne _ln                 ; (always)
+       sta v1
        stx v0
        lda HCol,x              ; the same colour as the run's (the 2600's colour as its last
        cmp RunRaw              ; line's: the same; else the C64's compared) and within 21 lines
        beq _same               ; of its start: on in the same sprite
        sta RunRaw
        lsr
        tay
        lda ColorMap,y
        sta v2
        ldy v4
        bmi _new
        cmp RunCol
        bne _new
_same   txa
        sec
        sbc RunStart
        cmp #21
        bcs _new
        tax                     ; row X: the rows between the last and this one blank
        ldy LastRow
        stx LastRow
        iny
        sty tmp
        cpx tmp
        bne +
        jmp _put
+       lda #0
-       ldy tmp
        lda Mul3,y
        tay
        lda #0
        sta (ptrA),y
        inc tmp
        cpx tmp
        bne -
        jmp _put
_new    lda HCol,x              ; (a new run: its colour)
        sta RunRaw
        lsr
        tay
        lda ColorMap,y
        sta v2
        jsr _close
        inc v4
        lda v4
        cmp #NHARRY
        bcc +
        inc DbgHarryOver        ; (more runs than sprites: the rest not drawn)
        ldx RangeHi
        rts
+       lda v0                  ; its sprite from this line, or line 199 at most (no sprite
        cmp #199 - 106          ; fetches past line 219: EvFloor; rows above the line blank)
        bcc +
        lda #199 - 106
+       sta RunStart
        lda v2
        sta RunCol
        ldx HSet                ; its registers: colour, Y
        lda Mul5,x
        clc
        adc v4
        tax
        lda v2
        sta HSC,x
        lda RunStart
        clc
        adc #106 + SPRYOFS
        sta HSY,x
        ldx v4
        lda Bit,x
        ora HEnBits
        sta HEnBits
        lda v4                  ; its block
        jsr HarryBlk
        lda v0                  ; this line's row (the rows above it cleared)
        sec
        sbc RunStart
        sta LastRow
        tax
        beq _put
        lda #0
-       dex
        ldy Mul3,x
        sta (ptrA),y
        cpx #0
        bne -
        ldx LastRow
_put    lda Mul3,x              ; row X: this line's pixels
        tay
        lda v1
        sta (ptrA),y
        tya                     ; (where: HSDst)
        clc
        adc ptrA
        ldx HSi
_dl     sta $ffff,x
        lda ptrA+1
        adc #0
_dh     sta $ffff,x
        ldx v0
        inx
        jmp _ln
; the run being filled: its rows past the last used before cleared; HUsed
_close  ldy v4
        bmi +
        cpy #NHARRY
        bcs +
        inc LastRow             ; (rows used: the last + 1)
; sprite v4's rows from LastRow to those it used before: cleared; HUsed = LastRow
_clear  ldx HSet
        lda Mul5,x
        clc
        adc v4
        tax
        lda HUsed,x
        sta tmp
        lda LastRow
        sta HUsed,x
        cmp tmp
        bcs +                   ; (no more rows than now)
        lda v4
        jsr HarryBlk
        ldx LastRow
        lda #0
-       ldy Mul3,x
        sta (ptrA),y
        inx
        cpx tmp
        bcc -
+       rts

; HarrySame: C set if set HSet's blocks can hold Harry's lines, maybe moved up or down: the same
; lengths and gap between the parts above and below the ground; the lines drawn in both the same
; colour; a line drawn now but blank before inside one of the set's runs (its colour, within 21
; rows of its start). What differs is written: in the blocks (where HSDst says, or the run's
; row), and the set's copy. C clear: they can't (the set to be rebuilt: maybe partly written).
HarrySame:
        ldx HSet
        lda UpHi
        sec
        sbc UpLo
        sta HSa
        cmp HSN1,x
        beq +
        clc
        rts
+       lda LwHi
        sec
        sbc LwLo
        sta HSb
        cmp HSN2,x
        bne _no
        lda HSa
        beq +
        lda HSb
        beq +
        lda LwLo
        sec
        sbc UpLo
        cmp HSGap,x
        bne _no
+       lda HSDLo,x             ; (where the lines are drawn: into the loads and stores below)
        sta _pl+1
        sta _ql+1
        lda HSDLo+NBUF,x
        sta _pl+2
        sta _ql+2
        lda HSDHi,x
        sta _ph+1
        sta _qh+1
        lda HSDHi+NBUF,x
        sta _ph+2
        sta _qh+2
        jsr HSPtrs
        ldy #0
        ldx UpLo
        lda HSa
        jsr _cmp
        bcc _no
        ldx LwLo
        lda HSb
_cmp    sta HSc                 ; (A lines from X, against the copy from Y)
-       lda HSc
        beq _yes
        lda HPat,x
        beq _nb
        cmp (ptrB),y
        bne _dif
        lda HCol,x              ; (the same pattern: the same colour?)
        cmp (ptrC),y
        bne _no
_nx     inx
        iny
        dec HSc
        jmp -
_yes    sec
        rts
_no     clc
        rts
_nb     lda (ptrB),y            ; blank now: if drawn before, cleared
        beq _nx
        lda #0
        sta (ptrB),y
        sta tmp
        jsr _wr
        jmp _nx
_dif    sta tmp                 ; drawn now, a different pattern: drawn before too (the same colour)
        lda (ptrB),y
        beq _new
        lda HCol,x
        cmp (ptrC),y
        bne _no
        lda tmp
        sta (ptrB),y
        jsr _wr
        jmp _nx
; the line in the blocks (A = tmp, Y = its index)
_wr
_pl     lda $ffff,y
        sta ptrD
_ph     lda $ffff,y
        sta ptrD+1
        sty tmp2
        ldy #0
        lda tmp
        sta (ptrD),y
        ldy tmp2
        rts
; drawn now, blank before: the run it falls in (its sprite Y from the line as the set has it)
_n2     clc
        rts
_new    stx HSx
        sty HSy
        ldx HSet
        tya
        cmp HSN1,x
        bcc +
        sbc HSN1,x
        clc
        adc HSLwLo,x
        jmp ++
+       adc HSUpLo,x
+       clc
        adc #106 + SPRYOFS
        sta tmp3
        lda HSEn,x
        sta tmp2
        lda Mul5,x
        clc
        adc #NHARRY - 1
        tax
        ldy #NHARRY - 1
_rk     lda tmp2                ; (the last sprite starting at or above it)
        and Bit,y
        beq _rn
        lda tmp3
        sec
        sbc HSY,x
        bcs _rf
_rn     dex
        dey
        bpl _rk
        bmi _n2
_rf     cmp #21
        bcs _n2
        sta HSr                 ; (its row)
        stx HSk
        sty HSs
        ldx HSx                 ; its colour: the run's?
        lda HCol,x
        lsr
        tay
        lda ColorMap,y
        ldx HSk
        cmp HSC,x
        bne _n2
        ldy HSr                 ; (rows used: at least this one)
        iny
        tya
        cmp HUsed,x
        bcc +
        sta HUsed,x
+       lda HSs                 ; where: the run's block, its row
        jsr HarryBlk
        ldx HSr
        lda Mul3,x
        clc
        adc ptrA
        ldy HSy
_ql     sta $ffff,y
        sta ptrD
        lda ptrA+1
        adc #0
_qh     sta $ffff,y
        sta ptrD+1
        lda tmp
        sta (ptrB),y
        ldx HSx
        lda HCol,x
        sta (ptrC),y
        ldy #0
        lda tmp
        sta (ptrD),y
        ldy HSy
        jmp _nx

; HKPtr: ptrB = set HSet's copy of HKey (what its blocks were drawn for); HKSave: HKey there
HKPtr:
        ldx HSet
        lda HKBLo,x
        sta ptrB
        lda HKBHi,x
        sta ptrB+1
        rts
HKSave:
        jsr HKPtr
        ldy #11
-       lda HKey,y
        sta (ptrB),y
        dey
        bpl -
        rts

; ptrB / ptrC = set HSet's copies of HPat / HCol
HSPtrs:
        ldx HSet
        lda HSPatLo,x
        sta ptrB
        lda HSPatHi,x
        sta ptrB+1
        lda HSColLo,x
        sta ptrC
        lda HSColHi,x
        sta ptrC+1
        rts
; HarryBlk: A = Harry's sprite (0-4) -> ptrA = its block in set HSet
HarryBlk:
        clc
        ldx HSet
        adc MulNB,x
        adc #1                  ; (block 0 is the blank one)
        jmp BlkPtr

; BlkPtr: A = a block number from SPRDATA -> ptrA
BlkPtr:
        tax
        lda BlkLo,x
        sta ptrA
        lda BlkHi,x
        sta ptrA+1
        rts

; ObjSprites: the objects on the ground (lines 153-167), one multicolour sprite per copy (5-7),
; each line's colour one of three (the sprite's own, $D025, $D026). The blocks are a pool of NBUF
; sets (OSet), each remembering what it was built for (OKey*): the shape, colours, and if the
; tunnel object's REFP1 (from pixel 88 of line 167) can change the copies' last rows, each copy's
; place against it (OCls: 0 left of 81, 1-7 partly, 8 from 88). One built for these is used as it
; is, else a free one is built. The copies share copy 0's block, unless their place differs.
ObjSprites:
        jsr GroundSlots         ; the colours' slots (when the colours change)
        ldx rbuf
        lda GSlotCol
        sta OCol0,x
        lda GSlotCol+1
        sta StMc1,x
        lda GSlotCol+2
        sta StMc2,x
        lda ObjNusiz            ; the copies' pixels
        and #7
        tax
        lda CopyN,x
        sta v3
        lda Mul3,x
        sta v4
        ldy #0
-       ldx v4
        lda ObjXPix
        clc
        adc CopyOff,x
        jsr Mod160
        sta OPx,y
        inc v4
        iny
        cpy v3
        bcc -
        lda #0                  ; their places (row 14 at line 167, and REFP1 set: else all 0)
        sta OCls
        sta OCls+1
        sta OCls+2
        lda TunReflect
        and #8
        beq _key
        ldy #0
        lda (ObjPtr),y
        beq _key
        ldy v3
        dey
-       lda OPx,y
        sec
        sbc #80
        bcs +
        lda #0
+       cmp #9
        bcc +
        lda #8
+       sta OCls,y
        dey
        bpl -
_key    ldx #NBUF - 1           ; a set built for these
_find   lda ObjPtr
        cmp OKeyP,x
        bne _nx
        lda ObjColPtr
        cmp OKeyC,x
        bne _nx
        lda ColourEor
        cmp OKeyE,x
        bne _nx
        lda ColourAnd
        cmp OKeyA,x
        bne _nx
        lda OCls
        cmp OKC0,x
        bne _nx
        lda OCls+1
        cmp OKC1,x
        bne _nx
        lda OCls+2
        cmp OKC2,x
        bne _nx
        stx OSet
        lda #0
        sta OBuild
        jmp _place
_nx     dex
        bpl _find
        lda #OSetOf - SetOf     ; none: a free one
        jsr FreeSet
        stx OSet
        lda ObjPtr
        sta OKeyP,x
        lda ObjColPtr
        sta OKeyC,x
        lda ColourEor
        sta OKeyE,x
        lda ColourAnd
        sta OKeyA,x
        lda OCls
        sta OKC0,x
        lda OCls+1
        sta OKC1,x
        lda OCls+2
        sta OKC2,x
        lda #1
        sta OBuild
        ldx #0                  ; the rows, line by line: 153-159 from RAM (rows 14-8), 160-167
        ldy #14                 ; from the ROM (7-0) (the same: the vblank code copied them)
-       lda (ObjPtr),y
        sta ORow,x
        inx
        dey
        bpl -
        lda #0                  ; copy 0's block (5)
        sta v2
        lda OPx
        sta v1
        jsr _block
_place  ldx rbuf                ; each copy: its block, registers
        lda OSet
        sta OSetOf,x
        lda #0
        sta ObEn,x
        sta ObMsb,x
        lda OCol0,x
        sta ObCol,x
        lda #0
        sta v2                  ; copy 0..2
_copy   lda v2
        cmp v3
        bcc +
        rts
+       tay
        lda OPx,y
        sta v1                  ; its pixel
        ldx OSet                ; its block: copy 0's (5), or its own if its place differs
        lda MulNB,x
        clc
        adc #5 + 1 + BLK_BLANK
        sta code
        lda OCls,y
        cmp OCls
        beq _ptr
        lda OBuild              ; (built with the set)
        beq +
        jsr _block
+       lda code
        clc
        adc v2
        sta code
_ptr    ldy v2                  ; registers (for EvObjects): pointer, X, enable (copy v2 at
        lda rbuf                ; [buffer + NBUF * copy])
        clc
        adc MulNBUF,y
        tax
        lda code
        sta ObPtr,x
        lda v1
        asl
        php
        clc
        adc #24
        sta ObX,x
        lda #0
        rol
        plp
        adc #0
        ldx rbuf
        cmp #0
        beq +
        lda Bit+5,y
        ora ObMsb,x
        sta ObMsb,x
+       lda Bit+5,y
        ora ObEn,x
        sta ObEn,x
        inc v2
        jmp _copy
; build the block of copy v2 (5 + v2), pixel v1 (for its last row)
_block  lda v2
        clc
        adc #5
        ldx OSet
        adc MulNB,x
        adc #1
        jsr BlkPtr
        ldx #0                  ; rows 0-14
        ldy #0
_r      lda ORow,x
        cpx #14                 ; line 167: REFP1 (the tunnel object's) from pixel 88
        bne +
        jsr Row167
+       sta tmp
        lda GSlot,x
        sta tmp2
        lda tmp
        lsr
        lsr
        lsr
        lsr
        stx tmp3
        tax
        lda Dbl,x
        and tmp2
        sta (ptrA),y
        iny
        lda tmp
        and #15
        tax
        lda Dbl,x
        and tmp2
        sta (ptrA),y
        iny
        iny
        ldx tmp3
        inx
        cpx #15
        bcc _r
        rts

; Row167: A = the object's row on line 167, v1 = the copy's pixel -> A with the pixels from 88
; on reflected if REFP1 (the tunnel object's) is set (X = 14 on return)
Row167:
        sta tmp
        lda TunReflect
        and #8
        beq _same
        lda v1
        cmp #88
        bcs _all
        lda #88
        sec
        sbc v1
        cmp #8
        bcs _same
        tax
        lda MaskFrom,x
        sta tmp2
        ldx tmp
        lda Reverse,x
        eor tmp
        and tmp2
        eor tmp
        ldx #14
        rts
_all    ldx tmp
        lda Reverse,x
        ldx #14
        rts
_same   lda tmp
        ldx #14
        rts

; Slots: OCol = colours, Y = how many -> OSlot per line (the AND mask: $AA own colour, $55
; $D025, $FF $D026) and SlotCol 0-2, in order of first use (every line's, whatever the shape: the
; colours change apart from it); a fourth falls back to the third.
Slots:
        sty tmp3
        lda #$ff
        sta SlotCol
        sta SlotCol+1
        sta SlotCol+2
        ldx #0
_l      lda OCol,x
        lsr
        tay
        lda ColorMap,y
        ldy #0
-       cmp SlotCol,y
        beq _have
        pha
        lda SlotCol,y
        cmp #$ff
        beq _free
        pla
        iny
        cpy #3
        bcc -
        ldy #2                  ; (a fourth colour: drawn in the third)
        inc DbgMcOver
        jmp _have
_free   pla
        sta SlotCol,y
_have   lda SlotMask,y
        sta OSlot,x
        inx
        cpx tmp3
        bcc _l
        ldx #2                  ; unused slots: black
-       lda SlotCol,x
        cmp #$ff
        bne +
        lda #0
        sta SlotCol,x
+       dex
        bpl -
        rts

; GroundSlots: the objects on the ground: their 15 lines' colours (rows 14-0 of their colour
; table, masked) to slots, GSlot / GSlotCol, when the table or the masks change
GroundSlots:
        lda ObjColPtr
        cmp GSKey
        bne +
        lda ColourEor
        cmp GSKey+1
        bne +
        lda ColourAnd
        cmp GSKey+2
        bne +
        rts
+       lda ObjColPtr
        sta GSKey
        lda ColourEor
        sta GSKey+1
        lda ColourAnd
        sta GSKey+2
        ldx #0
        ldy #14
-       lda (ObjColPtr),y
        eor ColourEor
        and ColourAnd
        sta OCol,x
        inx
        dey
        bpl -
        ldy #15
        jsr Slots
        ldx #14
-       lda OSlot,x
        sta GSlot,x
        dex
        bpl -
        ldx #2
-       lda SlotCol,x
        sta GSlotCol,x
        dex
        bpl -
        rts

; TunSlots: the tunnel object: its 32 lines' colours (183: $42; 184-198 the upper table's 14-0;
; 199-214 the lower's 15-0; masked) to slots, TSlot / TSlotCol, when the tables or the mask change
TunSlots:
        lda TunColA
        cmp TSKey
        bne +
        lda TunColB
        cmp TSKey+1
        bne +
        lda ColourAnd
        cmp TSKey+2
        bne +
        rts
+       lda TunColA
        sta TSKey
        lda TunColB
        sta TSKey+1
        lda ColourAnd
        sta TSKey+2
        lda #$42
        and ColourAnd
        sta OCol
        ldx #1
        ldy #14
-       lda (TunColA),y
        and ColourAnd
        sta OCol,x
        inx
        dey
        bpl -
        ldy #15
-       lda (TunColB),y
        and ColourAnd
        sta OCol,x
        inx
        dey
        bpl -
        ldy #32
        jsr Slots
        ldx #31
-       lda OSlot,x
        sta TSlot,x
        dex
        bpl -
        ldx #2
-       lda SlotCol,x
        sta TSlotCol,x
        dex
        bpl -
        rts

; TunSprites: the tunnel object (lines 183-214: the wall, or the scorpion), sprites 5 and 6 from
; line 174 on: 5 from its first line with pixels, 6 for what lies more than 21 lines below that.
; The blocks are a pool of NBUF sets (TSet), each remembering the shape, colours and reflection
; it was built for (TKey*) and its registers (TSY, TSEn): one built for these is used as it is,
; else a free one is built. X every frame.
TunSprites:
        jsr TunSlots            ; the colours' slots (when the colours change)
        ldx rbuf
        lda TSlotCol
        sta TnCol,x
        lda TSlotCol+1
        sta TnMc1,x
        lda TSlotCol+2
        sta TnMc2,x
        lda TunReflect
        and #8
        sta v2
        ldx #NBUF - 1           ; a set built for these
_find   lda TunShapeA
        cmp TKeyA,x
        bne _nx
        lda TunShapeB
        cmp TKeyB,x
        bne _nx
        lda TunColA
        cmp TKeyCA,x
        bne _nx
        lda TunColB
        cmp TKeyCB,x
        bne _nx
        lda v2
        cmp TKeyR,x
        bne _nx
        lda ColourAnd
        cmp TKeyM,x
        bne _nx
        stx TSet
        jmp _regs
_nx     dex
        bpl _find
        lda #TSetOf - SetOf     ; none: a free one
        jsr FreeSet
        stx TSet
        lda TunShapeA
        sta TKeyA,x
        lda TunShapeB
        sta TKeyB,x
        lda TunColA
        sta TKeyCA,x
        lda TunColB
        sta TKeyCB,x
        lda TunReflect
        and #8
        sta TKeyR,x
        lda ColourAnd
        sta TKeyM,x
        ldy #15                 ; the rows by line - 183: the upper part's 15..0, the lower's 15..0
        ldx #0
-       lda (TunShapeA),y
        sta ORow,x
        inx
        dey
        bpl -
        ldy #15
-       lda (TunShapeB),y
        sta ORow,x
        inx
        dey
        bpl -
        lda TunReflect          ; (reflected: REFP1)
        and #8
        beq +
        ldx #31
-       ldy ORow,x
        lda Reverse,y
        sta ORow,x
        dex
        bpl -
+       ldx TSet
        lda #0
        sta TSEn,x
        ldy #0                  ; the first line with pixels
-       lda ORow,y
        bne +
        iny
        cpy #32
        bcc -
        jmp _regs               ; (nothing in the tunnel)
+       sty v0
        lda #0                  ; sprite A (5) from there, B (6) 21 lines on
        sta v1
        jsr _spr
        lda v0
        clc
        adc #21
        cmp #32
        bcs _regs
        cmp #11                 ; (from line 194 at most, overlapping A where it must, the same
        bcc +                   ; pixels: no sprite fetches past line 214)
        lda #11
+       sta v0
        lda #1
        sta v1
        jsr _spr
_regs   ldx rbuf                ; the buffer: the set's registers (pointer, Y, enable)
        ldy TSet
        tya
        sta TSetOf,x
        lda TSEn,y
        sta TnEn,x
        lda MulNB,y
        clc
        adc #8 + 1 + BLK_BLANK
        sta TnPtr,x
        adc #1
        sta TnPtr+NBUF,x
        tya
        asl
        tay
        lda TSY,y
        sta TnY,x
        lda TSY+1,y
        sta TnY+NBUF,x
_place  ldx rbuf                ; X (both sprites), the MSB bits for those enabled
        lda TunXPix
        asl
        php
        clc
        adc #24
        sta TnX,x
        sta TnX+NBUF,x
        lda #0
        rol
        plp
        adc #0
        beq +
        lda TnEn,x
+       sta TnMsb,x
        rts
; one sprite: v1 = 0 (A) / 1 (B), lines v0 .. v0 + 20 (to 31)
_spr    lda v1
        clc
        adc #8
        ldx TSet
        adc MulNB,x
        adc #1
        jsr BlkPtr
        ldy #0                  ; 21 rows (a full block: no rows left over)
        ldx v0
_r      lda #0
        sta tmp
        sta tmp2
        cpx #32
        bcs +
        lda ORow,x
        sta tmp
        lda TSlot,x
        sta tmp2
+       lda tmp
        lsr
        lsr
        lsr
        lsr
        stx tmp3
        tax
        lda Dbl,x
        and tmp2
        sta (ptrA),y
        iny
        lda tmp
        and #15
        tax
        lda Dbl,x
        and tmp2
        sta (ptrA),y
        iny
        iny
        ldx tmp3
        inx
        cpy #63
        bcc _r
        lda TSet                ; the set's registers: Y, enable
        asl
        ora v1
        tax
        lda v0
        clc
        adc #183 + SPRYOFS
        sta TSY,x
        ldx TSet
        ldy v1
        lda Bit+5,y
        ora TSEn,x
        sta TSEn,x
        rts
