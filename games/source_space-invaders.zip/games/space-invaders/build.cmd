@echo off
rem Build Space Invaders:
rem   build\spaceinvaders.a26       the 2600 ROM rebuilt from source (checked against the original)
rem   build\spaceinv-V.prg   the Commodore 64 version
rem   build\spaceinv-V.d64   the C64 version on a disk image
rem   build\spaceinv-V.crt   the C64 version as an EasyFlash cartridge (..\..\tools\mkcrt.js)
rem The original ROM (or its .zip) must be in roms_port\ (found by MD5, any file name).
rem (V: the version in the BASIC listing; file names at most 16 characters: ..\..\tools\buildname.js)
cd /d "%~dp0"
set TASS=..\..\tools\64tass\64tass.exe
set MD5=72ffbef6504b75e69ee1045af9075f66
if not exist build mkdir build
if not exist 2600\spaceinvaders.asm node ..\..\tools\disasm.js . || exit /b 1
set NAME=
for /f %%n in ('node ..\..\tools\buildname.js . spaceinv') do set NAME=%%n
if "%NAME%"=="" (echo no build name: see tools\buildname.js & exit /b 1)

node ..\..\tools\rom.js %MD5% build\original.a26 >nul || exit /b 1
%TASS% -q --nostart -o build\spaceinvaders.a26 2600\spaceinvaders.asm || exit /b 1
fc /b build\original.a26 build\spaceinvaders.a26 >nul && (echo OK: build\spaceinvaders.a26 matches the original ROM) || (echo DIFFERENT: build differs from the original ROM & exit /b 1)

node tools\mkc64tables.js >nul || exit /b 1
del /q build\spaceinv-*.prg build\spaceinv-*.d64 build\spaceinv-*.crt build\spaceinv-*.lst build\spaceinvaders-c64.* 2>nul
%TASS% -q -C -a -o build\%NAME%.prg -L build\%NAME%.lst c64\main.asm || exit /b 1
echo OK: build\%NAME%.prg
node ..\..\tools\mkcrt.js build\%NAME%.prg build\%NAME%.crt "Space Invaders" || exit /b 1


where c1541 >nul 2>&1 || (echo c1541 not found, skipping the disk image & exit /b 0)
if exist build\%NAME%.d64 del build\%NAME%.d64
c1541 -format "space invaders,si" d64 build\%NAME%.d64 -write build\%NAME%.prg "space invaders" >nul || exit /b 1
echo OK: build\%NAME%.d64
