# Space Invaders (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80` | KRow | 1 | Kernel: index of the invader row being drawn (5 = top) |
| `$81` | Temp | 1 | General scratch byte |
| `$82` | HitFlags | 1 | Collisions latched by the kernel. Bits 0-5: ball hit invader row n. Bit 6: ball hit UFO. Bit 7: ball hit a shield |
| `$83-$88` | HPos | 6 | Horizontal positions converted for the TIA (high nibble fine HMOVE, low nibble coarse delay). +0 ball/UFO, +1 invaders, +2 shields, +3 cannon 1, +4 cannon 2, +5 second ball object |
| `$89` | BallCount | 1 | Line countdown to the first ball object (laser or bomb); ball is on while 0-3 |
| `$8A` | BallGap | 1 | Lines between the first and second ball object |
| `$8B` | AnimFrame | 1 | Invader animation: $FF or $09, added to the row graphics pointer |
| `$8C` | RowsLeft | 1 | Kernel: number of invader rows still to draw |
| `$8D` | MarchRight | 1 | Rightmost X the invader rack may reach (depends on surviving columns) |
| `$8E` | ShieldGapLines | 1 | Blank lines between the invaders and the shields |
| `$8F` | TopGap | 1 | Kernel: blank lines above the invader rack (copy of RackY) |
| `$90` | RackY | 1 | Invader rack vertical offset; grows by 5 each time the rack reverses |
| `$91` | InvadersLeft | 1 | Invaders still alive (36 at the start of a wave) |
| `$92-$97` | Rows | 6 | Alive mask per invader row, bottom row first; bit 0 = left column |
| `$98` | PlayFlags | 1 | Bit 0 UFO direction, bit 1 march right, bits 2-3 laser/bomb ownership after sorting, bit 4 show cannon 1, bit 5 show cannon 2, bit 6 shields present, bit 7 invaders have landed |
| `$99` | Wave | 1 | Wave number 0-3; picks the starting height of the rack |
| `$9A` | RackX | 1 | Invader rack X position |
| `$9B` | ShieldX | 1 | Shield X position (moves in "moving shields" games) |
| `$9C-$9D` | CannonX | 2 | Cannon X positions, player 1 then player 2 (range $23-$75) |
| `$9E` | UfoX | 1 | UFO X position; $B4 = no UFO |
| `$9F-$A9` | Alt | 11 | Saved copy of $90-$9A for the player who is not up (alternating games) |
| `$AA` | GameState | 1 | Bit 7 not playing (attract/select), bit 6 second player up, bit 4 shield direction, bit 3 wave cleared, bit 2 cannon 1 hit, bit 1 cannon 2 hit, bit 0 waiting to start |
| `$AB-$C5` | Shields | 27 | Three 9-line shield bitmaps, eroded by hits |
| `$C6` | UfoTimer | 1 | Countdown to the next UFO |
| `$C7` | AttractColor | 1 | Non-zero when no game is running; EORed into every colour for the attract colour cycle |
| `$C8` | Explosion | 1 | Explosion sprite: bits 0-2 column, bits 3-5 row, bits 6-7 frame. Row/col $39 = UFO |
| `$C9` | Lives | 1 | Lives left (shown at the bottom) |
| `$CA` | FrameTimer | 1 | Counts down every frame; bit 0 picks laser vs bomb frame. Reloaded as a pause timer after deaths and waves |
| `$CB-$CC` | SfxId | 2 | Sound effect playing on channel 0 / 1 (higher id = higher priority) |
| `$CD-$CE` | SfxTime | 2 | Sound effect frame counter, channel 0 / 1 |
| `$CF-$D0` | SfxPos | 2 | Sound effect data index, channel 0 / 1 |
| `$D1-$D2` | BombY | 2 | Bomb Y positions (kept sorted, lower first) |
| `$D3-$D4` | BombX | 2 | Bomb X positions |
| `$D5-$D6` | LaserY | 2 | Laser shot Y, player 1 / 2; $EC and up = not fired |
| `$D7-$D8` | LaserX | 2 | Laser shot X, player 1 / 2 |
| `$D9` | TurnTimer | 1 | Timer used by the two-player modes when control passes between players? |
| `$DA` | ZigZag | 1 | Random bits steering zig-zag bombs |
| `$DB` | ModeFlags | 1 | Feature flags for the selected game mode (from table TFD4B) |
| `$DC` | GameNumber | 1 | Selected game minus 1 (0-111). Bit 0 moving shields, bit 1 zig-zag bombs, bit 2 fast bombs, bit 3 invisible invaders; high nibble is the mode |
| `$DD-$E4` | Colors | 8 | Current colours: shields, UFO, cannon 1, cannon 2, invaders, playfield/ball, background, ground |
| `$E5` | GameOver | 1 | Bit 7 set when the game has ended |
| `$E6-$E7` | ScoreHi | 2 | Score high byte (BCD), player 1 / 2 |
| `$E8-$E9` | ScoreLo | 2 | Score low byte (BCD), player 1 / 2 |
| `$EA` | RandSeed | 1 | Pseudo-random seed, stepped by the Random routine (x*5 + $59) |
| `$EB` | Columns | 1 | OR of all row masks: which columns still have invaders |
| `$EC` | Mode | 1 | Game mode 0-6 (GameNumber >> 4) |
| `$ED` | SelectDelay | 1 | Auto-repeat delay for the Game Select switch |
| `$EE-$F9` | Scratch | 12 | Shared scratch. In the invader kernel: six graphics pointers. In the logic: temporaries and points to add (Scratch+6..+9 = score hi P1/P2, lo P1/P2) |
| `$FA-$FF` | StackArea | 6 | Top of RAM, used by the 6502 stack (subroutine return addresses) |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$F000` | InvaderLines | Draw one invader row: 6 sprites per line using 2 players x 3 copies, rewriting GRP0/GRP1 mid-line |
| `$F0A5` | InvaderRow | Set up the six graphics pointers for the next row from its alive mask |
| `$F109` | ShieldGap | Blank lines between the invaders and the shields |
| `$F11A` | DrawShields | Draw the three shields from RAM (one player, three copies) |
| `$F1B2` | DrawCannons | Position and draw the two cannons |
| `$F282` | DrawGround | Ground line, lives, sound update and cannon-hit check |
| `$F2F8` | Overscan | Wait for the kernel timer, then run the first half of the game logic |
| `$F36E` | LaserHits | Odd frames: resolve laser hits on the UFO and invaders |
| `$F429` | MoveUfo | Even frames: move the UFO |
| `$F459` | ReadJoysticks | Move the cannons from the joysticks |
| `$F4A5` | MoveShields | Slide the shields back and forth in "moving shields" games |
| `$F4D4` | StartFrame | Blank the screen, add pending points to the scores, generate VSYNC |
| `$F528` | MoveLasers | Odd frames: move laser shots up |
| `$F549` | MoveBombs | Even frames: move bombs down (zig-zag / fast variants) |
| `$F5A2` | GameFlow | When FrameTimer runs out: waves, deaths, turns and game over |
| `$F668` | LaunchUfo | Count down and launch the UFO |
| `$F68C` | ConsoleSwitches | Handle the Game Reset and Game Select switches |
| `$F6EE` | ShowGameNumber | Select screen: put the game number in the score digits |
| `$F747` | FireButtons | Read the fire buttons and launch lasers |
| `$F7DB` | DropBomb | Pick an invader column and drop a bomb |
| `$F875` | MarchInvaders | Step the rack sideways at a speed set by how many invaders remain; drop at the edges |
| `$F8F5` | RackLayout | Work out the kernel gaps from the rack height; detect landing |
| `$F952` | TrimColumns | Shift away empty columns on the left and compute the right-hand limit |
| `$F98E` | SetupKernel | Convert positions for the TIA and load this frame's colours |
| `$FA43` | StartKernel | Wait for the end of vertical blank and start drawing |
| `$FA64` | DrawScores | Draw both scores with the playfield |
| `$FB0D` | DrawUfo | Draw the UFO instead of the scores |
| `$FB55` | InvaderSetup | Position the two players for the invader rows |
| `$FBAF` | FireLaser | Launch a laser from cannon X (if allowed) |
| `$FBED` | CancelUfoIfExploding | Remove the UFO when its explosion is showing |
| `$FD67` | CalcHPos | Convert an X position in A to TIA fine/coarse form in HPos+X |
| `$FD7E` | SetHPos | Place object X (0-4) using the value in A |
| `$FD8B` | ErodeShieldY | Knock a bit out of a shield (with bounds check) |
| `$FD8F` | ErodeShield | Knock a bit out of a shield and maybe a random neighbour |
| `$FDB2` | BallLineReposition | Kernel line: update the ball and move it to the second object when the first is done |
| `$FDE9` | BallLine | Kernel helper: turn the ball on or off for this line |
| `$FDFB` | Random | Step the random number generator |
| `$FE08` | UpdateSound | Play the next step of the sound effect on channel X |
| `$FE75` | StartPause | Start a 128-frame pause (death, landing) |
| `$FE7E` | PlaySfx0 | Start sound effect A on channel 0 if it outranks the current one |
| `$FE8B` | PlaySfx1 | Start sound effect A on channel 1 if it outranks the current one |
| `$FEB2` | NewGame | Clear the scores and start a game |
| `$FEC0` | InitPlayers | Reset lives, wave and per-player state |
| `$FEFA` | NewWave | Fresh rack of 36 invaders, clear shots, reset positions |
| `$FF3A` | RebuildShields | Copy the shield shape into all three shield bitmaps |
