// Names for Space Invaders' RAM and routines, worked out by reading the code and
// watching RAM in tools/vcs.js. Used by tools/disasm.js to label the source and to
// write RAM-MAP.md. "?" in a description marks something not yet confirmed.
//
// Conventions found in the code:
//   - Invader rows are numbered from the bottom: Rows+0 is the lowest row.
//   - Within a row mask, bit 0 is the leftmost column.
//   - Many things alternate by frame parity (FrameTimer bit 0): odd frames draw
//     and collide the lasers, even frames the bombs (the ball does both).
//   - $F6 in a Y coordinate means "object not on screen".

const ram = [
  // ---- kernel scratch -------------------------------------------------------
  [0x80, 'KRow', 1, 'Kernel: index of the invader row being drawn (5 = top)'],
  [0x81, 'Temp', 1, 'General scratch byte'],
  [0x82, 'HitFlags', 1, 'Collisions latched by the kernel. Bits 0-5: ball hit invader row n. Bit 6: ball hit UFO. Bit 7: ball hit a shield'],
  [0x83, 'HPos', 6, 'Horizontal positions converted for the TIA (high nibble fine HMOVE, low nibble coarse delay). +0 ball/UFO, +1 invaders, +2 shields, +3 cannon 1, +4 cannon 2, +5 second ball object'],
  [0x89, 'BallCount', 1, 'Line countdown to the first ball object (laser or bomb); ball is on while 0-3'],
  [0x8A, 'BallGap', 1, 'Lines between the first and second ball object'],
  [0x8B, 'AnimFrame', 1, 'Invader animation: $FF or $09, added to the row graphics pointer'],
  [0x8C, 'RowsLeft', 1, 'Kernel: number of invader rows still to draw'],
  [0x8D, 'MarchRight', 1, 'Rightmost X the invader rack may reach (depends on surviving columns)'],
  [0x8E, 'ShieldGapLines', 1, 'Blank lines between the invaders and the shields'],
  [0x8F, 'TopGap', 1, 'Kernel: blank lines above the invader rack (copy of RackY)'],

  // ---- per-player state (swapped with the Alt copy in alternating games) ---
  [0x90, 'RackY', 1, 'Invader rack vertical offset; grows by 5 each time the rack reverses'],
  [0x91, 'InvadersLeft', 1, 'Invaders still alive (36 at the start of a wave)'],
  [0x92, 'Rows', 6, 'Alive mask per invader row, bottom row first; bit 0 = left column'],
  [0x98, 'PlayFlags', 1, 'Bit 0 UFO direction, bit 1 march right, bits 2-3 laser/bomb ownership after sorting, bit 4 show cannon 1, bit 5 show cannon 2, bit 6 shields present, bit 7 invaders have landed'],
  [0x99, 'Wave', 1, 'Wave number 0-3; picks the starting height of the rack'],
  [0x9A, 'RackX', 1, 'Invader rack X position'],
  [0x9B, 'ShieldX', 1, 'Shield X position (moves in "moving shields" games)'],
  [0x9C, 'CannonX', 2, 'Cannon X positions, player 1 then player 2 (range $23-$75)'],
  [0x9E, 'UfoX', 1, 'UFO X position; $B4 = no UFO'],
  [0x9F, 'Alt', 11, 'Saved copy of $90-$9A for the player who is not up (alternating games)'],
  [0xAA, 'GameState', 1, 'Bit 7 not playing (attract/select), bit 6 second player up, bit 4 shield direction, bit 3 wave cleared, bit 2 cannon 1 hit, bit 1 cannon 2 hit, bit 0 waiting to start'],
  [0xAB, 'Shields', 27, 'Three 9-line shield bitmaps, eroded by hits'],

  // ---- game flow, sound, objects -------------------------------------------
  [0xC6, 'UfoTimer', 1, 'Countdown to the next UFO'],
  [0xC7, 'AttractColor', 1, 'Non-zero when no game is running; EORed into every colour for the attract colour cycle'],
  [0xC8, 'Explosion', 1, 'Explosion sprite: bits 0-2 column, bits 3-5 row, bits 6-7 frame. Row/col $39 = UFO'],
  [0xC9, 'Lives', 1, 'Lives left (shown at the bottom)'],
  [0xCA, 'FrameTimer', 1, 'Counts down every frame; bit 0 picks laser vs bomb frame. Reloaded as a pause timer after deaths and waves'],
  [0xCB, 'SfxId', 2, 'Sound effect playing on channel 0 / 1 (higher id = higher priority)'],
  [0xCD, 'SfxTime', 2, 'Sound effect frame counter, channel 0 / 1'],
  [0xCF, 'SfxPos', 2, 'Sound effect data index, channel 0 / 1'],
  [0xD1, 'BombY', 2, 'Bomb Y positions (kept sorted, lower first)'],
  [0xD3, 'BombX', 2, 'Bomb X positions'],
  [0xD5, 'LaserY', 2, 'Laser shot Y, player 1 / 2; $EC and up = not fired'],
  [0xD7, 'LaserX', 2, 'Laser shot X, player 1 / 2'],
  [0xD9, 'TurnTimer', 1, 'Timer used by the two-player modes when control passes between players?'],
  [0xDA, 'ZigZag', 1, 'Random bits steering zig-zag bombs'],
  [0xDB, 'ModeFlags', 1, 'Feature flags for the selected game mode (from table TFD4B)'],
  [0xDC, 'GameNumber', 1, 'Selected game minus 1 (0-111). Bit 0 moving shields, bit 1 zig-zag bombs, bit 2 fast bombs, bit 3 invisible invaders; high nibble is the mode'],
  [0xDD, 'Colors', 8, 'Current colours: shields, UFO, cannon 1, cannon 2, invaders, playfield/ball, background, ground'],
  [0xE5, 'GameOver', 1, 'Bit 7 set when the game has ended'],
  [0xE6, 'ScoreHi', 2, 'Score high byte (BCD), player 1 / 2'],
  [0xE8, 'ScoreLo', 2, 'Score low byte (BCD), player 1 / 2'],
  [0xEA, 'RandSeed', 1, 'Pseudo-random seed, stepped by the Random routine (x*5 + $59)'],
  [0xEB, 'Columns', 1, 'OR of all row masks: which columns still have invaders'],
  [0xEC, 'Mode', 1, 'Game mode 0-6 (GameNumber >> 4)'],
  [0xED, 'SelectDelay', 1, 'Auto-repeat delay for the Game Select switch'],
  [0xEE, 'Scratch', 12, 'Shared scratch. In the invader kernel: six graphics pointers. In the logic: temporaries and points to add (Scratch+6..+9 = score hi P1/P2, lo P1/P2)'],
  [0xFA, 'StackArea', 6, 'Top of RAM, used by the 6502 stack (subroutine return addresses)'],
];

const labels = {
  0xF000: ['InvaderLines', 'Draw one invader row: 6 sprites per line using 2 players x 3 copies, rewriting GRP0/GRP1 mid-line'],
  0xF0A5: ['InvaderRow', 'Set up the six graphics pointers for the next row from its alive mask'],
  0xF109: ['ShieldGap', 'Blank lines between the invaders and the shields'],
  0xF11A: ['DrawShields', 'Draw the three shields from RAM (one player, three copies)'],
  0xF1B2: ['DrawCannons', 'Position and draw the two cannons'],
  0xF282: ['DrawGround', 'Ground line, lives, sound update and cannon-hit check'],
  0xF2F8: ['Overscan', 'Wait for the kernel timer, then run the first half of the game logic'],
  0xF36E: ['LaserHits', 'Odd frames: resolve laser hits on the UFO and invaders'],
  0xF429: ['MoveUfo', 'Even frames: move the UFO'],
  0xF459: ['ReadJoysticks', 'Move the cannons from the joysticks'],
  0xF4A5: ['MoveShields', 'Slide the shields back and forth in "moving shields" games'],
  0xF4D4: ['StartFrame', 'Blank the screen, add pending points to the scores, generate VSYNC'],
  0xF528: ['MoveLasers', 'Odd frames: move laser shots up'],
  0xF549: ['MoveBombs', 'Even frames: move bombs down (zig-zag / fast variants)'],
  0xF5A2: ['GameFlow', 'When FrameTimer runs out: waves, deaths, turns and game over'],
  0xF668: ['LaunchUfo', 'Count down and launch the UFO'],
  0xF68C: ['ConsoleSwitches', 'Handle the Game Reset and Game Select switches'],
  0xF6EE: ['ShowGameNumber', 'Select screen: put the game number in the score digits'],
  0xF747: ['FireButtons', 'Read the fire buttons and launch lasers'],
  0xF7DB: ['DropBomb', 'Pick an invader column and drop a bomb'],
  0xF875: ['MarchInvaders', 'Step the rack sideways at a speed set by how many invaders remain; drop at the edges'],
  0xF8F5: ['RackLayout', 'Work out the kernel gaps from the rack height; detect landing'],
  0xF952: ['TrimColumns', 'Shift away empty columns on the left and compute the right-hand limit'],
  0xF98E: ['SetupKernel', 'Convert positions for the TIA and load this frame\'s colours'],
  0xFA43: ['StartKernel', 'Wait for the end of vertical blank and start drawing'],
  0xFA64: ['DrawScores', 'Draw both scores with the playfield'],
  0xFB0D: ['DrawUfo', 'Draw the UFO instead of the scores'],
  0xFB55: ['InvaderSetup', 'Position the two players for the invader rows'],
  0xFBAF: ['FireLaser', 'Launch a laser from cannon X (if allowed)'],
  0xFBED: ['CancelUfoIfExploding', 'Remove the UFO when its explosion is showing'],
  0xFD67: ['CalcHPos', 'Convert an X position in A to TIA fine/coarse form in HPos+X'],
  0xFD7E: ['SetHPos', 'Place object X (0-4) using the value in A'],
  0xFD8B: ['ErodeShieldY', 'Knock a bit out of a shield (with bounds check)'],
  0xFD8F: ['ErodeShield', 'Knock a bit out of a shield and maybe a random neighbour'],
  0xFDB2: ['BallLineReposition', 'Kernel line: update the ball and move it to the second object when the first is done'],
  0xFDE9: ['BallLine', 'Kernel helper: turn the ball on or off for this line'],
  0xFDFB: ['Random', 'Step the random number generator'],
  0xFE08: ['UpdateSound', 'Play the next step of the sound effect on channel X'],
  0xFE75: ['StartPause', 'Start a 128-frame pause (death, landing)'],
  0xFE7E: ['PlaySfx0', 'Start sound effect A on channel 0 if it outranks the current one'],
  0xFE8B: ['PlaySfx1', 'Start sound effect A on channel 1 if it outranks the current one'],
  0xFEB2: ['NewGame', 'Clear the scores and start a game'],
  0xFEC0: ['InitPlayers', 'Reset lives, wave and per-player state'],
  0xFEFA: ['NewWave', 'Fresh rack of 36 invaders, clear shots, reset positions'],
  0xFF3A: ['RebuildShields', 'Copy the shield shape into all three shield bitmaps'],
};

const game = { title: 'Space Invaders', from: 'Atari 2600, 1980', md5: '72ffbef6504b75e69ee1045af9075f66', asm: 'spaceinvaders.asm' };

module.exports = { game, ram, labels };
