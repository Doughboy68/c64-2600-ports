; Space Invaders (Atari 2600, 1980) running on the Commodore 64.
;
; The original 2600 program runs almost unchanged at $F000, in the RAM under
; the C64 KERNAL. Three JMPs are patched in (see GameImage at the end). This
; file supplies everything the 2600 hardware used to do:
;
;   - display: invaders and shields as custom characters, cannons, UFO, shots
;     and explosions as sprites, laid out line-for-line like the 2600 screen
;     (one 2600 pixel = two C64 pixels, one 2600 line = one C64 line)
;   - collisions: computed in software with the 2600's geometry and handed to
;     the game exactly as the TIA collision registers would report them
;   - input: keyboard and joysticks mapped onto the 2600 joystick/switch ports
;   - sound: the game's TIA sound registers translated to the SID
;
; The game's own TIA writes land harmlessly in zero page $02-$2C, and its
; RIOT accesses ($0280-$0297) hit plain C64 RAM, which we fill in each frame.
;
; Build: build.cmd (64tass -C -a -o build/spaceinvaders-c64.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM
HitFlags    = $82
AnimFrame   = $8B
RowsLeft    = $8C
RackY       = $90
Rows        = $92       ; 6 bytes, bottom row first, bit 0 = left column
PlayFlags   = $98
RackX       = $9A
ShieldX     = $9B
CannonX     = $9C       ; 2 bytes
UfoX        = $9E
GameState   = $AA
Shields     = $AB       ; 27 bytes
AttractCol  = $C7
Explosion   = $C8
Lives       = $C9
FrameTimer  = $CA
BombY       = $D1       ; BombY, BombX, LaserY, LaserX are 2 bytes each, in this order
BombX       = $D3
LaserY      = $D5
LaserX      = $D7
Colors      = $DD       ; shields, UFO, cannon 1, cannon 2, invaders, ball, background, ground
ScoreHi     = $E6
ScoreLo     = $E8

; ---------------------------------------------- 2600 hardware, now plain RAM
CXP0FB      = $02       ; bit 6: ball hit player 0 (cannon 1)
CXP1FB      = $03       ; bit 6: ball hit player 1 (cannon 2)
INPT4       = $0C       ; bit 7 clear: player 1 fire
INPT5       = $0D       ; bit 7 clear: player 2 fire
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
SWCHA       = $0280     ; joysticks
SWCHB       = $0282     ; console switches
INTIM       = $0284     ; timer (kept at 0 so the game never waits)

; ------------------------------------------------ 2600 program entry points
GamePart1   = $F2B1     ; after the screen: sound, cannon hits, laser hits, joysticks
GamePart2   = $F4DA     ; vertical blank: scores, shots, marching, game flow
NewGame     = $FEB2
InvaderGfx  = $FCD6     ; low byte of each row's invader graphics in page $FC
ExplodeGfx  = $FD1E     ; low bytes of the four explosion frames
LivesGfx    = $FD16     ; low bytes (page $FF) of the digits 0-3
UfoGfx      = $A0       ; UFO graphics, page $FC

; ------------------------------------------------------------ C64 layout
SCREEN      = $0400
COLRAM      = $D800
CHARSET     = $2000
SPRDATA     = $2800     ; sprite block n at SPRDATA + 64n, pointer value SPRBASE + n
SPRBASE     = SPRDATA / 64
SPRPTR      = SCREEN + $3F8
SHIFTTAB    = $C000     ; 12 pages: 2600 byte -> 3 C64 bytes, for 4 sub-character shifts

; screen line of 2600 line L is L - LINEOFS; sprite Y register is screen line + SPRY
LINEOFS     = 37
SPRY        = 50
        .weak                      ; 1: start the ground dither with green, 0: with brown
GREENTOP    = 1
        .endweak
GROUNDLINE  = 51 + 230 - LINEOFS   ; raster line of 2600 line 230, where the ground starts. The
                                   ; loop waits for it and starts colouring on the next line.
TOPLINE     = 50                   ; switch to the picture colours just above the text area

; character numbers
CH_SCORETOP = 0         ; 0-15: 2x4 block patterns for the top 4 rows of a digit
CH_SCOREBOT = 16        ; bottom row of a digit
CH_SCORE2   = 160       ; digit pieces lit on the second line: same numbers + 160
CH_MARK0    = 18        ; ground markers
CH_MARK1    = 19
CH_INV      = 32        ; 6 rows x 9 characters
CH_SHIELD   = 96        ; 3 shields x 9 characters
CH_LIVES    = 128       ; 3 x 3 characters

; sprite numbers
SP_CANNON1  = 0
SP_CANNON2  = 1
SP_UFO      = 2
SP_LASER    = 3         ; 3, 4
SP_BOMB     = 5         ; 5, 6
SP_EXPLODE  = 7

; Sprite blocks. The VIC fetches all 21 lines of a sprite, stealing CPU time on
; each line even where it is empty. Shapes near the ground are put at the
; bottom of their sprite so the fetches stop where the shape does and leave
; the cycle-exact ground loop alone; shapes near the top stay at the top.
BLK_SHAPES  = 2         ; 2-9: one per entry in ShapeLo, at the top of the sprite
BLK_LOW     = 10        ; 10-17: the same, at the bottom (lines 11-20)
BLK_WIDE    = 18        ; 18-20: double-width cannons, at the bottom
BLK_BALL    = 21        ; 21-31: the ball, 1 to 11 lines tall, at the top
BLK_LOWBALL = 32        ; 32-42: the same, at the bottom (blocks 32+ are at $3000+)
        .cerror SPRDATA + 64 * (BLK_LOWBALL + 11) > $3400, "sprite blocks overflow the cleared area"
LOWSHIFT    = 11        ; a bottom-aligned 10-line shape starts 11 lines down

; ------------------------------------------------------- zero page ($30+)
; $02-$2C is where the game's TIA writes land, so ours start at $30.
        .virtual $30
ptrA        .word ?     ; source
ptrB        .word ?     ; destination
ptrC        .word ?     ; screen
ptrD        .word ?     ; colour RAM
ptrS        .word ?
t0          .word ?     ; shift table pages
t1          .word ?
t2          .word ?
cCol        .fill 8     ; C64 versions of the game's 8 colours
frameFlag   .byte ?     ; frames counted by the raster IRQ
frames      .byte ?
dcnt        .byte ?     ; raster loop counters
gcnt        .byte ?
isPal       .byte ?
tickAcc     .byte ?
firstTick   .byte ?
tmp         .byte ?
tmp2        .byte ?
cnt         .byte ?
width       .byte ?
voff        .byte ?
crow        .byte ?
ccol        .byte ?
shift       .byte ?
nrows       .byte ?
srcIdx      .byte ?
lineIdx     .byte ?
v0          .byte ?
v1          .byte ?
v2          .byte ?
mask        .byte ?
baseCh      .byte ?
colOff      .byte ?
jIdx        .byte ?
colour      .byte ?
acc         .byte ?
bTop        .byte ?
bBot        .byte ?
bx          .byte ?
bandT       .byte ?
bandB       .byte ?
gLo         .byte ?
gHi         .byte ?
dxv         .byte ?
objIdx      .byte ?
pairOff     .byte ?
cp1         .byte ?
cp2         .byte ?
sprOn       .byte ?
sprMsb      .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)
outv        .fill 3     ; SWCHA, INPT4, INPT5 being built
switches    .byte ?     ; SWCHB toggles (colour, difficulties)
        .cerror * > $80, "zero page overflow"
        .endv

cShield = cCol+0
cUfo    = cCol+1
cCan1   = cCol+2
cCan2   = cCol+3
cInv    = cCol+4
cBall   = cCol+5
cBg     = cCol+6
cGround = cCol+7

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title and credits. Line 0 is the
; SYS, the REM lines after it are the text. (Lower case here: 64tass -a turns it
; into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " space invaders"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600"
Bas30   .word Bas40, 30
        .null $8f, " programmed by rick maurer"
Bas40   .word Bas50, 40
        .null $8f, " version 1.4"
Bas50   .word Bas60, 50
        .null $8f, " ported by claude and doughboy68"
Bas60   .word Bas70, 60
        .null $8f, " p1-joy port 2 or a/d space-fire"
Bas70   .word Bas80, 70
        .null $8f, " p2-joy port 1 or j/l return-fire"
Bas80   .word Bas90, 80
        .null $8f, " f1 or fire-start f2-power off/on"
Bas90   .word Bas100, 90
        .null $8f, " f3-select f5-color f7/f8-difficulty"
Bas100   .word BasEnd, 100
        .null $8f, " f-flicker on/off"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #$ff
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01

        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -

        ; copy the patched 2600 program to $F000-$FFFF
        lda #<GameImage
        sta ptrA
        lda #>GameImage
        sta ptrA+1
        lda #0
        sta ptrB
        lda #$f0
        sta ptrB+1
        ldx #16
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        lda #<Nmi               ; our vectors replace the 2600's
        sta $fffa
        lda #>Nmi
        sta $fffb
        lda #<Irq
        sta $fffe
        lda #>Irq
        sta $ffff

        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #0
        sta INTIM
        lda #$80
        sta INPT4
        sta INPT5

        ; what the 2600's reset routine does after clearing memory
        jsr NewGame
        lda #$c5
        sta AttractCol
        lda #$80
        sta GameState
        lda #1
        sta firstTick

        jsr InitVideo
        jsr InitSound
        jsr DetectPal

        lda #TOPLINE-3          ; first raster interrupt: top of the picture
        sta $d012
        lda #$1b
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

; ================================================================ main loop
MainLoop:
-       lda frameFlag           ; frames since we last got here (set by the raster IRQ)
        beq -
        sei
        lda frameFlag
        ldx #0
        stx frameFlag
        cli
        cmp #3                  ; if we fell behind, catch up at most 3 frames
        bcc +
        lda #3
+       sta frames
        lda DbgBorder           ; testing aid: border shows where the time goes
        beq +
        lda #2
        sta $d020
+       jsr Render              ; draw the state the last tick produced
        jsr ReadInput
        lda PowerReq            ; F2: the power switch
        beq +
        jsr PowerCycle
+
        lda DbgBorder
        beq +
        lda #5
        sta $d020
+
_frame  lda isPal               ; PAL: 6 game ticks every 5 frames keeps 2600 speed
        beq _ntsc
        lda tickAcc
        clc
        adc #6
        sta tickAcc
-       lda tickAcc
        cmp #5
        bcc _done
        sbc #5
        sta tickAcc
        jsr Tick
        jmp -
_ntsc   jsr Tick
_done   dec frames
        bne _frame
        jsr UpdateSound
        lda DbgBorder
        beq +
        lda #0
        sta $d020
+       jmp MainLoop

; F2: the power switch off and on. The 2600's RAM and TIA are cleared and the
; game starts as from power-on (game 1); the console switches stay as they are
; set, as on a real 2600. The display catches up by itself.
PowerCycle:
        lda #0
        sta PowerReq
        sta FireStart
        sta IdleFrames
        ldx #2                  ; the TIA's registers ($02-$2C) and the 2600 RAM
-       sta $00,x
        inx
        cpx #$2d
        bne -
        ldx #$80
-       sta $00,x
        inx
        bne -
        sta INTIM
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        sta INPT5
        jsr NewGame             ; what the 2600's reset routine does after clearing memory
        lda #$c5
        sta AttractCol
        lda #$80
        sta GameState
        lda #1
        sta firstTick
        rts

; F2 (F1 with either shift key): ask for a power cycle on key-down. f2now = F2 held.
PowerKey:
        lda #0
        sta f2now
        lda Keys+0
        and #$10
        bne _up                 ; F1 key up
        lda Keys+1              ; left shift
        bpl _down
        lda Keys+6              ; right shift
        and #$10
        bne _up
_down   inc f2now
        lda PrevF2
        bne _up
        lda #1
        sta PowerReq
_up     lda f2now
        sta PrevF2
        rts

; One 2600 frame of game logic: collisions for the frame just "drawn",
; then the original code from the end of the kernel to the start of the next.
Tick:
        lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp GamePart2           ; the very first frame starts in vertical blank
+       jsr Collide
        jmp GamePart1
TickDone:                       ; the 2600 program jumps here instead of drawing
        rts

; =========================================================== interrupts
; Two raster splits per frame. The 2600 picture fills the whole width of the
; TV, so the border takes the background colour over the picture. From the
; ground down, a cycle-exact loop sets the colours line by line (every pass is
; exactly one line: 63 cycles on PAL, 65 on NTSC), alternating two colours to dither the 2600's
; olive ground. All colour writes land in the horizontal blank, so nothing
; flickers and no stray dots appear.
delay55 .macro                  ; 55 cycles
        lda #6
        sta dcnt
-       dec dcnt
        bne -
        bit $00
        .endm
delay47 .macro                  ; 47 cycles
        lda #5
        sta dcnt
-       dec dcnt
        bne -
        bit $00
        .endm

        .align 256              ; the timed loop must not cross a page: a branch
        .page                   ; across one would cost an extra cycle
Irq:
        pha
        txa
        pha
        tya
        pha
        lda $d019
        sta $d019
        lda irqPhase
        bne _ground

        ldx cBg                 ; top of the picture
        lda #TOPLINE-2          ; wait for the start of the line before ...
-       cmp $d012
        bcs -
        #delay55                ; ... then write at the very end of it
        stx $d020
        stx $d021
        lda #GROUNDLINE-2
        sta $d012
        inc irqPhase
        jmp _out

_ground ldx GroundA             ; the ground
        ldy GroundB
        lda GroundPairs
        sta gcnt
        lda isPal
        beq _ntsc
        lda #GROUNDLINE-1
-       cmp $d012
        bcs -
        #delay55
_pair   stx $d020               ; PAL: 63 cycles per line
        stx $d021
        #delay55
        sty $d020
        sty $d021
        #delay47
        dec gcnt
        bne _pair
        beq _below
_ntsc   lda #GROUNDLINE-1
-       cmp $d012
        bcs -
        #delay55
_npair  stx $d020               ; NTSC: 65 cycles per line
        stx $d021
        #delay55
        nop
        sty $d020
        sty $d021
        #delay47
        nop
        dec gcnt
        bne _npair
_below  lda #0                  ; black below the ground
        sta $d020
        inc frameFlag
        lda #TOPLINE-3
        sta $d012
        lda #0
        sta irqPhase
_out    pla
        tay
        pla
        tax
        pla
        rti
        .endp
Nmi:    rti

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        txa                     ; NTSC has fewer lines: a shorter ground
        bne +
        lda #9
        sta GroundPairs
+       txa                     ; the SID's pitch depends on the machine's clock
        bne +
        lda #<SidFreqLoN
        sta FreqTab
        lda #>SidFreqLoN
        sta FreqTab+1
+       rts

InitVideo:
        lda $dd02               ; VIC bank 0
        ora #3
        sta $dd02
        lda $dd00
        ora #3
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d017
        sta $d01b
        sta $d01c
        lda #$08
        sta $d016
        lda #$18                ; screen $0400, characters $2000
        sta $d018
        lda #$ff                ; every sprite double width: one 2600 pixel = two C64 pixels
        sta $d01d

        ; clear screen, colour RAM, characters and sprites
        ldx #0
        lda #0
-       sta SCREEN,x
        sta SCREEN+$100,x
        sta SCREEN+$200,x
        sta SCREEN+$2e8,x
        sta COLRAM,x
        sta COLRAM+$100,x
        sta COLRAM+$200,x
        sta COLRAM+$2e8,x
        inx
        bne -
        lda #<CHARSET
        sta ptrB
        lda #>CHARSET
        sta ptrB+1
        ldx #20                 ; $2000-$33FF: characters and sprites (the sprite blocks run
                                ; past $3000 into the copy of the 2600 program, no longer needed)
        ldy #0
        tya
-       sta (ptrB),y
        iny
        bne -
        inc ptrB+1
        dex
        bne -

        ; Digit pieces. Each 2-line block of a 2600 score digit has one lit line,
        ; the first (chars 1-15) or the second (chars 161-175); bits 0-3 of the
        ; character number are the blocks top to bottom.
        ldx #1
_piece  txa
        sta tmp
        asl
        asl
        asl
        sta ptrB
        lda #>CHARSET
        sta ptrB+1
        ldy #0
_p1     lsr tmp
        lda #0
        bcc +
        lda #$ff
+       sta (ptrB),y            ; first line of the pair
        iny
        iny
        cpy #8
        bne _p1
        inc ptrB+1              ; +5 pages = +160 characters: the second-line set
        inc ptrB+1
        inc ptrB+1
        inc ptrB+1
        inc ptrB+1
        txa
        sta tmp
        ldy #1
_p2     lsr tmp
        lda #0
        bcc +
        lda #$ff
+       sta (ptrB),y            ; second line of the pair
        iny
        iny
        cpy #9
        bne _p2
        inx
        cpx #16
        bne _piece
        lda #$ff                ; bottom row of a digit
        sta CHARSET + CH_SCOREBOT*8
        sta CHARSET + (CH_SCOREBOT+CH_SCORE2)*8 + 1
        ldx #5                  ; ground markers: 2600 pixels 33-34 and 122-123, lines 2-7 of row 24
-       lda #$3c
        sta CHARSET + CH_MARK0*8 + 2,x
        lda #$0f
        sta CHARSET + CH_MARK1*8 + 2,x
        dex
        bpl -
        lda #CH_MARK0
        sta SCREEN + 24*40 + 8
        lda #CH_MARK1
        sta SCREEN + 24*40 + 30

        jsr BuildShiftTables
        jsr BuildSprites

        lda #SPRBASE            ; all sprites blank to start
        ldx #7
-       sta SPRPTR,x
        dex
        bpl -
        rts

; Shift tables: for shift s (0-3) and 2600 byte g, the three C64 bytes of g
; with every bit doubled, moved right by 2s pixels. 12 pages, built once.
BuildShiftTables:
        lda #0
        sta tmp                 ; g
_g      ldx tmp
        txa
        lsr
        lsr
        lsr
        lsr
        tay
        lda Double,y
        sta v0
        txa
        and #15
        tay
        lda Double,y
        sta v1
        lda #0
        sta v2
        lda #>SHIFTTAB
        sta ptrB+1
        lda #0
        sta ptrB
        lda #4
        sta cnt
_s      ldy tmp                 ; store v0 v1 v2 into the three pages for this shift
        lda v0
        sta (ptrB),y
        inc ptrB+1
        lda v1
        sta (ptrB),y
        inc ptrB+1
        lda v2
        sta (ptrB),y
        inc ptrB+1
        lsr v0                  ; next shift: two pixels further right
        ror v1
        ror v2
        lsr v0
        ror v1
        ror v2
        dec cnt
        bne _s
        inc tmp
        bne _g
        rts

; Sprite shapes from the 2600 graphics in page $FC (10 lines, stored bottom-up)
BuildSprites:
        ldx #0                  ; the ball: one 2600 pixel wide, 1-11 lines
_ball   txa                     ; at the top of the sprite
        clc
        adc #BLK_BALL
        jsr BlockPtr
        ldy #0
        jsr _balllines
        txa                     ; at the bottom: from line 20 - height + 1
        clc
        adc #BLK_LOWBALL
        jsr BlockPtr
        txa
        eor #$ff
        clc
        adc #21                 ; 20 - x = first line
        sta tmp
        asl
        adc tmp
        tay
        jsr _balllines
        inx
        cpx #11
        bne _ball
        jmp _shapes
_balllines                      ; x+1 lines of $80 from byte Y of ptrB
        txa
        sta tmp
-       lda #$80
        sta (ptrB),y
        iny
        iny
        iny
        dec tmp
        bpl -
        rts
_shapes ldx #0
_shape  stx tmp
        lda ShapeLo,x
        sta ptrA
        lda #$fc
        sta ptrA+1
        txa                     ; destination block
        clc
        adc #BLK_SHAPES
        jsr BlockPtr
        lda #0
        ldy #0
        jsr CopyShape
        ldx tmp
        txa
        clc
        adc #BLK_LOW
        jsr BlockPtr
        lda #0
        ldy #LOWSHIFT*3
        jsr CopyShape
        ldx tmp
        cpx #3                  ; cannons also get a double-width version
        bcs +
        txa
        clc
        adc #BLK_WIDE
        jsr BlockPtr
        lda #1
        ldy #LOWSHIFT*3
        jsr CopyShape
        ldx tmp
+       inx
        cpx #ShapeCount
        bne _shape
        rts

BlockPtr:                       ; ptrB = SPRDATA + 64 * A
        ldy #0
        sty ptrB+1
        asl
        asl
        rol ptrB+1
        asl
        rol ptrB+1
        asl
        rol ptrB+1
        asl
        rol ptrB+1
        asl
        rol ptrB+1
        sta ptrB
        lda ptrB+1
        clc
        adc #>SPRDATA
        sta ptrB+1
        rts

CopyShape:                      ; ptrA = 2600 graphics, ptrB = sprite block, A = 1 for double
        sta tmp2                ; width, Y = first byte (3 x first line)
        sty lineIdx
        lda #9
        sta srcIdx
-       ldy srcIdx
        lda (ptrA),y
        ldy lineIdx
        ldx tmp2
        bne +
        sta (ptrB),y
        jmp ++
+       pha
        lsr
        lsr
        lsr
        lsr
        tax
        lda Double,x
        sta (ptrB),y
        pla
        and #15
        tax
        lda Double,x
        iny
        sta (ptrB),y
+       lda lineIdx
        clc
        adc #3
        sta lineIdx
        dec srcIdx
        bpl -
        rts

InitSound:
        lda #0
        ldx #$18
-       sta $d400,x
        dex
        bpl -
        lda #$0f
        sta $d418
        lda #$ff
        ldx #5
-       sta SndLast,x
        dex
        bpl -
        rts

; ================================================================== input
; Keyboard: W A S D + Space (player 1), I J K M + Return (player 2),
; F1 reset, F2 power off/on, F3 select, F5 colour/B&W, F7 / F8 left / right difficulty;
; fire also starts a game when none is running.
; Joysticks: port 2 = player 1, port 1 = player 2.
ReadInput:
        lda #$ff
        sta $dc02               ; port A output, port B input
        lda #0
        sta $dc03
        lda #$ff
        sta $dc00
        lda $dc00
        sta joyb                ; port 2
        lda $dc01
        sta joyb+1              ; port 1
        ldx #7
-       lda KeySelect,x
        sta $dc00
        lda $dc01
        sta Keys,x
        lda joyb+1              ; ignore lines a port 1 joystick is pulling low
        eor #$1f
        and #$1f
        ora Keys,x
        sta Keys,x
        dex
        bpl -
        lda #$ff
        sta $dc00

        lda #$ff                ; build SWCHA / INPT4 / INPT5
        sta outv
        lda #$80
        sta outv+1
        sta outv+2
        ldx #0
_in     ldy InputMap,x          ; joystick
        lda joyb,y
        and InputMap+1,x
        beq +
        ldy InputMap+2,x        ; key
        lda Keys,y
        and InputMap+3,x
        bne ++
+       ldy InputMap+4,x
        lda outv,y
        and InputMap+5,x
        sta outv,y
+       txa
        clc
        adc #6
        tax
        cpx #InputMapEnd-InputMap
        bne _in
        lda outv
        and DbgSWCHA            ; debug overrides, poked from the VICE monitor by tools
        sta SWCHA
        lda outv+1
        and DbgINPT4
        sta INPT4
        lda outv+2
        sta INPT5

        ; F: shot flicker on / off (on key-down)
        lda Keys+2
        and #$20
        bne +
        lda PrevKeyF
        and #$20
        beq +
        lda Flicker
        eor #1
        sta Flicker
+       lda Keys+2
        sta PrevKeyF

        ; console switches
        lda Keys+0              ; F5: colour / B&W (on key-down)
        and #$40
        bne +
        lda PrevKeys
        and #$40
        beq +
        lda switches
        eor #$08
        sta switches
+       lda Keys+0              ; F7 / F8: difficulty
        and #$08
        bne +
        lda PrevKeys
        and #$08
        beq +
        lda Keys+1              ; with either shift key (F8): right difficulty
        bpl _right
        lda Keys+6
        and #$10
        beq _right
        lda #$40                ; F7: left difficulty
        bne _tog
_right  lda #$80
_tog    eor switches
        sta switches
+       lda Keys+0
        sta PrevKeys

        ; C64 extra: fire starts a game when none is running (the 2600 needs
        ; Game Reset). Only a fresh press counts, and only after a second with no
        ; game, so firing as the last cannon dies doesn't skip the game-over screen.
        lda INPT4
        and INPT5               ; bit 7 clear: a fire button is down
        tax
        eor #$80
        and PrevFire            ; bit 7 set: down now, up last frame
        stx PrevFire
        ldx AttractCol
        bne +
        stx IdleFrames          ; a game is running
        stx FireStart
        beq _sw
+       ldx IdleFrames
        inx
        beq +                   ; stop counting at 255
        stx IdleFrames
+       tax
        bpl _sw
        lda IdleFrames
        cmp #50
        bcc _sw
        lda #6                  ; hold Game Reset a few frames: the game reads it every other tick
        sta FireStart

_sw     jsr PowerKey
        lda switches            ; reset (F1) and select (F3) are held buttons
        and #$fc
        sta tmp
        lda FireStart
        beq +
        dec FireStart
        bpl _f3                 ; fire start: reset down
+       lda f2now               ; F1 is Game Reset (F2, on the same key, is the power switch)
        bne _rup
        lda Keys+0
        and #$10
        beq _f3
_rup    inc tmp                 ; bit 0 up
_f3     lda Keys+0
        and #$20
        beq +
        lda tmp
        ora #2
        sta tmp
+       lda tmp
        and DbgSWCHB
        sta SWCHB
        rts

; ============================================================== collisions
; The 2600 kernel latched these collisions while drawing. We work them out
; from the same geometry. Only the shot pair drawn this frame counts: lasers
; on odd FrameTimer frames, bombs on even ones (the 2600 alternates them).
Collide:
        lda #0
        sta HitFlags
        sta CXP0FB
        sta CXP1FB
        ldx #0
        lda FrameTimer
        lsr
        bcc +
        ldx #LaserY-BombY
+       stx pairOff
        lda #0
        sta objIdx
_obj    lda pairOff
        clc
        adc objIdx
        tax
        lda BombY,x
        jsr ShotLines           ; not on screen (or not fired)?
        bcc _next
        lda BombX,x
        sec
        sbc #2
        sta bx
        jsr HitInvaders
        jsr HitUfo
        jsr HitShields
        jsr HitCannons
_next   inc objIdx
        lda objIdx
        cmp #2
        bne _obj
        rts

; A = shot Y from the game. Carry set if the 2600 draws it; bTop/bBot = its
; first and last 2600 line. Normally 8 lines from 2Y + 39, but in the cannon
; rows the kernel's line pattern is irregular and the ball stops at line 229.
ShotLines:
        cmp #$5f
        bcs _no
        cmp #$56
        bcs _zone
        asl
        adc #39
        sta bTop
        adc #7
        sta bBot
        sec
        rts
_zone   sbc #$56
        tay
        lda ZoneTop,y
        sta bTop
        lda ZoneBot,y
        sta bBot
        sec
        rts
_no     clc
        rts

; A = band top line, Y = band height. Carry set if the shot overlaps it;
; gLo/gHi = first/last overlapping line, counted from the band top.
Overlap:
        sta bandT
        dey
        tya
        clc
        adc bandT
        sta bandB
        lda bBot
        cmp bandT
        bcc _no
        lda bandB
        cmp bTop
        bcc _no
        lda bTop
        cmp bandT
        bcs +
        lda bandT
+       sec
        sbc bandT
        sta gLo
        lda bBot
        cmp bandB
        bcc +
        lda bandB
+       sec
        sbc bandT
        sta gHi
        sec
        rts
_no     clc
        rts

; acc = OR of the 10-line 2600 graphic at ptrA over lines gLo..gHi
; (2600 graphics are stored bottom-up: line g is byte 9 - g)
OrTen:
        lda #0
        sta acc
        lda #9
        sec
        sbc gLo
        tay
        lda gHi
        sec
        sbc gLo
        tax
-       lda (ptrA),y
        ora acc
        sta acc
        dey
        dex
        bpl -
        rts

HitInvaders:
        ldx #0
_row    lda Rows,x
        beq _nr
        lda RowTop,x            ; 2600 line of row x: 156 - 18x + 2 * RackY
        clc
        adc RackY
        bcs _nr
        adc RackY
        bcs _nr
        ldy #10
        jsr Overlap
        bcc _nr
        lda RackX               ; which column (16 pixels apart, 8 wide)
        sec
        sbc #1
        sta tmp
        lda bx
        sec
        sbc tmp
        bcc _nr
        sta dxv
        and #15
        cmp #8
        bcs _nr
        lda dxv
        lsr
        lsr
        lsr
        lsr
        cmp #6
        bcs _nr
        tay
        lda Bit,y
        and Rows,x
        beq _nr
        lda InvaderGfx,x        ; pixel test against the invader shape
        sec
        adc AnimFrame
        sta ptrA
        lda #$fc
        sta ptrA+1
        stx tmp2
        jsr OrTen
        ldx tmp2
        lda dxv
        and #7
        tay
        lda BitL,y
        and acc
        beq _nr
        lda Bit,x
        ora HitFlags
        sta HitFlags
_nr     inx
        cpx #6
        bne _row
        rts

HitUfo:
        jsr UfoShown
        bcc +
        lda #47
        ldy #10
        jsr Overlap
        bcc +
        jsr UfoShape
        sta ptrA
        lda #$fc
        sta ptrA+1
        ldy UfoX
        dey
        sty tmp
        lda bx
        sec
        sbc tmp
        cmp #8
        bcs +
        sta dxv
        jsr OrTen
        ldy dxv
        lda BitL,y
        and acc
        beq +
        lda HitFlags
        ora #$40
        sta HitFlags
+       rts

HitShields:
        bit PlayFlags
        bvc _done
        lda #192
        ldy #18
        jsr Overlap
        bcc _done
        ldy ShieldX
        dey
        sty tmp
        lda bx
        sec
        sbc tmp
        bcc _done
        sta dxv
        and #31
        cmp #8
        bcs _done
        lda dxv
        lsr
        lsr
        lsr
        lsr
        lsr
        cmp #3
        bcs _done
        tay
        lda Mul9,y
        sta tmp                 ; first byte of this shield
        lda #0
        sta acc
        ldx gLo
-       txa                     ; two lines per shield byte
        lsr
        clc
        adc tmp
        tay
        lda Shields,y
        ora acc
        sta acc
        inx
        cpx gHi
        beq -
        bcc -
        lda dxv
        and #7
        tay
        lda BitL,y
        and acc
        beq _done
        lda HitFlags
        ora #$80
        sta HitFlags
_done   rts

; (The ground markers are players too, but the 2600 never draws a shot that
; low, so they can't be hit.)
HitCannons:
        lda PlayFlags           ; no cannons once the invaders have landed
        bmi _done
        lda #220
        ldy #10
        jsr Overlap
        bcc _done
        jsr CannonShapes
        ldx #0
_can    lda cp1,x
        beq _nc
        sta ptrA
        lda #$fc
        sta ptrA+1
        ldy CannonX,x
        dey
        sty tmp
        lda bx
        sec
        sbc tmp
        bcc _nc
        sta dxv
        lda SWCHB               ; difficulty A = double-width cannon
        and WideBit,x
        beq +
        lsr dxv
+       lda dxv
        cmp #8
        bcs _nc
        stx tmp2
        jsr OrTen
        ldx tmp2
        ldy dxv
        lda BitL,y
        and acc
        beq _nc
        lda #$40
        sta CXP0FB,x
_nc     inx
        cpx #2
        bne _can
_done   rts

; ---------------------------------------------------------- shared helpers
; cp1/cp2 = low byte (page $FC) of each cannon's graphics this frame, 0 = hidden
CannonShapes:
        ldx #0
        ldy #0
        lda PlayFlags
        and #$10
        beq +
        ldx #$0a
+       lda PlayFlags
        and #$20
        beq +
        ldy #$0a
+       stx cp1
        sty cp2
        lda GameState
        lsr
        bcc _play
        lda FrameTimer          ; waiting to start: cannons blink
        and #8
        bne +
        lda #0
        sta cp1
        sta cp2
+       rts
_play   lda FrameTimer          ; hit cannons show their explosion
        lsr
        lsr
        lsr                     ; carry = FrameTimer bit 2 picks the frame
        lda GameState
        and #4
        beq _c2
        lda #$14
        bcc +
        lda #$1e
+       sta cp1
_c2     lda GameState
        and #2
        beq _done
        lda #$1e
        bcc +
        lda #$14
+       sta cp2
_done   rts

; carry set if the UFO is on screen (it replaces the scores while a game runs)
UfoShown:
        lda GameState
        bmi _no
        lda UfoX
        cmp #$b4
        beq _no
        sec
        rts
_no     clc
        rts

UfoShape:                       ; A = graphics low byte for the UFO or its explosion
        lda Explosion
        and #$39
        cmp #$39
        bne +
        lda Explosion
        rol
        rol
        rol
        and #3
        tay
        lda ExplodeGfx,y
        rts
+       lda #UfoGfx
        rts

; ================================================================= render
Render:
        inc FlickFrame          ; frame counter for the shot flicker
        ldx #7                  ; colours
-       lda Colors,x
        lsr
        tay
        lda ColorMap,y
        sta cCol,x
        dex
        bpl -
        ; Two different 2600 colours can map to the same C64 colour. If that
        ; hides something against the background, use a contrasting colour.
        ; (Identical 2600 colours stay identical: invisible invaders must hide.)
        ldx #7
-       cpx #6
        beq _nextc
        lda cCol,x
        cmp cBg
        bne _nextc
        lda Colors,x
        eor Colors+6
        and #$fe
        beq _nextc
        ldy cBg
        lda AltColor,y
        sta cCol,x
_nextc  dex
        bpl -
        lda cGround             ; the game's olive ground: dither brown and green lines
        ldx cGround
        ldy Colors+7
        cpy #$e2
        bne +
        .if GREENTOP
        lda #5                  ; green on the first line
        ldx #9                  ; brown on the next
        .else
        lda #9                  ; brown on the first line
        ldx #5                  ; green on the next
        .endif
+       sta GroundA
        stx GroundB
        jsr DrawSprites
        jsr DrawInvaders
        jsr DrawShields
        jsr DrawScores
        jsr DrawLives
        lda cCan1               ; ground markers
        sta COLRAM + 24*40 + 8
        lda cCan2
        sta COLRAM + 24*40 + 30
        rts

; ------------------------------------------------------------ invaders
; Each row is one shape repeated at 16-pixel (4-character) steps, so a row needs
; just 9 characters (3 wide x up to 3 tall). A row's characters are rebuilt only
; when its shape, sub-character shift or height changes, and its screen cells
; only when it moves a whole character or loses an invader. Rows are done top
; first so the work stays ahead of the raster beam (no tearing).
DrawInvaders:
        lda cInv                ; new colour: repaint the invader area's colour RAM
        cmp InvColour
        beq +
        sta InvColour
        jsr PaintInvZone
        ldx #5
-       lda #$ff                ; and rewrite every row's cells
        sta PrevMask,x
        dex
        bpl -
+       lda RackY               ; the rack moved down: clear all old blocks first
        cmp PrevRackY
        beq +
        sta PrevRackY
        ldx #5
-       jsr EraseRow
        dex
        bpl -

+       ldx #5
_row    lda Rows,x
        beq _erase
        lda RackY               ; screen line = 119 - 18 * row + 2 * RackY
        asl
        clc
        adc RowScreen,x
        bcs _erase
        cmp #191
        bcc _layout
_erase  jsr EraseRow
        jmp _next

_layout pha
        and #7
        sta voff
        pla
        lsr
        lsr
        lsr
        sta crow
        lda voff
        clc
        adc #9
        lsr
        lsr
        lsr
        clc
        adc #1
        sta nrows
        ldy RackX
        dey
        tya
        and #3
        sta shift
        tya
        lsr
        lsr
        sta ccol

        lda InvChar,x           ; characters
        jsr CharPtr
        lda PrevN,x
        beq _clear
        lda voff
        cmp PrevVoff,x
        bne _clear
        lda shift
        cmp PrevShift,x
        bne _plot
        lda AnimFrame
        cmp PrevAnim,x
        beq _cells
        bne _plot
_clear  jsr ClearStrips         ; lines move: start from blank characters
_plot   lda InvaderGfx,x
        sec
        adc AnimFrame
        sta ptrA
        lda #$fc
        sta ptrA+1
        jsr ShiftPtrs
        lda #9
        sta srcIdx
        lda voff
        sta lineIdx
-       ldy srcIdx
        lda (ptrA),y
        jsr PlotStrips
        inc lineIdx
        dec srcIdx
        bpl -
        lda voff
        sta PrevVoff,x
        lda shift
        sta PrevShift,x
        lda AnimFrame
        sta PrevAnim,x

_cells  lda PrevN,x             ; screen cells
        beq _write
        lda ccol
        cmp PrevCol,x
        bne _move
        lda Rows,x
        cmp PrevMask,x
        beq _next
        bne _write
_move   jsr EraseRow
_write  jsr WriteRow
_next   dex
        bmi +
        jmp _row
+       rts

; Write row X's block of cells at (crow, ccol): one 3-wide block per live
; invader, blanks elsewhere, `nrows` character rows tall.
WriteRow:
        lda Rows,x              ; template for character row 0
        sta mask
        ldy #0
_t      lsr mask
        bcs _alive
        lda #0                  ; dead invader: blank cells
        sta Tmpl,y
        sta Tmpl+1,y
        sta Tmpl+2,y
        beq _gap
_alive  lda InvChar,x
        sta Tmpl,y
        clc
        adc #3
        sta Tmpl+1,y
        adc #3
        sta Tmpl+2,y
_gap    lda #0
        sta Tmpl+3,y
        tya
        clc
        adc #4
        tay
        cpy #24
        bne _t
        lda #40
        sec
        sbc ccol
        cmp #24
        bcc +
        lda #24
+       sta width
        ldy crow
        lda RowLo,y
        clc
        adc ccol
        sta ptrC
        lda RowHi,y
        adc #0
        sta ptrC+1
        lda #0
        sta jIdx
_j      ldy #0
-       lda Tmpl,y
        beq +
        clc
        adc jIdx
+       sta (ptrC),y
        iny
        cpy width
        bne -
        lda crow                ; above the shields the colour is pre-painted
        clc
        adc jIdx
        cmp #19
        bcc +
        jsr PaintCells
        lda #1
        sta ShieldDirty
        sta LivesDirty
+       lda ptrC
        clc
        adc #40
        sta ptrC
        bcc +
        inc ptrC+1
+       inc jIdx
        lda jIdx
        cmp nrows
        bne _j
        lda crow
        sta PrevRow,x
        lda ccol
        sta PrevCol,x
        lda nrows
        sta PrevN,x
        lda Rows,x
        sta PrevMask,x
        rts

; colour `width` cells at ptrC with the invader colour
PaintCells:
        lda ptrC
        sta ptrD
        lda ptrC+1
        clc
        adc #>(COLRAM-SCREEN)
        sta ptrD+1
        ldy width
        dey
        lda cInv
-       sta (ptrD),y
        dey
        bpl -
        rts

; Remove row X's old block from the screen. Keeps X.
EraseRow:
        lda PrevN,x
        beq _done
        sta cnt
        ldy PrevRow,x
        clc
        adc PrevRow,x
        cmp #20
        bcc +
        lda #1
        sta ShieldDirty
        sta LivesDirty
+       lda RowLo,y
        clc
        adc PrevCol,x
        sta ptrC
        lda RowHi,y
        adc #0
        sta ptrC+1
        lda #40
        sec
        sbc PrevCol,x
        cmp #24
        bcc +
        lda #24
+       sta width
        jsr ClearRect
        lda #0
        sta PrevN,x
_done   rts

; colour RAM rows 3-18 (where invaders fly above the shields) = invader colour
PaintInvZone:
        lda #<(COLRAM + 3*40)
        sta ptrD
        lda #>(COLRAM + 3*40)
        sta ptrD+1
        ldx #16
-       ldy #39
        lda cInv
-       sta (ptrD),y
        dey
        bpl -
        lda ptrD
        clc
        adc #40
        sta ptrD
        bcc +
        inc ptrD+1
+       dex
        bne --
        rts

; ptrB = CHARSET + 8 * A
CharPtr:
        ldy #0
        sty ptrB+1
        asl
        rol ptrB+1
        asl
        rol ptrB+1
        asl
        rol ptrB+1
        sta ptrB
        lda ptrB+1
        clc
        adc #>CHARSET
        sta ptrB+1
        rts

ClearStrips:                    ; zero the 72 bytes at ptrB
        ldy #71
        lda #0
-       sta (ptrB),y
        dey
        bpl -
        rts

ShiftPtrs:                      ; t0-t2 = shift-table pages for `shift`
        lda shift
        asl
        adc shift
        adc #>SHIFTTAB
        sta t0+1
        adc #1
        sta t1+1
        adc #1
        sta t2+1
        lda #0
        sta t0
        sta t1
        sta t2
        rts

; A = 2600 graphics byte: write it, doubled and shifted, into line lineIdx
; of the three 24-line character strips at ptrB. Keeps X.
PlotStrips:
        tay
        lda (t0),y
        sta v0
        lda (t1),y
        sta v1
        lda (t2),y
        sta v2
        ldy lineIdx
        lda v0
        sta (ptrB),y
        tya
        clc
        adc #24
        tay
        lda v1
        sta (ptrB),y
        tya
        adc #24
        tay
        lda v2
        sta (ptrB),y
        rts

; Put a 3x(nrows) character block at each set bit of `mask`, starting at
; screen (crow, ccol), `tmp` characters apart. Block characters are numbered
; baseCh + 3 * column + row. Keeps X.
PlaceCopies:
        ldy crow
        lda RowLo,y
        clc
        adc ccol
        sta ptrC
        sta ptrD
        lda RowHi,y
        adc #0
        sta ptrC+1
        adc #>(COLRAM-SCREEN)
        sta ptrD+1
        lda #0
        sta colOff
_copy   lsr mask
        bcc _skip
        lda #0
        sta jIdx
-       ldy jIdx
        lda Mul40,y
        clc
        adc colOff
        tay
        lda baseCh
        clc
        adc jIdx
        sta (ptrC),y
        adc #3
        iny
        sta (ptrC),y
        adc #3
        iny
        sta (ptrC),y
        lda colour
        sta (ptrD),y
        dey
        sta (ptrD),y
        dey
        sta (ptrD),y
        inc jIdx
        lda jIdx
        cmp nrows
        bcc -
_skip   lda colOff
        clc
        adc tmp
        sta colOff
        lda mask
        bne _copy
        rts

; Clear `cnt` screen rows of `width` characters from ptrC. Keeps X.
ClearRect:
-       ldy width
        dey
        lda #0
-       sta (ptrC),y
        dey
        bpl -
        lda ptrC
        clc
        adc #40
        sta ptrC
        bcc +
        inc ptrC+1
+       dec cnt
        bne --
        rts

; ------------------------------------------------------------ shields
; Three 8-pixel shields 32 pixels apart, 2 lines per byte, from line 192
; (screen row 19, line 3). A shield's characters are rebuilt when its bitmap
; or the sub-character shift changes; cells are rewritten when the shields
; move a whole character, change colour, or invaders have drawn over them.
DrawShields:
        bit PlayFlags
        bvs +
        lda ShPrevN             ; gone (the invaders got down to them)
        beq _done
        jsr EraseShields
_done   rts
+       ldy ShieldX
        dey
        tya
        and #3
        sta shift
        tya
        lsr
        lsr
        sta ccol
        jsr ShiftPtrs
        lda shift
        cmp ShShift
        beq +
        sta ShShift
        lda #1                  ; every shield needs new characters
        sta ShRebuild
        sta ShRebuild+1
        sta ShRebuild+2
+       ldx #0                  ; shield number
_sh     lda Mul9,x
        tay
        lda #9
        sta cnt
-       lda Shields,y           ; bitmap changed?
        cmp ShKey,y
        beq +
        sta ShKey,y
        lda #1
        sta ShRebuild,x
+       iny
        dec cnt
        bne -
        lda ShRebuild,x
        beq _nsh
        lda #0
        sta ShRebuild,x
        lda ShChar,x
        jsr CharPtr
        lda Mul9,x
        sta tmp2
        lda #3
        sta lineIdx
        lda #9
        sta cnt
-       ldy tmp2
        lda Shields,y
        pha
        jsr PlotStrips
        inc lineIdx
        pla
        jsr PlotStrips
        inc lineIdx
        inc tmp2
        dec cnt
        bne -
_nsh    inx
        cpx #3
        bne _sh

        lda ShPrevN             ; cells
        beq _place
        lda ShieldDirty
        bne _redo
        lda cShield
        cmp ShColour
        bne _redo
        lda ccol
        cmp ShPrevCol
        beq _out
_redo   jsr EraseShields
_place  lda #0
        sta ShieldDirty
        lda cShield
        sta ShColour
        sta colour
        lda #19
        sta crow
        lda #3
        sta nrows
        ldx #0
-       lda ShChar,x            ; each shield has its own characters
        sta baseCh
        lda #1
        sta mask
        lda #0
        sta tmp
        lda ccol
        pha
        clc
        adc Mul8,x
        sta ccol
        jsr PlaceCopies
        pla
        sta ccol
        inx
        cpx #3
        bne -
        lda ccol
        sta ShPrevCol
        lda #3
        sta ShPrevN
_out    rts

EraseShields:
        lda ShPrevN
        sta cnt
        ldy #19
        lda RowLo,y
        clc
        adc ShPrevCol
        sta ptrC
        lda RowHi,y
        adc #0
        sta ptrC+1
        lda #19
        sta width
        jsr ClearRect
        lda #0
        sta ShPrevN
        rts

; ------------------------------------------------------------ scores
; Big 3x5 digits, each block one character wide and two lines tall (one of
; them lit, giving the 2600's striped look), on character rows 1-2. Hidden while the UFO is flying during a game.
DrawScores:
        ldx #3
-       lda ScoreHi,x
        sta KeyNew,x
        dex
        bpl -
        lda cCan1               ; score mode: each score in its player's colour
        sta KeyNew+4
        lda cCan2
        sta KeyNew+5
        jsr UfoShown
        lda #0
        rol
        sta KeyNew+6
        ldx #6
        ldy #0
-       lda KeyNew,x
        cmp ScKey,x
        beq +
        sta ScKey,x
        iny
+       dex
        bpl -
        tya
        bne +
        rts
+       ldx #7                  ; digit 0-7: player 1 is digits 0-3
_dig    lda DigitCol,x
        sta ccol
        lda cCan1
        cpx #4
        bcc +
        lda cCan2
+       sta colour
        lda DigitSet,x          ; which set of digit pieces (which scan line is lit)
        sta baseCh
        lda #10                 ; 10 = blank
        ldy KeyNew+6
        bne _draw
        ldy DigitByte,x         ; digit value from the BCD scores
        lda ScoreHi,y
        sta tmp
        txa
        lsr                     ; odd digits are low nibbles
        lda tmp
        bcs +
        lsr
        lsr
        lsr
        lsr
+       and #15
_draw   jsr DrawDigit
        dex
        bpl _dig
        rts

; draw digit A at character column ccol, rows 1-2. Keeps X.
DrawDigit:
        sta tmp                 ; glyph = $FF54 + 5 * digit, top row last
        asl
        asl
        adc tmp
        adc #$54
        sta ptrA
        lda #$ff
        sta ptrA+1
        lda #$20                ; glyph columns are bits 5, 6, 7 (left to right)
        sta mask
        ldy ccol
        sty tmp2
_col    lda #0
        sta acc
        ldy #4                  ; rows top (byte 4) to byte 1 make bits 0-3
-       lda (ptrA),y
        and mask
        cmp #1
        ror acc
        dey
        bne -
        lsr acc                 ; acc bits 7-4 -> 3-0
        lsr acc
        lsr acc
        lsr acc
        ldy tmp2
        lda acc
        beq +
        clc
        adc baseCh
+       sta SCREEN + 40,y
        lda colour
        sta COLRAM + 40,y
        sta COLRAM + 80,y
        ldy #0
        lda (ptrA),y
        and mask
        beq +
        lda #CH_SCOREBOT
        clc
        adc baseCh
+       ldy tmp2
        sta SCREEN + 80,y
        inc tmp2
        asl mask
        bcc _col
        rts

; ------------------------------------------------------------ lives
; While a player waits to start, the 2600 shows lives left as a big digit
; at pixels 84-95, lines 220-229.
DrawLives:
        lda PlayFlags
        bmi _hide
        lda GameState
        lsr
        bcc _hide
        lda Lives
        cmp #4
        bcc +
        lda #3
+       tax
        lda LivesGfx,x
        jmp +
_hide   lda #0
+       sta KeyNew
        lda cCan2
        sta KeyNew+1
        lda KeyNew
        cmp LvKey
        bne +
        lda KeyNew+1
        cmp LvKey+1
        bne +
        lda LivesDirty
        bne +
        rts
+       lda KeyNew
        sta LvKey
        lda KeyNew+1
        sta LvKey+1
        lda #0
        sta LivesDirty
        lda LvKey
        bne +
        ldx #2                  ; hidden: clear the 3x3 block
-       lda #0
        sta SCREEN + 22*40 + 21,x
        sta SCREEN + 23*40 + 21,x
        sta SCREEN + 24*40 + 21,x
        dex
        bpl -
        rts
+       sta ptrA
        lda #$ff
        sta ptrA+1
        lda #CH_LIVES
        jsr CharPtr
        jsr ClearStrips
        lda #$20
        sta mask
        lda #0
        sta tmp2                ; strip offset
_col    ldy #4
        lda #7
        sta lineIdx
-       lda (ptrA),y
        and mask
        beq +
        lda #$ff
+       sty tmp
        pha
        lda lineIdx
        clc
        adc tmp2
        tay
        pla
        sta (ptrB),y
        iny
        sta (ptrB),y
        ldy tmp
        inc lineIdx
        inc lineIdx
        dey
        bpl -
        lda tmp2
        clc
        adc #24
        sta tmp2
        asl mask
        bcc _col
        lda #22
        sta crow
        lda #21
        sta ccol
        lda #3
        sta nrows
        lda #1
        sta mask
        lda #CH_LIVES
        sta baseCh
        lda cCan2
        sta colour
        jmp PlaceCopies

; ------------------------------------------------------------ sprites
DrawSprites:
        lda #0
        sta sprOn
        sta sprMsb

        lda PlayFlags           ; cannons
        bmi _ufo
        jsr CannonShapes
        ldx #0
_can    lda cp1,x
        beq _nc
        jsr ShapeBlock
        clc
        adc #BLK_LOW-BLK_SHAPES  ; bottom-aligned (they sit right above the ground)
        sta tmp
        lda SWCHB
        and WideBit,x
        beq +
        lda tmp                 ; difficulty A: double width
        clc
        adc #BLK_WIDE-BLK_LOW
        sta tmp
+       lda tmp
        ldy #220-LINEOFS+SPRY-LOWSHIFT
        sty tmp2
        ldy CannonX,x
        dey
        tya
        ldy cCan1,x
        jsr PutSprite
_nc     inx
        cpx #2
        bne _can

_ufo    jsr UfoShown
        bcc _shots
        jsr UfoShape
        jsr ShapeBlock
        sta tmp
        lda #47-LINEOFS+SPRY
        sta tmp2
        ldy UfoX
        dey
        tya
        ldx #SP_UFO
        ldy cUfo
        jsr PutSprite

_shots  ldx #0                  ; bombs then lasers: sprites 5,6 then 3,4
_shot   lda Flicker             ; like the 2600: bombs on even frames, lasers on odd
        beq _show
        lda FlickFrame
        cpx #4
        bcc +
        eor #1                  ; lasers: the other frames
+       and #1
        bne _ns
_show   lda BombY,x
        jsr ShotLines
        bcc _ns
        lda bBot                ; sprite as tall as the 2600 draws it
        sec
        sbc bTop
        sta tmp
        lda bTop
        cmp #140
        bcs _low
        clc                     ; upper screen: shape at the top of the sprite
        adc #SPRY-LINEOFS
        sta tmp2
        lda tmp
        adc #BLK_BALL
        sta tmp
        bne _put
_low    lda bBot                ; lower screen: at the bottom, ending on the shot's last line
        clc
        adc #<(SPRY-LINEOFS-20)   ; (negative: wraps as a byte)
        sta tmp2
        lda tmp
        clc
        adc #BLK_LOWBALL
        sta tmp
_put
        lda BombX,x
        sec
        sbc #2
        pha
        lda ShotSprite,x
        stx v0
        tax
        pla
        ldy cBall
        jsr PutSprite
        ldx v0
_ns     inx
        cpx #2
        bne +
        ldx #4
+       cpx #6
        bne _shot

        lda Explosion           ; exploding invader
        lsr
        lsr
        lsr
        and #7
        cmp #6
        bcs _done
        tax
        lda RowsLeft            ; only rows the 2600 still draws
        bmi _done
        clc
        adc RowIdx,x            ; row + RowsLeft >= 5
        cmp #5
        bcc _done
        lda RackY
        asl
        clc
        adc RowScreen,x
        bcs _done
        adc #SPRY-LOWSHIFT      ; bottom-aligned: rows can come down to the ground
        sta tmp2
        lda Explosion
        rol
        rol
        rol
        and #3
        tay
        lda ExplodeGfx,y
        jsr ShapeBlock
        clc
        adc #BLK_LOW-BLK_SHAPES
        sta tmp
        lda Explosion
        and #7
        asl
        asl
        asl
        asl
        clc
        adc RackX
        sec
        sbc #1
        ldx #SP_EXPLODE
        ldy cInv
        jsr PutSprite

_done   lda sprMsb
        sta $d010
        lda sprOn
        sta $d015
        rts

; Show sprite X: A = 2600 x pixel, tmp = block, tmp2 = Y register, Y = colour. Keeps X.
PutSprite:
        sta v1
        tya                     ; colour registers only on change: writing one while
        cmp SprCol,x            ; the screen is drawn can leave a dot on newer C64s
        beq +
        sta SprCol,x
        sta $d027,x
+
        lda tmp
        clc
        adc #SPRBASE
        sta SPRPTR,x
        txa
        asl
        tay
        lda tmp2
        sta $d001,y
        lda #0
        sta v2
        lda v1
        asl                     ; 24 + 2x
        rol v2
        clc
        adc #24
        sta $d000,y
        bcc +
        inc v2
+       lda v2
        beq +
        lda Bit,x
        ora sprMsb
        sta sprMsb
+       lda Bit,x
        ora sprOn
        sta sprOn
        rts

; A = 2600 graphics low byte (page $FC) -> sprite block number
ShapeBlock:
        ldy #ShapeCount-1
-       cmp ShapeLo,y
        beq +
        dey
        bpl -
        lda #0
        rts
+       tya
        clc
        adc #BLK_SHAPES
        rts

; =================================================================== sound
; The game writes TIA sound registers (AUDC, AUDF, AUDV for two channels);
; play the nearest thing on SID voices 1 and 2.
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        beq _off
        ldy v1
        lda SidWave,y
        beq _off2
        sta tmp                 ; waveform
        lda v1                  ; frequency index = AUDC * 32 + AUDF
        lsr
        lsr
        lsr
        sta ptrS+1
        lda v1
        asl
        asl
        asl
        asl
        asl
        ora v2
        clc
        adc FreqTab
        sta ptrS
        lda ptrS+1
        adc FreqTab+1
        sta ptrS+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrS),y
        ldy tmp2
        sta $d400,y
        inc ptrS+1
        inc ptrS+1
        ldy #0
        lda (ptrS),y
        ldy tmp2
        sta $d401,y
        lda #0
        sta $d402,y
        sta $d405,y
        lda #8
        sta $d403,y
        lda v0                  ; volume becomes the sustain level
        asl
        asl
        asl
        asl
        sta $d406,y
        lda v0                  ; retrigger only when volume or waveform changes
        cmp SndLast,x
        bne +
        lda v1
        cmp SndLast+2,x
        beq _save
+       lda tmp
        sta $d404,y
        ora #1
        sta $d404,y
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts

; ================================================================== tables
Double:     .byte $00, $03, $0c, $0f, $30, $33, $3c, $3f, $c0, $c3, $cc, $cf, $f0, $f3, $fc, $ff
Bit:        .byte $01, $02, $04, $08, $10, $20, $40, $80
BitL:       .byte $80, $40, $20, $10, $08, $04, $02, $01
Mul9:       .byte 0, 9, 18
Mul8:       .byte 0, 8, 16
Mul40:      .byte 0, 40, 80
RowTop:     .byte 156, 138, 120, 102, 84, 66          ; 2600 line of each row with RackY = 0
RowScreen:  .byte 156-LINEOFS, 138-LINEOFS, 120-LINEOFS, 102-LINEOFS, 84-LINEOFS, 66-LINEOFS
RowIdx:     .byte 0, 1, 2, 3, 4, 5
InvChar:    .byte CH_INV, CH_INV+9, CH_INV+18, CH_INV+27, CH_INV+36, CH_INV+45
ShChar:     .byte CH_SHIELD, CH_SHIELD+9, CH_SHIELD+18
DigitCol:   .byte 1, 5, 9, 13, 21, 25, 29, 33
DigitByte:  .byte 0, 0, 2, 2, 1, 1, 3, 3                ; offset from ScoreHi for each digit
; The 2600's score loop lights the outer digits of each score on one line and
; the middle two on the next, so those sit one line lower.
DigitSet:   .byte 0, CH_SCORE2, CH_SCORE2, 0, 0, CH_SCORE2, CH_SCORE2, 0
WideBit:    .byte $40, $80
ShotSprite: .byte SP_BOMB, SP_BOMB+1, 0, 0, SP_LASER, SP_LASER+1
SidVoice:   .byte 0, 7
KeySelect:  .byte $fe, $fd, $fb, $f7, $ef, $df, $bf, $7f
; graphics low bytes in page $FC that become sprites: cannon, cannon hit x2, UFO, explosions
ZoneTop:    .byte 211, 212, 215, 217, 221, 223, 225, 227, 229   ; shot Y $56-$5E
ZoneBot:    .byte 220, 222, 224, 226, 228, 229, 229, 229, 229
ShapeLo:    .byte $0a, $14, $1e, UfoGfx, $aa, $b6, $c0, $cc
ShapeCount = * - ShapeLo

; joystick port (0 = port 2, 1 = port 1), joystick bit, key row, key bit,
; output (0 SWCHA, 1 INPT4, 2 INPT5), AND mask for the output
InputMap:
        .byte 0, $01, 1, $02, 0, $ef    ; P1 up:    W
        .byte 0, $02, 1, $20, 0, $df    ; P1 down:  S
        .byte 0, $04, 1, $04, 0, $bf    ; P1 left:  A
        .byte 0, $08, 2, $04, 0, $7f    ; P1 right: D
        .byte 0, $10, 7, $10, 1, $7f    ; P1 fire:  Space
        .byte 1, $01, 4, $02, 0, $fe    ; P2 up:    I
        .byte 1, $02, 4, $20, 0, $fd    ; P2 down:  K
        .byte 1, $04, 4, $04, 0, $fb    ; P2 left:  J
        .byte 1, $08, 5, $04, 0, $f7    ; P2 right: L
        .byte 1, $10, 0, $02, 2, $7f    ; P2 fire:  Return
InputMapEnd:


; ------------------------------------------------------- variables (RAM)
DbgSWCHA:   .byte $ff          ; AND masks applied to the inputs (testing aid)
DbgINPT4:   .byte $ff
DbgSWCHB:   .byte $ff
DbgBorder:  .byte 0            ; non-zero: colour the border while drawing / running the game
FreqTab:    .word SidFreqLo     ; PAL or NTSC frequency tables
GroundPairs: .byte 14            ; ground lines / 2 (the 2600 draws 28)
GroundA:    .byte 0             ; ground colours for even / odd lines
GroundB:    .byte 0
irqPhase:   .byte 0
SprCol:     .fill 8, $ff
Flicker:    .byte 1             ; 1: shots flicker like the 2600 (key F toggles)
FlickFrame: .byte 0
PrevKeyF:   .byte $ff
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
PrevFire:   .byte $ff           ; INPT4 AND INPT5 last frame
IdleFrames: .byte 0             ; frames with no game running (stops at 255)
FireStart:  .byte 0             ; frames left holding Game Reset after fire started a game
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0
KeyNew:     .fill 10
; invader rows as last drawn
InvColour:  .byte $ff
PrevRackY:  .byte $ff
PrevRow:    .fill 6
PrevCol:    .fill 6
PrevN:      .fill 6         ; character rows on screen, 0 = not drawn
PrevMask:   .fill 6
PrevVoff:   .fill 6
PrevShift:  .fill 6
PrevAnim:   .fill 6
Tmpl:       .fill 24
; shields as last drawn
ShKey:      .fill 27, $ff
ShShift:    .byte $ff
ShRebuild:  .fill 3, 1
ShColour:   .byte $ff
ShPrevCol:  .byte 0
ShPrevN:    .byte 0
ShieldDirty: .byte 1
ScKey:      .fill 7, $ff
LvKey:      .byte $ff, $ff
LivesDirty: .byte 1
SndLast:    .fill 6, $ff

        .cerror * > CHARSET, "code runs into the character set"

; ======================================================= the 2600 program
; The original ROM, with three patches:
;   $F4CF  JMP $F4DA   skip the wait for the 2600 timer and the VBLANK write
;   $F50C  JMP $F521   skip VSYNC (writing $00/$01 would remap C64 memory)
;   $FA43  JMP TickDone  stop where the 2600 would start drawing the screen
ROM = "../build/original.a26"     ; extracted from roms_port by build.cmd
        * = $3000
GameImage:
        .binary ROM, $0000, $04cf
        jmp $f4da
        .binary ROM, $04d2, $050c-$04d2
        jmp $f521
        .binary ROM, $050f, $0a43-$050f
        jmp TickDone
        .binary ROM, $0a46, $1000-$0a46
        .cerror * != GameImage + $1000, "game image is not 4K"

        .include "tables.inc"   ; generated by tools/mkc64tables.js (this game's tools)
        .cerror * > SHIFTTAB, "tables run into the shift tables"
