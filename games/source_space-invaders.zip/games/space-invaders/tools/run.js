// Quick runner: boot the ROM, optionally press RESET, step frames, save screenshots.
//   node games/space-invaders/tools/run.js <frames> [out.png]
const fs = require('fs');
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('72ffbef6504b75e69ee1045af9075f66'));
let lines = 0;
vcs.onFrame = v => { lines = v.line; };
const frames = +(process.argv[2] || 60);
vcs.runFrames(frames);
console.log('frames', vcs.frames, 'lines/frame', lines, 'cycles', vcs.cycles);
const hex = (b) => [...b].map(x => x.toString(16).padStart(2, '0')).join(' ');
for (let i = 0; i < 128; i += 16) console.log((0x80 + i).toString(16), hex(vcs.ram.subarray(i, i + 16)));
if (process.argv[3]) { vcs.savePNG(process.argv[3]); console.log('saved', process.argv[3]); }
