// Dump where each TIA object is drawn (scanline, x runs) for chosen frames,
// next to the RAM values that control them. Used to derive the C64 layout.
//   node games/space-invaders/tools/geometry.js
const fs = require('fs');
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('72ffbef6504b75e69ee1045af9075f66'));
const R = a => vcs.ram[a - 0x80];
const h = v => v.toString(16).padStart(2, '0');
const NAMES = { 1: 'P0', 2: 'P1', 16: 'BL', 32: 'PF' };

function dump(tag) {
  console.log(`\n== ${tag}  frame ${vcs.frames}  CA=${h(R(0xCA))} RackX=${h(R(0x9A))} RackY=${h(R(0x90))} ShieldX=${h(R(0x9B))} Cannon=${h(R(0x9C))},${h(R(0x9D))} Ufo=${h(R(0x9E))} ` +
    `Laser=${h(R(0xD5))}/${h(R(0xD7))} ${h(R(0xD6))}/${h(R(0xD8))} Bomb=${h(R(0xD1))}/${h(R(0xD3))} ${h(R(0xD2))}/${h(R(0xD4))} Rows=${[0, 1, 2, 3, 4, 5].map(i => h(R(0x92 + i))).join('')} Expl=${h(R(0xC8))} Anim=${h(R(0x8B))}`);
  let first = -1;
  for (let y = 0; y < 262; y++) {
    const runs = [];
    for (const bit of [1, 2, 16, 32]) {
      let x = 0;
      while (x < 160) {
        if (vcs.ob[y * 160 + x] & bit) { const s = x; while (x < 160 && (vcs.ob[y * 160 + x] & bit)) x++; runs.push(`${NAMES[bit]}:${s}-${x - 1}`); }
        else x++;
      }
    }
    if (runs.length) { if (first < 0) first = y; console.log(String(y).padStart(3), runs.join(' ')); }
  }
}

// Capture the frame at the moment VSYNC ends (framebuffer holds the finished frame)
let captured = null;
vcs.onFrame = v => { if (captured) captured(); };
const frameDump = (tag) => { captured = () => { dump(tag); captured = null; }; vcs.runFrames(1); };

vcs.runFrames(30);
vcs.swchb &= ~1; vcs.runFrames(4); vcs.swchb |= 1;
vcs.runFrames(120);
frameDump('playing, no shots');
vcs.fire[0] = true; vcs.runFrames(2); vcs.fire[0] = false;
vcs.runFrames(3);
frameDump('laser A'); frameDump('laser B');
vcs.runFrames(10);
frameDump('laser C'); frameDump('laser D');
