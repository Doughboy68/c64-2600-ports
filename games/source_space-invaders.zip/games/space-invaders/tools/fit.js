// Play a long random game and fit "screen position = RAM value + offset" for every object.
// Prints a histogram of offsets per object; a single dominant value means the formula holds.
//   node games/space-invaders/tools/fit.js [frames]
const fs = require('fs');
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('72ffbef6504b75e69ee1045af9075f66'));
const R = a => vcs.ram[a - 0x80];
const stats = {};
const add = (k, v) => { (stats[k] = stats[k] || {})[v] = (stats[k][v] || 0) + 1; };

// Find vertical runs of an object bit: returns [{x0,x1,top,bottom}] merged by x range overlap
function blobs(bit, y0, y1) {
  const out = [];
  for (let y = y0; y < y1; y++) {
    let x = 0;
    while (x < 160) {
      if (!(vcs.ob[y * 160 + x] & bit)) { x++; continue; }
      const s = x; while (x < 160 && (vcs.ob[y * 160 + x] & bit)) x++;
      const b = out.find(o => o.bottom === y - 1 && o.x0 === s);
      if (b) b.bottom = y; else out.push({ x0: s, x1: x - 1, top: y, bottom: y });
    }
  }
  return out;
}
function leftmost(bit, y0, y1) {
  let best = 999;
  for (let y = y0; y < y1; y++) for (let x = 0; x < 160; x++) if (vcs.ob[y * 160 + x] & bit) { best = Math.min(best, x); break; }
  return best;
}

let snap = null;
vcs.onFrame = () => {
  const s = {};
  for (const a of [0xCA, 0x9A, 0x90, 0x9B, 0x9C, 0x9D, 0x9E, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0x98, 0xAA, 0xC8]) s[a] = R(a);
  s.rows = [0, 1, 2, 3, 4, 5].map(i => R(0x92 + i));
  // The framebuffer holds the frame drawn from the *previous* snapshot's state
  if (snap) analyse(snap);
  snap = s;
};

function analyse(s) {
  // ---- ball: lasers on odd CA, bombs on even
  const odd = s[0xCA] & 1;
  const ys = odd ? [s[0xD5], s[0xD6]] : [s[0xD1], s[0xD2]];
  const xs = odd ? [s[0xD7], s[0xD8]] : [s[0xD3], s[0xD4]];
  for (const b of blobs(16, 0, 262)) {
    for (let i = 0; i < 2; i++) {
      if (ys[i] >= 0xEC) continue;
      const dx = b.x0 - xs[i];
      if (dx < -4 || dx > 4) continue;
      add(`${odd ? 'laser' : 'bomb'} x-X`, dx);
      add(`${odd ? 'laser' : 'bomb'} top-2Y`, b.top - 2 * ys[i]);
      add(`${odd ? 'laser' : 'bomb'} height`, b.bottom - b.top + 1);
    }
  }
  // ---- invaders: top row band and left column x
  const inv = blobs(3, 56, 190);
  if (inv.length) {
    const top = Math.min(...inv.map(b => b.top));
    const topRow = s.rows.reduce((t, m, i) => m ? i : t, -1);
    add('inv rowTop(5) - 2*RackY', top - 2 * s[0x90] - (5 - topRow) * 18);
  }
  // ---- shields
  if (s[0x98] & 0x40) {
    const sh = blobs(1, 180, 215);
    if (sh.length) add('shield top', Math.min(...sh.map(b => b.top)));
  }
  // ---- cannon 1 (P0 in lines 214-230)
  const c = leftmost(1, 214, 230);
  if (c < 999 && (s[0x98] & 0x10)) add('cannon1 x-X', c - s[0x9C]);
  const c2 = leftmost(2, 214, 230);
  if (c2 < 999 && (s[0x98] & 0x20)) add('cannon2 x-X', c2 - s[0x9D]);
  // ---- UFO (P0 above line 60)
  if (s[0x9E] !== 0xB4 && !(s[0xAA] & 0x80)) {
    const u = blobs(1, 30, 62);
    if (u.length) { add('ufo x-X', Math.min(...u.map(b => b.x0)) - s[0x9E]); add('ufo top', Math.min(...u.map(b => b.top))); }
  }
}

const frames = +(process.argv[2] || 6000);
let seed = 12345;
const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF) / 0x7FFFFFFF;
vcs.runFrames(10);
vcs.swchb &= ~1; vcs.runFrames(3); vcs.swchb |= 1;
for (let f = 0; f < frames; f += 8) {
  const r = rnd();
  vcs.swcha = r < 0.35 ? 0x7F : r < 0.7 ? 0xBF : 0xFF;
  vcs.fire[0] = rnd() < 0.5;
  vcs.runFrames(8);
  if (vcs.ram[0xAA - 0x80] & 0x80) { vcs.swchb &= ~1; vcs.runFrames(3); vcs.swchb |= 1; } // restart after game over
}
for (const [k, v] of Object.entries(stats))
  console.log(k.padEnd(26), Object.entries(v).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([o, n]) => `${o}:${n}`).join('  '));
