// Scripted play test of the C64 build in VICE (through the remote monitor).
// Presses Reset, moves, fires for a while, and saves screenshots + RAM dumps.
// Starts its own VICE on a monitor port of its own and closes only that one (other sessions
// may have a VICE running); --keep leaves it open and prints its port (for tools/vice.js).
//   node games/space-invaders/tools/c64test.js <outdir> [seconds-of-play] [--timing] [--keep]
const fs = require('fs');
const net = require('net');
const path = require('path');
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');

const out = path.resolve(process.argv[2] || '.');
const playSeconds = +(process.argv[3] || 20);
const timing = process.argv.includes('--timing');
const keep = process.argv.includes('--keep');
const root = path.join(__dirname, '..');
const prg = require('../../../tools/buildname').files(path.join(root, 'build')).prg;
const lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(root, 'build')).lst, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^>([0-9a-f]{4})\\s+(?:[0-9a-f]{2}\\s+)*\\s*${name}:`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return m[1];
};
const A = { swcha: addr('DbgSWCHA'), inpt4: addr('DbgINPT4'), swchb: addr('DbgSWCHB'), border: addr('DbgBorder') };
const sleep = ms => new Promise(r => setTimeout(r, ms));
let PORT = 0, vice = null;

function mon(cmds) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(PORT, '127.0.0.1');
    let buf = '';
    sock.on('data', d => { buf += d.toString('latin1'); });
    sock.on('error', reject);
    sock.on('connect', async () => {
      await sleep(150);
      for (const c of cmds) { sock.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 400); }
      sock.write('x\n');
      await sleep(100);
      sock.end();
      resolve(buf.replace(/\(C:\$[0-9a-f]{4}\) /g, ''));
    });
  });
}
const poke = (a, v) => mon([`> ${a} ${v}`]);
const shot = name => mon([`screenshot "${path.join(out, name).replace(/\\/g, '/')}" 2`]);

(async () => {
  fs.mkdirSync(out, { recursive: true });
  PORT = await freePort();
  vice = startVice(['-default', '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`,
    '-autostartprgmode', '1', '-autostart', prg]);
  // wait for our program (VICE's autostart takes a varying time); never poke anything else
  let ok = false;
  for (let t = 0; t < 30 && !ok; t++) { await sleep(1000); try { ok = await runsOurs(mon, prg); } catch { /* not up yet */ } }
  if (!ok) throw new Error(`the VICE on port ${PORT} isn't running Space Invaders: stopping`);
  await sleep(3000);
  if (timing) await poke(A.border, '1');
  await shot('t0-attract.png');
  await poke(A.swchb, 'fe'); await sleep(400); await poke(A.swchb, 'ff');   // Game Reset
  await sleep(3000);
  await shot('t1-start.png');
  let seed = 1;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const t0 = Date.now();
  let n = 0;
  while (Date.now() - t0 < playSeconds * 1000) {
    const r = rnd();
    await poke(A.swcha, r < 0.4 ? '7f' : r < 0.8 ? 'bf' : 'ff');
    await poke(A.inpt4, '7f'); await sleep(120); await poke(A.inpt4, 'ff');
    await sleep(400);
    if (++n % 15 === 0) await shot(`t2-play${n / 15}.png`);
  }
  await poke(A.swcha, 'ff');
  console.log(await mon(['m 0090 009f', 'm 00c6 00ca', 'm 00e6 00e9']));
  await shot('t3-end.png');
  if (keep) console.log(`VICE left running; its monitor port is ${PORT}: node tools/vice.js --port=${PORT} "<commands>"`);
  else stopVice(vice);
})().catch(e => { console.log(e.message); stopVice(vice); });
