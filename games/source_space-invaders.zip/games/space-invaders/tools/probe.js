// Play a scripted game in the emulator and log the RAM bytes we think we understand.
//   node games/space-invaders/tools/probe.js <outdir>
const fs = require('fs');
const { VCS } = require('../../../tools/vcs');
const out = process.argv[2] || '.';
const vcs = new VCS(require('../../../tools/rom').load('72ffbef6504b75e69ee1045af9075f66'));
vcs.cropTop = 25; vcs.cropHeight = 215;
const R = a => vcs.ram[a - 0x80];
const h = v => v.toString(16).padStart(2, '0');
const snap = (tag) => console.log(tag.padEnd(14),
  `f=${vcs.frames}`, `AA=${h(R(0xAA))}`, `98=${h(R(0x98))}`, `CA=${h(R(0xCA))}`,
  `inv x=${h(R(0x9A))} y=${h(R(0x90))} left=${R(0x91)}`, `rows=${[0, 1, 2, 3, 4, 5].map(i => h(R(0x92 + i))).join('')}`,
  `can=${h(R(0x9C))}`, `shX=${h(R(0x9B))}`, `ufo=${h(R(0x9E))}`,
  `laser=${h(R(0xD5))},${h(R(0xD7))}`, `bombs=${h(R(0xD1))}/${h(R(0xD3))} ${h(R(0xD2))}/${h(R(0xD4))}`,
  `score=${h(R(0xE6))}${h(R(0xE8))}`, `lives=${R(0xC9)}`, `expl=${h(R(0xC8))}`);

vcs.runFrames(30); snap('attract');
vcs.swchb &= ~1; vcs.runFrames(4); vcs.swchb |= 1;     // press and release RESET
vcs.runFrames(90); snap('game start');
vcs.savePNG(`${out}/start.png`);
vcs.swcha = 0x7F; vcs.runFrames(40); vcs.swcha = 0xFF; snap('after right');
vcs.swcha = 0xBF; vcs.runFrames(20); vcs.swcha = 0xFF; snap('after left');
vcs.fire[0] = true; vcs.runFrames(2); vcs.fire[0] = false;
for (let i = 0; i < 40; i++) { vcs.runFrames(1); if (i % 4 === 0) snap(`fire +${i}`); if (i === 12) vcs.savePNG(`${out}/shot.png`); }
// keep firing to watch kills and score
for (let n = 0; n < 12; n++) { vcs.fire[0] = true; vcs.runFrames(2); vcs.fire[0] = false; vcs.runFrames(45); }
snap('after volley');
vcs.savePNG(`${out}/volley.png`);
vcs.runFrames(600); snap('10 s later');
vcs.savePNG(`${out}/later.png`);
