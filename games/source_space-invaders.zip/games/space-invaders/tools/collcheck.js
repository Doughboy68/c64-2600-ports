// Check the C64 port's software collisions against the 2600's real (emulated) TIA.
// A JavaScript copy of Collide in c64/main.asm runs on the same RAM the 2600
// kernel just drew from; we compare with the collision latches the kernel produced.
//   node games/space-invaders/tools/collcheck.js [frames] [--markers]
const fs = require('fs');
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('72ffbef6504b75e69ee1045af9075f66'));
const rom = vcs.rom;
const R = a => vcs.ram[a - 0x80];
const G = a => rom[a & 0xFFF];                 // 2600 ROM byte
const withMarkers = process.argv.includes('--markers');

function overlap(top, bot, T, H) {
  const B = T + H - 1;
  if (bot < T || B < top) return null;
  return [Math.max(top, T) - T, Math.min(bot, B) - T];
}
const orTen = (lo, [g0, g1]) => { let a = 0; for (let g = g0; g <= g1; g++) a |= G(0xFC00 + lo + 9 - g); return a; };

function cannonShapes() {
  let c1 = R(0x98) & 0x10 ? 0x0A : 0, c2 = R(0x98) & 0x20 ? 0x0A : 0;
  const gs = R(0xAA), ft = R(0xCA);
  if (gs & 1) { if (!(ft & 8)) c1 = c2 = 0; return [c1, c2]; }
  const c = (ft >> 2) & 1;
  if (gs & 4) c1 = c ? 0x1E : 0x14;
  if (gs & 2) c2 = c ? 0x14 : 0x1E;
  return [c1, c2];
}

// Lines the 2600 draws a shot on: 2Y+39 for 8 lines, except in the cannon rows,
// where the kernel's line pattern is irregular and the ball is cut off at line 229.
const CANNON_ZONE = [[211, 220], [212, 222], [215, 224], [217, 226], [221, 228], [223, 229], [225, 229], [227, 229], [229, 229]];
function shotLines(Y) {
  if (Y >= 0x5F) return null;
  if (Y >= 0x56) return CANNON_ZONE[Y - 0x56];
  return [2 * Y + 39, 2 * Y + 46];
}

function model() {
  let hit = 0, p0 = 0, p1 = 0;
  const off = R(0xCA) & 1 ? 4 : 0;
  for (let k = 0; k < 2; k++) {
    const Y = R(0xD1 + off + k);
    const span = shotLines(Y);
    if (!span) continue;
    const [top, bot] = span, bx = (R(0xD3 + off + k) - 2) & 255;
    // invaders
    for (let r = 0; r < 6; r++) {
      const rows = R(0x92 + r); if (!rows) continue;
      const T = [156, 138, 120, 102, 84, 66][r] + 2 * R(0x90); if (T > 255) continue;
      const o = overlap(top, bot, T, 10); if (!o) continue;
      const dx = bx - (R(0x9A) - 1); if (dx < 0 || (dx & 15) >= 8 || (dx >> 4) >= 6) continue;
      if (!(rows & (1 << (dx >> 4)))) continue;
      const lo = (G(0xFCD6 + r) + R(0x8B) + 1) & 255;
      if (orTen(lo, o) & (0x80 >> (dx & 7))) hit |= 1 << r;
    }
    // UFO
    if (!(R(0xAA) & 0x80) && R(0x9E) !== 0xB4) {
      const o = overlap(top, bot, 47, 10), dx = (bx - (R(0x9E) - 1)) & 255;
      const ex = R(0xC8);
      const lo = (ex & 0x39) === 0x39 ? G(0xFD1E + (ex >> 6)) : 0xA0;
      if (o && dx < 8 && orTen(lo, o) & (0x80 >> dx)) hit |= 0x40;
    }
    // shields
    if (R(0x98) & 0x40) {
      const o = overlap(top, bot, 192, 18), dx = bx - (R(0x9B) - 1);
      if (o && dx >= 0 && (dx & 31) < 8 && (dx >> 5) < 3) {
        let a = 0; for (let g = o[0]; g <= o[1]; g++) a |= R(0xAB + 9 * (dx >> 5) + (g >> 1));
        if (a & (0x80 >> (dx & 7))) hit |= 0x80;
      }
    }
    // ground markers (what the C64 port did before the fix)
    if (withMarkers && overlap(top, bot, 231, 6)) { if (bx === 33 || bx === 34) p0 = 1; if (bx === 122 || bx === 123) p1 = 1; }
    // cannons
    if (!(R(0x98) & 0x80)) {
      const o = overlap(top, bot, 220, 10);
      if (o) cannonShapes().forEach((lo, i) => {
        if (!lo) return;
        let dx = bx - (R(0x9C + i) - 1); if (dx < 0) return;
        if (vcs.swchb & (i ? 0x80 : 0x40)) dx >>= 1;
        if (dx < 8 && orTen(lo, o) & (0x80 >> dx)) { if (i) p1 = 1; else p0 = 1; }
      });
    }
  }
  return { hit, p0, p1 };
}

const stats = { frames: 0, falseDeath: 0, missedDeath: 0, deaths: 0, hitDiff: 0, rowHits: 0, laserExtra: 0, laserMissed: 0, ufoShieldDiff: 0 };
const examples = [];
let started = false;
vcs.hooks = {
  0xF2B1: v => {                              // kernel finished: compare
    if (!started) return;
    stats.frames++;
    const m = model();
    const tP0 = (v.cx >> 5) & 1, tP1 = (v.cx >> 7) & 1, tHit = R(0x82);
    const active = !(R(0xAA) & 0x81);         // the game only checks cannon hits then
    if (active) {
      if (tP0 || tP1) stats.deaths++;
      if ((m.p0 && !tP0) || (m.p1 && !tP1)) { stats.falseDeath++; if (examples.length < 8) examples.push(`false death f${v.frames} bombs ${[0xD1, 0xD2, 0xD3, 0xD4].map(a => R(a).toString(16)).join(',')} cannon ${R(0x9C).toString(16)}`); }
      if ((!m.p0 && tP0) || (!m.p1 && tP1)) stats.missedDeath++;
    }
    if ((m.hit ^ tHit) & 0x3F) { stats.hitDiff++; if (R(0xCA) & 1) { if (m.hit & ~tHit & 0x3F) stats.laserExtra++; if (tHit & ~m.hit & 0x3F) stats.laserMissed++; } }
    if ((m.hit ^ tHit) & 0xC0) stats.ufoShieldDiff++;
    if (tHit & 0x3F) stats.rowHits++;
  },
};

const frames = +(process.argv[2] || 20000);
let seed = 99;
const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF) / 0x7FFFFFFF;
vcs.runFrames(10);
vcs.swchb &= ~1; vcs.runFrames(3); vcs.swchb |= 1;
started = true;
for (let f = 0; f < frames; f += 6) {
  const r = rnd();
  vcs.swcha = r < 0.35 ? 0x7F : r < 0.7 ? 0xBF : 0xFF;
  vcs.fire[0] = rnd() < 0.5;
  vcs.runFrames(6);
  if (R(0xAA) & 0x80) { vcs.swchb &= ~1; vcs.runFrames(3); vcs.swchb |= 1; }
}
console.log(stats);
examples.forEach(e => console.log(' ', e));
