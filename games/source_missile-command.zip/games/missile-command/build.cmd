@echo off
rem Build Missile Command:
rem   build\missile-command.a26     the 2600 ROM rebuilt from source (checked against the original)
rem   build\missilecmd-V.prg        the Commodore 64 version (V: the version in c64\main.asm)
rem   build\missilecmd-V.d64        the C64 version on a disk image
rem   build\missilecmd-V.crt        the C64 version as an EasyFlash cartridge (..\..\tools\mkcrt.js)
rem (file names at most 16 characters, a C64's: tools\buildfiles.js)
rem The original ROM (or its .zip) must be in roms_port\ (found by MD5, any file name).
cd /d "%~dp0"
set TASS=..\..\tools\64tass\64tass.exe
set MD5=3a2e2d0c6892aa14544083dfb7762782
if not exist build mkdir build
if not exist 2600\missile-command.asm node ..\..\tools\disasm.js . || exit /b 1

set NAME=
for /f %%n in ('node tools\buildfiles.js') do set NAME=%%n
if "%NAME%"=="" (echo no build name: see tools\buildfiles.js & exit /b 1)

node ..\..\tools\rom.js %MD5% build\original.a26 >nul || exit /b 1
%TASS% -q --nostart -o build\missile-command.a26 2600\missile-command.asm || exit /b 1
fc /b build\original.a26 build\missile-command.a26 >nul && (echo OK: build\missile-command.a26 matches the original ROM) || (echo DIFFERENT: build differs from the original ROM & exit /b 1)

rem (earlier versions' files: git keeps them)
del /q build\missilecmd-*.prg build\missilecmd-*.d64 build\missilecmd-*.crt build\missilecmd-*.lst build\missilecommand-c64.* 2>nul
node tools\mkc64tables.js >nul || exit /b 1
%TASS% -q -C -a -o build\%NAME%.prg -L build\%NAME%.lst c64\main.asm || exit /b 1
echo OK: build\%NAME%.prg
node ..\..\tools\mkcrt.js build\%NAME%.prg build\%NAME%.crt "Missile Command" || exit /b 1


where c1541 >nul 2>&1 || (echo c1541 not found, skipping the disk image & exit /b 0)
c1541 -format "missile command,mc" d64 build\%NAME%.d64 -write build\%NAME%.prg "missile command" >nul || exit /b 1
echo OK: build\%NAME%.d64
