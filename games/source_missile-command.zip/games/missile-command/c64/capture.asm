; ================================================================ capture
; A big explosion's first pixel for X = A: the positioning routine puts it 5 pixels further
; left (X 0-4: 23-26 and 159, as it leaves them), and a double-width player starts a pixel
; after its position (the real TIA)
BigX:
        cmp #5
        bcs +
        tay
        lda BigLow,y
        rts
+       sbc #4
        rts
BigLow: .byte 24, 25, 26, 27, 0

; Called where the game would draw the picture ($F7D1, the 2600's RAM as the kernel starts):
; note what the picture would show (tools/model.js has the rules), and leave the RAM as the
; 2600's kernel leaves it. Two captures are kept, the last tick's and the one before (the two
; attacking missiles are drawn on alternate frames; with flicker off both are shown).
Capture:
        lda CapLast             ; the next capture slot
        eor #1
        sta CapLast
        tax
        lda CapN
        cmp #2
        bcs +
        inc CapN
+
        ; ---- the attacking missile drawn this frame: its trail and warhead
        lda MslRow              ; warhead row ($53 - MslRow); nothing at all from $54 up
        cmp #$54
        bcc +
        lda #0
        sta CTr,x
        jmp _noTrail
+       lda #1
        sta CTr,x
        lda MslRow
        bne +
        lda #83                 ; (row 0 never comes: the whole trail, no warhead)
        bne ++
+       lda #$53
        sec
        sbc MslRow
+       sta CEnd,x
        lda PosX+2
        sta CX0,x
        lda MslSlope
        sta CSl,x
        lda MslDir
        sta CDir,x
        lda MslNusiz
        sta CNus,x
_noTrail
        ; the warhead's colour, as the kernel works it out into KColour
        lda MslDir              ; a cruise missile (bit 1): the score's colour
        and #2
        beq _blink
        lda Colours+4
        bne +
        beq +
_blink  lda FrameCount          ; others blink black / white every 8 frames
        and #8
        beq _white
        lda #0
        beq +
_white  lda #$0f
+       and PosX                ; (the colour mask)
        sta CW,x
        sta tmp                 ; (for the kernel's RAM, below)

        ; ---- the explosion (this frame's ABM slot) and the ABM shown (the slot before)
        lda GfxPtr
        sta CShape,x
        lda Flags
        and #$80
        sta CBig,x
        lda ExplRow
        sta C83,x
        lda ExplMask
        sta CMask,x
        ldy Slot
        lda ExplX,y
        sta tmp2                ; (for the comb's line, below)
        ldy CBig,x
        beq +
        jsr BigX
+       sta CP1X,x
        lda KColour
        sta CExpCol,x
        lda AbmRow
        sta CAbmRow,x
        lda PosX+3
        sta CAbmX,x
        lda CursorRow
        sta CBallRow,x
        lda PosX+4
        sta CBallX,x
        lda FrameCount
        sta CFrame,x
        and #$0f
        sta CCurCol,x
        ; colours
        lda Colours+1
        sta CT,x
        lda Colours+2
        sta CSky,x
        lda Colours+3
        sta CGround,x
        lda Colours
        sta CCity,x
        lda Colours+4
        eor Temp2
        and PosX
        sta CScore,x
        ; score, cities, ground
        txa                     ; 6 * capture
        asl
        sta tmp3
        asl
        adc tmp3
        tay
        ldx #0
-       lda DigitPtr,x
        sta CDig,y
        lda CityPtr,x
        sta CCit,y
        iny
        inx
        inx
        cpx #12
        bne -
        ldx CapLast
        ldy AbmsLeft
        lda PileTab,y
        sta CPile,x
        lda GameState
        and #3
        tay
        lda MarkTab,y
        sta CMark,x
        ; the three ABM slots (flicker off shows them all)
        txa                     ; 18 * capture
        asl
        sta tmp3
        asl
        asl
        asl
        adc tmp3
        tay
        ldx #0
-       lda ExplPhase,x
        sta CSlots,y
        lda ExplY,x
        sta CSlots+3,y
        lda ExplX,x
        sta CSlots+6,y
        lda AbmState,x
        sta CSlots+9,y
        lda AbmX,x
        sta CSlots+12,y
        lda AbmY,x
        sta CSlots+15,y
        iny
        inx
        cpx #3
        bne -
        ldx CapLast

        ; ---- the HMOVE comb near the top: the line depends on how long the kernel takes to
        ; position player 1 (model.js): T = path + 7n (+1 big) + 110 cycles from line 50,
        ; n = the positioning routine's divide steps
        lda #1
        ldy CBig,x
        beq +
        lda #$fc
+       clc
        adc tmp2
        ldy #0                  ; n = A / 15 + 1
        sec
-       iny
        sbc #15
        bcs -
        sty tmp3
        lda MslDir              ; path: 0 (cruise), 9, 10 cycles
        and #2
        beq +
        lda #0
        beq _path
+       lda FrameCount
        and #8
        beq +
        lda #9
        bne _path
+       lda #10
_path   ldy CBig,x
        beq +
        clc
        adc #1
+       ldy tmp3                ; + 7n
-       clc
        adc #7
        dey
        bne -
        ; T + 113 (= T + 3 with the 110): RESP1 on line 52 up to 152 cycles, 53 to 228, else 54
        ldy #52
        cmp #152 - 113 + 1
        bcc +
        iny
        cmp #228 - 113 + 1
        bcc +
        iny
+       lda tmp3                ; the HMOVE a line later, two when n >= 10
        cmp #10
        iny
        bcc +
        iny
+       tya
        sta CComb,x

        ; ---- the RAM as the kernel leaves it
        lda MslSlope            ; the slope accumulator after 83 rows: 83 * slope
        sta tmp2                ; (64 + 16 + 2 + 1)
        asl
        sta tmp3                ; 2 * slope
        asl
        asl
        asl
        sta tmp4                ; 16 * slope
        asl
        asl                     ; 64 * slope
        clc
        adc tmp4
        clc
        adc tmp3
        clc
        adc tmp2
        sta TrailAcc
        lda #$ff                ; the score loop's counter
        sta Temp2
        ldy #0                  ; its temp: the fourth digit's last row
        lda (DigitPtr+6),y
        sta Temp
        lda tmp                 ; the warhead's colour
        sta KColour
        ldy Slot                ; the explosion's X
        lda ExplX,y
        sta PosX+1
        ldy AbmsLeft            ; the pointer to the pile of ABMs left
        lda PileTab,y
        sta GfxPtr
        lda #$ff
        sta GfxPtr+1
        lda Colours+3           ; registers as the kernel leaves them (for Tick)
        sta ResumeA
        lda GameState
        and #3
        sta ResumeX
        rts
