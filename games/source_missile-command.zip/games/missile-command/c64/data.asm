; =================================================================== sound
; The game's TIA sound registers, translated to SID voices 1 and 2 once a frame.
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        beq _off
        ldy v1
        lda SidWave,y
        beq _off2
        sta tmp                 ; waveform
        lda v1                  ; frequency index = AUDC * 32 + AUDF
        lsr
        lsr
        lsr
        sta ptrA+1
        lda v1
        asl
        asl
        asl
        asl
        asl
        ora v2
        clc
        adc FreqTab
        sta ptrA
        lda ptrA+1
        adc FreqTab+1
        sta ptrA+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d400,y
        inc ptrA+1
        inc ptrA+1
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d401,y
        lda #0
        sta $d402,y
        sta $d405,y
        lda #8
        sta $d403,y
        lda v0                  ; volume becomes the sustain level
        asl
        asl
        asl
        asl
        sta $d406,y
        lda v0                  ; retrigger only when volume or waveform changes
        cmp SndLast,x
        bne +
        lda v1
        cmp SndLast+2,x
        beq _save
+       lda tmp
        sta $d404,y
        ora #1
        sta $d404,y
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts

; ================================================================== tables
Bit:        .byte $01, $02, $04, $08, $10, $20, $40, $80
BitHi:      .byte $80, $40, $20, $10, $08, $04, $02, $01
LeftMask:   .byte $00, $80, $c0, $e0, $f0, $f8, $fc, $fe, $ff
SidVoice:   .byte 0, 7
BmpHiTab:   .byte >(VIC0 + $2000), >(VIC1 + $2000)  ; per buffer: bitmap,
ScrHiTab:   .byte >VIC0, >VIC1                      ; screen,
SprHiTab:   .byte >(VIC0 + $0400), >(VIC1 + $0400)  ; sprite blocks,
BankBits:   .byte 2, 1                              ; $DD00 (VIC bank 1, 2)
CrBase:     .byte 0, CRMAX                          ; first warhead cell entry
Row40Lo:    .for r = 0, r < 25, r += 1
            .byte <(40 * r)
            .next
Row40Hi:    .for r = 0, r < 25, r += 1
            .byte >(40 * r)
            .next
; missile copies (NUSIZ0 & 7): how many, offsets (3 per mode)
CopyN:      .byte 1, 2, 2, 3, 2, 1, 3, 1
Times3:     .byte 0, 3, 6, 9, 12, 15, 18, 21
CopyOfs:    .byte 0, 0, 0,  0, 16, 0,  0, 32, 0,  0, 16, 32
            .byte 0, 64, 0,  0, 0, 0,  0, 32, 64,  0, 0, 0
WidthTab:   .byte 1, 2, 4, 8

        .include "tables.inc"

; ------------------------------------------------------- variables (RAM)
DbgSWCHA:   .byte $ff           ; AND masks applied to the inputs (testing aid)
DbgINPT4:   .byte $ff
DbgSWCHB:   .byte $ff
DbgBorder:  .byte 0             ; non-zero: colour the border while drawing / running the game
DbgLoops:   .word 0             ; main loop passes
DbgLate:    .word 0             ; ... that found more than one frame gone by
DbgTops:    .byte 0             ; frame tops the interrupt has done
DbgRMax:    .word 0             ; the most cycles one pass spent drawing,
DbgTMax:    .word 0             ; ... running the game,
DbgPMax:    .word 0             ; ... in all
DbgShown:   .word 0, 0          ; frames shown, by the parity of the tick they came from
DbgSame:    .word 0             ; ... of the same kind as the frame before (flicker on: only
                                ; where both captures to choose from hold the trail shown before)
BufKind:    .fill 2             ; ... of each buffer
dbgKind:    .byte 0             ; ... of the frame shown last
DbgAutoN    = DbgSame + 2 - DbgLoops
DbgAuto:    .byte 0             ; testing aid: N plays game N by itself from F2 on (AutoInput)
DbgAutoRes: .fill DbgAutoN      ; ... DbgLoops to DbgSame over its ticks AUTOFROM-AUTOTO
autoT:      .word 0             ; ... ticks since F2
autoRnd:    .byte 0
autoDir:    .byte 0
autoSW:     .byte 0
autoFire:   .byte 0
dbgT0:      .word 0
dbgT1:      .word 0
dbgNow:     .word 0
dbgTmp:     .word 0
FreqTab:    .word SidFreqLo     ; PAL or NTSC frequency tables
Flicker:    .byte 1             ; 1: the 2600's turns (one trail, one ABM slot a frame) (key F)
PrevKeyF:   .byte $ff
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
SndLast:    .fill 6, $ff
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0
irqTmp:     .byte 0
irqTop:     .byte 1             ; the next interrupt is the frame top
irqGnd:     .byte 0             ; the ground's colour for the frame end (StGround of the buffer shown)

; capture: what the last two ticks would have drawn (index 0/1)
CapLast:    .byte 1             ; the latest
CapN:       .byte 0             ; captures made (up to 2)
ResumeA:    .byte 0             ; registers as the kernel would leave them
ResumeX:    .byte 0
CTr:        .fill 2             ; an attacking missile is drawn
CEnd:       .fill 2             ; its warhead row (83: none)
CX0:        .fill 2             ; X at the top, slope, step (MslDir), NUSIZ0
CSl:        .fill 2
CDir:       .fill 2
CNus:       .fill 2
CW:         .fill 2             ; warhead colour
CShape:     .fill 2             ; the explosion: graphics (page $FF), big, bottom row,
CBig:       .fill 2
C83:        .fill 2
CMask:      .fill 2             ; ... rows mask, pixel, colour
CP1X:       .fill 2
CExpCol:    .fill 2
CAbmRow:    .fill 2             ; the ABM shown: row, pixel
CAbmX:      .fill 2
CBallRow:   .fill 2             ; the cursor: row, pixel, colour
CBallX:     .fill 2
CCurCol:    .fill 2
CT:         .fill 2             ; colours: trails, sky, ground, cities, score
CSky:       .fill 2
CGround:    .fill 2
CCity:      .fill 2
CScore:     .fill 2
CDig:       .fill 12            ; digit pointers (low bytes), 6 per capture
CCit:       .fill 12            ; city pointers (low bytes), 6 per capture
CPile:      .fill 2             ; the pile of ABMs left (low byte), the players' markers (PF0)
CMark:      .fill 2
CComb:      .fill 2             ; the HMOVE comb's line near the top
CFrame:     .fill 2             ; the frame counter
CSlots:     .fill 36            ; 18 per capture: phase, Y, X, state, ABM X, ABM Y (3 each)

; render: per buffer, what it holds
NibS:       .fill 2             ; screen colours: score rows, play rows, ground rows
NibP:       .fill 2
NibG:       .fill 2
BufDig:     .fill 12
BufCit:     .fill 13            ; (+1: DrawCity reads past the last)
BufPile:    .fill 2
BufMark:    .fill 2
BufComb:    .fill 2
TrV:        .fill 4             ; trail records (2 per buffer): in use,
TrX0:       .fill 4             ; identity,
TrSl:       .fill 4
TrDir:      .fill 4
TrNus:      .fill 4
TrEnd:      .fill 4             ; warhead row drawn,
TrW:        .fill 4             ; its colour
CRMAX       = 24
CrN:        .fill 2             ; warhead cells: count per buffer,
CrLo:       .fill 2 * CRMAX     ; colour RAM address, colour
CrHi:       .fill 2 * CRMAX
CrCol:      .fill 2 * CRMAX
; staged sprites (per buffer)
StX:        .fill 16
StY:        .fill 16
StCol:      .fill 16
StMsb:      .fill 2
StEn:       .fill 2
StBg:       .fill 2, $ff
StGround:   .fill 2             ; the ground's colour (the bottom border's)
; render's working variables
dN:         .byte 0
dCap:       .fill 2
dTaken:     .fill 2
rMatch:     .fill 2
erLo:       .fill 2
erHi:       .fill 2
nX:         .byte 0
nLo:        .byte 0
nHi:        .byte 0
fBig:       .byte 0
f83:        .byte 0
fMask:      .byte 0
fBall:      .byte 0
fCol:       .byte 0
fCity:      .byte 0
e83:        .byte 0
eX:         .byte 0
eSpr:       .byte 0
eR0:        .byte 0
aRow:       .byte 0
aX:         .byte 0
aOn:        .byte 0
aL223:      .byte 0
mIn:        .word 0             ; masks (left, right) of the pixels left of the GRP1 write: rows
mInB:       .word 0             ; inside, inside on the cursor's row, the row after, ... on the
mOut:       .word 0             ; cursor's row (in this order: offsets 0, 2, 4, 6)
mOutB:      .word 0
mComb:      .word 0             ; line A: the pixels the comb leaves
eHalf:      .byte 0             ; writing the second block
eMade:      .byte 0             ; explosions made this frame
spMin:      .fill 6             ; Overlap: copies' leftmost pixels (3-5: the eraser's),
spMax:      .fill 6             ; ... rightmost
spNC:       .fill 2             ; ... copies (+1: the eraser's)
spCO:       .byte 0
spW:        .byte 0
spX:        .byte 0
spSl:       .byte 0
spD:        .byte 0
spC0:       .byte 0
spC1:       .byte 0
zeroOK:     .byte 0             ; erasing may zero whole bytes
rSkip:      .fill 2             ; per record: its warhead stays as drawn this frame
pOfs:       .fill 3             ; PlotRow: the copies' byte offsets (SetRec),
lOr2:       .byte 0             ; Plot2: the second byte's pixel bits (0: one byte)
pXMax:      .byte 0             ; ... the pixels from pXMax on put a copy round the edge
nBase:      .word 0             ; ... a warhead row's colour RAM row,
nCol:       .byte 0             ; ... its colour
rbx2:       .byte 0             ; 2 * rb: its first record
rConv:      .fill 2             ; ... its old warhead row turned into trail ($FF: none)
pConv:      .byte $ff           ; PlotRows: the row whose pixels are set to trail ("10") whatever
                                ; was there (a warhead row becoming trail), $FF none
TrWS:       .fill 4             ; per trail record: how its warhead is drawn (HeadState)
GTabL:      .fill 16            ; an explosion's rows' graphics by index (0 = bottom): left byte,
GTabR:      .fill 16            ; ... right byte
eBallR:     .byte 0
sBase:      .byte 0             ; 8 * buffer
sNum:       .byte 0             ; sprite being written
BlkRows:    .fill 16            ; per buffer and sprite: 3 * rows its block used
KShape:     .fill 8, $ff        ; per buffer and sprite pair (4 * buffer + pair): the explosion
KBig:       .fill 8             ; its blocks hold (shape, size, pixel, rows, the cursor's row)
KX:         .fill 8
KR0:        .fill 8
KRB:        .fill 8
KBall:      .fill 8
cG:         .byte 0
cOnly:      .byte 0             ; DrawCity: city 0's third cell only
lAnd:       .byte 0             ; PlotLine: masks for the line's pixel
lOr:        .byte 0
wOp:        .byte 0             ; TrailWalk: 0 zero, 1 erase, 2 draw
wLast:      .byte 0
wReach:     .byte 0
wOfs:       .fill 3             ; ... the copies' byte offsets
wEntry:     .word 0
wI:         .byte 0
wQ:         .byte 0
wAcc:       .byte 0
wLic:       .byte 0
wCnt:       .byte 0
wM:         .byte 0
wAnd:       .byte 0
wOr:        .byte 0
wN2:        .byte 0             ; 2 * copies (FastWalk's pointers)
wMin:       .byte 0             ; the walk's leftmost pixel (first copy)
L223N:      .byte 0             ; line 223: explosions that reach it (up to 3),
L223G:      .fill 3             ; ... their last row's graphics, size, place
L223Big:    .fill 3
L223X:      .fill 3
L223B:      .fill 40            ; ... the line as bitmap bytes
Buf223:     .fill 80            ; ... as each buffer has it
Dirty223:   .fill 2             ; ... per buffer: an explosion is drawn in it

; ======================================================= the 2600 program
; The original 4K ROM, copied to $F000 at start-up, with these changes:
;   $F03F  NOP                   (was SEI: keep our interrupts)
;   $F047  JSR ClearZP           clear the 2600 RAM, not the C64's zero page
;   $F04D  NOP                   (was TXS: keep the C64's stack)
;   $F059, $F05B, $F065, $FA79   VBLANK / VSYNC writes go to $03 instead (writing $00 / $01
;                                would remap the C64's memory)
;   $F7D1  JMP KernelHook        stop where the 2600 would draw the picture
ROM = "../build/original.a26"     ; extracted from roms_port by build.cmd
GameImage:
        .binary ROM, $0000, $003f
        nop
        .binary ROM, $0040, $0047-$0040
        jsr ClearZP
        nop
        nop
        .binary ROM, $004c, 1
        nop
        .binary ROM, $004e, $0059-$004e
        .byte $03
        .binary ROM, $005a, 1
        .byte $03
        .binary ROM, $005c, $0065-$005c
        .byte $03
        .binary ROM, $0066, $07d1-$0066
        jmp KernelHook
        .binary ROM, $07d4, $0a79-$07d4
        .byte $03
        .binary ROM, $0a7a, $1000-$0a7a
        .cerror * - GameImage != $1000, "the 2600 image must be 4K"
