; Missile Command (Atari 2600, 1981) running on the Commodore 64.
;
; The original 4K program runs almost unchanged at $F000, in the RAM under the C64 KERNAL
; (patches: see GameImage at the end of data.asm). This file supplies everything the 2600
; hardware used to do:
;
;   - display: a multicolour bitmap laid out line for line like the 2600 picture (one 2600
;     pixel = one multicolour pixel = two C64 pixels, one 2600 line = one C64 line): the
;     attacking missiles' trails, the score, the cities and the ground are drawn into it; the
;     cursor, the explosions and the ABMs are sprites. The rules come from tools/model.js,
;     which matches the 2600 pixel for pixel.
;   - input: keyboard and joysticks mapped onto the 2600 joystick and switch ports
;   - sound: the game's TIA sound registers translated to the SID
;
; The 2600 game works out every hit itself (it never reads the TIA's collision registers),
; so the picture is all the C64 code has to produce.
;
; The game's TIA writes land harmlessly in zero page $02-$2C; it reads the TIA at the mirrors
; $30-$3D, where we put the fire buttons. Its RIOT accesses ($0280-$0297) hit plain C64 RAM,
; which we fill in each frame.
;
; Build: build.cmd (64tass -C -a -o build/missilecommand-c64.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM
FrameCount  = $80
TrailAcc    = $81
Temp        = $82
ExplRow     = $83       ; kernel: the explosion's bottom row
AbmRow      = $84       ; kernel: the shown ABM's row
CursorRow   = $85
PosX        = $86       ; 5: P0, P1, M0 (trail's X at the top), M1 (ABM X), ball (cursor X)
GfxPtr      = $8B       ; 2: the explosion's graphics
MslNusiz    = $91       ; this frame's attacking missile: NUSIZ0,
MslRow      = $93       ; ... warhead row,
MslSlope    = $95       ; ... slope,
MslDir      = $97       ; ... HMM0 step (bit 1: cruise missile)
ExplPhase   = $9E       ; 3 ABM slots: explosion phase
ExplMask    = $A1
Flags       = $A2       ; bit 7: big explosion
ExplY       = $A3       ; 3
ExplX       = $A6       ; 3
CityPtr     = $A9       ; 6 pointers
AbmState    = $B5       ; 3: bit 7 in use, bit 5 exploding
AbmX        = $C4       ; 3
AbmY        = $C7       ; 3
Slot        = $CA
DigitPtr    = $CB       ; 6 pointers
KColour     = $D7
Temp2       = $DA
GameState   = $DB       ; bit 7: no game
AbmsLeft    = $DD
Colours     = $E2       ; 5: cities, trails, sky, ground, score

; ------------------------------- 2600 hardware: TIA writes land in zero page
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
INPT4       = $3C       ; bit 7 clear: fire (left joystick)
INPT5       = $3D       ; ... (right joystick)
; RIOT
SWCHA       = $0280     ; joysticks (high nibble: left, low nibble: right)
SWCHB       = $0282     ; console switches
INTIM       = $0284     ; timer (kept at 0 so the game never waits)

; ------------------------------------------------ 2600 program addresses
Reset       = $F000     ; power on
KernelAt    = $F7D1     ; the game waits for its timer here, then draws the picture
Overscan    = $F96E     ; where the game continues after the picture
ExplShapes  = $FF00     ; page of the explosion phases' shapes, digits, cities
PileTab     = $FEE2     ; ABMs left -> low byte of the pile's graphics
MarkTab     = $FE7C     ; players' markers (PF0), by GameState & 3
HillTab     = $FF7F     ; the hills (PF2), 9 lines

; ------------------------------------------------------------ C64 layout
; Two frame buffers in two VIC banks: buffer 0 in bank 1 ($4000), buffer 1 in bank 2 ($8000).
; Each: screen (the bitmap's colours) at +$0000, sprite blocks at +$0400, bitmap at +$2000.
VIC0        = $4000
VIC1        = $8000
SPRBLK      = 16        ; first sprite block (+$0400)
D018VAL     = $08       ; screen +$0000, bitmap +$2000
COLRAM      = $D800
; tables built at start-up (InitTables), a page each
LineLo      = $C000     ; 2600 line -> offset of its first byte in the bitmap (lines 39-238)
LineHi      = $C100
ColOfsLo    = $C200     ; pixel (0-255: 160 on wrap round) -> column offset (column * 8)
ColOfsHi    = $C300
PixBits     = $C400     ; pixel -> its two bits ("11" in place)
PixT        = $C500     ; ... "10" in place (trail colour)
PixW        = PixBits   ; ... "11" (warhead colour)
Mod160      = $C600     ; x mod 160
PixCol      = $C700     ; pixel -> cell column
DblHi       = $C800     ; each bit doubled (double width rows): high byte
DblLo       = $C900     ; ... low byte
SqLo        = $CA00     ; n * n / 4 for n = 0-511 (Mul8): low bytes,
SqHi        = $CC00     ; ... high bytes

; 2600 line L is raster L + 12 and bitmap line L - 39 (cell row (L - 39) >> 3): the play area's
; last line (222) ends cell row 22, lines 223-238 (cities and ground) are rows 23-24. Lines
; 239 on (more ground) are below the C64's display, 39-40 (2600 VBLANK) are black at its top.
; Sprite Y register = raster - 1.
LINE2RAS    = 12
TOPRASTER   = 4         ; frame start (in the vertical blank: the 8565 VIC-II shows a grey dot
                        ; where a colour register is written, and nothing is shown here); on
                        ; NTSC BLACKNTSC - 3 (the border goes black at raster 10 first, see below)
ENDRASTER   = GROUNDRAS ; frame end (the interrupt's first write: the ground's colour, see below)
; The 2600's ground (from line 233) is the whole width and goes on to line 260 (VBLANK from 261),
; below the C64's display: the border takes the ground's colour from line 233 (raster 245) to
; raster 272 (on NTSC on round to raster 9). The 8565 VIC shows a grey dot where the beam is at
; a colour write: the ground's write lands mid-line (inside the display window, no border pixel
; to show it: the frame end's interrupt makes it first, about 30 cycles into raster 245), the
; black ones in the horizontal blank: the line before is waited for, then 58 cycles (the write
; lands in the first cycles of the line, PAL or NTSC; no sprites are fetched there).
GROUNDRAS   = 245
BLACKPAL    = 273
BLACKNTSC   = 10

; ------------------------------------------------------- zero page ($40+)
; $02-$2C take the game's TIA writes and $30-$3D are its TIA reads, so ours start at $40.
        .virtual $40
ptrA        .word ?
ptrB        .word ?
ptrC        .word ?
ptrD        .word ?
tmp         .byte ?
tmp2        .byte ?
tmp3        .byte ?
tmp4        .byte ?
frameFlag   .byte ?     ; frames counted by the raster interrupt
frames      .byte ?
isPal       .byte ?
topRaster   .byte ?     ; the frame top's raster: TOPRASTER, NTSC BLACKNTSC - 3
tickAcc     .byte ?
firstTick   .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)
outv        .byte ?, ?, ?       ; SWCHA, INPT4, INPT5 being built
switches    .byte ?     ; SWCHB toggles
curBuf      .byte ?     ; raster interrupt: frame buffer in use (0/1)
pending     .byte ?     ; a new frame is ready in the other buffer
rb          .byte ?     ; render: buffer being drawn
cap         .byte ?     ; render: capture being drawn
v0          .byte ?
v1          .byte ?
v2          .byte ?
bmpHi       .byte ?     ; render: the bitmap's page
; trail plotting
pX0         .byte ?     ; the trail: X at the top,
pX          .byte ?     ; pixel at the current row,
pAcc        .byte ?     ; slope accumulator,
pSl         .byte ?     ; slope,
pDir        .byte ?     ; step (1 right, $FF left),
pEnd        .byte ?     ; warhead row (83: none),
pW          .byte ?     ; warhead colour (2600),
pCru        .byte ?     ; cruise missile (no trail),
pNC         .byte ?     ; copies,
pCO         .byte ?     ; offset of its copies in CopyOfs,
pWid        .byte ?     ; width,
pOp         .byte ?     ; 0 erase, else draw
pRow        .byte ?
pR1         .byte ?
pLine       .byte ?
pXX         .byte ?
pBits       .byte ?
pMask       .byte ?
pLo         .byte ?     ; quirk: line A pixels pLo..pHi left out
pHi         .byte ?
; explosions (render.asm)
eGc         .word ?     ; row graphics (left, right byte): this row,
eGp         .word ?     ; ... the one before
eRow        .byte ?
eRB         .byte ?     ; bottom row
eH          .byte ?     ; rows (8, 16)
eMode       .byte ?     ; 1: right of the GRP1 writes, $FF: left, 0: across them
eShape      .byte ?
eBig        .byte ?
        .cerror * > $80, "zero page overflow"
        .endv

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title, credits and controls.
; (Lower case here: 64tass -a turns it into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " missile command"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600"
Bas30   .word Bas40, 30
        .null $8f, " programmed by rob fulop"
Bas40   .word Bas50, 40
        .null $8f, " version 1.0"
Bas50   .word Bas60, 50
        .null $8f, " ported by claude and doughboy68"
Bas60   .word Bas70, 60
        .null $8f, " joy port 2 (player 2: port 1)"
Bas70   .word Bas80, 70
        .null $8f, " or wasd-move cursor space-fire"
Bas80   .word Bas90, 80
        .null $8f, " f1 or fire-start f2-power off/on"
Bas90   .word Bas100, 90
        .null $8f, " f3-select f5-colour/b&w"
Bas100  .word Bas110, 100
        .null $8f, " f7/f8-difficulty (a: slow abms)"
Bas110  .word BasEnd, 110
        .null $8f, " f-flicker on/off"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #$ff
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01

        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -
        jsr InitTables

        ; copy the patched 2600 program to $F000-$FFFF
        lda #<GameImage
        sta ptrA
        lda #>GameImage
        sta ptrA+1
        lda #0
        sta ptrB
        lda #$f0
        sta ptrB+1
        ldx #16
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        lda #<Nmi               ; our vectors replace the 2600's
        sta $fffa
        lda #>Nmi
        sta $fffb
        lda #<Irq
        sta $fffe
        lda #>Irq
        sta $ffff

        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #0
        sta INTIM
        lda #$80
        sta INPT4
        sta INPT5
        lda #1
        sta firstTick

        jsr InitVideo
        jsr InitSound
        jsr DetectPal
        lda #$ff                ; CIA 2 timer A free-running (testing aid: DbgTime)
        sta $dd04
        sta $dd05
        lda #%00010001
        sta $dd0e

        lda #0                  ; start the raster interrupt on an empty frame
        sta curBuf
        lda topRaster
        sta $d012
        lda #$3b                ; bitmap mode, 25 rows, screen on
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

; ================================================================ main loop
MainLoop:
-       lda frameFlag           ; frames since we last got here (set by the raster interrupt)
        beq -
        sei
        lda frameFlag
        ldx #0
        stx frameFlag
        cli
        inc DbgLoops            ; (testing aid: passes, and frames that came late)
        bne +
        inc DbgLoops+1
+       cmp #2
        bcc +
        inc DbgLate
        bne +
        inc DbgLate+1
+       cmp #3                  ; if we fell behind, catch up at most 3 frames
        bcc +
        lda #3
+       sta frames
        jsr DbgTime             ; (testing aid: the most cycles drawing, ticking, both)
        stx dbgT0
        sty dbgT0+1
        lda DbgBorder           ; testing aid: the border shows where the time goes
        beq +
        lda #2
        sta $d020
+       lda CapN                ; draw the state the last tick produced (once there is one)
        beq +
        jsr Render
+       jsr ReadInput
        lda PowerReq            ; F2: the power switch
        beq +
        jsr PowerCycle
+       jsr DbgTime
        stx dbgT1
        sty dbgT1+1
        lda dbgT0               ; drawing
        ldx dbgT0+1
        ldy #0
        jsr DbgMax
        lda DbgBorder
        beq _frame
        lda #5
        sta $d020
_frame  lda isPal               ; PAL: 6 game ticks every 5 frames keeps 2600 speed
        beq _ntsc
        lda tickAcc
        clc
        adc #6
        sta tickAcc
-       lda tickAcc
        cmp #5
        bcc _done
        sbc #5
        sta tickAcc
        jsr Tick
        jmp -
_ntsc   jsr Tick
_done   dec frames
        bne _frame
        jsr DbgTime
        lda dbgT1               ; the ticks (from the end of drawing)
        ldx dbgT1+1
        ldy #2
        jsr DbgMax
        lda dbgT0               ; the whole pass
        ldx dbgT0+1
        ldy #4
        jsr DbgMax
        jsr UpdateSound
        lda DbgBorder
        beq +
        lda #0
        sta $d020
+       jmp MainLoop

; Testing aid: CIA 2 timer A counts down freely. DbgTime: dbgNow (and X/Y) = its value.
DbgTime:
-       ldy $dd05
        ldx $dd04
        cpy $dd05
        bne -
        stx dbgNow
        sty dbgNow+1
        rts
; DbgMax: cycles from the time in A/X (low/high) to dbgNow; keep the largest at
; DbgRMax+Y (Y = 0 drawing, 2 ticks, 4 the whole pass).
DbgMax:
        sec                     ; (the timer counts down: start - now)
        sbc dbgNow
        sta dbgTmp
        txa
        sbc dbgNow+1
        sta dbgTmp+1
        cmp DbgRMax+1,y
        bcc _keep
        bne _new
        lda dbgTmp
        cmp DbgRMax,y
        bcc _keep
_new    lda dbgTmp
        sta DbgRMax,y
        lda dbgTmp+1
        sta DbgRMax+1,y
_keep   rts

; One 2600 frame of game logic: the original code from the end of the picture to the start
; of the next one, where it jumps to KernelHook. The registers are as the 2600's kernel left
; them (A, X, Y: see KernelHook).
Tick:
        lda DbgAuto             ; (testing aid: the inputs by the tick count)
        beq +
        jsr AutoInput
+       lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp Reset               ; the very first frame starts at power-on
+       ldx ResumeX
        ldy #$ff
        lda ResumeA
        jmp Overscan

KernelHook:                     ; the game would draw the picture now
        jsr Capture             ; what to show (and what the kernel leaves in RAM)
        rts                     ; (returns to whoever called Tick)

; Replaces the 2600's "sta $00,x / inx / bne" clearing loop at power-on (A = 0): clear the
; 2600 RAM, but not the C64's zero page below $80.
ClearZP:
        ldx #$80
-       sta $00,x
        inx
        bne -
        rts

; F2: power off and on. Clear the TIA (our copies of its registers) and start again from the
; game's power-on code; the console switches stay as they are.
PowerCycle:
        lda #0
        sta PowerReq
        ldx #2                  ; the TIA's registers ($02-$2C) and our copies of its reads
-       sta $00,x
        inx
        cpx #$3e
        bne -
        sta INTIM
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        sta INPT5
        lda #1
        sta firstTick
        lda DbgAuto             ; (testing aid: AutoInput from the start)
        beq +
        lda #0
        sta autoT
        sta autoT+1
        lda #$5a
        sta autoRnd
        lda #$ff
        sta autoDir
+       rts

; =========================================================== interrupts
; Two interrupts a frame (three on PAL): the frame top shows the buffer in use (VIC bank,
; sprites, background, the warheads' colour RAM), the frame end lets the main loop draw the
; next frame and switches to a newly finished buffer; on PAL another makes the border black
; again after the 2600's ground (see GROUNDRAS). $01 is always $35 (nothing changes it after
; start-up), so the interrupts don't save it.
Irq:
        pha
        lda irqTop              ; frame top, frame end, or (PAL) the border black again?
        bmi IBlack
        bne +
        lda irqGnd              ; the frame end: first the 2600's ground (the border's colour
        beq +                   ; from raster 245, mid-line: see GROUNDRAS)
        sta $d020
+       txa
        pha
        tya
        pha
        cld                     ; the game uses decimal mode now and then
        lda $d019
        sta $d019
        lda irqTop
        bne ITop
        jmp IEnd

; The black writes land in the horizontal blank at the start of a line: the line before is
; waited for, then 58 cycles to the write, spent on the interrupt's own work where it takes a
; fixed time (no page crossings: see the check below).
IBlack: txa                     ; (PAL) the 2600's VBLANK: the border black again from raster
        pha                     ; 273 (only A and X used)
        ldx #BLACKPAL - 1 - 256
-       cpx $d012               ; raster 272 begins
        bne -
        lda #1                  ; (30 cycles) the frame top next
        sta irqTop
        lda #TOPRASTER
        sta $d012
        lda $d011               ; (raster 4: bit 8 clear)
        and #$7f
        sta $d011
        lda $d019
        sta $d019
        ldx #5                  ; (26)
_dly    dex
        bne _dly
        lda #0                  ; (2)
        sta $d020
        .cerror (>_dly) != (>(_dly + 2)), "the delay loop must not cross a page"
        pla
        tax
        pla
        rti

ITop:   lda #0
        sta irqTop
        ldy curBuf
        lda isPal               ; (NTSC) the border black again from raster 10
        bne _show
        lda $d020
        and #$0f
        beq _show
        ldx #BLACKNTSC - 1
-       cpx $d012               ; raster 9 begins
        bne -
        lda BankBits,y          ; (32 cycles) the buffer's VIC bank, ground, sprites
        sta $dd00
        lda StGround,y
        sta irqGnd
        lda StMsb,y
        sta $d010
        lda StEn,y
        sta $d015
        ldx #4                  ; (24)
_dly    dex
        bne _dly
        bit tmp
        lda #0                  ; (2)
        sta $d020
        .cerror (>_dly) != (>(_dly + 2)), "the delay loop must not cross a page"
        jmp _rest
_show   lda BankBits,y          ; the buffer's VIC bank
        sta $dd00
        lda StGround,y          ; its ground (the frame end's first write)
        sta irqGnd
        lda StMsb,y
        sta $d010
        lda StEn,y
        sta $d015
_rest   inc DbgTops             ; (testing aid: frames shown of each kind, by frame parity,
        lda BufKind,y           ; and how many repeat the kind before)
        cmp dbgKind
        sta dbgKind
        bne +
        inc DbgSame
        bne +
        inc DbgSame+1
+       asl
        tax
        inc DbgShown,x
        bne +
        inc DbgShown+1,x
+       ldy curBuf
        lda StBg,y              ; background (only when it changes: see TOPRASTER)
        cmp $d021
        beq +
        sta $d021
+       tya                     ; 8 * buffer: staged sprite values
        asl
        asl
        asl
        tay
        .for i = 0, i < 8, i += 1   ; (unrolled: half the time of loops)
        lda StCol+i,y
        sta $d027+i
        lda StX+i,y
        sta $d000+2*i
        lda StY+i,y
        sta $d001+2*i
        .next
        ; the warheads' colour RAM
        ldy curBuf
        ldx CrN,y
        beq _out
        lda CrBase,y
        sta irqTmp
-       ldy irqTmp
        lda CrLo,y
        sta _st+1
        lda CrHi,y
        sta _st+2
        lda CrCol,y
_st     sta COLRAM
        inc irqTmp
        dex
        bne -
_out    lda #ENDRASTER
        sta $d012
        jmp IrqOut

IEnd:   lda #1
        sta irqTop
        inc frameFlag           ; frame end: the next interrupt is the frame top
        lda pending             ; a newly finished frame: shown from the next frame top. (Swapped
        beq +                   ; here, just before the main loop draws the next one: at the
        lda curBuf              ; frame top, an NTSC frame's drawing would always just miss it
        eor #1                  ; and every other frame would go undrawn.)
        sta curBuf
        lda #0
        sta pending
+       lda isPal               ; (PAL: then black again from raster 273)
        beq +
        lda $d020
        and #$0f
        beq +
        lda #$ff
        sta irqTop
        lda #BLACKPAL - 2 - 256    ; (the interrupt two lines before: it waits for 272 to begin)
        sta $d012
        lda $d011
        ora #$80
        sta $d011
        jmp IrqOut
+       lda topRaster
        sta $d012
IrqOut  pla
        tay
        pla
        tax
        pla
        rti
        .cerror (>BankBits) != (>(BankBits + 1)) || (>StGround) != (>(StGround + 1)) || (>StMsb) != (>(StMsb + 1)) || (>StEn) != (>(StEn + 1)), "the black write's timing needs these tables in one page"

Nmi:    rti

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        ldy #BLACKNTSC - 3      ; the frame top: on NTSC just before the border goes black (the
        txa                     ; ground's colour until then): its wait for raster 9 must begin
                                ; in raster 8 (getting to it takes most of a line)
        beq +
        ldy #TOPRASTER
+       sty topRaster
        txa                     ; the SID's pitch depends on the machine's clock
        bne +
        lda #<SidFreqLoN
        sta FreqTab
        lda #>SidFreqLoN
        sta FreqTab+1
+       rts

InitVideo:
        lda $dd02               ; the VIC bank bits are outputs
        ora #3
        sta $dd02
        lda #2                  ; bank 1 ($4000) to start
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d01c               ; sprites: one colour,
        sta $d017               ; not Y-expanded (one sprite row a line),
        lda #$ff
        sta $d01d               ; X-expanded (one sprite pixel = one 2600 pixel),
        sta $d01b               ; behind the bitmap's "10" and "11" pixels (trails, warheads)
        lda #$18                ; multicolour, 40 columns
        sta $d016
        lda #D018VAL
        sta $d018
        lda #<VIC0              ; clear what the two banks show: screen and sprite blocks
        sta ptrB                ; (+$0000-$05FF), bitmap (+$2000-$3FFF); bank 1's +$0600-$1FFF
        lda #>VIC0              ; holds code (see the end)
        sta ptrB+1
        ldy #0
_page   lda ptrB+1
        and #$3f
        cmp #$06
        bcc _clr
        cmp #$20
        bcc _skip
_clr    tya
-       sta (ptrB),y
        iny
        bne -
_skip   inc ptrB+1
        lda ptrB+1
        cmp #>(VIC1 + $4000)
        bne _page
        ldx #0                  ; colour RAM: black
        txa
-       sta COLRAM,x
        sta COLRAM+$100,x
        sta COLRAM+$200,x
        sta COLRAM+$2e8,x
        inx
        bne -
        ldx #7                  ; sprite pointers: sprite n uses block SPRBLK + n in its bank
-       txa
        clc
        adc #SPRBLK
        sta VIC0+$3f8,x
        sta VIC1+$3f8,x
        dex
        bpl -
        lda #$f0                ; the cursor's image (sprite 7: 4 pixels, 2 lines)
        sta VIC0+$0400+7*64
        sta VIC0+$0400+7*64+3
        sta VIC1+$0400+7*64
        sta VIC1+$0400+7*64+3
        lda #0                  ; the static parts of both bitmaps
        jsr InitBitmap
        lda #1
        jsr InitBitmap
        rts

; The lookup tables at $C000-$C9FF
InitTables:
        ldx #0
        stx tmp                 ; x mod 160
-       lda tmp
        sta Mod160,x
        lsr
        lsr
        sta PixCol,x
        asl                     ; column * 8
        asl
        asl
        sta ColOfsLo,x
        lda #0
        rol
        sta ColOfsHi,x
        txa
        and #3
        tay
        lda Pix11,y
        sta PixBits,x
        and #$aa
        sta PixT,x
        inc tmp
        lda tmp
        cmp #160
        bne +
        lda #0
        sta tmp
+       inx
        bne -
        ; doubled bits: bit b of x becomes bits 2b and 2b+1
        ldx #0
-       stx tmp
        lda #0
        sta tmp2
        sta tmp3
        ldy #8
_d      asl tmp
        php
        rol tmp2
        rol tmp3
        plp
        rol tmp2
        rol tmp3
        dey
        bne _d
        lda tmp2
        sta DblLo,x
        lda tmp3
        sta DblHi,x
        inx
        bne -
        ; quarter squares: f(n) = n * n / 4, n = 0-511 (f(n+1) = f(n) + n / 2, rounded down:
        ; adding n >> 1 and, for odd n, one more every other step works out as: f(n+1) - f(n)
        ; = (n + 1) >> 1)
        lda #0
        sta tmp                 ; f low
        sta tmp2                ; f high
        sta tmp3                ; n low
        sta tmp4                ; n high
-       ldx tmp3
        lda tmp4
        bne +
        lda tmp
        sta SqLo,x
        lda tmp2
        sta SqHi,x
        jmp ++
+       lda tmp
        sta SqLo+256,x
        lda tmp2
        sta SqHi+256,x
+       lda tmp3                ; f += (n + 1) >> 1
        clc
        adc #1
        sta v0
        lda tmp4
        adc #0
        lsr
        ror v0
        lda v0
        clc
        adc tmp
        sta tmp
        bcc +
        inc tmp2
+       inc tmp3                ; n++
        bne -
        inc tmp4
        lda tmp4
        cmp #2
        bne -
        ; lines 39-238: cell row * 320 + line in the cell (others 0)
        ldx #0
        txa
-       sta LineLo,x
        sta LineHi,x
        inx
        bne -
        sta tmp                 ; offset of the cell row
        sta tmp2
        ldx #39
_ln     txa
        sec
        sbc #39
        and #7
        sta tmp3
        clc
        adc tmp
        sta LineLo,x
        lda tmp2
        adc #0
        sta LineHi,x
        lda tmp3
        cmp #7
        bne +
        lda tmp                 ; the next cell row: +320
        clc
        adc #<320
        sta tmp
        lda tmp2
        adc #>320
        sta tmp2
+       inx
        cpx #239
        bne _ln
        rts
Pix11:  .byte $c0, $30, $0c, $03

InitSound:
        ldx #$18
        lda #0
-       sta $d400,x
        dex
        bpl -
        lda #$0f                ; full volume
        sta $d418
        ldx #5
        lda #$ff
-       sta SndLast,x
        dex
        bpl -
        rts

        .include "capture.asm"
        .include "render.asm"
        .include "data.asm"
        .cerror GameImage > VIC0, "the program runs into the video banks"

; ---- code past the 2600 image: it loads into bank 1's RAM the VIC doesn't show ($4600-$5FFF:
; the screen, sprite blocks and bitmap are all it shows; InitVideo clears only those)
        .cerror * < VIC0 + $600, "the code past the 2600 image must start at $4600 or later"
        .include "input.asm"

; Testing aid (tools/c64late.js --auto): with DbgAuto = N the inputs are played by the tick
; count from F2 on (Game Select to game N, Game Reset, then the joystick moved and fire
; pressed at random every 16 ticks), so every build plays the same game whatever its timing.
; From tick AUTOFROM to AUTOTO the counters run; then they're kept in DbgAutoRes and the
; inputs left alone again.
AUTOFROM    = 800
AUTOTO      = AUTOFROM + 7200
AutoInput:
        inc autoT
        bne +
        inc autoT+1
+       lda #$ff                ; (the joystick at rest)
        sta autoSW
        lda autoT+1
        cmp #>(AUTOFROM - 200)
        bne +
        lda autoT
        cmp #<(AUTOFROM - 200)
+       bcc _select             ; up to AUTOFROM - 200: Game Select, N - 1 times
        lda autoT+1
        cmp #>(AUTOFROM - 100)
        bne +
        lda autoT
        cmp #<(AUTOFROM - 100)
+       bcs _play
        lda autoT               ; then Game Reset for 8 ticks
        sec
        sbc #<(AUTOFROM - 200)
        ldx #1
        cmp #8
        bcs +
        dex
+       stx tmp
        lda SWCHB
        and #$fe
        ora tmp
        sta SWCHB
        lda #$80
        sta autoFire
        jmp _set

_select lda autoT+1             ; ticks / 32
        asl
        asl
        asl
        sta tmp
        lda autoT
        lsr
        lsr
        lsr
        lsr
        lsr
        ora tmp
        clc
        adc #1
        ldx #2                  ; (select up)
        cmp DbgAuto
        bcs +
        lda autoT               ; down in ticks 16-23 of each 32
        and #31
        cmp #16
        bcc +
        cmp #24
        bcs +
        ldx #0
+       stx tmp
        lda SWCHB
        and #$fd
        ora tmp
        sta SWCHB
        lda #$80
        sta autoFire
        jmp _set

_play   ldx #1                  ; then play (after a game: Game Reset, 4 ticks in 32)
        lda GameState
        bpl +
        lda autoT
        and #31
        cmp #4
        bcs +
        dex
+       stx tmp
        lda SWCHB
        and #$fc
        ora #2
        ora tmp
        sta SWCHB
        lda autoT               ; new inputs every 16 ticks
        and #15
        bne _count
        lda autoRnd
        asl
        bcc +
        eor #$1d
+       sta autoRnd
        and #7
        tax
        lda AutoDirs,x
        sta autoDir
        lda autoRnd
        and #$80
        sta autoFire
_count  lda autoDir
        sta autoSW
        lda autoT+1
        cmp #>AUTOFROM
        bne +
        lda autoT
        cmp #<AUTOFROM
        bne +
        lda #0                  ; AUTOFROM: the counters from 0
        ldx #DbgAutoN - 1
-       sta DbgLoops,x
        dex
        bpl -
+       lda autoT+1
        cmp #>AUTOTO
        bne _set
        lda autoT
        cmp #<AUTOTO
        bne _set
        ldx #DbgAutoN - 1       ; AUTOTO: the counters kept, the inputs left alone
-       lda DbgLoops,x
        sta DbgAutoRes,x
        dex
        bpl -
        lda #0
        sta DbgAuto
        rts
_set    lda autoSW
        sta SWCHA
        lda autoFire
        sta INPT4
        sta INPT5
        rts
AutoDirs:   .byte $7f, $bf, $ef, $df, $ff, $6f, $af, $5f
        .cerror * > VIC0 + $2000, "the code past the 2600 image runs into the bitmap"
