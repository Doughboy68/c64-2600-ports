; ================================================================= render
; Draw a captured frame into the buffer the display isn't showing (rb): colours, the score,
; cities and ground, the trails (kept in the bitmap and brought up to date), the sprites.
Render:
        lda curBuf
        eor #1
        sta rb
        tax
        lda BmpHiTab,x
        sta bmpHi
        jsr PickCapture
        ldx cap                 ; (testing aid: which kind of frame this is)
        lda CFrame,x
        and #1
        ldx rb
        sta BufKind,x
        jsr SetColours
        jsr DrawStatic
        jsr DrawTrails
        jsr DrawSprites
        jsr DrawLine223
        lda #1
        sta pending
        rts

; Which capture to show. The two attacking missiles are drawn on alternate ticks, and the
; buffers alternate on the screen: show one whose trail differs from the buffer on the screen
; (so the display alternates too), else the latest. (With flicker off both trails are shown:
; the latest capture, plus the other's trail.)
PickCapture:
        lda CapLast
        sta cap
        lda CapN
        cmp #2
        bcc _done
        lda Flicker
        beq _done
        ldy CapLast
        jsr SameAsShown
        bne _done               ; the latest differs from what's shown: show the latest
        lda CapLast             ; else the one before, if that differs
        eor #1
        tay
        jsr SameAsShown
        beq _done
        lda CapLast
        eor #1
        sta cap
_done   rts

; Z set if capture Y's trail is one the buffer on the screen holds (or neither has one)
SameAsShown:
        lda curBuf
        asl
        tax
        lda TrV,x
        ora TrV+1,x
        bne +
        lda CTr,y               ; neither: the same (Z set if it has none)
        rts
+       lda CTr,y
        beq _no
        jsr _rec                ; record 0
        beq _r
        inx                     ; record 1
_rec    lda TrV,x
        beq _no
        lda TrX0,x
        cmp CX0,y
        bne _r
        lda TrSl,x
        cmp CSl,y
        bne _r
        lda TrDir,x
        cmp CDir,y
        bne _r
        lda TrNus,x
        cmp CNus,y
_r      rts
_no     lda #1                  ; (Z clear)
        rts

; ---------------------------------------------------------------- colours
; The bitmap's colours: background = the sky ($D021); per character cell the screen's high
; nibble ("01") and low nibble ("10"): rows 0-1 black / the score, rows 2-22 black (the HMOVE
; comb) / the trails, rows 23-24 the ground / the cities. Colour RAM ("11") holds the warheads.
SetColours:
        ldx cap
        ldy rb
        lda CSky,x
        lsr
        tax
        lda ColorMap,x
        sta StBg,y
        ldx cap                 ; rows 0-1
        lda CScore,x
        lsr
        tax
        lda ColorMap,x
        cmp NibS,y
        beq +
        sta NibS,y
        jsr FillScore
+       ldx cap                 ; rows 2-22
        ldy rb
        lda CT,x
        lsr
        tax
        lda ColorMap,x
        cmp NibP,y
        beq +
        sta NibP,y
        jsr FillPlay
+       ldx cap                 ; rows 23-24
        ldy rb
        lda CGround,x
        lsr
        tax
        lda ColorMap,x
        sta StGround,y          ; (the bottom border: the 2600 goes on showing the ground there)
        asl
        asl
        asl
        asl
        sta tmp
        ldx cap
        lda CCity,x
        lsr
        tax
        lda ColorMap,x
        ora tmp
        cmp NibG,y
        beq +
        sta NibG,y
        jsr FillGround
+       rts

; screen rows 0-1 of buffer rb = A (black high nibble: the colour is the low one)
FillScore:
        ldx rb
        ldy ScrHiTab,x
        sty _s+2
        ldx #79
_s      sta $4000,x
        dex
        bpl _s
        rts
; rows 23-24 (+920)
FillGround:
        ldx rb
        ldy ScrHiTab,x
        iny
        iny
        iny
        sty _s+2
        ldx #79
_s      sta $4000+920-768,x
        dex
        bpl _s
        rts
; rows 2-22: 840 bytes from +80, eight runs of 105 (+80, +185, ... +815)
FillPlay:
        sta tmp
        ldx rb
        lda ScrHiTab,x
        sta _0+2
        sta _1+2
        clc
        adc #1
        sta _2+2
        sta _3+2
        sta _4+2
        adc #1
        sta _5+2
        sta _6+2
        adc #1
        sta _7+2
        lda tmp
        ldx #104
_0      sta $4000+80,x
_1      sta $4000+185,x
_2      sta $4000+290-256,x
_3      sta $4000+395-256,x
_4      sta $4000+500-256,x
_5      sta $4000+605-512,x
_6      sta $4000+710-512,x
_7      sta $4000+815-768,x
        dex
        bpl _0
        rts

; ------------------------------------------------------------ static parts
; Score digits, cities, the pile of ABMs left, the players' markers, the line under the
; cities (player 1 still holding the last city's bottom row) and the HMOVE comb near the top:
; redrawn in this buffer when they change.
DrawStatic:
        lda rb                  ; 6 * buffer, 6 * capture
        asl
        sta tmp
        asl
        adc tmp
        sta v0
        lda cap
        asl
        sta tmp
        asl
        adc tmp
        sta v1
        ; (the usual case: score and cities as this buffer has them)
        ldx v1
        ldy v0
        lda #6
        sta tmp
-       lda CDig,x
        cmp BufDig,y
        bne _sc
        lda CCit,x
        cmp BufCit,y
        bne _sc
        inx
        iny
        dec tmp
        bne -
        lda v1                  ; (v1 as the loops leave it)
        clc
        adc #6
        sta v1
        jmp _ghost
_sc     ; score digits
        lda #0
        sta v2
-       ldx v1
        lda CDig,x
        ldx v0
        cmp BufDig,x
        beq +
        sta BufDig,x
        ldx v2
        jsr DrawDigit
+       inc v0
        inc v1
        inc v2
        lda v2
        cmp #6
        bne -
        ; cities (city 0's last pixel shows city 1's: redraw it when either changes)
        lda v0
        sec
        sbc #6
        sta v0
        lda v1
        sec
        sbc #6
        sta v1
        lda #0
        sta v2
-       ldx v1
        lda CCit,x
        ldx v0
        cmp BufCit,x
        beq +
        sta BufCit,x
        ldx v2
        jsr DrawCity
        lda v2
        cmp #1
        bne +
        ldx #0                  ; (city 0's last pixel: just that cell)
        jsr DrawCity0
+       inc v0
        inc v1
        inc v2
        lda v2
        cmp #6
        bne -
_ghost  ldy rb
        ldx cap
        lda CPile,x
        cmp BufPile,y
        beq +
        sta BufPile,y
        jsr DrawPile
+       ldy rb
        ldx cap
        lda CMark,x
        cmp BufMark,y
        beq +
        sta BufMark,y
        jsr DrawMarks
+       ldy rb
        ldx cap
        lda CComb,x
        cmp BufComb,y
        beq +
        pha
        lda BufComb,y           ; the old line's comb off, the new one's on
        ldx #0
        jsr CombLine
        pla
        ldy rb
        sta BufComb,y
        ldx #$55
        jsr CombLine
+       rts

; A = 2600 line (or 0: none), X = byte for columns 0-1 of buffer rb
CombLine:
        cmp #0
        beq _r
        tay
        stx tmp
        lda LineLo,y
        sta ptrA
        lda LineHi,y
        clc
        adc bmpHi
        sta ptrA+1
        ldy #0
        lda tmp
        sta (ptrA),y
        ldy #8
        sta (ptrA),y
_r      rts

; ptrA = buffer rb's bitmap byte for line Y (2600 line), pixel X (then use Y = 0)
LinePix .macro
        lda LineLo,y
        clc
        adc ColOfsLo,x
        sta ptrA
        lda LineHi,y
        adc ColOfsHi,x
        adc bmpHi
        sta ptrA+1
        .endm

; Digit X (0-5): pointer low byte A (page $FF), 7 rows on lines 42-48 at pixel 56 + 8X
DrawDigit:
        sta ptrB
        lda #>ExplShapes
        sta ptrB+1
        txa
        asl
        asl
        asl
        clc
        adc #56
        sta tmp2                ; pixel
        lda #6
        sta tmp3                ; row
-       lda #48
        sec
        sbc tmp3
        tay                     ; line 48 - row
        ldx tmp2
        #LinePix
        ldy tmp3
        lda (ptrB),y
        sta tmp
        lsr
        lsr
        lsr
        lsr
        tax
        lda Nib10,x
        ldy #0
        sta (ptrA),y
        lda tmp
        and #$0f
        tax
        lda Nib10,x
        ldy #8
        sta (ptrA),y
        dec tmp3
        bpl -
        rts

Pat2:   .byte $00, $55, $aa, $ff  ; a 2-bit value in every pixel of a byte

CITYX:  .byte 21, 37, 53, 102, 118, 134

; City X (0-5): 9 lines (224-232) from its pointer, "10" for the set bits. Its 8 pixels lie in
; three cells of their own (pixel 1 or 2 of the first on): each line is three whole bytes.
; City 0's last pixel (28) shows city 1's graphics (the kernel rewrites GRP0 there).
DrawCity0:
        lda #1                  ; city 0's third cell only (its last pixel is city 1's)
        bne +
DrawCity:
        lda #0
+       sta cOnly
        stx tmp4
        lda rb                  ; the city's pointer as this buffer holds it
        asl
        sta tmp
        asl
        adc tmp
        adc tmp4
        tax
        lda BufCit,x
        sta ptrB
        lda BufCit+1,x
        sta ptrC
        lda #>ExplShapes
        sta ptrB+1
        sta ptrC+1
        ldy #224                ; ptrA: the city's first cell on line 224 (then a line down each row)
        ldx tmp4
        lda CITYX,x
        tax
        #LinePix
        ldy #8                  ; row y, on line 232 - y
_line   sty tmp3
        lda (ptrB),y
        sta cG
        lda tmp4
        cmp #3
        bcs _sh2
        ; cities 0-2 start at pixel 1 of their first cell: cells g >> 5, (g >> 1) & 15, (g << 3) & 15
        lda cOnly
        bne +
        lda cG
        lsr
        lsr
        lsr
        lsr
        lsr
        tax
        lda Nib10,x
        ldy #0
        sta (ptrA),y
        lda cG
        lsr
        and #$0f
        tax
        lda Nib10,x
        ldy #8
        sta (ptrA),y
+       lda cG
        asl
        asl
        asl
        and #$0f
        ldx tmp4                ; city 0: pixel 28 (that cell's first) is city 1's bit 0
        bne +
        and #$07
        sta tmp
        ldy tmp3
        lda (ptrC),y
        and #1
        asl
        asl
        asl
        ora tmp
+       tax
        lda Nib10,x
        ldy #16
        sta (ptrA),y
        jmp _down
        ; cities 3-5 start at pixel 2: g >> 6, (g >> 2) & 15, (g << 2) & 15
_sh2    lda cG
        asl
        rol
        rol
        and #$03
        tax
        lda Nib10,x
        ldy #0
        sta (ptrA),y
        lda cG
        lsr
        lsr
        and #$0f
        tax
        lda Nib10,x
        ldy #8
        sta (ptrA),y
        lda cG
        asl
        asl
        and #$0f
        tax
        lda Nib10,x
        ldy #16
        sta (ptrA),y
_down   ldy tmp3                ; next line: +1, or from line 230 to 231 the next cell row (+313)
        cpy #2
        bne +
        lda ptrA
        clc
        adc #<313
        sta ptrA
        lda ptrA+1
        adc #>313
        sta ptrA+1
        jmp ++
+       inc ptrA
        bne +
        inc ptrA+1
+       dey
        bmi +
        jmp _line
+
        rts


; Lines 234-237: the pile of ABMs left (player 1, double width at 72: the sky's colour on the
; ground; the real TIA starts a double-width player a pixel late, so pixels 73-88). A = its
; graphics pointer's low byte (page $FF). Cells 18-22: the 16 pixels shifted 3 into 20.
DrawPile:
        sta ptrB
        lda #>ExplShapes
        sta ptrB+1
        lda #3
        sta tmp3                ; row y, on line 237 - y
-       ldy tmp3
        lda (ptrB),y
        tax
        lda DblLo,x
        sta tmp
        lda DblHi,x
        sta tmp2
        lda #0
        sta tmp4
        ldx #3
_sh     asl tmp
        rol tmp2
        rol tmp4
        dex
        bne _sh
        lda #237
        sec
        sbc tmp3
        tay
        ldx #72
        #LinePix
        ldy #0
        lda tmp4                ; pixels 72-75: bits 3-0 of the top byte
        jsr _cell
        lda tmp2
        lsr
        lsr
        lsr
        lsr
        jsr _cell
        lda tmp2
        jsr _cell
        lda tmp
        lsr
        lsr
        lsr
        lsr
        jsr _cell
        lda tmp
        jsr _cell
        dec tmp3
        bpl -
        rts
; one cell: the low nibble of A, set "00" (sky), clear "01" (ground); Y += 8
_cell   and #$0f
        eor #$0f
        tax
        lda Nib01,x
        sta (ptrA),y
        tya
        clc
        adc #8
        tay
        rts

; Lines 234-237, pixels 0-15: the players' markers (PF0 bits 4-7 left to right: the sky's
; colour on the ground). A = the PF0 value.
DrawMarks:
        sta v2
        lda #234
        sta tmp3
-       ldy tmp3
        ldx #0
        #LinePix
        lda v2
        lsr
        lsr
        lsr
        lsr
        sta tmp
        ldy #0
_c      lsr tmp
        lda #$55
        bcc +
        lda #0
+       sta (ptrA),y
        tya
        clc
        adc #8
        tay
        cpy #32
        bne _c
        inc tmp3
        lda tmp3
        cmp #238
        bne -
        rts

; ---- the static parts of bitmap A (0/1): lines 39-40 black (the 2600's VBLANK), the
; HMOVE comb on the first line of each play row, the ground and hills (lines 223-238)
InitBitmap:
        sta rb
        tax
        lda BmpHiTab,x
        sta bmpHi
        lda #$55                ; lines 39 and 40: "01" (black) all along
        sta pBits
        ldy #39
        jsr FillLine
        ldy #40
        jsr FillLine
        lda #57                 ; comb: lines 57, 59, ... 221, columns 0-1
        sta tmp3
-       lda tmp3
        ldx #$55
        jsr CombLine
        lda tmp3
        clc
        adc #2
        sta tmp3
        cmp #223
        bcc -
        ; ground: lines 233-238 "01" all along
        lda #233
        sta tmp3
-       ldy tmp3
        jsr FillLine
        inc tmp3
        lda tmp3
        cmp #239
        bne -
        ; line 223: the right edge's playfield (152-159; written at pixel 115)
        ldy #223
        jsr RightEdge
        ; lines 224-232: hills: PF0 $30 (0-7, 152-159), PF2 reflected (HillTab, 9 rows)
        lda #8
        sta tmp4                ; row y, on line 232 - y
_hill   lda #232
        sec
        sbc tmp4
        sta tmp3
        tay
        jsr RightEdge
        ldy tmp3
        ldx #0
        #LinePix
        lda #$55
        ldy #0
        sta (ptrA),y
        ldy #8
        sta (ptrA),y
        ldy tmp4
        lda HillTab,y
        sta v2
        lda #0
        sta tmp2                ; PF2 bit b: columns 12 + b (left) and 27 - b (right)
_b      lsr v2
        bcc +
        lda tmp2
        clc
        adc #12
        asl
        asl
        asl
        tay
        lda #$55
        sta (ptrA),y
        lda #27
        sec
        sbc tmp2
        asl
        asl
        asl
        tay
        lda #$55
        sta (ptrA),y
+       inc tmp2
        lda tmp2
        cmp #8
        bne _b
        dec tmp4
        bpl _hill
        ; what's drawn on demand: nothing yet
        ldx rb
        lda #$ff
        sta NibS,x
        sta NibP,x
        sta NibG,x
        sta BufPile,x
        sta BufMark,x
        lda #0
        sta BufComb,x
        sta CrN,x
        txa
        asl
        tax
        lda #0
        sta TrV,x
        sta TrV+1,x
        lda rb                  ; 6 * buffer
        asl
        sta tmp
        asl
        adc tmp
        tax
        lda #$ff
        ldy #6
-       sta BufDig,x
        sta BufCit,x
        inx
        dey
        bne -
        ldx #0                  ; line 223 as drawn above (40 * buffer)
        lda rb
        beq +
        ldx #40
+       ldy #40
        lda #0
-       sta Buf223,x
        inx
        dey
        bne -
        lda #$55
        sta Buf223-2,x
        sta Buf223-1,x
        rts

; line Y: columns 38-39 (pixels 152-159) "01"
RightEdge:
        ldx #152
        #LinePix
        lda #$55
        ldy #0
        sta (ptrA),y
        ldy #8
        sta (ptrA),y
        rts

; Line Y of buffer rb: all 40 bytes = pBits
FillLine:
        ldx #0
        #LinePix
        ldx #40
        ldy #0
-       lda pBits
        sta (ptrA),y
        tya
        clc
        adc #8
        tay
        bcc +
        inc ptrA+1
+       dex
        bne -
        rts

; ================================================================= trails
; Each buffer's bitmap holds the trails it shows (records rb * 2 + 0/1: identity = X at the
; top, slope, step, NUSIZ0; how far down it's drawn). Every frame: a trail still there gets
; its old warhead row erased, the rows since then drawn and its new warhead row drawn; trails
; gone are erased; new ones drawn whole. If two trails share the bitmap, rows of each inside
; what was erased are drawn again. Trail pixels are "10", warheads "11" (colour RAM, written
; at the frame top).
DrawTrails:
        ldx rb                  ; this buffer's warhead cells: none yet
        lda #0
        sta CrN,x
        txa
        asl
        sta rbx2
        ; what to show: dN trails, captures dCap
        lda #0
        sta dN
        ldx cap
        lda CTr,x
        beq +
        stx dCap
        inc dN
+       lda Flicker
        bne _match
        lda CapN
        cmp #2
        bcc _match
        lda cap
        eor #1
        tay
        lda CTr,y
        beq _match
        ldx cap                 ; (not if it's the same trail)
        lda CTr,x
        beq _add
        lda CX0,x
        cmp CX0,y
        bne _add
        lda CSl,x
        cmp CSl,y
        bne _add
        lda CDir,x
        cmp CDir,y
        bne _add
        lda CNus,x
        cmp CNus,y
        beq _match
_add    ldx dN
        tya
        sta dCap,x
        inc dN
_match  ; match the buffer's records with what's wanted
        lda #0
        sta dTaken
        sta dTaken+1
        lda #$ff
        sta rMatch
        sta rMatch+1
        sta erLo
        sta erLo+1
        lda #0
        sta v2                  ; record j
_mj     lda rb
        asl
        ora v2
        tax                     ; record index
        lda TrV,x
        beq _nextj
        ldy #0
_mi     cpy dN
        beq _nextj
        lda dTaken,y
        bne _ni
        sty tmp4
        lda dCap,y
        tay
        lda CX0,y
        cmp TrX0,x
        bne _ni0
        lda CSl,y
        cmp TrSl,x
        bne _ni0
        lda CDir,y
        cmp TrDir,x
        bne _ni0
        lda CNus,y
        cmp TrNus,x
        bne _ni0
        ldy tmp4                ; matched
        lda #1
        sta dTaken,y
        tya
        ldy v2
        sta rMatch,y
        jmp _nextj
_ni0    ldy tmp4
_ni     iny
        bne _mi
_nextj  inc v2
        lda v2
        cmp #2
        bne _mj

        ; ---- erase
        lda #0
        sta rSkip
        sta rSkip+1
        sta v2
        lda #$ff
        sta rConv
        sta rConv+1
_ej     lda rb
        asl
        ora v2
        tax
        lda TrV,x
        bne +
        jmp _enext
+
        ldy v2
        lda rMatch,y
        bmi _full
        tay                     ; matched: a trail that went back up is redrawn whole
        lda dCap,y
        tay
        lda CEnd,y              ; the warhead where it was, drawn the same: leave it
        cmp TrEnd,x
        bne +
        jsr CapHead
        cmp TrWS,x
        bne +
        ldy v2
        lda #1
        sta rSkip,y
        bne _enext
+       ldy v2
        lda rMatch,y
        tay
        lda dCap,y
        tay
        lda TrDir,x
        and #2
        bne _wrow
        lda CEnd,y
        cmp TrEnd,x
        beq _wrow
        bcc +
        lda TrEnd,x             ; moved down: no erasing, the draw turns its warhead row into
        ldy v2                  ; trail (the other's warhead redrawn if it's on that row)
        sta rConv,y
        jmp _enext
+       ldy v2                  ; (unmatch it)
        lda rMatch,y
        tay
        lda #0
        sta dTaken,y
        ldy v2
        lda #$ff
        sta rMatch,y
_full   jsr SetRec              ; erase all of it
        lda #0
        sta pOp
        lda pCru
        beq +
        lda pEnd
+       sta pRow
        lda pEnd
        sta pR1
        jsr NoteErased
        jsr ZeroOK
        jsr PlotRows
        lda rb
        asl
        ora v2
        tax
        lda #0
        sta TrV,x
        beq _enext
_wrow   jsr SetRec              ; still there: erase its warhead row
        lda #0
        sta pOp
        lda pEnd
        sta pRow
        sta pR1
        jsr NoteErased
        jsr ZeroOK
        jsr PlotRows
_enext  inc v2
        lda v2
        cmp #2
        beq +
        jmp _ej
+

        ; ---- draw
        lda #0
        sta v2
_dj     ldy v2
        lda rMatch,y
        bmi _dnext
        tay
        lda dCap,y
        tay                     ; the capture
        lda rb
        asl
        ora v2
        tax
        lda TrEnd,x             ; rows from the old warhead row to the new one
        sta tmp4
        lda CEnd,y
        sta TrEnd,x
        lda CW,y
        sta TrW,x
        jsr SetRec
        ldy v2                  ; (warhead left as it was: just its colour RAM cells)
        lda rSkip,y
        beq +
        jsr EmitCells
        jmp _dnext
+       lda #1
        sta pOp
        lda rConv,y
        sta pConv
        lda tmp4
        ldx pCru
        beq +
        lda pEnd                ; (cruise missile: just the warhead)
+       sta pRow
        lda pEnd
        sta pR1
        jsr PlotRows
        lda #$ff
        sta pConv
        lda rb
        asl
        ora v2
        tax
        jsr RecHead
        sta TrWS,x
_dnext  inc v2
        lda v2
        cmp #2
        bne _dj
        ; a warhead row turned into trail may have taken the other's warhead pixels: drawn again
        lda #0
        sta v2
_cj     ldy v2
        lda rConv,y
        bmi _cnext
        tya
        eor #1
        ora rbx2
        tax
        lda TrV,x
        beq _cnext
        lda rConv,y
        cmp TrEnd,x
        bne _cnext
        jsr SetRec
        lda #1
        sta pOp
        lda pEnd
        sta pRow
        sta pR1
        jsr PlotRows
_cnext  inc v2
        lda v2
        cmp #2
        bne _cj
        ; new trails, drawn whole
        ldy #0
_ni2    cpy dN
        beq _repair
        lda dTaken,y
        bne _nn
        sty v2
        lda rb                  ; a free record
        asl
        tax
        lda TrV,x
        beq +
        inx
+       lda dCap,y
        tay
        lda #1
        sta TrV,x
        lda CX0,y
        sta TrX0,x
        lda CSl,y
        sta TrSl,x
        lda CDir,y
        sta TrDir,x
        lda CNus,y
        sta TrNus,x
        lda CEnd,y
        sta TrEnd,x
        lda CW,y
        sta TrW,x
        jsr SetRec
        lda #1
        sta pOp
        lda #0
        ldx pCru
        beq +
        lda pEnd
+       sta pRow
        lda pEnd
        sta pR1
        jsr PlotRows
        ldy v2                  ; (the record: the warhead's state as drawn)
        lda dCap,y
        tay
        jsr CapHead
        pha
        lda rb
        asl
        tax
        lda TrX0,x              ; (which record took it: the one with this identity)
        cmp pX0
        beq +
        inx
+       pla
        sta TrWS,x
        ldy v2
_nn     iny
        bne _ni2

        ; ---- repair (only with two trails): their rows inside what was erased
_repair lda rb
        asl
        tax
        lda TrV,x
        and TrV+1,x
        beq _rdone
        lda #0
        sta v2
_rj     ldy v2
        lda erLo,y
        bmi _rnext
        lda #0
        sta v1
_rk     lda v1                  ; (not the trail that erased them: it drew its own rows again)
        cmp v2
        beq _rknext
        lda rb
        asl
        ora v1
        tax
        lda TrV,x
        beq _rknext
        jsr SetRec
        lda #1
        sta pOp
        ldy v2
        lda pCru
        beq _rt
        lda pEnd                ; a cruise missile: its one row, if inside
        cmp erLo,y
        bcc _rknext
        cmp erHi,y
        beq +
        bcs _rknext
+       sta pRow
        sta pR1
        bcc _rplot
        bcs _rplot
_rt     lda erLo,y              ; a trail: rows erLo..min(erHi, end)
        sta pRow
        lda erHi,y
        cmp pEnd
        bcc +
        lda pEnd
+       sta pR1
        cmp pRow
        bcc _rknext
        lda pR1                 ; (many rows: only if their pixels can share bytes there)
        sec
        sbc pRow
        cmp #8
        bcc _rplot
        jsr Overlap
        bcc _rknext
_rplot  jsr PlotRows
_rknext inc v1
        lda v1
        cmp #2
        bne _rk
_rnext  inc v2
        lda v2
        cmp #2
        bne _rj
_rdone  rts

; Could record v2 (the trail that erased rows pRow..pR1) and record v1 share a byte on those
; rows? From where each one's copies run over them (C set: yes, or can't tell)
Overlap:
        lda rb
        asl
        ora v2
        tax
        jsr SpanOf
        bcs _yes
        ldx #2
-       lda spMin,x             ; (keep the eraser's in slot 3-5)
        sta spMin+3,x
        lda spMax,x
        sta spMax+3,x
        dex
        bpl -
        lda spNC
        sta spNC+1
        lda rb
        asl
        ora v1
        tax
        jsr SpanOf
        bcs _yes
        ldx #0                  ; every copy against every copy, a byte's slack (3 pixels) each side
_cj     ldy #0
_ck     lda spMin,x             ; min(k) <= max(j) + 3 and min(j) <= max(k) + 3
        sec
        sbc #3
        bcc +
        cmp spMax+3,y
        bcs _nx
+       lda spMin+3,y
        sec
        sbc #3
        bcc _yes
        cmp spMax,x
        bcc _yes
_nx     iny
        cpy spNC+1
        bne _ck
        inx
        cpx spNC
        bne _cj
        clc                     ; no
        rts
_yes    sec
        rts

; Where record X's copies run over rows pRow..pR1: spMin/spMax (copies 0-2) leftmost and
; rightmost pixel (width included), spNC copies. C set if one wraps round the edge.
SpanOf:
        lda TrNus,x
        and #7
        tay
        lda CopyN,y
        sta spNC
        lda Times3,y
        sta spCO
        lda TrNus,x
        lsr
        lsr
        lsr
        lsr
        and #3
        tay
        lda WidthTab,y
        sta spW
        lda TrX0,x
        sta spX
        lda TrSl,x
        sta spSl
        lda TrDir,x
        sta spD
        lda pRow                ; carries up to the first row and the last
        ldx spSl
        jsr Mul8
        sta spC0
        lda pR1
        ldx spSl
        jsr Mul8
        sta spC1
        lda spD                 ; right: first row leftmost; left: last row leftmost
        and #$f0
        cmp #$f0
        bne _l
        lda spX
        clc
        adc spC0
        sta spMin
        lda spX
        clc
        adc spC1
        bcs _wrap
        sta spMax
        jmp _cp
_l      lda spX
        sec
        sbc spC1
        bcc _wrap
        sta spMin
        lda spX
        sec
        sbc spC0
        sta spMax
_cp     lda spMax               ; + width - 1
        clc
        adc spW
        sec
        sbc #1
        sta spMax
        ldx spNC                ; the copies (from the last down)
        dex
-       txa
        clc
        adc spCO
        tay
        lda spMin
        clc
        adc CopyOfs,y
        sta spMin,x
        lda spMax
        clc
        adc CopyOfs,y
        bcs _wrap
        cmp #160
        bcs _wrap
        sta spMax,x
        dex
        bpl -
        clc
        rts
_wrap   sec
        rts

; zeroOK: erasing rows pRow..pR1 of record v2 may just zero the bytes (no other trail in this
; buffer can share them; else the pixels are erased one by one and the other redrawn there)
ZeroOK:
        lda #1
        sta zeroOK
        lda v2
        eor #1
        sta v1
        lda rb
        asl
        ora v1
        tax
        lda TrV,x
        beq ++
        lda pR1                 ; (a few rows: just erase the pixels, not worth finding out)
        sec
        sbc pRow
        cmp #8
        bcc +
        jsr Overlap
        bcc ++
+       lda #0
        sta zeroOK
+       rts

; How a warhead is drawn (from capture Y / record X): 0 not at all (black cruise missile),
; 2 its top row missing pixels 8-18 of line A (black, row 0), 1 normally
CapHead:
        lda CDir,y
        and #2
        sta tmp
        lda CW,y
        sta tmp2
        lda CEnd,y
        jmp HeadState
RecHead:
        lda TrDir,x
        and #2
        sta tmp
        lda TrW,x
        sta tmp2
        lda TrEnd,x
HeadState:
        ldy tmp2                ; A = row, tmp = cruise, tmp2 = colour
        bne _1
        ldy tmp
        bne _0
        cmp #0
        bne _1
        lda #2
        rts
_1      lda #1
        rts
_0      lda #0
        rts

; The colour RAM cells of the warhead row of the trail set up by SetRec, colour pW, into
; buffer rb's list (the bitmap already has the warhead)
EmitCells:
        lda pEnd
        cmp #83
        bcs _r
        lda pW
        bne +
        lda pCru                ; (black cruise missile: not drawn)
        bne _r
+       lda pEnd
        sta pRow
        jsr RowPos
        lda pEnd
        asl
        adc #57
        sta pLine
        lda #0
        sta v0
_cp     lda pCO
        clc
        adc v0
        tay
        lda pX
        clc
        adc CopyOfs,y
        sta pXX
        lda #0
        sta tmp4
_w      lda pXX
        clc
        adc tmp4
        tax
        lda Mod160,x
        tax
        jsr NoteCell
        inc tmp4
        lda tmp4
        cmp pWid
        bne _w
        inc v0
        lda v0
        cmp pNC
        bne _cp
_r      rts

; note rows pRow..pR1 as erased by record v2
NoteErased:
        ldy v2
        lda pRow
        sta erLo,y
        lda pR1
        sta erHi,y
        rts

; Set up the plotting variables from record X (keeps X)
SetRec:
        lda TrX0,x
        sta pX0
        lda TrSl,x
        sta pSl
        lda TrDir,x
        and #2
        sta pCru
        lda TrDir,x             ; $10: left, $F0: right
        and #$f0
        cmp #$f0
        lda #1
        bcs +
        lda #$ff
+       sta pDir
        lda TrEnd,x
        sta pEnd
        lda TrW,x
        sta pW
        lda TrNus,x
        and #7
        tay
        lda CopyN,y
        sta pNC
        lda Times3,y
        sta pCO
        tay                     ; (PlotRow: the copies' byte offsets, and the pixels from which
        lda CopyOfs,y           ; a copy would go round the edge)
        asl
        sta pOfs
        lda CopyOfs+1,y
        asl
        sta pOfs+1
        lda CopyOfs+2,y
        asl
        sta pOfs+2
        tya
        clc
        adc pNC
        tay
        lda #160
        sec
        sbc CopyOfs-1,y
        sta pXMax
        lda TrNus,x
        lsr
        lsr
        lsr
        lsr
        and #3
        tay
        lda WidthTab,y
        sta pWid
        rts

; Erase (pOp = 0) or draw rows pRow..pR1 (rows past 82 left out) of the trail set up by
; SetRec. Drawn: rows before pEnd in the trail colour, row pEnd as the warhead. Trail rows go
; through TrailWalk; the warhead row, and trails that wrap round the screen's edge, through
; SlowRows.
PlotRows:
        lda pRow
        cmp #83
        bcc +
        rts
+       lda pR1
        cmp #83
        bcc +
        lda #82
        sta pR1
+       jsr RowPos
        lda pOp
        bne _draw
        lda #1                  ; erase: just zero the bytes if no other trail shares them
        sta wOp
        lda zeroOK
        beq +
        dec wOp
+       jsr TrailWalk
        bcc +
        jmp SlowRows
+       rts
_draw   lda pR1                 ; (the last row asked for)
        sta wLast
        lda pCru
        bne _wh
        lda pEnd                ; trail rows: pRow..min(pR1, pEnd - 1)
        beq _wh
        sec
        sbc #1
        cmp pR1
        bcs +
        sta pR1
+       lda pR1
        cmp pRow
        bcc _wh0
        lda pRow                ; a warhead row becoming trail: that row on its own (SlowRows sets
        cmp pConv               ; its pixels; it leaves pRow, pX, pAcc at the next row)
        bne _tw
        lda pR1
        pha
        lda pRow
        sta pR1
        jsr SlowRows
        pla
        sta pR1
        cmp pRow
        bcc _wh0
_tw     lda #2
        sta wOp
        jsr TrailWalk
        bcc _wh0
        jsr SlowRows
_wh0    lda wLast
        sta pR1
_wh     lda pEnd                ; the warhead row, if asked for
        cmp #83
        bcs _r
        cmp pRow
        bcc _r
        cmp pR1
        beq +
        bcs _r
+       sta pR1
        cmp pRow                ; (already there: SlowRows went on to it, or it's the first row)
        beq +
        sta pRow
        jsr RowPos
+       jmp SlowRows
_r      rts

; pX, pAcc: the trail's pixel and slope accumulator at row pRow (X0 + step * (pRow * slope >> 8))
RowPos:
        lda pRow
        bne +
        sta pAcc
        lda pX0
        sta pX
        rts
+       ldx pSl
        jsr Mul8                ; A = high byte, tmp = low byte
        sta tmp2
        lda tmp
        sta pAcc
        lda pDir
        bmi +
        lda pX0
        clc
        adc tmp2
        jmp ++
+       lda pX0
        sec
        sbc tmp2
        bcs +
        adc #160
+       tax
        lda Mod160,x
        sta pX
        rts

; ---- Rows pRow..pR1 (all trail rows) down the bitmap column by column: wOp 0 zero the bytes,
; (up to 3 rows: SlowRows is quicker than setting this up)
; 1 erase the pixels, 2 draw them ("10"). Every copy goes in the same pass (they're 16, 32 or
; 64 pixels apart: whole cells). C set if a pixel would wrap round the screen's edge (nothing
; done: the caller uses SlowRows). Keeps pRow, pR1, pX, pAcc.
TrailWalk:
        lda pR1                 ; how far it moves sideways: the carries of pAcc + rows * slope
        sec
        sbc pRow
        cmp #3
        bcs +
        sec                     ; (a few rows: SlowRows)
        rts
+       beq +
        ldx pSl
        jsr Mul8
        sta tmp4
        lda tmp
        clc
        adc pAcc
        lda tmp4
        adc #0
+       sta tmp4
        ldx pNC                 ; reach: the last copy's offset + width - 1
        lda pCO
        clc
        adc pNC
        tay
        lda CopyOfs-1,y
        clc
        adc pWid
        sec
        sbc #1
        sta wReach
        lda pDir                ; the rightmost pixel, the leftmost
        bmi _left
        lda pX
        sta wMin
        clc
        adc tmp4
        bcs _no
        bcc _chk
_left   lda pX
        sec
        sbc tmp4
        bcc _no
        sta wMin
        lda pX
_chk    clc
        adc wReach
        bcs _no
        cmp #160
        bcc +
_no     sec
        rts
+       lda pWid                ; one pixel wide, clear of the comb: the unrolled walk
        cmp #1
        bne +
        lda wMin
        cmp #8
        bcc +
        jmp FastWalk
+
        ; the copies' byte offsets (a copy 16 pixels on is 4 cells = 32 bytes on), and where to
        ; enter the unrolled copies
        ldx #0
-       txa
        clc
        adc pCO
        tay
        lda CopyOfs,y
        asl
        sta wOfs,x
        inx
        cpx #3
        bne -
        ldx pNC
        lda wOp
        beq +
        lda EntryRLo-1,x
        sta wEntry
        lda EntryRHi-1,x
        sta wEntry+1
        jmp ++
+       lda EntryZLo-1,x
        sta wEntry
        lda EntryZHi-1,x
        sta wEntry+1
+       lda #0
        sta wI
_wi     lda pX                  ; this pixel of the width
        clc
        adc wI
        sta wQ
        lda pAcc
        sta wAcc
        lda pRow                ; line A = 57 + 2 * row
        asl
        adc #57
        tay
        ldx wQ
        lda LineLo,y
        clc
        adc ColOfsLo,x
        sta ptrB
        lda LineHi,y
        adc ColOfsHi,x
        adc bmpHi
        sta ptrB+1
        tya
        sec
        sbc #39
        and #7
        sta wLic                ; line A's line in its cell
        lda PixBits,x
        jsr WMasks
        lda pR1
        sec
        sbc pRow
        sta wCnt                ; rows to go after this one
        lda #0
        jmp (wEntry)
_adv    lda wCnt                ; ---- after each row
        bne +
        inc wI
        lda wI
        cmp pWid
        bne _wi
        clc
        rts
+       dec wCnt
        lda wLic                ; two lines down
        clc
        adc #2
        cmp #8
        bcs _cross
        sta wLic
        lda ptrB
        adc #2
        sta ptrB
        bcc _acc
        inc ptrB+1
        bcs _acc
_cross  lda #0
        sta wLic
        lda ptrB
        clc
        adc #<314
        sta ptrB
        lda ptrB+1
        adc #>314
        sta ptrB+1
_acc    lda wAcc
        clc
        adc pSl
        sta wAcc
        bcc _go
        lda pDir                ; a step sideways
        bmi _sl
        inc wQ
        lsr wM
        lsr wM
        bne +
        lda #$c0
        sta wM
        lda ptrB
        clc
        adc #8
        sta ptrB
        bcc +
        inc ptrB+1
+       jsr WMasks2
        jmp _go
_sl     dec wQ
        asl wM
        asl wM
        bne +
        lda #$03
        sta wM
        lda ptrB
        sec
        sbc #8
        sta ptrB
        bcs +
        dec ptrB+1
+       jsr WMasks2
_go     lda #0
        jmp (wEntry)

; ---- FastWalk: TrailWalk's rows when the trail is one pixel wide and its first copy stays
; clear of the comb (pixel 8 on): four rows to a character cell unrolled, each copy on its own
; pointer (ptrB, ptrC, ptrD: its cell on the current cell row; Y = the line in the cell).
; wOp, rows, pX, pAcc as TrailWalk; wCnt = rows, wQ = pixel, wAcc. Returns C clear.
WP = [ptrB, ptrC, ptrD]

; one row, line A at line \1 of the cell, \2 copies; \3: 0 zero the bytes, 1 read-modify-write
WRow    .macro
        .if \3 == 0
        lda #0
        .fi
        .for c = 0, c < \2, c += 1
        ldy #\1
        .if \3
        lda (WP[c]),y
        and wAnd
        ora wOr
        sta (WP[c]),y
        iny
        lda (WP[c]),y
        and wAnd
        ora wOr
        sta (WP[c]),y
        .else
        sta (WP[c]),y
        iny
        sta (WP[c]),y
        .fi
        .next
        dec wCnt
        bne +
        jmp WDone
+       lda wAcc
        clc
        adc pSl
        sta wAcc
        bcc +
        jsr WStep
+
        .endm

; four rows (lines 0, 2, 4, 6 of a cell), then the next cell row
WBlock  .macro
_r0     #WRow 0, \1, \2
_r1     #WRow 2, \1, \2
_r2     #WRow 4, \1, \2
_r3     #WRow 6, \1, \2
        jsr WCell
        jmp _r0
        .endm

FastWalk:
        lda pX
        sta wQ
        lda pAcc
        sta wAcc
        lda pR1
        sec
        sbc pRow
        clc
        adc #1
        sta wCnt
        lda pNC                 ; copies (for WStep / WCell: pointer offsets 0, 2, 4)
        asl
        sta wN2
        lda pRow                ; line A = 57 + 2 * row; its cell's first byte on the pixel's column
        asl
        adc #57
        tay
        ldx wQ
        sec
        sbc #39
        and #7
        sta wLic
        lda LineLo,y
        sec
        sbc wLic
        sta ptrB
        lda LineHi,y
        sbc #0
        sta ptrB+1
        lda ptrB
        clc
        adc ColOfsLo,x
        sta ptrB
        lda ptrB+1
        adc ColOfsHi,x
        adc bmpHi
        sta ptrB+1
        ldx #0                  ; the other copies: + 2 * offset (16 pixels = 32 bytes)
        ldy pCO
-       inx
        inx
        iny
        cpx wN2
        bcs +
        lda CopyOfs,y
        asl
        clc
        adc ptrB
        sta ptrB,x
        lda ptrB+1
        adc #0
        sta ptrB+1,x
        jmp -
+       ldx wQ
        lda PixBits,x
        jsr WMasks
        ldx pNC                 ; the block: zero / read-modify-write, 1-3 copies; row = line / 2
        dex
        lda wOp
        beq +
        inx
        inx
        inx
+       txa
        asl
        asl
        sta tmp
        lda wLic
        lsr
        ora tmp
        tax
        lda WEntLo,x
        sta wEntry
        lda WEntHi,x
        sta wEntry+1
        jmp (wEntry)
WDone   clc
        rts

; a step sideways: the masks; a new column moves every copy's pointer a cell
WStep:
        lda pDir
        bmi _l
        inc wQ
        lda wQ
        and #3
        bne _m
        ldx #0
-       lda ptrB,x
        clc
        adc #8
        sta ptrB,x
        bcc +
        inc ptrB+1,x
+       inx
        inx
        cpx wN2
        bne -
        beq _m
_l      lda wQ
        dec wQ
        and #3
        bne _m
        ldx #0
-       lda ptrB,x
        sec
        sbc #8
        sta ptrB,x
        bcs +
        dec ptrB+1,x
+       inx
        inx
        cpx wN2
        bne -
_m      ldx wQ
        lda PixBits,x
        jmp WMasks

; the next cell row: every pointer + 320
WCell:
        ldx #0
-       lda ptrB,x
        clc
        adc #<320
        sta ptrB,x
        lda ptrB+1,x
        adc #>320
        sta ptrB+1,x
        inx
        inx
        cpx wN2
        bne -
        rts

WZ1     #WBlock 1, 0
WZ2     #WBlock 2, 0
WZ3     #WBlock 3, 0
WR1     #WBlock 1, 1
WR2     #WBlock 2, 1
WR3     #WBlock 3, 1
WENTS = [WZ1._r0, WZ1._r1, WZ1._r2, WZ1._r3, WZ2._r0, WZ2._r1, WZ2._r2, WZ2._r3, WZ3._r0, WZ3._r1, WZ3._r2, WZ3._r3, WR1._r0, WR1._r1, WR1._r2, WR1._r3, WR2._r0, WR2._r1, WR2._r2, WR2._r3, WR3._r0, WR3._r1, WR3._r2, WR3._r3]
WEntLo:     .byte <WENTS
WEntHi:     .byte >WENTS

; the masks for pixel bits A (wM): draw "10", erase, zero
WMasks: sta wM
WMasks2:
        lda wOp
        cmp #2
        bne +
        lda wM
        and #$aa
        sta wOr
        lda #$ff
        sta wAnd
        rts
+       lda wM
        eor #$ff
        sta wAnd
        lda #0
        sta wOr
        rts

; the copies, unrolled (enter at the right one for the number of copies): read-modify-write
WCopy3: ldy wOfs+2
        lda (ptrB),y
        and wAnd
        ora wOr
        sta (ptrB),y
        iny
        lda (ptrB),y
        and wAnd
        ora wOr
        sta (ptrB),y
WCopy2: ldy wOfs+1
        lda (ptrB),y
        and wAnd
        ora wOr
        sta (ptrB),y
        iny
        lda (ptrB),y
        and wAnd
        ora wOr
        sta (ptrB),y
WCopy1: ldy wOfs
        lda wQ                  ; (line A: pixels 0-7 are the comb)
        cmp #8
        bcc +
        lda (ptrB),y
        and wAnd
        ora wOr
        sta (ptrB),y
+       iny
        lda (ptrB),y
        and wAnd
        ora wOr
        sta (ptrB),y
        jmp TrailWalk._adv
; ... zeroing (A = 0)
WZero3: ldy wOfs+2
        sta (ptrB),y
        iny
        sta (ptrB),y
WZero2: ldy wOfs+1
        sta (ptrB),y
        iny
        sta (ptrB),y
WZero1: ldy wOfs
        ldx wQ
        cpx #8
        bcc +
        sta (ptrB),y
+       iny
        sta (ptrB),y
        jmp TrailWalk._adv
EntryRLo:   .byte <WCopy1, <WCopy2, <WCopy3
EntryRHi:   .byte >WCopy1, >WCopy2, >WCopy3
EntryZLo:   .byte <WZero1, <WZero2, <WZero3
EntryZHi:   .byte >WZero1, >WZero2, >WZero3

; Rows pRow..pR1 pixel by pixel (pX, pAcc at pRow)
SlowRows:
_row    lda pRow
        cmp #83
        bcs _done
        cmp pR1
        beq +
        bcs _done
+       ; what to put: erase "00"; draw: trail "10", warhead "11", or nothing
        lda #0
        sta pLo
        sta pHi
        lda pOp
        beq _put                ; (erase: pMask = 0)
        lda pRow
        cmp pEnd
        beq _wh
        bcs _next               ; (below the warhead: nothing)
        lda pCru
        bne _next
        lda pRow                ; trail: "10" over what's there; on the converted row set to it
        cmp pConv
        beq _cv
        lda #2
        bne _put
_cv     lda #4
        bne _put
_wh     lda pW                  ; warhead
        bne +
        lda pCru                ; black: a cruise missile isn't drawn at all; a missile's top
        bne _next               ; row leaves out pixels 8-18 of line A (ENAM0 written late)
        lda pRow
        bne +
        lda #8
        sta pLo
        lda #18
        sta pHi
+       lda #3
_put    sta pMask               ; 0 erase, 2 trail, 3 warhead, 4 trail set (converted row)
        lda pRow                ; line A = 57 + 2 * row
        asl
        adc #57
        sta pLine
        jsr PlotRow
_next   inc pRow
        lda pAcc                ; the next row's pixel
        clc
        adc pSl
        sta pAcc
        bcc _row
        lda pDir
        bmi _left
        ldx pX
        inx
        cpx #160
        bcc +
        ldx #0
+       stx pX
        jmp _row
_left   ldx pX
        bne +
        ldx #160
+       dex
        stx pX
        jmp _row
_done   rts

; Both lines of the current row (line A pLine, line B the next; pixels pLo-pHi of line A left
; out when pHi isn't 0). One pixel wide (the usual case): one address for the row, each copy
; whole cells on, line B the byte after line A's. Wider, or round the edge: PlotLineAny.
PlotRow:
        lda pWid
        cmp #1
        beq _fast
        cmp #2                  ; two pixels wide (a cruise missile's warhead), one copy, clear of
        bne _any                ; the comb, the quirk and the edge: Plot2
        lda pNC
        cmp #1
        bne _any
        lda pHi
        bne _any
        lda pX
        cmp #8
        bcc _any
        cmp #159
        bcs _any
        lda pMask
        beq +
        cmp #3
        bne _any
+       jmp Plot2
_any    jsr PlotLineAny
        inc pLine
        lda #0
        sta pLo
        sta pHi
        jsr PlotLineAny
        dec pLine
        rts
_fast   ldx pX                  ; the masks for this pixel (every copy has the same place in its cell)
        lda pMask
        beq _e
        cmp #3
        beq _h
        lda PixT,x              ; trail: OR "10"; set (4): the pixel's bits cleared first
        sta lOr
        lda pMask
        cmp #4
        beq _clr
        lda #$ff
        bne _and
_h      lda PixW,x              ; warhead: OR "11"
        sta lOr
        lda #$ff
        bne _and
_e      lda #0
        sta lOr
_clr    lda PixBits,x
        eor #$ff
_and    sta lAnd
        ldy pLine
        #LinePix
        lda pX                  ; no copy round the edge (the usual case): the copies by their
        cmp pXMax               ; byte offsets (SetRec)
        bcc +
        jmp _old
+       ldy #0                  ; line A of the first copy: not in the comb or the quirk's pixels
        cmp #8
        bcc _b0
        ldx pHi
        beq _a0
        cmp pLo
        bcc _a0
        cmp pHi
        bcc _b0
        beq _b0
_a0     lda (ptrA),y
        and lAnd
        ora lOr
        sta (ptrA),y
_b0     iny                     ; line B
        lda (ptrA),y
        and lAnd
        ora lOr
        sta (ptrA),y
        ldx #1
        cpx pNC
        beq _cells
_cn     ldy pOfs,x              ; the other copies: both lines
        lda (ptrA),y
        and lAnd
        ora lOr
        sta (ptrA),y
        iny
        lda (ptrA),y
        and lAnd
        ora lOr
        sta (ptrA),y
        inx
        cpx pNC
        bne _cn
_cells  lda pMask               ; a warhead: each copy's cell gets its colour
        cmp #3
        bne _r
        lda pLine               ; (the row's colour RAM, the colour: once)
        sec
        sbc #39
        lsr
        lsr
        lsr
        tay
        lda Row40Lo,y
        sta nBase
        lda Row40Hi,y
        clc
        adc #>COLRAM
        sta nBase+1
        lda pW
        lsr
        tax
        lda ColorMap,x
        sta nCol
        lda #0
        sta v0
_nc     ldy v0                  ; (copy v0's pixel)
        lda pOfs,y
        lsr
        clc
        adc pX
        tax
        lda PixCol,x
        clc
        adc nBase
        sta nLo
        lda nBase+1
        adc #0
        sta nHi
        lda nCol
        jsr AddCell
        inc v0
        lda v0
        cmp pNC
        bne _nc
_r      rts
_old    ldx #0
_c      stx v0
        txa
        clc
        adc pCO
        tay
        lda CopyOfs,y
        clc
        adc pX
        cmp #160
        bcs _wrap               ; (round the edge: the slow way)
        sta pXX
        lda CopyOfs,y           ; byte offset: 2 * pixels
        asl
        tay
        txa                     ; line A: the first copy may be in the comb or the quirk's pixels
        bne _a
        lda pX
        cmp #8
        bcc _b
        ldx pHi
        beq _a
        cmp pLo
        bcc _a
        cmp pHi
        bcc _b
        beq _b
_a      lda (ptrA),y
        and lAnd
        ora lOr
        sta (ptrA),y
_b      iny                     ; line B
        lda (ptrA),y
        and lAnd
        ora lOr
        sta (ptrA),y
        lda pMask               ; a warhead pixel: its cell gets the warhead's colour
        cmp #3
        bne _n
        ldx pXX
        jsr NoteCell
_n      ldx v0
        inx
        cpx pNC
        bne _c
        rts
_wrap   lda pX                  ; this copy and the rest, pixel by pixel
        pha
        lda pNC
        pha
        lda pCO
        pha
        lda pHi
        pha
        txa                     ; (start the general loop at this copy)
        clc
        adc pCO
        sta pCO
        lda pNC
        sec
        sbc v0
        sta pNC
        jsr PlotLineAny
        inc pLine
        lda #0
        sta pHi
        jsr PlotLineAny
        dec pLine
        pla
        sta pHi
        pla
        sta pCO
        pla
        sta pNC
        pla
        sta pX
        rts

; ... two pixels (pX, pX + 1) of a warhead (pMask 3) or erased (0): one byte, or two when
; they straddle columns (the second 8 bytes on, in the next cell: its colour too); both lines
Plot2:
        ldx pX
        ldy pLine
        #LinePix
        lda PixBits,x
        sta lOr
        lda PixBits+1,x
        sta lOr2
        txa
        and #3
        cmp #3
        beq +
        lda lOr                 ; (one byte)
        ora lOr2
        sta lOr
        lda #0
        sta lOr2
+       ldy #0
        jsr _op
        lda lOr2
        beq _cells
        sta lOr
        ldy #8
        jsr _op
_cells  lda pMask
        beq _r
        ldx pX
        jsr NoteCell
        lda lOr2
        beq _r
        ldx pX
        inx
        jmp NoteCell
_r      rts
_op     lda pMask               ; both lines (line B the byte after)
        beq _e
        lda (ptrA),y
        ora lOr
        sta (ptrA),y
        iny
        lda (ptrA),y
        ora lOr
        sta (ptrA),y
        rts
_e      lda lOr
        eor #$ff
        sta lAnd
        and (ptrA),y
        sta (ptrA),y
        iny
        lda (ptrA),y
        and lAnd
        sta (ptrA),y
        rts

; ... any width, pixel by pixel
PlotLineAny:
        lda #0
        sta v0                  ; copy
_copy   lda pCO
        clc
        adc v0
        tay
        lda pX
        clc
        adc CopyOfs,y
        sta pXX
        lda #0
        sta tmp4                ; pixel of the width
_w      lda pXX
        clc
        adc tmp4
        tax
        lda Mod160,x
        tax
        lda pLine               ; line A: pixels 0-7 are the HMOVE comb
        and #1
        beq _ok
        cpx #8
        bcc _skip
        lda pHi
        beq _ok
        cpx pLo
        bcc _ok
        cpx pHi
        bcc _skip
        beq _skip
_ok     ldy pLine
        #LinePix
        ldy #0
        lda pMask
        beq _erase
        cmp #2
        beq _t
        cmp #4
        beq _set
        lda pLine               ; a warhead pixel: its cell gets the warhead's colour (noted on
        lsr                     ; line B: line A is in the same cell)
        bcs +
        jsr NoteCell
+       lda PixW,x
        bne _st
_t      lda PixT,x
_st     ora (ptrA),y
        sta (ptrA),y
        jmp _skip
_set    lda PixBits,x           ; (trail set: cleared, then "10")
        eor #$ff
        and (ptrA),y
        sta (ptrA),y
        jmp _t
_erase  lda PixBits,x
        eor #$ff
        and (ptrA),y
        sta (ptrA),y
_skip   inc tmp4
        lda tmp4
        cmp pWid
        bne _w
        inc v0
        lda v0
        cmp pNC
        beq +
        jmp _copy
+
        rts

; Note the colour RAM cell of pixel X on line pLine for buffer rb's warhead list
; (keeps X, Y = 0 on return)
NoteCell:
        stx nX
        lda pLine               ; cell row (line - 39) >> 3
        sec
        sbc #39
        lsr
        lsr
        lsr
        tay
        lda PixCol,x
        clc
        adc Row40Lo,y
        sta nLo
        lda Row40Hi,y
        adc #>COLRAM
        sta nHi
        lda pW
        lsr
        tax
        lda ColorMap,x
        jsr AddCell
        ldx nX
        ldy #0
        rts

; Add colour RAM cell nLo/nHi with colour A to buffer rb's list (unless it's the last one
; added: a warhead's pixels come cell by cell; a repeat further back does no harm)
AddCell:
        sta tmp3
        ldx rb
        lda CrN,x
        beq _new
        cmp #CRMAX
        bcs _out
        clc
        adc CrBase,x
        tay
        dey
        lda CrLo,y
        cmp nLo
        bne _new
        lda CrHi,y
        cmp nHi
        beq _out
_new    lda CrBase,x
        clc
        adc CrN,x
        tay
        inc CrN,x
        lda nLo
        sta CrLo,y
        lda nHi
        sta CrHi,y
        lda tmp3
        sta CrCol,y
_out    rts

; A:tmp = A * X (8 x 8 bits: A high byte, tmp low), by quarter squares:
; a * x = f(a + x) - f(|a - x|), f(n) = n * n / 4 (SqLo/SqHi, n = 0-511)
Mul8:
        stx tmp2
        sta tmp3
        clc
        adc tmp2
        tay                     ; a + x (low byte; the high bit picks the table's second page)
        bcc +
        lda SqLo+256,y
        sta tmp
        lda SqHi+256,y
        jmp ++
+       lda SqLo,y
        sta tmp
        lda SqHi,y
+       sta tmp4
        lda tmp3                ; |a - x|
        sec
        sbc tmp2
        bcs +
        eor #$ff
        adc #1
+       tay
        lda tmp
        sec
        sbc SqLo,y
        sta tmp
        lda tmp4
        sbc SqHi,y
        rts

; ================================================================ sprites
; Buffer rb's sprites: with flicker on, the explosion (sprites 0-1: a big one is two sprites
; stacked) and the ABM shown (2-3: 3 for its part on line 223 right of pixel 61, in the
; cities' colour); with flicker off, ABM slot s on sprites 2s and 2s+1 (explosion or ABM);
; the cursor on sprite 7 (its image is made once, in InitVideo). The rows and their quirks
; are tools/model.js's. Each block remembers how many rows it used (BlkRows), so only those
; are cleared.
DrawSprites:
        ldx rb
        lda #0
        sta eMade
        sta L223N
        sta StEn,x
        sta StMsb,x
        lda SprHiTab,x          ; sprite blocks of this buffer
        sta ptrD+1
        txa
        asl
        asl
        asl
        sta sBase               ; 8 * buffer
        ; the cursor (ball: line B of its row and line A of the next, 4 pixels)
        ldx cap
        lda CBallRow,x
        beq _nocur
        cmp #$54
        bcs _nocur
        lda #7
        jsr SprOn
        ldx cap
        lda #$53                ; line B of row $53 - CursorRow: 58 + 2 * row
        sec
        sbc CBallRow,x
        asl
        adc #58 + LINE2RAS - 1
        sta tmp
        lda CBallX,x
        ldy #7
        jsr SprPos
        ldx cap
        lda CCurCol,x
        lsr
        tax
        lda ColorMap,x
        ldx #7
        jsr SprCol
_nocur  ldx cap                 ; the frame's explosion params (they also set the ABM's timing)
        lda CBig,x
        sta fBig
        lda C83,x
        sta f83
        lda CMask,x
        sta fMask
        lda CBallRow,x
        sta fBall
        lda CExpCol,x
        lsr
        tay
        lda ColorMap,y
        sta fCol
        lda CCity,x
        lsr
        tay
        lda ColorMap,y
        sta fCity
        lda Flicker
        beq _all
        ; flicker on: the frame's explosion (this slot) and ABM (the slot before)
        lda CShape,x
        sta eShape
        lda CBig,x
        sta eBig
        lda C83,x
        sta e83
        lda CP1X,x
        sta eX
        lda #0
        sta eSpr
        jsr Explosion
        ldx cap
        lda CAbmRow,x
        sta aRow
        lda CAbmX,x
        sta aX
        lda #2
        sta eSpr
        jmp Abm
        ; flicker off: every slot, as its own frame would show it
_all    lda cap                 ; 18 * capture
        asl
        sta tmp
        asl
        asl
        asl
        adc tmp
        sta v2
        lda #0
        sta v1                  ; slot
_slot   lda v1
        asl
        sta eSpr
        lda v2
        clc
        adc v1
        tax
        lda CSlots+9,x          ; exploding?
        and #$20
        beq _fly
        ldy CSlots,x            ; phase -> shape
        lda ExplShapes,y
        sta eShape
        lda #0
        cpy #4
        bcc +
        cpy #12
        bcs +
        lda #$80
+       sta eBig
        lda CSlots+3,x          ; Y (- 4 for a big one)
        ldy eBig
        beq +
        sec
        sbc #4
+       sta e83
        lda CSlots+6,x
        ldy eBig
        beq +
        jsr BigX
+       sta eX
        jsr Explosion
        jmp _snext
_fly    lda CSlots+15,x
        sta aRow
        lda CSlots+12,x
        sta aX
        jsr Abm
_snext  inc v1
        lda v1
        cmp #3
        bne _slot
        rts

; Sprite A on (in StEn); ptrA = its block in buffer rb; X = A, sNum = A
SprOn:
        sta sNum
        tax
        lsr
        lsr
        clc
        adc ptrD+1
        sta ptrA+1
        txa
        asl
        asl
        asl
        asl
        asl
        asl
        sta ptrA
        ldy rb
        lda Bit,x
        ora StEn,y
        sta StEn,y
        rts

; Done writing rows 0..n-1 (Y = 3n) of block ptrA, sprite sNum: clear the rows it used
; before beyond those, and remember n
SprEnd:
        sty tmp
        lda sBase
        clc
        adc sNum
        tax
        lda BlkRows,x           ; (3 * rows used before)
        sta tmp2
        lda tmp
        sta BlkRows,x
        ldy tmp
        lda #0
-       cpy tmp2
        bcs +
        sta (ptrA),y
        iny
        bne -
+       rts

; sprite Y: X position 2600 pixel A, Y register tmp
SprPos:
        sty tmp2
        tax
        tya
        clc
        adc sBase
        tay
        txa
        asl                     ; 24 + 2 * pixel
        php
        clc
        adc #24
        sta StX,y
        lda #0
        rol
        plp
        adc #0
        beq +
        ldx tmp2
        lda Bit,x
        ldx rb
        ora StMsb,x
        sta StMsb,x
+       lda tmp
        sta StY,y
        rts

; sprite X's colour = A
SprCol:
        pha
        txa
        clc
        adc sBase
        tay
        pla
        sta StCol,y
        rts

; ---- an explosion: shape eShape (page $FF; $30 = none), eBig, bottom row e83, pixel eX,
; on sprite eSpr (and eSpr + 1 for a big one's lower part: sprite rows 21 on). The kernel
; writes GRP1 part-way across each row's line B (model.js): pixels left of that show the row
; before. Line A shows the row; its pixels 0-7 are the HMOVE comb.
Explosion:
        lda eShape
        cmp #$30
        bne +
        rts
+       ldx #8                  ; rows: 8, or 16 (each shape row twice)
        lda eBig
        beq +
        ldx #16
+       stx eH
        lda #$53                ; kernel rows r = $53 - x: x from e83 + h - 1 down to e83
        sec
        sbc e83
        sta eRB                 ; bottom row
        sec
        sbc eH
        clc
        adc #1
        bpl +
        lda #0                  ; (clipped at the top)
+       sta eR0
        lda #$53                ; the cursor's row (its line B writes GRP1 3 pixels later)
        sec
        sbc fBall
        cmp eR0                 ; (it only matters on the explosion's rows and the one after)
        bcc +
        sta tmp
        lda eRB
        clc
        adc #1
        cmp tmp
        bcc +
        lda tmp
        bcs ++
+       lda #$ff
+       sta eBallR
        ; the same picture as this buffer's blocks hold already? Then just switch them on.
        lda rb
        asl
        asl
        sta tmp
        lda eSpr
        lsr
        ora tmp
        tax
        lda KShape,x
        cmp eShape
        bne _gen
        lda KBig,x
        cmp eBig
        bne _gen
        lda KX,x
        cmp eX
        bne _gen
        lda KR0,x
        cmp eR0
        bne _gen
        lda KRB,x
        cmp eRB
        bne _gen
        lda KBall,x
        cmp eBallR
        bne _gen
_same   lda eSpr
        jsr SprOn
        lda eBig
        beq +
        ldx eSpr
        inx
        txa
        jsr SprOn
+       jmp _place
_gen    lda Flicker             ; flicker off: one explosion made a frame; another that changed
        bne +                   ; shows its old picture a frame longer (shapes step every 8)
        lda eMade
        beq +
        lda KShape,x
        cmp #$ff
        beq +
        lda KBig,x
        sta eBig
        lda KX,x
        sta eX
        lda KR0,x
        sta eR0
        lda KRB,x
        sta eRB
        jmp _same
+       inc eMade
        lda eShape              ; (what the blocks will hold)
        sta KShape,x
        lda eBig
        sta KBig,x
        lda eX
        sta KX,x
        lda eR0
        sta KR0,x
        lda eRB
        sta KRB,x
        lda eBallR
        sta KBall,x
        ; the masks of the pixels left of the GRP1 write: rows inside the explosion (write at
        ; 58 small / 73 big), the row after it (43 / 58), +3 on the cursor's row; line A's comb
        lda #58
        ldx eBig
        beq +
        lda #73
+       sec
        sbc eX
        sta tmp4
        jsr LeftOf
        stx mIn
        sty mIn+1
        lda tmp4
        clc
        adc #3
        jsr LeftOf
        stx mInB
        sty mInB+1
        lda tmp4
        sec
        sbc #15
        jsr LeftOf
        stx mOut
        sty mOut+1
        lda tmp4
        sec
        sbc #12
        jsr LeftOf
        stx mOutB
        sty mOutB+1
        lda #8
        sec
        sbc eX
        bcs +
        lda #0
+       jsr LeftOf
        txa
        eor #$ff
        sta mComb
        tya
        eor #$ff
        sta mComb+1
        ; all on one side of the GRP1 writes (the usual case): line B is just this row's
        ; graphics (eMode 1) or the row before's ($FF), no masking
        lda #0
        sta eMode
        lda mIn
        ora mInB
        ora mOut
        ora mOutB
        ora mIn+1
        ora mInB+1
        ora mOut+1
        ora mOutB+1
        bne +
        inc eMode               ; right of them all
        bne _side
+       lda mIn
        and mInB
        and mOut
        and mOutB
        cmp #$ff
        bne _side
        ldx eBig
        beq +
        lda mIn+1
        and mInB+1
        and mOut+1
        and mOutB+1
        cmp #$ff
        bne _side
+       dec eMode               ; left of them all
_side
        ; its rows' graphics by index (0 = the bottom row): left and right byte
        ldx eH
        dex
-       txa
        ldy eBig
        beq +
        lsr
+       clc
        adc eShape
        tay
        lda ExplShapes,y
        ldy eBig
        bne +
        sta GTabL,x
        lda #0
        sta GTabR,x
        beq ++
+       tay
        lda DblHi,y
        sta GTabL,x
        lda DblLo,y
        sta GTabR,x
+       dex
        bpl -
        ; the blocks: the second's pointer in ptrC
        lda eBig
        beq +
        ldx eSpr
        inx
        txa
        jsr SprOn
        lda ptrA
        sta ptrC
        lda ptrA+1
        sta ptrC+1
+       lda eSpr
        jsr SprOn
        lda ptrA                ; (written through ptrB)
        sta ptrB
        lda ptrA+1
        sta ptrB+1
        lda #0
        sta eGp
        sta eGp+1
        sta eHalf
        tay                     ; Y = 3 * sprite row
        lda eR0
        sta eRow
        lda eMode               ; right of the GRP1 writes and clear of the comb (the usual
        cmp #1                  ; case): each row's graphics on its line B and the next line A
        bne _row
        lda mComb
        and mComb+1
        cmp #$ff
        bne _row
        lda eRB
        sec
        sbc eR0
        tax                     ; X: row eRow's index (down to 0, the bottom row)
_frow   lda GTabL,x             ; line B
        sta (ptrB),y
        iny
        lda GTabR,x
        sta (ptrB),y
        iny
        lda #0
        sta (ptrB),y
        iny
        cpy #63
        bne +
        stx tmp4
        jsr _next
        ldx tmp4
+       lda eRow                ; (the play area's last row: no line A, line 223 is the bitmap's)
        cmp #82
        bne +
        jmp _done
+       lda GTabL,x             ; line A
        sta (ptrB),y
        iny
        lda GTabR,x
        sta (ptrB),y
        iny
        lda #0
        sta (ptrB),y
        iny
        cpy #63
        bne +
        stx tmp4
        jsr _next
        ldx tmp4
+       inc eRow
        dex
        bpl _frow
        lda #0                  ; the row after the bottom: a blank line B
        sta (ptrB),y
        iny
        sta (ptrB),y
        iny
        sta (ptrB),y
        iny
        jsr _next
        jmp _done
_row    ; this row's graphics (eGc): index eRB - row, inside if < h
        lda eRB
        sec
        sbc eRow
        cmp eH
        bcs _zero
        tax
        lda GTabL,x
        sta eGc
        lda GTabR,x
        sta eGc+1
        lda #0                  ; (mask: inside)
        jmp _mask
_zero   lda #0
        sta eGc
        sta eGc+1
        lda #4                  ; (mask: outside)
_mask   ldx eGc                 ; this row and the one before both blank: a blank line B
        bne _nz
        ldx eGc+1
        bne _nz
        ldx eGp
        bne _nz
        ldx eGp+1
        bne _nz
        txa
        sta (ptrB),y
        iny
        sta (ptrB),y
        bcc _b3                 ; (always: C is clear)
        bcs _b3
_nz     ldx eMode
        beq _gen2
        bmi +
        lda eGc                 ; right of the writes: this row's graphics
        sta (ptrB),y
        iny
        lda eGc+1
        sta (ptrB),y
        jmp _b3
+       lda eGp                 ; left of them: the row before's
        sta (ptrB),y
        iny
        lda eGp+1
        sta (ptrB),y
        jmp _b3
_gen2   ldx eRow                ; (the cursor's row: the masks 2 bytes on)
        cpx eBallR
        bne +
        clc
        adc #2
+       tax                     ; X = the mask's offset from mIn
        ; line B: (Gp & left) | (Gc & ~left)
        lda mIn,x
        and eGp
        sta tmp
        lda mIn,x
        eor #$ff
        and eGc
        ora tmp
        sta (ptrB),y
        iny
        lda mIn+1,x
        and eGp+1
        sta tmp
        lda mIn+1,x
        eor #$ff
        and eGc+1
        ora tmp
        sta (ptrB),y
_b3     iny
        lda #0
        sta (ptrB),y
        iny
        jsr _next
_afterB lda eRow                ; the row after the bottom: only its line B
        cmp eRB
        beq +
        bcs _done
+       cmp #82                 ; the play area's last row: line 223 goes in the bitmap
        beq _done
        lda eGc                 ; line A: the row's graphics, comb off
        and mComb
        sta (ptrB),y
        iny
        lda eGc+1
        and mComb+1
        sta (ptrB),y
        iny
        lda #0
        sta (ptrB),y
        iny
        jsr _next
        lda eGc
        sta eGp
        lda eGc+1
        sta eGp+1
        inc eRow
        jmp _row
; after each sprite row: at 21 rows go on in the second block
_next   cpy #63
        bne +
        jsr SprEnd
        lda ptrC
        sta ptrB
        sta ptrA
        lda ptrC+1
        sta ptrB+1
        sta ptrA+1
        inc sNum
        inc eHalf
        ldy #0
+       rts
_done   jsr SprEnd              ; (clear what's left)
        lda eBig                ; a big one that ended in its first block: clear the second
        beq _place
        lda eHalf
        bne _place
        lda ptrC
        sta ptrA
        lda ptrC+1
        sta ptrA+1
        inc sNum
        ldy #0
        jsr SprEnd
_place  lda eRB                 ; down to the last row: line 223 (DrawLine223 draws it)
        cmp #82
        bne _pos
        ldx L223N
        lda eRB                 ; its graphics: shape row (x = 1) - e83, halved if big
        sec
        sbc #82
        ldy eBig
        beq +
        lsr
+       clc
        adc eShape
        tay
        lda ExplShapes,y
        sta L223G,x
        lda eBig
        sta L223Big,x
        lda eX
        sta L223X,x
        inc L223N
_pos    lda eR0                 ; positions and colours: line B of row eR0 = 58 + 2 * row
        asl
        adc #58 + LINE2RAS - 1
        sta tmp
        lda eX
        ldy eSpr
        jsr SprPos
        lda fCol
        ldx eSpr
        jsr SprCol
        lda eBig
        beq +
        lda eR0
        asl
        adc #58 + LINE2RAS - 1 + 21
        sta tmp
        lda eX
        ldy eSpr
        iny
        jsr SprPos
        lda fCol
        ldx eSpr
        inx
        jsr SprCol
+       rts

; A = k (signed: the pixels left of it): X / Y = mask of those pixels, left / right byte
; (clamped to 0-16 pixels)
LeftOf:
        cmp #$80
        bcc +
        lda #0
+       cmp #16
        bcc +
        lda #16
+       cmp #8
        bcc +
        tay
        lda LeftMask-8,y
        tay
        ldx #$ff
        rts
+       tay
        ldx LeftMask,y
        ldy #0
        rts

; ---- the ABM: row aRow ($54 up: none), pixel aX, on sprite eSpr (eSpr + 1: its part on line
; 223 right of pixel 61). Missile 1 is switched on in line B of its row and off in the next
; row's, each part-way across: the pixels right of the switch take it a line earlier. Row 82's
; next line is 223, where it goes off at pixel 106.
Abm:
        lda aRow
        bne +
        rts
+       cmp #$54
        bcc +
        rts
+       lda #$53
        sec
        sbc aRow
        sta eRow
        lda aRow                ; where row aRow's line B switches it on
        ldx #12
        jsr AbmSwitch
        sta aOn
        lda eSpr
        jsr SprOn
        lda rb                  ; (the explosion cache: these blocks no longer hold one)
        asl
        asl
        sta tmp
        lda eSpr
        lsr
        ora tmp
        tax
        lda #$ff
        sta KShape,x
        lda #0
        ldy #8
-       sta (ptrA),y
        dey
        bpl -
        lda aX                  ; line 0 (line B of the row): pixels right of the switch-on
        jsr _right
        ldy #0
        sta (ptrA),y
        lda eRow
        cmp #82
        beq _r82
        lda #$c0                ; line 1 (line A of the next row): both
        ldy #3
        sta (ptrA),y
        lda aRow                ; line 2 (line B of the next row): left of the switch-off
        sec
        sbc #1
        ldx #11
        jsr AbmSwitch
        sta aOn
        lda aX
        jsr _right
        eor #$c0
        ldy #6
        sta (ptrA),y
        ldy #9
        lda #0
        sta aL223
        beq _end
_r82    lda #106                ; row 82: line 1 is line 223, on left of pixel 106; right of
        sta aOn                 ; pixel 61 in the cities' colour (the next sprite)
        lda aX
        jsr _right
        eor #$c0
        sta tmp
        lda #61
        sta aOn
        lda aX
        jsr _right
        and tmp
        sta aL223
        eor tmp
        ldy #3
        sta (ptrA),y
        ldy #6
_end    jsr SprEnd
        lda eRow                ; position, colour: line B of the row = 58 + 2 * row
        asl
        adc #58 + LINE2RAS - 1
        sta tmp
        lda aX
        ldy eSpr
        jsr SprPos
        lda fCol
        ldx eSpr
        jsr SprCol
        lda aL223
        beq +
        ldx eSpr
        inx
        txa
        jsr SprOn
        lda aL223
        ldy #0
        sta (ptrA),y
        tya
        iny
        sta (ptrA),y
        iny
        sta (ptrA),y
        ldy #3
        jsr SprEnd
        lda #223 + LINE2RAS - 1
        sta tmp
        lda aX
        ldy eSpr
        iny
        jsr SprPos
        lda fCity
        ldx eSpr
        inx
        jsr SprCol
+       rts
; the missile's two pixels from A on: bits ($80, $40) of those at or right of aOn
_right  cmp aOn
        bcc +
        lda #$c0                ; both
        rts
+       clc
        adc #1
        cmp aOn
        bcc +
        lda #$40                ; the right one
        rts
+       lda #0
        rts

; ---- line 223 (the play area's last row is drawn on into it, model.js): player 1 still holds
; an explosion's last row there, at its place up to the RESP1 at pixel 97 (after a reset part-way
; across a line the real TIA draws nothing more of it there); the explosion's colour up to
; pixel 60 ("11": colour RAM), the cities' after ("10"). Plus the right edge's playfield
; (152-159, "01"). Redrawn when it changes.
DrawLine223:
        ldx rb                  ; nothing there, nothing drawn: nothing to do
        lda L223N
        ora Dirty223,x
        bne +
        rts
+       lda L223N
        sta Dirty223,x
        ldx #39
        lda #0
-       sta L223B,x
        dex
        bpl -
        lda #$55
        sta L223B+38
        sta L223B+39
        lda #0
        sta v1
_exp    lda v1
        cmp L223N
        beq _put
        tax
        lda L223G,x
        sta cG
        lda L223Big,x
        sta eBig
        lda L223X,x             ; at its place, before 97
        ldx #97
        jsr _player
        inc v1
        bne _exp
_put    lda rb                  ; changed? copy it into the bitmap
        asl
        asl
        asl
        sta tmp
        asl
        asl
        adc tmp
        tax                     ; 40 * buffer
        ldy #0
        sty tmp2
-       lda L223B,y
        cmp Buf223,x
        beq +
        sta Buf223,x
        inc tmp2
+       inx
        iny
        cpy #40
        bne -
        lda tmp2
        beq _cr
        ldy #223
        ldx #0
        #LinePix
        ldx #0
        ldy #0
-       lda L223B,x
        sta (ptrA),y
        tya
        clc
        adc #8
        tay
        bcc +
        inc ptrA+1
+       inx
        cpx #40
        bne -
_cr     lda L223N               ; colour RAM for the cells with "11" (cell row 23)
        bne +
        rts
+       ldx #0
-       lda L223B,x
        and #$55
        sta tmp
        lda L223B,x
        lsr
        and tmp                 ; "11" pairs
        beq +
        stx nX
        txa
        clc
        adc #<(COLRAM + 23 * 40)
        sta nLo
        lda #>(COLRAM + 23 * 40)
        adc #0
        sta nHi
        lda fCol
        jsr AddCell
        ldx nX
+       inx
        cpx #40
        bne -
        rts
; player pixels from A (the place) up to pixel X (excluded): cG, width by eBig
_player sta pX
        stx pR1
        lda #0
        sta pXX                 ; pixel of the player
-       lda pX
        clc
        adc pXX
        cmp pR1
        bcs _pend
        tax
        lda pXX
        ldy eBig
        beq +
        lsr
+       tay
        lda cG
        and BitHi,y
        beq +
        lda #3                  ; the explosion's colour before 61, the cities' after
        cpx #61
        bcc ++
        lda #2
        bne ++
+       lda #0
+       beq +
        jsr _plot
+       inc pXX
        lda pXX
        cmp #8
        beq _p8
        cmp #16
        bne -
_pend   rts
_p8     lda eBig
        bne -
        rts
; pixel X of L223B gets value A ("10" or "11")
_plot   tay
        lda Pat2,y
        and PixW,x
        pha
        lda PixCol,x
        tax
        pla
        ora L223B,x
        sta L223B,x
        rts

; Where the kernel switches missile 1 in row x = A (X = cycles after the GRP1 write: 12 when
; it's the ABM's row, 11 not): A = pixel. The GRP1 write comes 11 cycles into line B, +1 on
; the cursor's row, +15 (+20 big explosion), +3, +13 if the explosion has the row (else +8).
AbmSwitch:
        sta tmp
        stx tmp2
        lda #11 + 3
        ldy fBig
        beq +
        lda #11 + 3 + 5
+       clc
        adc #15
        ldy tmp
        cpy fBall
        bne +
        adc #0                  ; (+1: C is set)
+       sta tmp3
        lda tmp                 ; the explosion has the row: ((x - e83) & mask) == 0
        sec
        sbc f83
        ldy fBig
        beq +
        and #$fe
+       and fMask
        beq +
        lda #8
        bne ++
+       lda #13
+       clc
        adc tmp3
        adc tmp2                ; cycle t: pixel 3t - 68
        sta tmp3
        asl
        adc tmp3
        sec
        sbc #68
        rts
