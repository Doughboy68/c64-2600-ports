// Where the border colour writes land, in VICE: a breakpoint on each "sta $d020" of the build,
// the raster line and cycle of N hits each (VICE's LIN / CYC at the instruction's start: the
// write is 3 cycles later), in play (the C64 playing game 13 by itself: DbgAuto). The ground's
// write must land inside the display window (raster 245, cycles ~17-55), the black ones in the
// horizontal blank (the first cycles of raster 273 on PAL, 10 on NTSC; see GROUNDRAS in
// c64/main.asm), else the 8565's grey dots and part-coloured lines show.
//   node games/missile-command/tools/c64irq.js [N] [--ntsc]
const net = require('net');
const fs = require('fs');
const path = require('path');
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
const ntsc = process.argv.includes('--ntsc');
const N = +(process.argv.find(a => /^\d+$/.test(a)) || 12);
const build = process.env.MC_BUILD || path.join(__dirname, '..', 'build');   // (MC_BUILD: another build's folder)
const { prg: prgFile, lst: lstFile } = require('./buildfiles').files(build);
const lst = fs.readFileSync(lstFile, 'latin1');
const addr = n => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${n}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + n);
  return parseInt(m[1], 16);
};
// the sta $d020 instructions (8d 20 d0) in the listing
const stas = [...lst.matchAll(/^\.([0-9a-f]{4})\t8d 20 d0\t[^\n]*/gm)].map(m => ({ a: parseInt(m[1], 16), src: m[0].split('\t').slice(-1)[0].trim() }));
const hex = v => v.toString(16);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let vice = null, PORT = 0;
const session = () => new Promise((resolve, reject) => {
  const s = net.connect(PORT, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d; }); s.on('error', reject);
  s.on('connect', () => resolve({ send: c => s.write(c + '\n'), text: () => b, clear: () => { b = ''; }, end: () => s.end() }));
});
const mon = async cmds => {
  const s = await session(); await sleep(150);
  for (const c of cmds) { s.send(c); await sleep(400); }
  s.send('x'); await sleep(100); s.end(); return s.text();
};

(async () => {
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prgFile]);
  for (let t = 0; t < 40; t++) { await sleep(1000); try { if (await runsOurs(mon, prgFile)) break; } catch { /* not up yet */ } }
  await sleep(3000);
  if (!await runsOurs(mon, prgFile)) throw new Error(`the VICE on port ${PORT} isn't running our build: stopping`);
  await mon([`> ${hex(addr('Flicker'))} 0`, `> ${hex(addr('DbgAuto'))} d`, `> ${hex(addr('PowerReq'))} 1`]);
  await sleep(15000);                                   // (into the game)
  for (const st of stas) {
    const s = await session(); await sleep(200);
    s.send(`break exec ${hex(st.a)}`); await sleep(300);
    const hits = [];
    for (let k = 0; k < N; k++) {
      s.clear(); s.send('x');
      let hit = false;
      for (let w = 0; w < 40 && !hit; w++) { await sleep(100); hit = /Stop on/i.test(s.text()); }
      if (!hit) break;                                  // (not run in play: start-up code, testing aids)
      s.clear(); s.send('r'); await sleep(400);
      const r = s.text().match(/LIN CYC[^\n]*\n\.;[0-9a-f]{4}(?:\s+\S+){7}\s+(\d+)\s+(\d+)/i);
      if (!r) { console.log('unexpected monitor reply: ' + JSON.stringify(s.text().slice(0, 300))); break; }
      hits.push(`${+r[1]}:${+r[2]}`);
    }
    s.send('del'); await sleep(200); s.send('x'); await sleep(100); s.end();
    const count = {};
    for (const x of hits) count[x] = (count[x] || 0) + 1;
    console.log(`${ntsc ? 'NTSC' : 'PAL'} $${hex(st.a)} ${st.src}: ` +
      (hits.length ? Object.entries(count).sort().map(([k, v]) => `${k} x${v}`).join(', ') : 'not reached'));
  }
})().catch(e => console.log(e.message)).finally(() => {   // close the VICE started here, whatever happened
  stopVice(vice);
});
