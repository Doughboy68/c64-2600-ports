// Generate lookup tables for the Missile Command C64 port: c64/tables.inc (no game data in them)
//   node games/missile-command/tools/mkc64tables.js
const fs = require('fs');
const out = [];
const bytes = (label, arr, comment) => {
  out.push('', `; ${comment}`, `${label}:`);
  for (let i = 0; i < arr.length; i += 16)
    out.push('        .byte ' + arr.slice(i, i + 16).map(v => '$' + (v & 255).toString(16).padStart(2, '0')).join(', '));
};

// ---- 2600 NTSC colour -> C64 colour, indexed by (colour >> 1) = hue * 8 + luminance.
// Nearest C64 colour to the standard 2600 NTSC palette, brightened to match how the game
// looks on a TV, compared in YUV with extra weight on hue. Clearly coloured 2600 colours never
// map to the C64's greys. (As in the other ports.)
const NTSC = `000000 404040 6C6C6C 909090 B0B0B0 C8C8C8 DCDCDC ECECEC
444400 646410 848424 A0A034 B8B840 D0D050 E8E85C FCFC68
702800 844414 985C28 AC783C BC8C4C CCA05C DCB468 ECC878
841800 983418 AC5030 C06848 D0805C E09470 ECA880 FCBC94
880000 9C2020 B03C3C C05858 D07070 E08888 ECA0A0 FCB4B4
78005C 8C2074 A03C88 B0589C C070B0 D084C0 DC9CD0 ECB0E0
480078 602090 783CA4 8C58B8 A070CC B484DC C49CEC D4B0FC
140084 302098 4C3CAC 6858C0 7C70D0 9488E0 A8A0EC BCB4FC
000088 1C209C 3840B0 505CC0 6874D0 7C8CE0 90A4EC A4B8FC
00187C 1C3890 3854A8 5070BC 6888CC 7C9CDC 90B4EC A4C8FC
002C5C 1C4C78 386890 5084AC 689CC0 7CB4D4 90CCE8 A4E0FC
003C2C 1C5C48 387C64 509C80 68B494 7CD0AC 90E4C0 A4FCD4
003C00 205C20 407C40 5C9C5C 74B474 8CD08C A4E4A4 B8FCB8
143800 345C1C 507C38 6C9850 84B468 9CCC7C B4E490 C8FCA4
2C3000 4C501C 687034 848C4C 9CA864 B4C078 CCD488 E0EC9C
442800 644818 846830 A08444 B89C58 D0B46C E8CC7C FCE08C`.split(/\s+/).map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
// C64 colours as VICE shows them by default (its 'colodore' palette)
const PEPTO = ['000000','FFFFFF','96282E','5BD6CE','9F2DAD','41B936','2724C4','EFF347','9F4815','5E3500','DA5F66','474747','787878','91FF84','6864FF','AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
const BOOST = 1.3;              // the 2600 palette tables are darker than a TV shows them
const CHROMA = 2.5;             // weight of hue/saturation against brightness
const GREYS = [0, 1, 11, 12, 15];
const yuv = c => { const [r, g, b] = c; const y = 0.299 * r + 0.587 * g + 0.114 * b; return [y, 0.492 * (b - y), 0.877 * (r - y)]; };
const dist = (a, b) => { const p = yuv(a), q = yuv(b); return (p[0] - q[0]) ** 2 + CHROMA * ((p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2); };
const map = NTSC.map(c => {
  const lit = c.map(v => Math.min(255, v * BOOST));
  const mx = Math.max(...c), mn = Math.min(...c), sat = mx ? (mx - mn) / mx : 0;
  let best = -1;
  PEPTO.forEach((p, i) => {
    if (sat > 0.2 && GREYS.includes(i)) return;
    if (best < 0 || dist(lit, p) < dist(lit, PEPTO[best])) best = i;
  });
  return best;
});
bytes('ColorMap', map, '2600 colour (value >> 1) -> C64 colour');

// ---- TIA sound -> SID. TIA audio clock is 3.579545 MHz / 114 = 31399.5 Hz.
// Per AUDC value: SID waveform and the divider that sets the tone frequency.
const TIA_CLOCK = 3579545 / 114;
const SID_CLOCKS = { '': 985248, N: 1022727 };   // PAL, NTSC: the SID's pitch follows the CPU clock
const AUDC = [            // [waveform, divider]; noise uses divider as sample-rate divider
  [0x00, 1],    // 0 silent
  [0x80, 1],    // 1 4-bit poly
  [0x40, 15],   // 2 div 15 -> 4-bit poly
  [0x80, 2],    // 3 5-bit -> 4-bit poly
  [0x40, 2],    // 4 pure /2
  [0x40, 2],    // 5 pure /2
  [0x40, 31],   // 6 pure /31
  [0x40, 31],   // 7 5-bit poly /2 (buzzy)
  [0x80, 1],    // 8 9-bit poly (white noise)
  [0x40, 31],   // 9 5-bit poly
  [0x40, 31],   // 10 pure /31
  [0x00, 1],    // 11 silent
  [0x40, 6],    // 12 pure /6
  [0x40, 6],    // 13 pure /6
  [0x40, 93],   // 14 pure /93
  [0x40, 186],  // 15 5-bit poly /6
];
bytes('SidWave', AUDC.map(a => a[0]), 'SID waveform per AUDC value (0 = silent)');
for (const [suffix, clock] of Object.entries(SID_CLOCKS)) {
  const flo = [], fhi = [];
  for (const [wave, div] of AUDC) {
    for (let f = 0; f < 32; f++) {
      let hz = TIA_CLOCK / (f + 1) / div;
      if (wave === 0x80) hz /= 16;          // SID noise steps 16x per oscillator period
      const reg = Math.min(0xFFFF, Math.round(hz * 16777216 / clock));
      flo.push(reg & 255); fhi.push(reg >> 8);
    }
  }
  const sys = suffix ? 'NTSC' : 'PAL';
  bytes('SidFreqLo' + suffix, flo, `SID frequency low byte (${sys}), index AUDC * 32 + AUDF`);
  bytes('SidFreqHi' + suffix, fhi, `SID frequency high byte (${sys}), must follow the low bytes directly`);
}

// (The bitmap line, pixel and doubled-bit tables are built at start-up: InitTables in c64/main.asm.)

// ---- a 2600 byte as four multicolour pixels each: high and low nibble -> bitmap byte with
// "10" for each set bit (and "01" for a set bit with the second table)
const mc = (n, pat) => { let v = 0; for (let b = 3; b >= 0; b--) v = v << 2 | ((n >> b) & 1) * pat; return v; };
bytes('Nib10', [...Array(16).keys()].map(n => mc(n, 2)), 'four pixels (a nibble, high bit left) as "10" pairs');
bytes('Nib01', [...Array(16).keys()].map(n => mc(n, 1)), 'four pixels as "01" pairs');

fs.writeFileSync(__dirname + '/../c64/tables.inc', '; Generated by games/missile-command/tools/mkc64tables.js - do not edit\n' + out.join('\n') + '\n');
console.log('wrote games/missile-command/c64/tables.inc');
