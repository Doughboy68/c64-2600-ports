// Run the original in tools/vcs.js with the random player and save pictures.
//   node games/missile-command/tools/run.js frames [--seed=N] [--at=f1,f2,...] [--out=dir]
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load(require('../2600/symbols.js').game.md5);
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? a.split('=')[1] : d; };
const frames = +(process.argv[2] || 600);
const at = new Set((arg('at', '') || '').split(',').filter(Boolean).map(Number));
const out = arg('out', '.');
const play = require('./play')(+arg('seed', 1));
const v = new VCS(rom);
v.cropTop = 20; v.cropHeight = 230;
for (let f = 0; f < frames; f++) {
  const p = play(f, v.ram);
  v.swcha = p.swcha; v.swchb = p.swchb; v.fire[0] = v.fire[1] = p.fire;
  v.runFrames(1);
  if (at.has(f)) { v.savePNG(path.join(out, `f${f}.png`)); console.log(f, 'saved', [...v.ram].map(x => x.toString(16).padStart(2, '0')).join('')); }
}
