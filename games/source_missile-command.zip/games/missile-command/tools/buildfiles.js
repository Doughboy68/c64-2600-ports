// The build's file names: missilecmd-<version>.prg / .d64 / .lst, the version from the BASIC
// listing in c64/main.asm (" version 0.1"). The name (without .prg) must fit the C64's 16
// characters: on a C64 drive (SD2IEC, 1541 Ultimate) longer ones get cut short.
//   node games/missile-command/tools/buildfiles.js   prints the name (for build.cmd)
//   require('./buildfiles').files(dir) -> { prg, lst } in that folder (another build's folder
//   may hold another version, or older names: then the one .prg there)
const fs = require('fs');
const path = require('path');
const NAME = 'missilecmd';
const version = () => fs.readFileSync(path.join(__dirname, '..', 'c64', 'main.asm'), 'latin1').match(/" version ([\d.]+)"/)[1];
function base() {
  const b = `${NAME}-${version()}`;
  if (b.length > 16) throw new Error(`${b}: longer than a C64 file name (16 characters)`);
  return b;
}
function files(dir) {
  let b = base();
  if (!fs.existsSync(path.join(dir, b + '.prg'))) {
    const found = fs.readdirSync(dir).filter(f => /^missile.*\.prg$/i.test(f));
    if (found.length === 1) b = found[0].slice(0, -4);
  }
  return { prg: path.join(dir, b + '.prg'), lst: path.join(dir, b + '.lst') };
}
module.exports = { version, base, files };
if (require.main === module) console.log(base());
