// Two builds' renders side by side: the same inputs (tools/play.js, the 2600 alongside for its
// aiming) into both, and after every render what each would show compared: what the VIC shows
// of both banks (screen colours and sprite blocks, +$0000-$05FF; bitmaps, +$2000-$3FFF), the staged sprite registers, background and ground
// colours, and the warhead colour RAM cells (as a set: their order doesn't matter). For changes
// meant to draw the same picture faster (flicker off has no 2600 picture to compare with, so
// screencheck.js can't check it), and the cycles each build's renders take.
//   node games/missile-command/tools/rendercheck.js <reference build dir> [frames] [--seed=N]
//        [--game=N] [--flicker] [--ntsc] [--pal] [--power=N]
// The build checked is build/ (or MC_BUILD); flicker is off unless --flicker; --pal draws 5
// ticks in 6 as a PAL C64 does.
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const refDir = process.argv[2];
const { files } = require('./buildfiles');
if (!refDir || !fs.existsSync(files(refDir).prg)) throw new Error('usage: rendercheck.js <reference build dir> [frames] ...');
const frames = +(process.argv[3] || 3000);
const pal = process.argv.includes('--pal');

const mk = dir => {
  const c = new C64();
  if (dir) {                                    // (another build: its program and listing)
    const prg = fs.readFileSync(files(dir).prg);
    c.lst = fs.readFileSync(files(dir).lst, 'latin1');
    c.mem.fill(0);
    c.mem.set(prg.subarray(2), prg.readUInt16LE(0));
  }
  c.start(!process.argv.includes('--ntsc'));
  if (!process.argv.includes('--flicker')) c.mem[c.sym('Flicker')] = 0;
  return c;
};
const cs = [mk(null), mk(refDir)];
const KERNEL = 0xF96E;
let vcs, atKernel = false, kf = -1;
const newVcs = () => {
  vcs = new VCS(rom); kf = -1;
  const st = vcs.step.bind(vcs);
  vcs.step = function () { if (this.pc === KERNEL && this.frames !== kf) { atKernel = true; kf = this.frames; } return st(); };
};
newVcs();
const play = require('./play')(arg('seed', 21), { game: arg('game', 13) });
const powerAt = arg('power', -1);

const SHOWN = i => (i & 0x3fff) < 0x600 || (i & 0x3fff) >= 0x2000;   // (bank offset i: the VIC shows it)
// what a build shows from buffer b
const shown = (c, b) => {
  const s = n => c.sym(n), m = c.mem;
  const out = { banks: m.subarray(0x4000, 0xC000) };   // (compared where SHOWN says)
  out.regs = [...m.subarray(s('StX') + 8 * b, s('StX') + 8 * b + 8), ...m.subarray(s('StY') + 8 * b, s('StY') + 8 * b + 8),
    ...m.subarray(s('StCol') + 8 * b, s('StCol') + 8 * b + 8), m[s('StMsb') + b], m[s('StEn') + b], m[s('StBg') + b], m[s('StGround') + b]];
  const base = m[s('CrBase') + b], n = m[s('CrN') + b], cells = new Map();
  for (let i = base; i < base + n; i++) cells.set(m[s('CrLo') + i] | m[s('CrHi') + i] << 8, m[s('CrCol') + i]);
  out.cells = cells;
  return out;
};
let bad = 0, done = 0;
const cyc = [0, 0], max = [0, 0], over = [0, 0];
for (let f = 0; f < frames; f++) {
  if (f === powerAt) { for (const c of cs) c.call(c.sym('PowerCycle')); newVcs(); console.log(`frame ${f}: power off and on`); }
  const p = play(f, vcs.ram, vcs);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  atKernel = false; while (!atKernel) vcs.step();
  for (const c of cs) {
    c.mem[0x0280] = p.swcha; c.mem[0x0282] = p.swchb; c.mem[0x3C] = c.mem[0x3D] = p.fire ? 0 : 0x80;
    c.call(c.sym('Tick'));
    for (let a = 0x80; a < 0xFC; a++) c.mem[a] = vcs.ram[a - 0x80];    // (lockstep.js checks the ticks)
  }
  if (pal && f % 6 === 5) continue;
  const res = cs.map((c, k) => {
    c.mem[c.sym('pending')] = 0;
    c.mem[c.sym('curBuf')] ^= 1;
    const rc = c.call(c.sym('Render'));
    if (f >= 30) { cyc[k] += rc; max[k] = Math.max(max[k], rc); if (rc > 11500) over[k]++; }
    return shown(c, c.mem[c.sym('curBuf')] ^ 1);
  });
  if (f >= 30) done++;
  const d = [];
  const [a, b] = res;
  let nb = 0, first = -1;
  for (let i = 0; i < a.banks.length; i++) if (SHOWN(i) && a.banks[i] !== b.banks[i]) { if (first < 0) first = i; nb++; }
  if (nb) d.push(`${nb} video bytes (first $${(0x4000 + first).toString(16)})`);
  if (nb && process.argv.includes('--verbose') && bad < 10)   // bitmap bytes: 2600 line, pixels, the two values
    for (let i = 0; i < a.banks.length; i++) if (SHOWN(i) && a.banks[i] !== b.banks[i]) {
      const o = i & 0x3fff;
      const where = o >= 0x2000 && o < 0x2000 + 8000
        ? `line ${39 + Math.floor((o - 0x2000) / 320) * 8 + (o - 0x2000) % 8} pixels ${((o - 0x2000) % 320 >> 3) * 4}+` : `bank offset $${o.toString(16)}`;
      d.push(`\n    ${where}: ${a.banks[i].toString(2).padStart(8, 0)} (reference ${b.banks[i].toString(2).padStart(8, 0)})`);
    }
  if (a.regs.some((v, i) => v !== b.regs[i])) d.push('sprite registers / colours');
  const cellDiff = [...new Set([...a.cells.keys(), ...b.cells.keys()])].filter(k => a.cells.get(k) !== b.cells.get(k));
  if (cellDiff.length) d.push(`colour cells ${cellDiff.map(k => '$' + k.toString(16)).join(' ')}`);
  if (d.length) {
    bad++;
    if (bad <= 10) console.log(`frame ${f}: ${d.join(', ')}`);
    for (let i = 0x4000; i < 0xC000; i++) if (SHOWN(i - 0x4000)) cs[1].mem[i] = cs[0].mem[i];   // (carry on from the same picture)
  }
}
const k = n => Math.round(n / done);
console.log(`${done} renders, ${bad} different; cycles on average ${k(cyc[0])} (reference ${k(cyc[1])}), ` +
  `at most ${max[0]} (${max[1]}), over 11500: ${over[0]} (${over[1]})`);
