// Draw the C64 frame from what the C64 code set up (the buffer's bitmap, its screen colours,
// the colour RAM its frame top writes, the background, the sprites: X-expanded, one row a
// line, behind the bitmap's "10"/"11" pixels, lower numbers in front) and compare it with the
// 2600's picture (tools/vcs.js, HMOVE blank on), in C64 colours, lines 39-238 (what the C64
// shows). Runs the game as lockstep.js does (the same inputs on both).
//   node games/missile-command/tools/screencheck.js [frames] [--seed=N] [--diff=A] [--ntsc]
//        [--png=frame] [--verbose]
// --png=N writes check-N.png: the 2600's picture left, the C64's right (C64 colours); --png=first
// does so for the first frame that differs.
const fs = require('fs');
const zlib = require('zlib');
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 2000);
const verbose = process.argv.includes('--verbose');
const pngAt = arg('png', -1);

const c64 = new C64();
c64.start(!process.argv.includes('--ntsc'));
const sym = n => c64.sym(n);
const M = c64.mem;
const COLORMAP = M.slice(sym('ColorMap'), sym('ColorMap') + 128);
const S = n => sym(n);
const FIRST = 39, LAST = 238, LINE2RAS = 12;

// the original, stopped at its overscan's timer loop (the picture's lines all drawn)
const RESUME = 0xFA6F;
const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;   // (the real TIA, as Stella shows it)
let at = false, atFrame = -1;
{ const st = vcs.step.bind(vcs); vcs.step = function () { if (this.pc === RESUME && this.frames !== atFrame) { at = true; atFrame = this.frames; } return st(); }; }
const runTo = () => { at = false; let g = 0; while (!at) { vcs.step(); if (++g > 2e6) throw new Error('2600 never got there'); } };

// The C64 picture of buffer b: C64 colour per 2600 pixel, lines FIRST..LAST
function c64Picture(b) {
  const pic = new Uint8Array(160 * 262);
  pic.src = new Array(160 * 262);              // where each pixel's colour came from
  const bmp = [0x6000, 0xA000][b], scr = [0x4000, 0x8000][b], spr = [0x4400, 0x8400][b];
  const bg = M[S('StBg') + b] & 15;
  const en = M[S('StEn') + b], msb = M[S('StMsb') + b];
  const sp = [];
  for (let i = 0; i < 8; i++) if (en & (1 << i)) sp.push({ i, x: M[S('StX') + 8 * b + i] + ((msb >> i) & 1) * 256, y: M[S('StY') + 8 * b + i], col: M[S('StCol') + 8 * b + i] & 15, data: M.subarray(spr + 64 * i, spr + 64 * i + 63) });
  for (let L = FIRST; L <= LAST; L++) {
    const row = (L - 39) >> 3, line = (L - 39) & 7, ras = L + LINE2RAS;
    for (let x = 0; x < 160; x++) {
      const cell = row * 40 + (x >> 2);
      const byte = M[bmp + row * 320 + (x >> 2) * 8 + line];
      const bits = (byte >> (2 * (3 - (x & 3)))) & 3;
      let col = bits === 0 ? bg : bits === 1 ? M[scr + cell] >> 4 : bits === 2 ? M[scr + cell] & 15 : c64.colram[cell];
      let src = 'bitmap ' + bits.toString(2).padStart(2, '0');
      if (bits < 2) {                       // sprites show in front of "00" and "01" only
        for (const s of sp) {
          const r = ras - (s.y + 1), j = ((24 + 2 * x) - s.x) >> 1;
          if (r < 0 || r > 20 || 24 + 2 * x < s.x || j > 23) continue;
          if ((s.data[3 * r + (j >> 3)] >> (7 - (j & 7))) & 1) { col = s.col; src = `sprite ${s.i} row ${r}`; break; }
        }
      }
      pic[L * 160 + x] = col;
      pic.src[L * 160 + x] = src;
    }
  }
  return pic;
}

// what the frame top writes into the colour RAM for buffer b
function frameTop(b) {
  const n = M[S('CrN') + b], base = b * M[S('CrBase') + 1];
  for (let k = 0; k < n; k++) {
    const a = M[S('CrLo') + base + k] | M[S('CrHi') + base + k] << 8;
    c64.colram[a - 0xD800] = M[S('CrCol') + base + k] & 15;
  }
}

const PAL = ['000000','FFFFFF','96282E','5BD6CE','9F2DAD','41B936','2724C4','EFF347','9F4815','5E3500','DA5F66','474747','787878','91FF84','6864FF','AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
function png(file, a, b) {
  const W = 2 * 320 + 8, H = (LAST - FIRST + 1) * 2;
  const raw = Buffer.alloc((W * 3 + 1) * H);
  for (let y = 0; y < H; y++) {
    const L = FIRST + (y >> 1), o = y * (W * 3 + 1);
    for (let x = 0; x < W; x++) {
      let c = [40, 40, 40];
      if (x < 320) c = PAL[a[L * 160 + (x >> 1)]];
      else if (x >= 328) c = PAL[b[L * 160 + ((x - 328) >> 1)]];
      raw.set(c, o + 1 + 3 * x);
    }
  }
  const crcT = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; return c; });
  const crc = buf => { let c = -1; for (const v of buf) c = crcT[(c ^ v) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
  const ih = Buffer.alloc(13); ih.writeUInt32BE(W, 0); ih.writeUInt32BE(H, 4); ih[8] = 8; ih[9] = 2;
  fs.writeFileSync(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
}

const play = require('./play')(arg('seed', 11), { diff: process.argv.includes('--diff=A') ? 0xC0 : 0, game: arg('game', 0) });
const cov = {};
let bad = 0, checked = 0, badPix = 0;
for (let f = 0; f < frames; f++) {
  const p = play(f, vcs.ram, vcs);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  M[0x0280] = p.swcha; M[0x0282] = p.swchb; M[0x3C] = M[0x3D] = p.fire ? 0 : 0x80;
  runTo();
  c64.call(S('Tick'));
  M[S('pending')] = 0;
  const b = M[S('curBuf')] ^ 1;
  c64.call(S('Render'));
  M[S('curBuf')] = b;                       // shown from the next frame top
  frameTop(b);
  if (f < 3) continue;
  const pic = c64Picture(b);
  checked++;
  const diffs = [];
  for (let L = FIRST; L <= LAST; L++) for (let x = 0; x < 160; x++) {
    const want = COLORMAP[vcs.fb[L * 160 + x]] & 15, got = pic[L * 160 + x];
    if (want !== got) diffs.push(`line ${L} px ${x}: 2600 ${want} (objects ${vcs.ob[L * 160 + x]}) C64 ${got} (${pic.src[L * 160 + x]})`);
  }
  if (diffs.length) {
    bad++; badPix += diffs.length;
    if (bad <= 6 || verbose) console.log(`frame ${f}: ${diffs.length} pixels differ\n  ` + diffs.slice(0, 8).join('\n  '));
    if (bad === 1 && process.argv.includes('--png=first')) png(`check-${f}.png`, Uint8Array.from(vcs.fb, v => COLORMAP[v] & 15), pic);
  }
  if (f === pngAt) png(`check-${f}.png`, Uint8Array.from(vcs.fb, v => COLORMAP[v] & 15), pic);
}
console.log(`${checked} frames checked, ${bad} with differences (${badPix} pixels)`);
