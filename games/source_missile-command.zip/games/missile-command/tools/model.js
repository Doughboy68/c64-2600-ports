// A model of what Missile Command's kernel draws, built only from RAM and the TIA registers
// as the kernel starts ($F7D1, where the game waits for its timer), checked pixel by pixel
// against tools/vcs.js over random games: the objects in each pixel and the colour. The C64
// version draws from the same rules, so this is where its geometry is worked out and proven.
//
// The game never reads the TIA's collision registers (it works out every hit itself), so the
// picture is all there is to get right.
//
// The model restates the kernel as the TIA writes it makes on each line, with the cycle each
// one lands on (counted from the end of WSYNC), following the kernel's own branches; the
// writes are then played on a bare TIA (tools/vcs.js's pixel rules). A write that ends on
// cycle c changes pixels from 3c - 68 on.
//
// The picture (2600 lines, counted from the end of VSYNC):
//   41       blank (VBLANK ends)
//   42-48    score: six digits (players 0 and 1, three copies each, VDEL)
//   52       HMOVE comb (player 1 positioned for the explosion)
//   57-222   the play area, 83 rows of 2 lines (row r: lines 57+2r, 58+2r), HMOVE on the
//            first line of each (its first 8 pixels blank):
//            missile 0  one attacking missile's trail (with up to 3 copies), moved sideways
//                       by HMOVE; its last row (the warhead) in another colour
//            player 1   one ABM explosion (of three, in turns), small or big
//            missile 1  one ABM in flight (of three, in turns)
//            ball       the cursor
//   223      the trail's and ABM's leftovers, playfield and players set up mid-line
//   224-232  cities (players 0 and 1, three copies each, graphics rewritten mid-line), hills
//   233-237  the ground: the ABMs left (player 1, double width), players' markers (playfield)
//   238-     ground colour to the end of the frame (the C64 shows up to line 238)
//
//   node games/missile-command/tools/model.js [frames] [--seed=N] [--verbose] [--show=frame]
'use strict';
const { VCS } = require('../../../tools/vcs');
const ROMMD5 = require('../2600/symbols.js').game.md5;
const rom = require('../../../tools/rom').load(ROMMD5);
const HPOS = require('./hpos.json');

const KERNEL = 0xF7D1;
const FIRST = 39, LAST = 238;           // lines the C64 shows
const ROM = a => rom[a & 0xFFF];

// ---- snapshot: RAM and the TIA registers as the kernel starts
function snap(v) {
  return { ram: Uint8Array.from(v.ram), r: Uint8Array.from(v.r), grpOld: [...v.grpOld], blOld: v.blOld };
}

// The kernel's writes: lines[L] = [[cycle, register, value], ...]; 'HMOVE' and 'RES' entries
// are strobes. Also returns facts the C64 version uses (positions, rows).
function schedule(s) {
  const R = a => s.ram[a - 0x80];
  const M = a => a >= 0x1000 ? ROM(a) : R(a);
  const ind = (zp, y) => M(((R(zp) | R(zp + 1) << 8) + y) & 0xFFFF);
  const L = {};
  const w = (line, c, reg, v) => (L[line] = L[line] || []).push([c, reg, v]);

  // line 41: VBLANK off at 3; HMM0, HMM1, HMBL cleared at 9, 12, 15
  w(41, 9, 0x22, 0); w(41, 12, 0x23, 0); w(41, 15, 0x24, 0);
  // score, lines 42-48: the loop at $F7E6 (VDELP0/1 on, three copies 16 apart). Each row's
  // first GRP0 (the left digit) is written at the end of the line before (31 on line 41, 72 after).
  // (The digit graphics are all in one page: no page crossings.)
  for (let y = 6; y >= 0; y--) {
    const n = 48 - y;
    w(n - 1, y === 6 ? 31 : 72, 0x1B, ind(0xCB, y));
    w(n, 8, 0x1C, ind(0xCD, y)); w(n, 16, 0x1B, ind(0xCF, y));
    w(n, 44, 0x1C, ind(0xD1, y)); w(n, 47, 0x1B, ind(0xD3, y));
    w(n, 50, 0x1C, ind(0xD5, y)); w(n, 53, 0x1B, ind(0xD5, y));
  }
  // line 49: VDEL off, graphics cleared, CTRLPF, the cursor's colour
  w(49, 5, 0x25, 0); w(49, 8, 0x26, 0); w(49, 11, 0x1B, 0); w(49, 14, 0x1C, 0);
  w(49, 19, 0x0A, 0x21); w(49, 27, 0x08, R(0x80) & 0x0F);
  // line 50: colours
  const xc = R(0xCA);
  const expCol = R(0xD7);                // COLUP1: explosion / ABM colour ($D7 as the kernel starts)
  let wh = R(0xE6);                      // the warhead colour the kernel works out into $D7
  if (!(R(0x97) & 2)) { wh = 0; if (!(R(0x80) & 8)) wh = 0x0F; }
  wh &= R(0x86);
  w(50, 6, 0x06, R(0xE3)); w(50, 12, 0x09, R(0xE4)); w(50, 18, 0x07, expCol);
  w(50, 40, 0x04, R(0x91)); w(50, 46, 0x05, R(0xEE));
  // player 1 to the explosion's X ($A6,x) by the positioning routine ($F005), then HMOVE.
  // How long it takes to reach its WSYNC depends on the path above and on X (its divide
  // loop): T cycles from the start of line 50. RESP1 lands on the line after that WSYNC,
  // the HMOVE (and its comb) one line later, or two when the RESP is late in its line.
  const p1x = R(0xA6 + xc);
  const big = R(0xA1) === 0xF0;
  const n = Math.floor((((big ? 0xFC : 1) + p1x) & 0xFF) / 15) + 1;
  const T = (R(0x97) & 2 ? 0 : R(0x80) & 8 ? 9 : 10) + 7 * n + (big ? 1 : 0) + 110;
  const respLine = 50 + Math.ceil((T + 3) / 76);
  const hmoveLine = respLine + (5 * n + 31 > 76 ? 2 : 1);
  w(51, 0, 0x21, 0); w(51, 70, 'RESP1', big ? HPOS.big[p1x] : HPOS.player[p1x]);
  w(hmoveLine, 3, 'HMOVE', 0);

  // the play area
  const m0first = HPOS.missile[R(0x88)];
  let acc = 0, hmm0 = 0;
  const y93 = R(0x93), b97 = R(0x97), y85 = R(0x85), y84 = R(0x84), y83 = R(0x83), a1 = R(0xA1), a2 = R(0xA2);
  let warheadRow = -1;
  for (let r = 0; r < 83; r++) {
    const x = 0x53 - r, la = 57 + 2 * r, lb = la + 1;
    w(la, 3, 'HMOVE', hmm0);
    // ENAM0 and the warhead colour
    let en, ce;
    if (x === y93) {
      w(la, 16, 0x06, wh); warheadRow = r;
      if (wh) { en = 2; ce = 22; } else { en = (b97 & 2) ? 0 : 2; ce = 29; }
    } else if (b97 & 2) { en = 0; ce = 22; }
    else if (x > y93) { en = 2; ce = 22; }
    else { en = 0; ce = 23; }
    w(la, ce, 0x1D, en);
    acc += R(0x95);
    hmm0 = acc > 0xFF ? b97 : 0; acc &= 0xFF;
    // line B: ball, explosion row, ABM
    const ball = x === y85;
    let t = ball ? 12 : 11;
    w(lb, t, 0x1F, ball ? 2 : 0);
    let yy = (x - y83) & 0xFF, a = yy;
    if (a2 & 0x80) { yy = a >> 1; a = (yy << 1) & 0xFF; }
    // after "bit $A2 / bpl" (+ lsr tay asl): small 15 cycles on, big 20
    t = (ball ? 12 : 11) + ((a2 & 0x80) ? 20 : 15);
    t += 3;                              // and $A1
    let g;
    if (a & a1) { g = 0; t += 3 + 2 + 3; }
    else {
      const base = R(0x8B) | R(0x8C) << 8;
      g = M((base + yy) & 0xFFFF);
      t += 2 + 5 + (((base & 0xFF) + yy) > 0xFF ? 1 : 0) + 3 + 3;
    }
    w(lb, t, 0x1C, g);
    t += 2 + 3 + (x === y84 ? 2 + 2 : 3) + 3;
    w(lb, t, 0x1E, x === y84 ? 2 : 0);
  }
  // line 223
  w(223, 17, 0x1E, y84 === 1 ? 2 : 0);
  w(223, 22, 0x1D, 0); w(223, 25, 0x1D, 0);
  w(223, 28, 'RESP0', 0);
  w(223, 34, 0x08, R(0xE5)); w(223, 40, 0x06, R(0xE2)); w(223, 43, 0x07, R(0xE2)); w(223, 46, 0x07, R(0xE2));
  w(223, 55, 'RESP1', 0); w(223, 58, 0x1E, 8); w(223, 61, 0x0D, 0x30);
  w(223, 66, 0x04, 3); w(223, 69, 0x05, 3);
  // cities, lines 224-232
  for (let y = 8; y >= 0; y--) {
    const line = 232 - y;
    w(line, 7, 0x0F, ROM(0xFF7F + y));
    w(line, 22, 0x1B, ind(0xA9, y)); w(line, 32, 0x1B, ind(0xAB, y)); w(line, 38, 0x1B, ind(0xAD, y));
    w(line, 53, 0x1C, ind(0xAF, y)); w(line, 61, 0x1C, ind(0xB1, y)); w(line, 66, 0x1C, ind(0xB3, y));
  }
  // line 233
  w(233, 5, 0x05, 5); w(233, 11, 0x09, R(0xE5)); w(233, 19, 0x0F, 0); w(233, 22, 0x0D, 0);
  w(233, 25, 0x1B, 0); w(233, 45, 'RESP1', 0); w(233, 51, 0x07, R(0xE4)); w(233, 54, 0x08, R(0xE4));
  // ground, lines 234-237: the ABMs left, the players' markers (PF0, rewritten mid-line)
  const pile = 0xFF00 | ROM(0xFEE2 + R(0xDD));
  const pf = ROM(0xFE7C + (R(0xDB) & 3));
  for (let y = 3; y >= 0; y--) {
    const line = 237 - y;
    w(line, 8, 0x1C, ROM(pile + y)); w(line, 15, 0x0D, pf); w(line, 40, 0x0D, pf >> 4);
  }
  w(238, 6, 0x09, R(0xE5)); w(238, 17, 0x1C, 0);
  return { lines: L, hmoveLine, m0first, warheadRow, wh, expCol, p1x: big ? HPOS.big[p1x] : HPOS.player[p1x] };
}

// Play the writes on a bare TIA: { fb, ob } for lines FIRST..LAST (like tools/vcs.js)
function render(s) {
  const sch = schedule(s);
  const t = new VCS(rom);
  t.hmoveBlank = t.wideDelay = t.respDelay = true;   // (the real TIA, as Stella shows it: tools/stellacheck.js)
  t.r.set(s.r); t.grpOld = [...s.grpOld]; t.blOld = s.blOld;
  const R = a => s.ram[a - 0x80];
  // positions as the kernel starts: the positioning routine's results ($F003 at $F57F)
  t.pos = [HPOS.player[0x38], HPOS.player[0x40], HPOS.missile[R(0x88)], HPOS.missile[R(0x89)], HPOS.missile[R(0x8A)]];
  t.r[0x01] = 0;                         // VBLANK off from line 41
  for (let line = 41; line <= LAST; line++) {
    t.line = line;
    const ev = (sch.lines[line] || []).slice().sort((a, b) => a[0] - b[0]);
    let k = 0;
    const apply = (e) => {
      const [cyc, reg, v] = e;
      t.clock = 3 * cyc;
      if (reg === 'HMOVE') { t.r[0x20 + 2] = v; t.tiaWrite(0x2A, 0); }
      else if (reg === 'RESP0') t.tiaWrite(0x10, 0);
      else if (reg === 'RESP1') { if (line === 51) t.pos[1] = v; else t.tiaWrite(0x11, 0); }
      else t.tiaWrite(reg, v);
    };
    while (k < ev.length && 3 * ev[k][0] - 68 <= 0) apply(ev[k++]);
    for (let x = 0; x < 160; x++) {
      while (k < ev.length && 3 * ev[k][0] - 68 <= x) apply(ev[k++]);
      t.clock = x + 68;
      t.pixel(x);
    }
    while (k < ev.length) apply(ev[k++]);
  }
  return { fb: t.fb, ob: t.ob, sch };
}

// What a frame exercised (for the checks' coverage report)
function coverage(s, m) {
  const R = a => s.ram[a - 0x80], ob = m.ob;
  const any = (y0, y1, bit, x0 = 0, x1 = 159) => { for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) if (ob[y * 160 + x] & bit) return true; return false; };
  if (R(0xDB) & 0x80) { count('attract'); return; }
  count('game wave ' + Math.min(R(0xE7) >> 1, 9));
  if (any(57, 222, 2)) count(R(0xA2) & 0x80 ? 'explosion big' : 'explosion small');
  if (any(57, 222, 2, 40, 80)) count('explosion at the GRP1 write');
  if (any(57, 222, 8)) count('ABM');
  if (any(223, 223, 8)) count('ABM on line 223');
  if (any(57, 222, 4)) { count('trail copies ' + (R(0x91) & 7) + ' width ' + (1 << ((R(0x91) >> 4) & 3))); }
  if (any(57, 222, 4, 0, 12)) count('trail at the left edge');
  if (R(0x97) & 2) count('cruise missile');
  if (m.sch.warheadRow >= 0 && !m.sch.wh) count('black warhead');
  if (R(0xE4)) count('coloured sky');
  if ((R(0xDB) & 3) === 2) count('two players');
  if (!(R(0x86) & 0xF0)) count('B&W');
}

module.exports = { snap, coverage, schedule, render, KERNEL, FIRST, LAST, rom, ROMMD5 };
if (require.main !== module) return;

// ---- check against tools/vcs.js over random play
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? +a.split('=')[1] : d; };
const frames = +(process.argv[2] || 3000);
const verbose = process.argv.includes('--verbose');
const showFrame = arg('show', -1);
const play = require('./play')(arg('seed', 1), { diff: process.argv.includes('--diff=A') ? 0xC0 : 0, game: arg('game', 0) });
const cov = {};
const count = k => { cov[k] = (cov[k] || 0) + 1; };
const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
let state = null, stFrame = -1;
const origStep = vcs.step.bind(vcs);
vcs.step = function () { if (this.pc === KERNEL && this.frames !== stFrame) { state = snap(this); stFrame = this.frames; } return origStep(); };
let bad = 0, checked = 0;
const NAMES = ['P0', 'P1', 'M0', 'M1', 'BL', 'PF'];
const objs = o => NAMES.filter((n, i) => o & (1 << i)).join('+') || '-';
for (let f = 0; f < frames; f++) {
  const p = play(f, vcs.ram, vcs);
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  state = null;
  vcs.runFrames(1);
  if (!state) continue;
  const m = render(state);
  checked++;
  coverage(state, m);
  const diffs = [];
  for (let y = 41; y <= LAST; y++) for (let x = 0; x < 160; x++) {
    const i = y * 160 + x;
    if (m.fb[i] !== vcs.fb[i] || m.ob[i] !== vcs.ob[i]) diffs.push(`line ${y} px ${x}: 2600 ${objs(vcs.ob[i])} col ${(vcs.fb[i] * 2).toString(16)}, model ${objs(m.ob[i])} col ${(m.fb[i] * 2).toString(16)}`);
  }
  if (diffs.length) {
    bad++;
    if (bad <= 5 || verbose) console.log(`frame ${f}: ${diffs.length} pixels differ:\n  ` + diffs.slice(0, 12).join('\n  '));
  }
  if (f === showFrame) { vcs.cropTop = 20; vcs.cropHeight = 230; vcs.savePNG('show-2600.png'); const v2 = new VCS(rom); v2.fb = m.fb; v2.cropTop = 20; v2.cropHeight = 230; v2.savePNG('show-model.png'); }
}
console.log('coverage (frames):', Object.entries(cov).sort().map(([k, n]) => `${k} ${n}`).join(', '));
console.log(`${checked} frames checked, ${bad} with differences`);
