// A player for the checks (model.js, lockstep.js, screencheck.js): the same inputs from the
// same seed. Part of the time it aims: it steers the cursor (the ball in the last picture)
// towards the lowest warhead it can see (missile 0's lowest pixel) and fires when close,
// so games last into the later waves; the rest of the time it moves and fires at random.
// Between games it presses Game Select a few times (another of the 34 games), then Game
// Reset. Pass the emulator to let it aim (without one it only plays at random).
// opts.game: the game to select before each start (1-34; else a few random Selects).
//   const play = require('./play')(seed, { diff, game });  play(frame, ram, vcs) -> { swcha, swchb, fire }
module.exports = function (seed, opts = {}) {
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const diff = opts.diff || 0;
  let swcha = 0xFF, fire = false, between = 0, selects = 0, aiming = true;
  let target = null;
  return function (f, ram, v) {
    const R = a => ram[a - 0x80];
    let swchb = 0x0B | diff;
    if (f < 120) return { swcha: 0xFF, swchb, fire: false };
    const noGame = R(0xDB) & 0x80;
    if (noGame) {
      if (between === 0 && opts.game) {    // Select steps the game number: until it's the one wanted
        const bcd = R(0xE9), cur = (bcd >> 4) * 10 + (bcd & 15);
        if (cur !== opts.game) return { swcha: 0xFF, swchb: f % 8 < 4 ? swchb & ~2 : swchb, fire: false };
      }
      if (between === 0) { between = 30 + Math.floor(rnd() * 60); selects = opts.game ? 0 : Math.floor(rnd() * 4); }
      between--;
      if (between > 10 && selects && between % 8 < 4) swchb &= ~2;
      if (between > 10 && selects && between % 8 === 4) selects--;
      if (between <= 4) swchb &= ~1;
      return { swcha: 0xFF, swchb, fire: false };
    }
    between = 0;
    if (f % 300 === 0) aiming = rnd() < 0.75;
    if (aiming && v) {
      // lowest M0 pixel (the warhead) and the ball, in the last picture
      let wy = -1, wx = 0, by = -1, bx = 0;
      for (let y = 57; y <= 222; y++) for (let x = 0; x < 160; x++) {
        const o = v.ob[y * 160 + x];
        if (o & 4) { wy = y; wx = x; }
        if ((o & 16) && by < 0) { by = y; bx = x + 2; }
      }
      if (wy >= 0) target = { x: wx, y: Math.min(222, wy + 10), t: f };
      if (target && f - target.t > 20) target = null;
      let s = 0xFF, fire2 = false;
      if (target && by >= 0) {
        if (bx < target.x - 1) s &= 0x7F; else if (bx > target.x + 1) s &= 0xBF;
        if (by < target.y - 2) s &= 0xDF; else if (by > target.y + 2) s &= 0xEF;
        fire2 = Math.abs(bx - target.x) < 5 && Math.abs(by - target.y) < 8 && f % 6 < 3;
      }
      if (rnd() < 0.1) s = [0xFF, 0xEF, 0xDF, 0xBF, 0x7F][Math.floor(rnd() * 5)];
      return { swcha: (s & 0xF0) | (s >> 4), swchb, fire: fire2 };
    }
    if (f % 10 === 0) {
      const dirs = [0xFF, 0xEF, 0xDF, 0xBF, 0x7F, 0xAF, 0x6F, 0x9F, 0x5F];
      swcha = dirs[Math.floor(rnd() * dirs.length)];
      fire = rnd() < 0.5;
    }
    return { swcha: (swcha & 0xF0) | (swcha >> 4), swchb, fire: fire && f % 6 < 3 };
  };
};
