// Where the game's positioning routine ($F003 / $F005) puts each object for every X value,
// measured in tools/vcs.js: players (small explosions), player 1 when $A1 = $F0 (the big,
// double-width explosions: 5 pixels further left) and missiles / ball. Writes tools/hpos.json.
//   node games/missile-command/tools/mkhpos.js
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load(require('../2600/symbols.js').game.md5);
function run(entry, x, ram) {
  const v = new VCS(rom);
  for (const [a, val] of Object.entries(ram)) v.ram[a - 0x80] = val;
  v.x = x; v.s = 0xFD; v.ram[0x7F] = 0xF0; v.ram[0x7E] = 0xFF;   // return address $F0FF (pulled from $FE/$FF)
  v.pc = entry;
  for (let i = 0; v.pc !== 0xF100; i++) { v.step(); if (i > 5000) throw new Error('runaway'); }
  return v.pos;
}
const out = { player: [], big: [], missile: [] };
for (let x = 0; x < 256; x++) {
  const all = run(0xF003, 4, { 0x86: x, 0x87: x, 0x88: x, 0x89: x, 0x8A: x, 0xA1: 0 });
  out.player.push(all[0]);
  if (all[1] !== all[0]) throw new Error('P0/P1 differ at ' + x);
  out.missile.push(all[2]);
  if (all[3] !== all[2] || all[4] !== all[2]) throw new Error('missiles/ball differ at ' + x);
  out.big.push(run(0xF005, 1, { 0x87: x, 0xA1: 0xF0 })[1]);
}
fs.writeFileSync(path.join(__dirname, 'hpos.json'), JSON.stringify(out));
console.log('player', out.player.slice(0, 170).join(' '));
console.log('big', out.big.slice(0, 170).join(' '));
console.log('missile', out.missile.slice(0, 170).join(' '));
