// How the C64 version keeps up in VICE: main-loop passes, passes that found more than one
// frame gone by (late), the most cycles a pass spent drawing / running the game / in all
// (debug counters DbgLoops .. DbgPMax), and frames shown of each kind (DbgShown: by the parity
// of the tick they came from; with flicker on the two attacking missiles take turns, so both
// kinds must keep being shown). Over some attract mode, then a game played moving the cursor
// and firing, with flicker on and then off; --wave=N starts game N (34 games: 1, 7, 11 and 15
// start at later waves, see the manual) to get to the later waves sooner. Screenshots of each
// phase with --png=dir.
// --auto: the C64 plays by itself (DbgAuto, see AutoInput in c64/main.asm): from F2, game N
// (default 13) selected and played with the same inputs at the same ticks whatever the timing,
// counted over the same 7200 ticks, so builds can be compared (a run with VICE's monitor
// poking the inputs plays a different game each time).
//   node games/missile-command/tools/c64late.js [seconds] [--ntsc] [--png=dir] [--game=N] [--auto]
const net = require('net');
const fs = require('fs');
const path = require('path');
const ntsc = process.argv.includes('--ntsc');
const seconds = +(process.argv.find(a => /^\d+$/.test(a)) || 20);
const pngArg = process.argv.find(a => a.startsWith('--png='));
const gameArg = process.argv.find(a => a.startsWith('--game='));
const root = path.join(__dirname, '..');
const build = process.env.MC_BUILD || path.join(root, 'build');   // (MC_BUILD: another build's folder)
const { prg: prgFile, lst: lstFile } = require('./buildfiles').files(build);
const lst = fs.readFileSync(lstFile, 'latin1');
const addr = n => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${n}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + n);
  return parseInt(m[1], 16);
};
const hex = v => v.toString(16);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
let vice = null;              // the VICE this run started (only that one is closed)
let PORT = 0;                 // our own monitor port (another session's VICE may have 6510)
const mon = cmds => new Promise((resolve, reject) => {
  const s = net.connect(PORT, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d; }); s.on('error', reject);
  s.on('connect', async () => {
    await sleep(150);
    for (const c of cmds) {                     // (time for each answer before the next command)
      s.write(c + '\n');
      await sleep(c.startsWith('screenshot') ? 1200 : 400);
    }
    s.write('x\n'); await sleep(100); s.end(); resolve(b);
  });
});
// all the counters in one monitor session (VICE stops answering if it is asked too often)
const VARS = [['passes', 'DbgLoops', 2], ['late', 'DbgLate', 2], ['draw', 'DbgRMax', 2], ['ticks', 'DbgTMax', 2], ['pass', 'DbgPMax', 2],
  ['shown', 'DbgShown', 4], ['same', 'DbgSame', 2]];
const read = async () => {               // (one memory dump covering them all, plus the wave)
  const lo = Math.min(...VARS.map(([, n]) => addr(n))), hi = Math.max(...VARS.map(([, n, len]) => addr(n) + len - 1));
  const o = await mon([`m ${hex(lo)} ${hex(hi)}`, 'm e7 e7']);
  const mem = {};
  for (const m of o.matchAll(/>C:([0-9a-f]{4})((?:\s+[0-9a-f]{2}\b)+)/gi))
    m[2].trim().split(/\s+/).forEach((x, k) => { mem[parseInt(m[1], 16) + k] = parseInt(x, 16); });
  const r = {};
  for (const [k, n, len] of VARS) {
    const v = [...Array(len)].map((_, i) => mem[addr(n) + i]);
    if (v.some(x => x === undefined)) throw new Error('unexpected monitor reply: ' + JSON.stringify(o.slice(0, 300)));
    r[k] = k === 'shown' ? [v[0] + 256 * v[1], v[2] + 256 * v[3]] : len === 2 ? v[0] + 256 * v[1] : v[0];
  }
  r.wave = mem[0xE7];
  return r;
};
const reset = () => mon([`> ${hex(addr('DbgRMax'))} 0 0 0 0 0 0`]);
const report = (name, a, b) => console.log(`${ntsc ? 'NTSC' : 'PAL'} ${name}: ${b.passes - a.passes} passes, ${b.late - a.late} late; ` +
  `most cycles: drawing ${b.draw}, ticks ${b.ticks}, whole pass ${b.pass} (a frame has ${ntsc ? '17095' : '19656'}); ` +
  `frames shown: even ${(b.shown[0] - a.shown[0]) & 65535}, odd ${(b.shown[1] - a.shown[1]) & 65535}, ` +
  `${(b.same - a.same) & 65535} of the same kind as the one before; wave byte ${b.wave}`);
const shot = async name => { if (pngArg) await mon([`screenshot "${path.join(pngArg.slice(6), name).split(path.sep).join('/')}" 2`]); };
const press = async (a, v, ms) => { await mon([`> ${hex(addr(a))} ${v}`]); await sleep(ms); await mon([`> ${hex(addr(a))} ff`]); };

// --auto: F2 with DbgAuto set, flicker on and then off; the counters come from DbgAutoRes
const auto = async () => {
  const game = gameArg ? +gameArg.slice(7) : 13;
  for (const flicker of [1, 0]) {
    await mon([`> ${hex(addr('Flicker'))} ${flicker}`, `> ${hex(addr('DbgAuto'))} ${hex(game)}`, `> ${hex(addr('PowerReq'))} 1`]);
    const t0 = Date.now();
    for (;;) {
      await sleep(3000);
      const o = await mon([`m ${hex(addr('DbgAuto'))} ${hex(addr('DbgAuto'))}`]);
      const m = o.match(new RegExp(`>C:${hex(addr('DbgAuto'))}\\s+([0-9a-f]{2})`, 'i'));
      if (m && parseInt(m[1], 16) === 0) break;
      if (Date.now() - t0 > 600000) throw new Error('DbgAuto never finished');
    }
    const lo = addr('DbgAutoRes'), base = addr('DbgLoops');
    const o = await mon([`m ${hex(lo)} ${hex(lo + addr('DbgSame') + 1 - base)}`, 'm e7 e9']);
    const mem = {};
    for (const m of o.matchAll(/>C:([0-9a-f]{4})((?:\s+[0-9a-f]{2}\b)+)/gi))
      m[2].trim().split(/\s+/).forEach((x, k) => { mem[parseInt(m[1], 16) + k] = parseInt(x, 16); });
    const w = n => mem[lo + addr(n) - base] + 256 * mem[lo + addr(n) - base + 1];
    const sh = addr('DbgShown') - base;
    console.log(`${ntsc ? 'NTSC' : 'PAL'} auto, game ${game}, flicker ${flicker ? 'on' : 'off'}: ${w('DbgLoops')} passes, ${w('DbgLate')} late; ` +
      `most cycles: drawing ${w('DbgRMax')}, ticks ${w('DbgTMax')}, whole pass ${w('DbgPMax')}; ` +
      `frames shown: even ${mem[lo + sh] + 256 * mem[lo + sh + 1]}, odd ${mem[lo + sh + 2] + 256 * mem[lo + sh + 3]}, ${w('DbgSame')} of the same kind as the one before; ` +
      `wave byte ${mem[0xe7]}, game ${mem[0xe9].toString(16)}`);
    await shot(`auto-flicker-${flicker ? 'on' : 'off'}.png`);
  }
};

(async () => {
  if (pngArg) fs.mkdirSync(pngArg.slice(6), { recursive: true });
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prgFile]);
  // wait until the program runs (its main loop counting passes; VICE's autostart takes a varying time)
  const loops = async () => { try { const r = await read(); return r.passes; } catch { return -1; } };
  for (let t = 0, last = -1; t < 40; t++) {
    await sleep(1000);
    const n = await loops();
    if (last > 0 && n > last) break;
    last = n;
  }
  if (!await runsOurs(mon, prgFile)) throw new Error(`the VICE on port ${PORT} isn't running our build: stopping`);
  if (process.argv.includes('--auto')) return auto();
  await reset();
  const a = await read();
  await sleep(4000);
  const b = await read();
  report('attract', a, b);
  await shot('attract.png');
  if (gameArg) for (let k = 1; k < +gameArg.slice(7); k++) { await press('DbgSWCHB', 'fd', 300); await sleep(300); }   // Game Select
  await press('DbgINPT4', '7f', 500);
  await sleep(2000);
  for (const flicker of [1, 0]) {
    await mon([`> ${hex(addr('Flicker'))} ${flicker}`]);
    await reset();
    const c = await read();
    const t0 = Date.now();
    let seed = 1; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    const DIRS = ['7f', 'bf', 'ef', 'df', 'ff', '6f', 'af'];
    while (Date.now() - t0 < seconds * 500) {
      await mon([`> ${hex(addr('DbgSWCHA'))} ${DIRS[Math.floor(rnd() * DIRS.length)]}`, `> ${hex(addr('DbgINPT4'))} ${rnd() < .5 ? '7f' : 'ff'}`]);
      await sleep(300);
    }
    const d = await read();
    report(`play, flicker ${flicker ? 'on' : 'off'}`, c, d);
    await shot(`play-flicker-${flicker ? 'on' : 'off'}.png`);
  }
})().catch(e => console.log(e.message)).finally(() => {   // close the VICE started here, whatever happened
  stopVice(vice);
});
