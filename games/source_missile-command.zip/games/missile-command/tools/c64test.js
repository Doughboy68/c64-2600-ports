// Scripted play test of the C64 build in VICE (through the remote monitor, on a port of its
// own; only the VICE started here is closed): start it, screenshot the attract mode, press
// fire to start a game, move the cursor about firing, and save screenshots.
//   node games/missile-command/tools/c64test.js <outdir> [seconds-of-play] [--ntsc] [--noflicker] [--diffA] [--keep]
// --keep leaves the VICE running afterwards (to look at it).
const fs = require('fs');
const net = require('net');
const path = require('path');

const out = path.resolve(process.argv[2] || '.');
const playSeconds = +(process.argv[3] || 20);
const ntsc = process.argv.includes('--ntsc');
const root = path.join(__dirname, '..');
const build = process.env.MC_BUILD || path.join(root, 'build');   // (MC_BUILD: another build's folder)
const { prg: prgFile, lst: lstFile } = require('./buildfiles').files(build);
const lst = fs.readFileSync(lstFile, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return m[1];
};
const A = { swcha: addr('DbgSWCHA'), inpt4: addr('DbgINPT4'), flicker: addr('Flicker'), switches: addr('switches') };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
let vice = null;              // the VICE this run started (only that one is closed)
let PORT = 0;                 // our own monitor port (another session's VICE may have 6510)

function mon(cmds) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(PORT, '127.0.0.1');
    let buf = '';
    sock.on('data', d => { buf += d.toString('latin1'); });
    sock.on('error', reject);
    sock.on('connect', async () => {
      await sleep(150);
      for (const c of cmds) { sock.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 150); }
      sock.write('x\n');
      await sleep(100);
      sock.end();
      resolve(buf.replace(/\(C:\$[0-9a-f]{4}\) /g, ''));
    });
  });
}
const poke = (a, v) => mon([`> ${a} ${v}`]);
const shot = name => mon([`screenshot "${path.join(out, name).replace(/\\/g, '/')}" 2`]);

(async () => {
  fs.mkdirSync(out, { recursive: true });
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prgFile]);
  await sleep(7000);
  if (!await runsOurs(mon, prgFile)) throw new Error(`the VICE on port ${PORT} isn't running our build: stopping`);
  await shot('t0-attract.png');
  if (process.argv.includes('--noflicker')) await poke(A.flicker, '0');
  if (process.argv.includes('--diffA')) await poke(A.switches, 'cb');      // both difficulties A
  await poke(A.inpt4, '7f'); await sleep(600); await poke(A.inpt4, 'ff');   // fire: start a game
  await sleep(2500);
  await shot('t1-start.png');
  let seed = 1;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const t0 = Date.now();
  let n = 0;
  const DIRS = ['7f', 'bf', 'ef', 'df', 'ff', '6f', 'af'];
  while (Date.now() - t0 < playSeconds * 1000) {
    await poke(A.swcha, DIRS[Math.floor(rnd() * DIRS.length)]);
    await sleep(400);
    if (rnd() < 0.5) { await poke(A.inpt4, '7f'); await sleep(150); await poke(A.inpt4, 'ff'); }
    if (++n % 6 === 0) await shot(`t2-play${String(n / 6).padStart(2, '0')}.png`);
  }
  await poke(A.swcha, 'ff');
  await shot('t3-end.png');
  await sleep(500);
  if (!process.argv.includes('--keep')) stopVice(vice);
})().catch(e => { console.log(e.message); stopVice(vice); });
