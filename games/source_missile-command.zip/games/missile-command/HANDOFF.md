# Missile Command: handoff (2026-10-03)

State: version 1.0, **published** on the web builder (2026-10-04). Next version 1.1.
Read README.md (top level), this game's README.md and the memory note `missile-command-port`.

## Done

* Disassembly (`2600/`), RAM/routine names, `tools/model.js` (exact against `tools/vcs.js` with
  `hmoveBlank`, `wideDelay`, `respDelay`), C64 port (`c64/`), lockstep / screencheck / inputtest /
  c64test / c64late, and `tools/stellacheck.js` (same inputs in vcs.js and Stella's debugger,
  pictures compared; Stella's joystick values are 0 = pressed; swchb needs `$` hex).
* From the user's comparison with Stella / a video: no bar under the base (mid-line RESP1 draws
  no main copy: new opt-in `respDelay` in the shared `tools/vcs.js`), ABM pile and big explosions
  a pixel right (`wideDelay`), the ground continues into the bottom border (rasters 245-272, NTSC
  to 9; grey-dot-free timing, checked in VICE screenshots).
* **PAL, flicker on, "frames of each kind unbalanced" (even 2, odd 201): not a bug.** DbgShown
  was 8 bits and wrapped (2 was 258). Now 16 bits, plus DbgSame (frames of the same kind as the
  one before). PAL flicker on: 231 / 230 frames shown, 2 repeats (c64late 40 --game=13); in the
  `--auto` game below the build from before the border change and the new one repeat as often
  (about 7% on PAL: frames where both captures hold the same trail, so nothing else could be shown).
* **NTSC, flicker off, late frames up after the border change: the interrupts' waits, now
  trimmed.** Measured with `c64late.js --auto` (the C64 plays game 13 by itself from F2, the
  same inputs at the same ticks in every build; counted over 7200 ticks). Late frames, flicker off:

  | Build | NTSC | PAL |
  |---|---|---|
  | before the border change (6a361cc) | 863 | 378 |
  | border change (36c37a9) | 1016 | |
  | now | 847 | 369 |

  Flicker on: 12-17 late on NTSC, 5-8 on PAL in every build. (The `--auto` game fires at
  random a lot: much heavier than the monitor-driven play; that one gives 5-6 PAL / 13-29 NTSC
  late in 20 s now, varying a lot from run to run, the build before the border change 16 NTSC.)
  What changed: the frame-end interrupt comes at raster 245 and writes the ground's colour first
  (cycles 33-36: no wait); NTSC's frame top comes at raster 7 instead of 4 (it waited ~6 lines
  for raster 9); the black writes' 58-cycle delays do the interrupt's own fixed-time work (PAL:
  IBlack sets up the frame top; NTSC: bank, ground, sprite switches); $01 isn't saved any more
  (always $35); the sprite registers are copied unrolled. Write cycles checked in VICE with
  `tools/c64irq.js` (PAL black at 273:2-6, NTSC at 10:0-1, as HBlank had them: 1-7; the ground
  at 245:29-37, inside the display window); bottom border one colour
  on every row in 12 VICE screenshots (PAL and NTSC). `.cerror` checks keep the timed tables and
  delay loops from crossing pages.
* All checks passed on the last build: screencheck 0 differences (incl. --game=13, PAL and NTSC),
  lockstep 0, inputtest.

## Open

1. A pixel now and then still differs from Stella (exact timing of mid-line writes: the ABM's
   pixel on line 222, a cursor pixel): see `tools/stellacheck.js --verbose`. Minor.
2. Flicker off, render speed (2026-10-04): late frames in the `--auto` game, flicker off, now
   NTSC 254 / PAL 101 (were 847 / 369). Done, each checked identical with `tools/rendercheck.js`
   against the build before: a warhead row that becomes trail is set to "10" in place (no erase,
   no repair of the other trail; the other's warhead drawn again if it was on that row); the
   usual explosion layout built by a fast loop; PlotRow's copies by offsets from SetRec, the
   warhead's colour cells worked out once a row, no second RowPos for the warhead row; cruise
   missiles' 2-pixel warheads by Plot2 instead of pixel by pixel. ReadInput and AutoInput now
   sit past the 2600 image in bank 1's free RAM ($4600-$5FFF; InitVideo clears only what the
   VIC shows). Left: a dead trail (missile hits the ground) is erased whole in each buffer,
   10-14K cycles (pixel by pixel when the other trail may share bytes: rows below the other's
   warhead could just be zeroed); explosions reused still ~490 cycles; ABMs ~450 each.
   The user found it plays fine (flicker on and off) and asked for no more tweaking. Found but
   not done: the worst spikes (30-43K) are a trail losing one of its copies (an ABM gets part of
   a split missile: NUSIZ/X0 change, so the record doesn't match: erased whole and redrawn
   whole; erasing just the lost copy would do). Zeroing a dead trail's rows below the other
   trail gained almost nothing (when both die they reach as far down).
3. Published as 1.0 (2026-10-04): build.cmd now writes its profile to `site/games/` too; between
   releases restore `site/` after building (`git checkout -- site`): other sessions publish too.

## How to check (after any render change)

    node games/missile-command/tools/screencheck.js 4000 --seed=1
    node games/missile-command/tools/screencheck.js 4000 --game=13 --seed=21 [--ntsc]  (later waves!)
    node games/missile-command/tools/lockstep.js 4000 --seed=6 --power=2000 --pal
    node games/missile-command/tools/inputtest.js
    node games/missile-command/tools/c64late.js 40 --game=13 [--ntsc]
    node games/missile-command/tools/c64late.js --auto [--ntsc]   (to compare timing between builds)
    node games/missile-command/tools/c64irq.js [--ntsc]           (after interrupt changes)
    node games/missile-command/tools/rendercheck.js <old build dir> 4000 [--flicker] [--pal]   (speed changes)
    node games/missile-command/tools/stellacheck.js 1200   (Stella at C:\Program Files\Stella)

Develop with a scratch build (`MC_BUILD=<dir>` makes the checks use it, c64late and c64test
too) so background runs aren't disturbed. Commit only `games/missile-command` (and shared tools
when changed, saying so).
