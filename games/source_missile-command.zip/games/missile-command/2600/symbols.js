// Names for Missile Command's RAM and routines, worked out by reading the code and
// watching RAM in tools/vcs.js (games/missile-command/tools/model.js). Used by tools/disasm.js
// to label the source and to write RAM-MAP.md. "?" marks something not yet confirmed.
//
// Conventions found in the code:
//   - Y coordinates are kernel rows: the play area is 83 rows of 2 lines, counted $53 at the
//     top down to 1 at the bottom (the kernel's row counter).
//   - Two attacking missiles (ICBMs) are kept in pairs of bytes, "this frame's" and "the
//     other's"; the pairs are swapped every frame, so each is drawn on alternate frames.
//   - Three ABM slots (the player's missiles: flying, then exploding); one is drawn per
//     frame ($CA counts 2, 1, 0).
//   - The stack is at the top of page zero ($FC-$FF) as on any 2600.

const game = { title: 'Missile Command', from: 'Atari 2600, 1981', md5: '3a2e2d0c6892aa14544083dfb7762782', asm: 'missile-command.asm' };

const ram = [
  [0x80, 'FrameCount', 1, 'Frame counter'],
  [0x81, 'TrailAcc', 1, 'Kernel: the trail\'s slope accumulator (adds TrailSlope each row; a carry moves it a pixel). Also a temp'],
  [0x82, 'Temp', 1, 'Scratch'],
  [0x83, 'ExplRow', 1, 'Kernel: the explosion\'s bottom row (explosion slot\'s Y - 4; 4 more for a big one). Also a temp'],
  [0x84, 'AbmRow', 1, 'Kernel: the shown ABM\'s row ($54: none)'],
  [0x85, 'CursorRow', 1, 'Kernel: the cursor\'s row'],
  [0x86, 'PosX', 5, 'X of player 0, player 1, missile 0, missile 1, ball for the positioning routine. +0 later the colour mask ($FF colour, $0F B&W, bit 3 off with no game); +1 the explosion\'s X; +2 the trail\'s X at the top; +3 the ABM\'s X; +4 the cursor\'s X'],
  [0x8B, 'GfxPtr', 2, 'Kernel: the explosion\'s graphics pointer ($FF30: none); then the ABMs-left pile\'s'],
  [0x8D, 'CursorY', 2, 'Cursor Y: fraction, row'],
  [0x8F, 'CursorX', 2, 'Cursor X: fraction, pixel'],
  [0x91, 'MslNusiz', 2, 'Attacking missiles (this frame\'s, the other): NUSIZ0, copies and width ($FF: none)'],
  [0x93, 'MslRow', 2, 'Attacking missiles: the warhead\'s row ($54: none)'],
  [0x95, 'MslSlope', 2, 'Attacking missiles: added to the slope accumulator each row'],
  [0x97, 'MslDir', 2, 'Attacking missiles: HMM0 for a step ($10 left, $F0 right); bit 1: a cruise missile (no trail)'],
  [0x99, 'MslX', 2, 'Attacking missiles: X at the top of the screen (this frame\'s is copied to PosX+2)'],
  [0x9B, 'MslSpeed', 1, 'Attacking missiles\' speed (added to MslStep each frame)'],
  [0x9C, 'MslStep', 2, 'Attacking missiles\' speed accumulators, by frame parity'],
  [0x9E, 'ExplPhase', 3, 'ABM slots: explosion phase 0-15 (steps every 8 frames)'],
  [0xA1, 'ExplMask', 1, 'Kernel: explosion rows mask ($F8 small: 8 rows, $F0 big: 16); 0 while positioning all objects'],
  [0xA2, 'Flags', 1, 'Bit 7: the explosion is big (double width, rows doubled); bit 3: fire held (one ABM per press)'],
  [0xA3, 'ExplY', 3, 'ABM slots: explosion Y (row of its centre)'],
  [0xA6, 'ExplX', 3, 'ABM slots: explosion X'],
  [0xA9, 'CityPtr', 12, 'Six graphics pointers, the cities left to right (low $38: standing, +9 each step of its destruction, $70: rubble, $B1: ?)'],
  [0xB5, 'AbmState', 3, 'ABM slots: bit 7 in use, bit 6 steep (Y the major axis), bit 5 exploding'],
  [0xB8, 'AbmSteps', 3, 'ABM slots: steps left to the target'],
  [0xBB, 'AbmMajor', 3, 'ABM slots: distance along the major axis'],
  [0xBE, 'AbmMinor', 3, 'ABM slots: distance along the minor axis'],
  [0xC1, 'AbmAcc', 3, 'ABM slots: line accumulator'],
  [0xC4, 'AbmX', 3, 'ABM slots: X'],
  [0xC7, 'AbmY', 3, 'ABM slots: Y (row; 1 at the base)'],
  [0xCA, 'Slot', 1, 'The ABM slot drawn this frame (2, 1, 0 in turn)'],
  [0xCB, 'DigitPtr', 12, 'Six pointers to the score digits\' graphics (page $FF; $FF30 blank)'],
  [0xD7, 'KColour', 1, 'Kernel: the explosion\'s colour (changes every frame); during the kernel the warhead\'s'],
  [0xD8, 'Random', 2, 'Random number generator'],
  [0xDA, 'Temp2', 1, 'Scratch; the score loop\'s row counter; the attract mode colour EOR'],
  [0xDB, 'GameState', 1, 'Bit 7: no game (attract); bit 6: game set up; bits 0-1: player turns; bit 2: showing the game number?'],
  [0xDC, 'Timer', 1, '?'],
  [0xDD, 'AbmsLeft', 1, 'ABMs in the base (10 per load)'],
  [0xDE, 'WavePhase', 1, 'Wave sequencer ($E8/$E0 counting bonuses, $A0-$B0 wave start, ...)?'],
  [0xDF, 'Sound', 1, 'Sound effects: low nibble channel 0, high nibble channel 1'],
  [0xE0, 'SoundTimer', 2, 'Sound effect timers'],
  [0xE2, 'Colours', 5, 'Colours of the wave: cities, trails, sky, ground, score and cruise missiles'],
  [0xE7, 'Wave', 1, 'Wave number ($FF: before the first)?'],
  [0xE8, 'AttractTimer', 1, 'Counts every 256 frames: the attract mode colours'],
  [0xE9, 'GameNumber', 1, 'Selected game, BCD 1-34'],
  [0xEA, 'SelectTimer', 1, 'Game Select repeat timer'],
  [0xEB, 'CruiseLeft', 1, 'Cruise missiles left in the wave?'],
  [0xEC, 'Cities', 2, 'Per player: cities standing (bits)'],
  [0xEE, 'P1Nusiz', 1, 'Kernel: NUSIZ1 ($10, $15 for a big explosion)'],
  [0xEF, 'Score', 6, 'Scores, BCD: low byte per player ($EF, $F0), middle ($F1, $F2), high ($F3, $F4)'],
  [0xF5, 'Player', 1, 'Whose turn (0, 1)'],
  [0xF6, 'BonusCount', 2, 'Per player: bonus cities given (one per 10,000 points)'],
  [0xF8, 'GameFlags', 1, 'Features of the selected game (table at $FE94): bit 0 slow cursor?, bit 6 smart cruise missiles, bit 7 two players?'],
  [0xF9, 'Dodge', 2, 'Smart cruise missiles: dodges left, by frame parity?'],
  [0xFB, 'Special', 1, 'Bit 7: end of game sequence?; bit 6: children\'s game'],
  [0xFC, 'Stack', 4, 'The stack (return addresses)'],
];

const labels = {
  0xF000: ['Reset', 'Power on: jump to the start-up code'],
  0xF003: ['PosAll', 'Position all five objects (ball, missiles, players) from PosX, then HMOVE'],
  0xF005: ['PosObjects', 'Position objects X down to 0 (only the first unless ExplMask is 0)'],
  0xF03F: ['PowerOn', 'Start-up: clear the RAM and the TIA'],
  0xF056: ['Frame', 'Frame start: VSYNC, then the game logic for the frame'],
  0xF58E: ['SoundJump', 'Jump to the sound effect routine for channel 0 (table below)'],
  0xF7D1: ['Kernel', 'The picture: wait for the timer, then score, play area, cities, ground'],
  0xF7E6: ['ScoreLoop', 'Kernel: six score digits, 7 lines'],
  0xF86B: ['PlayRow', 'Kernel: one row (2 lines) of the play area: trail, explosion, ABM, cursor'],
  0xF8FF: ['CityLoop', 'Kernel: the cities and hills, 9 lines'],
  0xF955: ['GroundLoop', 'Kernel: the ground, ABMs left and the players\' markers, 4 lines'],
  0xF96E: ['Overscan', 'After the picture: hits, cities, the attacking missiles'],
  0xFC92: ['NextRandom', 'Step the random number generator'],
  0xFCCB: ['AddScore', 'Add A (low) and Y (middle) to the current player\'s score, times the wave\'s multiplier'],
  0xFD8F: ['HighNibble', 'A = A >> 4'],
};

module.exports = { game, ram, labels, code: [0xF655, 0xF63F, 0xF5F8, 0xF5E0, 0xF5C7, 0xF5CE, 0xF5A7, 0xF617], always: [0xF688] };
