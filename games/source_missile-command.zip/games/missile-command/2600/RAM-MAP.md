# Missile Command (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80` | FrameCount | 1 | Frame counter |
| `$81` | TrailAcc | 1 | Kernel: the trail's slope accumulator (adds TrailSlope each row; a carry moves it a pixel). Also a temp |
| `$82` | Temp | 1 | Scratch |
| `$83` | ExplRow | 1 | Kernel: the explosion's bottom row (explosion slot's Y - 4; 4 more for a big one). Also a temp |
| `$84` | AbmRow | 1 | Kernel: the shown ABM's row ($54: none) |
| `$85` | CursorRow | 1 | Kernel: the cursor's row |
| `$86-$8A` | PosX | 5 | X of player 0, player 1, missile 0, missile 1, ball for the positioning routine. +0 later the colour mask ($FF colour, $0F B&W, bit 3 off with no game); +1 the explosion's X; +2 the trail's X at the top; +3 the ABM's X; +4 the cursor's X |
| `$8B-$8C` | GfxPtr | 2 | Kernel: the explosion's graphics pointer ($FF30: none); then the ABMs-left pile's |
| `$8D-$8E` | CursorY | 2 | Cursor Y: fraction, row |
| `$8F-$90` | CursorX | 2 | Cursor X: fraction, pixel |
| `$91-$92` | MslNusiz | 2 | Attacking missiles (this frame's, the other): NUSIZ0, copies and width ($FF: none) |
| `$93-$94` | MslRow | 2 | Attacking missiles: the warhead's row ($54: none) |
| `$95-$96` | MslSlope | 2 | Attacking missiles: added to the slope accumulator each row |
| `$97-$98` | MslDir | 2 | Attacking missiles: HMM0 for a step ($10 left, $F0 right); bit 1: a cruise missile (no trail) |
| `$99-$9A` | MslX | 2 | Attacking missiles: X at the top of the screen (this frame's is copied to PosX+2) |
| `$9B` | MslSpeed | 1 | Attacking missiles' speed (added to MslStep each frame) |
| `$9C-$9D` | MslStep | 2 | Attacking missiles' speed accumulators, by frame parity |
| `$9E-$A0` | ExplPhase | 3 | ABM slots: explosion phase 0-15 (steps every 8 frames) |
| `$A1` | ExplMask | 1 | Kernel: explosion rows mask ($F8 small: 8 rows, $F0 big: 16); 0 while positioning all objects |
| `$A2` | Flags | 1 | Bit 7: the explosion is big (double width, rows doubled); bit 3: fire held (one ABM per press) |
| `$A3-$A5` | ExplY | 3 | ABM slots: explosion Y (row of its centre) |
| `$A6-$A8` | ExplX | 3 | ABM slots: explosion X |
| `$A9-$B4` | CityPtr | 12 | Six graphics pointers, the cities left to right (low $38: standing, +9 each step of its destruction, $70: rubble, $B1: ?) |
| `$B5-$B7` | AbmState | 3 | ABM slots: bit 7 in use, bit 6 steep (Y the major axis), bit 5 exploding |
| `$B8-$BA` | AbmSteps | 3 | ABM slots: steps left to the target |
| `$BB-$BD` | AbmMajor | 3 | ABM slots: distance along the major axis |
| `$BE-$C0` | AbmMinor | 3 | ABM slots: distance along the minor axis |
| `$C1-$C3` | AbmAcc | 3 | ABM slots: line accumulator |
| `$C4-$C6` | AbmX | 3 | ABM slots: X |
| `$C7-$C9` | AbmY | 3 | ABM slots: Y (row; 1 at the base) |
| `$CA` | Slot | 1 | The ABM slot drawn this frame (2, 1, 0 in turn) |
| `$CB-$D6` | DigitPtr | 12 | Six pointers to the score digits' graphics (page $FF; $FF30 blank) |
| `$D7` | KColour | 1 | Kernel: the explosion's colour (changes every frame); during the kernel the warhead's |
| `$D8-$D9` | Random | 2 | Random number generator |
| `$DA` | Temp2 | 1 | Scratch; the score loop's row counter; the attract mode colour EOR |
| `$DB` | GameState | 1 | Bit 7: no game (attract); bit 6: game set up; bits 0-1: player turns; bit 2: showing the game number? |
| `$DC` | Timer | 1 | ? |
| `$DD` | AbmsLeft | 1 | ABMs in the base (10 per load) |
| `$DE` | WavePhase | 1 | Wave sequencer ($E8/$E0 counting bonuses, $A0-$B0 wave start, ...)? |
| `$DF` | Sound | 1 | Sound effects: low nibble channel 0, high nibble channel 1 |
| `$E0-$E1` | SoundTimer | 2 | Sound effect timers |
| `$E2-$E6` | Colours | 5 | Colours of the wave: cities, trails, sky, ground, score and cruise missiles |
| `$E7` | Wave | 1 | Wave number ($FF: before the first)? |
| `$E8` | AttractTimer | 1 | Counts every 256 frames: the attract mode colours |
| `$E9` | GameNumber | 1 | Selected game, BCD 1-34 |
| `$EA` | SelectTimer | 1 | Game Select repeat timer |
| `$EB` | CruiseLeft | 1 | Cruise missiles left in the wave? |
| `$EC-$ED` | Cities | 2 | Per player: cities standing (bits) |
| `$EE` | P1Nusiz | 1 | Kernel: NUSIZ1 ($10, $15 for a big explosion) |
| `$EF-$F4` | Score | 6 | Scores, BCD: low byte per player ($EF, $F0), middle ($F1, $F2), high ($F3, $F4) |
| `$F5` | Player | 1 | Whose turn (0, 1) |
| `$F6-$F7` | BonusCount | 2 | Per player: bonus cities given (one per 10,000 points) |
| `$F8` | GameFlags | 1 | Features of the selected game (table at $FE94): bit 0 slow cursor?, bit 6 smart cruise missiles, bit 7 two players? |
| `$F9-$FA` | Dodge | 2 | Smart cruise missiles: dodges left, by frame parity? |
| `$FB` | Special | 1 | Bit 7: end of game sequence?; bit 6: children's game |
| `$FC-$FF` | Stack | 4 | The stack (return addresses) |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$F000` | Reset | Power on: jump to the start-up code |
| `$F003` | PosAll | Position all five objects (ball, missiles, players) from PosX, then HMOVE |
| `$F005` | PosObjects | Position objects X down to 0 (only the first unless ExplMask is 0) |
| `$F03F` | PowerOn | Start-up: clear the RAM and the TIA |
| `$F056` | Frame | Frame start: VSYNC, then the game logic for the frame |
| `$F58E` | SoundJump | Jump to the sound effect routine for channel 0 (table below) |
| `$F7D1` | Kernel | The picture: wait for the timer, then score, play area, cities, ground |
| `$F7E6` | ScoreLoop | Kernel: six score digits, 7 lines |
| `$F86B` | PlayRow | Kernel: one row (2 lines) of the play area: trail, explosion, ABM, cursor |
| `$F8FF` | CityLoop | Kernel: the cities and hills, 9 lines |
| `$F955` | GroundLoop | Kernel: the ground, ABMs left and the players' markers, 4 lines |
| `$F96E` | Overscan | After the picture: hits, cities, the attacking missiles |
| `$FC92` | NextRandom | Step the random number generator |
| `$FCCB` | AddScore | Add A (low) and Y (middle) to the current player's score, times the wave's multiplier |
| `$FD8F` | HighNibble | A = A >> 4 |
