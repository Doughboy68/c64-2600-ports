version 1.0 |version 1.0 |version 1.0 |version 1.0 |version 1.0 |# Atari 2600 → Commodore 64 ports

Atari 2600 cartridges ported to the C64. Each port runs the original 2600 program (almost)
unchanged on the C64's 6510; new C64 code takes over everything the 2600's hardware did:
the display, collision detection, controls and sound.

| Game | Folder | State |
|---|---|---|
| Space Invaders (Atari, 1980) | [`games/space-invaders`](games/space-invaders/README.md) | version 1.4 |
| Berzerk (Atari, 1982) | [`games/berzerk`](games/berzerk/README.md) | version 1.2 |
| Asteroids (Atari, 1981) | [`games/asteroids`](games/asteroids/README.md) | version 1.3 |
| Demon Attack (Imagic, 1982) | [`games/demon-attack`](games/demon-attack/README.md) | version 1.1 |
| Adventure (Atari, 1980) | [`games/adventure`](games/adventure/README.md) | version 1.1 |
| Missile Command (Atari, 1981) | [`games/missile-command`](games/missile-command/README.md) | version 1.0 |
| Combat (Atari, 1977), TjLaZer's port | [`games/combat`](games/combat/README.md) | version 1.3 |
| Pac-Man (Atari, 1982), Zeiche's port | [`games/pac-man`](games/pac-man/README.md) | version 1.0 |
| E.T. The Extra-Terrestrial (Atari, 1982), Zeiche's port | [`games/et`](games/et/README.md) | version 1.0 |
| Ms. Pac-Man (Atari, 1982), Zeiche's port | [`games/ms-pac-man`](games/ms-pac-man/README.md) | version 1.0 |
| Kaboom! (Activision, 1981), Zeiche's port | [`games/kaboom`](games/kaboom/README.md) | version 1.0 |
| Yars' Revenge (Atari, 1982), Zeiche's port | [`games/yars-revenge`](games/yars-revenge/README.md) | version 1.0 |

## Layout

| Path | What |
|---|---|
| `games/<game>/` | One folder per port (see below) |
| `roms_port/` | The original ROM dumps, as `.a26` or `.zip`, any file name. **Never in git.** |
| `usb/` | The released games' `.prg` and `.d64` files for the owner's own USB stick, refreshed by `publish.cmd` (`tools/usbcopy.js`). **Never in git** (original game code) |
| `tools/` | Shared tools (below) |
| `docs/NEW-PORT-PROMPT.md` | How to start a new port in a new Claude Code session (the prompt to paste) |
| `src/web/`, `site/` | The web builder (below) |

Each game folder:

| Path | What |
|---|---|
| `README.md` | Controls, how the port works, differences from the 2600 |
| `build.cmd` | Builds the game (the top-level `build.cmd` builds them all) |
| `2600/symbols.js` | Title, ROM MD5, and names and notes for the game's RAM and routines |
| `2600/<game>.asm` | The 2600 program disassembled; rebuilds the exact original ROM (generated) |
| `2600/RAM-MAP.md` | What each byte of the game's RAM means, plus its routines (generated) |
| `c64/` | The C64 port's source |
| `tools/` | Scripts for this game only (measuring, testing) |
| `build/` | The finished `.prg` and `.d64` (kept in git); everything else there is temporary. Named `<short name>-<version>` (`berzerk-1.2.prg`), at most 16 characters (a C64 file name): `tools/buildname.js` |

Shared tools:

| Tool | What |
|---|---|
| `tools/buildname.js` | A game's build file names: `<short name>-<version>` from its BASIC listing, at most 16 characters (its `build.cmd` and tools use it) |
| `tools/rom.js` | Finds a ROM in `roms_port/` by MD5 (`node tools/rom.js` lists them all) |
| `tools/disasm.js` | `node tools/disasm.js games/<game>`: regenerates the game's `.asm` and `RAM-MAP.md` from `symbols.js` (4K ROMs, or 8K F8 bank-switched ones: `game.banks` in `symbols.js` gives where each bank runs). Its core, `src/web/disasm-core.js`, also runs in the builder page |
| `tools/vcs.js` | Small scriptable 2600 emulator used to study games (4K and 8K F8 ROMs; `hmoveBlank` draws the HMOVE bars) |
| `tools/vice.js` | Drives VICE's remote monitor: `--start` launches a VICE on a monitor port of its own (other sessions may use 6510), `--stop` closes only that one |
| `tools/vicemon.js` | For the games' VICE test tools: a free monitor port, a check that VICE runs our build before anything is poked, starting / closing only our own VICE |
| `tools/mkprofile.js`, `tools/mkpage.js`, `tools/listgames.js`, `tools/mksource.js`, `tools/serve.js` | The web builder (below) |
| `tools/64tass/` | 64tass 1.60 from [sourceforge.net/projects/tass64](https://sourceforge.net/projects/tass64/) (not in git) |

Building needs Node.js, 64tass in `tools\64tass\`, and VICE's `c1541` for disk images.

## Standard controls

Every port uses the same keys, so they're easy to remember (on the 2600 these were console switches):

| Key | Does |
|---|---|
| **F1** | Start a game (Game Reset) |
| **F2** | Power off and on: everything back to the start (game 1, no score), without reloading |
| Fire (joystick, or the game's fire key) | Also starts a game when none is running |
| **F3** | Game Select |
| **F5** | Colour / black and white |
| **F7** / **F8** | Left / right difficulty |
| **F** | Flicker on / off, in games that flicker (it was **6** until October 2026) |

Joystick: port 2 for player 1, port 1 for player 2. Keyboard: player 1 W A S D + Space; in games
where two play at once (Space Invaders, Combat) player 2 also has I J K L + Return. (The keys are
mainly for trying games in an emulator; on a real C64 people use joysticks, so games where players
take turns need only the one set.) Other features never take keys from these sets.
The BASIC listing (`LIST` before `RUN`) holds the title, credits and controls.

F2 is new (October 2026): before, F1 and F2 both started a game. Every port should handle it
the same way: on F2 (F1 with either shift key, on key-down), clear the 2600's TIA and RAM and
start the game from its power-on code again, keeping the console switches as they are set
(see `PowerCycle` / `PowerKey` in either game's `c64/main.asm`).

## Versions

Versions start at 0.1 while a port is being developed locally, and at 1.0 when it is first
published on the web builder. The version is in the BASIC listing (`c64/main.asm`), from where
the site's profile takes it.

## Web builder

`site/` is the builder page published at <https://doughboy68.github.io/c64-2600-ports/>
(repository [Doughboy68/c64-2600-ports](https://github.com/Doughboy68/c64-2600-ports)). It builds the C64
versions in the browser from the user's own ROM, and holds no original game code. `site/index.html` is
one self-contained file made by `tools/mkpage.js` from `src/web/page.html` and `src/web/builder-core.js`;
it lists the games in `site/games/` (JSON profiles), and saved to disk it works standalone.
For our own games (those with a disassembly) it also offers the source: `tools/mksource.js` (run by
`publish.cmd`) packs each game's files, the shared tools and a `CLAUDE.md` into `site/games/source_<id>.zip`,
without the disassembly or anything else holding ROM bytes (it checks), and the page adds the
disassembly, made in the browser from the player's own ROM.
To add a game: describe it in `src/web/<game>.json` and run `node tools/mkprofile.js src/web/<game>.json`
(or use the page's "Make a profile" tab and put the `.json` in `site/games/`), commit, then run `publish.cmd`.
Both refuse to make a profile when less than half of the ROM is found in the `.prg` byte for byte
(every port here holds 65% or more): with the wrong ROM, or a port that rewrote the game's code instead
of running the ROM's, the profile would still carry the game.
