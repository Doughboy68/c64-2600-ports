# Megamania (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80` | GameNum | 1 | Selected game 0-3 (shown as 1-4): bit 0 two players, bit 1 straight lasers (games 1-2: the laser follows the ship, and holding fire repeats) |
| `$81` | Frame | 1 | Frame counter (paces animation, energy drain, attract player swap) |
| `$82` | Random | 1 | Random number (LFSR, stepped by Random); 0 only at power-on, which is how the first start is told from Game Reset |
| `$83` | SelectDelay | 1 | Frames until Game Select steps again ($1E) |
| `$84` | Joy0 | 1 | Left joystick, SWCHA high nibble shifted down (bit 3 right, bit 2 left; 0 = pressed); read as Joy0 + CurPlayer |
| `$85` | Joy1 | 1 | Right joystick, SWCHA low nibble (player 2) |
| `$86` | ColEor | 1 | Colour EOR mask: the idle timer (attract colour cycling) shifted left, else 0 |
| `$87` | ColAnd | 1 | Colour AND mask: $FF colour, $0F B&W (and $F7 while cycling) |
| `$88` | ColBg | 1 | Background colour (masked), also the "ENERGY" letters' and a hidden ship's colour |
| `$89` | ColBand | 1 | Bottom band background (shown in the energy bar's gaps) |
| `$8A` | ColLaser | 1 | Laser colour (COLUPF in the play area) |
| `$8B` | ColBar | 1 | Energy bar colour |
| `$8C` | ColPf | 1 | Bottom band (playfield) colour |
| `$8D-$98` | DigitPtr | 12 | Six pointers to the score digits' graphics ($FCxx; leading zeros point at a blank) |
| `$99-$9A` | ColShips | 2 | Ship colour by player (masked) |
| `$9B-$9C` | ColScore | 2 | Score and ships-left colour by player (masked) |
| `$9D-$9E` | Lives | 2 | Ships in reserve by player (3 at the start, 0 for player 2 in a one-player game; up to 6) |
| `$9F` | ColEnemy | 1 | Enemy colour (table EnemyColours by Wave & 15) |
| `$A0` | BobCount | 1 | Three-row waves: counter for the rows' up-and-down swoop (stepped at a rate by wave type, BobRate) |
| `$A1` | FormTop | 1 | Three-row waves: the line counter value at the top row ($50 + a triangle of BobCount); bombs drop only when $55 or more |
| `$A2` | Temp | 1 | Scratch (CalcPos fine part, kernel HMP0 for a row, logo row, ...) |
| `$A3` | Temp2 | 1 | Scratch (kernel HMP1 for a row, shape list pointer high byte, ...) |
| `$A4` | Temp3 | 1 | Scratch (kernel: player 0 colour for a row; logo line) |
| `$A5` | Temp4 | 1 | Kernel: line counter at a row's start |
| `$A6` | Temp5 | 1 | Scratch (kernel: player 1 copies; loops: which bomb / laser hit) |
| `$A7` | Temp6 | 1 | Scratch (kernel: player 0 copies; loops: the row) |
| `$A8` | RowPattern | 1 | Six-row waves: bits giving each row's direction (space dice, from wave 9); starts $AA, rotated each time the rows shift down |
| `$A9` | ScrollB | 1 | Six-row waves: the top row's height (0-$1C; at $1D the rows shift down one) |
| `$AA` | BallPos | 1 | Energy bar end (ball): fine \| coarse |
| `$AB-$AD` | BarPF | 3 | Energy bar playfield: PF0, PF1, PF2 |
| `$AE` | ShipPos | 1 | Ship position for the kernel: fine \| coarse |
| `$AF-$B0` | ShapePtr | 2 | Pointer to the enemies' shape (this animation frame; set by SetShapePtr) |
| `$B1-$B6` | Enemies | 6 | Enemies alive by row. Three-row (rows 0-2): bits 4-6 player 0's copies, bits 0-2 player 1's. Six-row: bits 4-6 the row's copies |
| `$B7-$BC` | Enemies2 | 6 | The other player's Enemies (two-player games: swapped by SwapPlayers) |
| `$BD` | LaserX | 1 | Laser X |
| `$BE-$C1` | RowPos0 | 4 | Player 0 position by row (fine \| coarse): three-row rows 0-2; six-row rows 0-5 run on into RowPos1 |
| `$C2-$C4` | RowPos1 | 3 | Three-row waves: player 1 position by row (fine \| coarse). Six-row: RowPos0 rows 4-5 |
| `$C6-$CB` | RowCopies | 6 | Copies drawn by row (index into CopiesNusiz). Three-row: player 0 high nibble, player 1 low; six-row: one per row |
| `$CC-$CE` | RowX0 | 3 | Three-row waves: player 0 X by row (the bombs drop from it) |
| `$CF` | KernelRow | 1 | Kernel: the row being drawn |
| `$D0-$D2` | RowX1 | 3 | Three-row waves: player 1 X by row |
| `$D3` | IdleTimer | 1 | Counts up every 256 frames without joystick input; from $80 the colours cycle (attract). Cleared by any input |
| `$D4` | ColShip | 1 | Ship colour this frame (flashes while dying, background when no game) |
| `$D5` | AnimFrame | 1 | Enemy animation frame: counts down every 4 frames, from the wave type's AnimFrames |
| `$D6` | ShipX | 1 | Ship X ($18-$84; $50 at the start) |
| `$D7` | CurPlayer | 1 | Player up: 0 or 1 |
| `$D8` | FirePrev | 1 | Fire button last frame (INPT4/5), for a new press; $FF in games 1-2 (holding fire repeats) |
| `$D9` | WaveFlags | 1 | Between waves: bit 0 set up the new wave's enemies, bit 1 count the energy left into the score, bit 2 fill the energy bar (7 after a wave is cleared, 4 after a ship is lost) |
| `$DA` | GameOver | 1 | 0: a game is running; else counts down each frame, never reaching 0 (the copyright line scrolls by it). $FF after power-on or Game Select |
| `$DB-$DD` | Score | 3 | Score, BCD, high byte first (after Game Select: the game number) |
| `$DE` | Wave | 1 | Wave count from 0 (bit 0: six-row wave; & 7 the type; & 15 the colour; 8 and up harder) |
| `$DF` | WaveType | 1 | Wave & 7: the enemies' shape and movement |
| `$E0` | Points | 1 | Points to add to the score this frame (BCD, tens and units) |
| `$E1-$E5` | Score2 | 5 | The other player's Score, Wave and WaveType (swapped by SwapPlayers) |
| `$E6` | Energy | 1 | Energy left (0-$53; the bar's length; drains every 32 frames, the ship is lost at 0) |
| `$E9` | HitRow0 | 1 | The kernel's collision result: row + 1 where player 0 met the laser (ball), 0 none (set to the row count before the kernel) |
| `$EA` | HitRow1 | 1 | The same for player 1 (three-row waves) |
| `$EB` | ShipHit | 1 | Ship being destroyed: $1F on a hit, counts down every 4 frames (the wave restarts below 9, a ship is lost at 0) |
| `$EC` | Bomb0Y | 1 | Bomb 0 (missile 0) Y; $F0 none |
| `$ED` | Bomb1Y | 1 | Bomb 1 (missile 1) Y; $F0 none |
| `$EE` | Bomb0X | 1 | Bomb 0 X |
| `$EF` | Bomb1X | 1 | Bomb 1 X |
| `$F0` | EntryCount | 1 | Three-row waves: counts up to $91 as the enemies come in (its high nibble picks which are shown, EntryMask0/1). Not used by six-row waves |
| `$F1-$F6` | RowX | 6 | Six-row waves: X by row. Three-row: +0 is the formation's X (the rows are offset from it) |
| `$F7` | RowsHidden | 1 | Rows not yet shown: 6 at a wave's start, one less each time the rows shift down (six-row waves; three-row: 0 once set up) |
| `$F8` | HitSound | 1 | Enemy hit sound timer ($20, counts down) |
| `$F9` | LaserY | 1 | Laser Y ($11 when fired, up 4 a frame, 3 with the player's difficulty switch at A, gone at $92); 0 none |
| `$FA-$FF` | Stack | 6 | Stack (the deepest call is three levels) |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$F000` | Reset | Power on: clear RAM, set up a game; the first time (Random 0) go to the game select |
| `$F004` | ClearRAM | Clear page zero from X (Game Reset comes here with X = $D3), then InitGame |
| `$F01B` | FrameStart | Vertical blank: colours, the ship's colour, then the kernel's positions |
| `$F04B` | SixRowPositions | Six-row waves: each row's copies and position |
| `$F081` | ThreeRowPositions | Three-row waves: the copies shown so far, X and position of each row's two players |
| `$F0FA` | PositionObjects | Energy bar end, ship, bombs and laser positions |
| `$F138` | Kernel | Wait for the timer, then draw the picture |
| `$F159` | ThreeRowKernel | Three-row waves: laser lines down to the top row |
| `$F172` | ThreeRowRow | Three-row waves: a row's 5 set-up lines (positions, copies, colours) |
| `$F213` | ThreeRowLines | Three-row waves: a row's 9 drawn lines (enemies, bombs, laser), then its collisions |
| `$F25C` | BelowRows | Three-row waves: bombs and laser down to the ship |
| `$F2A5` | SixRowKernel | Six-row waves: position the ship, then the rows |
| `$F2D3` | SixRowRow | Six-row waves: a row's set-up lines, then its shape masked by the diamond (ship drawn among them) |
| `$F3C2` | ShipKernel | Three-row waves: position and draw the ship |
| `$F410` | BandKernel | Below the play area: did a bomb or enemy hit the ship, then the bottom band |
| `$F4B1` | EnergyLines | "ENERGY" and the energy bar |
| `$F4E5` | LivesLines | The ships left |
| `$F541` | ScoreLines | Six score digits (48-pixel trick) |
| `$F59D` | LogoLines | The Activision logo, or the copyright line scrolling by GameOver |
| `$F639` | Overscan | After the picture (FrameEnd): bombs fall, score digits, wave cleared? |
| `$F646` | MoveBombs | Bombs fall (faster from wave 17); off the bottom: none ($F0) |
| `$F662` | ScoreDigits | Score digit pointers; leading zeros blanked |
| `$F694` | CheckWaveCleared | No enemies left: next wave (WaveFlags = 7) |
| `$F6B3` | CheckNoGame | If no game is running: silence, hide the ship; two-player games swap players now and then |
| `$F6D8` | Animate | Enemy animation frame and shape, three-row swoop (FormTop) |
| `$F707` | EnemyColour | Enemy colour from the wave |
| `$F715` | FrameSync | Wait for the timer, vertical sync, frame and idle counters, colour masks, joysticks |
| `$F76C` | Switches | Game Reset and Game Select |
| `$F784` | NextGame | Game Select: next game number |
| `$F786` | SelectGame | Show game GameNum: score shows its number, no game running |
| `$F7A8` | GameLogic | The game's logic (only while a game is running) |
| `$F7AF` | HitSoundStep | Enemy hit sound |
| `$F7C5` | WaveState | Between waves (WaveFlags): set up, energy bonus, energy fill |
| `$F7D3` | FillEnergy | Fill the energy bar with its sound; full: the wave starts |
| `$F7FB` | EnergyBonus | Wave cleared: count the energy left into the score |
| `$F824` | SetUpWave | Set up the new wave's enemies (full rows, X 0), no bombs |
| `$F85C` | CheckShip | Ship hit or out of energy: the ship explodes |
| `$F86B` | ShipDying | Ship exploding: sound, flash; the wave restarts; at the end lose a ship or end the game |
| `$F8CC` | DropBombs | Drop bombs from the enemies above the ship |
| `$F919` | SixRowBomb | Six-row waves: a bomb from row 4 (none in space dice waves) |
| `$F946` | MoveShip | Joystick moves the ship; the laser |
| `$F990` | MoveLaser | Laser up 4 lines a frame (3 with the difficulty switch at A), with its sound |
| `$F9B7` | LaserHits | Kill the enemy copy the laser hit (from HitRow0/1 and LaserX), score it |
| `$FA09` | MoveEnemies | Move the enemies by wave type |
| `$FA29` | ThreeRowMove | Three-row waves: the formation moves right (from wave 8: waits, then double speed) |
| `$FA44` | SixRowMove | Six-row waves: scroll the rows down; at the bottom the rows shift and one comes back at the top |
| `$FAC5` | TireMove | Radial tires: alternate rows move opposite ways |
| `$FACA` | CookieMove | Cookies: all rows sway left and right together |
| `$FADE` | IronMove | Steam irons: rows drift at random in a band, faster scrolling |
| `$FB29` | DiceMove | Space dice (from wave 9): rows move by RowPattern's bits |
| `$FB31` | MoveRowsByBits | Move each row one pixel left or right by A's bits |
| `$FB41` | DrainEnergy | Every 32 frames: one less energy |
| `$FB4D` | AddScore | Add Points to the score; an extra ship each 10,000; at 999,999 the game ends |
| `$FB88` | NextFrame | Back to FrameStart |
| `$FB8B` | PrepareKernel | Collision rows reset, energy bar playfield, ship and score colours |
| `$FBDA` | Wrap160 | A (+ carry) wrapped into 0-159 |
| `$FBE4` | SwapPlayers | Swap the two players' enemies and score/wave, switch CurPlayer |
| `$FC0A` | SetShape | ShapePtr from the wave type's shape list and AnimFrame |
| `$FC16` | Digits | Digit graphics 0-9, 8 rows each (upside down); then a blank |
| `$FC6A` | ShipGfx | The ship's rows (22, from the bottom) |
| `$FC80` | Logo0 | Activision logo and copyright: six columns of 16 rows |
| `$FC90` | Logo1 | Logo column 2 |
| `$FCA0` | Logo2 | Logo column 3 |
| `$FCB0` | Logo3 | Logo column 4 |
| `$FCC0` | Logo4 | Logo column 5 |
| `$FCD0` | Logo5 | Logo column 6 |
| `$FCE0` | EnergyLabel0 | "ENERGY": three 5-row columns |
| `$FCE5` | EnergyLabel1 | "ENERGY" column 2 |
| `$FCEA` | EnergyLabel2 | "ENERGY" column 3 |
| `$FCEF` | Colours | Background, band, laser, energy bar and band playfield colours |
| `$FCF4` | EnemyColours | Enemy colour by Wave & 15 |
| `$FD04` | KillMask0 | Clear a player 0 copy (by the laser's offset from the row X) |
| `$FD07` | KillMask1 | Clear a player 1 copy |
| `$FD0A` | BombMask | Bombs: which nibble of Enemies (player 0 / player 1) |
| `$FD0C` | LivesGfx | The ships-left symbol (10 rows) |
| `$FD16` | EntryMask0 | Three-row waves: copies shown as the enemies come in (rows 0 and 2), by EntryCount |
| `$FD20` | EntryMask1 | The same for row 1 |
| `$FD2A` | CopyOffset | X offset of the first copy left (by copies bits) |
| `$FD2F` | CopiesNusiz | Copies bits -> NUSIZ |
| `$FD37` | P1Offset | Three-row waves: player 1's X offset from player 0 |
| `$FD39` | RowStagger | Three-row waves: X offset of each row (the middle row moved) |
| `$FD3B` | BarPF0 | Energy bar PF0 by length (runs on into BarPF2) |
| `$FD3F` | BarPF2 | Energy bar PF2 by length |
| `$FD54` | BarPF1 | Energy bar PF1 by length |
| `$FD69` | BombStartY | Three-row waves: a bomb's start below FormTop by row |
| `$FD6C` | FullRows | A new three-row wave's Enemies |
| `$FD6F` | LivesNusiz | NUSIZ for the ships left (player 1 low nibble, player 0 high) |
| `$FD76` | AnimFrames | Animation frames - 1 by wave type |
| `$FD7E` | DiamondMask | Six-row waves: the enemies' diamond mask |
| `$FD92` | DeathColours | Ship colour while exploding, by ShipHit |
| `$FDB2` | BobRate | Three-row swoop rate by wave type (Frame mask) |
| `$FDBA` | ShapeLists | Pointer to each wave type's shape list (low bytes of the frames, same page) |
| `$FDBB` | ShapeListsHi | ShapeLists' high bytes |
| `$FDCA` | DiamondFrames | Diamonds (type 4): shape list, then shapes |
| `$FE00` | CookieFrames | Cookies (type 1): shape list, then shapes |
| `$FE2B` | HamburgerFrames | Hamburgers (type 0): shape list, then shapes |
| `$FE49` | IronFrames | Steam irons (type 5): shape list, then shapes |
| `$FE74` | BowTieFrames | Bow ties (type 6): shape list, then shapes |
| `$FE9E` | TireFrames | Radial tires (type 3): shape list, then shapes |
| `$FECD` | DiceFrames | Space dice (type 7): shape list (16 frames, a window sliding down the shape), then the shape |
| `$FEFE` | NextRandom | Step Random (8-bit LFSR) |
| `$FF09` | BugFrames | Bugs (type 2): shape list, then shapes |
| `$FF27` | InitGame | New game: digit pointers, shape, enemies, energy fill, ship, lives |
| `$FF79` | SetPosHmove | SetPos, then WSYNC and HMOVE |
| `$FF81` | CalcPos | X (A) -> fine motion (A, high nibble) and coarse count (Y) |
| `$FF9C` | Delay18 | Cycle delays: a jsr here takes 18 cycles (then 16, 14, 12) |
| `$FF9D` | Delay16 | jsr: 16 cycles |
| `$FF9E` | Delay14 | jsr: 14 cycles |
| `$FF9F` | Delay12 | jsr: 12 cycles (also CalcPos's rts) |
| `$FFA0` | SetPos | Position object X (0 player 0 ... 4 ball) at A (RESPx) |
| `$FFAD` | ScoreEnemy | Points for an enemy by wave (energy bonus: the wave before's) |
| `$FFC4` | BonusPoints | Points table one entry early (its first byte is the rts) |
| `$FFC5` | EnemyPoints | Points for an enemy by wave (BCD 20-90) |
| `$FFCE` | LoseShip | Next player up (if they have ships), one ship less |
| `$FFDF` | SetRowX | Store X as row Y's X, wrapped into 0-159 |
| `$FFEE` | SetShapePtr | ShapePtr from the shape list (Temp/Temp2) and AnimFrame |
