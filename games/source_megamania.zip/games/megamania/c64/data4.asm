; data.asm's code, tables and variables kept in the file (run at CODE_4: copied there by Start)

; =================================================================== sound
; The game's TIA sound registers, translated to SID voices 1 and 2 once a frame (Stargate's
; mapping: the TIA circuit's periods and duties; the envelope restarted only when the volume
; rises; very quiet starts left silent).
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   stx v3
        lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        bne _on
        jmp _off
_on     cmp #3
        bcs +
        lda SndOn,x
        bne +
        jmp _off
+       ldy v1
        lda SidWave,y
        bne +
        jmp _off2
+
        cpx #0                  ; (sync / ring, bits 1-2: only voice 1, by voice 3)
        beq +
        and #$f9
+       sta tmp                 ; waveform
        jsr Sync3
        lda v1                  ; frequency index = AUDC * 32 + AUDF
        lsr
        lsr
        lsr
        sta ptrA+1
        lda v1
        asl
        asl
        asl
        asl
        asl
        ora v2
        clc
        adc FreqTab
        sta ptrA
        lda ptrA+1
        adc FreqTab+1
        sta ptrA+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d400,y
        inc ptrA+1
        inc ptrA+1
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d401,y
        ldy v1                  ; the pulse width (the TIA waveform's duty)
        lda SidPWHi,y
        pha
        lda SidPWLo,y
        ldy tmp2
        sta $d402,y
        pla
        sta $d403,y
        lda v0                  ; volume becomes the sustain level (doubled for a narrow
        ldy v1                  ; pulse, SidBoost)
        ldx SidBoost,y
        beq +
        asl
        cmp #16
        bcc +
        lda #15
+       asl
        asl
        asl
        asl
        ldy tmp2
        sta $d406,y
        ldx v3                  ; (the channel)
        lda SndLast,x           ; the envelope restarted only when the volume rises
        cmp v0
        bcs +
        lda tmp
        sta $d404,y
+       lda tmp
        ora #1
        sta $d404,y
        lda #1
        sta SndOn,x
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
        sta SndOn,x
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts

; Sync3: waveform A with sync or ring (bits 1-2): voice 3 at its frequency for AUDC 15, AUDF v2
; (it restarts or ring-modulates voice 1)
Sync3:
        and #6
        beq _r
        ldy v2
        lda isPal
        beq +
        lda SyncLo,y
        sta $d40e
        lda SyncHi,y
        sta $d40f
        rts
+       lda SyncLoN,y
        sta $d40e
        lda SyncHiN,y
        sta $d40f
_r      rts

; Testing aid (tools/c64late.js): with DbgAuto set the C64 plays by itself, the inputs by the
; tick count (the same game on PAL and NTSC, whatever the timing): moves left and right, fires
; often, Game Reset when a game is over, lives kept. From tick AutoFrom to AutoTo (300 and 3900
; unless a tool sets them) the counters run; then they are kept in DbgAutoRes and DbgAuto becomes
; $80 (the inputs left alone).
AutoInput:
        lda DbgAuto
        bpl +
        rts
+       inc AutoT
        bne +
        inc AutoT+1
+       lda AutoT
        cmp AutoFrom
        bne +
        lda AutoT+1
        cmp AutoFrom+1
        bne +
        ldx #DbgAutoN - 1       ; AutoFrom: the counters from 0
        lda #0
-       sta DbgLoops,x
        dex
        bpl -
+       lda AutoT
        cmp AutoTo
        bne +
        lda AutoT+1
        cmp AutoTo+1
        bne +
        ldx #DbgAutoN - 1       ; AutoTo: the counters kept, the inputs left alone
-       lda DbgLoops,x
        sta DbgAutoRes,x
        dex
        bpl -
        lda #$80
        sta DbgAuto
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        sta INPT5
        rts
+       lda firstTick           ; (the power-on tick: the 2600's RAM not set up yet)
        beq +
        jmp _in
+       lda AutoR               ; a random number (an 8-bit shift register)
        asl
        bcc +
        eor #$1d
+       sta AutoR
        lda Lives               ; (lives kept)
        cmp #3
        bcs +
        lda #3
        sta Lives
+       inc AutoHop             ; every 600 ticks, in play: the wave cleared (the next comes)
        bne +
        inc AutoHop+1
+       lda AutoHop
        cmp #<600
        lda AutoHop+1
        sbc #>600
        bcc +
        lda GameOver
        ora ShipHit
        ora WaveFlags
        bne +
        lda #0
        sta AutoHop
        sta AutoHop+1
        ldx #5
-       sta $b1,x
        dex
        bpl -
+       dec AutoHold            ; a new direction now and then: right, left, none
        bpl +
        lda AutoR
        and #63
        clc
        adc #10
        sta AutoHold
        lda AutoR
        and #3
        tax
        lda AutoDirs,x
        sta AutoDir
+       lda SWCHB               ; no game: Game Reset
        ora #1
        ldx GameOver
        beq +
        ldx AutoR
        cpx #40
        bcs +
        and #$fe
+       sta SWCHB
_in     lda AutoDir
        sta SWCHA
        lda #$80                ; fire now and then
        ldx AutoR
        cpx #100
        bcs +
        lda #0
+       sta INPT4
        rts
AutoDirs:   .byte $7f, $bf, $ff, $7f

; ================================================================== tables
Bit:        .byte $01, $02, $04, $08, $10, $20, $40, $80
BitL:       .byte $80, $40, $20, $10, $08, $04, $02, $01
SidVoice:   .byte 0, 7
Mul14:      .byte 0, 14, 28
McPixN:     .byte $3f, $cf, $f3, $fc            ; multicolour pixel n cleared
McPixMask:  .byte $c0, $30, $0c, $03            ; ... its bits
McPix10:    .byte $80, $20, $08, $02            ; ... as "10"
; copies by NUSIZ: CopyOff[CopyFirst[n] .. CopyFirst[n + 1] - 1]
CopyFirst:  .byte 0, 1, 3, 5, 8, 10, 11, 14, 15
CopyOff:    .byte 0, 0, 16, 0, 32, 0, 16, 32, 0, 64, 0, 0, 32, 64, 0
CopyTabLo:  .byte <CopyD0, 0, <CopyD2, 0, <CopyD4, 0, <CopyD6, 0
CopyTabHi:  .byte >CopyD0, 0, >CopyD2, 0, >CopyD4, 0, >CopyD6, 0
; the energy bar's 20 cells: the register ($AB PF0, $AC PF1, $AD PF2) and bit of each
BarCell:    .byte 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1
BarBit:     .byte $01, $02, $04, $08, $10, $20, $40, $80, $10, $20, $40, $80
            .byte $80, $40, $20, $10, $08, $04, $02, $01
R1SrcLo:    .byte <R1B0, <R1B1, <R1B2
R1SrcHi:    .byte >R1B0, >R1B1, >R1B2
; buffers (VIC banks 1, 2, 0): bank bits ($DD00), $D018 (the screen's place), the bitmap's,
; screen's and sprite blocks' pages
BankBits:   .byte 2, 1, 3
D18Of:      .byte $08, $08, $18
BmHiOf:     .byte $60, $a0, $20
ScrHiOf:    .byte $40, $80, $04
ScrPtrHi:   .byte $43, $83, $07
SprHiOf:    .byte $4c, $8c, $0c
EvBaseOf:   .byte 0, NEV, 2 * NEV
NG          = 6         ; sprite moves per buffer at most
MvBaseOf:   .byte 0, NG, 2 * NG
BCBase:     .byte 0, BRMAX, 2 * BRMAX
R1CodeLo:   .byte <R1CodeA0, <R1CodeA1, <R1CodeA2       ; the middle row's store code, by buffer
R1CodeHi:   .byte >R1CodeA0, >R1CodeA1, >R1CodeA2
R1CodeBLo:  .byte <R1CodeB0, <R1CodeB1, <R1CodeB2
R1CodeBHi:  .byte >R1CodeB0, >R1CodeB1, >R1CodeB2
R1Base:     .byte 0, 5, 10
R1TBase:    .byte 0, 42, 84
BarBase:    .byte 0, 20, 40
ShPg0:      .byte $50, $53, $56, $59    ; the middle row's shifted bytes (made by InitTables, in
ShPg1:      .byte $51, $54, $57, $5a    ; bank 1 between its sprite blocks and bitmap): the pages
ShPg2:      .byte $52, $55, $58, $5b    ; for shift 0-3, byte 0 / 1 / 2
        .cerror NBUF != 3, "the tables above are for three buffers"

; ------------------------------------------------------- variables (RAM)
DbgSWCHA:   .byte $ff           ; AND masks applied to the inputs (testing aid)
DbgINPT4:   .byte $ff
DbgSWCHB:   .byte $ff
DbgBorder:  .byte 0             ; non-zero: colour the border while drawing / running the game
DbgLoops:   .word 0             ; main loop passes
DbgLate:    .word 0             ; ... that skipped pictures (more than one frame owed)
DbgTops:    .word 0             ; frame tops the interrupt has done
DbgRepeat:  .word 0             ; frame tops with no new picture waiting (the last shown again)
DbgMoveLate: .word 0            ; sprite moves done on or after the new sprites' start line
DbgIdle:    .fill 3             ; the main loop waiting for a frame (15 cycles a count)
DbgIdleQ:   .fill 3             ; ... for a buffer (17 cycles a count)
DbgRepW:    .fill 16            ; frame tops with no new picture, by wave ($DE & 15)
DbgAutoN    = DbgRepW + 16 - DbgLoops
DbgAuto:    .byte 0             ; testing aid: non-zero: the C64 plays by itself (AutoInput)
DbgAutoRes: .fill DbgAutoN      ; ... the counters over its ticks AutoFrom-AutoTo
AutoT:      .word 0
AutoFrom:   .word 300
AutoTo:     .word 3900
AutoR:      .byte 1
AutoHold:   .byte 0
AutoDir:    .byte $ff
AutoHop:    .word 0
FreqTab:    .word SidFreqLo     ; PAL or NTSC frequency tables
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0
outv:       .fill 3             ; ReadInput: SWCHA, INPT4, INPT5 being built
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
SndLast:    .fill 6, $ff
SndOn:      .fill 2
LastEnemyCol: .byte $ff         ; the colour RAM's colours (both buffers share it)
LastGapCol: .byte $ff
LastLogoCol: .byte $ff
NmiDone:    .byte 0             ; the one NMI came (Start)
R1CodeA0:   .fill 3 * 18 + 7, $60       ; the middle row's store code (R1Init, R1Patch)
R1CodeB0:   .fill 3 * 18 + 7, $60
R1CodeA1:   .fill 3 * 18 + 7, $60
R1CodeB1:   .fill 3 * 18 + 7, $60
R1CodeA2:   .fill 3 * 18 + 7, $60
R1CodeB2:   .fill 3 * 18 + 7, $60
