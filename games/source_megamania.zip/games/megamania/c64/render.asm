; ================================================================= render
; Draws the frame the ticks produced into a free buffer (neither shown nor waiting: its bitmap,
; screen, sprite blocks and staged registers), with its list of raster events. What a buffer
; shows is remembered (keys) so that only what changed is drawn again: the bitmap's middle row
; of enemies and bombs are cleared where the buffer last had them; the bottom (energy bar, ships
; left, score, logo) and the colours only when they change. (The six-row waves' part and the
; buffers' set-up: render6.asm.)

Render:
        sei                     ; the buffer neither shown nor waiting (at most one waits): with
        ldx curBuf              ; none waiting, the one after the shown one
        inx
        cpx #NBUF
        bcc +
        ldx #0
+       lda QCount
        beq +
        lda #NBUF * (NBUF - 1) / 2      ; (0 + 1 + 2 less the other two)
        sec
        sbc curBuf
        sec
        sbc Queue
        tax
+       cli
        stx rbuf
        lda BmHiOf,x
        sta bmHi
        lda ScrHiOf,x
        sta scrHi
        lda SprHiOf,x
        sta sprHi
        txa
        asl
        asl
        asl
        sta v5                  ; 8 * buffer: the staged sprite values' index
        lda #0
        sta FrMsb
        sta FrEn
        jsr RColours
        jsr RBottom
        jsr ClearBombs
        lda IsModeB
        beq +
        jsr ClearRow1
        jmp RenderB
+       jsr Row1
        jsr DrawBombs
        jmp SpritesA

; ------------------------------------------------------------------ colours
; The 2600's colours mapped to the C64's: the background, sprites; the colour RAM ("11": the
; enemies' colour in the playing area, the energy bar's gaps, the logo's first line) when one of
; those changes; the bottom's screen bytes ("01" / "10") when theirs change (by buffer)
RColours:
        ldx rbuf
        lda ColBg
        lsr
        tay
        lda ColorMap,y
        sta StBg,x
        lda ColEnemy
        lsr
        tay
        lda ColorMap,y
        sta cEnemy
        lda ColShip
        lsr
        tay
        lda ColorMap,y
        sta cShip
        lda ColLaser
        lsr
        tay
        lda ColorMap,y
        sta cLaser
        lda ColPf
        lsr
        tay
        lda ColorMap,y
        sta cBand
        lda ColBar
        lsr
        tay
        lda ColorMap,y
        sta cBar
        lda ColBand
        lsr
        tay
        lda ColorMap,y
        sta cGap
        ldy CurPlayer
        lda ColScore,y
        lsr
        tay
        lda ColorMap,y
        sta cScore
        lda #$16                ; the logo's colour (masked as the kernel does)
        eor $86
        and $87
        lsr
        tay
        lda ColorMap,y
        sta cLogo
        ; sprites: the enemies (0-4; 3 the bomb in six-row waves), the ship, the laser
        ldx v5
        lda cEnemy
        sta StCol,x
        sta StCol+1,x
        sta StCol+2,x
        sta StCol+4,x
        ldy cEnemy
        lda IsModeB
        beq +
        ldy cShip
+       tya
        sta StCol+3,x
        lda cShip
        sta StCol+5,x
        sta StCol+6,x           ; (three-row waves' bomb sprite: the ship's colour, as its "10")
        lda cLaser
        sta StCol+7,x
        ; colour RAM: the enemies' colour (rows 0-17, columns 2-39)
        lda cEnemy
        cmp LastEnemyCol
        beq _cr2
        sta LastEnemyCol
        ldx #2
-       .for r := 0, r < 18, r += 1
        sta $d800 + 40 * r,x
        .endfor
        inx
        cpx #40
        bne -
_cr2    lda cGap                ; the energy bar's gaps (row 19, columns 12-31), the logo's
        cmp LastGapCol          ; first line (row 22, columns 5-17)
        beq +
        sta LastGapCol
        ldx #12
-       sta $d800 + 40 * 19,x
        inx
        cpx #32
        bne -
+       lda cLogo
        cmp LastLogoCol
        beq +
        sta LastLogoCol
        ldx #5
-       sta $d800 + 40 * 22,x
        inx
        cpx #18
        bne -
+       ; the bottom's screen bytes (this buffer's): rows 18-23, when their colours change
        lda cBand
        asl
        asl
        asl
        asl
        sta tmp                 ; "01": the band
        ldx rbuf
        lda cBar
        ora tmp
        sta tmp2
        lda cScore
        ora tmp
        sta tmp3
        lda tmp2
        cmp KBotA,x
        bne +
        lda tmp3
        cmp KBotB,x
        bne +
        lda cLogo
        cmp KBotC,x
        beq _done
+       lda tmp2
        sta KBotA,x
        lda tmp3
        sta KBotB,x
        lda cLogo
        sta KBotC,x
        lda #<(40 * 18)
        sta ptrA
        lda scrHi
        clc
        adc #>(40 * 18)
        sta ptrA+1
        ldy #0                  ; row 18: the band (the bombs' colour: set where they are)
-       lda (ptrA),y
        and #$0f
        ora tmp
        sta (ptrA),y
        iny
        cpy #40
        bne -
        lda tmp2                ; row 19: band, bar
-       sta (ptrA),y
        iny
        cpy #80
        bne -
        lda tmp3                ; rows 20-22: band, score and ships left
-       sta (ptrA),y
        iny
        cpy #200
        bne -
        lda cLogo               ; row 23: the logo ("10")
-       sta (ptrA),y
        iny
        cpy #240
        bne -
_done   rts

; ------------------------------------------------------------------ the bottom
; Lines 192-222 the band (playfield, "01"), drawn once; on it the energy bar (lines 195-199,
; columns 12-31), the ships left (202-211, columns 16-27), the score (214-221, columns 16-27);
; the logo (225-232, columns 5-17) on black. Each drawn when what it shows changes.
RBottom:
        ldx rbuf
        lda BarPF               ; the energy bar: PF0/PF1/PF2 ($AB-$AD), its end (the ball)
        cmp KBar,x
        bne _bar
        lda BarPF+1
        cmp KBar+NBUF,x
        bne _bar
        lda BarPF+2
        cmp KBar+2*NBUF,x
        bne _bar
        lda BallPos
        cmp KBar+3*NBUF,x
        beq _lives
_bar    lda BarPF
        sta KBar,x
        lda BarPF+1
        sta KBar+NBUF,x
        lda BarPF+2
        sta KBar+2*NBUF,x
        lda BallPos
        sta KBar+3*NBUF,x
        jsr DrawBar
_lives  ldx rbuf
        ldy CurPlayer
        lda Lives,y
        cmp KLives,x
        beq _score
        sta KLives,x
        jsr DrawLives
_score  lda #0                  ; each digit drawn again when its pointer changed
        sta v3
        lda rbuf
        sta v4                  ; (its key: NBUF * digit + buffer)
_dg     lda v3
        asl
        tay
        ldx v4
        lda DigitPtr,y
        cmp KScore,x
        beq +
        sta KScore,x
        ldx v3
        jsr DrawDigit
+       lda v4
        clc
        adc #NBUF
        sta v4
        inc v3
        lda v3
        cmp #6
        bne _dg
_logo   ldx rbuf
        lda LogoY0
        cmp KLogo,x
        beq +
        sta KLogo,x
        jsr DrawLogo
+       rts

; BmAt: ptrA = the bitmap byte of line A, column X (this buffer's)
BmAt:
        tay
        lda LnLo,y
        clc
        adc Col8Lo,x
        sta ptrA
        lda LnHi,y
        adc Col8Hi,x
        adc bmHi
        sta ptrA+1
        rts

; Row8: store A at the bitmap byte (ptrA),y and move y (ptrA) a column right
Row8:
        sta (ptrA),y
        tya
        clc
        adc #8
        tay
        bcc +
        inc ptrA+1
+       rts

; DrawLives: the ships left (icons at pixels 64 + 8i) on lines 202-211 (rows 9-0), "10" on
; the band
DrawLives:
        ldy CurPlayer
        lda Lives,y
        cmp #7
        bcc +
        lda #6
+       sta v2                  ; icons
        lda #202
        sta line
        lda #9
        sta v3                  ; the row
_ll     ldy v3
        lda T_LIVES,y
        sta v4
        lda line
        ldx #16
        jsr BmAt
        ldx #0                  ; 6 places, 2 bytes each
        ldy #0
-       lda #0
        cpx v2
        bcs +
        lda v4
+       jsr Pair
        inx
        cpx #6
        bne -
        inc line
        dec v3
        bpl _ll
        rts

; Pair: a byte's 8 pixels as two multicolour bytes at (ptrA),y (and the next column), set "10",
; clear "01"; y moved two columns on (X kept)
Pair:
        sta tmp2
        stx tmp3
        lsr
        lsr
        lsr
        lsr
        tax
        lda Exp1001,x
        jsr Row8
        lda tmp2
        and #$0f
        tax
        lda Exp1001,x
        jsr Row8
        ldx tmp3
        rts

; DrawDigit: score digit X (pixels 64 + 8X: columns 16 + 2X) on lines 214-221 (its rows 7-0):
; lines 214-217 the cell row 21's lines 4-7, 218-221 the row 22's lines 0-3; set pixels "10" on
; the band ("01")
DrawDigit:
        txa
        asl
        tay
        lda DigitPtr,y
        sta ptrB
        lda DigitPtr+1,y
        sta ptrB+1
        txa
        asl
        adc #16
        tax                     ; the column
        lda Col8Lo,x
        clc
        adc #<(21 * 320)
        sta ptrA
        lda Col8Hi,x
        adc #>(21 * 320)
        clc
        adc bmHi
        sta ptrA+1
        lda ptrA
        clc
        adc #<320
        sta ptrD
        lda ptrA+1
        adc #>320
        sta ptrD+1
        ; the glyph's rows 7-4 on row 21's lines 4-7, rows 3-0 on row 22's lines 0-3: each as
        ; two multicolour bytes (ExpL / ExpR, the right one a column on: + 8)
        ldy #7
        lda (ptrB),y
        tax
        lda ExpL,x
        ldy #4
        sta (ptrA),y
        lda ExpR,x
        ldy #12
        sta (ptrA),y
        ldy #6
        lda (ptrB),y
        tax
        lda ExpL,x
        ldy #5
        sta (ptrA),y
        lda ExpR,x
        ldy #13
        sta (ptrA),y
        ldy #5
        lda (ptrB),y
        tax
        lda ExpL,x
        ldy #6
        sta (ptrA),y
        lda ExpR,x
        ldy #14
        sta (ptrA),y
        ldy #4
        lda (ptrB),y
        tax
        lda ExpL,x
        ldy #7
        sta (ptrA),y
        lda ExpR,x
        ldy #15
        sta (ptrA),y
        ldy #3
        lda (ptrB),y
        tax
        lda ExpL,x
        ldy #0
        sta (ptrD),y
        lda ExpR,x
        ldy #8
        sta (ptrD),y
        ldy #2
        lda (ptrB),y
        tax
        lda ExpL,x
        ldy #1
        sta (ptrD),y
        lda ExpR,x
        ldy #9
        sta (ptrD),y
        ldy #1
        lda (ptrB),y
        tax
        lda ExpL,x
        ldy #2
        sta (ptrD),y
        lda ExpR,x
        ldy #10
        sta (ptrD),y
        ldy #0
        lda (ptrB),y
        tax
        lda ExpL,x
        ldy #3
        sta (ptrD),y
        lda ExpR,x
        ldy #11
        sta (ptrD),y
        rts

; DrawLogo: the logo's six bytes at pixels 21 + 8i (columns 5-17, one pixel in), lines 225-232
; (rows LogoY0 .. LogoY0 - 7), set pixels "10" on black. (Pixel 28 the first byte's own, as Stella
; shows it: tools/vcs.js has the third byte's there, a GRP1 write landing on it.)
DrawLogo:
        lda #225
        sta line
        lda LogoY0
        sta v3
_lg     ldy v3
        lda T_LOGO,y
        sta LogoRow
        lda T_LOGO+$10,y
        sta LogoRow+1
        lda T_LOGO+$20,y
        sta LogoRow+2
        lda T_LOGO+$30,y
        sta LogoRow+3
        lda T_LOGO+$40,y
        sta LogoRow+4
        lda T_LOGO+$50,y
        sta LogoRow+5
        lda #0
        sta LogoRow+6
        jsr LogoBytes           ; (13 bytes from pixel 20: one pixel right)
        lda line
        ldx #5
        jsr BmAt
        lda #$aa                ; ("10"; line 225 shares its cell row with the score's lines:
        ldx line                ; "11", the colour RAM's logo colour there)
        cpx #225
        bne +
        lda #$ff
+       sta tmp3
        ldx #0
        ldy #0
-       lda LogoOut,x
        and tmp3
        jsr Row8
        inx
        cpx #13
        bne -
        inc line
        dec v3
        lda line
        cmp #233
        bne _lg
        rts

; LogoBytes: LogoRow's 48 pixels shifted one pixel right (the first at pixel 1 of 52), as
; 13 multicolour bytes ("11" set) in LogoOut
LogoBytes:
        clc
        .for i := 0, i < 7, i += 1
        ror LogoRow + i         ; (the carry from byte to byte)
        .endfor
        ldx #0
-       txa
        lsr
        tay
        lda LogoRow,y
        bcs +
        lsr
        lsr
        lsr
        lsr
+       and #$0f
        tay
        lda Exp4,y
        sta LogoOut,x
        inx
        cpx #13
        bne -
        rts

; ------------------------------------------------------------------ bombs (three-row waves)
; ClearBombs: the bomb runs this buffer last had, cleared
ClearBombs:
        ldx rbuf
        lda BCN,x
        beq _done
        sta v4
        lda #0
        sta BCN,x
        lda BCBase,x
        sta v3
_r      ldx v3
        lda BCLo,x
        sta ptrA
        lda BCHi,x
        sta ptrA+1
        lda BCMask,x
        sta _m+1
        ldy BCO,x
        lda BCCnt,x
        tax                     ; (lines)
_cl     lda (ptrA),y
_m      and #0
        sta (ptrA),y
        dex
        beq +
        iny
        cpy #8
        bne _cl
        jsr NextCellRow
        jmp _cl
+       inc v3
        dec v4
        bne _r
_done   rts

; NextCellRow: ptrA + 320 (the bitmap's next cell row), Y = 0
NextCellRow:
        lda ptrA
        clc
        adc #<320
        sta ptrA
        lda ptrA+1
        adc #>320
        sta ptrA+1
        ldy #0
        rts

; DrawBombs: Collide's runs into the bitmap ("11" the enemies' colour, "10" the ship's: that
; colour into the cells' screen bytes), each remembered to be cleared
DrawBombs:
        ldx rbuf
        lda BCBase,x
        sta v2                  ; this buffer's clear list
        lda #0
        sta v3                  ; runs drawn
        sta v4                  ; Collide's run
_br     ldx v4
        cpx BRN
        bcc +
        jmp _end
+       lda BRX,x
        lsr
        lsr
        sta v1                  ; the column
        lda BRX,x
        and #3
        tay
        lda McPixN,y
        sta tmp                 ; the pixel's mask
        lda BRC,x
        cmp #3
        beq +
        lda McPix10,y
        bne ++
+       lda McPixMask,y
+       sta tmp3                ; its bits
        lda BRLn,x
        sta tmp2                ; lines
        lda BRL,x
        sta line
        ldx v1
        jsr BmAt
        ldy line
        lda LnLo,y
        and #7
        tay                     ; (its line in the cell row)
        lda ptrA
        and #$f8
        sta ptrA                ; (the cell's first line)
        ldx v2                  ; remember it
        sta BCLo,x
        lda ptrA+1
        sta BCHi,x
        tya
        sta BCO,x
        lda tmp
        sta BCMask,x
        lda tmp2
        sta BCCnt,x
        inc v2
        inc v3
        lda tmp
        sta _dm+1
        lda tmp3
        sta _do+1
        ldx tmp2
_dl     lda (ptrA),y
_dm     and #0
_do     ora #0
        sta (ptrA),y
        dex
        beq +
        iny
        cpy #8
        bne _dl
        jsr NextCellRow
        jmp _dl
+       ldx v4                  ; "10": the ship's colour in the cells' screen bytes
        lda BRC,x
        cmp #3
        beq _nx
        lda BRLn,x
        sta tmp2
        lda BRL,x
        tay
        lda CellLo,y
        clc
        adc v1
        sta ptrB
        lda CellHi,y
        adc scrHi
        sta ptrB+1
        lda LnLo,y
        and #7
        clc
        adc tmp2                ; (cells: (o + lines + 7) / 8)
        adc #7
        lsr
        lsr
        lsr
        tax
-       ldy #0
        lda (ptrB),y
        and #$f0
        ora cShip
        sta (ptrB),y
        dex
        beq _nx
        lda ptrB
        clc
        adc #40
        sta ptrB
        bcc -
        inc ptrB+1
        bne -
_nx     inc v4
        jmp _br
_end    ldx rbuf
        lda v3
        sta BCN,x
        rts

; ------------------------------------------------------------------ the middle row
; Three-row waves: the middle row of enemies drawn into the bitmap ("11"): each copy 8 pixels
; at its pixel, 3 bytes (shifted 0-3 pixels; all copies alike) a line on 8 lines. The stores are
; code, by buffer (R1CodeA: the lines in the first cell row, R1CodeB: the next): each byte loaded
; once and stored to its column in each window (then a jump past the slots not used); the targets
; patched when the row's line or windows change (a column in the comb: stored to a dummy). The
; columns windows leave are cleared. Columns 0-1 are never written.
R1DUMMY     = $0340     ; (the cassette buffer: a place for stores that mustn't show)
Row1:
        lda #0                  ; the copies' columns (distinct), the shift
        sta R1N
        sta v4                  ; (player 0: no copies to check against)
        lda RowCopies+1
        lsr
        lsr
        lsr
        lsr
        beq +
        lda RowX0+1
        ldx RowN0+1
        jsr R1Copies
        lda R1N                 ; (player 1's checked against player 0's)
        sta v4
+       lda RowCopies+1
        and #7
        beq +
        lda RowX1+1
        ldx RowN1+1
        jsr R1Copies
+       ; the shape's rows 8-1, shifted: from the pages for R1Shift (ptrB-ptrD; InitTables)
        ldx R1Shift
        lda #0
        sta ptrB
        sta ptrC
        sta ptrD
        lda ShPg0,x
        sta ptrB+1
        lda ShPg1,x
        sta ptrC+1
        lda ShPg2,x
        sta ptrD+1
        ldy #8
        lda (ShapePtr),y
        tay
        lda (ptrB),y
        sta R1B0+0
        lda (ptrC),y
        sta R1B1+0
        lda (ptrD),y
        sta R1B2+0
        ldy #7
        lda (ShapePtr),y
        tay
        lda (ptrB),y
        sta R1B0+1
        lda (ptrC),y
        sta R1B1+1
        lda (ptrD),y
        sta R1B2+1
        ldy #6
        lda (ShapePtr),y
        tay
        lda (ptrB),y
        sta R1B0+2
        lda (ptrC),y
        sta R1B1+2
        lda (ptrD),y
        sta R1B2+2
        ldy #5
        lda (ShapePtr),y
        tay
        lda (ptrB),y
        sta R1B0+3
        lda (ptrC),y
        sta R1B1+3
        lda (ptrD),y
        sta R1B2+3
        ldy #4
        lda (ShapePtr),y
        tay
        lda (ptrB),y
        sta R1B0+4
        lda (ptrC),y
        sta R1B1+4
        lda (ptrD),y
        sta R1B2+4
        ldy #3
        lda (ShapePtr),y
        tay
        lda (ptrB),y
        sta R1B0+5
        lda (ptrC),y
        sta R1B1+5
        lda (ptrD),y
        sta R1B2+5
        ldy #2
        lda (ShapePtr),y
        tay
        lda (ptrB),y
        sta R1B0+6
        lda (ptrC),y
        sta R1B1+6
        lda (ptrD),y
        sta R1B2+6
        ldy #1
        lda (ShapePtr),y
        tay
        lda (ptrB),y
        sta R1B0+7
        lda (ptrC),y
        sta R1B1+7
        lda (ptrD),y
        sta R1B2+7
        ; this buffer's line and windows: the same, only the stores; each window a column at
        ; most from where it was (the same count), the columns they leave cleared and their
        ; code patched. A new line in the same cell row: the code's targets hold (Y is the line in
        ; the cell row): the old row cleared (its code run with zeros), the windows moved patched.
        ; Else all it had cleared, all patched
        ldx rbuf
        lda R1Base,x
        sta v5b
        lda #0
        sta r1noclr
        lda R1Line,x
        cmp #$ff
        bne +
        jmp _all                ; (nothing drawn)
+       cmp RowL+1
        beq _line
        clc                     ; a new line: the old row cleared
        adc #5
        tay
        lda LnLo,y
        and #$f8
        sta tmp
        lda LnHi,y
        sta tmp2
        ldx rbuf
        lda R1Line,x
        ldx #8
        jsr R1Exec
        lda RowL+1              ; (the same cell row?)
        clc
        adc #5
        tay
        lda LnLo,y
        and #$f8
        cmp tmp
        bne _all
        lda LnHi,y
        cmp tmp2
        bne _all
        inc r1noclr
        ldx rbuf
        lda RowL+1
        sta R1Line,x
_line   ldx rbuf
        lda R1NB,x
        cmp R1N
        bne _zero
        ldx v5b
        ldy #0
        sty v4                  ; windows moved
-       cpy R1N
        bcs _moved
        lda R1New,y
        sec
        sbc R1C,x
        beq _same
        inc v4
        cmp #1
        beq _same
        cmp #$ff
        beq _same
        cmp #39                 ; (across the wrap)
        beq _same
        cmp #<-39
        bne _zero
_same   inx
        iny
        bne -
_moved  lda v4
        beq +
        jsr R1Moved
+       jmp _run
_zero   lda r1noclr             ; the old windows cleared (unless they were): their code run
        bne _all                ; from the zero rows
        ldx rbuf
        lda R1Line,x
        ldx #8
        jsr R1Exec
_all    ldx rbuf                ; remember the new ones; the code's targets
        lda RowL+1
        sta R1Line,x
        lda R1N
        sta R1NB,x
        ldx v5b
        ldy #0
-       lda #$ff
        cpy R1N
        bcs +
        lda R1New,y
+       sta R1C,x
        inx
        iny
        cpy #5
        bne -
        jsr R1Patch
_run    lda RowL+1              ; the stores: the shape's rows
        ldx #0
        jmp R1Exec

; R1Moved: Row1's windows each moved a column at most (v4 of them): the columns they leave
; cleared, their code patched, remembered
R1Moved:
        jsr R1PSetup
        jsr R1Tab               ; (the table, or the targets worked out: r1direct)
        lda RowL+1              ; (the first line's place in its cell row)
        clc
        adc #5
        tay
        lda LnLo,y
        and #7
        sta r1y0
        ldy #0
_mw     sty v2
        tya
        clc
        adc v5b
        tax
        lda R1New,y
        sec
        sbc R1C,x
        beq _mn
        cmp #1
        beq _right
        cmp #<-39
        beq _right
        lda R1C,x               ; moved left: its old last column left behind
        clc
        adc #2
        cmp #40
        bcc _lv
        sbc #40
        bcs _lv
_right  lda R1C,x               ; moved right: its old first column
_lv     ldx r1noclr             ; (the old row all cleared already: none)
        bne +
        cmp #2
        bcc +
        ldx r1direct            ; (no table: from the line)
        beq _ct
        tax
        lda RowL+1
        clc
        adc #5
        jsr ColClear
        jmp +
_ct     clc                     ; (this buffer's table)
        adc v0
        tax
        jsr ColClearT
+       ldx v2
        lda r1direct
        bne _dir
        jsr R1PWin
        jmp _pw
_dir    jsr R1PWinD
_pw     ldy v2
        tya
        clc
        adc v5b
        tax
        lda R1New,y
        sta R1C,x
_mn     ldy v2
        iny
        cpy R1N
        bcc _mw
        rts

; R1Exec: this buffer's store code run for the row at line A, from row X of R1B0-R1B2 (0: the
; shape's, 8: zeros): Y the line in the cell row (block A, then B; each loops over its lines)
R1Exec:
        stx tmp4
        clc
        adc #5
        tay
        lda LnLo,y
        and #7
        tay
        txa
        clc
        adc #8
        sta tmp3                ; (the end)
        ldx rbuf
        lda R1CodeLo,x
        sta _ja+1
        lda R1CodeHi,x
        sta _ja+2
        lda R1CodeBLo,x
        sta _jb+1
        lda R1CodeBHi,x
        sta _jb+2
        ldx tmp4
_ja     jsr $0000               ; (block A loops to its cell row's last line,
        cpx tmp3
        beq _done
        ldy #0
_jb     jsr $0000               ; block B to row tmp3)
_done   rts

; R1PSetup: for patching this buffer's store code: ptrC / ptrD its blocks; v0 its column
; address table's start; r1bLo / r1bHi the row's first line's cell row in the bitmap
R1PSetup:
        ldx rbuf
        lda R1CodeLo,x
        sta ptrC
        lda R1CodeHi,x
        sta ptrC+1
        lda R1CodeBLo,x
        sta ptrD
        lda R1CodeBHi,x
        sta ptrD+1
        lda R1TBase,x
        sta v0
        lda RowL+1
        clc
        adc #5
        tay
        lda LnLo,y
        and #$f8
        sta r1bLo
        lda LnHi,y
        clc
        adc bmHi
        sta r1bHi
        rts

; R1Tab: this buffer's column address table for the row's cell row (R1PSetup), made again when
; it was made for another, but only the fourth time running in that cell row (the row moving
; up and down: till then r1direct, the targets worked out)
R1Tab:
        lda #0
        sta r1direct
        ldx rbuf
        lda r1bHi
        cmp R1TLine,x
        bne +
        lda r1bLo
        cmp R1TLo,x
        bne +
        rts
+       lda r1bHi               ; (the fourth time in a row?)
        cmp R1TSeenH,x
        bne +
        lda r1bLo
        cmp R1TSeenL,x
        bne +
        inc R1TSeenN,x
        lda R1TSeenN,x
        cmp #4
        bcs ++
        inc r1direct
        rts
+       lda r1bHi
        sta R1TSeenH,x
        lda r1bLo
        sta R1TSeenL,x
        lda #1
        sta R1TSeenN,x
        inc r1direct
        rts
+       lda r1bLo
        sta R1TLo,x
        lda r1bHi
        sta R1TLine,x
        ldx #0                  ; columns 0-41 (40, 41: 0, 1): block A's byte, block B's (a cell
        ldy v0                  ; row down); the comb's: the dummy
-       txa
        cmp #40
        bcc +
        sbc #40
+       cmp #2
        bcs +
        lda #<R1DUMMY
        sta CALo,y
        sta CBLo,y
        lda #>R1DUMMY
        sta CAHi,y
        sta CBHi,y
        bne _nx
+       stx tmp3
        tax
        lda r1bLo
        clc
        adc Col8Lo,x
        sta CALo,y
        lda r1bHi
        adc Col8Hi,x
        sta CAHi,y
        lda CALo,y
        clc
        adc #<320
        sta CBLo,y
        lda CAHi,y
        adc #>320
        sta CBHi,y
        ldx tmp3
_nx     iny
        inx
        cpx #42
        bne -
_done   rts

; R1PWinD: window X's 3 stores' targets worked out (not from the table: a full patch)
R1PWinD:
        ldy WinOfs,x
        iny                     ; (the target: after the opcode)
        lda R1New,x
        sta v3
        lda #3
        sta v4
_pe     lda v3
        cmp #40
        bcc +
        sbc #40
+       cmp #2
        bcc _dum
        tax
        lda r1bLo
        clc
        adc Col8Lo,x
        sta (ptrC),y
        sta tmp
        lda r1bHi
        adc Col8Hi,x
        sta tmp2
        lda tmp
        clc
        adc #<320
        sta (ptrD),y
        iny
        lda tmp2
        sta (ptrC),y
        adc #>320
        sta (ptrD),y
        jmp _pn
_dum    lda #<R1DUMMY
        sta (ptrC),y
        sta (ptrD),y
        iny
        lda #>R1DUMMY
        sta (ptrC),y
        sta (ptrD),y
_pn     tya                     ; (the next byte's slot: 18 on)
        clc
        adc #17
        tay
        inc v3
        dec v4
        bne _pe
        rts

; R1Patch: this buffer's store code: each window's stores (R1PWin); after the last, a jump to the
; next byte's load (R1PJmp)
R1Patch:
        jsr R1PSetup
        ldx #0
-       stx v2
        cpx R1N
        bcs +
        jsr R1PSta
        ldx v2
        jsr R1PWinD
        ldx v2
        inx
        cpx #5
        bne -
        rts
+       jmp R1PJmp

; The store code (by buffer, block A and B): for each of the shape's 3 bytes k, "lda R1Bk,x"
; and 5 slots, one a window, "sta <its column k's byte>,y" (slot 18k + 3w + 3), the first not
; used "jmp <the next byte's load>"; then rts.
; R1PWin: window X's 3 stores' targets (R1New): its columns' bytes from the table (R1PSetup);
; the slots must be stores already (R1PSta)
R1PWin:
        ldy WinOfs,x
        iny                     ; (the target: after the opcode)
        lda R1New,x
        clc
        adc v0
        tax
        lda CALo+0,x
        sta (ptrC),y
        lda CBLo+0,x
        sta (ptrD),y
        iny
        lda CAHi+0,x
        sta (ptrC),y
        lda CBHi+0,x
        sta (ptrD),y
        tya                     ; (the next byte's slot: 18 on)
        clc
        adc #17
        tay
        lda CALo+1,x
        sta (ptrC),y
        lda CBLo+1,x
        sta (ptrD),y
        iny
        lda CAHi+1,x
        sta (ptrC),y
        lda CBHi+1,x
        sta (ptrD),y
        tya                     ; (the next byte's slot: 18 on)
        clc
        adc #17
        tay
        lda CALo+2,x
        sta (ptrC),y
        lda CBLo+2,x
        sta (ptrD),y
        iny
        lda CAHi+2,x
        sta (ptrC),y
        lda CBHi+2,x
        sta (ptrD),y
        rts

; R1PSta: window X's 3 slots made stores ("sta abs,y": one may have been a jump)
R1PSta:
        ldy WinOfs,x
        lda #$99
        sta (ptrC),y
        sta (ptrD),y
        ldy WinOfs+5,x
        sta (ptrC),y
        sta (ptrD),y
        ldy WinOfs+10,x
        sta (ptrC),y
        sta (ptrD),y
        rts

; R1PJmp: window X's slots (the first not used) jumps to the next byte's load (the last: rts)
R1PJmp:
        lda WinOfs,x
        tay
        lda #18
        sta v4                  ; (the next byte's load: 18 (k + 1) on)
_pj     lda #$4c
        sta (ptrC),y
        sta (ptrD),y
        iny
        lda ptrC
        clc
        adc v4
        sta (ptrC),y
        lda ptrC+1
        adc #0
        sta tmp
        lda ptrD
        clc
        adc v4
        sta (ptrD),y
        lda ptrD+1
        adc #0
        iny
        sta (ptrD),y
        lda tmp
        sta (ptrC),y
        tya
        clc
        adc #16
        tay
        lda v4
        clc
        adc #18
        sta v4
        cmp #18 * 4
        bne _pj
        rts
WinOfs:     .byte 3, 6, 9, 12, 15   ; (window w's slot for byte k: 18k + 3w + 3)
            .byte 21, 24, 27, 30, 33
            .byte 39, 42, 45, 48, 51

; ColClearT: the middle row's column (X: its column address table index) cleared: from r1y0 in
; its first cell row, to r1y0 - 1 in the next
ColClearT:
        lda CALo,x
        sta ptrA
        lda CAHi,x
        sta ptrA+1
        lda CBLo,x
        sta ptrB
        lda CBHi,x
        sta ptrB+1
        ldy r1y0
        lda #0
-       sta (ptrA),y
        iny
        cpy #8
        bne -
        ldy r1y0
        beq +
        dey
-       sta (ptrB),y
        dey
        bpl -
+       rts

; ColClear: column X of the middle row cleared on lines A .. A + 7
ColClear:
        sta line
        jsr BmAt
        ldy line
        lda LnLo,y
        and #7
        tay
        lda ptrA
        and #$f8
        sta ptrA
        ldx #8
-       lda #0
        sta (ptrA),y
        dex
        beq +
        iny
        cpy #8
        bne -
        jsr NextCellRow
        jmp -
+       rts

; R1Copies: a player's copies (pixel A, NUSIZ X) into R1New (distinct columns: not one of the
; v4 before), R1Shift
R1Copies:
        sta v0
        and #3
        sta R1Shift
        txa
        and #7
        tax
        lda CopyFirst+1,x
        sta cpe
        ldy CopyFirst,x
_c      cpy cpe
        bcs _done
        lda CopyOff,y
        iny
        clc
        adc v0
        cmp #160
        bcc +
        sbc #160
+       lsr
        lsr                     ; the column
        ldx v4                  ; (already there?)
        beq _new
-       cmp R1New-1,x
        beq _c
        dex
        bne -
_new    ldx R1N
        cpx #5
        bcs _c
        sta R1New,x
        inc R1N
        bne _c
_done   rts

; ClearRow1: six-row waves: the middle row this buffer had, cleared
ClearRow1:
        ldx rbuf
        lda R1Line,x
        cmp #$ff
        beq _done
        sta v4
        lda #$ff
        sta R1Line,x
        lda #0
        sta R1NB,x
        lda R1Base,x
        sta v2
        lda #5                  ; (all 5 windows' places: unused ones are $FF)
        sta v3
_ow     ldx v2
        lda R1C,x
        cmp #$ff
        beq _nw
        sta v1
        lda #$ff
        sta R1C,x
        lda #3
        sta v0
_oc     lda v1
        cmp #40
        bcc +
        sbc #40
        sta v1
+       cmp #2
        bcc +
        lda v4
        clc
        adc #5
        ldx v1
        jsr ColClear
+       inc v1
        dec v0
        bne _oc
_nw     inc v2
        dec v3
        bne _ow
_done   rts

; ------------------------------------------------------------------ sprites
; SprX: sprite X for 2600 pixel A: tmp (low byte), carry (bit 8); X and Y kept
SprX:
        sty sprY
        tay
        lda SprXLo,y
        sta tmp
        lda SprXHi,y
        ldy sprY
        lsr                     ; carry: bit 8
        rts

; SpritesA: three-row waves: the top row's enemies on sprites 0-4 (and from the move between,
; the bottom row's), the ship (5), the laser (6)
SpritesA:
        ldx #0                  ; the top row (k = 0): the frame top's values
        jsr RowSprites
        ldx v5
        lda RowL
        clc
        adc #5 + SPRYOFS
        .for i := 0, i < 5, i += 1
        sta StY+i,x
        .endfor
        .for i := 0, i < 5, i += 1
        lda RSX+i
        sta StX+i,x
        .endfor
        lda RSMsb
        sta FrMsb
        lda RSEn
        sta FrEn
        ldx #2                  ; the bottom row (k = 2): the move's values
        jsr RowSprites
        ldx rbuf
        lda MvBaseOf,x
        tax
        lda RSMsb
        sta MvMsb,x
        lda RSEn
        sta MvEn,x
        lda RowL+2
        clc
        adc #5 + SPRYOFS
        sta MvY,x
        lda #0
        sta MvPtr,x
        txa
        sta tmp
        asl
        asl
        adc tmp
        tax
        .for i := 0, i < 5, i += 1
        lda RSX+i
        sta MvX+i,x
        .endfor
        ; the image (the shape's rows 8-1), when the shape changed
        ldx rbuf
        lda ShapePtr
        cmp KShape,x
        bne +
        lda ShapePtr+1
        cmp KShape+NBUF,x
        beq _img
+       lda ShapePtr
        sta KShape,x
        lda ShapePtr+1
        sta KShape+NBUF,x
        lda #BLK_ROWA
        jsr BlkAt
        ldx #0
        ldy #8
-       lda (ShapePtr),y
        sta ShapeTmp,x
        inx
        dey
        bne -
        ldx #0
        ldy #0
-       lda ShapeTmp,x
        sta (ptrB),y
        iny
        iny
        iny
        inx
        cpx #8
        bne -
_img    lda #169 + SPRYOFS      ; the ship (lines 169-189)
        jsr ShipSprite
        jsr LaserSprite
        jsr BombSprA
        ; pointers (this buffer's screen): 0-4 the rows' image, 5 the ship, 6 a bomb, 7 the laser
        lda #$f8
        sta ptrA
        lda scrHi
        ora #3
        sta ptrA+1
        lda #BLK_ROWA
        ldx rbuf
        sta StPtr,x
        ldy #4
-       sta (ptrA),y
        dey
        bpl -
        lda #BLK_SHIPA
        ldy #5
        sta (ptrA),y
        lda #BLK_BOMB
        iny
        sta (ptrA),y
        lda #BLK_LASER
        iny
        sta (ptrA),y
        jmp Finish

; RowSprites: a three-row wave's row k (X) on sprites 0-4: RSX (X low bytes), RSMsb, RSEn
RowSprites:
        lda #0
        sta R1N
        sta RSMsb
        sta v4                  ; (player 0: no copies to check against)
        stx v3
        lda #2                  ; (the game's row: 2 - k)
        sec
        sbc v3
        tay
        lda RowCopies,y
        sta v2
        lsr
        lsr
        lsr
        lsr
        beq +
        lda RowX0,x
        sta v0
        lda RowN0,x
        jsr RSCopies
        lda R1N                 ; (player 1's copies checked against player 0's)
        sta v4
+       lda v2
        and #7
        beq +
        ldx v3
        lda RowX1,x
        sta v0
        lda RowN1,x
        jsr RSCopies
+       ldx R1N                 ; the sprites used: on
        lda EnMask,x
        sta RSEn
        rts
EnMask:     .byte 0, 1, 3, 7, 15, 31

; RSCopies: a player's copies (pixel v0, NUSIZ A) onto the next free sprites (distinct pixels:
; not on one of the v4 copies before)
RSCopies:
        and #7
        tax
        lda CopyFirst+1,x
        sta cpe
        ldy CopyFirst,x
_c      cpy cpe
        bcs _done
        lda CopyOff,y
        iny
        clc
        adc v0
        cmp #160
        bcc +
        sbc #160
+       ldx v4                  ; (already there: the other player's copy on the same pixel)
        beq _new
-       cmp R1New-1,x
        beq _c
        dex
        bne -
_new    ldx R1N
        cpx #5
        bcs _c
        sta R1New,x
        sty cpi
        tay
        lda SprXLo,y
        sta RSX,x
        lda SprXHi,y
        beq +
        lda Bit,x
        ora RSMsb
        sta RSMsb
+       inc R1N
        ldy cpi
        jmp _c
_done   rts

; ShipSprite: the ship (sprite 5), its first line's sprite Y in A
ShipSprite:
        ldx v5
        sta StY+5,x
        lda ShipX
        jsr SprX
        lda tmp
        sta StX+5,x
        bcc +
        lda FrMsb
        ora #$20
        sta FrMsb
+       lda FrEn
        ora #$20
        sta FrEn
        rts

; LaserSprite: the laser (sprite 7): its lines from Collide, one pixel wide
LaserSprite:
        lda LsrOn
        cmp #$ff
        bne +
        rts
+       ldx v5
        clc
        adc #SPRYOFS
        sta StY+7,x
        lda bx
        jsr SprX
        lda tmp
        sta StX+7,x
        bcc +
        lda FrMsb
        ora #$80
        sta FrMsb
+       lda FrEn
        ora #$80
        sta FrEn
        lda LsrOff              ; the image: rows 0 .. LsrOff - LsrOn - 1 (21 at most)
        sec
        sbc LsrOn
        cmp #22
        bcc +
        lda #21
+       sta tmp3
        ldx rbuf
        ldy KLsr,x
        cmp KLsr,x
        beq _off
        sta KLsr,x
        lda #BLK_LASER
        jmp LenImg
_off    rts

; BombSprA: three-row waves: the bomb Collide put on sprite 6 (BSprN: one), else none
BombSprA:
        lda BSprN
        bne +
        rts
+       ldx v5
        lda BSprL
        clc
        adc #SPRYOFS
        sta StY+6,x
        lda BSprX
        jsr SprX
        lda tmp
        sta StX+6,x
        bcc +
        lda FrMsb
        ora #$40
        sta FrMsb
+       lda FrEn
        ora #$40
        sta FrEn
        lda BSprLn
        cmp #22
        bcc +
        lda #21
+       sta tmp3
        ldx rbuf
        ldy KBomb,x
        cmp KBomb,x
        beq _off
        sta KBomb,x
        lda #BLK_BOMB
        jmp LenImg
_off    rts

; LenImg: sprite block A's image a line one pixel wide, rows 0 .. tmp3 - 1 (Y: the rows it has,
; 22 or more: unknown): only the rows between written
LenImg:
        jsr BlkAt
        cpy #22
        bcc _part
        ldx #0                  ; (none made yet: all 21 rows)
        ldy #0
-       lda #0
        cpx tmp3
        bcs +
        lda #$80
+       sta (ptrB),y
        iny
        iny
        iny
        inx
        cpx #21
        bne -
        rts
_part   sty tmp4                ; longer: rows old .. new - 1 set
        ldx tmp4
        lda #$80
        cpy tmp3
        bcc +
        ldx tmp3                ; shorter: rows new .. old - 1 cleared
        sty tmp3
        lda #0
+       sta v0
        stx tmp
        txa
        asl
        adc tmp
        tay                     ; (3 bytes a row)
        lda v0
-       sta (ptrB),y
        iny
        iny
        iny
        inx
        cpx tmp3
        bcc -
        rts

; ImgRows: sprite block A: rows 0 .. X - 1 the shape's (RowImg), rows X .. 13 blank
ImgRows:
        stx tmp3
        jsr BlkAt
        ldx #0
        ldy #0
-       lda #0
        cpx tmp3
        bcs +
        lda RowImg,x
+       sta (ptrB),y
        iny
        iny
        iny
        inx
        cpx #14
        bne -
        rts

; BlkAt: ptrB = sprite block A in this buffer's bank
BlkAt:
        sec
        sbc #BLK0
        sta ptrB
        lsr                     ; (64 bytes a block)
        lsr
        clc
        adc sprHi
        sta ptrB+1
        lda ptrB
        clc
        ror
        ror
        ror
        and #$c0
        sta ptrB
        rts

; Finish: the frame top's enables and MSBs, the event list
Finish:
        ldx rbuf
        lda FrMsb
        sta StMsb,x
        lda FrEn
        sta StEn,x
        lda EvBaseOf,x
        tax
        lda #EV_TOP             ; the frame top
        sta EvType,x
        lda #TOPRASTER
        sta EvLine,x
        inx
        lda IsModeB
        bne _b
        lda #EV_MOVEA           ; three-row waves: the move, after the top row's last line
        sta EvType,x
        lda RowL
        clc
        adc #14 + LINEOFS
        sta EvLine,x
        ldy rbuf
        lda MvBaseOf,y
        sta EvArg,x
        inx
        jmp _end
_b      ldy #0                  ; six-row waves: a move for each row after the first
-       cpy NGroups
        bcs _end
        lda #EV_MOVEB
        sta EvType,x
        lda GrpLine,y
        sta EvLine,x
        stx tmp
        ldx rbuf
        tya
        clc
        adc MvBaseOf,x
        ldx tmp
        sta EvArg,x
        inx
        iny
        bne -
_end    lda #EV_END
        sta EvType,x
        lda #ENDRASTER
        sta EvLine,x
        rts
