; ================================================================ collide
; What the 2600's kernel would have seen and left behind, worked out from the RAM it starts
; from (the rules: tools/c64ref.js, checked against tools/model.js and tools/vcs.js):
;   - $E9 / $EA: the row the laser hit (player 0 / player 1), + 1; $EB: the ship hit (a bomb, or
;     in six-row waves an enemy); $DA counted down; the kernel's scratch bytes ($A2-$A7, $CF)
;   - for Render: the laser's lines, the bombs' pixels (three-row waves: drawn into the bitmap,
;     copies included) or lines (six-row waves: a sprite), the rows' places
;
; The kernel tests a counter X on each line: the laser shows where X - $F9 is 0-7, bomb 0 where
; X - $EC is, bomb 1 where X - $ED is. Where a line writes the register, X falls one a line,
; in runs ("segments": first line, last line, and c: X = c - line); between them the register
; holds. So the lines a register is on are found from two values: the first line written with
; X at most the top of the range (it comes on), the first written with X below it (it goes off).

Collide:
        ldx LaserX              ; the pixels the vertical blank put the laser and the bombs at
        lda MissilePos,x
        sta bx
        ldx Bomb0X
        lda MissilePos,x
        sta m0x
        ldx Bomb1X
        lda MissilePos,x
        sta m1x
        lda $d6                 ; (the ship's pixel: its X)
        sta ShipX
        lda #0
        sta BRN
        sta BSprN               ; (three-row waves: no bomb on a sprite yet)
        sta cx                  ; bit 0: bomb 0 on player 1, 1: bomb 1 on player 1, 2: P0-P1
        lda #$ff
        sta M1Top
        lda GameOver            ; (the logo's line: from $DA before the kernel counts it down)
        lsr
        lsr
        lsr
        ldy #$0f
        cmp #$14
        bcs +
        ldy #7
        cmp #$0c
        bcc +
        sbc #4
        tay
+       sty LogoY0
        lda Wave
        lsr
        bcc ModeA
        jmp ModeB

; ------------------------------------------------------------------ three rows
ModeA:
        lda #0
        sta IsModeB
        lda FormTop             ; the rows start at line 188 - $A1 (the search runs a line at
        cmp #$90                ; least: $A1 at most $8F)
        bcc +
        lda #$8f
+       sta A1c
        lda #188
        sec
        sbc A1c
        sta L2
        clc
        adc #42
        sta LA
        ; the rows (k = 0 the top, the game's row 2): line, positions, copies, colours (a player
        ; with no enemies left: the ship's colour, at pixel 0, hidden by the comb; its bomb shows
        ; in that colour)
        .for k := 0, k < 3, k += 1
        lda L2
        clc
        adc #14 * k
        sta RowL + k
        ldx RowPos0 + 2 - k
        lda XOf,x
        sta RowX0 + k
        ldx RowPos1 + 2 - k
        lda XOf,x
        sta RowX1 + k
        lda RowCopies + 2 - k
        lsr
        lsr
        lsr
        lsr
        tax
        lda T_NUSIZ,x
        sta RowN0 + k
        lda ColEnemy
        cpx #0
        bne +
        lda ColShip
+       sta RowC0 + k
        lda RowCopies + 2 - k
        and #7
        tax
        lda T_NUSIZ,x
        sta RowN1 + k
        lda ColEnemy
        cpx #0
        bne +
        lda ColShip
+       sta RowC1 + k
        .endfor

        ; the laser: written on the lines before the rows (X = 186 - line), the rows' drawing
        ; lines (X one behind: 187 + k - line), the lines after them (190 - line); 0 from 169
        lda #44                 ; (as AddSeg would: lines 44 .. L2 - 1, X = 186 - line)
        sta SegS
        lda #186
        sta SegC
        lda #186 - 44
        sta SegXS
        ldx L2
        dex
        stx SegE
        lda #186
        sec
        sbc SegE
        sta SegXE
        ldx #2                  ; the rows: lines L+5 .. L+13, X = 187 + k - line
-       lda RowL,x
        clc
        adc #5
        sta SegS+1,x
        adc #8
        sta SegE+1,x
        txa
        adc #187
        sta SegC+1,x
        sec
        sbc SegS+1,x
        sta SegXS+1,x
        lda SegC+1,x
        sbc SegE+1,x
        sta SegXE+1,x
        dex
        bpl -
        ldx #4                  ; after them: LA + 1 .. 166, X = 190 - line (if any)
        lda LA
        clc
        adc #1
        cmp #167
        bcs +
        sta SegS+4
        lda #166
        sta SegE+4
        lda #190
        sta SegC+4
        sec
        sbc SegS+4
        sta SegXS+4
        lda #190 - 166
        sta SegXE+4
        ldx #5
+       stx NSeg
        lda #169
        sta forced
        ldx #0                  ; (its range below the rows' X all through them, and segment 4
        lda LaserY              ; there: from it)
        clc
        adc #7
        bcs +
        cmp SegXE+3
        bcs +
        lda NSeg
        cmp #5
        bcc +
        ldx #4
+       stx SegFrom
        lda LaserY
        jsr Run
        lda #0
        sta SegFrom
        lda lon
        sta LsrOn
        lda loff
        sta LsrOff

        ; the rows' reads, top first: player 0 / 1 against the laser by the end of each row (the
        ; laser's pixel's place in each player's copies is the row's: worked out once)
        lda #0
        sta lat                 ; bit 0: P0-ball latched, bit 1: P1-ball
        ldx #0
_rr     stx tmp4
        lda RowL,x              ; lines L+5 .. L+12 (L+13: the shape's last row, blank), where
        clc                     ; the laser is: from max(L+5, LsrOn)
        adc #5
        cmp LsrOn
        bcs +
        lda LsrOn
+       sta line
        lda RowL,x
        clc
        adc #13
        sta v2                  ; (the row's line L + 13)
        cmp line                ; (none: the row done)
        beq _rd
        bcc _rd
        lda line
        cmp LsrOff
        bcs _rd
        lda RowX0,x             ; the places ($FF: neither player has the pixel: done)
        sta v0
        lda RowN0,x
        sta v1
        lda bx
        jsr PlaceOf
        sta pl0
        ldx tmp4
        lda RowX1,x
        sta v0
        lda RowN1,x
        sta v1
        lda bx
        jsr PlaceOf
        sta pl1
        and pl0
        bmi _rd
_rl     lda v2
        cmp line
        beq _rd
        bcc _rd
        lda line
        cmp LsrOff
        bcs _rd
        lda lat                 ; (both latched: nothing more to find)
        cmp #3
        beq _rd
        lda v2                  ; the shape's row: L + 13 - line
        sec
        sbc line
        tay
        lda (ShapePtr),y
        beq _rn
        sta gbits
        ldx pl0
        bmi +
        and BitL,x
        beq +
        lda lat
        ora #1
        sta lat
+       ldx pl1
        bmi _rn
        lda gbits
        and BitL,x
        beq _rn
        lda lat
        ora #2
        sta lat
_rn     inc line
        jmp _rl
_rd     lda #2                  ; (the row's number to the game: 2 - k)
        sec
        sbc tmp4
        tay
        lda lat
        lsr
        bcs +
        sty HitRow0
+       lsr
        bcs +
        sty HitRow0+1
+       ldx tmp4
        inx
        cpx #3
        beq +
        jmp _rr
+       lda lat                 ; (F48C: no P0-ball at all, $E9 = 0)
        lsr
        bcs +
        lda #0
        sta HitRow0
+
        ; the bombs: bomb 1 first (bomb 0 is drawn over it)
        lda #1
        sta which
        jsr BombA
        lda #0
        sta which
        jsr BombA

        ; the kernel's scratch bytes
        lda #0
        sta $cf
        lda A1c
        sec
        sbc #27
        sta $a5
        lda RowCopies
        and #7
        sta $a6
        lda RowCopies
        lsr
        lsr
        lsr
        lsr
        sta $a7
        jmp Common

; AddSeg: a segment, lines A to X, X = Y - line (left out if empty: A > X)
AddSeg:
        stx tmp3
        cmp tmp3
        beq +
        bcs _no
+       ldx NSeg
        sta SegS,x
        pha
        tya
        sta SegC,x
        pla
        eor #$ff                ; (X on the first line: Y - A, on the last: Y - X)
        sec
        adc SegC,x
        sta SegXS,x
        lda tmp3
        sta SegE,x
        eor #$ff
        sec
        adc SegC,x
        sta SegXE,x
        inc NSeg
_no     rts

; FirstLE: the first line (in the segments' order) written with X at most A; A = the line
; ($FF: none), tmp = its X
FirstLE:
        sta tmp2
        ldx SegFrom
-       cpx NSeg
        bcs _none
        lda SegXS,x             ; X on the segment's first line
        cmp tmp2
        beq _first
        bcc _first
        lda SegXE,x             ; ... on its last
        cmp tmp2
        beq _mid
        bcc _mid
        inx
        bne -
_first  sta tmp
        lda SegS,x
        rts
_mid    lda tmp2                ; the line where X = A
        sta tmp
        lda SegC,x
        sec
        sbc tmp2
        rts
_none   lda #$ff
        rts

; Run: the lines a register is on for the range A .. A + 7 (the segments set up, with their
; first and last lines' X): lon, the first; loff, the first off again (at most `forced`); lon =
; loff = $FF if never on. (The kernel's test is 8 bits: from $F9 the range wraps to
; 0 .. A + 7 - 256, a bomb's bottom lines.)
Run:
        sta vlo
        clc
        adc #7
        sta vhi
        bcc +
        lda #0                  ; (wrapped: 0 .. A + 7 - 256)
        sta vlo
+       lda vhi
        jsr FirstLE
        cmp #$ff
        beq _never
        sta lon
        lda tmp                 ; (that line's X in the range? the range may fall between)
        cmp vlo
        bcc _never
        lda forced
        sta loff
        lda vlo
        beq +                   ; (range 0-7: off only where forced)
        sec
        sbc #1
        jsr FirstLE
        cmp loff
        bcs +
        sta loff
+       rts
_never  lda #$ff
        sta lon
        sta loff
        rts

; PHas: does a player (shape gbits, at pixel v0, NUSIZ v1: 0, 2, 4 or 6) draw pixel A?
; (Z clear: yes)
PHas:
        sec
        sbc v0
        bcs +
        adc #160
+       tay
        lda v1
        and #6
        tax
        lda CopyTabLo,x
        sta ptrD
        lda CopyTabHi,x
        sta ptrD+1
        lda (ptrD),y            ; the pixel's place in the copy shown there, or $FF
        bmi _no
        tax
        lda gbits
        and BitL,x
        rts
_no     lda #0
        rts

; PlaceOf: pixel A's place in a player at pixel v0, NUSIZ v1 (the bit of its shape byte, 0-7),
; or $FF (in none of its copies)
PlaceOf:
        sec
        sbc v0
        bcs +
        adc #160
+       tay
        lda v1
        and #6
        tax
        lda CopyTabLo,x
        sta ptrD
        lda CopyTabHi,x
        sta ptrD+1
        lda (ptrD),y            ; the pixel's place in the copy shown there, or $FF
        rts

; LaserAt: the laser shown on `line`? (Z clear: yes)
LaserAt:
        lda line
        cmp LsrOn
        bcc _no
        cmp LsrOff
        bcs _no
        lda #1
        rts
_no     lda #0
        rts

; BombA: a bomb in a three-row wave (which = 0 / 1): the lines it is on, the pixels it shows
; (its copies) as runs of lines, whether it touches player 1. New runs start where something
; changes (its first line, its last, a row's NUSIZ or colour, the rows' end, a line where bomb
; 1 may hide behind player 0); between, the runs go on a line at a time.
BombA:
        ldx which               ; (from X 143 to $F8 a bomb never shows: none drawn, none touches)
        lda Bomb0Y,x
        cmp #$8f
        bcc +
        cmp #$f9
        bcc _skip
+
        ldx #2                  ; the segments: the rows' (lines L+4 .. L+12, X = 186 + k - line)
-       lda RowL,x
        clc
        adc #4
        sta SegS,x
        adc #8
        sta SegE,x
        txa
        adc #186
        sta SegC,x
        sec                     ; (X on the first line, the last)
        sbc SegS,x
        sta SegXS,x
        lda SegC,x
        sbc SegE,x
        sta SegXE,x
        dex
        bpl -
        lda #189                ; (after the rows, both bombs: X from 189 - LA to 24, 21 to 1)
        sec
        sbc LA
        sta SegXS+3
        lda #24
        sta SegXE+3
        lda #21
        sta SegXS+4
        lda #1
        sta SegXE+4
        lda which
        bne _m1
        lda LA                  ; bomb 0: lines LA .. 165 and 168 .. 188, X = 189 - line
        sta SegS+3
        lda #165
        sta SegE+3
        lda #189
        sta SegC+3
        sta SegC+4
        lda #168
        sta SegS+4
        lda #188
        sta SegE+4
        lda Bomb0Y
        ldx m0x
        jmp _go
_skip   rts
_m1     ldx LA                  ; bomb 1: LA + 1 .. 166 and 169 .. 189, X = 190 - line
        inx
        stx SegS+3
        lda #166
        sta SegE+3
        lda #190
        sta SegC+3
        sta SegC+4
        lda #169
        sta SegS+4
        lda #189
        sta SegE+4
        lda Bomb1Y
        ldx m1x
_go     stx mx
        sta by
        lda #5
        sta NSeg
        ldx #0                  ; (its range below the rows' X all through them: from segment 3)
        lda by
        clc
        adc #7
        bcs +
        cmp SegXE+2
        bcs +
        ldx #3
+       stx SegFrom
        lda #190                ; (line 190 clears both)
        sta forced
        lda by
        jsr Run
        lda #0
        sta SegFrom
        lda lon
        cmp #$ff
        bne +
        rts
+       sta line                ; the pixel the first write lands on, the last's
        lda #1
        sta v2
        jsr WritePx
        sta pon
        lda #0
        sta poff
        lda loff
        cmp #190
        bcs +
        sta line
        lda #0
        sta v2
        jsr WritePx
        sta poff
+       lda loff                ; the last line drawn
        cmp #190
        bcc +
        lda #189
+       sta lastL
        lda lon                 ; all after the rows: one copy, the ship's colour (one run)
        cmp LA
        bcc +
        jmp BombAfter
+       sta line
        lda BRN                 ; (no runs open yet)
        sta openFirst
_blk    jsr BombParams          ; new runs: this line's pixels, each checked against player 1
        lda line                ; (the first line's window is cut: new runs on the next too)
        cmp lon
        bne +
        adc #0                  ; (carry set: + 1)
        sta nb
+       jsr SoloLine
        sta solo
        lda which               ; (bomb 1 in the ship's colour: lines it may hide on)
        beq +
        lda colA
        cmp ColEnemy
        beq +
        lda #1
        bne ++
+       lda #0
+       sta soloPos
        lda openFirst           ; (the last block's runs: may go on)
        sta prevFirst
        lda BRN
        sta openFirst
        lda nusA
        ldx #0
        jsr CopiesPass
        lda split
        cmp #160
        beq _nx
        lda nusB
        ldx #1
        jsr CopiesPass
_nx     lda line
        cmp lastL
        bcs _done
        inc line
        lda line
        cmp nb
        beq _blk
        cmp loff
        beq _blk
        lda solo                ; (after a line checked pixel by pixel: new runs)
        bne _blk
        lda soloPos
        beq +
        jsr SoloLine
        bne _blk
+
        ldx openFirst           ; the runs go on a line
-       cpx BRN
        bcs +
        inc BRLn,x
        inx
        bne -
+       jsr P1Line              ; player 1 here: the runs' pixels against it
        beq _nx
        ldx openFirst
-       cpx BRN
        bcs _nx
        stx tmp4
        lda BRX,x
        sta px
        jsr P1At
        beq +
        ldx which
        lda cx
        ora BombBit,x
        sta cx
+       ldx tmp4
        inx
        bne -
_done   rts

; BombAfter: BombA for a bomb whose lines are all after the rows: at pixel mx (not in the comb)
; on lines lon .. lastL, the first only from pon, the last (loff, under 190) only before poff;
; one run, "10" (or "11" with the ship's colour the enemies'); against the ship on 169-189
BombAfter:
        lda mx
        cmp #8
        bcs +
        rts
+       ldx lon
        cmp pon
        bcs +
        inx
+       stx tmp                 ; the first line
        ldx lastL
        ldy loff
        cpy #190
        bcs +
        cmp poff
        bcc +
        dex
+       stx tmp2                ; the last
        cpx tmp
        bcs +
        rts
+       lda BSprN               ; the first such bomb: a sprite (BombSprA), not bitmap runs
        bne _run
        inc BSprN
        lda tmp
        sta BSprL
        lda mx
        sta BSprX
        lda tmp2
        sec
        sbc tmp
        adc #0                  ; (+ 1: carry set)
        sta BSprLn
        jmp _ship
_run    ldx BRN
        cpx #BRMAX
        bcs _none
        lda tmp
        sta BRL,x
        lda mx
        sta BRX,x
        lda tmp2
        sec
        sbc tmp
        adc #0                  ; (+ 1: carry set)
        sta BRLn,x
        lda #2
        ldy ColShip
        cpy ColEnemy
        bne +
        lda #3
+       sta BRC,x
        inc BRN
_ship   lda tmp2                ; the ship's lines among them: its pixel in each
        cmp #169
        bcc _none
        lda mx
        sec
        sbc ShipX
        bcs +
        adc #160
+       cmp #8
        bcs _none
        tax
        lda BitL,x
        sta tmp3
        lda tmp
        cmp #169
        bcs +
        lda #169
+       tay                     ; (190 - line: the ship's row, from 190 - first down)
        lda #190
        sec
        sbc tmp2
        sta tmp4                ; (the last's row)
        tya
        eor #$ff
        sec
        adc #190
        tax
-       lda T_SHIP,x
        and tmp3
        bne _hit
        dex
        cpx tmp4
        bcs -
_none   rts
_hit    ldx which
        lda cx
        ora BombBit,x
        sta cx
        rts

; WritePx: the pixel the bomb's write on `line` lands on (v2: the value written)
WritePx:
        lda line
        cmp LA
        bcs _after
        sec                     ; in the rows: k, the line in the row
        sbc L2
        tax
        lda Div14,x
        sta tmp4
        ldy #0                  ; ball written on (lines L+5 ..: the laser on): + 3
        lda Mod14,x
        cmp #5
        bcc +
        jsr LaserAt
        beq +
        ldy #3
+       sty tmp
        lda which
        bne _r1
        lda #82                 ; bomb 0: 82 + 3 ball + 3 value
        clc
        adc tmp
        ldx v2
        beq +
        adc #3
+       rts
_r1     lda #186                ; bomb 1: 127 + 3 (ball + bomb 0 + value); X = 186 + k - line
        clc
        adc tmp4
        sec
        sbc line
        sec
        sbc Bomb0Y              ; (bomb 0 written on here?)
        and #$f8
        bne +
        lda tmp
        clc
        adc #3
        sta tmp
+       lda #127
        clc
        adc tmp
        ldx v2
        beq +
        adc #3
+       rts
_after  lda which
        beq +
        lda #0                  ; bomb 1 after the rows: at the line's start
        rts
+       lda line
        cmp LA
        bne +
        lda #106
        bne _v
+       cmp #166
        bcs +
        jsr LaserAt             ; (LA+1 .. 165: 103, + 3 with the ball written on)
        beq _103
        lda #106
        bne _v
_103    lda #103
        bne _v
+       cmp #168
        bne +
        lda #76
        bne _v
+       cmp #190
        bcc +
        lda #0
        rts
+       lda #79
_v      ldx v2
        beq +
        clc
        adc #3
+       rts

; BombParams: the bomb's window on `line` (lo .. hi - 1: from pon on its first line, to before
; poff on its last), its NUSIZ by the side of the split (bomb 0's changes at pixel 67 of a row's
; line 2), its colour; nb: the next line these change on
BombParams:
        lda #0
        sta lo
        lda #160
        sta hi
        sta split
        lda line
        cmp lon
        bne +
        lda pon
        sta lo
+       lda line
        cmp loff
        bne +
        lda poff
        sta hi
+       lda line
        cmp LA
        bcc _rows
        lda #0                  ; after the rows: one copy, the ship's colour
        sta nusA
        sta nusB
        lda ColShip
        sta colA
        lda #190
        sta nb
        rts
_rows   sec
        sbc L2
        tax
        lda Div14,x
        tay
        lda Mod14,x
        sta tmp3
        lda line                ; nb: this row's line 2 or 4, else the next row's 2 (or LA)
        sec
        sbc tmp3
        ldx tmp3
        cpx #2
        bcs +
        adc #2                  ; (carry clear)
        bcc _nb
+       cpx #4
        bcs +
        adc #4
        bcc _nb
+       adc #16 - 1             ; (carry set)
        cmp LA
        bcc _nb
        lda LA
_nb     sta nb
        ldx which
        bne _b1
        ; bomb 0: NUSIZ0 (row k's from pixel 67 of its line 2), COLUP0 (from line 4)
        lda RowN0,y
        sta nusB
        lda RowN0-1,y
        sta nusA
        lda tmp3
        cmp #2
        bcc _oldA
        bne _newA
        lda #67
        sta split
        bne _colA
_oldA   lda nusA
        sta nusB
        jmp _colA
_newA   lda nusB
        sta nusA
_colA   lda RowC0,y
        ldx tmp3
        cpx #4
        bcs +
        lda RowC0-1,y
+       sta colA
        rts
_b1     lda RowN1,y             ; bomb 1: NUSIZ1 (from line 2), COLUP1 (from line 4)
        ldx tmp3
        cpx #2
        bcs +
        lda RowN1-1,y
+       sta nusA
        sta nusB
        lda RowC1,y
        ldx tmp3
        cpx #4
        bcs +
        lda RowC1-1,y
+       sta colA
        rts

; P1Line: player 1 drawn on `line` at all (the rows' drawing lines, the ship's)? (Z clear: yes)
P1Line:
        lda line
        cmp #169
        bcs _ship
        cmp LA
        bcs _no
        sec
        sbc L2
        bcc _no
        tax
        lda Mod14,x
        cmp #5
        bcc _no
        cmp #13
        bcs _no
        lda #1
        rts
_ship   cmp #190
        bcs _no
        lda #1
        rts
_no     lda #0
        rts

; SoloLine: bomb 1 in the ship's colour on a line player 0 is drawn on (it may hide behind it:
; this line's pixels each checked)? A = 1, else 0
SoloLine:
        lda which
        beq _no
        lda colA
        cmp ColEnemy
        beq _no
        lda line
        cmp LA
        bcs _no
        sec
        sbc L2
        bcc _no
        tax
        lda Mod14,x
        cmp #5
        bcc _no
        cmp #13
        bcs _no
        lda #1
        rts
_no     lda #0
        rts

; CopiesPass: the bomb's copies by NUSIZ A on this line (X = 0: the pixels left of the split,
; 1: from it): those shown (lo .. hi - 1, not in the comb) as new runs; touching player 1?
CopiesPass:
        stx split2
        and #7
        tax
        lda CopyFirst,x
        sta cpi
        lda CopyFirst+1,x
        sta cpe
_cp     ldx cpi
        cpx cpe
        bcc +
        rts
+       inc cpi
        lda CopyOff,x
        clc
        adc mx
        cmp #160
        bcc +
        sbc #160
+       sta px
        cmp #8                  ; (the HMOVE comb: nothing drawn, nothing collides)
        bcc _cp
        cmp lo
        bcc _cp
        cmp hi
        bcs _cp
        ldx split2
        bne +
        cmp split
        bcs _cp
        bcc _emit
+       cmp split
        bcc _cp
_emit   jsr P1At                ; touches player 1? (the rows' enemies, the ship)
        beq +
        ldx which
        lda cx
        ora BombBit,x
        sta cx
+       lda which               ; bomb 1 in the ship's colour hides behind player 0 (P0 > M1)
        beq _add
        lda colA
        cmp ColEnemy
        beq _add
        jsr P0At
        bne _cp
_add    lda #2                  ; class: "11" the enemies' colour, "10" the ship's
        ldy colA
        cpy ColEnemy
        bne +
        lda #3
+       sta cls
        ldx prevFirst           ; a run of the last block's with this pixel and class (they all
-       cpx openFirst           ; ended on the line before) goes on: moved into this block's
        bcs _new
        lda BRX,x
        cmp px
        bne +
        lda BRC,x
        cmp cls
        beq _cont
+       inx
        bne -
_cont   dec openFirst           ; (swapped with the last block's last, now this block's first)
        ldy openFirst
        lda BRX,y
        sta swp
        lda BRX,x
        sta BRX,y
        lda swp
        sta BRX,x
        lda BRL,y
        sta swp
        lda BRL,x
        sta BRL,y
        lda swp
        sta BRL,x
        lda BRLn,y
        sta swp
        lda BRLn,x
        sta BRLn,y
        lda swp
        sta BRLn,x
        lda BRC,y
        sta BRC,x
        lda cls
        sta BRC,y
        lda BRLn,y
        clc
        adc #1
        sta BRLn,y
        jmp _cp
_new    ldx BRN                 ; a new run: this pixel from this line
        cpx #BRMAX
        bcs +
        lda line
        sta BRL,x
        lda px
        sta BRX,x
        lda #1
        sta BRLn,x
        lda cls
        sta BRC,x
        inc BRN
+       jmp _cp

BombBit:    .byte 1, 2

; P1At / P0At: player 1 / 0 drawn at (line, px)? (Z clear: yes) three-row waves
P1At:
        lda #1
        bne PAt
P0At:
        lda #0
PAt     sta tmp2
        lda line
        cmp #169
        bcc _rows
        cmp #190
        bcs _none
        lda tmp2                ; the ship (player 1)
        beq _none
        lda #190
        sec
        sbc line
        tax
        lda T_SHIP,x
        beq _none
        sta gbits
        lda ShipX
        sta v0
        lda #0
        sta v1
        lda px
        jmp PHas
_rows   cmp LA
        bcs _none
        sec
        sbc L2
        bcc _none
        tax
        lda Mod14,x
        cmp #5
        bcc _none
        cmp #13
        bcs _none
        eor #$ff                ; the shape's row: 13 - (the line in the row)
        sec
        adc #13
        tay
        lda Div14,x
        tax
        lda (ShapePtr),y
        beq _none
        sta gbits
        lda tmp2
        bne +
        lda RowX0,x
        sta v0
        lda RowN0,x
        sta v1
        lda px
        jmp PHas
+       lda RowX1,x
        sta v0
        lda RowN1,x
        sta v1
        lda px
        jmp PHas
_none   lda #0
        rts

; ------------------------------------------------------------------ six rows
; X falls one a line throughout (X = 189 - line after each line's own dex). Row 5 (the top)
; starts at line 47: 4 set-up lines, then $A9 + 1 lines drawn (the shape's rows $A9 .. 0, the
; mask leaves 14 .. 1); the others follow 29 lines apart (25 lines drawn), down to line 189.
ModeB:
        lda #1
        sta IsModeB
        lda #47                 ; the rows' first lines (row 5 the top), how many lines drawn
        sta RowA+5
        lda ScrollB
        sta RowYY+5
        clc
        adc #52
        ldx #4
-       sta RowA,x
        tay
        lda #24
        sta RowYY,x
        tya
        clc
        adc #29
        dex
        bpl -
        ldx #5
-       lda RowPos0,x
        tay
        lda XOf,y
        sta RowXB,x
        ldy RowCopies,x
        lda T_NUSIZ,y
        sta RowNB,x
        dex
        bpl -

        ; the laser: written on the rows' drawing lines (X one behind: 190 - line), 0 from 170
        lda #0
        sta NSeg
        ldx #5
-       stx tmp4
        lda RowA,x
        cmp #166
        bcs +
        adc #4                  ; (carry clear)
        sta tmp3
        clc
        adc RowYY,x
        cmp #170
        bcc _ok
        lda #169
_ok     tax
        lda tmp3
        ldy #190
        jsr AddSeg
+       ldx tmp4
        dex
        bpl -
        lda #170
        sta forced
        lda LaserY
        jsr Run
        lda lon
        sta LsrOn
        lda loff
        sta LsrOff
        ; (line 169 a row's first: the laser cut off part-way, at pixel 88 + 3 * bomb 1 on)
        cmp #170
        bne _nocut
        ldx #5
-       lda RowA,x
        cmp #169
        beq +
        dex
        bpl -
        bmi _nocut
+       lda #21                 ; bomb 1 written on there? (X = 21)
        sec
        sbc Bomb1Y
        and #$f8
        cmp #1
        lda #88
        bcs +
        lda #91
+       cmp bx
        beq +
        bcs _nocut
+       lda #169                ; the laser's pixel right of the cut: off on line 169
        sta LsrOff
_nocut
        ; the rows' reads (the last row cut short has none, but its pixels count at the end):
        ; each row's drawing lines (A + 4 .. A + 4 + yy) where the laser is
        lda #0
        sta lat
        lda #5
        sta $cf
        ldx #5
_br     stx tmp4
        lda RowA,x
        cmp #190
        bcs _cut
        clc
        adc #4
        sta v2                  ; the row's first drawing line
        clc
        adc RowYY,x
        sta v3                  ; its last (the shape's row 0)
        lda v2
        cmp LsrOn
        bcs +
        lda LsrOn
+       sta line
        cmp v3                  ; (no laser line in the row: done)
        beq +
        bcs _bd
+       cmp LsrOff
        bcs _bd
        lda RowXB,x             ; the laser's pixel's place in the row's copies ($FF: none)
        sta v0
        lda RowNB,x
        sta v1
        lda bx
        jsr PlaceOf
        sta pl0
        bmi _bd
_bl     lda line
        cmp v3
        beq +
        bcs _bd
+       cmp LsrOff
        bcs _bd
        cmp #190
        bcs _bd
        lda v3                  ; the shape's row: (A + 4 + yy) - line
        sec
        sbc line
        tay
        lda (ShapePtr),y
        and T_MASK,y
        beq _bn
        ldx pl0
        and BitL,x
        beq _bn
        lda #1
        sta lat
_bn     inc line
        bne _bl
_bd     lda v3                  ; the row done (its last line 189 at most): its read
        cmp #190
        bcs _cut
        lda lat
        bne +
        lda tmp4
        sta HitRow0
+       ldx tmp4
        dex
        stx $cf
        bmi _cut
        jmp _br
_cut    lda lat
        bne +
        lda #0
        sta HitRow0
+
        ; enemies against the ship: the rows' drawing lines among 170-189
        ldx #5
_pr     stx tmp4
        lda RowA,x
        cmp #190
        bcs _pd
        clc
        adc #4
        sta v2
        clc
        adc RowYY,x
        sta v3
        cmp #170                ; (ends above the ship)
        bcc _pn
        jsr NearCopy            ; (a copy within 8 pixels of the ship? only one can be)
        bmi _pn
        lda v2
        cmp #170
        bcs +
        lda #170
+       sta line
_pl     lda line
        cmp v3
        beq +
        bcs _pn
+       cmp #190
        bcs _pn
        lda #190                ; the ship's row
        sec
        sbc line
        tax
        lda T_SHIP,x
        beq _pnx
        sta v4
        lda v3                  ; the enemy's
        sec
        sbc line
        tay
        lda (ShapePtr),y
        and T_MASK,y
        beq _pnx
        ldx tmp3                ; lined up with the ship's: shifted by the distance
        bit v1
        bmi _sl
-       dex
        bmi +
        lsr
        bne -
+       and v4
        bne _hitpp
        beq _pnx
_sl
-       dex
        bmi +
        asl
        bne -
+       and v4
        beq _pnx
_hitpp  lda cx
        ora #4
        sta cx
        jmp _pd
_pnx    inc line
        bne _pl
_pn     ldx tmp4
        dex
        bpl _pr
_pd

        jsr BombB               ; bomb 1: a sprite (no copies: NUSIZ1 is 0 here)
        jmp Common

; NearCopy: row tmp4's copy within 8 pixels of the ship (copies are 32 or more apart: one at
; most): tmp3 its distance, v1 $00 right of the ship, $80 left; N set: none
NearCopy:
        ldx tmp4
        lda RowNB,x
        and #7
        tay
        lda CopyFirst,y
        sta cpi
        lda CopyFirst+1,y
        sta cpe
        lda RowXB,x
        sta v0
_c      ldx cpi
        cpx cpe
        bcs _none
        inc cpi
        lda CopyOff,x
        clc
        adc v0
        cmp #160
        bcc +
        sbc #160
+       sec
        sbc ShipX
        bcs +
        adc #160
+       cmp #8
        bcs +
        sta tmp3
        lda #0
        sta v1
        rts
+       cmp #153
        bcc _c
        eor #$ff
        adc #160                ; (160 - d: carry set from the compare)
        sta tmp3
        lda #$80
        sta v1
        lda #0
        rts
_none   lda #$ff
        rts

; BombB: bomb 1's lines in a six-row wave: walk the lines from just before its range, each line's
; write (which X it tests, where it lands) by its place in the row; into M1Top / M1Len
BombB:
        lda #0
        sta M1Len
        lda Bomb1Y
        cmp #$8f                ; (X 143 to $F8: never shows)
        bcc +
        cmp #$f9
        bcs +
        rts
+       lda m1x                 ; (in the comb: never shows, touches nothing)
        cmp #8
        bcs +
        rts
+       lda m1x                 ; (its pixel's bit in the ship's: 0 if none)
        sec
        sbc ShipX
        bcs +
        adc #160
+       ldx #0
        cmp #8
        bcs +
        tax
        lda BitL,x
        tax
+       stx shipBit
        lda #181                ; a line before the first that could test X <= $ED + 7 (from
        sec                     ; $F9, wrapped: X <= $ED + 7 - 256, near the bottom: 8 bits do it)
        sbc Bomb1Y
        cmp #47
        bcs +
        lda #47
+       sta line
        lda #0
        sta v2                  ; the state carried
        sta v3                  ; writes on so far
_wl     lda v3                  ; never on, and X below the range from here on: never will be
        ora v2                  ; (but in the wrapped range)
        bne +
        lda Bomb1Y
        cmp #$f9
        bcs +
        lda #190
        sec
        sbc line
        cmp Bomb1Y
        bcs +
        rts
+       lda v2                  ; on, and X tested in the range this line whichever it is
        beq _type               ; (189 - line, 190 - line): it stays on, no need to look
        lda Bomb1Y
        cmp #$f9
        bcs _type
        lda #189
        sec
        sbc line
        sec
        sbc Bomb1Y
        cmp #7
        bcs _type
        lda #$ff
        sta pon
        jmp _on
_type   jsr LineTypeB           ; A: 0-3 set-up, 4 drawing, 5 drawing's last
        sta tmp3
        lda #$ff
        sta pon                 ; the write's pixel ($FF: none)
        ldx tmp3
        cpx #1
        beq _nw
        cpx #5
        beq _nw
        cpx #3                  ; (line 189, A+3 or drawing: X reaches 0 before the write)
        bcc +
        lda line
        cmp #189
        beq _nw
+       lda #190                ; X tested: one behind on lines A, A+2; this line's otherwise
        sec
        sbc line
        sta tmp4                ; (X one behind: "near" the ship below $15)
        cpx #3
        bcc +
        sbc #1
+       sec
        sbc Bomb1Y
        and #$f8
        cmp #1
        lda #0
        rol
        eor #1
        sta v4                  ; the value written
        lda tmp4
        cmp #$15
        bcc _near
        lda WPxFar,x
        cpx #4                  ; drawing lines not near: + 3 if the ball was written on
        bne _pv
        sta tmp
        jsr LaserAt
        beq +
        lda tmp
        clc
        adc #3
        bne _pv
+       lda tmp
        bne _pv
_near   lda WPxNear,x
_pv     ldx v4
        beq +
        clc
        adc #3
+       sta pon
_nw     lda v2                  ; shown at the bomb's pixel: the old state left of the write
        ldx pon
        cpx #$ff
        beq _sh
        ldy m1x
        cpy pon
        bcc _sh
        lda v4
_sh     tay
        beq _off
_on     lda M1Top
        cmp #$ff
        bne +
        lda line
        sta M1Top
+       lda line
        sec
        sbc M1Top
        cmp #21
        bcs _off
        tax
        inx                     ; (its lines are one run: the length)
        stx M1Len
        lda shipBit             ; against the ship (lines 170-189)
        beq _off
        lda line
        cmp #170
        bcc _off
        lda #190
        sec
        sbc line
        tax
        lda T_SHIP,x
        and shipBit
        beq _off
        lda cx
        ora #2
        sta cx
_off    lda pon                 ; the state carried on
        cmp #$ff
        beq +
        lda v4
        sta v2
        beq +
        inc v3
+       lda v2                  ; done: off again after being on
        bne +
        lda v3
        bne _done
+       inc line
        lda line
        cmp #190
        bcs _done
        jmp _wl
_done   rts

WPxFar:     .byte 16, 0, 16, 91, 88
WPxNear:    .byte 34, 0, 34, 109, 91

; LineTypeB: `line`'s place in its row (six-row waves): 0-3 the set-up lines, 4 a drawing line,
; 5 a row's last drawing line (no bomb write)
LineTypeB:
        lda line
        cmp RowA+4
        bcs +
        sec                     ; row 5
        sbc #47
        ldx ScrollB
        jmp _t
+       sec
        sbc RowA+4
        tax
        lda Mod29,x
        ldx #24
_t      cmp #4
        bcc _r
        stx tmp
        sec
        sbc #4
        cmp tmp                 ; y = yy - (rel - 4) = 0: the last
        beq +
        lda #4
        rts
+       lda #5
_r      rts

; ------------------------------------------------------------------ both
Common:
        ; the ship hit: a bomb low enough touching player 1, or an enemy (six-row waves)
        lda ShipHit
        bne _eb
        lda Bomb0Y
        cmp #$14
        bcs +
        lda cx
        and #1
        beq +
        lda #$1f
        sta ShipHit
+       lda Bomb1Y
        cmp #$14
        bcs +
        lda cx
        and #2
        beq +
        lda #$1f
        sta ShipHit
+       lda IsModeB
        beq _eb
        lda cx
        and #4
        beq _eb
        lda #$1f
        sta ShipHit
_eb
        ; the logo's loop leaves its scratch bytes: $A2 its last row's, $A3 $FF, $A4
        lda LogoY0
        sec
        sbc #7
        tax
        lda T_LOGO+$50,x        ; (TFCD0)
        sta $a2
        lda #$ff
        sta $a3
        lda LogoY0
        sec
        sbc #8
        sta $a4
        lda GameOver            ; counted down (from 1 it goes to $FF)
        beq +
        dec GameOver
        bne +
        dec GameOver
+       rts
