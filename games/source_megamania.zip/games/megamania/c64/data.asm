; working variables in free RAM at $C000 (not in the program file; cleared at start-up)
        .virtual WORKRAM
; collide
IsModeB:    .byte 0             ; six-row wave
A1c:        .byte 0             ; three-row waves: $A1 (at most $8F), the rows' first line,
L2:         .byte 0             ; the line after them
LA:         .byte 0
ShipX:      .byte 0
LogoY0:     .byte 0             ; the logo's first row
            .byte 0
RowL:       .fill 3             ; three-row waves, by row (top first): the first line,
            .byte 0
RowX0:      .fill 3             ; player 0's pixel, NUSIZ, colour; player 1's
            .byte 0
RowN0:      .fill 3
            .byte 0
RowC0:      .fill 3
            .byte 0
RowX1:      .fill 3
            .byte 0
RowN1:      .fill 3
            .byte 0
RowC1:      .fill 3
RowA:       .fill 6             ; six-row waves, by row (5 the top): the first line, the lines
RowYY:      .fill 6             ; drawn - 1, the pixel, NUSIZ
RowXB:      .fill 6
RowNB:      .fill 6
pl0:        .byte 0             ; ModeA: the laser's pixel's place in a row's players ($FF: none)
pl1:        .byte 0
shipBit:    .byte 0             ; BombB: its pixel's bit in the ship's rows (0: off the ship)
NSeg:       .byte 0             ; Run's segments: first line, last line, X + line
SegFrom:    .byte 0             ; ... FirstLE's first (0 but in BombA)
SegS:       .fill 8
SegE:       .fill 8
SegC:       .fill 8
SegXS:      .fill 8             ; ... X on the first line, the last
SegXE:      .fill 8
soloPos:    .byte 0             ; BombA: bomb 1 in the ship's colour (lines it may hide on)
nb:         .byte 0             ; BombA: the next line its pixels change on, its last line
lastL:      .byte 0
forced:     .byte 0             ; Run: the line it is off from at the latest
by:         .byte 0             ; a bomb's range
LsrOn:      .byte 0             ; the laser's lines: LsrOn .. LsrOff - 1 ($FF: none)
LsrOff:     .byte 0
BSprN:      .byte 0             ; three-row waves: a bomb on sprite 6 (BombAfter: 1), its first
BSprL:      .byte 0             ; line, lines, pixel
BSprLn:     .byte 0
BSprX:      .byte 0
BRMAX       = 32
BRN:        .byte 0             ; three-row waves: the bombs' runs (pixel, first line, lines,
BRX:        .fill BRMAX         ; class)
BRL:        .fill BRMAX
BRLn:       .fill BRMAX
BRC:        .fill BRMAX
openFirst:  .byte 0             ; ... the runs the last line opened; its window, NUSIZ, colour
prevFirst:  .byte 0             ; ... the runs the block before opened (to go on); a run's class;
cls:        .byte 0             ; (a swap's byte)
swp:        .byte 0
prevLo:     .byte 0
prevHi:     .byte 0
prevSplit:  .byte 0
prevNusA:   .byte 0
prevNusB:   .byte 0
prevCol:    .byte 0
solo:       .byte 0             ; ... a line whose pixels were each checked
M1Top:      .byte 0             ; six-row waves: bomb 1's first line ($FF: none), its lines
M1Len:      .byte 0

; render
cEnemy:     .byte 0             ; this frame's colours (C64)
cShip:      .byte 0
cLaser:     .byte 0
cBand:      .byte 0
cBar:       .byte 0
cGap:       .byte 0
cScore:     .byte 0
cLogo:      .byte 0
sprY:       .byte 0             ; (SprX)
FrMsb:      .byte 0             ; the frame top's sprite X MSBs and enables being built
FrEn:       .byte 0
StBg:       .fill NBUF          ; staged registers per buffer: $D021,
StMsb:      .fill NBUF          ; sprites' X MSBs, enables, the top row's image (0-2),
StEn:       .fill NBUF
StPtr:      .fill NBUF
StCol:      .fill 8 * NBUF      ; colours, X, Y (8 per buffer)
StX:        .fill 8 * NBUF
StY:        .fill 8 * NBUF
EvLine:     .fill NEV * NBUF    ; the events (NEV per buffer): raster line, kind, argument
EvType:     .fill NEV * NBUF
EvArg:      .fill NEV * NBUF
MvX:        .fill 5 * NG * NBUF ; sprite moves (NG per buffer): sprites 0-4's X,
MvY:        .fill NG * NBUF     ; Y, MSBs, enables, image (0: unchanged)
MvMsb:      .fill NG * NBUF
MvEn:       .fill NG * NBUF
MvPtr:      .fill NG * NBUF
NGroups:    .byte 0             ; six-row waves: the moves this frame, their raster lines
GrpLine:    .fill NG
RSX:        .fill 5             ; a row's sprites: X (low bytes), MSBs, enables
RSMsb:      .byte 0
RSEn:       .byte 0
RowImg:     .fill 14            ; six-row waves: the full image's rows
ShapeTmp:   .fill 8
BarBytes:   .fill 20            ; the energy bar's cells, and those each buffer has
BarK:       .fill 4             ; ... the bar they are for ($AA-$AD; $FF: none)
BarB:       .fill 20 * NBUF
KImgF:      .fill 2 * NBUF      ; six-row waves: the shape each buffer's full image is for,
KImgT:      .fill 3 * NBUF      ; the shape and $A9 its top row's, the shape and cut its bottom row's
KImgBt:     .fill 3 * NBUF      ; (interleaved by buffer)
KLsr:       .fill NBUF          ; the laser image's length each buffer has, the bomb's
KBomb:      .fill NBUF
LogoRow:    .fill 7             ; a logo (or label) row's pixels, as multicolour bytes
LogoOut:    .fill 13
R1N:        .byte 0             ; the middle row: its windows' columns this frame, the shift,
R1New:      .fill 5
R1Shift:    .byte 0
R1B0:       .fill 16            ; ... the shape's rows shifted (3 bytes a row; 8-15 zero: the
R1B1:       .fill 16            ; store code run from there clears)
R1B2:       .fill 16
R1Line:     .fill NBUF          ; ... what each buffer has: its line ($FF: none), its windows'
R1NB:       .fill NBUF          ; count and first columns ($FF: none)
R1C:        .fill 5 * NBUF
R1TLine:    .fill NBUF          ; ... its column address table: the cell row it is for ($FF: none),
R1TLo:      .fill NBUF
r1y0:       .byte 0
r1noclr:    .byte 0
r1direct:   .byte 0             ; ... (R1Tab: no table, the targets worked out)
R1TSeenL:   .fill NBUF          ; ... (R1Tab: the cell row each buffer last went without one)
R1TSeenH:   .fill NBUF
R1TSeenN:   .fill NBUF          ; ... (how many times in a row)             ; ... (Row1: the old row cleared already)
r1bLo:      .byte 0             ; ... (R1PSetup: the row's first line's cell row in the bitmap)
r1bHi:      .byte 0             ; ... (R1Moved: the row's first line in its cell row)
CALo:       .fill 42 * NBUF     ; block A's bytes (columns 0-41), block B's
CAHi:       .fill 42 * NBUF
CBLo:       .fill 42 * NBUF
CBHi:       .fill 42 * NBUF
BCN:        .fill NBUF          ; the bomb runs each buffer has, to clear: the cell's address,
BCLo:       .fill BRMAX * NBUF  ; the line in it, lines, the pixel's mask
BCHi:       .fill BRMAX * NBUF
BCO:        .fill BRMAX * NBUF
BCCnt:      .fill BRMAX * NBUF
BCMask:     .fill BRMAX * NBUF
KBar:       .fill 4 * NBUF      ; keys: what each buffer's bottom shows (interleaved by buffer)
KLives:     .fill NBUF
KScore:     .fill 6 * NBUF
KLogo:      .fill NBUF
KShape:     .fill 2 * NBUF
KBotA:      .fill NBUF          ; ... and its screen colours
KBotB:      .fill NBUF
KBotC:      .fill NBUF
Queue:      .fill NBUF
        .cerror * > CODE_C, "the working variables run into the code at CODE_C"
        .endv

; ---------------------------------------------------- the 2600 program
; The original ROM with the patches the C64 needs (see the top of main.asm):
;   $F000 power-on: no SEI (our interrupts run the display)
;   $F006 the RAM clear (power-on, and Game Reset from $D3): from $80 only (JSR ClearZP), the
;         stack pointer left to the C64 (no TXS)
;   $F138 the kernel's wait for the timer: "jmp KernelHook" instead of drawing the picture
;   $F642 "stx VBLANK", $F71E "sty VSYNC", $F726 "sta VSYNC": they would hit the C64's $01 /
;         $00 (to $2E instead)
;   $FFA7 the delay loop before RESP0 / RESP1 (the beam's place: nothing here): ldy #$FF
ROM     = "../build/original.a26"
GameImage:
        nop                     ; F000: (sei)
        .binary ROM, $0001, $0006-$0001
        jsr ClearZP             ; F006: (sta $00,x / txs / inx / bne)
        nop
        nop
        nop
        .binary ROM, $000c, $0138-$000c
        jmp KernelHook          ; F138: (lda INTIM / bne)
        nop
        nop
        .binary ROM, $013d, $0642-$013d
        stx $2e                 ; F642: (stx VBLANK)
        .binary ROM, $0644, $071e-$0644
        sty $2e                 ; F71E: (sty VSYNC)
        .binary ROM, $0720, $0726-$0720
        sta $2e                 ; F726: (sta VSYNC)
        .binary ROM, $0728, $0fa7-$0728
        ldy #$ff                ; FFA7: (dey / bpl FFA7: the beam's delay before RESPx; Y and the
        nop                     ; flags as after it)
        .binary ROM, $0faa, $1000-$0faa
        .cerror * - GameImage != $1000, "the 2600 image must be 4K"
