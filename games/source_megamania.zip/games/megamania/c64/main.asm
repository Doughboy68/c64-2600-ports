; Megamania (Atari 2600, Activision 1982) running on the Commodore 64.
;
; The original 2600 program runs almost unchanged at $F000, in the RAM under the C64 KERNAL
; (patches: see GameImage in data.asm). This file and the others supply everything the 2600
; hardware used to do:
;   - display: laid out line for line like the 2600 picture (one 2600 pixel = one multicolour
;     pixel, two C64 pixels; one 2600 line = one C64 line: 2600 line L is raster line L + 9).
;     A multicolour bitmap, three of them (VIC banks 1, 2 and 0: one shown, one waiting to be,
;     the next frame drawn into the third: the drawing may run late now and then and catch up). Its colours: "11" the colour RAM (black at the left edge: the 2600's
;     HMOVE comb, which also hides sprites behind it; the enemies' colour elsewhere), "10" the
;     screen's low nibble (the ship's colour for the bombs; the bottom's digits and bar), "01"
;     its high nibble (the bottom's grey band). The bottom (energy bar, ships left, score, logo)
;     is drawn when it changes.
;     Three-row waves (the 1st, 3rd, ...): the top and bottom rows of enemies are sprites 0-4
;     (one per enemy, X-expanded: a sprite pixel is a 2600 pixel), moved from the top row to the
;     bottom one between them; the middle row and the bombs are drawn into the bitmap (inside the
;     rows the 2600 copies the bombs along with their players: so do we).
;     Six-row waves: the rows are sprites 0-2, moved down the screen row by row; the bomb is
;     sprite 3. Both: the ship is sprite 5, the laser sprite 7 (three-row waves: a bomb all after
;     the rows sprite 6).
;   - collisions: the laser against the rows, the bombs and the enemies against the ship, worked
;     out in software by the rules in tools/c64ref.js and tools/model.js (which match the 2600
;     pixel for pixel), handed to the game as the RAM its kernel would have left
;   - input: keyboard and joysticks mapped onto the 2600 joystick and switch ports
;   - sound: the game's TIA sound registers translated to the SID
;
; The game's TIA writes land harmlessly in zero page $02-$2C; it reads its fire buttons at
; $0C/$0D, where we put them. Its RIOT accesses ($0280-$0297) hit plain C64 RAM, which we fill
; in each frame.
;
; Build: build.cmd (64tass -C -a -o build/megamania-V.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM (see 2600/symbols.js)
GameNum     = $80
Frame       = $81
ColBg       = $88       ; the picture's colours (masked): the background,
ColBand     = $89       ; the bottom band's background (shown in the energy bar's gaps),
ColLaser    = $8A       ; the laser (COLUPF),
ColBar      = $8B       ; the energy bar,
ColPf       = $8C       ; the band (playfield)
DigitPtr    = $8D       ; 6 pointers: the score
ColScore    = $9B       ; the score and ships left (by player)
Lives       = $9D       ; by player
ColEnemy    = $9F
FormTop     = $A1       ; three-row waves: the rows' line counter value at the top
ScrollB     = $A9       ; six-row waves: the top row's height
BallPos     = $AA       ; the energy bar's end (fine | coarse)
BarPF       = $AB       ; the energy bar: PF0, PF1, PF2
ShipPos     = $AE
ShapePtr    = $AF       ; the enemies' shape
LaserX      = $BD
RowPos0     = $BE       ; the rows' player 0 positions (fine | coarse), top row first ($BE + row)
RowPos1     = $C2       ; ... player 1 (three-row waves)
RowCopies   = $C6       ; the rows' copies (three-row waves: player 0 high nibble, player 1 low)
ColShip     = $D4
CurPlayer   = $D7
WaveFlags   = $D9
GameOver    = $DA       ; 0: a game is running
Wave        = $DE
HitRow0     = $E9       ; the row the laser hit (player 0 / 1), + 1
ShipHit     = $EB
Bomb0Y      = $EC
Bomb1Y      = $ED
Bomb0X      = $EE
Bomb1X      = $EF
LaserY      = $F9

; ------------------------------- 2600 hardware: TIA writes land in zero page
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
INPT4       = $0C       ; (read at $F97E as $000C + player) bit 7 clear: fire
INPT5       = $0D
; RIOT
SWCHA       = $0280     ; joysticks (high nibble: player 1, low: player 2)
SWCHB       = $0282     ; console switches
INTIM       = $0284     ; timer (kept at 0 so the game never waits)

; ------------------------------------------------ 2600 program addresses
PowerOn     = $F000
FrameEnd    = $F639     ; where the game continues after drawing a picture
KernelStart = $F138     ; patched: the game hands over here instead of drawing
T_SHIP      = $FC6A     ; the ship's rows (22, from the bottom)
T_NUSIZ     = $FD2F     ; copy bits -> NUSIZ
T_MASK      = $FD7E     ; six-row waves: the enemies' diamond mask
T_LIVES     = $FD0C     ; the ships left: their rows (10)
T_LIVESNUS  = $FD6F     ; ... NUSIZ by count
T_LABEL0    = $FCE0     ; "ENERGY": three 5-row columns
T_LABEL1    = $FCE5
T_LABEL2    = $FCEA
T_LOGO      = $FC80     ; the logo and copyright: six columns of 16 rows
T_DIGITS    = $FC16

; ------------------------------------------------------------ C64 layout
NBUF        = 3         ; buffers: one shown, one waiting, one being drawn
LINEOFS     = 9         ; 2600 line L is raster line L + LINEOFS (line 42: raster 51, the first
SPRYOFS     = 8         ; bitmap line), and sprite Y register value L + SPRYOFS
TOPRASTER   = 20        ; frame start: above the picture
ENDRASTER   = 245       ; the picture done (line 236)
WORKRAM     = $c000     ; our working variables (data.asm), up to CODE_C
TABLES      = $9000     ; the generated tables (copied there by Start)
SIDTABLES   = $8400
CODE_E      = $e000     ; parts of the program that run elsewhere (copied there by Start): Render,
CODE_C      = $c800     ; the six-row waves' drawing and the buffers' set-up, data.asm's code
CODE_4      = $4400
ExpL        = $5c00     ; (InitTables: a byte as multicolour bytes, left / right; after the middle
ExpR        = $5d00     ; row's shift pages at $5000-$5BFF)
BLK0        = 48        ; sprite blocks (the same in all banks: $4C00 / $8C00 / $0C00)
BLK_BLANK   = BLK0
BLK_SHIPA   = BLK0 + 1  ; the ship (three-row waves: 21 lines; six-row: 20)
BLK_SHIPB   = BLK0 + 2
BLK_LASER   = BLK0 + 3
BLK_ROWA    = BLK0 + 4  ; three-row waves: the rows' enemy
BLK_TOPB    = BLK0 + 5  ; six-row waves: the top row's enemy, the full rows', the bottom row's
BLK_FULLB   = BLK0 + 6
BLK_BOTB    = BLK0 + 7
BLK_BOMB    = BLK0 + 8  ; six-row waves: the bomb
        .cerror BLK_BOMB != BLK0 + 8, "9 sprite blocks a buffer (InitBuffer; buffer 2's are followed by code)"

; sprites
S_LASER     = 7
S_SHIP      = 5
S_BOMBA     = 6         ; three-row waves: a bomb all after the rows
S_BOMB      = 3

; ------------------------------------------------------- zero page ($40+)
; $02-$2C take the game's TIA writes, $2E its VSYNC / VBLANK writes (patched), $0C/$0D are
; its fire buttons, so ours start at $40.
        .virtual $40
ptrA        .word ?
ptrB        .word ?
ptrC        .word ?
ptrD        .word ?
tmp         .byte ?
tmp2        .byte ?
tmp3        .byte ?
tmp4        .byte ?
v0          .byte ?
v1          .byte ?
v2          .byte ?
v3          .byte ?
v4          .byte ?
v5          .byte ?
frameFlag   .byte ?     ; frames counted by the raster interrupt, the main loop's yet to do
FOwed       .byte ?     ; main loop: the frames owed, those this pass does
FNow        .byte ?
isPal       .byte ?
tickAcc     .byte ?
firstTick   .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)
switches    .byte ?     ; SWCHB toggles
curBuf      .byte ?     ; raster interrupt: the buffer shown
QCount      .byte ?     ; buffers drawn, waiting to be shown, in Queue
evIdx       .byte ?     ; the raster interrupt's next event
evBase      .byte ?     ; ... the shown buffer's events (NEV * buffer)
rbuf        .byte ?     ; render: the buffer being drawn
bmHi        .byte ?     ; ... its bitmap's page, its screen's, its sprite blocks'
scrHi       .byte ?
sprHi       .byte ?
bx          .byte ?     ; collide: the laser's pixel, the bombs'
m0x         .byte ?
m1x         .byte ?
line        .byte ?     ; a 2600 line
lon         .byte ?     ; a run's first line, the line it ends on
loff        .byte ?
pon         .byte ?     ; ... the pixels the writes land on
poff        .byte ?
vlo         .byte ?     ; FirstLE's value, a run's range
vhi         .byte ?
cx          .byte ?     ; collision flags being gathered
lat         .byte ?
gbits       .byte ?
px          .byte ?     ; a bomb's pixel; the pixels shown on its line: lo .. hi - 1;
lo          .byte ?     ; where its NUSIZ changes, which side of it this pass
hi          .byte ?
split       .byte ?
split2      .byte ?
mx          .byte ?     ; ... the bomb's pixel (its first copy)
cpi         .byte ?     ; copies: the next, the end (CopyOff's)
cpe         .byte ?
which       .byte ?     ; the bomb (0 / 1)
nusA        .byte ?     ; ... its NUSIZ left of the split, right of it; its colour
nusB        .byte ?
colA        .byte ?
v5b         .byte ?
irqT        .byte ?     ; the raster interrupt's own scratch bytes
irqT2       .byte ?
        .cerror * > $80, "zero page overflow"
        .endv

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title, credits and controls.
; (Lower case here: 64tass -a turns it into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " megamania"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600, activision 1982"
Bas30   .word Bas40, 30
        .null $8f, " programmed by steve cartwright"
Bas40   .word Bas50, 40
        .null $8f, " version 1.0"
Bas50   .word Bas60, 50
        .null $8f, " ported by claude and doughboy68"
Bas60   .word Bas70, 60
        .null $8f, " joy port 2 (player 2: port 1) or"
Bas70   .word Bas80, 70
        .null $8f, " a/d-move space-fire"
Bas80   .word Bas90, 80
        .null $8f, " f1 or fire-start f2-power off/on"
Bas90   .word BasEnd, 90
        .null $8f, " f3-game f5-colour/b&w f7/f8-laser"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #$ff
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01

        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -
        ldx #0                  ; and our working variables
-       .for i := 0, i < (CODE_C - WORKRAM) / $100, i += 1
        sta WORKRAM + i * $100,x
        .endfor
        inx
        bne -
        jsr Relocate            ; the parts that run elsewhere, the 2600 program at $F000
        lda #<Irq               ; our IRQ vector replaces the 2600's
        sta $fffe
        lda #>Irq
        sta $ffff
        ; NMIs off for good: one from CIA 2's timer A, never acknowledged (then the RESTORE key's
        ; can't come either). The NMI vector is the 2600's code ($FFFA-$FFFB: its last routine's
        ; "sta $AF / rts"): ours only while that one NMI comes, then the game's bytes again.
        lda $fffa
        sta tmp
        lda $fffb
        sta tmp2
        lda #<Nmi
        sta $fffa
        lda #>Nmi
        sta $fffb
        lda #0
        sta NmiDone
        sta $dd04
        sta $dd05
        lda #$81                ; timer A's NMI on
        sta $dd0d
        lda #$19                ; load, start, one shot
        sta $dd0e
-       lda NmiDone
        beq -
        lda tmp
        sta $fffa
        lda tmp2
        sta $fffb

        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #0
        sta INTIM
        lda #$80
        sta INPT4
        sta INPT5
        lda #1
        sta firstTick

        jsr InitVideo
        jsr InitSound
        jsr DetectPal

        lda #0                  ; start the raster interrupt at the frame top
        sta curBuf
        sta QCount
        sta evIdx
        sta evBase
        lda #NBUF - 1
        sta frameFlag
        lda #TOPRASTER
        sta $d012
        lda #$3b                ; bitmap mode, 25 rows, YSCROLL 3, raster bit 8 clear
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

; ================================================================ main loop
; Each pass: the game's ticks for a frame (PAL: 6 every 5 frames), then the picture drawn into
; the buffer not shown, queued for the frame top. Behind (more frames owed), a pass does the
; ticks of the rest at once, skipping pictures to keep the game's speed (at most 4 frames owed).
MainLoop:
-       lda frameFlag           ; frames to do (the raster interrupt adds one each frame)
        bne +
        inc DbgIdle             ; (testing aid: the time waiting, 15 cycles a count)
        bne -
        inc DbgIdle+1
        bne -
        inc DbgIdle+2
        jmp -
+       sei
        lda frameFlag
        cmp #5
        bcc +
        lda #4
+       sta FOwed
        sec                     ; this pass: all owed but the lead (NBUF - 2), at least one
        sbc #NBUF - 2
        beq +
        bcs ++
+       lda #1
+       sta FNow
        eor #$ff
        sec
        adc FOwed
        sta frameFlag
        cli
        ldx FNow
        inc DbgLoops            ; (testing aid: passes, and passes that skipped pictures)
        bne +
        inc DbgLoops+1
+       cpx #2
        bcc +
        inc DbgLate
        bne +
        inc DbgLate+1
+       lda DbgBorder           ; testing aid: the border shows where the time goes
        beq +
        lda #5
        sta $d020
+       jsr ReadInput
        lda PowerReq            ; F2: the power switch
        beq _frame
        jsr PowerCycle
_frame  lda isPal               ; PAL: 6 game ticks every 5 frames keeps 2600 speed
        beq _ntsc
        lda tickAcc
        clc
        adc #6
        sta tickAcc
-       lda tickAcc
        cmp #5
        bcc _next
        sbc #5
        sta tickAcc
        jsr Tick
        jmp -
_ntsc   jsr Tick
_next   dec FNow
        bne _frame
_draw   lda DbgBorder
        beq +
        lda #0
        sta $d020
+
-       lda QCount              ; a buffer free (one shown, at most one waiting)
        cmp #NBUF - 1
        bcc +
        inc DbgIdleQ            ; (testing aid: the time waiting, 17 cycles a count)
        bne -
        inc DbgIdleQ+1
        bne -
        inc DbgIdleQ+2
        jmp -
+
        lda DbgBorder
        beq +
        lda #2
        sta $d020
+       jsr Render              ; draw the state the ticks produced
        sei                     ; ... queued for the frame top
        ldx QCount
        lda rbuf
        sta Queue,x
        inc QCount
        cli
        jsr UpdateSound
        lda DbgBorder
        beq +
        lda #0
        sta $d020
+       jmp MainLoop

; One 2600 frame of game logic: the original code from the end of the picture to the start
; of the next one, where it jumps to KernelHook.
Tick:
        lda DbgAuto             ; (testing aid: the inputs by the tick count)
        beq +
        jsr AutoInput
+       lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp PowerOn             ; the very first frame starts at power-on
+       jmp FrameEnd

KernelHook:                     ; the game would draw the picture now
        jsr Collide             ; what the TIA would have seen, and the RAM the kernel leaves
        rts                     ; (returns to whoever called Tick)

; Relocate: the parts of the file that run elsewhere copied there, whole pages (each one's place
; takes in no part of the file still to be copied: checked at the file's end)
Relocate:
        ldx #0
_part   stx tmp4
        lda RelSrcLo,x
        sta ptrA
        lda RelSrcHi,x
        sta ptrA+1
        lda #0
        sta ptrB
        lda RelDst,x
        sta ptrB+1
        lda RelPages,x
        tax
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        ldx tmp4
        inx
        cpx #RelN
        bne _part
        rts
RelSrcLo:   .byte <ImgE, <ImgC, <GameImage, <TabImage, <SidImage, <Img4
RelSrcHi:   .byte >ImgE, >ImgC, >GameImage, >TabImage, >SidImage, >Img4
RelDst:     .byte >CODE_E, >CODE_C, $f0, >TABLES, >SIDTABLES, >CODE_4
RelPages:   .byte >(ImgEEnd - CODE_E + 255), >(ImgCEnd - CODE_C + 255), 16
            .byte >(TabEnd - TABLES + 255), >(SidEnd - SIDTABLES + 255), >(Img4End - CODE_4 + 255)
RelN        = 6

; =========================================================== interrupts
; Each buffer has its list of events down the screen (made by Render): the frame top (the
; buffer shown, the sprites' first places), sprites moved for the next row of enemies, the
; picture's end. Each is armed a few lines ahead (a sprite moved before its next start).
Irq:
        pha
        txa
        pha
        tya
        pha
        cld                     ; the game uses decimal mode now and then
        lda $d019
        sta $d019
_run    lda evIdx
        clc
        adc evBase
        tax
        ldy EvType,x
        lda EvLo,y
        sta _j+1
        lda EvHi,y
        sta _j+2
_j      jmp $0000               ; (X: the event's index)

; every event ends here: arm the next (one whose line has passed is run at once)
IrqNext:
        inc evIdx
        lda evIdx
        clc
        adc evBase
        tax
        lda EvLine,x
        sta $d012
        cmp $d012               ; the line already reached or passed: now
        beq +
        bcs _out
+       lda #$ff
        sta $d019
        jmp Irq._run
_out    pla
        tay
        pla
        tax
        pla
        rti
        .cerror * > $0c00, "the program's start runs into buffer 2's sprite blocks"

; (buffer 2's sprite blocks at $0C00-$0E3F: the program goes on after them)
        * = $0e40

; F2: the power switch off and on. The TIA is cleared and the next tick starts at the 2600's
; power-on code, which clears its RAM; the console switches, the joysticks and the fire buttons
; stay as they are, as on a real 2600. The display catches up by itself.
PowerCycle:
        lda INPT4
        pha
        lda INPT5
        pha
        lda #0
        sta PowerReq
        ldx #2                  ; the TIA's registers ($02-$2E)
-       sta $00,x
        inx
        cpx #$30
        bne -
        sta INTIM
        pla
        sta INPT5
        pla
        sta INPT4
        lda #1
        sta firstTick
        lda DbgAuto             ; (testing aid: the self-playing game from its start, whenever
        beq +                   ; the power cycle came: the same game every time)
        lda #0
        sta AutoT
        sta AutoT+1
        sta AutoHold
        sta AutoHop
        sta AutoHop+1
        lda #1
        sta AutoR
        lda #$ff
        sta AutoDir
+       rts

; Replaces the 2600's "sta $00,x / txs / inx / bne" clearing loop (power-on, X = 0, and Game
; Reset, X = $D3; A = 0): clear the 2600 RAM from X up, but not the C64's zero page below $80.
ClearZP:
        cpx #$80
        bcs +
        ldx #$80
+
-       sta $00,x
        inx
        bne -
        rts

Nmi:    inc NmiDone             ; (CIA 2 not acknowledged: no more NMIs)
        rti

EvLo:       .byte <EvTop, <EvMoveA, <EvMoveB, <EvEnd
EvHi:       .byte >EvTop, >EvMoveA, >EvMoveB, >EvEnd
EV_TOP      = 0
EV_MOVEA    = 1
EV_MOVEB    = 2
EV_END      = 3
NEV         = 8         ; events per buffer at most: the top, 6 moves, the end

; Frame top: switch to a newly finished buffer; its bank, colours, sprites
EvTop:
        inc DbgTops             ; (testing aid)
        bne +
        inc DbgTops+1
+       lda QCount              ; the next picture waiting, if any (else the same again)
        beq _rep
        lda Queue
        sta curBuf
        lda Queue+1
        sta Queue
        dec QCount
        jmp _shown
_rep    inc DbgRepeat
        bne +
        inc DbgRepeat+1
+       lda Wave                ; (and by wave, 0-15)
        and #15
        tax
        inc DbgRepW,x
_shown  ldy curBuf
        lda EvBaseOf,y
        sta evBase
        lda $dd00               ; the buffer's VIC bank
        and #$fc
        ora BankBits,y
        sta $dd00
        lda D18Of,y             ; (its screen's place in the bank)
        sta $d018
        lda StBg,y              ; (here the beam is in the border: no grey dot)
        sta $d021
        lda StMsb,y
        sta $d010
        lda StEn,y
        sta $d015
        tya                     ; 8 * buffer: staged sprite values
        asl
        asl
        asl
        tay
        .for i := 0, i < 8, i += 1
        lda StCol+i,y
        sta $d027+i
        lda StX+i,y
        sta $d000+2*i
        lda StY+i,y
        sta $d001+2*i
        .endfor
        ldy curBuf              ; sprites 0-2's image (six-row waves change it down the screen)
        lda ScrPtrHi,y
        sta _p+2
        sta _p2+2
        sta _p3+2
        lda StPtr,y
_p      sta $43f8
_p2     sta $43f9
_p3     sta $43fa
        lda #0                  ; (the event list from its start: the top is event 0)
        sta evIdx
        jmp IrqNext

; Three-row waves: the bottom row's sprites (X: the event's index): positions, the enable bits
; and the X MSBs of sprites 0-4 (the image stays)
EvMoveA:
        ldy EvArg,x             ; the group's staged values
        lda MvMsb,y
        sta irqT
        lda $d010
        and #$e0
        ora irqT
        sta $d010
        lda MvEn,y
        sta irqT
        lda $d015
        and #$e0
        ora irqT
        sta $d015
        lda MvY,y
        sta $d001
        sta $d003
        sta $d005
        sta $d007
        sta $d009
        tya                     ; 5 * group: the X values
        sta irqT
        asl
        asl
        adc irqT
        tax
        lda MvX,x
        sta $d000
        lda MvX+1,x
        sta $d002
        lda MvX+2,x
        sta $d004
        lda MvX+3,x
        sta $d006
        lda MvX+4,x
        sta $d008
        jmp MoveDone

; Six-row waves: the next row's sprites 0-2: positions, enables, X MSBs, image
EvMoveB:
        ldy EvArg,x
        lda MvMsb,y
        sta irqT
        lda $d010
        and #$f8
        ora irqT
        sta $d010
        lda MvEn,y
        sta irqT
        lda $d015
        and #$f8
        ora irqT
        sta $d015
        lda MvY,y
        sta $d001
        sta $d003
        sta $d005
        lda MvPtr,y
        sta irqT
        tya                     ; 5 * group: the X values
        sta irqT2
        asl
        asl
        adc irqT2
        tax
        lda MvX,x
        sta $d000
        lda MvX+1,x
        sta $d002
        lda MvX+2,x
        sta $d004
        ldx curBuf
        lda ScrPtrHi,x
        sta _p+2
        sta _p2+2
        sta _p3+2
        lda irqT
_p      sta $43f8
_p2     sta $43f9
_p3     sta $43fa
        jmp MoveDone

; MoveDone: (testing aid) a move done on or after its sprites' start line is late
MoveDone:
        lda $d012
        cmp $d001
        bcc +
        inc DbgMoveLate
        bne +
        inc DbgMoveLate+1
+       jmp IrqNext

; After the picture: the main loop may draw the next frame
EvEnd:
        inc frameFlag
        lda #TOPRASTER          ; the next frame's top: event 0 again (IrqNext would go on)
        sta $d012
        lda #0
        sta evIdx
        jmp IrqNext._out

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        txa                     ; the SID's pitch depends on the machine's clock
        bne +
        lda #<SidFreqLoN
        sta FreqTab
        lda #>SidFreqLoN
        sta FreqTab+1
+       rts

InitVideo:
        lda $dd02               ; VIC bank: buffer 0's (bank 1, $4000) to start
        ora #3
        sta $dd02
        lda $dd00
        and #$fc
        ora BankBits
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d017
        sta $d01c               ; no multicolour sprites
        lda #$ff                ; all sprites behind the foreground ("10" and "11"), X-expanded
        sta $d01b
        sta $d01d
        lda #$18                ; multicolour, 40 columns
        sta $d016
        lda D18Of               ; buffer 0's screen and bitmap
        sta $d018
        jsr InitTables
        ldx #0                  ; colour RAM: black (the comb, the rows below the picture)
        lda #0
-       sta $d800,x
        sta $d900,x
        sta $da00,x
        sta $dae8,x
        inx
        bne -
        ldx #NBUF - 1           ; every buffer: everything to be drawn
-       stx rbuf
        jsr InitBuffer
        ldx rbuf
        dex
        bpl -
        lda #0
        sta rbuf
        rts

InitSound:
        ldx #$18
        lda #0
-       sta $d400,x
        dex
        bpl -
        lda #$8f                ; full volume, voice 3 off (it only syncs voice 1)
        sta $d418
        ldx #5
        lda #$ff
-       sta SndLast,x
        dex
        bpl -
        rts

        .include "input.asm"
        .include "collide.asm"
        .cerror * > $2000, "the program runs into buffer 2's bitmap"
; (in the file from here on: copied to where they run by Relocate)
ImgE:
        .logical CODE_E
        .include "render.asm"
ImgEEnd:
        .here
        .cerror ImgEEnd > $f000, "Render runs past $EFFF"
ImgC:
        .logical CODE_C
        .include "render6.asm"
ImgCEnd:
        .here
        .cerror ImgCEnd > $d000, "the code at $C800 runs past $CFFF"
        .include "data.asm"

; The generated tables run at $9000 (the VIC sees the character ROM there: free for the CPU) and
; $8400 (the SID's frequencies: between buffer 1's screen and its sprite blocks): in the file after the 2600 image,
; copied there by Start
TabImage:
        .logical TABLES
        .include "tables.inc"
TabEnd:
        .here
        .cerror TabEnd > $a000, "the tables run past $9FFF"
SidImage:
        .logical SIDTABLES
        .include "sidtables.inc"
SidEnd:
        .here
        .cerror SidEnd > $8c00, "the SID tables run into buffer 1's sprite blocks"
; data.asm's code and variables: run at $4400 (between buffer 0's screen and its sprite blocks);
; copied last (its place takes in the file before it)
Img4:
        .logical CODE_4
        .include "data4.asm"
Img4End:
        .here
        .cerror CODE_4 + 256 * (>(Img4End - CODE_4 + 255)) > Img4, "data.asm's code's place runs into its own file bytes"
        .cerror Img4End > $4c00, "data.asm's code runs into buffer 0's sprite blocks"
