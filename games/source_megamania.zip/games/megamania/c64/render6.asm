; ================================================================ render (2)
; Render's six-row waves part; the buffers' set-up (runs at CODE_C: render.asm runs at CODE_E)

; ------------------------------------------------------------------ six rows
; RenderB: the rows on sprites 0-2, moved down row by row (each 29 lines after the last: its
; image's 14 rows start where the shape's row 14 would be, blank where the row isn't drawn);
; the bomb (3), the ship (5), the laser (6)
RenderB:
        lda #0
        sta NGroups
        ; the shape's 14 rows (y 14-1, masked): RowImg
        ldx #13
        ldy #1
-       lda (ShapePtr),y
        and T_MASK,y
        sta RowImg,x
        iny
        dex
        bpl -
        ; the full image (the shape's rows), when this buffer's is another shape's
        ldx rbuf
        lda ShapePtr
        cmp KImgF,x
        bne +
        lda ShapePtr+1
        cmp KImgF+NBUF,x
        beq _top
+       lda ShapePtr
        sta KImgF,x
        lda ShapePtr+1
        sta KImgF+NBUF,x
        lda #BLK_FULLB
        ldx #14
        jsr ImgRows
_top    ; the top row's (rows with y above $A9 blank): only for $A9 under 14 (else the full one)
        lda ScrollB
        cmp #14
        bcs _rows
        ldx rbuf
        lda ShapePtr
        cmp KImgT,x
        bne +
        lda ShapePtr+1
        cmp KImgT+NBUF,x
        bne +
        lda ScrollB
        cmp KImgT+2*NBUF,x
        beq _rows
+       lda ShapePtr
        sta KImgT,x
        lda ShapePtr+1
        sta KImgT+NBUF,x
        lda ScrollB
        sta KImgT+2*NBUF,x
        lda #BLK_TOPB           ; rows 0 .. 13 - $A9 blank, then the shape's
        jsr BlkAt
        lda #14
        sec
        sbc ScrollB
        tax                     ; (blank rows)
        lda #0
        ldy #0
-       sta (ptrB),y
        iny
        iny
        iny
        dex
        bne -
        lda #14
        sec
        sbc ScrollB
        tax
        cpx #14                 ; ($A9 = 0: no rows of the shape)
        beq _rows
-       lda RowImg,x
        sta (ptrB),y
        iny
        iny
        iny
        inx
        cpx #14
        bne -
_rows   ; each row: its sprite start, image, copies
        ldx #5
_grp    stx v3                  ; the row
        lda RowA,x
        cmp #190
        bcc +
        jmp _gend
+       clc                     ; start: A + 4 + yy - 14
        adc RowYY,x
        sec
        sbc #10
        sta v2
        lda #BLK_FULLB          ; the image: the top row's (cut), the bottom's (lines past 189
        cpx #5                  ; blank), or the full one
        bne +
        ldy ScrollB
        cpy #14
        bcs +
        lda #BLK_TOPB
+       sta v1
        lda v2
        clc
        adc #13                 ; the image's last row's line
        cmp #190
        bcc _img
        sbc #189                ; bottom cut: the rows on lines 190+ blank (A: how many)
        sta tmp3
        lda #BLK_BOTB
        sta v1
        ldx rbuf                ; (this buffer's: the same shape and cut already?)
        lda ShapePtr
        cmp KImgBt,x
        bne +
        lda ShapePtr+1
        cmp KImgBt+NBUF,x
        bne +
        lda tmp3
        cmp KImgBt+2*NBUF,x
        beq _img
+       lda ShapePtr
        sta KImgBt,x
        lda ShapePtr+1
        sta KImgBt+NBUF,x
        lda tmp3
        sta KImgBt+2*NBUF,x
        lda #14
        sec
        sbc tmp3
        bcs +
        lda #0
+       tax                     ; (the rows kept)
        lda #BLK_BOTB
        jsr ImgRows
_img    lda #0                  ; the copies' X (sprites 0-2: one player, no two the same)
        sta RSMsb
        sta RSEn
        ldx v3
        lda RowCopies,x
        beq _noc
        lda RowXB,x
        sta v0
        lda RowNB,x
        and #7
        tay
        lda CopyFirst,y
        sta cpi
        lda CopyFirst+1,y
        sta cpe
        ldy #0
_cpy    ldx cpi
        cpx cpe
        bcs _noc
        inc cpi
        lda CopyOff,x
        clc
        adc v0
        cmp #160
        bcc +
        sbc #160
+       tax
        lda SprXLo,x
        sta RSX,y
        lda SprXHi,x
        beq +
        lda Bit,y
        ora RSMsb
        sta RSMsb
+       lda Bit,y
        ora RSEn
        sta RSEn
        iny
        bne _cpy
_noc    ldx v3
        cpx #5
        bne _move
        ldx v5                  ; the top row: the frame top's values
        lda RSX
        sta StX,x
        lda RSX+1
        sta StX+1,x
        lda RSX+2
        sta StX+2,x
        lda v2
        clc
        adc #SPRYOFS
        sta StY,x
        sta StY+1,x
        sta StY+2,x
        lda RSEn
        ora FrEn
        sta FrEn
        lda RSMsb
        ora FrMsb
        sta FrMsb
        ldx rbuf
        lda v1
        sta StPtr,x
        jmp _gnext
_move   ldx rbuf                ; a later row: a move, armed after the previous row's image
        lda MvBaseOf,x
        clc
        adc NGroups
        tax
        lda RSEn
        sta MvEn,x
        lda RSMsb
        sta MvMsb,x
        lda v2
        clc
        adc #SPRYOFS
        sta MvY,x
        lda v1
        sta MvPtr,x
        txa
        sta tmp
        asl
        asl
        adc tmp
        tax
        lda RSX
        sta MvX,x
        lda RSX+1
        sta MvX+1,x
        lda RSX+2
        sta MvX+2,x
        ldy NGroups             ; (the previous row's image done: 14 lines before this start)
        lda v2
        sec
        sbc #14 - LINEOFS
        sta GrpLine,y
        inc NGroups
_gnext  ldx v3
        dex
        bmi _gend
        jmp _grp
_gend   lda M1Top               ; the bomb (sprite 3)
        cmp #$ff
        beq _nb
        ldx v5
        clc
        adc #SPRYOFS
        sta StY+3,x
        lda m1x
        jsr SprX
        lda tmp
        sta StX+3,x
        bcc +
        lda FrMsb
        ora #8
        sta FrMsb
+       lda FrEn
        ora #8
        sta FrEn
        ldx rbuf                ; the image: rows 0 .. M1Len - 1, when its length changed
        lda M1Len
        ldy KBomb,x
        cmp KBomb,x
        beq _nb
        sta KBomb,x
        sta tmp3
        lda #BLK_BOMB
        jsr LenImg
_nb     lda #170 + SPRYOFS      ; the ship (lines 170-189)
        jsr ShipSpriteB
        jsr LaserSprite
        ; pointers: 0-2 the top row's image, 3 the bomb, 5 the ship, 7 the laser
        lda #$f8
        sta ptrA
        lda scrHi
        ora #3
        sta ptrA+1
        ldx rbuf
        lda StPtr,x
        ldy #0
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        lda #BLK_BOMB
        sta (ptrA),y
        ldy #5
        lda #BLK_SHIPB
        sta (ptrA),y
        iny
        iny
        lda #BLK_LASER
        sta (ptrA),y
        jmp Finish

ShipSpriteB = ShipSprite

; ------------------------------------------------------------------ set-up
; InitBuffer: a buffer (rbuf) from scratch: the bitmap (the comb, the bottom's band and label,
; black below the picture), the screen, the sprite blocks; its keys "nothing drawn"
InitBuffer:
        ldx rbuf
        lda BmHiOf,x
        sta bmHi
        lda ScrHiOf,x
        sta scrHi
        lda SprHiOf,x
        sta sprHi
        lda #0                  ; the bitmap: 0
        sta ptrA
        lda bmHi
        sta ptrA+1
        ldx #32
        jsr ClearPages
        lda scrHi               ; the screen: 0 (the sprite pointers too)
        sta ptrA+1
        ldx #4
        jsr ClearPages
        lda sprHi               ; the sprite blocks (9: buffer 2's are followed by code): 0
        sta ptrA+1
        ldx #2
        jsr ClearPages
        ldy #63                 ; (ptrA: the third page)
-       sta (ptrA),y
        dey
        bpl -
        ; the comb: columns 0-1 "11" (black: the colour RAM) on every line
        lda #42
        sta line
-       lda line
        ldx #0
        jsr BmAt
        ldy #0
        lda #$ff
        sta (ptrA),y
        ldy #8
        sta (ptrA),y
        inc line
        lda line
        cmp #242
        bne -
        ; below the picture (lines 234-241) black: "11"
        lda #234
        ldx #$ff
        ldy #242
        jsr FillLines
        ; the band: lines 192-222 "01"
        lda #192
        ldx #$55
        ldy #223
        jsr FillLines
        ; the label "ENERGY" (lines 195-199, rows 4-0): pixels 24-30 the first column's,
        ; 31 the third's bit 0, 32-39 the second's, 40-47 the third's; black ("00") on the band
        lda #195
        sta line
        lda #4
        sta v3
_lb     ldy v3
        lda T_LABEL0,y
        and #$fe
        sta LogoRow
        lda T_LABEL2,y
        and #1
        ora LogoRow
        sta LogoRow
        lda T_LABEL1,y
        sta LogoRow+1
        lda T_LABEL2,y
        sta LogoRow+2
        lda line
        ldx #6
        jsr BmAt
        ldx #0
        ldy #0
-       stx tmp
        txa
        lsr
        tax
        lda LogoRow,x
        bcs +
        lsr
        lsr
        lsr
        lsr
+       and #$0f
        tax
        lda Exp4,x
        eor #$ff
        and #$55                ; clear pixels: the band; set: black
        jsr Row8
        ldx tmp
        inx
        cpx #6
        bne -
        inc line
        dec v3
        bpl _lb
        ; the ship's images (both kinds): three-row waves 21 lines (rows 21-1), six-row 20
        lda #BLK_SHIPA
        jsr BlkAt
        ldx #21
        ldy #0
-       lda T_SHIP,x
        sta (ptrB),y
        iny
        iny
        iny
        dex
        bne -
        lda #BLK_SHIPB
        jsr BlkAt
        ldx #20
        ldy #0
-       lda T_SHIP,x
        sta (ptrB),y
        iny
        iny
        iny
        dex
        bne -
        ; the keys: nothing drawn yet
        ldx rbuf
        lda #$ff
        sta R1Line,x
        sta R1TLine,x
        sta KLives,x
        sta KLogo,x
        sta KBar,x
        sta KBar+NBUF,x
        sta KBar+2*NBUF,x
        sta KBar+3*NBUF,x
        sta BarK                ; ($FF $FF $FF $FF: never a bar)
        sta BarK+1
        sta BarK+2
        sta BarK+3
        sta KShape,x
        sta KShape+NBUF,x
        sta KBotA,x
        sta KBotB,x
        sta KBotC,x
        sta KLsr,x
        sta KBomb,x
        lda #0
        sta BCN,x
        sta KImgF+NBUF,x            ; (no image made: a shape page of 0)
        sta KImgT+NBUF,x
        sta KImgBt+NBUF,x
        ldy #6
-       lda #$ff
        sta KScore,x
        txa
        clc
        adc #NBUF
        tax
        dey
        bne -
        ldx rbuf                ; the bar's cells
        lda BarBase,x
        tax
        ldy #20
        lda #0                  ; (no cell is 0: never black)
-       sta BarB,x
        inx
        dey
        bne -
        ldx rbuf                ; the events until it is first drawn: the top, the end
        lda #0
        sta StEn,x
        lda EvBaseOf,x
        tax
        lda #EV_TOP
        sta EvType,x
        lda #TOPRASTER
        sta EvLine,x
        lda #EV_END
        sta EvType+1,x
        lda #ENDRASTER
        sta EvLine+1,x
        ldx rbuf                ; the middle row: no windows; its code's skeleton
        lda #0
        sta R1NB,x
        lda R1Base,x
        tax
        ldy #5
        lda #$ff
-       sta R1C,x
        inx
        dey
        bne -
        jmp R1Init

; ClearPages: X pages from ptrA+1 (ptrA = 0) cleared
ClearPages:
        lda #0
        sta ptrA
        tay
-       sta (ptrA),y
        iny
        bne -
        inc ptrA+1
        dex
        bne -
        rts

; FillLines: lines A .. Y - 1, columns 2-39, filled with X
FillLines:
        sta line
        sty tmp4
        stx tmp3
_fl     lda line
        ldx #2
        jsr BmAt
        ldx #38
        ldy #0
-       lda tmp3
        jsr Row8
        dex
        bne -
        inc line
        lda line
        cmp tmp4
        bne _fl
        rts

; InitTables: a byte's 8 pixels as two multicolour bytes (ExpL, ExpR: Exp1001's, "10"), the
; middle row's shifted bytes, a page each for shift s (0-3) and byte k (0-2) (ShPg0-ShPg2): a
; shape byte's 8 pixels ("11") shifted right s pixels across 3 bytes
InitTables:
        ldy #0
-       tya
        lsr
        lsr
        lsr
        lsr
        tax
        lda Exp1001,x
        sta ExpL,y
        tya
        and #$0f
        tax
        lda Exp1001,x
        sta ExpR,y
        iny
        bne -
        ldx #0
_s      stx v0                  ; the shift
        txa
        asl
        asl
        asl
        asl
        sta v1                  ; (16 * shift: ShA / ShB's)
        lda #0
        sta ptrB
        sta ptrC
        sta ptrD
        lda ShPg0,x
        sta ptrB+1
        lda ShPg1,x
        sta ptrC+1
        lda ShPg2,x
        sta ptrD+1
        ldy #0
_g      tya                     ; b0 = ShA[hi], b1 = ShB[hi] | ShA[lo], b2 = ShB[lo]
        lsr
        lsr
        lsr
        lsr
        ora v1
        tax
        lda ShA,x
        sta (ptrB),y
        lda ShB,x
        sta tmp
        tya
        and #$0f
        ora v1
        tax
        lda ShA,x
        ora tmp
        sta (ptrC),y
        lda ShB,x
        sta (ptrD),y
        iny
        bne _g
        ldx v0
        inx
        cpx #4
        bne _s
        rts

; (the middle row's, from render.asm: Render runs at CODE_E, which is full)
; R1Init: a buffer's store code skeleton (InitBuffer): for k = 0-2 "lda R1Bk,x" and 5 times
; "sta R1DUMMY,y"; the line done and the loop (R1Exec); rts
R1Init:
        ldx #7                  ; (the zero rows)
        lda #0
-       sta R1B0+8,x
        sta R1B1+8,x
        sta R1B2+8,x
        dex
        bpl -
        ldx rbuf
        lda R1CodeLo,x
        sta ptrC
        lda R1CodeHi,x
        sta ptrC+1
        lda R1CodeBLo,x
        sta ptrD
        lda R1CodeBHi,x
        sta ptrD+1
        ldy #0
        ldx #0                  ; k
_ik     lda #$bd
        jsr _put
        lda R1SrcLo,x
        jsr _put
        lda R1SrcHi,x
        jsr _put
        lda #5
        sta v2
-       lda #$99
        jsr _put
        lda #<R1DUMMY
        jsr _put
        lda #>R1DUMMY
        jsr _put
        dec v2
        bne -
        inx
        cpx #3
        bne _ik
        lda #$e8                ; the line done: inx / iny; block A: cpy #8, block B: cpx tmp3;
        jsr _put                ; bne to the start; rts
        lda #$c8
        jsr _put
        lda #$c0
        sta (ptrC),y
        lda #$e4
        sta (ptrD),y
        iny
        lda #8
        sta (ptrC),y
        lda #<tmp3
        sta (ptrD),y
        iny
        lda #$d0
        jsr _put
        lda #<-60
        jsr _put
        lda #$60
_put    sta (ptrC),y
        sta (ptrD),y
        iny
        rts

; (from render.asm: Render runs at CODE_E, which is full)
; DrawBar: the energy bar's 20 cells (pixels 48-127) on lines 195-199
DrawBar:
        ldx #3                  ; (the cells' bytes worked out already for this bar, $AA-$AD:
-       lda BallPos,x           ; once for all buffers)
        cmp BarK,x
        bne +
        dex
        bpl -
        jmp _bwr
+       ldx #3
-       lda BallPos,x
        sta BarK,x
        dex
        bpl -
        ; each cell: its playfield bit set: the bar's colour ("10"; pixels 48 and 127 are drawn
        ; while COLUPF is the band's: "01"), else the gap ("11", the band's background)
        lda BarPF+2
        and #$01
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+0
        lda BarPF+2
        and #$02
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+1
        lda BarPF+2
        and #$04
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+2
        lda BarPF+2
        and #$08
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+3
        lda BarPF+2
        and #$10
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+4
        lda BarPF+2
        and #$20
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+5
        lda BarPF+2
        and #$40
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+6
        lda BarPF+2
        and #$80
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+7
        lda BarPF+0
        and #$10
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+8
        lda BarPF+0
        and #$20
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+9
        lda BarPF+0
        and #$40
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+10
        lda BarPF+0
        and #$80
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+11
        lda BarPF+1
        and #$80
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+12
        lda BarPF+1
        and #$40
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+13
        lda BarPF+1
        and #$20
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+14
        lda BarPF+1
        and #$10
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+15
        lda BarPF+1
        and #$08
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+16
        lda BarPF+1
        and #$04
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+17
        lda BarPF+1
        and #$02
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+18
        lda BarPF+1
        and #$01
        beq +
        lda #$aa
        bne ++
+       lda #$ff
+       sta BarBytes+19
        lda BarBytes
        cmp #$aa
        bne +
        lda #$6a
        sta BarBytes
+       lda BarBytes+19
        cmp #$aa
        bne +
        lda #$a9
        sta BarBytes+19
+       ; the ball, 4 wide from its pixel, drawn as set: pixels s .. s + 3 of the bar (s = pixel
        ; - 48, -3 to 79 for any in it): cell s / 4 from pixel s & 3 on, the next to before it
        ldx BallPos
        lda XOf,x
        sec
        sbc #1                  ; (from pixel 0: 159, none)
        bcc _nob
        cmp #128
        bcs _nob
        sec
        sbc #48
        sta tmp2                ; s
        bcs _pos
        cmp #<-3
        bcc _nob
        and #3                  ; (s -3 to -1: only cell 0's pixels 0 .. s + 3)
        tay
        ldx #0
        beq _hi
_pos    and #3
        tay
        lda tmp2
        lsr
        lsr
        tax
        lda SetLo,y
        jsr _set
        inx
        cpx #20
        bcs _fix
_hi     lda SetHi,y
        beq _fix
        jsr _set
_fix    lda tmp2                ; pixel 48 in it (s -3 to 0): "01"
        clc
        adc #3
        cmp #4
        bcs +
        lda BarBytes
        and #$3f
        ora #$40
        sta BarBytes
+       lda tmp2                ; pixel 127 (s 76 to 79): "01"
        sec
        sbc #76
        cmp #4
        bcs _nob
        lda BarBytes+19
        and #$fc
        ora #$01
        sta BarBytes+19
_nob    jmp _bwr
_set    sta tmp3                ; (cell X: the pixels in mask A set, "10")
        eor #$ff
        and BarBytes,x
        sta tmp4
        lda tmp3
        and #$aa
        ora tmp4
        sta BarBytes,x
        rts
SetLo:      .byte $ff, $3f, $0f, $03     ; (pixels n .. 3 of a cell)
SetHi:      .byte $00, $c0, $f0, $fc     ; (pixels 0 .. n - 1)

        ; lines 195-199 (in one cell row): the cells this buffer has otherwise
_bwr    ldx rbuf
        ldy BarBase,x
        ldx #0
_bw     lda BarBytes,x
        cmp BarB,y
        bne _bd
_bs     iny
        inx
        cpx #20
        bne _bw
        rts
_bd     sta BarB,y              ; a cell this buffer has otherwise: its 5 lines
        sta tmp
        stx v1
        sty v2
        txa
        clc
        adc #12
        tax
        lda #195
        jsr BmAt
        lda tmp
        ldy #0
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        sta (ptrA),y
        ldx v1
        ldy v2
        jmp _bs
