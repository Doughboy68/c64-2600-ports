@echo off
rem Build Megamania:
rem   build\megamania.a26     the 2600 ROM rebuilt from source (checked against the original)
rem   build\megamania-V.prg   the Commodore 64 version
rem   build\megamania-V.d64   the C64 version on a disk image
rem The original ROM (or its .zip) must be in roms_port\ (found by MD5, any file name).
rem (V: the version in the BASIC listing; file names at most 16 characters: ..\..\tools\buildname.js)
cd /d "%~dp0"
set TASS=..\..\tools\64tass\64tass.exe
set MD5=318a9d6dda791268df92d72679914ac3
if not exist build mkdir build
if not exist 2600\megamania.asm node ..\..\tools\disasm.js . || exit /b 1
set NAME=
for /f %%n in ('node ..\..\tools\buildname.js . megamania') do set NAME=%%n
if "%NAME%"=="" (echo no build name: see tools\buildname.js & exit /b 1)

node ..\..\tools\rom.js %MD5% build\original.a26 >nul || exit /b 1
%TASS% -q --nostart -o build\megamania.a26 2600\megamania.asm || exit /b 1
fc /b build\original.a26 build\megamania.a26 >nul && (echo OK: build\megamania.a26 matches the original ROM) || (echo DIFFERENT: build differs from the original ROM & exit /b 1)

node tools\mkc64tables.js >nul || exit /b 1
del /q build\megamania-*.prg build\megamania-*.d64 build\megamania-*.lst 2>nul
%TASS% -q -C -a -o build\%NAME%.prg -L build\%NAME%.lst c64\main.asm || exit /b 1
echo OK: build\%NAME%.prg


where c1541 >nul 2>&1 || (echo c1541 not found, skipping the disk image & exit /b 0)
if exist build\%NAME%.d64 del build\%NAME%.d64
c1541 -format "megamania,mm" d64 build\%NAME%.d64 -write build\%NAME%.prg "megamania" >nul || exit /b 1
echo OK: build\%NAME%.d64
