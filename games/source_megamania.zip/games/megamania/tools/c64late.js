// Timing in VICE: does the C64 keep up with the 2600's 60 frames a second? Starts its own VICE
// (a monitor port of its own; PAL, or NTSC with --ntsc; warp speed: the emulated timing is the
// same), sets the build's self-playing testing aid (DbgAuto, AutoInput in c64/data.asm: the same
// game whatever the timing, from power-on; a wave cleared every 600 ticks, so later waves come)
// and when its 3600 ticks are done reads what the build counted over them (DbgAutoRes): main-loop
// passes (one picture drawn each), passes that found more than one frame gone by (a picture
// skipped), frame tops, frame tops with no new picture (the last shown again), sprite moves done
// on or after the new sprites' first line. Closes only the VICE it started.
// --from=T: the 3600 ticks counted from tick T (300: waves 0-5; a wave cleared every 600 ticks)
//   node games/megamania/tools/c64late.js [--ntsc] [--from=T] [--png=dir] [--keep] [--nowarp]
const net = require('net');
const fs = require('fs');
const path = require('path');
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
const ntsc = process.argv.includes('--ntsc'), keep = process.argv.includes('--keep');
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const pngDir = opt('png', null);
const build = process.env.MM_BUILD || path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const lst = fs.readFileSync(files.lst, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return parseInt(m[2] || m[1], 16);
};
const hex = n => n.toString(16);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let PORT = 0, vice = null;
const mon = cmds => new Promise((resolve, reject) => {
  const s = net.connect(PORT, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d.toString('latin1'); }); s.on('error', reject);
  s.on('connect', async () => {
    await sleep(150);
    for (const c of cmds) { s.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 400); }
    s.write('x\n'); await sleep(100); s.end(); resolve(b);
  });
});
const dump = async (lo, hi) => {
  const o = await mon([`m ${hex(lo)} ${hex(hi)}`]);
  const mem = {};
  for (const m of o.matchAll(/>C:([0-9a-f]{4})((?:\s+[0-9a-f]{2}\b)+)/gi))
    m[2].trim().split(/\s+/).forEach((x, k) => { mem[parseInt(m[1], 16) + k] = parseInt(x, 16); });
  return mem;
};

(async () => {
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', ...(process.argv.includes('--nowarp') ? [] : ['-warp']),
    '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', files.prg]);
  let ok = false;
  for (let t = 0; t < 40 && !ok; t++) { await sleep(1000); try { ok = await runsOurs(mon, files.prg); } catch { /* not up yet */ } }
  if (!ok) throw new Error(`the VICE on port ${PORT} isn't running ${path.basename(files.prg)}: stopping`);
  await sleep(2000);
  const A = { auto: addr('DbgAuto'), res: addr('DbgAutoRes'), t: addr('AutoT'), power: addr('PowerReq'), from: addr('AutoFrom') };
  const from = +opt('from', 300), to = from + 3600, wd = v => `${hex(v & 255)} ${hex(v >> 8)}`;
  await mon([`> ${hex(A.t)} 0 0`, `> ${hex(A.from)} ${wd(from)} ${wd(to)}`, `> ${hex(A.auto)} 1`, `> ${hex(A.power)} 1`]);
  const t0 = Date.now();
  for (;;) {
    await sleep(3000);
    const m = await dump(A.auto, A.auto);
    if (m[A.auto] === 0x80) break;
    if (Date.now() - t0 > 1200000) throw new Error('the self-playing run never finished');
  }
  const r = await dump(A.res, A.res + 31);
  const w = i => r[A.res + i] + 256 * r[A.res + i + 1], w3 = i => w(i) + 65536 * r[A.res + i + 2];
  const loops = w(0), late = w(2), tops = w(4), repeat = w(6), moveLate = w(8), idle = 15 * w3(10), idleQ = 17 * w3(13);
  const ticks = 3600, frames = ntsc ? ticks : ticks * 5 / 6;
  const ram = await dump(0xde, 0xde);
  const byWave = [...Array(16)].map((_, k) => r[A.res + 16 + k]).map((n, k) => n ? `wave ${k}: ${n}` : '').filter(Boolean).join(', ');
  console.log(`${ntsc ? 'NTSC' : 'PAL'}: ${ticks} ticks in ${tops} frames (${frames} if all on time), ${loops} pictures drawn, ` +
    `${late} passes skipping pictures (${(100 * late / Math.max(1, loops)).toFixed(1)}%), ${repeat} frames with no new picture (${(100 * repeat / Math.max(1, tops)).toFixed(1)}%), ` +
    `${moveLate} sprite moves late; waiting ${Math.round(idle / tops)} + ${Math.round(idleQ / tops)} cycles a frame; wave reached ${ram[0xde]}` + (byWave ? `; no new picture by wave: ${byWave}` : ''));
  if (pngDir) {
    const f = path.resolve(pngDir, `late-${ntsc ? 'ntsc' : 'pal'}.png`);
    await mon([`screenshot "${f.replace(/\\/g, '/')}" 2`]);
  }
  if (keep) console.log(`VICE left running: monitor port ${PORT}, pid ${vice.pid}`);
  else stopVice(vice);
})().catch(e => { console.log(e.message); stopVice(vice); });
