// Trace one frame's TIA writes: line, pixel (colour clock - 68), register, value, PC.
//   node games/megamania/tools/trace.js <frame> [--reset] [--fire] [--from=L] [--to=L] [--regs=GRP0,RESP0]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('318a9d6dda791268df92d72679914ac3'));
vcs.hmoveBlank = true;
const NAMES = ['VSYNC','VBLANK','WSYNC','RSYNC','NUSIZ0','NUSIZ1','COLUP0','COLUP1','COLUPF','COLUBK','CTRLPF','REFP0','REFP1','PF0','PF1','PF2','RESP0','RESP1','RESM0','RESM1','RESBL','AUDC0','AUDC1','AUDF0','AUDF1','AUDV0','AUDV1','GRP0','GRP1','ENAM0','ENAM1','ENABL','HMP0','HMP1','HMM0','HMM1','HMBL','VDELP0','VDELP1','VDELBL','RESMP0','RESMP1','HMOVE','HMCLR','CXCLR'];
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const frame = +process.argv[2];
const from = +opt('from', 0), to = +opt('to', 999);
const regs = opt('regs', '') ? opt('regs').split(',') : null;
if (process.argv.includes('--reset')) { vcs.runFrames(10); vcs.swchb &= ~1; vcs.runFrames(5); vcs.swchb |= 1; }
const fire = process.argv.includes('--fire');
while (vcs.frames < frame) { vcs.fire[0] = fire && (vcs.frames & 8) !== 0; vcs.runFrames(1); }
const orig = vcs.tiaWrite.bind(vcs);
const out = [];
vcs.tiaWrite = (a, v) => {
  const n = NAMES[a] || a.toString(16);
  if (vcs.line >= from && vcs.line <= to && n !== 'WSYNC' && (!regs || regs.includes(n)))
    out.push(`${String(vcs.line).padStart(3)} ${String(vcs.clock - 68).padStart(4)} ${n.padEnd(7)} ${v.toString(16).padStart(2, '0')}  ${vcs.lastPc.toString(16)}  pos ${vcs.pos.join(',')}`);
  orig(a, v);
};
vcs.runFrames(1);
console.log(out.join('\n'));
