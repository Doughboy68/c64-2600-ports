// Draws the C64 frame from what the C64 code set up (the buffer's multicolour bitmap, screen and
// colour RAM; the staged sprites, moved by the raster events down the screen, with the VIC's real
// restart rule: an unexpanded sprite starts again only 22 lines after its last start; sprites
// behind the bitmap's "10" and "11", the lower numbered in front) and compares it, in C64
// colours, with the 2600's picture (tools/vcs.js, its colours mapped by the port's own table),
// over a random game. Runs the C64 code on the 6502 core as lockstep.js does.
//   node games/megamania/tools/screencheck.js [frames] [--seed=N] [--hop=N] [--show=F]
//        [--png=dir (each differing frame, and --show's: 2600 left, C64 right)] [--verbose]
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('318a9d6dda791268df92d72679914ac3');
const build = process.env.MM_BUILD || path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
const cst = name => {   // a constant ("=$c800 ... CODE_C = $c800")
  const m = lst.match(new RegExp(`^=(\\$?)([0-9a-f]+)\\t+${name}\\s+=`, 'm'));
  if (!m) throw new Error('no constant ' + name);
  return parseInt(m[2], m[1] ? 16 : 10);
};
const fileAt = n => parseInt(lst.match(new RegExp(`^\\.([0-9a-f]{4})\\t(?:[0-9a-f]{4}\\t)?[^\\n]*?\\t${n}:`, 'm'))[1], 16);
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 1000);
const verbose = process.argv.includes('--verbose');
const showFrame = arg('show', -1), pngDir = arg('png', null);

class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) { a &= 0xFFFF; if (process.env.MM_WATCH && v && ((a >= 0x4D6A && a < 0x4D80) || (a >= 0x8D6A && a < 0x8D80))) console.log(`write ${a.toString(16)} ${v.toString(16)} at ${this.lastPc.toString(16)}`); this.mem[a] = v; }
  commit() {} flush() {} tick(n) { this.cycles += n; }
  call(addr, limit = 3e6) {
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error('runaway at $' + this.pc.toString(16)); }
  }
}
const c64 = new C64();
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
for (let a = 0xC000; a < cst('CODE_C'); a++) c64.mem[a] = 0;
c64.call(sym('Relocate'));      // (as Start: the program's parts where they run)
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x0C] = 0x80; c64.mem[0x0D] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));
const M = a => c64.mem[a];
const S = {};
for (const n of ['StX', 'StY', 'StCol', 'StMsb', 'StEn', 'StBg', 'StPtr', 'EvLine', 'EvType', 'EvArg', 'MvX', 'MvY', 'MvMsb', 'MvEn', 'MvPtr',
  'curBuf', 'rbuf', 'ColorMap']) S[n] = sym(n);
const NEV = 8, LINEOFS = 9, SPRYOFS = 8;
const NBUF = cst('NBUF'), byBuf = n => [...Array(NBUF)].map((_, b) => c64.mem[sym(n) + b]);
const BMHI = byBuf('BmHiOf'), SCRHI = byBuf('ScrHiOf'), BANK = byBuf('BankBits').map(v => (3 - v) * 0x4000);
const EV = { TOP: 0, MOVEA: 1, MOVEB: 2, END: 3 };

const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
const AFTER = 0xF639;
const runTick = () => { let g = 0; do { vcs.step(); if (++g > 2e6) throw new Error('2600 never got through a frame'); } while (vcs.pc !== AFTER); };

// The C64 picture of buffer `buf`: a C64 colour per 2600 pixel, lines 42-241; and what drew it
// ('b0'-'b3' the bitmap's classes, 's0'-'s7' sprites)
function c64Picture(buf) {
  const col = new Uint8Array(160 * 264), src = new Array(160 * 264).fill('');
  const bm = BMHI[buf] << 8, scr = SCRHI[buf] << 8, bank = BANK[buf];
  const bg = M(S.StBg + buf) & 15;
  // the sprites at the frame top
  const sp = [...Array(8)].map((_, n) => ({
    x: M(S.StX + 8 * buf + n) + ((M(S.StMsb + buf) >> n) & 1) * 256, y: M(S.StY + 8 * buf + n), col: M(S.StCol + 8 * buf + n) & 15,
    en: (M(S.StEn + buf) >> n) & 1, ptr: n < 3 ? M(S.StPtr + buf) : M(scr + 0x3F8 + n), start: -100, row: -1,
  }));
  // the events after the top: [raster, apply()]
  const evs = [];
  for (let i = 1; i < NEV; i++) {
    const e = NEV * buf + i, t = M(S.EvType + e), line = M(S.EvLine + e), a = M(S.EvArg + e);
    if (t === EV.END) break;
    if (t === EV.MOVEA || t === EV.MOVEB) {
      const n = t === EV.MOVEA ? 5 : 3, mask = (1 << n) - 1;
      evs.push([line, () => {
        for (let k = 0; k < n; k++) {
          sp[k].x = M(S.MvX + 5 * a + k) + ((M(S.MvMsb + a) >> k) & 1) * 256;
          sp[k].y = M(S.MvY + a);
          sp[k].en = (M(S.MvEn + a) >> k) & 1;
          if (t === EV.MOVEB) sp[k].ptr = M(S.MvPtr + a);
        }
      }]);
    }
  }
  let ei = 0;
  for (let L = 21; L <= 241; L++) {     // (sprites may start above the picture)
    const raster = L + LINEOFS;
    // events whose raster line came before this line's Y compare (a line ahead at least)
    while (ei < evs.length && evs[ei][0] < raster - 1) evs[ei++][1]();
    // sprite starts: the Y compare on the line before (raster - 1); a running sprite (21 lines)
    // can't start again until 22 lines after its start
    for (const s of sp) {
      if (s.en && s.y === raster - 1 && (s.start < 0 || raster - s.start >= 22)) { s.start = raster; s.row = 0; }
      else if (s.start >= 0 && raster - s.start < 21) s.row = raster - s.start; else s.row = -1;
    }
    if (L < 42) continue;
    const b = L - 42, rowOff = (b >> 3) * 320 + (b & 7), cell = (b >> 3) * 40;
    for (let x = 0; x < 160; x++) {
      const c = x >> 2;
      const byte = M(bm + rowOff + c * 8);
      const cls = (byte >> (6 - 2 * (x & 3))) & 3;
      const sb = M(scr + cell + c);
      let colour = cls === 0 ? bg : cls === 1 ? sb >> 4 : cls === 2 ? sb & 15 : M(0xD800 + cell + c) & 15;
      let who = 'b' + cls;
      if (cls < 2) {     // sprites show over "00" and "01" only (all behind the foreground)
        for (let n = 0; n < 8; n++) {
          const s = sp[n];
          if (s.row < 0) continue;
          const sx = (s.x - 24) / 2;           // (X-expanded: a sprite pixel is a 2600 pixel)
          const d = x - sx;
          if (d < 0 || d >= 24) continue;
          const data = M(bank + s.ptr * 64 + s.row * 3 + (d >> 3));
          if ((data >> (7 - (d & 7))) & 1) { colour = s.col; who = 's' + n; break; }
        }
      }
      col[L * 160 + x] = colour; src[L * 160 + x] = who;
    }
  }
  return { col, src };
}

const play = require('./play')(arg('seed', 1), { hop: arg('hop', 1000) });
const poke = (a, v) => { vcs.ram[a - 0x80] = v; c64.mem[a] = v; };
let bad = 0, done = 0;
const byWho = {};
const png = (file, a, b) => {
  const W = 160 * 2 * 2 + 8, H = 200 * 2, PAL = ['000000','FFFFFF','96282E','5BD6CE','9F2DAD','41B936','2724C4','EFF347','9F4815','5E3500','DA5F66','474747','787878','91FF84','6864FF','AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
  const raw = Buffer.alloc((W * 3 + 1) * H);
  for (let y = 0; y < H; y++) {
    raw[y * (W * 3 + 1)] = 0;
    for (let x = 0; x < W; x++) {
      const L = 42 + (y >> 1), side = x < 320 ? a : x >= 328 ? b : null, px = x < 320 ? x >> 1 : (x - 328) >> 1;
      const c = side ? PAL[side[L * 160 + Math.min(159, px)]] : [128, 0, 128];
      raw.set(c, y * (W * 3 + 1) + 1 + x * 3);
    }
  }
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const cr = Buffer.alloc(4); let c = -1; for (const v of td) { c ^= v; for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xEDB88320 & -(c & 1)); } cr.writeUInt32BE((c ^ -1) >>> 0); return Buffer.concat([l, td, cr]); };
  const ih = Buffer.alloc(13); ih.writeUInt32BE(W, 0); ih.writeUInt32BE(H, 4); ih[8] = 8; ih[9] = 2;
  fs.writeFileSync(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
};
for (let f = 0; f < frames; f++) {
  play.step(vcs, f > 0 ? poke : null);
  c64.mem[0x0280] = vcs.swcha; c64.mem[0x0C] = vcs.fire[0] ? 0 : 0x80; c64.mem[0x0D] = vcs.fire[1] ? 0 : 0x80; c64.mem[0x0282] = vcs.swchb;
  runTick();
  c64.call(sym('Tick'));
  c64.call(sym('Render'));
  const rb = M(S.rbuf);
  c64.mem[S.curBuf] = rb;
  for (let a = 0x80; a < 0x100; a++) c64.mem[a] = vcs.ram[a - 0x80];   // (lockstep's job: keep going whatever)
  if (f < 3) continue;
  done++;
  // the 2600's picture of this frame (vcs.js drew it during runTick), in C64 colours
  const want = new Uint8Array(160 * 264);
  for (let L = 42; L <= 241; L++) for (let x = 0; x < 160; x++) want[L * 160 + x] = L <= 233 ? M(S.ColorMap + vcs.fb[L * 160 + x]) & 15 : 0;
  { // the logo's pixel 28 (its first byte's last): vcs.js shows the third byte's there (a GRP1 write
    // landing on it), Stella and the real TIA the first byte's own (tools/stellacheck.js)
    const y0 = M(sym('LogoY0')), lc = M(S.ColorMap + (((0x16 ^ vcs.ram[6]) & vcs.ram[7]) >> 1)) & 15;
    for (let i = 0; i < 8; i++) { const L = 225 + i; want[L * 160 + 28] = c64.mem[0xFC80 + ((y0 - i) & 255)] & 1 ? lc : want[L * 160 + 20]; }
  }
  const got = c64Picture(rb);
  if (arg('sprites', -1) === f) {     // --sprites=F: that frame's staged sprites
    const scr = SCRHI[rb] << 8;
    console.log(`frame ${f} buffer ${rb}: enable ${M(S.StEn + rb).toString(2)} msb ${M(S.StMsb + rb).toString(2)}; ` + [...Array(8)].map((_, n) =>
      `${n}: x ${M(S.StX + 8 * rb + n)} y ${M(S.StY + 8 * rb + n)} col ${M(S.StCol + 8 * rb + n)} ptr ${M(scr + 0x3F8 + n)}`).join('; '));
    for (const blk of [53, 54, 55]) console.log(`  block ${blk}: ` + [...Array(21)].map((_, r) => M(BANK[rb] + blk * 64 + r * 3).toString(16)).join(' '));
    console.log(`  $A9 ${vcs.ram[0xA9 - 0x80]} shape ${(vcs.ram[0xB0 - 0x80] * 256 + vcs.ram[0xAF - 0x80]).toString(16)}`);
  }
  const diffs = [];
  for (let L = 42; L <= 241; L++) for (let x = 0; x < 160; x++) if (want[L * 160 + x] !== got.col[L * 160 + x]) diffs.push([L, x]);
  if (diffs.length) {
    bad++;
    for (const [L, x] of diffs) { const k = got.src[L * 160 + x] + (vcs.ob[L * 160 + x] ? ':o' + vcs.ob[L * 160 + x] : ''); byWho[k] = (byWho[k] || 0) + 1; }
    if (bad <= 5 || verbose) console.log(`frame ${f} (wave ${vcs.ram[0xDE - 0x80]}): ${diffs.length} pixels differ; first at ` + diffs.slice(0, 6).map(([L, x]) => `(${x},${L}) 2600 ${want[L * 160 + x]} C64 ${got.col[L * 160 + x]} ${got.src[L * 160 + x]}`).join(' '));
    if (pngDir && bad <= 20) { fs.mkdirSync(pngDir, { recursive: true }); png(path.join(pngDir, `f${f}.png`), want, got.col); }
  }
  if (f === showFrame && pngDir) { fs.mkdirSync(pngDir, { recursive: true }); png(path.join(pngDir, `show${f}.png`), want, got.col); }
}
console.log(`${done} frames, ${bad} with differences; by source: ${Object.entries(byWho).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([k, v]) => k + ' ' + v).join(', ')}`);
process.exit(bad ? 1 : 0);
