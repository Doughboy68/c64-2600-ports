// The whole C64 program on the 6502 core of tools/vcs.js, as the C64 runs it: from Start (BASIC's
// SYS), the raster interrupt driven by a raster counter (63 cycles a line, 312 lines on PAL; 65
// and 263 on NTSC; no badlines or sprite DMA), I/O at $D000-$DFFF when $01 says so, the joystick
// and fire button through the testing aids. Stops at the first sign of a crash: a BRK, the stack
// running low, $01 changed, the CPU outside our code.
// --auto: the build's self-playing game (AutoInput, as tools/c64late.js plays it in VICE), from
// power-on, ticks --from=T on (default 300); --wave=N: the cycles each routine took in wave N
// (main loop and interrupts, idle loops left out), per frame; --spikes=C: frames whose work was
// more than C cycles, what they spent it on
//   node games/megamania/tools/c64run.js [frames] [--ntsc] [--fire=F,F...] [--moves] [--auto [--from=T] [--wave=N]]
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('318a9d6dda791268df92d72679914ac3');
const files = require('../../../tools/buildname').files(path.join(__dirname, '..', 'build'));
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? a.split('=')[1] : d; };
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 600);
const ntsc = process.argv.includes('--ntsc');
const CYC = ntsc ? 65 : 63, LINES = ntsc ? 263 : 312;
const labels = [...lst.matchAll(/^\.([0-9a-f]{4})\t(?:([0-9a-f]{4})\t)?.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[2] || m[1], 16), m[3]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xF000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };

class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); this.io = new Uint8Array(4096); this.raster = 0; this.lineCyc = 0; this.irqLatch = 0; }
  ioOn() { return (this.mem[1] & 3) !== 0 && (this.mem[1] & 4) !== 0; }
  read(a) {
    a &= 0xFFFF;
    if (a >= 0xD000 && a < 0xE000 && this.ioOn()) {
      const r = a & 0xFFF;
      if (r === 0x012) return this.raster & 255;
      if (r === 0x011) return (this.io[0x11] & 0x7F) | ((this.raster >> 1) & 0x80);
      if (r === 0x019) return this.irqLatch | 0x70;
      if (r === 0xC00 || r === 0xC01) return 0xFF;   // (no keys, no joysticks: the testing aids drive the game)
      return this.io[r];
    }
    return this.mem[a];
  }
  write(a, v) {
    a &= 0xFFFF;
    if (a === 1 && v !== 0x35 && this.started) throw new Error(`$01 written: ${v.toString(16)} at $${this.pc.toString(16)} (${labelOf(this.lastPc)})`);
    if (a >= 0xD000 && a < 0xE000 && this.ioOn()) {
      const r = a & 0xFFF;
      if (r === 0x019) { this.irqLatch &= ~v & 0x0F; return; }
      if (r === 0xD0E && (v & 1) && (this.io[0xD0D] & 1)) this.nmiPending = true;   // (CIA 2's timer: an NMI)
      this.io[r] = v; return;
    }
    this.mem[a] = v;
  }
  commit() {} flush() {}
  tick(n) {
    this.cycles += n;
    this.lineCyc += n;
    while (this.lineCyc >= CYC) {
      this.lineCyc -= CYC;
      this.raster = (this.raster + 1) % LINES;
      const cmp = this.io[0x12] | ((this.io[0x11] & 0x80) << 1);
      if (this.raster === cmp) this.irqLatch |= 1;
    }
  }
}
const c = new C64();
c.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c.mem[1] = 0x37;
c.s = 0xFF;
c.pc = sym('Start');
// our code: in place from $0801 (before buffer 2's bitmap), and the parts Start copies elsewhere
const CODE = [[0x0801, 0x2000], [0xE000, sym('ImgEEnd')], [0xC800, sym('ImgCEnd')], [0x4400, sym('Img4End')]];
let lastFrame = -1, frame = 0;
const A_MAIN = sym('MainLoop'), A_TOPS = sym('DbgTops'), A_FIRE = sym('DbgINPT4'), A_SWCHA = sym('DbgSWCHA');
const fireAt = (arg('fire', '200,400') + '').split(',').map(Number);
const ring = [];
const auto = process.argv.includes('--auto'), profWave = +arg('wave', -1), prof = {};
let profFrames = 0, profTop = -1;
const spikes = +arg('spikes', 0), spP = {};
let spW = 0, spTop = -1;
const IDLE = new Set(['MainLoop']);
const autoFrom = +arg('from', 300);
try {
  for (let i = 0; ; i++) {
    if (c.nmiPending) {
      c.nmiPending = false;
      c.push(c.pc >> 8); c.push(c.pc & 255); c.push((c.p & 0xEF) | 0x20);
      c.p |= 4;
      c.pc = c.mem[0xFFFA] | (c.mem[0xFFFB] << 8);
    }
    // the raster interrupt
    if ((c.irqLatch & 1) && (c.io[0x1A] & 1) && !(c.p & 4)) {
      c.push(c.pc >> 8); c.push(c.pc & 255); c.push((c.p & 0xEF) | 0x20);
      c.p |= 4;
      c.pc = c.mem[0xFFFE] | (c.mem[0xFFFF] << 8);
    }
    const pc = c.pc;
    ring[i & 63] = pc;
    if (pc === A_MAIN) c.started = true;
    const inCode = CODE.some(([lo, hi]) => pc >= lo && pc < hi) || pc >= 0xF000;
    if (c.started && !inCode) throw new Error(`the CPU at $${pc.toString(16)} (outside our code)`);
    if (auto && c.started && !c.autoOn) { c.autoOn = true; c.mem[sym('DbgAuto')] = 1; c.mem[sym('PowerReq')] = 1; c.mem[sym('AutoT')] = 0; c.mem[sym('AutoT') + 1] = 0;
      const A = sym('AutoFrom'), to = autoFrom + 3600;   // (as c64late: the counters from tick --from)
      c.mem[A] = autoFrom & 255; c.mem[A + 1] = autoFrom >> 8; c.mem[A + 2] = to & 255; c.mem[A + 3] = to >> 8; }
    if (c.started && c.s < 0xC0) throw new Error(`the stack low: $${c.s.toString(16)} at $${pc.toString(16)} (${labelOf(pc)})`);
    const cyc0 = c.cycles;
    c.step();
    if (spikes && c.started) {   // (--spikes: the work between frame tops, idle loops left out)
      const k = labelOf(pc);
      if (!IDLE.has(k)) { spW += c.cycles - cyc0; spP[k] = (spP[k] || 0) + c.cycles - cyc0; }
      const t = c.mem[A_TOPS] | (c.mem[A_TOPS + 1] << 8);
      if (t !== spTop) {
        if (spW > spikes) console.log(`tick ${c.mem[sym('AutoT')] | (c.mem[sym('AutoT') + 1] << 8)} wave ${c.mem[0xDE]}: ${spW}: ` + Object.entries(spP).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([q, v]) => q + ' ' + v).join(', '));
        spTop = t; spW = 0; for (const q in spP) delete spP[q];
      }
    }
    if (profWave >= 0 && c.mem[0xDE] === profWave && c.mem[sym('DbgAuto')] === 1) {
      const k = labelOf(pc);
      if (!IDLE.has(k)) prof[k] = (prof[k] || 0) + c.cycles - cyc0;
      const t = c.mem[A_TOPS] | (c.mem[A_TOPS + 1] << 8);
      if (t !== profTop) { profTop = t; profFrames++; }
    }
    // frames by the frame top's count; inputs then
    const tops = c.mem[A_TOPS] | (c.mem[A_TOPS + 1] << 8);   // (counted here: the build's count only once started, reset by the self-play)
    if (c.started && tops !== lastFrame) {
      lastFrame = tops; frame++;
      if (!auto) c.mem[A_FIRE] = fireAt.some(f => frame >= f && frame < f + 5) ? 0x7F : 0xFF;
      if (process.argv.includes('--moves') && !auto) c.mem[A_SWCHA] = [0x7F, 0xBF, 0xFF][Math.floor(frame / 60) % 3];
      if (process.argv.includes('--progress') && frame % 1000 === 0) console.log(frame, 'AutoT', c.mem[sym('AutoT')] | (c.mem[sym('AutoT') + 1] << 8), 'wave', c.mem[0xDE], 'DA', c.mem[0xDA].toString(16), 'D9', c.mem[0xD9].toString(16));
      if (frame >= frames) break;
    }
  }
  if (profFrames) {
    const tot = Object.values(prof).reduce((a, b) => a + b, 0);
    console.log(`wave ${profWave}: ${profFrames} frames, ${Math.round(tot / profFrames)} cycles a frame (no idle loops; no badlines or sprite DMA here):`);
    for (const [k, v] of Object.entries(prof).sort((a, b) => b[1] - a[1]).slice(0, 30)) console.log('  ' + k.padEnd(18) + Math.round(v / profFrames));
  }
  const W = n => c.mem[sym(n)] | (c.mem[sym(n) + 1] << 8);
  if (auto) console.log('AutoT', c.mem[sym('AutoT')] | (c.mem[sym('AutoT') + 1] << 8), 'DbgAuto', c.mem[sym('DbgAuto')], 'AutoHop', c.mem[sym('AutoHop')] | (c.mem[sym('AutoHop') + 1] << 8));
  console.log(`${frame} frames: main loop passes ${W('DbgLoops')}, skipping pictures ${W('DbgLate')}, frame tops with no new picture ${W('DbgRepeat')}; ` +
    `2600 $81 ${c.mem[0x81].toString(16)} $DA ${c.mem[0xDA].toString(16)} $DE ${c.mem[0xDE].toString(16)}`);
} catch (e) {
  console.log(`frame ${frame}: ${e.message}`);
  console.log('last PCs: ' + [...Array(64)].map((_, k) => ring[(c.cycles + k) & 63]).filter(Boolean).map(p => p.toString(16) + ' ' + labelOf(p)).slice(-24).join(', '));
  console.log(`A ${c.a.toString(16)} X ${c.x.toString(16)} Y ${c.y.toString(16)} S ${c.s.toString(16)} P ${c.p.toString(16)}`);
  process.exit(1);
}
