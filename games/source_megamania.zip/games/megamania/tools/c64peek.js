// Start the C64 build in VICE (our own, on a monitor port of its own), let it run, then show the
// CPU's registers and memory (the 2600's RAM, our counters, any address range asked for), and
// close that VICE (only that one).
//   node games/megamania/tools/c64peek.js [--ntsc] [--wait=ms] [--fire] [m:ADDR-ADDR ...]
const fs = require('fs');
const net = require('net');
const path = require('path');
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
const files = require('../../../tools/buildname').files(path.join(__dirname, '..', 'build'));
const prg = files.prg;
const lst = fs.readFileSync(files.lst, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return parseInt(m[2] || m[1], 16);
};
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
let PORT = 0, vice = null;
function mon(cmds) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(PORT, '127.0.0.1');
    let buf = '';
    sock.on('data', d => { buf += d.toString('latin1'); });
    sock.on('error', reject);
    sock.on('connect', async () => {
      await sleep(150);
      for (const c of cmds) { sock.write(c + '\n'); await sleep(300); }
      sock.write('x\n');
      await sleep(100);
      sock.end();
      resolve(buf.replace(/\(C:\$[0-9a-f]{4}\) /g, ''));
    });
  });
}
(async () => {
  PORT = await freePort();
  vice = startVice(['-default', ...(process.argv.includes('--ntsc') ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress',
    `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prg]);
  let ok = false;
  for (let t = 0; t < 30 && !ok; t++) { await sleep(1000); try { ok = await runsOurs(mon, prg); } catch { /* not up yet */ } }
  if (!ok) { console.log('VICE not running our build'); stopVice(vice); return; }
  await sleep(+opt('wait', 4000));
  if (process.argv.includes('--fire')) { await mon([`> ${addr('DbgINPT4').toString(16)} 7f`]); await sleep(500); await mon([`> ${addr('DbgINPT4').toString(16)} ff`]); await sleep(2000); }
  const h = a => a.toString(16).padStart(4, '0');
  const ranges = process.argv.filter(a => a.startsWith('m:')).map(a => a.slice(2).split('-'));
  const cmds = ['r', 'm 0040 007f', 'm 0080 00ff', `m ${h(addr('DbgLoops'))} ${h(addr('DbgLoops') + 15)}`, ...ranges.map(([a, b]) => `m ${a} ${b}`)];
  console.log(await mon(cmds));
  stopVice(vice);
})().catch(e => { console.log(e.message); stopVice(vice); });
