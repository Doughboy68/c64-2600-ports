// Quick runner: boot the ROM, optionally press Game Reset, step frames, save a screenshot.
//   node games/megamania/tools/run.js <frames> [out.png] [--reset] [--fire] [--right=N]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('318a9d6dda791268df92d72679914ac3'));
vcs.hmoveBlank = true;
let lines = 0;
vcs.onFrame = v => { lines = v.line; };
const frames = +(process.argv[2] || 60);
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
if (process.argv.includes('--reset')) {
  vcs.runFrames(10);
  vcs.swchb &= ~1; vcs.runFrames(5); vcs.swchb |= 1;   // press and release Game Reset
}
const right = +opt('right', 0);
if (right) { vcs.swcha = 0x7F; vcs.runFrames(right); vcs.swcha = 0xFF; }
if (process.argv.includes('--fire')) { for (let i = 0; i < frames; i++) { vcs.fire[0] = (i & 8) !== 0; vcs.runFrames(1); } }
else vcs.runFrames(frames);
console.log('frames', vcs.frames, 'lines/frame', lines, 'cycles', vcs.cycles);
const hex = b => [...b].map(x => x.toString(16).padStart(2, '0')).join(' ');
for (let i = 0; i < 128; i += 16) console.log((0x80 + i).toString(16), hex(vcs.ram.subarray(i, i + 16)));
if (process.argv[3] && !process.argv[3].startsWith('--')) { vcs.cropTop = 0; vcs.cropHeight = 262; vcs.savePNG(process.argv[3]); console.log('saved', process.argv[3]); }
