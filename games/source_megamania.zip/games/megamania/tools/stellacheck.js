// Compare tools/vcs.js's picture with Stella's (the reference for the real 2600): play a game
// in vcs.js with tools/play.js, then replay the same inputs in Stella's debugger (a script:
// joystick and switches each frame, a snapshot every few frames) and compare the pictures
// line by line. The palettes differ, so each frame's colours are matched by majority.
// Stella runs with a base folder of its own in the scratchpad (the user's settings untouched)
// and only the Stella started here is closed.
// (from games/missile-command/tools/stellacheck.js)
//   node games/megamania/tools/stellacheck.js [frames] [--every=N] [--seed=N] [--first=F]
//        [--model] [--out=dir] [--verbose]
// vcs.js runs with wideDelay and respDelay (--nowide / --noresp: without); --model compares
// model.js's picture instead.
// --shift=N: Stella runs N frames before the inputs start (negative: vcs.js does).
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const { VCS } = require('../../../tools/vcs');
const ROMMD5 = require('../2600/symbols.js').game.md5;
const rom = require('../../../tools/rom').load(ROMMD5);
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 1200);
const every = arg('every', 50);
const verbose = process.argv.includes('--verbose');
const STELLA = arg('stella', 'C:/Program Files/Stella/Stella.exe');
const work = path.resolve(arg('out', path.join(os.tmpdir(), 'mm-stellacheck')));
const snapDir = path.join(work, 'snaps-' + Date.now());
fs.mkdirSync(path.join(work, 'base'), { recursive: true });
fs.mkdirSync(snapDir, { recursive: true });
fs.writeFileSync(path.join(work, 'mm.a26'), rom);

// ---- the game in vcs.js: inputs per frame, pictures at the snapshot frames
const v = new VCS(rom);
v.hmoveBlank = true;
v.wideDelay = !process.argv.includes('--nowide');
v.respDelay = !process.argv.includes('--noresp');
const useModel = process.argv.includes('--model');
const model = useModel ? require('./model') : null;
let snapState = null, snapFrame = -1;
if (useModel) { const st = v.step.bind(v); v.step = function () { if (this.pc === model.KERNEL && this.frames !== snapFrame) { snapState = model.snap(this); snapFrame = this.frames; } return st(); }; }
const player = require('./play')(arg('seed', 3), { hop: 1e9 });
const play = (f, ram, vcs) => { player.step(vcs, null); return { swcha: vcs.swcha, swchb: vcs.swchb, fire: !!vcs.fire[0] }; };
const script = [];
const shift = arg('shift', 0);
const INV = true;      // Stella's joystick values: 0 = pressed, 1 = released
for (let k = 0; k < shift; k++) script.push('frame 1');
for (let k = 0; k < -shift; k++) v.runFrames(1);
const want = [];                 // frames to compare: their vcs pictures
let last = { up: 0, down: 0, left: 0, right: 0, fire: 0, swchb: -1 };
for (let f = 0; f < frames; f++) {
  const p = play(f, v.ram, v);
  const cur = { up: +!(p.swcha & 0x10), down: +!(p.swcha & 0x20), left: +!(p.swcha & 0x40), right: +!(p.swcha & 0x80), fire: +p.fire, swchb: p.swchb };
  for (const k of ['up', 'down', 'left', 'right', 'fire']) if (cur[k] !== last[k]) script.push(`joy0${k[0].toUpperCase()}${k.slice(1)} ${INV ? 1 - cur[k] : cur[k]}`);
  if (cur.swchb !== last.swchb) script.push(`swchb $${cur.swchb.toString(16).padStart(2, "0")}`);
  last = cur;
  v.swcha = p.swcha; v.swchb = p.swchb; v.fire[0] = v.fire[1] = p.fire;
  v.runFrames(1);
  script.push('frame 1');
  if (f >= arg('first', 150) && f % every === 0) {
    script.push('saveSnap');
    want.push({ f, fb: useModel ? model.render(snapState).fb.slice() : v.fb.slice() });
  }
}
fs.writeFileSync(path.join(work, 'base', 'autoexec.script'), script.join('\r\n') + '\r\n');

// ---- Stella
const PAL = require('../../../tools/vcs').PALETTE;
(async () => {
  const child = spawn(STELLA, ['-basedir', path.join(work, 'base'), '-snapsavedir', snapDir, '-debug', path.join(work, 'mm.a26')], { stdio: 'ignore' });
  const t0 = Date.now();
  for (;;) {
    await new Promise(r => setTimeout(r, 1000));
    const n = fs.readdirSync(snapDir).length;
    if (n >= want.length) { await new Promise(r => setTimeout(r, 1000)); break; }
    if (Date.now() - t0 > 120000) { console.log(`only ${n} of ${want.length} snapshots after 2 minutes`); break; }
  }
  try { child.kill(); } catch { /* gone */ }
  const files = fs.readdirSync(snapDir).map(n => path.join(snapDir, n)).sort((a, b) => fs.statSync(a).mtimeMs - fs.statSync(b).mtimeMs);
  const read = require('../../missile-command/tools/pngread');
  let badFrames = 0;
  files.forEach((file, i) => {
    const w = want[i]; if (!w) return;
    const img = read(file);
    // line L of the 2600 = snapshot row L - OFS (Stella shows lines OFS on): find OFS by best match
    let best = null;
    for (let ofs = 20; ofs <= 30; ofs++) {
      const map = new Map(), counts = new Map();
      for (let L = 41; L <= 238; L++) { const row = L - ofs; if (row < 0 || row >= img.h) continue;
        for (let x = 0; x < 160; x++) { const k = w.fb[L * 160 + x] + ':' + img.px(2 * x, row).join(','); counts.set(k, (counts.get(k) || 0) + 1); } }
      for (const [k, n] of counts) { const [c, s] = k.split(':'); if (!map.has(c) || map.get(c).n < n) map.set(c, { s, n }); }
      let bad = 0; const diffs = [];
      for (let L = 41; L <= 238; L++) { const row = L - ofs; if (row < 0 || row >= img.h) continue;
        for (let x = 0; x < 160; x++) { const s = img.px(2 * x, row).join(','); if (map.get(String(w.fb[L * 160 + x])).s !== s) { bad++; if (diffs.length < 400) diffs.push([L, x, w.fb[L * 160 + x], s]); } } }
      if (!best || bad < best.bad) best = { ofs, bad, diffs };
    }
    if (best.bad) badFrames++;
    // differing pixels as runs per line
    const runs = [];
    for (const [L, x] of best.diffs) { const r = runs[runs.length - 1]; if (r && r.L === L && r.x1 === x - 1) r.x1 = x; else runs.push({ L, x0: x, x1: x, c: best.diffs.find(d => d[0] === L && d[1] === x) }); }
    console.log(`frame ${w.f}: ${best.bad} pixels differ (Stella row = line - ${best.ofs})` + (best.bad ? ': ' + runs.slice(0, verbose ? 40 : 8).map(r => `line ${r.L} px ${r.x0}-${r.x1}` + (verbose ? ` (vcs ${(r.c[2] * 2).toString(16)} Stella ${r.c[3]})` : "")).join(', ') : ''));
  });
  console.log(`${files.length} snapshots, ${badFrames} with differences`);
})();
