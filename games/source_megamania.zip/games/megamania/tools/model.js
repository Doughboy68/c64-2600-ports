// A model of what Megamania's kernel draws, built only from RAM (and the ROM's tables), checked
// pixel by pixel against tools/vcs.js over random games: which objects draw each pixel, their
// colours, the collisions the game reads, and the RAM the kernel leaves behind. The C64 version
// draws and collides by the same rules, so this is where its geometry is worked out and proven.
//   node games/megamania/tools/model.js [frames] [--seed=N] [--verbose] [--show=frame]
//
// The kernel is transcribed instruction by instruction (cycle counts, branches, page crossings):
// each TIA write lands on its line and pixel, each collision read happens where the code reads.
// 2600 lines as tools/vcs.js counts them (from the end of VSYNC): the picture is lines 42-233.
// Every line starts with an HMOVE, so its first 8 pixels are blank (nothing drawn, no collisions).
//
// Two kernels, chosen by bit 0 of the wave ($DE):
//   even waves (1st, 3rd, ...): three rows of enemies, each row player 0 and player 1 with copies
//     (NUSIZ 0/2/4/6), 14 lines a row (5 set-up lines, 9 drawn), from line 188 - $A1;
//     the bombs are missiles 0 and 1 (copied with their players' NUSIZ inside the rows!),
//     the laser is the ball; then the ship (player 1, 21 lines) from 2600 line ~167.
//   odd waves: six rows of player 0 (copies), 29 lines a row (4 set-up, 25 drawn: the shape
//     masked by a diamond), the top row $A9+1 lines; the ship (player 1) drawn among them at the
//     bottom; one bomb (missile 1), the laser (the ball).
// Then (both): the energy bar (playfield, ball 4 wide, "ENERGY" in players 0/1), the ships left,
// the score (six digits, VDEL), the Activision logo (or the copyright line, scrolling by $DA).
'use strict';
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('318a9d6dda791268df92d72679914ac3');
const T = a => rom[(a & 0xFFFF) - 0xF000];
const P0 = 1, P1 = 2, M0 = 4, M1 = 8, BL = 16, PF = 32;
const sgn = h => (h < 8 ? h : h - 16);          // an HM nibble: moves left by this much
const LINES = 264;

// LF81: X position -> coarse count (Y) and fine motion (A: high nibble)
function posOf(x) {
  const y0 = (x + 0x2E) & 0xFF;
  let c = y0 >> 4, a = (y0 & 15) + c;
  if (a >= 15) { a -= 15; c++; }
  return { coarse: c, fine: ((a ^ 7) << 4) & 0xF0 };
}
const add160 = (a, b) => { let s = a + b; if (s >= 0xA0) s -= 0xA0; return s & 0xFF; };   // (LFBDA with carry clear)

// The vertical blank's work for the kernel (F04B-F0F8, F0FA-F11B): the rows' coarse/fine bytes
// $BE-$C3, copies $C6-$C8, X positions $CC-$D1 come from the logic's RAM; we take them from
// RAM as the kernel finds them (the snapshot is taken at the kernel's start, F138).

// ------------------------------------------------------------------ the kernel, transcribed
// Returns { ev: per line [pixel, register, value] (pixel = colour clock - 68 when the write
// lands), reads: [{line, px, reg, pc}], kram: RAM bytes the kernel leaves }.
function kernel(ram) {
  const R = a => ram[a - 0x80];
  const ev = []; for (let l = 0; l < LINES; l++) ev.push([]);
  const reads = [];
  const kram = {};
  let line = 42, c = 0;
  const t = n => { c += n; };
  const st = (reg, v, n = 3) => { c += n; if (c > 76) throw new Error(`line ${line}: store past the line end (${c})`); ev[line].push([3 * c - 68, reg, v & 0xFF]); };
  const rd = (reg, pc, n = 3) => { reads.push({ line, px: 3 * c - 68, reg, pc }); c += n; };
  const wsync = () => { c += 3; if (c > 76) throw new Error(`line ${line}: WSYNC past the line end (${c})`); line++; c = 0; };
  const br = (taken, cross = false) => { c += taken ? (cross ? 4 : 3) : 2; return taken; };
  const hmove = () => { st('HMOVE', 0); };
  const ind = (ptr, y) => { const base = R(ptr) | (R(ptr + 1) << 8); return { v: T((base + y) & 0xFFFF), cross: ((base & 0xFF) + y) > 0xFF }; };
  // the coarse delay loop: X/Y = n, dex/dey + bpl until negative: 5n + 4 cycles
  const loop = n => t(5 * n + 4);

  const mode = R(0xDE) & 1;
  // line 42 (F13D's WSYNC ended line 41)
  hmove(); st('VBLANK', 0); st('NUSIZ1', 0); wsync();
  // line 43
  hmove(); t(3); st('COLUBK', R(0x88)); t(3); st('COLUPF', R(0x8A)); t(3); t(2);
  let X;
  if (mode === 0) {
    br(true);                                     // bcc F159
    t(2); X = 0x8F; wsync();
    // F15B: lines until X < $A1, the ball from X - $F9
    for (;;) {
      hmove(); X = (X - 1) & 0xFF; t(2 + 2 + 2 + 3 + 2);
      const on = ((X - R(0xF9)) & 0xF8) === 0;
      br(!on); if (on) t(2); st('ENABL', on ? 2 : 0);
      t(3);                                       // cpx $A1
      if (br(X >= R(0xA1))) { wsync(); continue; }
      break;
    }
    t(2);                                         // ldy #2
    let A2 = 0, A3 = 0, A4 = 0, A5 = 0, A6 = 0, A7 = 0;
    for (let y = 2; y >= 0; y--) {
      // F172 (still on the previous line)
      t(3 + 2 + 3 + 3 + 3); A2 = 0; A3 = 0; A5 = X; kram[0xCF] = y; wsync();
      // line L: RESP0
      hmove(); t(4 + 2 + 2);
      let n = R(0xBE + y) & 15;
      if (br(n !== 0)) { loop(n); t(2); st('RESP0', 0); } else { t(2); A2 = 0x60; t(3); t(4); st('RESP0', 0); t(3); }
      wsync();
      // line L+1: RESP1
      hmove(); t(4 + 2 + 2);
      n = R(0xC2 + y) & 15;
      if (br(n !== 0)) { loop(n); t(2); st('RESP1', 0); } else { t(2); A3 = 0x60; t(3); t(4); st('RESP1', 0); t(3); }
      wsync();
      // line L+2: NUSIZ
      hmove(); t(4 + 2 + 2); A6 = R(0xC6 + y) & 7; t(3); t(4); st('NUSIZ1', T(0xFD2F + A6));
      t(4 + 8 + 2); A7 = R(0xC6 + y) >> 4; t(3); t(4); st('NUSIZ0', T(0xFD2F + A7));
      wsync();
      // line L+3: fine motion, colours
      hmove(); t(18); t(4); st('HMP0', R(0xBE + y)); t(4); st('HMP1', R(0xC2 + y));
      t(3); t(3);
      let col = R(0x9F);
      if (!br(A7 !== 0)) { t(3); col = R(0xD4); }
      A4 = col; t(3);
      let col1 = R(0x9F); t(3); t(3);
      if (!br(A6 !== 0)) { t(3); col1 = R(0xD4); }
      t(2); wsync();
      // line L+4: colours, the second fine motion, then the drawing loop
      hmove(); t(3); st('COLUP0', A4); st('COLUP1', col1);
      t(3 + 2); X = (A5 - 4) & 0xFF; t(2); t(3); st('HMP0', A2); t(3); st('HMP1', A3); t(2);
      let yy = 8;
      for (;;) {
        // F213
        X = (X - 1) & 0xFF; t(2 + 2 + 2 + 3 + 2);
        const m0 = ((X - R(0xEC)) & 0xF8) === 0;
        br(!m0); if (m0) t(2); st('ENAM0', m0 ? 2 : 0);
        t(2 + 2 + 3 + 2);
        const m1 = ((X - R(0xED)) & 0xF8) === 0;
        br(!m1); if (m1) t(2); st('ENAM1', m1 ? 2 : 0);
        const g = ind(0xAF, yy); t(5 + (g.cross ? 1 : 0));
        wsync();
        hmove(); st('GRP0', g.v); st('GRP1', g.v);
        t(2 + 2 + 3 + 2);
        const on = ((X - R(0xF9)) & 0xF8) === 0;
        br(!on); if (on) t(2); st('ENABL', on ? 2 : 0);
        st('HMCLR', 0, 4);
        yy--; t(2);
        if (br(yy >= 0)) continue;
        break;
      }
      // F248: the row's collisions (P0-ball, P1-ball)
      // (a read's result changes the cycles after it: the kernel is replayed with the
      //  results the renderer found until they agree, see model())
      t(3); rd('CXP0FB', 0xF24A);
      const r0 = kernel.cx ? kernel.cx.shift() : 0;
      if (br(r0 & 0x40)) {} else { t(3); kram[0xE9] = y; }
      rd('CXP1FB', 0xF250);
      const r1 = kernel.cx ? kernel.cx.shift() : 0;
      if (br(r1 & 0x40)) {} else { t(3); kram[0xEA] = y; }
      t(2);                                        // dey
      if (y > 0) { br(false); t(3); continue; }    // jmp F172
      br(true);
    }
    kram[0xA2] = A2; kram[0xA3] = A3; kram[0xA4] = A4; kram[0xA5] = A5; kram[0xA6] = A6; kram[0xA7] = A7;
    // F25C: below the rows, the bombs and the laser until X < $18
    wsync();
    hmove(); X = (X - 1) & 0xFF; t(2 + 2); st('NUSIZ0', 0); st('NUSIZ1', 0); t(3);
    st('COLUP0', R(0xD4)); st('COLUP1', R(0xD4)); st('COLUP1', R(0xD4)); t(18);
    for (;;) {
      t(2 + 2 + 3 + 2);
      const m0 = ((X - R(0xEC)) & 0xF8) === 0;
      br(!m0); if (m0) t(2); st('ENAM0', m0 ? 2 : 0);
      t(2 + 2 + 3 + 2);
      const m1 = ((X - R(0xED)) & 0xF8) === 0;
      br(!m1); if (m1) t(2);
      wsync();
      hmove(); st('ENAM1', m1 ? 2 : 0);
      t(2 + 2 + 3 + 2);
      const on = ((X - R(0xF9)) & 0xF8) === 0;
      br(!on); if (on) t(2); st('ENABL', on ? 2 : 0);
      t(14); X = (X - 1) & 0xFF; t(2); t(2);
      if (br(X >= 0x18)) continue;
      t(3); break;                                  // jmp F3C2
    }
    // F3C2: the ship (player 1)
    wsync();
    hmove(); X = (X - 2) & 0xFF; t(4 + 3 + 2 + 2);
    loop(R(0xAE) & 15); t(2); st('RESP1', 0); wsync();
    hmove(); t(3); st('COLUP1', R(0xD4)); t(18); t(3); st('HMP1', R(0xAE));
    for (;;) {
      // F3E2
      t(2 + 2 + 3 + 2);
      const m0 = ((X - R(0xEC)) & 0xF8) === 0;
      br(!m0); if (m0) t(2); st('ENAM0', m0 ? 2 : 0);
      t(2 + 2 + 3 + 2);
      const m1 = ((X - R(0xED)) & 0xF8) === 0;
      br(!m1); if (m1) t(2);
      wsync();
      hmove(); st('ENAM1', m1 ? 2 : 0); t(4); st('GRP1', T(0xFC6A + X)); t(2); st('ENABL', 0); st('ENABL', 0);
      t(4); st('HMCLR', 0);
      X = (X - 1) & 0xFF; t(2);
      if (br(X !== 0, true)) continue;
      break;
    }
  } else {
    // ------------------------------------------------ odd waves: six rows of player 0
    br(false); t(3); wsync();
    // line 44: the ship's position
    hmove(); t(4 + 3 + 2 + 2); loop(R(0xAE) & 15); t(2); st('RESP1', 0); wsync();
    // line 45
    hmove(); t(3); st('COLUP1', R(0xD4)); t(3); st('COLUP0', R(0x9F)); t(12); t(3); st('HMP1', R(0xAE)); wsync();
    // line 46
    hmove(); t(2 + 2 + 3); X = 0x90;
    let row = 5;
    const shipOrNone = () => {                        // lda #0; cpx #$15; bcs ...; sta ENABL; lda TFC6A,x
      t(2 + 2);
      if (br(X >= 0x15)) return 0;
      st('ENABL', 0); t(4); return T(0xFC6A + X);
    };
    const enam1 = () => {                             // txa sec sbc $ED and #$F8 bne / lda #2; sta ENAM1
      t(2 + 2 + 3 + 2);
      const m1 = ((X - R(0xED)) & 0xF8) === 0;
      br(!m1); if (m1) t(2); st('ENAM1', m1 ? 2 : 0);
    };
    let done = false;
    // dex; beq -> F2FF / F31B / F37A / F3C0 / F410: each beq after it is taken too (same line)
    // (exitChain(label): the beqs at label and after it, down to F3C0's beq F410, all taken)
    const exitChain = (from) => {
      const chain = ['F2FF', 'F31B', 'F37A', 'F3C0'];
      for (let i = chain.indexOf(from); i < chain.length; i++) br(true, chain[i] === 'F3C0');
      done = true;
    };
    for (;;) {
      // F2D3
      X = (X - 1) & 0xFF; t(2);
      if (X === 0) { br(true); exitChain('F2FF'); break; }
      br(false); t(4 + 2 + 4); st('NUSIZ0', T(0xFD2F + R(0xC6 + row))); st('HMCLR', 0); wsync();
      // line A
      hmove();
      let g1 = shipOrNone(); st('GRP1', g1);
      enam1();
      X = (X - 1) & 0xFF; t(2);
      if (X === 0) { br(true); exitChain('F31B'); break; }
      br(false);
      t(3 + 4 + 2 + 2); const n = R(0xBE + row) & 15;
      g1 = shipOrNone(); wsync();
      // line A+1
      hmove(); st('GRP1', g1);
      X = (X - 1) & 0xFF; t(2);
      if (X === 0) { br(true); exitChain('F37A'); break; }
      br(false); t(2);
      if (!br(n !== 0)) { t(8); st('RESP0', 0); t(2); st('HMP0', 0x60); t(3); }
      else { loop(n); st('RESP0', 0, 4); }
      wsync();
      // line A+2
      hmove(); g1 = shipOrNone(); st('GRP1', g1); enam1();
      t(3 + 4 + 2); st('HMP0', R(0xBE + row)); t(2 + 2);
      let yy = 0x18;
      if (!br(row !== 5)) { t(3); yy = R(0xA9); }
      t(2); X = (X - 1) & 0xFF; t(2);
      if (X === 0) { br(true); exitChain('F3C0'); break; }
      br(false); wsync();
      // line A+3
      hmove(); g1 = shipOrNone(); st('GRP1', g1); t(18);
      // F379 .. the drawing lines
      let rowDone = false;
      for (;;) {
        X = (X - 1) & 0xFF; t(2);
        if (X === 0) { br(true); exitChain('F3C0'); rowDone = true; break; }
        br(false);
        t(2 + 2 + 3 + 2); st('HMCLR', 0);
        const m1 = ((X - R(0xED)) & 0xF8) === 0;
        br(!m1); if (m1) t(2); st('ENAM1', m1 ? 2 : 0);
        const g = ind(0xAF, yy); t(5 + (g.cross ? 1 : 0)); t(4);
        const g0 = g.v & T(0xFD7E + yy);
        wsync();
        hmove(); st('GRP0', g0); t(2);
        let bl;
        if (br(X < 0x15)) { t(4); st('GRP1', T(0xFC6A + X)); t(2); t(3); bl = 0; }
        else { t(2 + 2 + 3 + 2); bl = ((X - R(0xF9)) & 0xF8) === 0; br(!bl); if (bl) t(2); bl = bl ? 2 : 0; }
        st('ENABL', bl);
        yy--; t(2);
        if (br(yy >= 0)) continue;
        // F3A8: the row's collision (P0-ball)
        t(3); rd('CXP0FB', 0xF3AA);
        const r0 = kernel.cx ? kernel.cx.shift() : 0;
        if (br(r0 & 0x40)) {} else { t(3); kram[0xE9] = row; }
        t(2 + 3); row--; kram[0xCF] = row & 0xFF; t(3);
        break;
      }
      if (rowDone) break;
    }
    void done;
  }
  // ------------------------------------------------ F410: the bottom (both kernels)
  wsync();
  hmove(); st('GRP1', 0); st('ENAM0', 0); st('ENAM1', 0); st('GRP0', 0);
  t(3); let eb = R(0xEB);
  if (!br(eb !== 0)) {
    t(3 + 2);
    if (!br(R(0xEC) >= 0x14)) { rd('CXM0P', 0xF426); const v = kernel.cx ? kernel.cx.shift() : 0; if (!br(!(v & 0x80))) { t(2); eb = 0x1F; } }
    t(3 + 2);
    if (!br(R(0xED) >= 0x14)) { rd('CXM1P', 0xF432); const v = kernel.cx ? kernel.cx.shift() : 0; if (!br(!(v & 0x40))) { t(2); eb = 0x1F; } }
    t(3 + 2);
    if (!br(!(R(0xDE) & 1))) { rd('CXPPMM', 0xF43D); const v = kernel.cx ? kernel.cx.shift() : 0; if (!br(!(v & 0x80))) { t(2); eb = 0x1F; } }
  }
  t(3); kram[0xEB] = eb; wsync();
  // the energy bar's ball (4 wide)
  hmove(); t(3 + 2 + 2 + 4); loop(R(0xAA) & 15); t(2); st('RESBL', 0); t(3); st('HMBL', R(0xAA)); wsync();
  hmove(); t(2); st('PF0', 0xFF); st('PF1', 0xFF); st('PF2', 0xFF); t(3); st('COLUPF', R(0x8C)); t(2); st('CTRLPF', 0x20);
  st('RESP0', 0, 4); st('RESP1', 0); st('NUSIZ1', 0x20); t(2); st('NUSIZ0', 0x21); t(3); st('COLUP0', R(0x88)); st('COLUP1', R(0x88));
  st('HMCLR', 0); t(2); st('HMP1', 0x10); t(3); st('COLUBK', R(0x89)); wsync();
  hmove();
  rd('CXP0FB', 0xF48C);
  { const v = kernel.cx ? kernel.cx.shift() : 0; if (br(v & 0x40)) {} else { t(2 + 3); kram[0xE9] = 0; } }
  st('CXCLR', 0); t(16); st('HMCLR', 0); wsync();
  hmove(); t(18 + 18 + 12 + 14); t(2); st('ENABL', 2); t(2);
  for (let x = 4; x >= 0; x--) {
    wsync();
    hmove(); t(4); st('GRP0', T(0xFCE0 + x)); t(4); st('GRP1', T(0xFCE5 + x)); t(4); const a = T(0xFCEA + x); t(3);
    st('HMCLR', 0); st('PF2', R(0xAD)); st('GRP0', a); t(3); st('COLUPF', R(0x8B)); t(3); st('PF0', R(0xAB)); t(3); st('PF1', R(0xAC));
    t(2); st('PF2', 0xFF); st('PF0', 0xFF); t(3); st('COLUPF', R(0x8C)); st('PF1', 0xFF); t(2); br(x > 0);
  }
  wsync();
  // the ships left
  hmove(); t(2); st('GRP0', 0); st('GRP1', 0); st('ENABL', 0); t(3);
  const lives = R(0x9D + R(0xD7)); t(4); const nus = T(0xFD6F + lives); t(4);
  st('NUSIZ1', nus); t(8); st('NUSIZ0', nus >> 4); st('RESP0', 0); st('RESP1', 0); t(2); st('HMP0', 0xF0); wsync();
  hmove(); t(4); st('COLUP0', R(0x9B + R(0xD7))); st('COLUP1', R(0x9B + R(0xD7))); t(12); st('HMCLR', 0); t(2 + 2 + 2);
  for (let y = 9; y >= 0; y--) {
    t(4); const g = T(0xFD0C + y); wsync();
    hmove(); st('GRP0', g); st('GRP1', g); t(2 + 2);
    if (!br(lives >= 2)) st('GRP1', 0);
    t(2); if (!br(lives !== 0)) st('GRP0', 0);
    t(2); br(y > 0);
  }
  wsync();
  hmove(); t(2); st('GRP0', 0); st('GRP1', 0); st('GRP1', 0); wsync();
  // the score: six digits, VDEL
  hmove(); t(2); st('NUSIZ0', 3); st('NUSIZ1', 3); t(18); st('HMCLR', 0); t(3); const sc = R(0x9B + R(0xD7)); t(4);
  st('COLUP0', sc); st('COLUP1', sc); t(2); st('VDELP0', 7); st('VDELP1', 7);
  const dig = p => y => ind(p, y).v;
  let A2 = 0, A3 = 0;
  for (let y = 7; y >= 0; y--) {
    t(3); A2 = y; const g97 = dig(0x97)(y); t(5);
    wsync();
    hmove(); t(3); A3 = g97; t(5); st('GRP0', dig(0x8D)(y)); t(5); st('GRP1', dig(0x8F)(y)); t(5); st('GRP0', dig(0x91)(y));
    t(5); const xx = dig(0x95)(y); t(2); const a = dig(0x93)(y); t(5); t(3);
    st('GRP1', a); st('GRP0', xx); st('GRP1', A3); st('GRP0', a); t(3 + 2); br(y > 0);
  }
  wsync();
  hmove(); t(2); st('GRP0', 0); st('GRP1', 0); st('GRP0', 0); st('GRP1', 0); t(8); st('RESP0', 0); st('RESP1', 0); wsync();
  // the logo (or the copyright line)
  hmove(); t(3); st('COLUBK', R(0x88)); t(2); st('PF0', 0); st('PF1', 0); st('PF2', 0); t(12); t(2); st('HMP1', 0x10);
  const lc = (0x16 ^ R(0x86)) & R(0x87); t(2 + 3 + 3); st('COLUP0', lc); st('COLUP1', lc); t(2); st('NUSIZ0', 3); st('NUSIZ1', 3);
  t(2 + 2); A3 = 7; t(3); wsync();
  hmove(); st('VDELP0', 7); st('VDELP1', 7); t(2); st('GRP0', 0); st('GRP1', 0); st('GRP0', 0);
  const da = R(0xDA);
  t(3 + 6); let a = da >> 3, Y = 0x0F; t(2);
  if (!br(a >= 0x14)) { t(2); Y = 7; t(2); if (!br(a < 0x0C)) { t(2); Y = a - 4; t(2); } }
  let A4 = Y; t(3); st('HMCLR', 0);
  for (let k = 7; k >= 0; k--) {
    t(3); const y = A4; t(4); A2 = T(0xFCD0 + y); t(3); t(4); const xx = T(0xFCC0 + y); t(2); t(4); st('GRP0', T(0xFC80 + y));
    wsync();
    hmove(); A4 = (A4 - 1) & 0xFF; t(5); t(4); st('GRP1', T(0xFC90 + y)); t(4); st('GRP0', T(0xFCA0 + y)); t(4); const b = T(0xFCB0 + y); t(3);
    st('GRP1', b); st('GRP0', xx); st('GRP1', A2); st('GRP0', b); A3 = (A3 - 1) & 0xFF; t(5); br(k > 0);
  }
  wsync();
  hmove(); t(2); st('VDELP0', 0); st('VDELP1', 0); st('GRP0', 0); st('GRP1', 0);
  kram[0xA2] = A2; kram[0xA3] = A3; kram[0xA4] = A4;
  let daNew = da;
  if (da) { daNew = (da - 1) & 0xFF; if (!daNew) daNew = 0xFF; }
  kram[0xDA] = daNew;
  wsync();
  t(4); st('VBLANK', 0x82);      // (F642: the picture ends; no HMOVE on this line)
  return { ev, reads, kram, lastLine: line };
}

// ------------------------------------------------------------------ the TIA, for the model
// Draws the lines from the events, the same rules as tools/vcs.js (with hmoveBlank, wideDelay,
// respDelay); collisions latch per pixel; reads see the pixels before them.
function render(ram, k, start) {
  const R = a => ram[a - 0x80];
  const ob = new Uint8Array(160 * LINES), fb = new Uint8Array(160 * LINES);
  const r = new Uint8Array(64);
  const NAMES = { VSYNC: 0, VBLANK: 1, NUSIZ0: 4, NUSIZ1: 5, COLUP0: 6, COLUP1: 7, COLUPF: 8, COLUBK: 9, CTRLPF: 0xA, REFP0: 0xB, REFP1: 0xC,
    PF0: 0xD, PF1: 0xE, PF2: 0xF, RESP0: 0x10, RESP1: 0x11, RESM0: 0x12, RESM1: 0x13, RESBL: 0x14, GRP0: 0x1B, GRP1: 0x1C, ENAM0: 0x1D,
    ENAM1: 0x1E, ENABL: 0x1F, HMP0: 0x20, HMP1: 0x21, HMM0: 0x22, HMM1: 0x23, HMBL: 0x24, VDELP0: 0x25, VDELP1: 0x26, VDELBL: 0x27,
    HMOVE: 0x2A, HMCLR: 0x2B, CXCLR: 0x2C };
  const pos = start.pos.slice();
  let grpOld = [0, 0], blOld = 0, cx = start.cx, resetLine = [-1, -1], hmoveLine = -1;
  r[1] = 0x82; r[4] = 3; r[5] = 3;
  const results = [];
  const readAt = {};       // line -> [reads sorted by px]
  for (const rd of k.reads) (readAt[rd.line] = readAt[rd.line] || []).push(rd);
  const cxBits = (a) => {
    const b = i => (cx >> i) & 1;
    switch (a) {
      case 'CXM0P': return (b(0) << 7) | (b(1) << 6);
      case 'CXM1P': return (b(2) << 7) | (b(3) << 6);
      case 'CXP0FB': return (b(4) << 7) | (b(5) << 6);
      case 'CXP1FB': return (b(6) << 7) | (b(7) << 6);
      case 'CXPPMM': return (b(13) << 7) | (b(14) << 6);
    }
    return 0;
  };
  const COPIES = [[0], [0, 16], [0, 32], [0, 16, 32], [0, 64], [0], [0, 32, 64], [0]];
  const playerBit = (i, x, line) => {
    const nus = r[4 + i] & 7;
    const g = (r[0x25 + i] & 1) ? grpOld[i] : r[0x1B + i];
    if (!g) return false;
    const d = (x - pos[i] - (nus === 5 || nus === 7 ? 1 : 0) + 160) % 160;
    const scale = nus === 5 ? 2 : nus === 7 ? 4 : 1;
    for (const cc of COPIES[nus]) {
      if (cc === 0 && resetLine[i] === line) continue;
      const dd = d - cc;
      if (dd >= 0 && dd < 8 * scale) { let bit = Math.floor(dd / scale); if (!(r[0xB + i] & 8)) bit = 7 - bit; return ((g >> bit) & 1) === 1; }
    }
    return false;
  };
  const missileBit = (i, x) => {
    if (!(r[0x1D + i] & 2)) return false;
    const w = 1 << ((r[4 + i] >> 4) & 3), d = (x - pos[2 + i] + 160) % 160;
    return COPIES[r[4 + i] & 7].some(cc => d - cc >= 0 && d - cc < w);
  };
  const ballBit = x => {
    const en = (r[0x27] & 1) ? blOld : r[0x1F];
    if (!(en & 2)) return false;
    return (x - pos[4] + 160) % 160 < (1 << ((r[0xA] >> 4) & 3));
  };
  const pfBit = x => {
    let c = x >> 2;
    if (c >= 20) c = (r[0xA] & 1) ? 39 - c : c - 20;
    if (c < 4) return (r[0xD] >> (4 + c)) & 1;
    if (c < 12) return (r[0xE] >> (11 - c)) & 1;
    return (r[0xF] >> (c - 12)) & 1;
  };
  const write = (line, px, name, v) => {
    const a = NAMES[name];
    switch (name) {
      case 'RESP0': case 'RESP1': case 'RESM0': case 'RESM1': case 'RESBL': {
        const isP = a < 0x12;
        pos[a - 0x10] = px < 0 ? (isP ? 3 : 2) : (px + (isP ? 5 : 4)) % 160;
        if (isP && px >= 0) resetLine[a - 0x10] = line;
        break;
      }
      case 'GRP0': grpOld[1] = r[0x1C]; break;
      case 'GRP1': grpOld[0] = r[0x1B]; blOld = r[0x1F]; break;
      case 'HMOVE':
        if (px < 0) hmoveLine = line;
        for (let i = 0; i < 5; i++) { const m = (r[0x20 + i] >> 4) ^ 8; pos[i] = (pos[i] - (m - 8) + 160) % 160; }
        break;
      case 'HMCLR': r[0x20] = r[0x21] = r[0x22] = r[0x23] = r[0x24] = 0; break;
      case 'CXCLR': cx = 0; break;
    }
    if (a !== undefined) r[a] = v;
  };
  let cxAtClear = null;
  for (let line = 42; line < LINES; line++) {
    const evs = k.ev[line];
    const rds = readAt[line] || [];
    let ei = 0, ri = 0;
    for (let px = -68; px < 160; px++) {
      while (ri < rds.length && rds[ri].px <= px) { rds[ri].value = cxBits(rds[ri].reg); ri++; }
      while (ei < evs.length && evs[ei][0] <= px) { const [p, n, v] = evs[ei++]; if (n === 'CXCLR') cxAtClear = cx; write(line, p, n, v); }
      if (px < 0) continue;
      const x = px;
      if (x < 8 && hmoveLine === line) continue;
      const p0 = playerBit(0, x, line), p1 = playerBit(1, x, line);
      const m0 = missileBit(0, x), m1 = missileBit(1, x), bl = ballBit(x), pf = !!pfBit(x);
      const pairs = [[m0, p1], [m0, p0], [m1, p0], [m1, p1], [p0, pf], [p0, bl], [p1, pf], [p1, bl], [m0, pf], [m0, bl], [m1, pf], [m1, bl], [bl, pf], [p0, p1], [m0, m1]];
      for (let i = 0; i < 15; i++) if (pairs[i][0] && pairs[i][1]) cx |= 1 << i;
      if (r[1] & 2) continue;
      let col = r[9];
      const pfCol = (r[0xA] & 2) ? (x < 80 ? r[6] : r[7]) : r[8];
      if (pf || bl) col = pfCol;
      if (p1 || m1) col = r[7];
      if (p0 || m0) col = r[6];
      fb[line * 160 + x] = col;
      ob[line * 160 + x] = p0 | p1 << 1 | m0 << 2 | m1 << 3 | bl << 4 | pf << 5;
    }
    while (ri < rds.length) { rds[ri].value = cxBits(rds[ri].reg); ri++; }
  }
  return { ob, fb, cxEnd: cx, pos, reads: k.reads };
}

// The positions the vertical blank leaves for the kernel: players 0/1 from the last frame's logo
// (21, 29), missiles 0/1 from $EE/$EF and the ball from $BD (LFFA0, one HMOVE for all three).
// LFFA0's reset comes 5 * coarse + 8 cycles into a line; in the horizontal blank (an X from $D2
// up wraps LF81's add: coarse 0) or past the line's end (an X above 159, as the bombs' can be:
// the next line's blank) it puts the object at pixel 2; then the fine move.
const missilePos = v => {
  const { coarse, fine } = posOf(v);
  const cyc = 5 * coarse + 8, h = 3 * cyc - 68;
  const p = cyc >= 76 || h < 0 ? 2 : h + 4;
  return (p - sgn(fine >> 4) + 160) % 160;
};
function startPos(ram) {
  const R = a => ram[a - 0x80];
  return [21, 29, missilePos(R(0xEE)), missilePos(R(0xEF)), missilePos(R(0xBD))];
}

// The whole frame from RAM at the kernel's start. prevCx: the latches the last frame left
// (collisions after its CXCLR); the reads' results feed back into the kernel's timing, so the
// kernel is replayed until they agree.
function model(ram, prevCx = 0) {
  const start = { pos: startPos(ram), cx: prevCx };
  let cxs = [], m, k;
  for (let iter = 0; iter < 20; iter++) {
    kernel.cx = cxs.slice();
    k = kernel(ram);
    kernel.cx = null;
    m = render(ram, k, start);
    const got = m.reads.map(r => r.value);
    if (got.length === cxs.length && got.every((v, i) => v === cxs[i])) break;
    cxs = got;
    if (iter === 19) throw new Error('reads do not settle');
  }
  return { ...m, kram: k.kram, ev: k.ev, lastLine: k.lastLine, carriedIn: prevCx };
}

module.exports = { model, kernel, render, posOf, startPos, missilePos, T, sgn, P0, P1, M0, M1, BL, PF };

// ------------------------------------------------------------------ check
if (require.main === module) {
  const vcs = new VCS(rom);
  vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
  const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 2000);
  const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
  const verbose = process.argv.includes('--verbose');
  const showFrame = +opt('show', -1);
  const play = require('./play')(+opt('seed', 1), { wave: opt('wave') !== undefined ? +opt('wave') : undefined });
  const KERNEL = 0xF138, AFTER = 0xF63F;
  const READ_PCS = new Set([0xF24A, 0xF250, 0xF3AA, 0xF426, 0xF432, 0xF43D, 0xF48C]);
  let bad = 0, checked = 0, cxBad = 0, ramBad = 0, colBad = 0;
  const names = { 1: 'P0', 2: 'P1', 4: 'M0', 8: 'M1', 16: 'BL', 32: 'PF' };
  const seen = { modeA: 0, modeB: 0, waves: new Set(), laser: 0, ship: 0, carried: 0, copies: 0 };
  let prevCx = 0;
  const NAMES = ['CXM0P', 'CXM1P', 'CXP0FB', 'CXP1FB', 'CXM0FB', 'CXM1FB', 'CXBLPF', 'CXPPMM'];
  for (let f = 0; f < frames; f++) {
    play.step(vcs, (a, v) => { vcs.ram[a - 0x80] = v; });
    while (vcs.pc >= KERNEL && vcs.pc < KERNEL + 5) vcs.step();
    let g = 0;
    while (vcs.pc !== KERNEL) { vcs.step(); if (++g > 2e6) throw new Error('no kernel'); }
    const snap = vcs.ram.slice();
    const f0 = vcs.frames;
    const vReads = [];
    while (vcs.pc !== AFTER) {
      if (READ_PCS.has(vcs.pc)) { const op = vcs.read(vcs.pc + 1) & 0x0F; vReads.push({ pc: vcs.pc, line: vcs.line, px: vcs.clock - 68, v: vcs.read(op) }); }
      vcs.step(); if (++g > 4e6) throw new Error('no kernel end');
    }
    let m;
    try { m = model(snap, prevCx); } catch (e) { console.log(`frame ${f0}: ${e.message}`); bad++; prevCx = 0; continue; }
    prevCx = m.cxEnd;
    if (f < 3) continue;
    checked++;
    const R = a => snap[a - 0x80];
    seen.waves.add(R(0xDE));
    if (R(0xDE) & 1) seen.modeB++; else seen.modeA++;
    // reads: same places, same values
    const mr = m.reads.map(r => ({ pc: r.pc, line: r.line, px: r.px, v: r.value }));
    const rs = JSON.stringify(mr), vs = JSON.stringify(vReads.map(r => ({ pc: r.pc, line: r.line, px: r.px, v: r.v & 0xC0 })));
    if (rs !== vs) { cxBad++; if (cxBad <= 5) console.log(`frame ${f0}: reads differ\n  vcs   ${vs}\n  model ${rs}`); }
    if (vReads.some(r => [0xF24A, 0xF250, 0xF3AA].includes(r.pc) && (r.v & 0x40))) seen.laser++;
    if (vReads.some(r => (r.pc === 0xF426 && (r.v & 0x80)) || (r.pc === 0xF432 && (r.v & 0x40)) || (r.pc === 0xF43D && (r.v & 0x80)))) seen.ship++;
    if (m.carriedIn & 0xA0) seen.carried++;
    // bombs drawn with copies (inside the three-row kernel's rows)
    if (!(R(0xDE) & 1)) { let n = 0; for (let y = 42; y < 190; y++) { let k0 = 0, k1 = 0; for (let x = 0; x < 160; x++) { if (m.ob[y * 160 + x] & M0) k0++; if (m.ob[y * 160 + x] & M1) k1++; } if (k0 > 1 || k1 > 1) n++; } if (n) seen.copies++; }
    // the RAM the kernel left
    const rd = [];
    for (const [a, v] of Object.entries(m.kram)) if (vcs.ram[a - 0x80] !== v) rd.push(`$${(+a).toString(16)} vcs ${vcs.ram[a - 0x80].toString(16)} model ${v.toString(16)}`);
    if (rd.length) { ramBad++; if (ramBad <= 5) console.log(`frame ${f0}: kernel RAM differs: ${rd.join(', ')}`); }
    const diffs = [];
    let cdiff = 0;
    for (let y = 42; y <= 233; y++) for (let x = 0; x < 160; x++) {
      const a = vcs.ob[y * 160 + x], b = m.ob[y * 160 + x];
      if (a !== b) diffs.push({ y, x, a, b });
      else if (vcs.fb[y * 160 + x] !== m.fb[y * 160 + x] >> 1) cdiff++;
    }
    if (cdiff) { colBad++; if (colBad <= 5) console.log(`frame ${f0}: ${cdiff} pixels differ in colour`); }
    if (diffs.length) {
      bad++;
      if (verbose || bad <= 5) {
        const byBit = {};
        for (const d of diffs) for (const bit of [1, 2, 4, 8, 16, 32]) if ((d.a ^ d.b) & bit) { const k = names[bit] + (d.a & bit ? '-' : '+'); byBit[k] = (byBit[k] || 0) + 1; }
        console.log(`frame ${f0} (wave ${R(0xDE)}): ${diffs.length} pixels differ: ${Object.entries(byBit).map(([k, v]) => k + ' ' + v).join(', ')}; first at ` +
          diffs.slice(0, 6).map(d => `(${d.x},${d.y}) vcs ${d.a} model ${d.b}`).join(' '));
      }
    }
    if (f0 === showFrame || (showFrame === -2 && diffs.length && bad === 1)) {
      for (let y = 42; y <= 233; y++) {
        let s = '';
        for (let x = 0; x < 160; x++) { const a = vcs.ob[y * 160 + x], b = m.ob[y * 160 + x]; s += a === b ? (a ? (a & P0 ? '0' : a & P1 ? '1' : a & M0 ? 'm' : a & M1 ? 'n' : a & BL ? 'b' : '#') : '.') : (a ? 'V' : 'M'); }
        console.log(String(y).padStart(3), s);
      }
    }
  }
  console.log(`${checked} frames (${seen.modeA} three-row, ${seen.modeB} six-row; waves ${[...seen.waves].sort((a, b) => a - b).join(' ')}), ` +
    `${bad} differ in pixels, ${colBad} in colours, ${ramBad} in kernel RAM, ${cxBad} in collision reads; laser hits ${seen.laser}, ship hits ${seen.ship}, ` +
    `ball-player latches carried from the energy bar ${seen.carried}, frames with bomb copies ${seen.copies}`);
  process.exit(bad || ramBad || cxBad || colBad ? 1 : 0);
}
