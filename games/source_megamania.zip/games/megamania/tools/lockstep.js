// Run the C64 port's game ticks (the patched 2600 program plus our collision code, from
// build/megamania-<version>.prg) on a plain 6502 with 64K of memory, side by side with the
// original game in tools/vcs.js, with the same inputs. After every frame the two must have the
// same 2600 RAM at the same point: just after the picture (the 2600 has drawn it; the C64 side
// has worked out its collisions and the RAM the kernel leaves). Any difference is a bug in a
// patch or in the collisions. Render runs each frame too (crashes, cycles).
//   node games/megamania/tools/lockstep.js [frames] [--seed=N] [--hop=N] [--power=F]
//        [--verbose] [--profile[=Label]] [--slow=cycles [--slowsum]]
// --slow: frames whose tick + render took more than that many cycles, with what they spent it on
// (--slowsum: their average instead; --three / --six: only those waves'; --wave=N: only wave N)
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('318a9d6dda791268df92d72679914ac3');
const build = process.env.MM_BUILD || path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[2] || m[1], 16);
};
const cst = name => {   // a constant ("=$c800 ... CODE_C = $c800")
  const m = lst.match(new RegExp(`^=(\\$?)([0-9a-f]+)\\t+${name}\\s+=`, 'm'));
  if (!m) throw new Error('no constant ' + name);
  return parseInt(m[2], m[1] ? 16 : 10);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 3000);
const verbose = process.argv.includes('--verbose');

// ---- the C64 side: the VCS 6502 core on a flat 64K memory
class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) {
    a &= 0xFFFF;
    // the 2600 program must keep out of the C64's zero page: $00 / $01 and ours at $40-$7F
    if (this.pc >= 0xF000 && (a < 2 || (a >= 0x40 && a < 0x80))) throw new Error(`the 2600 code at $${this.pc.toString(16)} wrote $${a.toString(16)}`);
    this.mem[a] = v;
  }
  commit() {}
  flush() {}
  tick(n) { this.cycles += n; }
  call(addr, limit = 2e6) {      // JSR addr from a stub, run until it returns
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    const start = this.cycles;
    const ring = [];
    for (let i = 0; this.pc !== STUB + 3; i++) { ring[i & 31] = this.pc; this.step(); if (i > limit) throw new Error(`runaway at $${this.pc.toString(16)}; last PCs ${ring.map(p => p.toString(16)).join(' ')}; X ${this.x} Y ${this.y} A ${this.a}`); }
    return this.cycles - start;
  }
}
const c64 = new C64();
const profile = process.argv.some(a => a === '--profile' || a.startsWith('--profile=')) ? {} : null;
const labels = [...lst.matchAll(/^[.>]([0-9a-f]{4})\t(?:([0-9a-f]{4})\t)?.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[2] || m[1], 16), m[3]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xF000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
const profLabel = arg('profile', null);
const pcProfile = typeof profLabel === 'string' ? {} : null;
if (profile) { const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc), d = this.cycles - c; profile[k] = (profile[k] || 0) + d; if (pcProfile && k === profLabel) pcProfile[pc] = (pcProfile[pc] || 0) + d; return r; }; }
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
// what Start does that matters here: the working variables cleared, the program's parts (the
// 2600 image at $F000 among them) where they run, the RIOT ports, the fire buttons
for (let a = 0xC000; a < cst('CODE_C'); a++) c64.mem[a] = 0;
c64.call(sym('Relocate'));
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x0C] = 0x80; c64.mem[0x0D] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));

// ---- the original: run from the end of one picture ($F639) to the end of the next
const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
const AFTER = 0xF639;
const runTick = () => { let g = 0; do { vcs.step(); if (++g > 2e6) throw new Error('2600 never got through a frame'); } while (vcs.pc !== AFTER); };

const NAMES = {};
for (const [a, n, size] of require('../2600/symbols.js').ram) for (let i = 0; i < size; i++) NAMES[a + i] = size > 1 ? `${n}+${i}` : n;
// bytes the two may legitimately disagree on: the stack (on the 2600 it is page zero's top)
const IGNORE = new Set([0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF]);

const play = require('./play')(arg('seed', 1), { hop: arg('hop', 1000) });
const poke = (a, v) => { vcs.ram[a - 0x80] = v; c64.mem[a] = v; };
const power = arg('power', 0), slow = arg('slow', 0);
const frameProf = slow ? {} : null;
if (slow) { const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc); frameProf[k] = (frameProf[k] || 0) + this.cycles - c; return r; }; }
const ioC = { inp: 0, snd: 0, n: 0 };
const perFrame = [], byMode = [], slowSum = {}; let slowN = 0, slowRuns = 0;
let maxCycles = 0, totalCycles = 0, bad = 0, done = 0, maxRender = 0, totalRender = 0;
const waves = new Set();
for (let f = 0; f < frames; f++) {
  play.step(vcs, f > 0 ? poke : null);
  c64.mem[0x0280] = vcs.swcha; c64.mem[0x0C] = vcs.fire[0] ? 0 : 0x80; c64.mem[0x0D] = vcs.fire[1] ? 0 : 0x80; c64.mem[0x0282] = vcs.swchb;
  if (power && f === power) { c64.call(sym('PowerCycle')); vcs.pc = 0xF000; vcs.s = 0xFD; }   // F2 on both
  let kram = null;
  if (arg('dump', -1) === f) { const st = vcs.step.bind(vcs); vcs.step = function () { if (this.pc === 0xF138 && !kram) kram = this.ram.slice(); return st(); }; }
  runTick();
  if (frameProf) for (const k in frameProf) delete frameProf[k];
  const cyc = c64.call(sym('Tick'));
  if (kram) {   // --dump=F: the C64's bomb runs and collisions against tools/c64ref.js's
    const r = require('./c64ref').ref(kram);
    const M = n => c64.mem[sym(n)];
    console.log(`frame ${f}: C64 cx ${M('cx')} runs ${M('BRN')}: ` + [...Array(M('BRN'))].map((_, i) => `x${c64.mem[sym('BRX') + i]} l${c64.mem[sym('BRL') + i]}+${c64.mem[sym('BRLn') + i]} c${c64.mem[sym('BRC') + i]}`).join(' '));
    console.log('  ref cx', JSON.stringify(r.cx), 'm0', JSON.stringify(r.m0.map((v, l) => [l, v.map(q => q[0])]).filter(q => q[1].length)), 'm1', JSON.stringify(r.m1.map((v, l) => [l, v.map(q => q[0])]).filter(q => q[1].length)));
    console.log('  EC', kram[0xEC - 0x80], 'ED', kram[0xED - 0x80], 'EE', kram[0xEE - 0x80], 'EF', kram[0xEF - 0x80], 'A1', kram[0xA1 - 0x80], 'D6', kram[0xD6 - 0x80]);
  }
  maxCycles = Math.max(maxCycles, cyc); totalCycles += cyc;
  // as the main loop and the frame top would: drawn into the buffer not shown, then shown
  const rc = c64.call(sym('Render'));
  if (process.argv.includes('--io')) { ioC.inp += c64.call(sym('ReadInput')); ioC.snd += c64.call(sym('UpdateSound')); ioC.n++; }
  c64.mem[sym('curBuf')] = c64.mem[sym('rbuf')];
  maxRender = Math.max(maxRender, rc); totalRender += rc;
  if (f > 10) perFrame.push(cyc + rc);
  if (f > 10) { const m = c64.mem[0xDE] & 1; (byMode[m] = byMode[m] || []).push(cyc + rc); }
  const modeOk = !process.argv.includes('--six') && !process.argv.includes('--three') || (process.argv.includes('--six') ? (c64.mem[0xDE] & 1) : !(c64.mem[0xDE] & 1));
  const waveOk = arg('wave', -1) < 0 || c64.mem[0xDE] === arg('wave', -1);
  if (slow && cyc + rc > slow && f > 5 && modeOk && waveOk) { slowN++; slowRuns += c64.mem[sym('BRN')]; for (const k in frameProf) slowSum[k] = (slowSum[k] || 0) + frameProf[k]; }
  if (slow && cyc + rc > slow && f > 5 && !process.argv.includes('--slowsum')) console.log(`frame ${f} (wave ${vcs.ram[0xDE - 0x80]}): tick ${cyc} + render ${rc}: ` + Object.entries(frameProf).filter(e => e[1] > 200).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([k, v]) => k + ' ' + v).join(', '));
  if (process.argv.includes('--r1') && c64.mem[0xDE] === arg('wave', -1)) console.log(f, 'line', c64.mem[sym('RowL') + 1], 'N', c64.mem[sym('R1N')], [0, 1, 2, 3, 4].map(k => c64.mem[sym('R1New') + k]).join(' '), 'buf', c64.mem[sym('rbuf')]);
  if (process.argv.includes('--snd')) console.log(f, 'C', c64.mem[0x15], c64.mem[0x16], 'F', c64.mem[0x17], c64.mem[0x18], 'V', c64.mem[0x19], c64.mem[0x1A], 'laserY', c64.mem[0xF9]);
  if (process.argv.includes('--trace')) console.log(f, [0xDE, 0xAF, 0xA1, 0xBE, 0xBF, 0xC0, 0xC2, 0xC3, 0xC4, 0xC6, 0xC7, 0xC8, 0xEC, 0xED, 0xF9].map(a => c64.mem[a].toString(16)).join(' '));
  done++;
  waves.add(vcs.ram[0xDE - 0x80]);
  const diffs = [];
  for (let a = 0x80; a < 0x100; a++) if (!IGNORE.has(a) && vcs.ram[a - 0x80] !== c64.mem[a])
    diffs.push(`${NAMES[a] || '$' + a.toString(16)} 2600 ${vcs.ram[a - 0x80].toString(16)} C64 ${c64.mem[a].toString(16)}`);
  if (diffs.length) {
    bad++;
    if (bad <= 3 || verbose) console.log(`frame ${f} (wave ${vcs.ram[0xDE - 0x80]}): ${diffs.join(', ')}`);
    if (bad === 3 && !verbose) { console.log('... stopping'); break; }
    for (let a = 0x80; a < 0x100; a++) c64.mem[a] = vcs.ram[a - 0x80];   // resync and carry on
  }
}
if (profile) {
  const tot = Object.values(profile).reduce((a, b) => a + b, 0);
  for (const [k, v] of Object.entries(profile).sort((a, b) => b[1] - a[1]).slice(0, 30)) console.log(k.padEnd(16), String(Math.round(v / done)).padStart(7), (100 * v / tot).toFixed(1) + '%');
  if (pcProfile) for (const [pc, v] of Object.entries(pcProfile).sort((a, b) => a[0] - b[0])) console.log('  $' + (+pc).toString(16), Math.round(v / done));
}
console.log(`${done} frames, waves ${[...waves].sort((a, b) => a - b).join(' ')}, ${bad} with differences; C64 tick: ${Math.round(totalCycles / done)} cycles on average, ${maxCycles} at most; render: ${Math.round(totalRender / done)} on average, ${maxRender} at most`);
{ const q = perFrame.slice().sort((a, b) => a - b), at = x => q[Math.min(q.length - 1, Math.floor(x * q.length))];
  console.log(`tick + render per frame: median ${at(0.5)}, 90% ${at(0.9)}, 99% ${at(0.99)}, 99.9% ${at(0.999)}, most ${q[q.length - 1]}`);
  byMode.forEach((v, m) => { if (!v) return; const w = v.slice().sort((a, b) => a - b), p = x => w[Math.min(w.length - 1, Math.floor(x * w.length))];
    console.log(`  ${m ? 'six' : 'three'}-row waves: ${v.length} frames, average ${Math.round(v.reduce((a, b) => a + b, 0) / v.length)}, median ${p(0.5)}, 90% ${p(0.9)}, 99% ${p(0.99)}`); }); }
if (ioC.n) console.log(`ReadInput ${Math.round(ioC.inp / ioC.n)}, UpdateSound ${Math.round(ioC.snd / ioC.n)} cycles a frame on average`);
if (slowN) { console.log(`${slowN} frames over ${slow} (bomb runs ${(slowRuns / slowN).toFixed(1)}), on average:`); for (const [k, v] of Object.entries(slowSum).sort((a, b) => b[1] - a[1]).slice(0, 30)) console.log(`  ${k.padEnd(18)} ${Math.round(v / slowN)}`); }
process.exit(bad ? 1 : 0);
