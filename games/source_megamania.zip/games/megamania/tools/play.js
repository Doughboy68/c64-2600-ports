// A random player for the checks: moves left and right for a while, fires often, presses
// Game Select now and then and Game Reset some time after a game ends. Deterministic from a seed.
// To see every wave (a random player rarely clears one), every so often it clears the wave
// (`poke(addr, value)` writes the 2600 RAM, both machines in lockstep): the game then brings
// the next one in its own way.
//   const play = require('./play')(seed, { hop, wave }); each frame: play.step(vcs, poke)
//   sets vcs.swcha / fire / swchb (SWCHA high nibble, active low: $7F right, $BF left)
module.exports = function (seed = 1, opts = {}) {
  let s = seed * 16807 % 2147483647 || 1;
  const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
  const DIRS = [0x7F, 0x7F, 0xBF, 0xBF, 0xFF, 0xEF, 0xDF];   // right, left, none, up, down
  const hop = opts.hop ?? 1000;
  let aim = -1, hold = 0, dir = 0xFF, fireLeft = 0, resetLeft = 0, selectLeft = 0, frame = 0, over = 0, lastHop = 0;
  return {
    step(vcs, poke) {
      frame++;
      const ram = a => (vcs.ram ? vcs.ram[a - 0x80] : vcs.mem[a]);
      vcs.swchb |= 3;
      // no game running ($DA non-zero) for a while: maybe Game Select, then Game Reset
      if (ram(0xDA) !== 0) over++; else over = 0;
      if (over === 150 && rnd() < 0.5) selectLeft = 3;
      if (over > 200 || frame === 5) { resetLeft = 3; over = 0; }
      if (selectLeft-- > 0) vcs.swchb &= ~2;
      else if (resetLeft-- > 0) vcs.swchb &= ~1;
      if (hold-- <= 0) {
        hold = 10 + Math.floor(rnd() * 80);
        dir = DIRS[Math.floor(rnd() * DIRS.length)];
        // mostly: aim for an enemy (a row's X plus a copy's offset) and steer under it
        aim = rnd() < (opts.aim ?? 0.7) ? (((ram(0xDE) & 1) ? ram(0xF1 + Math.floor(rnd() * 6)) : ram(0xCC + Math.floor(rnd() * 6)))
          + 32 * Math.floor(rnd() * 3) + 3) % 160 : -1;
      }
      if (aim >= 0) {
        const x = ram(0xD6) + 4, d = ((aim - x + 240) % 160) - 80;
        dir = Math.abs(d) < 2 ? 0xFF : d > 0 ? 0x7F : 0xBF;
      }
      // clear the wave now and then (while playing, not dying, no wave coming in)
      if (poke && hop && frame - lastHop >= hop && ram(0xDA) === 0 && ram(0xEB) === 0 && ram(0xD9) === 0) {
        lastHop = frame;
        for (let a = 0xB1; a <= 0xB6; a++) poke(a, 0);
      }
      // (lives kept topped up, so the waves go on)
      if (poke && opts.keepLives !== false && ram(0xDA) === 0 && ram(0x9D) < 3) poke(0x9D, 3);
      // fire: when lined up with no shot in the air ($F9), else now and then
      if (fireLeft <= -2 && ((aim >= 0 && dir === 0xFF && ram(0xF9) === 0) || rnd() < 0.2)) fireLeft = 2 + Math.floor(rnd() * 4);
      vcs.swcha = dir | 0x0F;
      vcs.fire[0] = fireLeft-- > 0;
    },
  };
};
