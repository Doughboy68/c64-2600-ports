// The C64 port's algorithm in JavaScript: what c64/collide.asm works out each frame, written
// first here, at the level the C64 code works (rows, lines, the X values the kernel tests,
// the pixels its mid-line writes land on), and checked against tools/model.js (the 2600 kernel
// transcribed instruction by instruction, itself checked against tools/vcs.js):
//   - the RAM the kernel leaves ($E9/$EA the rows the laser hit, $EB the ship hit, $DA, temps)
//   - what each line shows: the laser (the ball, at one pixel), the bombs (missiles, with the
//     copies their players' NUSIZ give them inside the rows), the ship, the enemies
//   node games/megamania/tools/c64ref.js [frames] [--seed=N] [--verbose]
//
// Lines: 2600 lines as tools/vcs.js counts them. X: the kernel's line counter (its tests use
// it: the laser on lines where X - $F9 is 0-7, bomb 0 where X - $EC is, bomb 1 X - $ED).
'use strict';
const rom = require('../../../tools/rom').load('318a9d6dda791268df92d72679914ac3');
const T = a => rom[(a & 0xFFFF) - 0xF000];
const COPIES = [[0], [0, 16], [0, 32], [0, 16, 32], [0, 64], [0], [0, 32, 64], [0]];
const { missilePos } = require('./model');               // (X - 1; past the line's end: pixel 2 - fine)
const NUSIZ = i => T(0xFD2F + (i & 7));                  // a row's copy bits -> NUSIZ (0/2/4/6)
// The pixel a player is put at from its position byte (low nibble: the coarse delay, high: the
// fine motion), as the kernel's rows place it: 15 * coarse + 6, then the fine move
const xOf = hm => (15 * (hm & 15) + 6 - ((hm >> 4) < 8 ? hm >> 4 : (hm >> 4) - 16) + 160) % 160;

function ref(ram) {
  const R = a => ram[a - 0x80];
  const inR = (X, v) => (((X - v) & 0xFF) & 0xF8) === 0;   // the kernel's "X - v, and #$F8, beq"
  const on = X => inR(X, R(0xF9)), on0 = X => inR(X, R(0xEC)), on1 = X => inR(X, R(0xED));
  const kram = {};
  const bx = missilePos(R(0xBD));                         // the laser's pixel (the ball, 1 wide)
  const m0x = missilePos(R(0xEE)), m1x = missilePos(R(0xEF));
  const sx = R(0xD6);                                      // the ship (player 1)
  const shape = y => T(((R(0xB0) << 8) | R(0xAF)) + y & 0xFFFF);
  const laser = new Uint8Array(264);                       // the laser shown on a line (at bx)
  const m0 = [], m1 = [];                                  // per line: [pixel, colour]
  for (let l = 0; l < 264; l++) { m0.push([]); m1.push([]); }
  const ship = [];                                         // [line, bits]
  const rows = [];                                         // [{lines: [first, last], g(l), x0, n0, x1, n1, col0, col1}]
  const mode = R(0xDE) & 1;
  let cxM0P1 = false, cxM1P1 = false, cxP0P1 = false;

  // a bomb on a line: its state before the write and after it (the write lands at pixel p), its
  // copies (NUSIZ, changing at pixel np on the line), its colour: the pixels shown
  const bombLine = (list, l, x, was, now, p, nusA, nusB, np, col) => {
    for (let px = 8; px < 160; px++) {
      const st = px < p ? was : now;
      if (!st) continue;
      const nus = px < np ? nusA : nusB;
      if (COPIES[nus & 7].includes((px - x + 160) % 160)) list[l].push([px, col]);
    }
  };
  const P1At = []; for (let l = 0; l < 264; l++) P1At.push(null);   // player 1's pixels by line (for the bombs)
  const P0At = []; for (let l = 0; l < 264; l++) P0At.push(null);
  const playerHas = (g, x, nus, px) => {
    if (px < 8 || !g) return false;
    for (const c of COPIES[nus & 7]) { const d = (px - x - c + 320) % 160; if (d < 8) return ((g >> (7 - d)) & 1) === 1; }
    return false;
  };

  if (mode === 0) {
    // ---------------------------------------------------------------- three rows
    const A1 = Math.min(R(0xA1), 0x8F);                   // (the search for the rows runs one line at least)
    const L2 = 188 - A1, LA = L2 + 42;
    // the laser: ENABL written (whole lines) on the lines before the rows, the rows' drawing
    // lines (X one behind), the lines after the rows; held on the rows' set-up lines
    const enabl = new Int16Array(264).fill(-1);            // -1: not written on this line
    for (let l = 44; l < L2; l++) enabl[l] = on(186 - l) ? 1 : 0;
    for (let k = 0; k < 3; k++) for (let l = L2 + 14 * k + 5; l <= L2 + 14 * k + 13; l++) enabl[l] = on(187 + k - l) ? 1 : 0;
    for (let l = LA + 1; l <= 166; l++) enabl[l] = on(190 - l) ? 1 : 0;
    for (let l = 169; l <= 189; l++) enabl[l] = 0;
    let b = 0;
    for (let l = 42; l <= 190; l++) { if (enabl[l] >= 0) b = enabl[l]; laser[l] = b; }
    // the rows
    for (let k = 0; k < 3; k++) {
      const y = 2 - k, L = L2 + 14 * k;
      const c = R(0xC6 + y);
      const r = { y, L, x0: xOf(R(0xBE + y)), n0: NUSIZ(c >> 4), x1: xOf(R(0xC2 + y)), n1: NUSIZ(c & 7),
        col0: (c >> 4) ? R(0x9F) : R(0xD4), col1: (c & 7) ? R(0x9F) : R(0xD4), first: L + 5, last: L + 12 };
      rows.push(r);
      for (let l = L + 5; l <= L + 12; l++) {
        const g = shape(L + 13 - l);
        P0At[l] = { g, x: r.x0, nus: r.n0 }; P1At[l] = { g, x: r.x1, nus: r.n1 };
      }
    }
    // the bombs: missile 0 written mid-line (pixel 82 in the rows, + 3 if the ball was written on
    // and + 3 if the missile is on; 106/103 after the rows; 76/79 by the ship), missile 1 at 127
    // (+ 3 for each of ball, missile 0, missile 1 on) in the rows, at the line's start after them
    let s0 = 0, s1 = 0;                                     // the states carried from line to line
    let nus0 = 3, nus1 = 0, colA = 0, colB = 0;             // (NUSIZ0 is 3 until the first row: the logo's)
    for (let l = 43; l <= 190; l++) {
      // what this line writes: [pixel, value] for each missile; NUSIZ changes; colours
      let w0 = null, w1 = null, n0new = nus0, n0px = 999, n1new = nus1, n1px = 999;
      const k = Math.floor((l - L2) / 14), rl = l - L2 - 14 * k;   // (the row and the line in it)
      if (l >= L2 && k < 3) {
        const y = 2 - k, c = R(0xC6 + y);
        if (rl === 2) { n1new = NUSIZ(c & 7); n1px = -5; n0new = NUSIZ(c >> 4); n0px = 67; }
        if (rl === 4) { colA = (c >> 4) ? R(0x9F) : R(0xD4); colB = (c & 7) ? R(0x9F) : R(0xD4); }
        if (rl >= 4 && rl <= 12) {
          const X = 186 + k - l, v0 = on0(X), v1 = on1(X), bl = rl >= 5 ? enabl[l] : 0;
          w0 = [82 + 3 * bl + 3 * v0, v0]; w1 = [127 + 3 * (bl + v0 + v1), v1];
        }
      } else if (l === LA) {
        n0new = 0; n0px = -38; n1new = 0; n1px = -29; colA = colB = R(0xD4);
        const v0 = on0(189 - l); w0 = [106 + 3 * v0, v0];
      } else if (l > LA && l <= 166) {
        w1 = [-50, on1(190 - l)];
        if (l <= 165) { const v0 = on0(189 - l); w0 = [103 + 3 * enabl[l] + 3 * v0, v0]; }
      } else if (l === 168) { const v0 = on0(21); w0 = [76 + 3 * v0, v0]; }
      else if (l >= 169 && l <= 189) {
        w1 = [-50, on1(190 - l)];
        if (l <= 188) { const v0 = on0(189 - l); w0 = [79 + 3 * v0, v0]; }
      } else if (l === 190) { w0 = [-41, 0]; w1 = [-32, 0]; }
      const was0 = s0, was1 = s1;
      if (w0) s0 = w0[1] ? 1 : 0;
      if (w1) s1 = w1[1] ? 1 : 0;
      if (l < 190) {
        bombLine(m0, l, m0x, was0, s0, w0 ? w0[0] : 999, nus0, n0new, n0px, colA);
        bombLine(m1, l, m1x, was1, s1, w1 ? w1[0] : 999, nus1, n1new, n1px, colB);
      }
      nus0 = n0new; nus1 = n1new;
    }
    for (let l = 169; l <= 189; l++) { const g = T(0xFC6A + 190 - l); ship.push([l, g]); P1At[l] = { g, x: sx, nus: 0 }; }

    // the rows' reads: P0-ball and P1-ball latched by the end of each row (top first)
    let p0 = false, p1 = false;
    for (const r of rows) {
      for (let l = r.first; l <= r.last; l++) if (laser[l]) {
        if (playerHas(P0At[l].g, r.x0, r.n0, bx)) p0 = true;
        if (playerHas(P1At[l].g, r.x1, r.n1, bx)) p1 = true;
      }
      if (!p0) kram[0xE9] = r.y;
      if (!p1) kram[0xEA] = r.y;
    }
    if (!p0) kram[0xE9] = 0;                                // (F48C)
    kram[0xCF] = 0;
    const c0 = R(0xC6);
    kram[0xA5] = (A1 - 27) & 0xFF; kram[0xA6] = c0 & 7; kram[0xA7] = c0 >> 4;
  } else {
    // ---------------------------------------------------------------- six rows
    // X after each line's one dex: 189 - line (from line 46)
    const X = l => (189 - l) & 0xFF;
    const shipG = Xv => (Xv < 0x15 ? T(0xFC6A + Xv) : 0);
    const mask = y => T(0xFD7E + y);
    let bl = 0, s1 = 0;                                     // ball and missile 1 carried
    const blWas = new Uint8Array(264);
    let p0 = false, cf = 5, e9 = R(0xE9);
    let A = 47, row = 5, yy = R(0xA9);
    const nusRow = r => NUSIZ(R(0xC6 + r));
    // lines 42-46: nothing (ENABL 0 from the last frame, missile 1 off)
    for (let l = 42; l <= 46; l++) { laser[l] = 0; }
    let done = false;
    const lineBomb = (l, was, now, p) => bombLine(m1, l, m1x, was, now, p, 0, 0, 999, R(0xD4));
    const setShip = (l, Xv) => { const g = shipG(Xv); if (g) { ship.push([l, g]); P1At[l] = { g, x: sx, nus: 0 }; } };
    while (!done) {
      const x0 = xOf(R(0xBE + row));
      // line A
      let l = A;
      if (X(l - 1) === 0) break;
      {
        const Xp = X(l - 1);
        let bw = bl;
        setShip(l, Xp);
        const near = Xp < 0x15;
        if (near) bw = 0;
        const v = on1(Xp) ? 1 : 0;
        const p = near ? 34 + 3 * v : 16 + 3 * v;
        const was = s1; s1 = v;
        // the ball: 0 from the line's start when near; mid-line 0 when X(A) is first below $15
        laser[l] = bw;
        if (!near && X(l) < 0x15) {
          // ENABL = 0 at pixel 88 + 3 * missile 1 (the ball shows to the left of it)
          const pz = 88 + 3 * v;
          laser[l] = bw && bx < pz ? 1 : 0;
          bl = 0;
        } else bl = bw;
        lineBomb(l, was, s1, p);
        if (X(l) === 0) { done = true; break; }
      }
      // line A+1: RESP0
      l = A + 1;
      setShip(l, X(l - 1));
      laser[l] = bl; lineBomb(l, s1, s1, 999);
      if (X(l) === 0) { done = true; break; }
      // line A+2
      l = A + 2;
      {
        const Xp = X(l - 1), near = Xp < 0x15;
        setShip(l, Xp);
        if (near) bl = 0;
        laser[l] = bl;
        const v = on1(Xp) ? 1 : 0, was = s1; s1 = v;
        lineBomb(l, was, s1, (near ? 34 : 16) + 3 * v);
        if (X(l) === 0) { done = true; break; }
      }
      // line A+3
      l = A + 3;
      {
        const Xp = X(l - 1), near = Xp < 0x15;
        setShip(l, Xp);
        if (near) bl = 0;
        laser[l] = bl;
        if (X(l) === 0) { lineBomb(l, s1, s1, 999); done = true; break; }
        const v = on1(X(l)) ? 1 : 0, was = s1; s1 = v;
        lineBomb(l, was, s1, (near ? 109 : 91) + 3 * v);
      }
      // the drawing lines
      for (let y = yy; y >= 0; y--) {
        l++;
        const Xp = X(l - 1), near = Xp < 0x15;
        const g = shape(y) & mask(y);
        P0At[l] = { g, x: x0, nus: nusRow(row) };
        if (near) { setShip(l, Xp); bl = 0; } else bl = on(Xp) ? 1 : 0;
        laser[l] = bl;
        if (y > 0) {
          if (X(l) === 0) { lineBomb(l, s1, s1, 999); done = true; break; }
          const v = on1(X(l)) ? 1 : 0, was = s1; s1 = v;
          lineBomb(l, was, s1, (near ? 91 : 88 + 3 * bl) + 3 * v);
        } else {
          lineBomb(l, s1, s1, 999);
          // the row's read
          for (let q = A + 4; q <= l; q++) if (laser[q] && playerHas(P0At[q].g, x0, nusRow(row), bx)) p0 = true;
          if (!p0) e9 = row;
          cf = row - 1;
          if (X(l) === 0) { done = true; break; }
        }
      }
      if (done) {
        // (the last row, cut short: its pixels still count for the bottom's read)
        for (let q = A + 4; q <= l; q++) if (P0At[q] && laser[q] && playerHas(P0At[q].g, x0, nusRow(row), bx)) p0 = true;
        break;
      }
      rows.push({ y: row, A, x0, n0: nusRow(row) });
      A = l + 1; row--; yy = 0x18;
    }
    if (!p0) e9 = 0;
    kram[0xE9] = e9; kram[0xCF] = cf & 0xFF;
    // enemies against the ship
    for (const [l, g] of ship) if (P0At[l]) for (let px = 8; px < 160; px++) if (playerHas(g, sx, 0, px) && playerHas(P0At[l].g, P0At[l].x, P0At[l].nus, px)) cxP0P1 = true;
  }
  // bombs against player 1 (row enemies and the ship)
  for (let l = 42; l <= 190; l++) {
    const p1 = P1At[l];
    if (!p1) continue;
    for (const [px] of m0[l]) if (playerHas(p1.g, p1.x, p1.nus, px)) cxM0P1 = true;
    for (const [px] of m1[l]) if (playerHas(p1.g, p1.x, p1.nus, px)) cxM1P1 = true;
  }
  let eb = R(0xEB);
  if (!eb) {
    if (R(0xEC) < 0x14 && cxM0P1) eb = 0x1F;
    if (R(0xED) < 0x14 && cxM1P1) eb = 0x1F;
    if (mode && cxP0P1) eb = 0x1F;
  }
  kram[0xEB] = eb;
  // the bottom's temporaries (the logo loop) and the game-over timer
  const da = R(0xDA), a = da >> 3;
  const y0 = a >= 0x14 ? 0x0F : a < 0x0C ? 7 : a - 4;
  kram[0xA2] = T(0xFCD0 + ((y0 - 7) & 0xFF)); kram[0xA3] = 0xFF; kram[0xA4] = (y0 - 8) & 0xFF;
  kram[0xDA] = da ? ((da - 1) & 0xFF) || 0xFF : 0;
  return { kram, laser, bx, m0, m1, ship, sx, rows, P0At, P1At, mode, cx: { cxM0P1, cxM1P1, cxP0P1 } };
}

module.exports = { ref, NUSIZ, COPIES, xOf };

// ------------------------------------------------------------------ check
if (require.main === module) {
  const { VCS } = require('../../../tools/vcs');
  const M = require('./model');
  const vcs = new VCS(rom);
  vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
  const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 2000);
  const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
  const verbose = process.argv.includes('--verbose');
  const play = require('./play')(+opt('seed', 1), {});
  let bad = 0, ramBad = 0, checked = 0;
  for (let f = 0; f < frames; f++) {
    play.step(vcs, (a, v) => { vcs.ram[a - 0x80] = v; });
    while (vcs.pc >= 0xF138 && vcs.pc < 0xF13D) vcs.step();
    while (vcs.pc !== 0xF138) vcs.step();
    const snap = vcs.ram.slice();
    while (vcs.pc !== 0xF63F) vcs.step();
    if (f < 3) continue;
    checked++;
    const r = ref(snap), m = M.model(snap, 0);
    // the RAM the kernel leaves
    const rd = [];
    for (const [a, v] of Object.entries(r.kram)) if (vcs.ram[a - 0x80] !== v) rd.push(`$${(+a).toString(16)} vcs ${vcs.ram[a - 0x80].toString(16)} ref ${v.toString(16)}`);
    for (const [a, v] of Object.entries(m.kram)) if (!(a in r.kram) && vcs.ram[a - 0x80] !== snap[a - 0x80]) rd.push(`$${(+a).toString(16)} not worked out`);
    if (rd.length) { ramBad++; if (ramBad <= 8 || verbose) console.log(`frame ${vcs.frames} (wave ${snap[0xDE - 0x80]}): ${rd.join(', ')}`); }
    // the pixels: laser, bombs, ship, enemies against the model's, lines 42-189
    const ob = new Uint8Array(160 * 264);
    for (let l = 42; l <= 189; l++) {
      if (r.laser[l] && r.bx >= 8) ob[l * 160 + r.bx] |= M.BL;
      for (const [px] of r.m0[l]) ob[l * 160 + px] |= M.M0;
      for (const [px] of r.m1[l]) ob[l * 160 + px] |= M.M1;
      for (let px = 8; px < 160; px++) {
        const has = (p, g, x, nus) => { for (const c of [[0], [0, 16], [0, 32], [0, 16, 32], [0, 64], [0], [0, 32, 64], [0]][nus & 7]) { const d = (px - x - c + 320) % 160; if (d < 8) return (g >> (7 - d)) & 1; } return 0; };
        if (r.P0At[l] && has(0, r.P0At[l].g, r.P0At[l].x, r.P0At[l].nus)) ob[l * 160 + px] |= M.P0;
        if (r.P1At[l] && has(1, r.P1At[l].g, r.P1At[l].x, r.P1At[l].nus)) ob[l * 160 + px] |= M.P1;
      }
    }
    const diffs = [];
    for (let l = 42; l <= 189; l++) for (let x = 0; x < 160; x++) {
      const a = m.ob[l * 160 + x] & 31, b = ob[l * 160 + x];
      if (a !== b) diffs.push(`(${x},${l}) model ${a} ref ${b}`);
    }
    // the bombs' colours
    for (let l = 42; l <= 189; l++) for (const [list, bit] of [[r.m0, M.M0], [r.m1, M.M1]]) for (const [px, col] of list[l]) {
      const o = m.ob[l * 160 + px];
      const topIs = bit === M.M0 ? !(o & M.P0) : !(o & (M.P0 | M.M0 | M.P1));
      if (topIs && m.fb[l * 160 + px] !== col) diffs.push(`colour (${px},${l}) model ${m.fb[l * 160 + px].toString(16)} ref ${col.toString(16)}`);
    }
    if (diffs.length) { bad++; if (bad <= 8 || verbose) console.log(`frame ${vcs.frames} (wave ${snap[0xDE - 0x80]}): ${diffs.length} differ: ${diffs.slice(0, 6).join(' ')}`); }
  }
  console.log(`${checked} frames: ${bad} differ in pixels, ${ramBad} in the kernel's RAM`);
  process.exit(bad || ramBad ? 1 : 0);
}
