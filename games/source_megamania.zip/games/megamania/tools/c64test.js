// Screenshots of the C64 build in VICE (through the remote monitor), PAL or NTSC, driven through
// its testing aids (DbgSWCHA / DbgINPT4 / DbgSWCHB, PowerReq). Starts its own VICE on a monitor
// port of its own and closes only that one.
//   the title (the game waiting), fire (starts it), then --shots=n screenshots --every=ms apart,
//   with --play the ship moved about at random, firing; --power: F1 (Game Reset) in play, fire,
//   then F2; prints the 2600's $80-$9F after each step, and the testing counters.
//   --c64c: VICE as a C64C (its VIC, 8565 / 8562, shows a grey dot at each colour register
//   write where that register's colour shows: tools/greydots.js finds them in the screenshots).
//   node games/megamania/tools/c64test.js <outdir> [--ntsc] [--c64c] [--play] [--shots=6] [--every=1500] [--power] [--keep]
const fs = require('fs');
const net = require('net');
const path = require('path');
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');

const root = path.join(__dirname, '..');
const files = require('../../../tools/buildname').files(path.join(root, 'build'));
const prg = files.prg;
const lst = fs.readFileSync(files.lst, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})\\t(?:([0-9a-f]{4})\\t)?[^\\n]*?\\t${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return m[2] || m[1];
};
const A = { swcha: addr('DbgSWCHA'), inpt4: addr('DbgINPT4'), swchb: addr('DbgSWCHB'), power: addr('PowerReq'), loops: addr('DbgLoops') };
const out = path.resolve(process.argv[2] || '.');
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const ntsc = process.argv.includes('--ntsc'), keep = process.argv.includes('--keep'), c64c = process.argv.includes('--c64c');
const shots = +opt('shots', 6), every = +opt('every', 1500);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let PORT = 0, vice = null;

function mon(cmds) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(PORT, '127.0.0.1');
    let buf = '';
    sock.on('data', d => { buf += d.toString('latin1'); });
    sock.on('error', reject);
    sock.on('connect', async () => {
      await sleep(150);
      for (const c of cmds) { sock.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 300); }
      sock.write('x\n');
      await sleep(100);
      sock.end();
      resolve(buf.replace(/\(C:\$[0-9a-f]{4}\) /g, ''));
    });
  });
}
const shot = async name => {
  const f = path.join(out, name);
  await mon([`screenshot "${f.replace(/\\/g, '/')}" 2`]);
  for (let t = 0; t < 50 && !fs.existsSync(f); t++) await sleep(200);
};
const poke = (a, v) => mon([`> ${a} ${v}`]);
const press = async (a, v) => { await poke(a, v); await sleep(300); await poke(a, 'ff'); };
const state = async label => console.log(`${label.padEnd(12)} ` + (await mon(['m 0080 009f'])).trim().replace(/\s+/g, ' '));

(async () => {
  fs.mkdirSync(out, { recursive: true });
  PORT = await freePort();
  const model = c64c ? ['-model', ntsc ? 'newntsc' : 'c64c'] : ntsc ? ['-ntsc'] : [];
  vice = startVice(['-default', ...model, '+sound', '-remotemonitor', '-remotemonitoraddress',
    `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prg]);
  let ok = false;
  for (let t = 0; t < 30 && !ok; t++) { await sleep(1000); try { ok = await runsOurs(mon, prg); } catch { /* not up yet */ } }
  if (!ok) throw new Error(`the VICE on port ${PORT} isn't running ${path.basename(prg)}: stopping`);
  await sleep(3000);
  await shot('a0-title.png');
  await state('title');
  await press(A.inpt4, '7f'); await sleep(1500);
  await shot('a1-fire.png');
  await state('after fire');
  let seed = 7;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const moves = ['7f', '7f', 'bf', 'bf', 'ff'];
  for (let i = 1; i <= shots; i++) {
    const t0 = Date.now();
    if (process.argv.includes('--play')) {
      while (Date.now() - t0 < every) {
        await poke(A.swcha, moves[Math.floor(rnd() * moves.length)]);
        if (rnd() < 0.5) await press(A.inpt4, '7f');
        await sleep(200);
      }
    } else await sleep(every);
    await shot(`p${i}.png`);
  }
  await poke(A.swcha, 'ff');
  await state('played');
  if (process.argv.includes('--power')) {
    await press(A.swchb, 'fe'); await sleep(1500);
    await shot('q1-reset.png'); await state('after F1');
    await press(A.inpt4, '7f'); await sleep(1500);
    await shot('q2-fire.png'); await state('after fire');
    await poke(A.power, '01'); await sleep(1500);
    await shot('q3-power.png'); await state('after F2');
  }
  const t = (await mon([`m ${A.loops} ${(parseInt(A.loops, 16) + 7).toString(16)}`])).match(/>C:[0-9a-f]{4}\s+(\w\w) (\w\w) (\w\w) (\w\w) (\w\w) (\w\w) (\w\w) (\w\w)/i);
  if (t) console.log(`main loop passes ${parseInt(t[2] + t[1], 16)}, passes skipping pictures ${parseInt(t[4] + t[3], 16)}, frame tops ${parseInt(t[6] + t[5], 16)}, tops with no new picture ${parseInt(t[8] + t[7], 16)}`);
  if (keep) console.log(`VICE left running; monitor port ${PORT}`);
  else stopVice(vice);
})().catch(e => { console.log(e.message); stopVice(vice); });
