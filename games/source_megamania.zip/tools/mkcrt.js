// Make an EasyFlash cartridge image (.crt) from a game's .prg, as the web builder does
// (Builder.buildCrt, src/web/builder-core.js). Runs on EasyFlash, Kung Fu Flash, the Ultimate
// devices and VICE (x64sc -cartcrt game.crt).
//   node tools/mkcrt.js <game.prg> [out.crt] [cartridge name]
//   (out: the .prg's name with .crt; name: from the file name)
const fs = require('fs');
const path = require('path');
const Builder = require('../src/web/builder-core.js');

const [prgFile, outArg, nameArg] = process.argv.slice(2);
if (!prgFile) { console.error('usage: node tools/mkcrt.js <game.prg> [out.crt] [name]'); process.exit(1); }
const out = outArg || prgFile.replace(/\.prg$/i, '') + '.crt';
const name = nameArg || path.basename(prgFile).replace(/\.prg$/i, '');
try {
  fs.writeFileSync(out, Builder.buildCrt(new Uint8Array(fs.readFileSync(prgFile)), name));
} catch (e) { console.error(`${prgFile}: ${e.message}`); process.exit(1); }
console.log('OK: ' + out);
