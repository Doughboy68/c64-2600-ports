; =================================================================== sound
; The game's TIA sound registers, translated to SID voices 1 and 2 once a frame (Donkey Kong
; uses channel 0 only).
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        beq _off
        ldy v1
        lda SidWave,y
        beq _off2
        sta tmp                 ; waveform
        lda v1                  ; frequency index = AUDC * 32 + AUDF
        lsr
        lsr
        lsr
        sta ptrA+1
        lda v1
        asl
        asl
        asl
        asl
        asl
        ora v2
        clc
        adc FreqTab
        sta ptrA
        lda ptrA+1
        adc FreqTab+1
        sta ptrA+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d400,y
        inc ptrA+1
        inc ptrA+1
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d401,y
        lda #0
        sta $d402,y
        sta $d405,y
        lda #8
        sta $d403,y
        lda v0                  ; volume becomes the sustain level
        asl
        asl
        asl
        asl
        sta $d406,y
        lda v1                  ; restart the envelope only when the waveform changes or the
        cmp SndLast+2,x         ; volume goes up; a lower volume is just a lower sustain level,
        bne +                   ; which the SID glides down to (restarting at every step
        lda SndLast,x           ; clicked: the end of a jump, whose volume steps down)
        cmp v0
        bcs _save
+       lda tmp
        sta $d404,y
        ora #1
        sta $d404,y
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts

; ================================================================== tables
Bit:        .byte $01, $02, $04, $08, $10, $20, $40, $80
SidVoice:   .byte 0, 7
        .include "tables.inc"

; ------------------------------------------------------- variables (RAM)
DbgSWCHA:   .byte $ff           ; AND masks applied to the inputs (testing aid)
DbgINPT4:   .byte $ff
DbgSWCHB:   .byte $ff
DbgMarioDY: .byte 0             ; Mario's sprite and colour events this many lines lower (display only)
DbgBorder:  .byte 0             ; non-zero: colour the border while drawing / running the game
DbgLoops:   .word 0             ; main loop passes
DbgLate:    .word 0             ; ... that found more than one frame gone by
DbgTops:    .word 0             ; frame tops the interrupt has done
DbgRingI:   .byte 0             ; the last 16 late passes (main loop): next entry, then frames
DbgRingF:   .fill 16            ; gone by, GameState, DbgTops's low byte
DbgRingS:   .fill 16
DbgRingT:   .fill 16
FreqTab:    .word SidFreqLo     ; PAL or NTSC frequency tables
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
SndLast:    .fill 6, $ff

MarioRow:   .fill 21            ; Mario's shape as drawn, by line from marioFirst
MarioCol:   .fill 21            ; ... and its 2600 colour per line (0: not drawn)
PfTab:      .fill 4             ; the row's playfield table pointers (low bytes)
PfL0:       .byte 0             ; a playfield line's register values, left half ...
PfL1:       .byte 0
PfL2:       .byte 0
PfR0:       .byte 0             ; ... and right half
PfR1:       .byte 0
PfR2:       .byte 0
LineBuf:    .fill 16
BlkRows:    .fill BLK_SET + 2 * NBLK ; barrel blocks: the rows drawn in them (to be cleared),
BlkGfx:     .fill BLK_SET + 2 * NBLK, $ff ; and the shape they hold: its table ($FF: none or
BlkRef:     .fill BLK_SET + 2 * NBLK ; more than one piece) and reflection
HamKey:     .fill 6, $ff        ; the hammer drawn in each buffer's block: its two tables, ball
HamShown:   .fill 2             ; ... and whether any of it shows
RowPx:      .fill 6             ; Collide: each row's barrel pixel (for RenderBarrels)
PfBits:     .fill 5             ; DrawPfLine: the line's 40 cells, one bit each
HamPat:     .fill 6             ; the hammer's sprite bytes in a row: the missile's, the ball's
DigLo:      .fill 6
ScrKeys:    .fill 13, $ff       ; what the bitmap shows: colours, digits (2 bytes + mode),
KeysEnd:                        ; lives, level, rivets (6), the digits' colour
PaulineCol: .fill 12            ; Pauline's colours: the first, then one per change ...
PaulineEvLine: .fill 12         ; ... with the raster line of each change (0 ends the list)
PaulineEvReg: .fill 12          ; ... and its register ($D029, + $80 on a badline)
LastBg:     .byte 0             ; the colour last written to $D021 (InitVideo: black)

StX:        .fill 16            ; staged sprite registers, 8 per buffer
StY:        .fill 16
StPtr:      .fill 16
StCol:      .fill 16
StMsb:      .fill 2
StEn:       .fill 2
StBg:       .fill 2
StMc1:      .fill 2
StMc2:      .fill 2
EvRas:      .fill 2 * NEV       ; colour events per buffer: raster line (ENDRASTER ends the list),
EvReg:      .fill 2 * NEV       ; $D000-page register, value
EvVal:      .fill 2 * NEV
EvN:        .fill 2

; ---------------------------------------------------- the 2600 program
; The original ROM with the patches the C64 needs (see the top of main.asm):
;   $F000 power-on: no SEI (our interrupts run the display), the stack pointer left to the
;         C64 (TXS -> NOP), the RAM cleared from $80 only (JSR ClearZP)
;   $F01F "sty VBLANK" and $F3B8 / $F3C0 "sta / stx VSYNC": they would hit the C64's $01 / $00
;   $F07F Game Reset's clear, "sta $4E,x" for X = $42..1 ($4F-$90; $4F-$7F are TIA mirrors on
;         the 2600, our zero page here): the game's RAM $80-$90 only, in the same 9 bytes
;   $F651 the kernel's wait for the timer: "jmp KernelHook" instead of drawing the picture
ROM     = "../build/original.a26"
GameImage:
        nop                     ; F000: (sei)
        cld
        ldx #$ff
        nop                     ; F004: (txs)
        inx
        txa
        jsr ClearZP             ; F007: (sta $00,x / inx / bne)
        nop
        nop
        .binary ROM, $000c, $001f-$000c
        nop                     ; F01F: (sty VBLANK)
        nop
        .binary ROM, $0021, $007f-$0021
        ldx #$10                ; F07F: (ldx #$42 / lda #0 / sta $4E,x / dex / bne)
        lda #$00
-       sta $80,x
        dex
        bpl -
        .binary ROM, $0088, $03b8-$0088
        nop                     ; F3B8: (sta VSYNC)
        nop
        .binary ROM, $03ba, $03c0-$03ba
        nop                     ; F3C0: (stx VSYNC)
        nop
        .binary ROM, $03c2, $0651-$03c2
        jmp KernelHook          ; F651: (ldx INTIM / bne)
        nop
        nop
        .binary ROM, $0656, $1000-$0656
        .cerror * - GameImage != $1000, "the 2600 image must be 4K"

; tables built at start-up, in free RAM (not in the program file)
        .virtual $c000
RngLo:      .fill 3 * 256       ; RangeFB/FC (InitRanges): per pointer low byte, for pages
RngHi:      .fill 3 * 256       ; $FB, $FC and $FF
Dig6H:      .fill 256           ; InitDigitTabs: a font byte's pixels for the score digits
Dig6M:      .fill 256
Dig6L:      .fill 256
        .cerror * > $d000, "start-up tables overflow"
        .endv
