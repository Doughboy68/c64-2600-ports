; ================================================================== input
; Keyboard: W A S D + Space; a joystick in port 2 or port 1 (Donkey Kong is for one player).
; F1 Game Reset, F2 power off/on, F3 Game Select, F5 colour/B&W, F7 / F8 difficulties (the game
; reads only Game Reset). Fire starts a game by itself in Donkey Kong, and after a game over
; it is Game Reset too (the original wants Game Reset there). No flicker: no F key.
ReadInput:
        lda #$ff
        sta $dc02               ; port A output, port B input
        lda #0
        sta $dc03
        lda #$ff
        sta $dc00
        lda $dc00
        sta joyb                ; port 2
        lda $dc01
        sta joyb+1              ; port 1
        ldx #7
-       lda KeySelect,x
        sta $dc00
        lda $dc01
        sta Keys,x
        lda joyb+1              ; ignore lines a port 1 joystick is pulling low
        eor #$1f
        and #$1f
        ora Keys,x
        sta Keys,x
        dex
        bpl -
        lda #$ff
        sta $dc00

        lda #$ff                ; build SWCHA / INPT4
        sta outv
        lda #$80
        sta outv+1
        ldx #0
_in     ldy InputMap,x          ; joystick
        lda joyb,y
        and InputMap+1,x
        beq +
        ldy InputMap+2,x        ; key
        lda Keys,y
        and InputMap+3,x
        bne ++
+       ldy InputMap+4,x
        lda outv,y
        and InputMap+5,x
        sta outv,y
+       txa
        clc
        adc #6
        tax
        cpx #InputMapEnd-InputMap
        bne _in
        lda outv
        and DbgSWCHA            ; debug overrides, poked from the VICE monitor by tools
        sta SWCHA
        lda outv+1
        and DbgINPT4
        sta INPT4

        ; console switches
        lda Keys+0              ; F5: colour / B&W (on key-down)
        and #$40
        bne +
        lda PrevKeys
        and #$40
        beq +
        lda switches
        eor #$08
        sta switches
+       lda Keys+0              ; F7 / F8: difficulty
        and #$08
        bne +
        lda PrevKeys
        and #$08
        beq +
        lda Keys+1              ; with either shift key (F8): right difficulty
        bpl _right
        lda Keys+6
        and #$10
        beq _right
        lda #$40                ; F7: left difficulty
        bne _tog
_right  lda #$80
_tog    eor switches
        sta switches
+       lda Keys+0
        sta PrevKeys
        jsr PowerKey
        lda switches            ; reset (F1) and select (F3) are held buttons
        and #$fc
        sta tmp
        lda f2now               ; F1 is Game Reset (F2, on the same key, is the power switch)
        bne _rup
        lda Keys+0
        and #$10
        beq _f3
_rup    inc tmp                 ; bit 0 up
_f3     lda Keys+0
        and #$20
        beq +
        lda tmp
        ora #2
        sta tmp
+       lda INPT4               ; after a game over the original ignores fire until Game
        bmi +                   ; Reset (LevelCount 0 or more, no game on): there fire
        lda GameState           ; presses Game Reset too, for the one tick until the reset
        bne +                   ; makes LevelCount negative; fire held on then starts a game
        lda LevelCount
        bmi +
        lda tmp
        and #$fe
        sta tmp
+       lda tmp
        and DbgSWCHB
        sta SWCHB
        rts

; F2 (F1 with either shift key): ask for a power cycle on key-down. f2now = F2 held.
PowerKey:
        lda #0
        sta f2now
        lda Keys+0
        and #$10
        bne _up                 ; F1 key up
        lda Keys+1              ; left shift
        bpl _down
        lda Keys+6              ; right shift
        and #$10
        bne _up
_down   inc f2now
        lda PrevF2
        bne _up
        lda #1
        sta PowerReq
_up     lda f2now
        sta PrevF2
        rts

; joystick port (0 = port 2, 1 = port 1), joystick bit, key row, key bit,
; output (0 SWCHA, 1 INPT4), AND mask for the output
InputMap:
        .byte 0, $01, 1, $02, 0, $ef    ; up:    W
        .byte 0, $02, 1, $20, 0, $df    ; down:  S
        .byte 0, $04, 1, $04, 0, $bf    ; left:  A
        .byte 0, $08, 2, $04, 0, $7f    ; right: D
        .byte 0, $10, 7, $10, 1, $7f    ; fire:  Space
        .byte 1, $01, 1, $02, 0, $ef    ; the same from port 1
        .byte 1, $02, 1, $20, 0, $df
        .byte 1, $04, 1, $04, 0, $bf
        .byte 1, $08, 2, $04, 0, $7f
        .byte 1, $10, 7, $10, 1, $7f
InputMapEnd:
KeySelect:  .byte $fe, $fd, $fb, $f7, $ef, $df, $bf, $7f
