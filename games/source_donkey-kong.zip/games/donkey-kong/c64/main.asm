; Donkey Kong (Atari 2600, Coleco 1982) running on the Commodore 64.
;
; The original 2600 program runs almost unchanged at $F000, in the RAM under the C64 KERNAL
; (patches: see GameImage in data.asm). This file supplies everything the 2600 hardware used
; to do:
;   - display: the girders, ladders, score and lives in a hires bitmap drawn from the game's
;     own tables; Mario, Kong, Pauline, the hammer and the barrels as sprites, laid out line
;     for line like the 2600 picture (one 2600 pixel = two C64 pixels, one line = one line),
;     with each sprite's colour changed per line as the 2600 kernel does (a raster schedule)
;   - collisions: Mario against the barrels and the hammer, worked out in software from the
;     rules in tools/model.js, which match the 2600 pixel for pixel
;   - input: keyboard and joysticks mapped onto the 2600 joystick and switch ports
;   - sound: the game's TIA sound registers translated to the SID
;
; The game's TIA writes land harmlessly in zero page $02-$2C; it reads the TIA at the mirrors
; $30-$3D, where we put the collisions and the fire button. Its RIOT accesses ($0280-$0297)
; hit plain C64 RAM, which we fill in each frame.
;
; Build: build.cmd (64tass -C -a -o build/donkeykong-V.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM (see 2600/symbols.js)
BarrelY     = $80       ; 4 slots
JumpTimer   = $85
HammerTime  = $86
GameState   = $8C
Level       = $90
LevelCount  = $91       ; rounds: negative at power-on and after Game Reset
BgColour    = $92
MarioX      = $93
Facing      = $94
HammerPtr   = $95       ; low bytes at $95, $97 (page $FF)
PfColour    = $9A
MarioY      = $9B
HammerX     = $9C
Rivets      = $9D       ; per row 0..5 (the top row's at $A2)
Lives       = $A3
MarioGfx    = $A5       ; 28 bytes
RowCoarse   = $CD       ; per row 0..5
RowFine     = $D3
RowGfx      = $F2
RowColour   = $F8

; ------------------------------- 2600 hardware: TIA writes land in zero page
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
; the game reads the TIA at $30-$3D: we fill these in
CXM1P       = $31       ; bit 7 M1-P0 (the hammer and Mario)
CXP1FB      = $33       ; bit 6 P1-BL (a barrel and the hammer's head: smashed)
CXPPMM      = $37       ; bit 7 P0-P1 (Mario and a barrel)
INPT4       = $3C       ; bit 7 clear: fire
; RIOT
SWCHA       = $0280     ; joystick (high nibble: player 0)
SWCHB       = $0282     ; console switches
INTIM       = $0284     ; timer (kept at 0 so the game never waits)

; ------------------------------------------------ 2600 program addresses
PowerOn     = $F000
FrameEnd    = $F017     ; where the game continues after drawing a picture
KernelStart = $F651     ; patched: the game hands over here instead of drawing

; ------------------------------------------------------------ C64 layout
VICBANK     = $4000     ; the VIC sees $4000-$7FFF (no character ROM there)
SPRDATA     = $4000     ; sprite blocks (block n at SPRDATA + 64 n)
SCREEN      = $5C00     ; bitmap colour cells
BITMAP      = $6000     ; hires bitmap, 2600 line L on screen line L - LINEOFS
SPRPTR      = SCREEN + $3F8
D018VAL     = ((SCREEN - VICBANK) / $400) << 4 | ((BITMAP - VICBANK) / $2000) << 3

LINEOFS     = 40        ; 2600 line L is screen line L - LINEOFS,
RASTEROFS   = 51 - LINEOFS      ; raster line L + RASTEROFS,
SPRYOFS     = 50 - LINEOFS      ; and sprite Y register value L + SPRYOFS
BADLINE     = 3         ; badlines: raster & 7 = YSCROLL ($D011 = $3B)
BADDELAY    = 7         ; delay loops (5 cycles) before a badline event's write: see _bad
TOPRASTER   = 44        ; frame start: before the first line of the picture (2600 line 40)
ENDRASTER   = 231 + RASTEROFS   ; frame end: after 2600 line 230
ROWTOP      = 75        ; the top girder row's first line (rows of 28 lines, 5 at the top .. 0)
KONGLINE    = 50        ; Kong and Pauline: 20 lines from here
HAMMERLINE  = 103       ; the hammer's row: 14 lines from here (row 4, y 27..14)

; sprites: 0 Mario, 1 Kong, 2 Pauline, 3 the hammer (multicolour), 4-7 barrels
; sprite blocks: 0 blank, 1-2 Kong (facing left, right), 3 Pauline, then two sets of 6:
; Mario, the hammer, 4 barrels (the display uses one set while the next frame fills the other)
BLK_BLANK   = 0
BLK_KONG    = 1
BLK_PAULINE = 3
BLK_SET     = 4
NBLK        = 6
B_MARIO     = 0
B_HAMMER    = 1
B_BARREL    = 2
NEV         = 24        ; colour events a frame at most (per buffer)
        .cerror SPRDATA + 64 * (BLK_SET + 2 * NBLK) > SCREEN, "sprite blocks overflow"

; ------------------------------------------------------- zero page ($40+)
; $02-$2C take the game's TIA writes and $30-$3D are its TIA reads, so ours start at $40.
        .virtual $40
ptrA        .word ?
ptrB        .word ?
ptrC        .word ?
tmp         .byte ?
tmp2        .byte ?
tmp3        .byte ?
v0          .byte ?
v1          .byte ?
v2          .byte ?
v3          .byte ?
v4          .byte ?
v5          .byte ?
frameFlag   .byte ?     ; frames counted by the raster interrupt
frames      .byte ?
isPal       .byte ?
tickAcc     .byte ?
firstTick   .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)
outv        .word ?     ; SWCHA, INPT4 being built
switches    .byte ?     ; SWCHB toggles
curBuf      .byte ?     ; raster interrupt: frame buffer in use (0/1)
pending     .byte ?     ; a new frame is ready in the other buffer
irqIdx      .byte ?     ; the next colour event
rbuf        .byte ?     ; render: the buffer being drawn (0/1)
bufOfs      .byte ?     ; render: 0 or 8 for that buffer's staged sprite values
blkOfs      .byte ?     ; render: its first sprite block
evOfs       .byte ?     ; render: its events (NEV * rbuf)
evN         .byte ?     ; render: events so far
refp0       .byte ?     ; this frame: player 0 reflected ($08) or not
refp1       .byte ?     ; ... player 1
lastCol     .byte ?
row         .byte ?     ; render / collide: the girder row being done, its top line
rowTop      .byte ?
yEnd        .byte ?     ; ... its last kernel y (3, or 13 for the bottom row)
lineL       .byte ?
sprN        .byte ?     ; barrels: the sprite being filled, its first line, its pixel
sprFirst    .byte ?
sprX        .byte ?
p1x         .byte ?     ; player 1's pixel, kept from row to row
marioFirst  .byte ?     ; Mario's first line and pixel this frame ($FF: none)
marioPx     .byte ?
cellOld     .byte ?
evA         .byte ?     ; AddEvent's arguments
evX         .byte ?
evY         .byte ?
mcBits      .byte ?     ; McPixels: the colour bits, the byte, the count
mcByte      .byte ?
mcCnt       .byte ?
yHi         .byte ?     ; RangeFB/FC: the lines to scan, y from yHi down to yLo
yLo         .byte ?
sprRows     .byte ?     ; barrels: the rows the open sprite has
marioDone   .byte ?     ; MarioLines done for the last tick
pxDone      .byte ?     ; Collide's RowPx done for the last tick
irqT        .byte ?     ; the interrupt: the event's line
irqB        .byte ?     ; ... the line before a badline's event
        .cerror * > $80, "zero page overflow"
        .endv

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title, credits and controls.
; (Lower case here: 64tass -a turns it into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " donkey kong"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600, coleco 1982"
Bas30   .word Bas40, 30
        .null $8f, " programmed by garry kitchen"
Bas40   .word Bas50, 40
        .null $8f, " version 1.0"
Bas50   .word Bas60, 50
        .null $8f, " ported by claude and doughboy68"
Bas60   .word Bas70, 60
        .null $8f, " joy port 2/1 or wasd, space-jump"
Bas70   .word BasEnd, 70
        .null $8f, " f1 or fire-start f2-power off/on"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #$ff
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01

        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -

        ; copy the patched 2600 program to $F000-$FFFF
        lda #<GameImage
        sta ptrA
        lda #>GameImage
        sta ptrA+1
        lda #0
        sta ptrB
        lda #$f0
        sta ptrB+1
        ldx #16
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        lda #<Nmi               ; our vectors replace the 2600's
        sta $fffa
        lda #>Nmi
        sta $fffb
        lda #<Irq
        sta $fffe
        lda #>Irq
        sta $ffff

        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #0
        sta INTIM
        lda #$80
        sta INPT4
        lda #1
        sta firstTick

        jsr InitVideo
        jsr InitSound
        jsr DetectPal

        ldx #0                  ; start the raster interrupt on an empty frame
        stx curBuf
        stx pending
        lda #ENDRASTER
        sta EvRas
        sta EvRas+NEV
        lda #$ff
        sta irqIdx
        lda #TOPRASTER
        sta $d012
        lda #$3b                ; bitmap mode, 25 rows, raster bit 8 clear
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

; ================================================================ main loop
MainLoop:
-       lda frameFlag           ; frames since we last got here (set by the raster interrupt)
        beq -
        sei
        lda frameFlag
        ldx #0
        stx frameFlag
        cli
        inc DbgLoops            ; (testing aid: passes, and frames that came late)
        bne +
        inc DbgLoops+1
+       cmp #2
        bcc +
        pha                     ; (testing aid: the last 16 late passes: frames gone by,
        ldx DbgRingI            ; GameState, the frame count)
        sta DbgRingF,x
        lda GameState
        sta DbgRingS,x
        lda DbgTops
        sta DbgRingT,x
        inx
        txa
        and #15
        sta DbgRingI
        pla
        inc DbgLate
        bne +
        inc DbgLate+1
+       cmp #3                  ; if we fell behind, catch up at most 3 frames
        bcc +
        lda #3
+       sta frames
        lda DbgBorder           ; testing aid: the border shows where the time goes
        beq +
        lda #2
        sta $d020
+       jsr Render              ; draw the state the last tick produced
        jsr ReadInput
        lda PowerReq            ; F2: the power switch
        beq +
        jsr PowerCycle
+       lda DbgBorder
        beq _frame
        lda #5
        sta $d020
_frame  lda isPal               ; PAL: 6 game ticks every 5 frames keeps 2600 speed
        beq _ntsc
        lda tickAcc
        clc
        adc #6
        sta tickAcc
-       lda tickAcc
        cmp #5
        bcc _done
        sbc #5
        sta tickAcc
        jsr Tick
        jmp -
_ntsc   jsr Tick
_done   dec frames
        bne _frame
        jsr UpdateSound
        lda DbgBorder
        beq +
        lda #0
        sta $d020
+       jmp MainLoop

; One 2600 frame of game logic: the original code from the end of the picture to the start
; of the next one, where it jumps to KernelHook.
Tick:
        lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp PowerOn             ; the very first frame starts at power-on
+       jmp FrameEnd

KernelHook:                     ; the game would draw the picture now
        jsr Collide             ; what the TIA would have seen
        rts                     ; (returns to whoever called Tick; the game's logic reads
                                ; nothing the kernel leaves behind)

; F2: the power switch off and on. The TIA is cleared and the next tick starts at the 2600's
; power-on code, which clears its RAM; the console switches stay as they are set, as on a
; real 2600. The display catches up by itself.
PowerCycle:
        lda #0
        sta PowerReq
        ldx #2                  ; the TIA's registers ($02-$2C) and our copies of its reads
-       sta $00,x
        inx
        cpx #$3e
        bne -
        sta INTIM
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        lda #1
        sta firstTick
        rts

; Replaces the 2600's "sta $00,x / inx / bne" clearing loop at power-on (A = 0): clear the
; 2600 RAM from X up, but not the C64's zero page below $80.
ClearZP:
        cpx #$80
        bcs +
        ldx #$80
+
-       sta $00,x
        inx
        bne -
        rts

; =========================================================== interrupts
; Each frame: at TOPRASTER the staged sprite registers of a newly finished buffer go in, then
; the buffer's colour events (sprite colour changes on given raster lines, written at the start
; of the line) in raster order, then the frame end lets the main loop draw the next frame.
Irq:
        pha
        txa
        pha
        tya
        pha
        cld                     ; the game uses decimal mode now and then
        lda $d019
        sta $d019
        lda irqIdx
        cmp #$ff
        beq +
        jmp _event
+
        inc DbgTops             ; (testing aid)
        bne +
        inc DbgTops+1
+       lda pending             ; frame top: switch to a newly finished frame
        beq +
        lda curBuf
        eor #1
        sta curBuf
        lda #0
        sta pending
+       lda curBuf
        asl
        asl
        asl
        tay                     ; 8 * buffer: staged sprite values
        ldx #0
-       lda StPtr,y
        sta SPRPTR,x
        lda StCol,y
        sta $d027,x
        iny
        inx
        cpx #8
        bne -
        lda curBuf
        asl
        asl
        asl
        tay
        ldx #0
-       lda StX,y
        sta $d000,x
        lda StY,y
        sta $d001,x
        iny
        inx
        inx
        cpx #16
        bne -
        ldy curBuf
        lda StMsb,y
        sta $d010
        lda StEn,y
        sta $d015
        lda StMc1,y
        sta $d025
        lda StMc2,y
        sta $d026
        lda StBg,y              ; only when it changes: the C64C's VIC (8565) shows a grey
        cmp LastBg              ; dot where the beam is at each colour register write
        beq +
        sta $d021
        sta LastBg
+       lda #0
        sta irqIdx
; The buffer's events from irqIdx on, in one loop (Y = the event): an event on this line, a
; line that has passed, or one at most 4 lines ahead is written now (its value in A, its
; register in the store's operand, then a wait for its line or a later one: an exact match
; can be missed, as on a badline with sprites the CPU may get no cycle to read $D012 on that
; line); the next event, if it is on the same or the next line, straight on (~50 cycles from
; one write to the next, sprite DMA included under a line, so following lines don't drift
; late); one further ahead gets the interrupt 3 lines before it (2 or more lines from now: no
; race with the beam). The end marker (ENDRASTER) likewise ends the frame. Render marks a
; badline's event with bit 7 of its register (_bad).
_event  ldy irqIdx
        lda curBuf
        beq _ev
        tya
        clc
        adc #NEV
        tay
_ev     lda EvRas,y
        cmp #ENDRASTER
        bcc +
        lda #ENDRASTER
+       sta irqT
        bit $d011               ; below line 255 ($D012 reads 0-55 there): passed, no wait
        bmi _late
        cmp $d012
        bcc _due
        beq _due
        sbc $d012               ; (carry set) the lines to go
        cmp #5
        bcc _due
        jmp _arm                ; (carry set)
_due    lda irqT
        cmp #ENDRASTER
        bne +
        jmp _end
+       lda EvReg,y
        bmi _bad
        sta _w+1
        lda EvVal,y
_wait   ldx $d012               ; (wait for the line or a later one)
        cpx irqT
        bcc _wait
_w      sta $d000               ; (operand: the event's register)
        iny                     ; the next event on this line or the next: straight on
        lda EvRas,y
        sec
        sbc irqT
        cmp #2
        bcs _ev
        adc irqT                ; (carry clear) its line
        sta irqT
        lda EvReg,y
        bmi _bad
        sta _w+1
        lda EvVal,y
        jmp _wait
_late   lda irqT
        cmp #ENDRASTER
        bne +
        jmp _end
+       lda EvReg,y
        and #$7f
        sta _l+1
        lda EvVal,y
_l      sta $d000               ; (operand: the event's register)
        iny
        jmp _ev
; A badline's event (A = its register + $80): the VIC holds the CPU from cycle ~12 of that
; line, too early to write before the sprite's pixels, so write it at the end of the line
; before, once the beam has passed the sprite there (BADDELAY: the write ~cycle 50-68, after
; any sprite ending by ~cycle 55 and before the badline's hold, sprite DMA included)
_bad    and #$7f
        sta _w+1
        lda irqT
        sec
        sbc #1
        sta irqB
        lda EvVal,y
        ldx $d012
        cpx irqB
        bcc _badw
        bne _w                  ; the badline or later already: at once
        ldx #BADDELAY - 4       ; already on the line before (after an event there): less
        bne _badd
_badw   ldx $d012               ; wait for the line before
        cpx irqB
        bcc _badw
        bne _w
        ldx #BADDELAY
_badd   dex                     ; (5 cycles a loop)
        bne _badd
        beq _w
_arm    lda irqT                ; ask for an interrupt 3 lines before the event's (entry
        sbc #3                  ; and dispatch can take 2 lines with badlines and 8 sprites)
        sta $d012               ; (carry set)
        tya                     ; and keep the event's index
        ldx curBuf
        beq +
        sbc #NEV                ; (carry set)
+       sta irqIdx
_out    pla
        tay
        pla
        tax
        pla
        rti
_end    inc frameFlag           ; frame end: the next interrupt is the frame top
        lda #$ff
        sta irqIdx
        lda #TOPRASTER
        sta $d012
        jmp _out

Nmi:    rti

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        txa                     ; the SID's pitch depends on the machine's clock
        bne +
        lda #<SidFreqLoN
        sta FreqTab
        lda #>SidFreqLoN
        sta FreqTab+1
+       rts

InitVideo:
        lda $dd02               ; VIC bank 1 ($4000)
        ora #3
        sta $dd02
        lda $dd00
        and #$fc
        ora #2
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d017
        sta $d01b
        lda #$08                ; sprite 3 (the hammer) multicolour, the others expanded
        sta $d01c
        lda #$f7
        sta $d01d
        lda #$08
        sta $d016
        lda #D018VAL
        sta $d018

        ; clear the bitmap and its colour cells, and the sprite blocks
        lda #<BITMAP
        sta ptrB
        lda #>BITMAP
        sta ptrB+1
        ldx #32                 ; ($6000-$7FFF)
        ldy #0
        tya
-       sta (ptrB),y
        iny
        bne -
        inc ptrB+1
        dex
        bne -
        lda #<SPRDATA
        sta ptrB
        lda #>SPRDATA
        sta ptrB+1
        ldx #(>(SPRDATA + 64 * (BLK_SET + 2 * NBLK))) - (>SPRDATA) + 1
        ldy #0
        tya
-       sta (ptrB),y
        iny
        bne -
        inc ptrB+1
        dex
        bne -
        lda #BLK_BLANK          ; all sprites blank to start
        ldx #7
-       sta SPRPTR,x
        sta StPtr,x
        sta StPtr+8,x
        dex
        bpl -
        jsr InitShapes          ; Kong and Pauline's blocks and fixed registers
        jsr InitRanges          ; the ROM tables' non-zero lines
        jsr InitDigitTabs       ; the score digits' shifted pixels
        lda #$ff                ; the bitmap's keys: everything to be drawn
        ldx #KeysEnd-ScrKeys-1
-       sta ScrKeys,x
        dex
        bpl -
        rts

InitSound:
        ldx #$18
        lda #0
-       sta $d400,x
        dex
        bpl -
        lda #$0f                ; full volume
        sta $d418
        ldx #5
        lda #$ff
-       sta SndLast,x
        dex
        bpl -
        rts

        .include "input.asm"
        .include "collide.asm"
        .include "render.asm"
        .include "data.asm"
        .cerror * > VICBANK, "the program runs into the video bank"
