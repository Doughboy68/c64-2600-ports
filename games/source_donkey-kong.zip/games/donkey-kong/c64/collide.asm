; =============================================================== collisions
; What the TIA would have latched while drawing this frame's picture, for the two registers
; the game reads: CXPPMM bit 7 (player 0 and player 1: Mario and a barrel) and CXM1P bit 7
; (missile 1 and player 0: the hammer's head and Mario). Worked out from the same rules as the
; renderer: Mario's lines and shape bytes as drawn, each row's barrel, the hammer's missile.
; Run at the kernel hook, before Render (both read the game's RAM as the kernel would).
; Mario's lines (MarioLines) are worked out only when something comes near him; Render
; gets them if no tick needed them.
Collide:
        lda #0
        sta CXPPMM
        sta CXM1P
        sta marioDone
        sta pxDone
        jsr SmashCheck          ; the hammer's head against the hammer row's barrel
        jsr MarioTop            ; his first line (marioFirst) and pixel
        lda marioFirst
        cmp #$ff
        bne +
        rts
+       ; --- barrels: each row's player 1, line by line
        jsr SetRefp1
        lda #0
        sta p1x
        lda #5
        sta row
        bne _row                ; (always)
_skip   jmp _nextrow
_row    ldx row
        cpx #5                  ; (as RenderBarrels)
        beq _pos
        lda RowCoarse,x
        bmi _gfx
_pos    jsr BarrelPixel
_gfx    ldx row
        lda p1x                 ; (for RenderBarrels)
        sta RowPx,x
        lda RowGfx,x
        cmp #$5d
        beq _skip
        sta ptrA
        lda p1x                 ; the barrel within 8 pixels of Mario at all?
        sec
        sbc marioPx
        bcs +
        eor #$ff
        adc #1                  ; (carry clear)
+       cmp #8
        bcs _skip
        jsr RowBounds           ; rowTop, yEnd
        lda rowTop              ; Mario's lines (marioFirst .. +20) meet the row's?
        clc
        adc #27
        cmp marioFirst
        bcc _skip
        lda marioFirst
        adc #19                 ; (carry set: + 20)
        cmp rowTop
        bcc _skip
        lda #$fc
        sta ptrA+1
        lda ptrA
        jsr RangeFC             ; the lines where the shape isn't 0
        bcc _skip
        lda marioDone           ; Mario's lines needed now (they use the row's variables)
        bne +
        lda row
        pha
        jsr MarioLines
        pla
        sta row
        jsr RowBounds
        lda ptrA
        jsr RangeFC
+       ldy yHi
_line   sty tmp3
        lda (ptrA),y
        beq _nl
        lda rowTop              ; the line: rowTop + 27 - y
        clc
        adc #27
        sec
        sbc tmp3
        sec
        sbc marioFirst          ; Mario's row of it
        bcc _nl
        cmp #21
        bcs _nl
        tax
        lda MarioRow,x
        beq _nl
        sta v0                  ; Mario's byte at pixel marioPx, the barrel's at p1x
        lda (ptrA),y
        ldx refp1
        beq +
        tax
        lda Reverse,x
+       sta v1
        lda p1x
        sec
        sbc marioPx             ; dx = barrel - Mario
        bcc _left
        cmp #8
        bcs _nl
        tax                     ; dx >= 0: (mario << dx) & barrel
        lda v0
_sh1    dex
        bmi +
        asl
        jmp _sh1
+       and v1
        bne _hit
        beq _nl
_left   eor #$ff                ; dx < 0: (barrel << -dx) & mario
        clc
        adc #1
        cmp #8
        bcs _nl
        tax
        lda v1
_sh2    dex
        bmi +
        asl
        jmp _sh2
+       and v0
        beq _nl
_hit    lda #$80
        sta CXPPMM
_nl     ldy tmp3
        cpy yLo
        beq _nextrow
        dey
        jmp _line
_nextrow
        dec row
        bmi +
        jmp _row
+       lda #1                  ; RowPx done
        sta pxDone
        ; --- the hammer's missile against Mario, on the hammer row's 14 lines
        lda marioFirst          ; Mario's lines (marioFirst .. +20) meet lines 103-116?
        sec
        sbc #HAMMERLINE - 20
        cmp #34
        bcs _nohit
        lda HammerX             ; the missile (HammerX - 5, up to 4 wide) meets his 8 pixels?
        clc
        sbc marioPx             ; (HammerX - marioPx - 1 ...
        sec
        sbc #1                  ; ... - 1 = HammerX - marioPx - 2: 0 .. 10)
        cmp #11
        bcs _nohit
        jsr NeedMario
        lda HammerX
        sec
        sbc #5
        sta v2                  ; missile pixel
        lda #2
        ldx HammerPtr
        cpx #$a7
        bne +
        lda #4
+       sta v3                  ; its width
        ldx HammerPtr
        stx ptrA
        lda #$ff
        sta ptrA+1
        ldy #27
_hl     sty tmp3
        lda (ptrA),y            ; (ENAM1: bit 1 enables)
        and #2
        beq _hn
        tya
        eor #$ff                ; line = HAMMERLINE + 27 - y
        clc
        adc #HAMMERLINE + 28
        sec
        sbc marioFirst
        bcc _hn
        cmp #21
        bcs _hn
        tax
        lda MarioRow,x
        beq _hn
        sta v0
        ldx v3                  ; each missile pixel against Mario's byte
        lda v2
        sta v4
-       lda v4
        sec
        sbc marioPx
        bcc +
        cmp #8
        bcs +
        tay                     ; bit 7 - (px - marioPx)
        lda Bit7,y
        and v0
        bne _hhit
+       inc v4
        dex
        bne -
_hn     ldy tmp3
        dey
        cpy #14
        bcs _hl
        rts
_hhit   lda #$80
        sta CXM1P
_nohit  rts

; CXP1FB bit 6, player 1 against the ball: the hammer row's barrel (row 4) against the
; hammer's head, on the row's upper 14 lines (y 27..14, where the kernel draws the ball from
; its enable table, page $FF at HammerPtr+2). The ball is 4 pixels from HammerX - 6 at rest,
; 2 pixels from HammerX - 1 (facing right) or HammerX - 7 while the hammer swings (as
; RenderHammer draws it). The game smashes a barrel in row 4 when it is set.
SmashCheck:
        lda #0
        sta CXP1FB
        ldx #4
        lda RowGfx,x
        cmp #$5d
        beq _none
        sta ptrA                ; the barrel's shape (page $FC)
        lda #$fc
        sta ptrA+1
        lda HammerPtr+2         ; the ball's enable table
        sta ptrB
        lda #$ff
        sta ptrB+1
        lda #5                  ; player 1's pixel in row 4: row 5's, unless row 4 positions it
        sta row
        jsr BarrelPixel
        ldx #4
        lda RowCoarse,x
        bmi +
        stx row
        jsr BarrelPixel
+       jsr SetRefp1
        lda #4                  ; the ball's width and first pixel, less the barrel's (v4)
        sta v3
        lda HammerX
        sec
        sbc #6
        ldx HammerPtr
        cpx #$a7
        bne +
        lda #2
        sta v3
        lda HammerX
        sec
        sbc #7
        ldx Facing
        beq +
        clc
        adc #6
+       sec
        sbc p1x
        sta v4
        ldy #27
_line   lda (ptrB),y            ; the ball on this line (ENABL: bit 1) ...
        and #2
        beq _next
        lda (ptrA),y            ; ... and the barrel
        beq _next
        ldx refp1
        beq +
        tax
        lda Reverse,x
+       sta v0
        lda v3                  ; each ball pixel against the barrel's byte (a pixel left of
        sta v1                  ; the barrel reads as 128 or more: none)
        lda v4
        sta v5
-       lda v5
        cmp #8
        bcs +
        tax
        lda Bit7,x
        and v0
        bne _hit
+       inc v5
        dec v1
        bne -
_next   dey
        cpy #14
        bcs _line
_none   rts
_hit    lda #$40
        sta CXP1FB
        rts

; Mario's lines if this tick hasn't worked them out yet
NeedMario:
        lda marioDone
        bne +
        jmp MarioLines
+       rts

; Mario's first line (marioFirst, $FF: none) and pixel (marioPx), as MarioLines finds them
MarioTop:
        lda MarioX
        sec
        sbc #4
        sta marioPx
        lda #5
        sta row
-       ldx row
        lda RowColour,x
        cmp #$22
        beq +
        jsr RowBounds
        ldx row
        lda RowColour,x
        jsr RangeFB
        bcc +
        lda rowTop
        clc
        adc #27
        sec
        sbc yHi
        sta marioFirst
        rts
+       dec row
        bpl -
        lda #$ff
        sta marioFirst
        rts

; Mario as the kernel draws him: for each line, his shape byte where his colour table says he
; shows (reflected as REFP0 has it), into MarioRow (21 rows from his first line, marioFirst);
; marioPx his pixel. Also the first colour and the colour changes for the renderer (MarioCol).
MarioLines:
        lda #1
        sta marioDone
        lda #$ff
        sta marioFirst
        lda #0
        .for i = 0, i < 21, i += 1
        sta MarioRow + i
        sta MarioCol + i
        .endfor
        lda MarioX
        sec
        sbc #4
        sta marioPx
        jsr SetRefp0
        lda #5
        sta row
_row    ldx row
        lda RowColour,x
        cmp #$22
        beq _next
        sta ptrB
        lda #$fb
        sta ptrB+1
        jsr RowBounds
        lda ptrB
        jsr RangeFB             ; the lines where his colour isn't 0
        bcc _next
        lda rowTop              ; the range's first line (a non-zero colour)
        clc
        adc #27
        sec
        sbc yHi
        ldx marioFirst          ; the first such line is his first
        cpx #$ff
        bne +
        sta marioFirst
+       sec
        sbc marioFirst          ; X = his row for that line, then one more per line
        cmp #21
        bcs _next
        tax
        ldy yHi
_line   lda (ptrB),y
        beq _nl
        sta MarioCol,x
        lda refp0
        bne _refl
        lda MarioGfx,y
        sta MarioRow,x
        jmp _nl
_refl   sty tmp3
        lda MarioGfx,y
        tay
        lda Reverse,y
        ldy tmp3
        sta MarioRow,x
_nl     inx
        cpx #21
        bcs _next
        cpy yLo
        beq _next
        dey
        jmp _line
_next   dec row
        bpl _row
        rts

; REFP0 as the kernel sets it: Mario's facing ($08 right), or while climbing from his Y
SetRefp0:
        lda Facing
        bpl +
        lda MarioY
        and #4
        asl
+       and #8
        sta refp0
        rts
; REFP1: barrels flip every 8 frames; fireballs (the rivets screen) don't
SetRefp1:
        lda #0
        ldx Level
        bne +
        lda $e8                 ; FrameCount
        and #8
+       sta refp1
        rts

; The row in `row`: its first line and the last kernel y (the bottom row stops at y = 13)
RowBounds:
        lda #5
        sec
        sbc row
        tax
        lda RowTopTab,x
        sta rowTop
        lda #3
        ldx row
        bne +
        lda #13
+       sta yEnd
        rts
; The lines of the row in `row` (RowBounds done) where a table the kernel reads through (ptr),y
; for y = 27 .. 0 has non-zero bytes: A = the table's low byte, in page $FB (Mario's colours),
; $FC (the barrels' shapes) or $FF (the hammer's enables). Carry set: y from yHi down to yLo;
; clear: none. (The bottom row's kernel stops at y = 13.)
RangeFB:
        tay
        lda RngLo,y
        sta yLo
        lda RngHi,y
        jmp RangeClip
RangeFC:
        tay
        lda RngLo+$100,y
        sta yLo
        lda RngHi+$100,y
RangeClip:
        cmp #$ff
        beq _none
        sta yHi
        lda row
        bne +
        lda yLo
        cmp #13
        bcs +
        lda #13
        sta yLo
+       lda yHi
        cmp yLo
        rts
_none   clc
        rts

; Build RngLo / RngHi: for each pointer low byte, the lowest and highest y (0-27) with a
; non-zero byte at (pointer),y, in pages $FB, $FC and $FF of the 2600 program ($FF: none)
InitRanges:
        ldx #2
_page   lda RngPages,x
        sta ptrA+1
        txa
        clc
        adc #>RngLo
        sta ptrB+1
        adc #3
        sta ptrC+1
        lda #0
        sta ptrA
        sta ptrB
        sta ptrC
_ptr    lda #$ff
        sta tmp                 ; the highest
        sta tmp2                ; the lowest
        ldy #27
-       lda (ptrA),y
        beq +
        sty tmp2
        lda tmp
        cmp #$ff
        bne +
        sty tmp
+       dey
        bpl -
        ldy ptrA
        lda tmp2
        sta (ptrB),y
        lda tmp
        sta (ptrC),y
        inc ptrA
        bne _ptr
        dex
        bpl _page
        rts
RngPages:   .byte $fb, $fc, $ff

RowTopTab:  .byte ROWTOP, ROWTOP + 28, ROWTOP + 56, ROWTOP + 84, ROWTOP + 112, ROWTOP + 140

; The row's barrel pixel from RowCoarse (X) and RowFine: p1x = 15 * coarse + FineX[fine >> 4]
BarrelPixel:
        ldx row
        lda RowFine,x
        lsr
        lsr
        lsr
        lsr
        tay
        lda RowCoarse,x
        and #7
        tax
        lda Mul15,x
        clc
        adc FineX,y
        sta p1x
        rts

Bit7:   .byte $80, $40, $20, $10, $08, $04, $02, $01
