; ================================================================= render
; Draw the last tick's picture: the bitmap (only what changed) and the sprites with their
; colour events into the buffer the display isn't using, then hand it over (pending).
Render:
        lda pending             ; the last frame hasn't been shown yet
        beq +
        rts
+       jsr NeedMario           ; (if the last tick didn't work out Mario's lines)
        jsr RenderBitmap
        lda curBuf
        eor #1
        sta rbuf                ; buffer being drawn
        asl
        asl
        asl
        sta bufOfs
        lda #BLK_SET
        ldx rbuf
        beq +
        lda #BLK_SET + NBLK
+       sta blkOfs
        lda #0
        ldx rbuf
        beq +
        lda #NEV
+       sta evOfs
        lda #0
        sta evN
        ldx rbuf
        sta StMsb,x
        lda #%00000110          ; Kong and Pauline (their other registers are fixed: InitShapes)
        sta StEn,x
        lda BgColour
        jsr C64Colour
        ldx rbuf
        sta StBg,x
        jsr Colup1              ; the barrels' colour: the hammer's missile ($D025, and the
        ldx rbuf                ; sprite's own colour where the ball is under it) ...
        sta StMc1,x
        ldy bufOfs
        sta StCol+3,y
        lda PfColour            ; ... and its ball, the girders' colour ($D026)
        jsr C64Colour
        ldx rbuf
        sta StMc2,x

        jsr RenderKong
        jsr RenderPauline
        jsr RenderMario
        jsr RenderHammer
        jsr RenderBarrels
        lda evOfs               ; the end marker
        clc
        adc evN
        tay
        lda #ENDRASTER
        sta EvRas,y
        lda #1
        sta pending
        rts

; A 2600 colour in A -> C64 colour (Y used)
C64Colour:
        lsr
        tay
        lda ColorMap,y
        rts
; COLUP1 in the girder rows: Pauline's loop leaves her last line's colour there -> C64 colour
Colup1:
        lda $f9e3+1
        jmp C64Colour
; COLUP0 / COLUP1 for the score: $8A, or $DA while a game is on (GameState bit 7) -> C64 colour
ScoreColour:
        lda #$8a
        ldx GameState
        bpl +
        lda #$da
+       jmp C64Colour

; Stage sprite X (Y = sprite): A = 2600 pixel -> x = 24 + 2 A, with its MSB
StageX:
        sty tmp
        sta tmp2
        lda #0
        sta tmp3
        lda tmp2
        asl
        rol tmp3
        clc
        adc #24
        bcc +
        inc tmp3
+       pha
        lda tmp3
        beq +
        ldy tmp
        lda Bit,y
        ldx rbuf
        ora StMsb,x
        sta StMsb,x
+       lda bufOfs
        clc
        adc tmp
        tax
        pla
        sta StX,x
        rts
; Enable sprite Y in the staged registers
StageOn:
        ldx rbuf
        lda Bit,y
        ora StEn,x
        sta StEn,x
        rts
; Add a colour event: A = raster line, X = sprite, Y = C64 colour
AddEvent:
        sta evA
        stx evX
        sty evY
        ldy evN
        cpy #NEV-1
        bcs _full
        sty tmp3
        tya
        clc
        adc evOfs
        tay
        lda evA
        sta EvRas,y
        lda evX
        clc
        adc #$27                ; $D027 + sprite
        sta EvReg,y
        lda evA                 ; on a badline: bit 7 (the interrupt writes it on the line
        and #7                  ; before)
        cmp #BADLINE & 7
        bne +
        lda EvReg,y
        ora #$80
        sta EvReg,y
+
        lda evY
        sta EvVal,y
        inc evN
        ldy tmp3                ; keep the list sorted by line (insertion)
-       dey
        bmi _full
        tya
        clc
        adc evOfs
        tax
        lda EvRas+1,x
        cmp EvRas,x
        bcs _full
        lda EvRas,x             ; swap entries x and x+1
        pha
        lda EvRas+1,x
        sta EvRas,x
        pla
        sta EvRas+1,x
        lda EvReg,x
        pha
        lda EvReg+1,x
        sta EvReg,x
        pla
        sta EvReg+1,x
        lda EvVal,x
        pha
        lda EvVal+1,x
        sta EvVal,x
        pla
        sta EvVal+1,x
        jmp -
_full   rts

; --- Kong: sprite 1, double width, facing the way Mario faces (REFP0)
RenderKong:
        lda #BLK_KONG
        ldx refp0
        beq +
        lda #BLK_KONG+1
+       ldx bufOfs
        sta StPtr+1,x
        rts

; --- Pauline: sprite 2, her colour changing down her 20 lines (fixed events)
RenderPauline:
        ldy evOfs               ; her events: the list's first (nothing above her has any),
        ldx #1                  ; in line order
-       lda PaulineEvLine,x
        beq +
        sta EvRas,y
        lda PaulineEvReg,x
        sta EvReg,y
        lda PaulineCol,x
        sta EvVal,y
        iny
        inx
        bne -
+       dex
        stx evN
        rts

; --- Mario: sprite 0, from MarioRow / MarioCol (Collide's MarioLines)
RenderMario:
        lda marioFirst
        cmp #$ff
        bne +
        rts
+       lda blkOfs              ; the block: 21 rows of (shape, 0, 0) (the zeros stay from
        clc                     ; InitVideo: his blocks hold nothing else)
        adc #B_MARIO
        ldx bufOfs
        sta StPtr+0,x
        jsr BlockAddr
        ldy #60
        ldx #20
-       lda MarioRow,x
        sta (ptrA),y
        dey
        dey
        dey
        dex
        bpl -
        lda marioFirst
        clc
        adc #SPRYOFS
        adc DbgMarioDY          ; (testing aid: Mario and his colours N lines lower)
        ldx bufOfs
        sta StY+0,x
        lda marioPx
        ldy #0
        jsr StageX
        ldy #0
        jsr StageOn
        lda #0                  ; the colour of his first line, then an event per change
        sta lastCol
        tax
_col    lda MarioCol,x
        beq _nc
        cmp lastCol
        beq _nc
        sta lastCol
        stx lineL
        jsr C64Colour
        tay
        lda lineL
        bne +
        tya
        ldx bufOfs
        sta StCol+0,x
        jmp _same
+       clc
        adc marioFirst
        clc
        adc #RASTEROFS
        adc DbgMarioDY          ; (testing aid)
        ldx #0
        jsr AddEvent
_same   ldx lineL
_nc     inx
        cpx #21
        bne _col
        rts

; A = block number -> ptrA = its address
BlockAddr:
        sta ptrA+1
        lda #0
        lsr ptrA+1              ; block * 64 = block << 6
        ror
        lsr ptrA+1
        ror
        sta ptrA
        lda ptrA+1
        clc
        adc #>SPRDATA
        sta ptrA+1
        rts

; --- the hammer: sprite 3, multicolour (a pixel = one 2600 pixel): the missile (colour 1,
; $D025: COLUP1) and the ball (colour 2, $D026: COLUPF), on the hammer row's 14 lines.
; The sprite starts at pixel HammerX - 7: the missile is at HammerX - 5 (2 wide; 4 while the
; hammer swings), the ball at HammerX - 6 (4 wide) at rest, HammerX - 1 or - 7 (2 wide) swinging.
RenderHammer:
        lda HammerX
        sec
        sbc #7
        sta sprX
        lda #2
        sta v0                  ; the missile: pixel 2 of the sprite, 2 wide
        sta v1
        lda #1
        sta v2                  ; the ball: pixel 1, 4 wide
        lda #4
        sta v3
        lda HammerPtr
        cmp #$a7
        bne _rest
        lda #4
        sta v1
        lda #2
        sta v3
        lda #6
        ldx Facing
        bne +
        lda #0
+       sta v2
_rest   lda blkOfs
        clc
        adc #B_HAMMER
        ldx bufOfs
        sta StPtr+3,x
        lda rbuf                ; this buffer's block already holds this hammer? (it
        asl                     ; depends on the two tables and the ball's place)
        adc rbuf
        tax
        lda HammerPtr
        cmp HamKey,x
        bne _draw
        lda HammerPtr+2
        cmp HamKey+1,x
        bne _draw
        lda v2
        cmp HamKey+2,x
        bne _draw
        ldx rbuf
        lda HamShown,x
        sta v5
        jmp _stage
_draw   lda HammerPtr
        sta HamKey,x
        lda HammerPtr+2
        sta HamKey+1,x
        lda v2
        sta HamKey+2,x
        lda #<HamPat            ; a row's missile pixels (HamPat 0-2) and ball pixels (3-5),
        sta ptrA                ; the same on every line they show
        lda #>HamPat
        sta ptrA+1
        lda #0
        ldx #5
-       sta HamPat,x
        dex
        bpl -
        sta v4
        lda #%01000000          ; missile pixels: colour 1
        ldx v0
        ldy v1
        jsr McPixels
        lda #3
        sta v4
        lda #%10000000          ; ball pixels: colour 2
        ldx v2
        ldy v3
        jsr McPixels
        lda blkOfs
        clc
        adc #B_HAMMER
        jsr BlockAddr
        lda HammerPtr           ; the missile's enable table (page $FF) ...
        sta ptrB
        lda #$ff
        sta ptrB+1
        lda HammerPtr+2         ; ... and the ball's
        sta ptrC
        lda #$ff
        sta ptrC+1
        lda #0
        sta v5                  ; anything drawn?
        sta v4                  ; the block's byte for the row (3 * (27 - y))
        ldy #27
_line   sty tmp3
        ldx #0                  ; the line's three bytes in v0-v2 (the pixel numbers are done)
        stx v0
        stx v1
        stx v2
        lda (ptrB),y            ; (ENAM1 / ENABL: bit 1 enables; the "no hammer" table
        and #2                  ; has $F0 on two lines)
        beq +
        lda HamPat+0
        sta v0
        lda HamPat+1
        sta v1
        lda HamPat+2
        sta v2
        inc v5
+       lda (ptrC),y
        and #2
        beq +
        lda HamPat+3
        ora v0
        sta v0
        lda HamPat+4
        ora v1
        sta v1
        lda HamPat+5
        ora v2
        sta v2
        inc v5
+       ldy v4
        lda v0
        sta (ptrA),y
        iny
        lda v1
        sta (ptrA),y
        iny
        lda v2
        sta (ptrA),y
        iny
        sty v4
        ldy tmp3
        dey
        cpy #14
        bcs _line
        ldx rbuf
        lda v5
        sta HamShown,x
_stage  lda v5
        beq +
        lda #HAMMERLINE + SPRYOFS
        ldx bufOfs
        sta StY+3,x
        lda sprX
        ldy #3
        jsr StageX
        ldy #3
        jsr StageOn
+       rts
; Y pixels of colour A (as bits 7-6) from pixel X of the row whose first byte is v4, in the
; block at ptrA
McPixels:
        sta mcBits
        sty mcCnt
_px     txa
        pha
        lsr
        lsr
        clc
        adc v4                  ; byte: row * 3 + pixel / 4
        sta mcByte
        pla
        pha
        and #3                  ; the pixel's bits: shift right 2 * (pixel & 3)
        tay
        lda mcBits
-       dey
        bmi +
        lsr
        lsr
        jmp -
+       ldy mcByte
        ora (ptrA),y
        sta (ptrA),y
        pla
        tax
        inx
        dec mcCnt
        bne _px
        lda #1
        sta v5
        rts

; --- barrels: each row's player 1, sprites 4-7; a straddling barrel is one sprite
RenderBarrels:
        jsr SetRefp1
        jsr Colup1
        sta v1                  ; their colour
        lda #4
        sta sprN
        lda #$ff
        sta sprFirst            ; no sprite open
        lda #0
        sta p1x
        lda #5
        sta row
        bne _row                ; (always)
_skip   jmp _nextrow
_row    ldx row
        lda pxDone              ; the last tick's Collide has the rows' pixels
        beq +
        lda RowPx,x
        sta p1x
        jmp _gfx
+       cpx #5                  ; the kernel positions player 1 for the row unless the row's
        beq _pos                ; coarse count has bit 7 (a barrel reaching into it from above)
        lda RowCoarse,x
        bmi _gfx
_pos    jsr BarrelPixel
_gfx    ldx row
        lda RowGfx,x
        cmp #$5d
        beq _skip
        sta ptrB
        lda #$fc
        sta ptrB+1
        jsr RowBounds
        lda ptrB
        jsr RangeFC             ; the lines where the shape isn't 0
        bcc _skip
        lda rowTop              ; the range's first line and its line count - 1
        clc
        adc #27
        sec
        sbc yHi
        sta lineL
        lda yHi
        sec
        sbc yLo
        sta v2
        lda sprFirst            ; the open sprite takes the whole range? (the same pixel, all
        cmp #$ff                ; within its 21 lines)
        beq _open
        lda p1x
        cmp sprX
        bne _close
        lda lineL
        clc
        adc v2
        sec
        sbc sprFirst
        cmp #21
        bcs _close
        lda sprN                ; (the block now holds two pieces: no key for it)
        sec
        sbc #4
        clc
        adc blkOfs
        adc #B_BARREL
        tax
        lda #$ff
        sta BlkGfx,x
        lda lineL
        sec
        sbc sprFirst
        jmp _put
_close  jsr CloseBarrel
_open   lda sprN
        cmp #8
        bcs _skip               ; (no sprite left: the rows that follow find none either)
        lda lineL
        sta sprFirst
        lda p1x
        sta sprX
        lda sprN
        sec
        sbc #4
        clc
        adc blkOfs
        adc #B_BARREL
        tax
        jsr BlockAddr
        lda ptrB                ; the block holds this very shape already (from two frames
        cmp BlkGfx,x            ; ago, its buffer's last)? the same table, reflection and
        bne _new                ; line count
        lda refp1
        cmp BlkRef,x
        bne _new
        ldy v2
        iny
        tya
        cmp BlkRows,x
        bne _new
        sta sprRows
        jmp _nextrow
_new    lda ptrB
        sta BlkGfx,x
        lda refp1
        sta BlkRef,x
        ldy BlkRows,x           ; clear the rows it had last time (only their first byte:
        beq +                   ; a barrel is 8 pixels wide)
        lda #0
        sta BlkRows,x
        tya
        sta tmp2
        asl
        adc tmp2
        tay
        lda #0
-       dey
        dey
        dey
        sta (ptrA),y
        bne -
+
        lda #0
_put    sta tmp2                ; the range's first row in the block
        sec
        adc v2
        sta sprRows             ; (the rows it has: up to the range's last)
        lda tmp2
        asl
        adc tmp2
        tay                     ; that row's first byte: 3 * row
        lda ptrB                ; the shape: $FC00 + low byte + y, y from yHi down (the
        clc                     ; pointers the game uses stay within the page)
        adc yHi
        tax
        inc v2                  ; the line count
        lda refp1
        bne _refl
-       lda $fc00,x
        sta (ptrA),y
        iny
        iny
        iny
        dex
        dec v2
        bne -
        jmp _nextrow
_refl
-       lda $fc00,x             ; reflected: the bits reversed
        sty tmp
        tay
        lda Reverse,y
        ldy tmp
        sta (ptrA),y
        iny
        iny
        iny
        dex
        dec v2
        bne -
_nextrow
        dec row
        bmi +
        jmp _row
+       lda sprFirst
        cmp #$ff
        beq _done
        jsr CloseBarrel
_done   rts
; the open barrel sprite: stage it
CloseBarrel:
        lda sprN
        sec
        sbc #4
        clc
        adc blkOfs
        adc #B_BARREL
        sta tmp2
        tax
        lda sprRows
        sta BlkRows,x
        lda bufOfs
        clc
        adc sprN
        tax
        lda tmp2
        sta StPtr,x
        lda sprFirst
        clc
        adc #SPRYOFS
        sta StY,x
        lda v1
        sta StCol,x
        lda sprX
        ldy sprN
        jsr StageX
        ldy sprN
        jsr StageOn
        inc sprN
        lda #$ff
        sta sprFirst
        rts

; ================================================================ bitmap
; The playfield (girders, ladders, the lives, the top girder), the score digits and the
; colour cells, redrawn when what they depend on changes (ScrKeys).
RenderBitmap:
        ; colour cells: girders in the playfield colour on the background colour
        lda PfColour
        jsr C64Colour
        asl
        asl
        asl
        asl
        sta tmp
        lda BgColour
        jsr C64Colour
        ora tmp
        sta tmp2
        jsr ScoreColour         ; the score digits' cells: their colour on the background
        asl
        asl
        asl
        asl
        sta tmp3
        lda BgColour
        jsr C64Colour
        ora tmp3
        sta tmp3                ; the digit cells' colour
        lda tmp2
        cmp ScrKeys+0
        bne _cells
        lda tmp3
        cmp ScrKeys+12
        beq +
_cells  lda tmp2
        sta ScrKeys+0
        ldx #0
-       sta SCREEN,x
        sta SCREEN+$100,x
        sta SCREEN+$200,x
        sta SCREEN+$2e8,x
        inx
        bne -
        lda tmp3                ; the digits' cells (lines 42-48: rows 0 and 1, cells 13-26)
        sta ScrKeys+12
        ldx #13
-       sta SCREEN,x
        sta SCREEN+40,x
        inx
        cpx #27
        bne -
+       ; the score digits: from the score, or (a game on) the lives and the bonus
        lda GameState
        and #$80
        sta tmp
        ldx #$87
        ldy GameState
        bpl +
        ldx #$a3
+       stx ptrA
        lda #0
        sta ptrA+1
        ldy #0
        lda (ptrA),y
        cmp ScrKeys+1
        bne _digits
        iny
        lda (ptrA),y
        cmp ScrKeys+2
        bne _digits
        lda tmp
        cmp ScrKeys+3
        beq _lives
_digits ldy #0
        lda (ptrA),y
        sta ScrKeys+1
        iny
        lda (ptrA),y
        sta ScrKeys+2
        lda tmp
        sta ScrKeys+3
        jsr DrawDigits
_lives  lda Lives
        cmp ScrKeys+4
        beq +
        sta ScrKeys+4
        jsr DrawLives
+       ; the girder rows: all of them when the level changes, else those whose rivets changed
        lda Level
        cmp ScrKeys+5
        bne _rows
        lda #5
        sta row
-       ldx row
        lda Rivets,x
        cmp ScrKeys+6,x
        beq +
        sta ScrKeys+6,x
        jsr DrawRow
+       dec row
        bpl -
        rts
_rows   lda Level
        sta ScrKeys+5
        ldx #5
-       lda Rivets,x
        sta ScrKeys+6,x
        dex
        bpl -
        jsr CachedRows          ; a screen as it starts: its picture made at start-up
        bcs +
        jsr DrawRows
+       jmp DrawLives           ; (mirrored or not by the level)

; The top girder and the six girder rows
DrawRows:
        jsr DrawGirderTop
        lda #5
        sta row
-       jsr DrawRow
        dec row
        bpl -
        rts

; ------------------------------------------------ the two screens' pictures, made at start-up
; A screen change used to draw every girder line (~210K cycles, ~11 frames); the screens'
; girder pictures (character rows 3-23 of the bitmap: the top girder and the six rows) are
; drawn once at start-up into RAM at $8000 and copied in (~64K cycles). The barrels screen's
; doesn't depend on the rivets; the rivets screen's is the one it starts with (Rivets 0-5:
; each row's index, none taken); with rivets taken it is drawn as before.
CACHEROWS   = BITMAP + 3 * 320          ; the bitmap's character rows 3..
CACHEPAGES  = 27                        ; ... 23 (and a little of row 24, which is empty)
CACHE0      = $8000
CACHE1      = CACHE0 + CACHEPAGES * 256
        .cerror CACHE1 + CACHEPAGES * 256 > $c000, "screen pictures overflow"

; Carry set: the picture for Level (and its rivets) copied in from its start-up copy
CachedRows:
        lda Level
        beq _l0
        ldx #5
-       txa
        cmp Rivets,x
        bne _no
        dex
        bpl -
        jmp CopyIn1             ; (carry set by the last compare)
_l0     jsr CopyIn0
        sec
        rts
_no     clc
        rts

; Make both pictures (InitVideo; the game's Level and Rivets put back after)
InitCaches:
        lda Level
        pha
        ldx #5
-       lda Rivets,x
        pha
        dex
        bpl -
        lda #0
        sta Level
        jsr DrawRows
        jsr CopyOut0
        lda #1
        sta Level
        ldx #5
-       txa
        sta Rivets,x
        dex
        bpl -
        jsr DrawRows
        jsr CopyOut1
        ldx #0
-       pla
        sta Rivets,x
        inx
        cpx #6
        bne -
        pla
        sta Level
        rts

; the copies: 27 pages from ptrA to ptrB, one loop of 256 over all of them (~9 cycles a byte):
; the 27 load / store pairs' addresses are patched in first
CopyIn0:
        ldx #<CACHE0
        ldy #>CACHE0
        bne CopyIn
CopyIn1:
        ldx #<CACHE1
        ldy #>CACHE1
CopyIn  stx ptrA
        sty ptrA+1
        lda #<CACHEROWS
        sta ptrB
        lda #>CACHEROWS
        sta ptrB+1
        jmp CopyPages
CopyOut0:
        ldx #<CACHE0
        ldy #>CACHE0
        bne CopyOut
CopyOut1:
        ldx #<CACHE1
        ldy #>CACHE1
CopyOut stx ptrB
        sty ptrB+1
        lda #<CACHEROWS
        sta ptrA
        lda #>CACHEROWS
        sta ptrA+1
CopyPages:
        lda ptrA+1
        sta tmp
        lda ptrB+1
        sta tmp2
        ldx #0
-       lda ptrA
        sta _cp+1,x
        lda tmp
        sta _cp+2,x
        lda ptrB
        sta _cp+4,x
        lda tmp2
        sta _cp+5,x
        inc tmp
        inc tmp2
        txa
        clc
        adc #6
        tax
        cpx #6 * CACHEPAGES
        bne -
        ldx #0
_loop
_cp
        .rept CACHEPAGES
        lda $ffff,x             ; (patched: page p of the source ...
        sta $ffff,x             ; ... and of the destination)
        .endrept
        inx
        beq +
        jmp _loop
+       sec
        rts

; --- the six digits (lines 42-48): 2600 pixels 55 + 8 i, from the font at $FC00; while a game
; is on the first two are blank and the others show the lives and the bonus
DrawDigits:
        ldx #$87
        ldy GameState
        bpl +
        ldx #$a3
+       stx ptrA
        lda #0
        sta ptrA+1              ; (ptrA = $87 or $A3: the two bytes to show)
        ldy #0
        lda (ptrA),y
        lsr
        lsr
        lsr
        lsr
        sta DigLo+0
        lda (ptrA),y
        and #15
        sta DigLo+1
        iny
        lda (ptrA),y
        lsr
        lsr
        lsr
        lsr
        sta DigLo+2
        lda (ptrA),y
        and #15
        sta DigLo+3
        lda #0
        sta DigLo+4
        sta DigLo+5
        ldx #5                  ; the font: digit * 8, low byte of its address in page $FC
-       lda DigLo,x
        asl
        asl
        asl
        sta DigLo,x
        dex
        bpl -
        lda GameState
        bpl +
        lda #$5d                ; blank
        sta DigLo+0
        sta DigLo+1
+       lda #6                  ; font rows 6 (top) .. 0
        sta v0
_line   lda #42 + 6 - LINEOFS   ; screen line 2 + (6 - row)
        sec
        sbc v0
        tax
        lda BmpLo,x
        sta ptrB
        lda BmpHi,x
        sta ptrB+1
        ldx #0                  ; the line's 14 bytes from byte 13 (2600 pixel 52) on, built
-       lda #0                  ; in LineBuf: digit i at bit 6 + 16 i
        sta LineBuf,x
        inx
        cpx #16
        bne -
        ldx #0
_dig    lda DigLo,x
        clc
        adc v0
        sta ptrA
        lda #$fc
        sta ptrA+1
        ldy #0
        lda (ptrA),y
        beq _nd
        tay
        lda Dig6H,y             ; the glyph's 16 pixels, shifted right 6 within 3 bytes
        sta v1
        lda Dig6M,y
        sta v2
        lda Dig6L,y
        sta v3
        txa
        asl
        tay                     ; byte 2 i (+13)
        lda LineBuf,y
        ora v1
        sta LineBuf,y
        lda LineBuf+1,y
        ora v2
        sta LineBuf+1,y
        lda LineBuf+2,y
        ora v3
        sta LineBuf+2,y
_nd     inx
        cpx #6
        bne _dig
        ldx #0                  ; into the bitmap: cells 13 .. 26 of the line
        .for c = 0, c < 14, c += 1
        lda LineBuf + c
        ldy #(13 + c) * 8
        sta (ptrB),y
        .endfor
        dec v0
        bmi +
        jmp _line
+       rts

; Write tmp2 to cell A (0-39) of the bitmap line at ptrB (cell n is 8 n bytes along)
PutCell:
        asl
        asl
        asl
        tay
        bcc +
        inc ptrB+1              ; cells 32-39: the next page
        lda tmp2
        sta (ptrB),y
        dec ptrB+1
        rts
+       lda tmp2
        sta (ptrB),y
        rts
; ptrB = the bitmap line of screen line lineL
LinePtr:
        ldx lineL
        lda BmpLo,x
        sta ptrB
        lda BmpHi,x
        sta ptrB+1
        rts

; --- the lives marks (lines 58-65): PF1 on the right half, the value from the table at
; $FBF7 by lives; mirrored on the rivets screen
DrawLives:
        ldx Lives
        lda $fbf7,x
        sta v1
        lda #58 - LINEOFS
        sta lineL
-       lda #0
        sta PfL0
        sta PfL1
        sta PfL2
        sta PfR0
        sta PfR2
        lda v1
        sta PfR1
        jsr DrawPfLine
        inc lineL
        lda lineL
        cmp #66 - LINEOFS
        bne -
        rts

; --- the top girder (lines 70-71): PF1 = $0F, PF2 = $FF on the left; on the barrels screen
; the right half is cleared before it is drawn, on the rivets screen it mirrors the left
DrawGirderTop:
        lda #70 - LINEOFS
        sta lineL
-       lda #0
        sta PfL0
        sta PfR0
        sta PfR1
        sta PfR2
        lda #$0f
        sta PfL1
        lda #$ff
        sta PfL2
        ldx Level
        beq +
        lda #$0f
        sta PfR1
        lda #$ff
        sta PfR2
+       jsr DrawPfLine
        inc lineL
        lda lineL
        cmp #72 - LINEOFS
        bne -
        rts

; --- a girder row: its 25 kernel lines (the three boundary lines stay blank)
DrawRow:
        jsr RowBounds
        ldx row
        lda Level
        bne _lvl1
        cpx #5
        bne +
        lda #$4f                ; the top row's tables (set by the Kong loop)
        sta PfTab+0
        lda #$d4
        sta PfTab+1
        lda #$62
        sta PfTab+2
        lda #$91
        sta PfTab+3
        jmp _go
+       lda $ffe4,x             ; rows 4-0: from the row above's index (TFFE3 + row + 1 ...)
        sta PfTab+0
        lda $ffea,x
        sta PfTab+1
        lda $fff0,x
        sta PfTab+2
        lda $fe09,x
        sta PfTab+3
        jmp _go
_lvl1   lda Rivets,x            ; the rivets screen: pointer lows by the row's rivets taken
        tay
        lda $fbaf,y
        sta PfTab+0
        lda $fbc7,y
        sta PfTab+1
        lda $fbdf,y
        sta PfTab+2
_go     ldy #27
_line   sty tmp3
        lda rowTop
        clc
        adc #27
        sec
        sbc tmp3
        sec
        sbc #LINEOFS
        sta lineL
        lda #0
        sta PfL0
        sta PfR2
        lda row
        cmp #4
        bne _plain
        cpy #14
        bcc _plain
        ; the hammer row's upper 14 lines
        lda Level
        bne _h1
        lda #0                  ; barrels screen: PF1 left 0, PF2 left b, PF0 right stays 0,
        sta PfL1                ; PF1 right d, PF2 right 0
        sta PfR0
        jsr PfByte1
        sta PfL2
        jsr PfByte3
        sta PfR1
        jsr DrawPfLine
        jmp _nl
_h1     ldy tmp3
        lda $fa2a,y             ; rivets screen: PF2 from its table (both halves, mirrored),
        sta PfL2                ; PF1 from its table written at pixel 37: cells 4-8 and the
        sta PfR2                ; first pixel of cell 9 still show the line before's value
        lda $fa11,y
        sta PfL1
        sta PfR1
        lda #0
        sta PfR0
        cpy #27
        beq +
        lda $fa12,y             ; (the previous line's PF1: the table entry above)
+       sta cellOld
        jsr DrawPfLine
        jsr HammerRowSplit
        jmp _nl
_plain  lda Level
        bne _p1
        jsr PfByte0             ; barrels screen: left PF1 a, PF2 b; right PF0 c, PF1 d
        sta PfL1
        jsr PfByte1
        sta PfL2
        jsr PfByte2
        sta PfR0
        jsr PfByte3
        sta PfR1
        jsr DrawPfLine
        jmp _nl
_p1     jsr PfByte0             ; rivets screen: left PF1 a, PF2 b; the right half mirrors
        sta PfL1                ; the left, with PF2 = c from pixel 82 (cell 20's first two
        sta PfR1                ; pixels still show b's top bit)
        jsr PfByte1
        sta PfL2
        jsr PfByte2
        sta PfR2
        lda #0
        sta PfR0
        jsr DrawPfLine
        jsr RivetsSplit
_nl     ldy tmp3
        dey
        cpy yEnd
        bcc +
        jmp _line
+       rts
; the row's table bytes at y (tmp3): PfTab+n is the low byte, page by table
PfByte0:
        lda PfTab+0
        ldx #$fe
        ldy Level
        beq +
        ldx #$fa
+       jmp PfGet
PfByte1:
        lda PfTab+1
        ldx #$fe
        ldy Level
        beq +
        ldx #$fa
+       jmp PfGet
PfByte2:
        lda PfTab+2
        ldx #$ff
        ldy Level
        beq +
        ldx #$fa
+       jmp PfGet
PfByte3:
        lda PfTab+3
        ldx #$fd
PfGet:  sta ptrC
        stx ptrC+1
        ldy tmp3
        lda (ptrC),y
        rts

; Draw one playfield line (lineL = screen line) from PfL0-2 (left half, in effect for pixels
; 0-79) and PfR0-2 (right half): 40 bytes, a cell $FF or 0. The right half is mirrored on
; the rivets screen (CTRLPF bit 0 = Level). The 40 cells go into PfBits (5 bytes, the
; leftmost cell in the top bit), then into the bitmap.
DrawPfLine:
        jsr LinePtr
        ldx PfL0                ; cells 0-3: PF0 bits 4-7; 4-11: PF1 bits 7-0
        lda Reverse,x
        asl
        asl
        asl
        asl
        sta PfBits+0
        lda PfL1
        lsr
        lsr
        lsr
        lsr
        ora PfBits+0
        sta PfBits+0
        lda PfL1
        asl
        asl
        asl
        asl
        sta PfBits+1
        ldx PfL2                ; cells 12-19: PF2 bits 0-7
        lda Reverse,x
        sta tmp
        lsr
        lsr
        lsr
        lsr
        ora PfBits+1
        sta PfBits+1
        lda tmp
        asl
        asl
        asl
        asl
        sta PfBits+2
        lda Level               ; the right half
        and #1
        bne _mirror
        ldx PfR0                ; cells 20-23: PF0 bits 4-7; 24-31: PF1 bits 7-0; 32-39: PF2
        lda Reverse,x           ; bits 0-7
        and #$0f
        ora PfBits+2
        sta PfBits+2
        lda PfR1
        sta PfBits+3
        ldx PfR2
        lda Reverse,x
        sta PfBits+4
        jmp EmitCells
_mirror lda PfR2                ; mirrored: PF2 bits 7-0, PF1 bits 0-7, PF0 bits 7-4
        lsr
        lsr
        lsr
        lsr
        ora PfBits+2
        sta PfBits+2
        lda PfR2
        asl
        asl
        asl
        asl
        sta PfBits+3
        ldx PfR1
        lda Reverse,x
        sta tmp
        lsr
        lsr
        lsr
        lsr
        ora PfBits+3
        sta PfBits+3
        lda tmp
        asl
        asl
        asl
        asl
        sta PfBits+4
        lda PfR0
        lsr
        lsr
        lsr
        lsr
        ora PfBits+4
        sta PfBits+4
; PfBits -> the 40 cells of the bitmap line at ptrB (a cell n is 8 n bytes along: $FF or 0)
EmitCells:
        .for cb = 0, cb < 5, cb += 1
        lda PfBits + cb
        sta tmp
        .for bit = 0, bit < 8, bit += 1
        .if cb == 4 && bit == 0
        inc ptrB+1              ; cells 32-39: the next page
        .endif
        asl tmp                 ; the cell's bit into C: $FF if set, else 0
        lda #0
        adc #$ff
        eor #$ff
        ldy #((cb * 8 + bit) * 8) & $ff
        sta (ptrB),y
        .endfor
        .endfor
        dec ptrB+1
        rts

; rivets screen, a plain line: cell 20 (pixels 80-83): pixels 80-81 from PfL2 bit 7, 82-83
; from PfR2 bit 7
RivetsSplit:
        lda #0
        ldx PfL2
        bpl +
        ora #$f0
+       ldx PfR2
        bpl +
        ora #$0f
+       sta tmp2
        jsr LinePtr
        lda #20
        jmp PutCell
; rivets screen, the hammer row: cells 4-8 (PF1 bits 7-3) from the previous line's value
; (cellOld), cell 9: pixel 36 from it (bit 2), pixels 37-39 from this line's
HammerRowSplit:
        jsr LinePtr
        lda cellOld
        sta v1
        lda #4
        sta v4
-       asl v1
        lda #0
        bcc +
        lda #$ff
+       sta tmp2
        lda v4
        jsr PutCell
        inc v4
        lda v4
        cmp #9
        bne -
        lda #0                  ; cell 9
        sta tmp2
        lda cellOld
        and #4
        beq +
        lda #$c0
        sta tmp2
+       lda PfL1
        and #4
        beq +
        lda tmp2
        ora #$3f
        sta tmp2
+       lda #9
        jmp PutCell

; Kong's two blocks (double width, each pixel doubled; as the table has him, and reflected)
; and Pauline's, from the ROM's tables; her colour events
InitShapes:
        lda #BLK_KONG
        jsr BlockAddr
        lda #BLK_KONG+1
        jsr BlockAddr2
        ldx #20
        ldy #0
-       stx tmp
        lda $fb97,x             ; Kong's line (x = 20 .. 1: lines 50 .. 69)
        tax
        lda DblHi,x
        sta (ptrA),y
        lda DblLo,x
        iny
        sta (ptrA),y
        dey
        lda Reverse,x           ; reflected: the bits reversed
        tax
        lda DblHi,x
        sta (ptrC),y
        lda DblLo,x
        iny
        sta (ptrC),y
        iny
        iny
        ldx tmp
        dex
        bne -
        lda #BLK_PAULINE
        jsr BlockAddr
        ldx #20
        ldy #0
-       lda $fdab,x
        sta (ptrA),y
        iny
        iny
        iny
        dex
        bne -
        ; Pauline's colours: her first, then an event per change (lines 50 + 20 - x)
        lda $f9e3+20
        sta tmp
        jsr C64Colour
        sta PaulineCol
        ldx #19
        ldy #1
-       lda $f9e3,x
        cmp tmp
        beq _samecol
        sta tmp
        sty tmp2
        jsr C64Colour
        ldy tmp2
        sta PaulineCol,y
        txa
        eor #$ff
        clc
        adc #KONGLINE + 21 + RASTEROFS
        sta PaulineEvLine,y
        and #7                  ; her register, + $80 on a badline (see AddEvent)
        cmp #BADLINE & 7
        bne +
        lda #$27 + 2 + $80
        bne ++
+       lda #$27 + 2
+       sta PaulineEvReg,y
        iny
_samecol
        dex
        bne -
        lda #0
        sta PaulineEvLine,y
        ; Kong's and Pauline's fixed sprite registers, in both buffers
        lda #$34                ; Kong: COLUP0 as the Kong loop sets it
        jsr C64Colour
        sta StCol+1
        sta StCol+1+8
        lda PaulineCol
        sta StCol+2
        sta StCol+2+8
        lda #KONGLINE + SPRYOFS
        sta StY+1
        sta StY+1+8
        sta StY+2
        sta StY+2+8
        lda #24 + 2 * 34        ; (the real TIA starts a double-width player a pixel late)
        sta StX+1
        sta StX+1+8
        lda #24 + 2 * 63
        sta StX+2
        sta StX+2+8
        lda #BLK_PAULINE
        sta StPtr+2
        sta StPtr+2+8
        rts
; Dig6H/M/L: a font byte's 16 pixels (each doubled: DblHi/DblLo) shifted right 6 across 3 bytes
InitDigitTabs:
        ldx #0
-       lda DblHi,x
        sta v1
        lda DblLo,x
        sta v2
        lda #0
        sta v3
        ldy #6
-       lsr v1
        ror v2
        ror v3
        dey
        bne -
        lda v1
        sta Dig6H,x
        lda v2
        sta Dig6M,x
        lda v3
        sta Dig6L,x
        inx
        bne --
        rts
BlockAddr2:
        sta ptrC+1
        lda #0
        lsr ptrC+1
        ror
        lsr ptrC+1
        ror
        sta ptrC
        lda ptrC+1
        clc
        adc #>SPRDATA
        sta ptrC+1
        rts
