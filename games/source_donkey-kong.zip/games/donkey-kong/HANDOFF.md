# Donkey Kong port: handoff (2026-10-06: version 1.1 published to the web builder)

Version 0.1, in development, not published. Our own port (the Berzerk / Missile Command method),
not Zeiche's. Read this, `README.md` (what exists so far), the top-level README, and the memory
notes `donkey-kong-port`, `c64-vic-lessons` and `vice-launch-monitor`.

## Where it stands

| Part | State |
|---|---|
| Disassembly | `2600/donkey-kong.asm` rebuilds the ROM exactly (MD5 36b20c427975760cb9cf4a47e41369e4); RAM and routines named in `2600/symbols.js` (RAM-MAP.md generated) |
| Kernel model | `tools/model.js`: **exact**, 0 pixels differ over 12,000+ frames on both screens (barrels and rivets), with the real TIA's rules (`hmoveBlank`, `wideDelay`, `respDelay`); its two collisions (Mario-barrel CXPPMM, hammer-Mario CXM1P) match the 2600's latches |
| C64 game logic | `tools/lockstep.js`: **0 differences** over 3000 frames, 5 runs (seeds 1-4, both screens), collisions included. Tick ~3.7K cycles on average (7.6K at most; the 2600's own code is ~2.4-3.3K of it) |
| C64 picture | `tools/screencheck.js`: **clean**: 0 object and 0 colour differences over 1500 frames (seeds 1, 3, 5, and the rivets screen). Render ~6K cycles a frame |
| VICE timing | `tools/c64time.js --play`, 20 s of random play: **every frame drawn gets its frame top** (PAL 686 of 686, NTSC 812 of 812), 0 / 1 late main-loop passes |
| VICE play | Fire starts it, barrels roll, Mario moves, F1 resets, F2 restarts (first session); not re-checked by eye since this session's changes beyond the timing screenshots |
| Input, sound, F2 | Written (Berzerk's code), untested by ear / keyboard |

### This session (speed first, then the screen check)

* **The game ran at half speed or less in VICE and blinked** after the first commit of this
  session, though c64time said "0 late": the colour-event wait was `cmp $d012 / bne`, an exact
  match, and on a badline with sprites the CPU can get no cycle to read $D012 on the target
  line, so it waited a whole frame for that line to come round (frame tops every 2-3 frames;
  buffers and colours in the wrong frames). Now it waits for the line **or a later one**.
  c64time now compares frame tops with the frames VICE drew (its cycle stopwatch), which is
  what caught it. The raster compares are 9-bit aware too (`$D011` bit 7: below line 255
  every event has passed), and the frame end is done at once if its line has passed.

* **The raster interrupt** was the main NTSC problem: writing `$D012` with the beam's own line
  latches an interrupt; the "do it now" path then ran the event, and the latched interrupt
  started the *next* event early, which busy-waited up to a frame for its line. Now `_now` acks
  `$D019`, and an event more than 2 lines away re-arms the interrupt and returns (`_later`).
  Early interrupts still come now and then (`DbgIrqEarly`, ~1 per 30 frames on NTSC, cause not
  found: not the `_now` latch, not CIA, `$D019` = $F1), but they cost only a re-arm now.
* **Collide** works out Mario's first line cheaply (`MarioTop`) and builds his lines
  (`MarioLines`) only when a barrel is within 8 pixels and on his lines, or the hammer could
  touch him; `Render` builds them (`NeedMario`) if no tick did. It leaves each row's barrel
  pixel in `RowPx` for `RenderBarrels`.
* **Scans** of the ROM tables (Mario's colours page $FB, barrel shapes $FC, hammer $FF) use
  `RngLo/RngHi` (built at start-up by `InitRanges`, at $C000): per pointer low byte, the
  lines where the table isn't 0 (`RangeFB/FC`). The pointers the game uses give 8-14 lines.
* **RenderBarrels** decides once per row whether the open sprite takes the row, copies the
  row's lines in a tight loop, clears only the rows a block had (`BlkRows`), and skips the
  copy when the block already holds the same shape (`BlkGfx/BlkRef`). This also fixed
  open item 1 of the first session (a barrel missing in the hammer row).
* **RenderHammer** builds the missile's and ball's sprite bytes once (`HamPat`), and redraws
  the block only when its tables or the ball's place change (`HamKey`).
* **Kong and Pauline**: their fixed sprite registers are set once (`InitShapes`); Pauline's
  colour events are copied in order, not sorted in.
* **Bitmap**: `DrawPfLine` packs a line's 40 cells into 5 bytes and an unrolled emitter writes
  them (~20 cycles a cell, was ~80); a rivet taken redraws only its row; the lives marks are
  redrawn on a level change (they were never mirrored on the rivets screen); the digits use
  pre-shifted tables (`Dig6H/M/L`, `InitDigitTabs`) and unrolled stores.
* **Colours**: COLUP1 in the girder rows is Pauline's last line colour ($2F, from $F9E4), not
  $8A: the barrels, the hammer's missile ($D025) and the hammer sprite's own colour (where the
  ball is under the missile; the missile wins, CTRLPF has no priority bit) use it. The score's
  colour is $8A, or $DA while a game is on (GameState bit 7) (`ScoreColour`).
* Tools: `lockstep.js --profile=Label` (cycles per instruction in one routine), `--from=N`
  (profile from frame N), `--slow=N` (list frames over N cycles); `screencheck.js --level=1`
  fixed (it switched the 2600 two frames before the C64); `tools/c64time.js` (new, see below);
  testing aids in the build: `DbgTops` (16-bit), `DbgIrqEarly`, `DbgRing*` (the last 16 late
  passes: frames gone by, GameState, frame count).

## How it works (see main.asm's header)

* The ROM runs at $F000 with 7 patches (`GameImage` in `c64/data.asm`): no SEI / TXS at power-on, Game Reset's clear from $80 only,
  the RAM clear from $80 only (`ClearZP`), the VSYNC / VBLANK writes that would hit $00 / $01,
  and the kernel's timer wait at $F651 replaced by `jmp KernelHook` (Collide, then `rts` to the
  tick's caller; the next tick starts at $F017, FrameEnd).
* Picture: a hires bitmap at $6000 (screen / colour cells at $5C00, VIC bank $4000) for the
  girders, ladders, lives and score digits, drawn from the game's own tables when its keys
  change (`ScrKeys`: colours, digits, lives, level, rivets); sprites 0 Mario, 1 Kong (X-expanded
  double width, facing Mario's way), 2 Pauline, 3 the hammer (multicolour: missile = $D025,
  ball = $D026), 4-7 barrels (one sprite per row's player 1, a straddling barrel one sprite).
  All sprites X-expanded (one 2600 pixel = one sprite pixel) except the hammer.
* Per-line sprite colours (Mario's bands, Pauline's) as a raster event list (`EvRas/EvReg/EvVal`,
  24 per buffer, in line order), applied by the IRQ at the start of each event's line;
  staged sprite registers (`St*`) go in at TOPRASTER (44); double-buffered by `curBuf/pending`.
* `collide.asm`: `MarioTop` / `MarioLines` (Mario's 21 rows as drawn, reflected, + colours);
  barrels per row from RowGfx / RowCoarse / RowFine (`BarrelPixel` = 15 * coarse +
  FineX[fine >> 4]); the hammer's missile against Mario on the hammer row's 14 lines.
* Start-up tables in free RAM at $C000 (not in the file): `RngLo/RngHi`, `Dig6H/M/L`.
* Geometry constants: LINEOFS 40 (2600 line L = screen line L - 40), RASTEROFS 11, SPRYOFS 10,
  rows of 28 lines from line 75 (row 5 at the top), the hammer row = row 4, lines 103-116.

## Open

* **Fixed after play-testing**: the hammer didn't smash barrels: the game reads CXP1FB bit 6
  (player 1 against the ball = a barrel against the hammer's head, `asl $33` at $F59D), which
  the port never set: `SmashCheck` in collide.asm now works it out on the hammer row
  (lockstep compares it; `--hammer=F` puts Mario by the hammer and walks him with it: 6
  smashes over 6 runs, exact). ENAM1 / ENABL enable on bit 1 only (the "no hammer" table
  $FF70 has $F0 bytes): Collide and RenderHammer test bit 1. The jump sound clicked as it
  faded: the SID envelope was restarted at every volume step; now only on a new waveform or a
  louder volume (VICE WAV recording: the tail spiked back to 40+ of 47, now a smooth fade).

* **Fixed after the user's NTSC test**: Game Reset (F1) cleared $4F-$90 (`sta $4E,x` at $F083;
  TIA mirrors on the 2600) and so wiped our zero page: no keys, a garbled Mario. Patched to
  clear $80-$90 only. `lockstep.js` now throws if the 2600 code writes $00/$01 or $40-$7F,
  and the random player presses Game Reset after a game over. After a game over on the rivets
  screen the original ignores fire until Game Reset: that is the 2600 game, not a hang.

* **Colour events, fixed**: Pauline's head flickered on PAL (her first event armed one line
  ahead; her three changes on lines 62-64 drifted late); a colour change on a badline (raster
  & 7 = 3) missed Mario's first pixels. Now: a 3-line lead; the event loop keeps the index in
  Y and the register in the store's operand (self-modified) so back-to-back lines take ~50
  cycles a write; a badline's event (Render sets bit 7 of its register) is written at the end
  of the line before, after the sprite's pixels (`_bad`, BADDELAY). Checked with
  `tools/c64colours.js` (Mario's pixels on screen against his events, drawn 0-7 lines lower
  in turn via DbgMarioDY: 11-12 badline changes a run, 0 wrong, PAL and NTSC; the previous
  build: 11 of 11 wrong) and 16-screenshot captures of Pauline (identical, PAL and NTSC).

1. **Level start**: the whole bitmap is still ~210K cycles (~12 frames: the game catches up 3
   frames per pass afterwards). Precompute both levels' bitmaps at start-up, or spread the
   redraw over frames. The score digits' redraw (~7K extra, every 128 frames while the bonus
   counts down) fits now but is the next biggest spike.
2. **Early raster interrupts** of unknown cause (see above). Harmless now; worth understanding.
3. **Not verified in VICE**: the picture by eye after this session's changes (take
   `c64test.js` shots, PAL and NTSC), colour events on the right lines, grey dots
   (`--c64c` + `node ../../tools/greydots.js <pngs>`), sound, keys, F2.
4. The random player (`tools/play.js`) never picks up the hammer and never reaches the top, so
   the hammer swing (`HammerPtr = $A7`, CXM1P), the level change and the round-end states
   (GameState $40-$7F: their colours) are unverified on the C64 side. A scripted climb, or
   poking Mario onto row 4 next to the hammer (X ~ 40) and jumping, would cover it.
5. `lockstep.js --power=1500`: one difference on the power frame itself (Attract: 2600 0, C64
   $FF), the same on the first session's build: look at what the harness does differently at F2.
6. README.md is a stub; `src/web/donkey-kong.json` not written (build.cmd skips the profile
   when it is absent); no d64 name check.

## How to check

    games\donkey-kong\build.cmd                      (ROM rebuild check, tables, prg, d64)
    node games/donkey-kong/tools/model.js 3000 [--seed=N] [--level=1]      (the kernel model)
    node games/donkey-kong/tools/lockstep.js 3000 [--seed=N] [--level=1] [--profile[=Label]] [--from=N] [--slow=N]
    node games/donkey-kong/tools/screencheck.js 1500 [--seed=N] [--level=1] [--show=F] [--verbose]
    node games/donkey-kong/tools/c64time.js <outdir> --play [--ntsc] [--secs=25] [--keep]
    node games/donkey-kong/tools/c64test.js <outdir> --play --power [--ntsc] [--c64c]

Study tools: `run.js`, `trace.js` (TIA writes per line), `objects.js` (where each object has
pixels), `watch.js` (RAM over a scripted game), `calib.js` (object positions vs RAM X).

Lessons (also in memory): write .cmd files and anything with `$` through the Write tool, never
through a bash heredoc or `node -e "..."` (bash eats `$d012`, `>nul` becomes `/dev/null`); in the
6502 harnesses the 2600's kernel start ($F651) is a wait loop, so a "run to the kernel" must
leave it first; the 2600 reads the joystick in the logic that runs after its picture, so inputs
for frame f must be set before that logic runs. VICE's remote monitor hangs when a breakpoint
is hit (record what you need in the build instead). `git stash` turns these files to CRLF.
