# Donkey Kong (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80-$83` | BarrelY | 4 | Barrel slots 3..0 (indexed $80,x): Y, lines down from the top girder (0: no barrel; $0C when released at Kong) |
| `$84` | WalkCount | 1 | Mario's walk counter: steps since he last landed (bits 1-2 pick the walking frame) |
| `$85` | JumpTimer | 1 | Jump in progress: counts $1F down to 0 (0: not jumping) |
| `$86` | HammerTime | 1 | Mario holds the hammer: counts 3 down to 0, one step each 256 frames (0: no hammer) |
| `$87-$88` | Score | 2 | Score, BCD: high byte at $87, low at $88 (shown x100?) |
| `$89` | MoveDiv | 1 | Movement divider: Mario moves on every third frame (counts 2, 1, 0) |
| `$8A` | IdleCount | 1 | Frames (x256) without input: attract mode colours |
| `$8B` | SoundTimer | 1 | Sound effect: steps left |
| `$8C` | GameState | 1 | $FF playing, 0 attract (no game), 1 after a level is done?, 2 level change? |
| `$8D` | Dying | 1 | $FF while Mario dies |
| `$8E` | Attract | 1 | $FF in attract mode (colours cycle) |
| `$8F` | Sound | 1 | Sound effect playing (0 none; 1 jump, 2 step, 3 hit/score, 4 death, 5 level done?) |
| `$90` | Level | 1 | 0 the barrels screen, 1 the rivets screen |
| `$91` | LevelCount | 1 | Rounds played ($FF at the start; counts down with Game Reset)? |
| `$92` | BgColour | 1 | COLUBK (attract mode cycles it) |
| `$93` | MarioX | 1 | Mario's X (pixel, from the left) |
| `$94` | Facing | 1 | Mario: $08 facing right, 0 left (REFP0); $FE climbing up, $FF climbing down |
| `$95-$98` | HammerPtr | 4 | Pointers to the hammer's missile 1 and ball enable tables (page $FF; two swing phases; $FF70: no hammer) |
| `$99` | NextBarrel | 1 | The barrel slot to release next (3, 2, 1, 0 in turn) |
| `$9A` | PfColour | 1 | COLUPF: the girders' colour |
| `$9B` | MarioY | 1 | Mario's Y (lines down from the top girder; $9A on the bottom girder) |
| `$9C` | HammerX | 1 | The hammer's X: at rest $2D; held, Mario's X + 9 (facing right) or - 2 |
| `$9D-$A0` | Rivets | 4 | Rivets screen: rivets taken per row (row index 2..5?; bit values 6 / 12 per rivet)? |
| `$A1-$A2` | Unused | 2 | ? |
| `$A3` | Lives | 1 | Lives left (2 at the start) |
| `$A4` | Bonus | 1 | Bonus timer, BCD ($50 at the start, counts down every 128 frames) |
| `$A5-$C0` | MarioGfx | 28 | Mario's shape for the kernel: 28 lines (one girder row), copied from the graphics tables each frame (page $F9) |
| `$C1-$C4` | BarrelX | 4 | Barrel slots: X |
| `$C5-$C8` | BarrelDir | 4 | Barrel slots: 1 rolling right, 0 left; $F0 / $F1 going down a ladder (bit 0 = the direction to resume) |
| `$C9-$CC` | BarrelLadder | 4 | Barrel slots: the ladder it is on (index into the ladder tables) |
| `$CD-$D2` | RowCoarse | 6 | Kernel: per girder row (0 bottom .. 5 top), the barrel's coarse position (loop count; bit 7: no barrel in the row) |
| `$D3-$D8` | RowFine | 6 | Kernel: per girder row, the barrel's HMP1 value |
| `$D9-$E0` | PfPtr | 8 | Kernel: four pointers to the row's playfield columns (PF1 left, PF2 left, PF0 right, PF1 right); page $FC/$FE/$FF |
| `$E1-$E4` | GfxPtr | 4 | Kernel: the row's barrel shape pointer ($E1, page $FC) and Mario colour pointer ($E3, page $FB) |
| `$E5-$E6` | Temp | 2 | Scratch; the kernel's row counter ($E5) and line count ($E6) |
| `$E7` | BarrelTimer | 1 | Frames until the next barrel is released (compared with the table at $F900 by score) |
| `$E8` | FrameCount | 1 | Frame counter |
| `$E9` | JumpLatch | 1 | Fire held: one jump per press |
| `$EA` | MarioLadder | 1 | The ladder Mario is on (index into the ladder tables) |
| `$EB` | JoyLatch | 1 | SWCHA at the start of a jump (the jump keeps its direction) |
| `$EC` | JumpedOver | 1 | Barrel jumped over: counts the slot checked ($FF: already scored this jump)? |
| `$ED` | Temp2 | 1 | Scratch; Mario's row |
| `$EE-$F1` | RowKernel | 4 | Kernel: jump vectors for the row kernels (the hammer row at $EE, the others at $F0), by level |
| `$F2-$F7` | RowGfx | 6 | Kernel: per girder row, the barrel shape pointer (low byte, page $FC; $5D: none) |
| `$F8-$FD` | RowColour | 6 | Kernel: per girder row, Mario's colour table pointer (low byte, page $FB; $22: Mario not in the row) |
| `$FE-$FF` | Stack | 2 | The stack |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$F000` | Reset | Power on: clear the RAM and the TIA |
| `$F017` | FrameEnd | After the kernel: overscan, then the frame logic |
| `$F026` | Logic | The frame logic: timers, switches, Mario, the hammer, sounds |
| `$F05D` | Switches | Idle count, Game Reset |
| `$F0B5` | MarioMove | Every third frame: the joystick moves Mario (walk, ladders) |
| `$F24A` | Jump | Mario's jump: the arc, barrels jumped over |
| `$F296` | FireJump | Fire starts a jump (or a game) |
| `$F2CE` | MarioShape | Mario's row, shape and colour pointers, the shape buffer |
| `$F344` | Hammer | The hammer: picked up (missile 1 hits Mario in a jump), swung, dropped |
| `$F381` | SoundFx | Sound effects |
| `$F3AF` | FrameSync | Wait for the overscan timer, then VSYNC and the VBLANK timer |
| `$F3C9` | Round | Level done (Mario at the top), level change, lives |
| `$F409` | Barrels | Release and move the barrels (or fireballs) |
| `$F56E` | RowSetup | Kernel set-up: each row's barrel position and shape |
| `$F5EC` | Collide | Player 0 hit player 1: Mario dies |
| `$F613` | Kernel | Position Mario, the hammer; the picture |
| `$F685` | ScoreLoop | Score digits |
| `$F6E1` | KongLoop | Kong and Pauline |
| `$F7A9` | HammerRow | Girder row kernel with the hammer (missile 1 and ball), barrels screen |
| `$F7D8` | RowKernel0 | Girder row kernel, barrels screen |
| `$F7FD` | RowEnd | End of a row: the next row's barrel is positioned, pointers set |
| `$F885` | NextRow | Next row: pointers, which row kernel |
| `$F8A8` | HammerRow1 | Girder row kernel with the hammer, rivets screen |
| `$F8DA` | RowKernel1 | Girder row kernel, rivets screen |
| `$F90A` | OnLadder | Is Mario at a ladder end? (carry clear: yes) |
| `$F91C` | KernelPtrs | The row kernel vectors and the score digit pointers |
| `$F9F5` | CopyMario | Copy Mario's 28-line shape to the buffer |
| `$FA8A` | InitVars | Level start: the variables from the tables |
| `$FAA3` | Die | Mario dies |
| `$FAAD` | Score100 | Add 100 (BCD) to the score |
| `$FAAF` | AddScore | Add A (BCD) to the score |
| `$FAC0` | StartSound | Start sound effect A, X steps |
| `$FCED` | ClearBarrels | Clear the barrels and the row pointers |
| `$FDE2` | PosObject | Position object X at pixel A (RESP0,x and HMP0,x) |
