// Names for Donkey Kong's RAM and routines, worked out by reading the code and watching RAM
// in tools/vcs.js (games/donkey-kong/tools/watch.js, objects.js, trace.js). Used by
// tools/disasm.js to label the source and to write RAM-MAP.md. "?" marks something not yet
// confirmed.
//
// Conventions found in the code:
//   - The picture: score (lines 42-48), Kong and Pauline (50-68), the top girder (70-71), then
//     six girder rows of 28 lines each from line 75 (row 6 at the top down to row 1 at the
//     bottom; the kernel counts X from 6 down).
//   - Y coordinates count lines down from the top girder: Mario's Y ($9B) is $9A on the
//     bottom girder; a barrel's Y ($80-$83) grows as it rolls down.
//   - Mario is player 0, drawn from a 28-byte shape buffer ($A5-$C0) in the row(s) he is in,
//     with a colour per line from a table in page $FB; one barrel (or fireball) per row is
//     player 1, repositioned at each row boundary; the hammer is missile 1 plus the ball.
//   - Four barrel slots; the player's stack is at the top of page zero.

const game = { title: 'Donkey Kong', from: 'Atari 2600 (Coleco, 1982)', md5: '36b20c427975760cb9cf4a47e41369e4', asm: 'donkey-kong.asm' };

const ram = [
  [0x80, 'BarrelY', 4, 'Barrel slots 3..0 (indexed $80,x): Y, lines down from the top girder (0: no barrel; $0C when released at Kong)'],
  [0x84, 'WalkCount', 1, 'Mario\'s walk counter: steps since he last landed (bits 1-2 pick the walking frame)'],
  [0x85, 'JumpTimer', 1, 'Jump in progress: counts $1F down to 0 (0: not jumping)'],
  [0x86, 'HammerTime', 1, 'Mario holds the hammer: counts 3 down to 0, one step each 256 frames (0: no hammer)'],
  [0x87, 'Score', 2, 'Score, BCD: high byte at $87, low at $88 (shown x100?)'],
  [0x89, 'MoveDiv', 1, 'Movement divider: Mario moves on every third frame (counts 2, 1, 0)'],
  [0x8A, 'IdleCount', 1, 'Frames (x256) without input: attract mode colours'],
  [0x8B, 'SoundTimer', 1, 'Sound effect: steps left'],
  [0x8C, 'GameState', 1, '$FF playing, 0 attract (no game), 1 after a level is done?, 2 level change?'],
  [0x8D, 'Dying', 1, '$FF while Mario dies'],
  [0x8E, 'Attract', 1, '$FF in attract mode (colours cycle)'],
  [0x8F, 'Sound', 1, 'Sound effect playing (0 none; 1 jump, 2 step, 3 hit/score, 4 death, 5 level done?)'],
  [0x90, 'Level', 1, '0 the barrels screen, 1 the rivets screen'],
  [0x91, 'LevelCount', 1, 'Rounds played ($FF at the start; counts down with Game Reset)?'],
  [0x92, 'BgColour', 1, 'COLUBK (attract mode cycles it)'],
  [0x93, 'MarioX', 1, 'Mario\'s X (pixel, from the left)'],
  [0x94, 'Facing', 1, 'Mario: $08 facing right, 0 left (REFP0); $FE climbing up, $FF climbing down'],
  [0x95, 'HammerPtr', 4, 'Pointers to the hammer\'s missile 1 and ball enable tables (page $FF; two swing phases; $FF70: no hammer)'],
  [0x99, 'NextBarrel', 1, 'The barrel slot to release next (3, 2, 1, 0 in turn)'],
  [0x9A, 'PfColour', 1, 'COLUPF: the girders\' colour'],
  [0x9B, 'MarioY', 1, 'Mario\'s Y (lines down from the top girder; $9A on the bottom girder)'],
  [0x9C, 'HammerX', 1, 'The hammer\'s X: at rest $2D; held, Mario\'s X + 9 (facing right) or - 2'],
  [0x9D, 'Rivets', 4, 'Rivets screen: rivets taken per row (row index 2..5?; bit values 6 / 12 per rivet)?'],
  [0xA1, 'Unused', 2, '?'],
  [0xA3, 'Lives', 1, 'Lives left (2 at the start)'],
  [0xA4, 'Bonus', 1, 'Bonus timer, BCD ($50 at the start, counts down every 128 frames)'],
  [0xA5, 'MarioGfx', 28, 'Mario\'s shape for the kernel: 28 lines (one girder row), copied from the graphics tables each frame (page $F9)'],
  [0xC1, 'BarrelX', 4, 'Barrel slots: X'],
  [0xC5, 'BarrelDir', 4, 'Barrel slots: 1 rolling right, 0 left; $F0 / $F1 going down a ladder (bit 0 = the direction to resume)'],
  [0xC9, 'BarrelLadder', 4, 'Barrel slots: the ladder it is on (index into the ladder tables)'],
  [0xCD, 'RowCoarse', 6, 'Kernel: per girder row (0 bottom .. 5 top), the barrel\'s coarse position (loop count; bit 7: no barrel in the row)'],
  [0xD3, 'RowFine', 6, 'Kernel: per girder row, the barrel\'s HMP1 value'],
  [0xD9, 'PfPtr', 8, 'Kernel: four pointers to the row\'s playfield columns (PF1 left, PF2 left, PF0 right, PF1 right); page $FC/$FE/$FF'],
  [0xE1, 'GfxPtr', 4, 'Kernel: the row\'s barrel shape pointer ($E1, page $FC) and Mario colour pointer ($E3, page $FB)'],
  [0xE5, 'Temp', 2, 'Scratch; the kernel\'s row counter ($E5) and line count ($E6)'],
  [0xE7, 'BarrelTimer', 1, 'Frames until the next barrel is released (compared with the table at $F900 by score)'],
  [0xE8, 'FrameCount', 1, 'Frame counter'],
  [0xE9, 'JumpLatch', 1, 'Fire held: one jump per press'],
  [0xEA, 'MarioLadder', 1, 'The ladder Mario is on (index into the ladder tables)'],
  [0xEB, 'JoyLatch', 1, 'SWCHA at the start of a jump (the jump keeps its direction)'],
  [0xEC, 'JumpedOver', 1, 'Barrel jumped over: counts the slot checked ($FF: already scored this jump)?'],
  [0xED, 'Temp2', 1, 'Scratch; Mario\'s row'],
  [0xEE, 'RowKernel', 4, 'Kernel: jump vectors for the row kernels (the hammer row at $EE, the others at $F0), by level'],
  [0xF2, 'RowGfx', 6, 'Kernel: per girder row, the barrel shape pointer (low byte, page $FC; $5D: none)'],
  [0xF8, 'RowColour', 6, 'Kernel: per girder row, Mario\'s colour table pointer (low byte, page $FB; $22: Mario not in the row)'],
  [0xFE, 'Stack', 2, 'The stack'],
];

const labels = {
  0xF000: ['Reset', 'Power on: clear the RAM and the TIA'],
  0xF017: ['FrameEnd', 'After the kernel: overscan, then the frame logic'],
  0xF026: ['Logic', 'The frame logic: timers, switches, Mario, the hammer, sounds'],
  0xF05D: ['Switches', 'Idle count, Game Reset'],
  0xF0B5: ['MarioMove', 'Every third frame: the joystick moves Mario (walk, ladders)'],
  0xF24A: ['Jump', 'Mario\'s jump: the arc, barrels jumped over'],
  0xF296: ['FireJump', 'Fire starts a jump (or a game)'],
  0xF2CE: ['MarioShape', 'Mario\'s row, shape and colour pointers, the shape buffer'],
  0xF344: ['Hammer', 'The hammer: picked up (missile 1 hits Mario in a jump), swung, dropped'],
  0xF381: ['SoundFx', 'Sound effects'],
  0xF3AF: ['FrameSync', 'Wait for the overscan timer, then VSYNC and the VBLANK timer'],
  0xF3C9: ['Round', 'Level done (Mario at the top), level change, lives'],
  0xF409: ['Barrels', 'Release and move the barrels (or fireballs)'],
  0xF56E: ['RowSetup', 'Kernel set-up: each row\'s barrel position and shape'],
  0xF5EC: ['Collide', 'Player 0 hit player 1: Mario dies'],
  0xF613: ['Kernel', 'Position Mario, the hammer; the picture'],
  0xF685: ['ScoreLoop', 'Score digits'],
  0xF6E1: ['KongLoop', 'Kong and Pauline'],
  0xF7A9: ['HammerRow', 'Girder row kernel with the hammer (missile 1 and ball), barrels screen'],
  0xF7D8: ['RowKernel0', 'Girder row kernel, barrels screen'],
  0xF7FD: ['RowEnd', 'End of a row: the next row\'s barrel is positioned, pointers set'],
  0xF885: ['NextRow', 'Next row: pointers, which row kernel'],
  0xF8A8: ['HammerRow1', 'Girder row kernel with the hammer, rivets screen'],
  0xF8DA: ['RowKernel1', 'Girder row kernel, rivets screen'],
  0xF90A: ['OnLadder', 'Is Mario at a ladder end? (carry clear: yes)'],
  0xF91C: ['KernelPtrs', 'The row kernel vectors and the score digit pointers'],
  0xF9F5: ['CopyMario', 'Copy Mario\'s 28-line shape to the buffer'],
  0xFA8A: ['InitVars', 'Level start: the variables from the tables'],
  0xFAA3: ['Die', 'Mario dies'],
  0xFAAD: ['Score100', 'Add 100 (BCD) to the score'],
  0xFAAF: ['AddScore', 'Add A (BCD) to the score'],
  0xFAC0: ['StartSound', 'Start sound effect A, X steps'],
  0xFCED: ['ClearBarrels', 'Clear the barrels and the row pointers'],
  0xFDE2: ['PosObject', 'Position object X at pixel A (RESP0,x and HMP0,x)'],
};

module.exports = { game, ram, labels, code: [0xF7A9, 0xF7D8, 0xF8A8, 0xF8DA], always: [] };
