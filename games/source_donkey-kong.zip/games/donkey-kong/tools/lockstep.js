// Run the C64 port's game ticks (the patched 2600 program plus our collision code, from
// build/donkeykong-<version>.prg) on a plain 6502 with 64K of memory, side by side with the
// original game in tools/vcs.js, with the same joystick inputs. After every frame the two must
// have the same 2600 RAM at the same point: where the kernel would start drawing (the C64 side
// has worked out its collisions). Any difference is a bug in a patch or in the collisions.
// The collisions: what the 2600 latched for its picture (read before it clears them for the
// next) against what the C64 worked out for the same picture.
//   node games/donkey-kong/tools/lockstep.js [frames] [--seed=N] [--level=1] [--power=N] [--verbose] [--profile[=Label]] [--from=N] [--slow=cycles] [--hammer=F]
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const ROMMD5 = '36b20c427975760cb9cf4a47e41369e4';
const rom = require('../../../tools/rom').load(ROMMD5);
const build = path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[1], 16);
};
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 3000);
const verbose = process.argv.includes('--verbose');

// ---- the C64 side: the VCS 6502 core on a flat 64K memory
class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) {
    a &= 0xFFFF;
    // the 2600 program must keep out of the C64's zero page: $00 / $01 and ours at $40-$7F
    if (this.pc >= 0xF000 && (a < 2 || (a >= 0x40 && a < 0x80))) throw new Error(`the 2600 code at $${this.pc.toString(16)} wrote $${a.toString(16)}`);
    this.mem[a] = v;
  }
  commit() {}
  flush() {}
  tick(n) { this.cycles += n; }
  call(addr, limit = 2e6) {      // JSR addr from a stub, run until it returns
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    const start = this.cycles;
    const ring = [];
    for (let i = 0; this.pc !== STUB + 3; i++) { ring[i & 31] = this.pc; this.step(); if (i > limit) throw new Error(`runaway at $${this.pc.toString(16)}; last PCs ${ring.map(p => p.toString(16)).join(' ')}; X ${this.x} Y ${this.y} A ${this.a}`); }
    return this.cycles - start;
  }
}
const c64 = new C64();
const profile = process.argv.some(a => a === '--profile' || a.startsWith('--profile=')) ? {} : null;
const labels = [...lst.matchAll(/^\.([0-9a-f]{4})\t.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[1], 16), m[2]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xF000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
// --profile=Label: cycles per instruction inside that routine instead
let profOn = true;
const profLabel = arg('profile', null);
const pcProfile = typeof profLabel === 'string' ? {} : null;
if (profile) { const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); if (!profOn) return r; const k = labelOf(pc), d = this.cycles - c; profile[k] = (profile[k] || 0) + d; if (pcProfile && k === profLabel) pcProfile[pc] = (pcProfile[pc] || 0) + d; return r; }; }
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
// what Start does that matters here: the 2600 image at $F000, the RIOT ports, the tables
c64.mem.set(c64.mem.subarray(sym('GameImage'), sym('GameImage') + 0x1000), 0xF000);
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x3C] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));

// ---- the original: run from one kernel start to the next (its picture, then the logic)
const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
const KERNEL = 0xF651, CXCLR = 0xF615;
let atKernel = false, cxLatched = 0;
const origStep = vcs.step.bind(vcs);
vcs.step = function () { if (this.pc === CXCLR) cxLatched = this.cx; if (this.pc === KERNEL) atKernel = true; return origStep(); };
// (the kernel start is the 2600's wait for its timer, a loop: leave it first)
const runToKernel = () => { while (vcs.pc >= KERNEL && vcs.pc < KERNEL + 5) vcs.step(); atKernel = false; let g = 0; while (!atKernel) { vcs.step(); if (++g > 1e6) throw new Error('2600 never reached the kernel'); } };

const NAMES = {};
for (const [a, n, size] of require('../2600/symbols.js').ram) for (let i = 0; i < size; i++) NAMES[a + i] = size > 1 ? `${n}+${i}` : n;
// bytes the two may legitimately disagree on: the stack (on the 2600 it is page zero's top)
// and the kernel's own working bytes (its row counter and line count), set before use
const IGNORE = new Set([0xFE, 0xFF, 0xE5, 0xE6]);

const play = require('./play')(arg('seed', 1));
const level = arg('level', 0), power = arg('power', 0), slow = arg('slow', 0);
// --hammer=F: at frame F (a game on) Mario stands on the hammer row by the hammer, jumps for
// it, then walks right and left for 900 frames, smashing barrels (both sides poked alike)
const hammer = arg('hammer', 0);   // --slow=N: list the frames over N cycles
let maxCycles = 0, totalCycles = 0, bad = 0, done = 0, maxRender = 0, totalRender = 0, cxSeen = 0, profFrames = 0, smashSeen = 0;
const from = arg('from', 0);                            // --from=N: profile from frame N on
for (let f = 0; f < frames; f++) {
  profOn = f >= from; if (profOn) profFrames++;
  if (level && f === 2) vcs.ram[0x10] = c64.mem[0x90] = 1;
  play.step(vcs);
  if (hammer && f >= hammer && f < hammer + 900) {
    const h = f - hammer;
    if (h === 0) { vcs.ram[0x13] = c64.mem[0x93] = 0x28; vcs.ram[0x1B] = c64.mem[0x9B] = 0x2A; }
    vcs.fire[0] = h === 5 || h === 6;
    vcs.swcha = h < 20 ? 0xFF : (Math.floor(h / 200) % 2 ? 0x7F : 0xBF);
  }
  c64.mem[0x0280] = vcs.swcha; c64.mem[0x3C] = vcs.fire[0] ? 0 : 0x80; c64.mem[0x0282] = vcs.swchb;
  if (power && f === power) { c64.call(sym('PowerCycle')); vcs.pc = 0xF000; vcs.s = 0xFD; }   // F2 on both
  const cP0P1 = c64.mem[0x37] >> 7, cM1P0 = c64.mem[0x31] >> 7, cP1BL = (c64.mem[0x33] >> 6) & 1;   // the C64's collisions for the last picture
  runToKernel();
  const cyc = c64.call(sym('Tick'));
  maxCycles = Math.max(maxCycles, cyc); totalCycles += cyc;
  c64.mem[sym('pending')] = 0;                          // draw it, as the main loop would
  const rc = c64.call(sym('Render'));
  maxRender = Math.max(maxRender, rc); totalRender += rc;
  if (slow && cyc + rc > slow) console.log(`frame ${f}: tick ${cyc} + render ${rc} cycles (GameState ${c64.mem[0x8C].toString(16)})`);
  done++;
  const diffs = [];
  for (let a = 0x80; a < 0x100; a++) if (!IGNORE.has(a) && vcs.ram[a - 0x80] !== c64.mem[a])
    diffs.push(`${NAMES[a] || '$' + a.toString(16)} 2600 ${vcs.ram[a - 0x80].toString(16)} C64 ${c64.mem[a].toString(16)}`);
  const vP0P1 = (cxLatched >> 13) & 1, vM1P0 = (cxLatched >> 2) & 1, vP1BL = (cxLatched >> 7) & 1;
  if (vP0P1 || vM1P0 || vP1BL) cxSeen++;
  if (vP1BL) smashSeen++;
  const h2 = n => vcs.ram[n - 0x80].toString(16);
  if (f > 0 && f !== hammer && (vP0P1 !== cP0P1 || vM1P0 !== cM1P0 || vP1BL !== cP1BL)) diffs.push(`collisions: Mario-barrel 2600 ${vP0P1} C64 ${cP0P1}, hammer-Mario 2600 ${vM1P0} C64 ${cM1P0}, barrel-hammer head 2600 ${vP1BL} C64 ${cP1BL} (MarioX ${h2(0x93)} Y ${h2(0x9B)} Facing ${h2(0x94)} HammerTime ${h2(0x86)} HammerPtr ${h2(0x95)}/${h2(0x97)} HammerX ${h2(0x9C)} JumpTimer ${h2(0x85)})`);
  if (diffs.length) {
    bad++;
    if (bad <= 3 || verbose) console.log(`frame ${f}: ${diffs.join(', ')}`);
    if (bad === 3 && !verbose) { console.log('... stopping'); break; }
    for (let a = 0x80; a < 0x100; a++) c64.mem[a] = vcs.ram[a - 0x80];   // resync and carry on
  }
}
if (pcProfile) {
  const src = {}; for (const m of lst.matchAll(/^\.([0-9a-f]{4})\t[^\n]*?\t\t([^\n]*)$/gm)) src[parseInt(m[1], 16)] = m[2].trim();
  for (const [pc, v] of Object.entries(pcProfile).sort((a, b) => a[0] - b[0])) console.log('$' + (+pc).toString(16), String(Math.round(v / profFrames)).padStart(6), src[pc] || '');
}
if (profile) { const tot = Object.values(profile).reduce((a, b) => a + b, 0); for (const [k, v] of Object.entries(profile).sort((a, b) => b[1] - a[1]).slice(0, 20)) console.log(k.padEnd(16), String(Math.round(v / profFrames)).padStart(7), (100 * v / tot).toFixed(1) + '%'); }
console.log(`${done} frames (${cxSeen} with a collision, ${smashSeen} barrel-hammer head), ${bad} with differences; C64 tick: ${Math.round(totalCycles / done)} cycles on average, ${maxCycles} at most; render: ${Math.round(totalRender / done)} on average, ${maxRender} at most`);
process.exit(bad ? 1 : 0);
