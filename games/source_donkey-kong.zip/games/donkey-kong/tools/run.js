// Quick runner: boot the ROM, optionally press Game Reset, step frames, save screenshots.
//   node games/donkey-kong/tools/run.js <frames> [out.png] [--reset] [--fire]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('36b20c427975760cb9cf4a47e41369e4'));
let lines = 0;
vcs.onFrame = v => { lines = v.line; };
const frames = +(process.argv[2] || 60);
if (process.argv.includes('--reset')) {
  vcs.runFrames(10);
  vcs.swchb &= ~1; vcs.runFrames(5); vcs.swchb |= 1;   // press and release Game Reset
}
if (process.argv.includes('--fire')) { vcs.runFrames(10); vcs.fire[0] = true; vcs.runFrames(5); vcs.fire[0] = false; }
vcs.runFrames(frames);
console.log('frames', vcs.frames, 'lines/frame', lines, 'cycles', vcs.cycles);
const hex = b => [...b].map(x => x.toString(16).padStart(2, '0')).join(' ');
for (let i = 0; i < 128; i += 16) console.log((0x80 + i).toString(16), hex(vcs.ram.subarray(i, i + 16)));
if (process.argv[3] && !process.argv[3].startsWith('--')) { vcs.savePNG(process.argv[3]); console.log('saved', process.argv[3]); }
