// Where each TIA object has pixels in a frame (tools/vcs.js): per object, runs of lines with
// their x range, to see what the kernel draws with what. Also the frame's RAM.
//   node games/donkey-kong/tools/objects.js <frame> [--fire] [--reset] [--level=1] [--png=file]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('36b20c427975760cb9cf4a47e41369e4'));
const frame = +(process.argv[2] || 100);
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
if (+opt('level', 0)) { vcs.runFrames(2); vcs.ram[0x90 - 0x80] = 1; }
if (process.argv.includes('--reset')) { vcs.runFrames(10); vcs.swchb &= ~1; vcs.runFrames(5); vcs.swchb |= 1; }
if (process.argv.includes('--fire')) { vcs.runFrames(10); vcs.fire[0] = true; vcs.runFrames(5); vcs.fire[0] = false; }
vcs.runFrames(frame - vcs.frames);
const NAMES = ['P0', 'P1', 'M0', 'M1', 'BL', 'PF'];
const h = v => v.toString(16).padStart(2, '0');
console.log('frame', vcs.frames, 'RAM:');
for (let i = 0; i < 128; i += 16) console.log(' ', h(0x80 + i), [...vcs.ram.subarray(i, i + 16)].map(h).join(' '));
for (let b = 0; b < 6; b++) {
  const runs = [];
  let cur = null;
  for (let y = 0; y < 262; y++) {
    let x0 = -1, x1 = -1;
    for (let x = 0; x < 160; x++) if (vcs.ob[y * 160 + x] & (1 << b)) { if (x0 < 0) x0 = x; x1 = x; }
    if (x0 < 0) { if (cur) { runs.push(cur); cur = null; } continue; }
    if (cur && cur.x0 === x0 && cur.x1 === x1 && cur.y1 === y - 1) cur.y1 = y;
    else if (cur && cur.y1 === y - 1 && b === 5) { cur.y1 = y; cur.x0 = Math.min(cur.x0, x0); cur.x1 = Math.max(cur.x1, x1); }
    else { if (cur) runs.push(cur); cur = { y0: y, y1: y, x0, x1 }; }
  }
  if (cur) runs.push(cur);
  console.log(NAMES[b].padEnd(3), runs.map(r => `lines ${r.y0}${r.y1 !== r.y0 ? '-' + r.y1 : ''} x ${r.x0}${r.x1 !== r.x0 ? '-' + r.x1 : ''}`).join(' | ') || 'nothing');
}
if (opt('png', '')) { vcs.savePNG(opt('png', '')); console.log('saved', opt('png', '')); }
