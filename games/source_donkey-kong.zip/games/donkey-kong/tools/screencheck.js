// Draws the C64 frame from what the C64 code set up (the bitmap, the staged sprite registers
// and blocks, the colour events) and compares it with the 2600's picture (tools/vcs.js), as
// objects (which of player 0, player 1, missile 1, ball, playfield is at each pixel) and as
// C64 colours, over a random game. Runs the C64 code on the 6502 core as lockstep.js does.
//   node games/donkey-kong/tools/screencheck.js [frames] [--seed=N] [--level=1] [--score=N] [--advance=F] [--show=frame] [--verbose]
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const ROMMD5 = '36b20c427975760cb9cf4a47e41369e4';
const rom = require('../../../tools/rom').load(ROMMD5);
const build = path.join(__dirname, '..', 'build');
const files = require('../../../tools/buildname').files(build);
const prg = fs.readFileSync(files.prg);
const lst = fs.readFileSync(files.lst, 'latin1');
const sym = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no symbol ' + name);
  return parseInt(m[1], 16);
};
const equ = name => { const m = lst.match(new RegExp(`^=([0-9a-f]+)[ \\t]+${name}\\b`, 'mi')) || lst.match(new RegExp(`^=\\$([0-9a-f]+)[ \\t]+${name}\\b`, 'mi')); if (!m) throw new Error('no equate ' + name); return parseInt(m[1], 16); };
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 1000);
const verbose = process.argv.includes('--verbose');
const showFrame = arg('show', -1);

class C64 extends VCS {
  constructor() { super(rom); this.mem = new Uint8Array(65536); }
  read(a) { return this.mem[a & 0xFFFF]; }
  write(a, v) { this.mem[a & 0xFFFF] = v; }
  commit() {} flush() {} tick(n) { this.cycles += n; }
  call(addr, limit = 2e6) {
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error('runaway at $' + this.pc.toString(16)); }
  }
}
const c64 = new C64();
c64.mem.set(prg.subarray(2), prg.readUInt16LE(0));
c64.s = 0xFF;
c64.mem.set(c64.mem.subarray(sym('GameImage'), sym('GameImage') + 0x1000), 0xF000);
c64.mem[0x0280] = 0xFF; c64.mem[0x0282] = 0x0B; c64.mem[0x0284] = 0; c64.mem[0x3C] = 0x80;
c64.mem[sym('firstTick')] = 1;
c64.mem[0x01] = 0x35;
c64.call(sym('InitVideo'));
const S = {};
for (const n of ['StX', 'StY', 'StPtr', 'StCol', 'StMsb', 'StEn', 'StBg', 'StMc1', 'StMc2', 'EvRas', 'EvReg', 'EvVal', 'curBuf', 'pending', 'ColorMap', 'BmpLo', 'BmpHi']) S[n] = sym(n);
const NEV = 24, SPRDATA = 0x4000, SCREEN = 0x5C00, LINEOFS = 40, RASTEROFS = 11, SPRYOFS = 10;
const M = a => c64.mem[a];

const vcs = new VCS(rom);
vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;
let atKernel = false;
const origStep = vcs.step.bind(vcs);
vcs.step = function () { if (this.pc === 0xF651) atKernel = true; return origStep(); };
const runToKernel = () => { while (vcs.pc >= 0xF651 && vcs.pc < 0xF656) vcs.step(); atKernel = false; let g = 0; while (!atKernel) { vcs.step(); if (++g > 1e6) throw new Error('2600 never reached the kernel'); } };

const P0 = 1, P1 = 2, M1 = 8, BL = 16, PF = 32;
const SPRBIT = [P0, P0, P1, 0, P1, P1, P1, P1];   // sprite 3 (the hammer) by its colour: 1 M1, 2 BL

// The C64 picture from the staged frame: object bits and C64 colours per 2600 pixel
function c64Picture() {
  const buf = M(S.curBuf) ^ 1;             // Render drew the other buffer
  const ob = new Uint8Array(160 * 262), col = new Uint8Array(160 * 262);
  const sprCol = [...Array(8)].map((_, i) => M(S.StCol + 8 * buf + i));
  const events = [];
  for (let i = 0; i < NEV; i++) { const r = M(S.EvRas + NEV * buf + i); if (r >= 242) break; events.push([r, M(S.EvReg + NEV * buf + i), M(S.EvVal + NEV * buf + i)]); }
  const mc = [0, M(S.StMc1 + buf), M(S.StMc2 + buf)];
  const en = M(S.StEn + buf), msb = M(S.StMsb + buf);
  const spr = [];
  for (let n = 0; n < 8; n++) {
    if (!(en & (1 << n))) continue;
    const x = M(S.StX + 8 * buf + n) + ((msb >> n) & 1) * 256, y = M(S.StY + 8 * buf + n), ptr = M(S.StPtr + 8 * buf + n);
    spr.push({ n, px: (x - 24) / 2, line: y - SPRYOFS, block: SPRDATA + 64 * ptr });
  }
  let ev = 0;
  for (let L = 40; L <= 230; L++) {
    const raster = L + RASTEROFS;
    while (ev < events.length && events[ev][0] <= raster) { const [, reg, val] = events[ev++]; if ((reg & 0x7f) >= 0x27 && (reg & 0x7f) < 0x2F) sprCol[(reg & 0x7f) - 0x27] = val; }
    const s = L - LINEOFS, base = M(S.BmpLo + s) + 256 * M(S.BmpHi + s);
    for (let x = 0; x < 160; x++) {
      const cx = 2 * x, cell = cx >> 3, byte = M(base + 8 * cell), bit = (byte >> (7 - (cx & 7))) & 1;
      const cellCol = M(SCREEN + 40 * (s >> 3) + cell);
      col[L * 160 + x] = bit ? cellCol >> 4 : cellCol & 15;
      if (bit) ob[L * 160 + x] |= PF;
    }
    for (const sp of [...spr].reverse()) {       // lower sprite numbers in front
      const row = L - sp.line;
      if (row < 0 || row >= 21) continue;
      const b0 = M(sp.block + 3 * row), b1 = M(sp.block + 3 * row + 1), b2 = M(sp.block + 3 * row + 2);
      if (sp.n === 3) {                          // multicolour, unexpanded: 12 pixels of 2 bits
        for (let i = 0; i < 12; i++) {
          const byte = [b0, b1, b2][i >> 2], v = (byte >> (6 - 2 * (i & 3))) & 3;
          if (!v) continue;
          const x = sp.px + i; if (x < 0 || x >= 160) continue;
          ob[L * 160 + x] |= v === 1 ? M1 : v === 2 ? BL : (M1 | BL);
          col[L * 160 + x] = v === 3 ? sprCol[3] : mc[v];
        }
      } else {                                   // hires, expanded: 24 pixels, one each
        for (let i = 0; i < 24; i++) {
          const byte = [b0, b1, b2][i >> 3];
          if (!((byte >> (7 - (i & 7))) & 1)) continue;
          const x = sp.px + i; if (x < 0 || x >= 160) continue;
          ob[L * 160 + x] |= SPRBIT[sp.n];
          col[L * 160 + x] = sprCol[sp.n];
        }
      }
    }
  }
  return { ob, col };
}

const play = require('./play')(arg('seed', 1));
const level = arg('level', 0);
const score = parseInt(String(arg('score', 0)), 16);       // BCD, e.g. 5 = 50,000 points
const advance = arg('advance', 0);
let advanced = 0;
const names = { 1: 'P0', 2: 'P1', 8: 'M1', 16: 'BL', 32: 'PF' };
let bad = 0, colBad = 0, done = 0;
for (let f = 0; f < frames; f++) {
  if (level && f === 2) vcs.ram[0x10] = c64.mem[0x90] = 1;     // (as lockstep.js: both sides at once)
  // --score=N: the score kept at N x 10,000 or more (both sides): the game releases barrels
  // sooner by the score's top BCD byte (the table at $F900)
  if (score && vcs.ram[0x07] < score) vcs.ram[0x07] = c64.mem[0x87] = score;
  // --advance=F: from frame F, every 600 frames, finish the screen being played (both sides):
  // Mario at the top of the barrels screen, or every rivet taken; the game then does its own
  // screen change, bonus and next screen (the screens alternate, round after round)
  if (advance && f >= advance && (f - advance) % 600 === 0 && vcs.ram[0x0C] === 0xFF) {
    if (vcs.ram[0x10] === 0) vcs.ram[0x1B] = c64.mem[0x9B] = 0x0F;
    else for (let i = 2; i < 6; i++) vcs.ram[0x1D + i] = c64.mem[0x9D + i] = 0x12;
    advanced++;
  }
  play.step(vcs);
  c64.mem[0x0280] = vcs.swcha; c64.mem[0x3C] = vcs.fire[0] ? 0 : 0x80; c64.mem[0x0282] = vcs.swchb;
  runToKernel();
  c64.call(sym('Tick'));
  c64.mem[S.pending] = 0;
  c64.call(sym('Render'));
  for (let g = 0; vcs.pc !== 0xF017; g++) { vcs.step(); if (g > 1e6) throw new Error('no picture'); }   // the 2600 draws its picture (stops before its logic runs)
  // (the kernel writes $D9-$E6: its pointers and temps)
  for (let a = 0x80; a < 0x100; a++) if (!(a >= 0xD9 && a <= 0xE6) && a !== 0xFE && a !== 0xFF && vcs.ram[a - 0x80] !== c64.mem[a]) { console.log(`frame ${f}: RAM differs at $${a.toString(16)} (2600 ${vcs.ram[a - 0x80]} C64 ${c64.mem[a]}): run lockstep.js`); break; }
  const pic = c64Picture();
  const diffs = [], cdiffs = [];
  for (let L = 40; L <= 230; L++) for (let x = 0; x < 160; x++) {
    let a = vcs.ob[L * 160 + x] & (P0 | P1 | M1 | BL | PF);
    if (L >= 42 && L <= 48 && (a & (P0 | P1))) a = PF;           // (the score digits are in the bitmap)
    const b = pic.ob[L * 160 + x];
    if (a !== b) diffs.push({ L, x, a, b });
    else if (a) { const want = M(S.ColorMap + vcs.fb[L * 160 + x]); if (want !== pic.col[L * 160 + x]) cdiffs.push({ L, x, want, got: pic.col[L * 160 + x] }); }
  }
  done++;
  if (diffs.length) { bad++; if (verbose || bad <= 5) { const byBit = {}; for (const d of diffs) for (const bit of [1, 2, 8, 16, 32]) if ((d.a ^ d.b) & bit) { const k = names[bit] + (d.a & bit ? '-' : '+'); byBit[k] = (byBit[k] || 0) + 1; } console.log(`frame ${f}: ${diffs.length} pixels differ: ${Object.entries(byBit).map(([k, v]) => k + ' ' + v).join(', ')}; first ${diffs.slice(0, 5).map(d => `(${d.x},${d.L}) 2600 ${d.a} C64 ${d.b}`).join(' ')}`); } }
  if (cdiffs.length) { colBad++; if (verbose || colBad <= 5) console.log(`frame ${f}: ${cdiffs.length} pixels with the wrong colour; first ${cdiffs.slice(0, 5).map(d => `(${d.x},${d.L}) want ${d.want} got ${d.got}`).join(' ')}`); }
  if (f === showFrame) {
    const buf = M(S.curBuf) ^ 1;
    console.log('sprites:', [...Array(8).keys()].filter(n => M(S.StEn + buf) & (1 << n)).map(n => `${n}: x ${(M(S.StX + 8 * buf + n) + ((M(S.StMsb + buf) >> n) & 1) * 256 - 24) / 2} line ${M(S.StY + 8 * buf + n) - SPRYOFS} block ${M(S.StPtr + 8 * buf + n)} colour ${M(S.StCol + 8 * buf + n)}`).join(' | '));
    const evs = []; for (let i = 0; i < NEV; i++) { const r = M(S.EvRas + NEV * buf + i); if (r >= 242) break; evs.push(`line ${r - RASTEROFS} $d0${M(S.EvReg + NEV * buf + i).toString(16)}=${M(S.EvVal + NEV * buf + i)}`); }
    console.log('events:', evs.join(', '));
    console.log('vcs pos', vcs.pos.join(','), 'C64 RAM 93', c64.mem[0x93].toString(16), 'e8', c64.mem[0xe8].toString(16), 'refp0', c64.mem[0x0b], '| RAM 93', vcs.ram[0x13].toString(16), '9c', vcs.ram[0x1c].toString(16), '95', vcs.ram[0x15].toString(16), '97', vcs.ram[0x17].toString(16));
    { const s = 2, base = M(S.BmpLo + s) + 256 * M(S.BmpHi + s); console.log(`bitmap line 2 at $${base.toString(16)} (BmpLo at $${S.BmpLo.toString(16)}): cells 13-26`, [...Array(14).keys()].map(c => M(base + 8 * (13 + c)).toString(16).padStart(2, '0')).join(' ')); }
    for (let L = 40; L <= 230; L++) {
      let s = '';
      for (let x = 0; x < 160; x++) { let a = vcs.ob[L * 160 + x] & 63; if (L >= 42 && L <= 48 && (a & 3)) a = PF; const b = pic.ob[L * 160 + x]; s += a === b ? (a ? (a & PF ? '#' : a & P0 ? '0' : a & P1 ? '1' : a & M1 ? 'm' : 'b') : '.') : (a ? 'V' : 'C'); }
      console.log(String(L).padStart(3), s);
    }
  }
}
console.log(`${done} frames, ${bad} with object differences, ${colBad} with colour differences`);
process.exit(bad || colBad ? 1 : 0);
