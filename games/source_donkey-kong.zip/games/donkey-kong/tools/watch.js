// Play a scripted game in tools/vcs.js and print chosen RAM bytes every few frames,
// to check what each byte means.
//   node games/donkey-kong/tools/watch.js [png-dir] [--every=10]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('36b20c427975760cb9cf4a47e41369e4'));
const out = process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : null;
const every = +((process.argv.find(a => a.startsWith('--every=')) || '--every=10').split('=')[1]);
const r = a => vcs.ram[a - 0x80];
const h = v => v.toString(16).padStart(2, '0');
const hx = (a, n) => [...Array(n)].map((_, i) => h(r(a + i))).join(' ');
const UP = 0xEF, DOWN = 0xDF, LEFT = 0xBF, RIGHT = 0x7F, NONE = 0xFF;
// [frames, joystick, fire, note]
const script = [
  [20, NONE, false, 'boot'], [5, NONE, true, 'fire'], [60, NONE, false, 'start'],
  [60, RIGHT, false, 'walk right'], [3, NONE, true, 'jump'], [40, NONE, false, 'land'],
  [60, RIGHT, false, 'walk right'], [60, UP, false, 'climb'], [60, LEFT, false, 'walk left'],
  [300, NONE, false, 'wait'],
];
let shot = 0;
for (const [n, joy, fire, note] of script) {
  vcs.swcha = joy; vcs.fire[0] = fire;
  for (let i = 0; i < n; i++) {
    vcs.runFrames(1);
    if (i % every === 0 || i === n - 1)
      console.log(`${note.padEnd(10)} f${String(vcs.frames).padStart(4)} ` +
        `80-83 ${hx(0x80, 4)} | 84 ${h(r(0x84))} 85 ${h(r(0x85))} 86 ${h(r(0x86))} score ${hx(0x87, 2)} 89 ${h(r(0x89))} 8a ${h(r(0x8A))} 8b ${h(r(0x8B))} 8c ${h(r(0x8C))} 8d ${h(r(0x8D))} 8e ${h(r(0x8E))} 8f ${h(r(0x8F))} 90 ${h(r(0x90))} ` +
        `91 ${h(r(0x91))} 92 ${h(r(0x92))} y93 ${h(r(0x93))} 94 ${h(r(0x94))} 95-98 ${hx(0x95, 4)} 99 ${h(r(0x99))} 9a ${h(r(0x9A))} x9b ${h(r(0x9B))} 9c ${h(r(0x9C))} 9d-a0 ${hx(0x9D, 4)} a1-a4 ${hx(0xA1, 4)} | ` +
        `c1-c4 ${hx(0xC1, 4)} c5-c8 ${hx(0xC5, 4)} c9-cc ${hx(0xC9, 4)} cd-d2 ${hx(0xCD, 6)} d3-d8 ${hx(0xD3, 6)} | e5-ed ${hx(0xE5, 9)} | ee-f1 ${hx(0xEE, 4)} f2-f7 ${hx(0xF2, 6)} f8-fd ${hx(0xF8, 6)}`);
  }
  if (out) vcs.savePNG(`${out}/w${String(++shot).padStart(2, '0')}-${note.replace(/ /g, '-')}.png`);
}
