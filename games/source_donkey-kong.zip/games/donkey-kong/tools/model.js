// A model of what Donkey Kong's kernel draws, built only from RAM (and the ROM's tables),
// checked pixel by pixel against tools/vcs.js over a random game. The C64 version draws from
// the same rules, so this is where its geometry is worked out and proven.
//   node games/donkey-kong/tools/model.js [frames] [--seed=N] [--level=1] [--verbose] [--show=frame]
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('36b20c427975760cb9cf4a47e41369e4');
const vcs = new VCS(rom);
if (!process.argv.includes('--plain')) vcs.hmoveBlank = vcs.wideDelay = vcs.respDelay = true;   // (the real TIA, as Stella shows it)
const frames = +(process.argv.find(a => /^\d+$/.test(a)) || 2000);
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const verbose = process.argv.includes('--verbose');
const showFrame = +opt('show', -1);
const T = a => rom[a - 0xF000];
let snap = vcs.ram;                     // the RAM as the kernel saw it (taken when the kernel starts)
let R = a => snap[a - 0x80];

// --- the picture's geometry (lines are 2600 lines from the start of VSYNC; x in 2600 pixels)
// Score on lines 42-48, Kong and Pauline 50-69, the top girder 70-71, then six girder rows of
// 28 lines from line 75 (row 5 at the top down to row 0): 25 lines of the row kernel, with the
// row's playfield, and 3 boundary lines without it (the bottom row stops after 15 lines).
const SCORE_TOP = 42, KONG_TOP = 50, GIRDER_TOP = 70, ROW_TOP = 75, ROW_LINES = 28;
const DIGIT_X = [55, 63, 71, 79, 87, 95];
const KONG_X = 34, PAULINE_X = 63;       // (Kong is double width: the real TIA starts him a pixel late)

const P0 = 1, P1 = 2, M1 = 8, BL = 16, PF = 32;

// 8 pixels of a graphics byte at x (bit 7 leftmost unless reflected), each `w` wide
function drawByte(ob, y, x, g, bit, reflect, w = 1) {
  for (let i = 0; i < 8; i++) {
    const b = reflect ? i : 7 - i;
    if ((g >> b) & 1) for (let k = 0; k < w; k++) { const px = x + i * w + k; if (px >= 0 && px < 160) ob[y * 160 + px] |= bit; }
  }
}
// The playfield registers, kept from line to line: a line is drawn from the values in effect at
// each pixel, `events` being the kernel's writes on that line as [pixel, register, value]
// (register 0 PF0, 1 PF1, 2 PF2; the pixel is the write's colour clock - 68).
const pfr = [0, 0, 0];
function pfBit(x, reflect) {
  let c = x >> 2;
  if (c >= 20) c = reflect ? 39 - c : c - 20;
  if (c < 4) return (pfr[0] >> (4 + c)) & 1;
  if (c < 12) return (pfr[1] >> (11 - c)) & 1;
  return (pfr[2] >> (c - 12)) & 1;
}
function pfLine(ob, y, events, reflect) {
  events.sort((a, b) => a[0] - b[0]);
  let e = 0;
  for (let x = 0; x < 160; x++) {
    while (e < events.length && events[e][0] <= x) { pfr[events[e][1]] = events[e][2]; e++; }
    if (pfBit(x, reflect)) ob[y * 160 + x] |= PF;
  }
  while (e < events.length) { pfr[events[e][1]] = events[e][2]; e++; }
}

function model() {
  const ob = new Uint8Array(160 * 262);
  const level = R(0x90), playing = R(0x8C) & 0x80, reflect = level & 1;
  pfr[0] = pfr[1] = pfr[2] = 0;           // (the frame before ends with them cleared)
  // --- score (7 lines): four digits from the score (attract) or lives and bonus (playing),
  // then two zeros; the first two digits blank while playing
  const src = playing ? 0xA3 : 0x87;
  const nib = [R(src) >> 4, R(src) & 15, R(src + 1) >> 4, R(src + 1) & 15];
  for (let i = 0; i < 6; i++) {
    const base = i >= 4 ? 0xFC00 : (playing && i < 2) ? 0xFC5D : 0xFC00 + nib[i] * 8;
    for (let y = 6; y >= 0; y--) drawByte(ob, SCORE_TOP + 6 - y, DIGIT_X[i], T(base + y), i & 1 ? P1 : P0, false);
  }
  // REFP0 is set once a frame from Mario's facing (climbing: from his Y), and Kong is player 0
  // too, so Kong faces the way Mario does
  const facing = R(0x94);
  const refp0 = (facing & 0x80) ? ((R(0x9B) & 4) << 1) : facing & 8;
  // --- Kong (player 0, double width) and Pauline (player 1), 20 lines; the lives as playfield
  for (let x = 20; x >= 1; x--) {
    const y = KONG_TOP + 20 - x;
    drawByte(ob, y, KONG_X, T(0xFB97 + x), P0, refp0, 2);
    drawByte(ob, y, PAULINE_X, T(0xFDAB + x), P1, false);
    const ev = [[-44, 1, 0]];
    if (x >= 5 && x < 13) ev.push([67, 1, T(0xFBF7 + R(0xA3))]);
    if (x === 1) ev.push([100, 1, 0], [109, 2, 0]);
    pfLine(ob, y, ev, reflect);
  }
  // --- the top girder (2 lines; the writes clearing it come later on the rivets screen)
  for (let y = GIRDER_TOP; y < GIRDER_TOP + 2; y++) pfLine(ob, y, [[-53, 1, 0x0F], [-38, 2, 0xFF], [level ? 139 : 97, 1, 0], [level ? 148 : 106, 2, 0]], reflect);
  // --- the six girder rows
  const marioX = R(0x93) - 4;
  const hammerX = R(0x9C), swing = R(0x95) === 0xA7;
  const m1x = hammerX - 5, m1w = swing ? 4 : 2;
  const blx = (swing ? hammerX + (facing ? 4 : -2) : hammerX - 1) - 5, blw = swing ? 2 : 4;
  const refp1 = level ? 0 : R(0xE8) & 8;    // barrels roll (flip every 8 frames); fireballs don't
  let p1x = null;                           // player 1 keeps its position from row to row
  for (let row = 5; row >= 0; row--) {
    const top = ROW_TOP + (5 - row) * ROW_LINES;
    const gfx = 0xFC00 + R(0xF2 + row), col = 0xFB00 + R(0xF8 + row);
    const coarse = R(0xCD + row);
    // a barrel reaching into the row below sets bit 7 of that row's coarse count: the kernel
    // then leaves player 1 where it is (and the row's shape is the barrel's lower part)
    if (row === 5 || !(coarse & 0x80)) p1x = barrelPos(coarse, R(0xD3 + row)) ?? p1x;
    const barrelX = p1x;
    // the row's playfield tables: set at the end of the row above from that row's index (the
    // top row's by the Kong loop); on the rivets screen from the row's rivets taken
    let pf;
    if (level === 0) pf = row === 5 ? { a: 0xFE4F, b: 0xFED4, c: 0xFF62, d: 0xFD91 }
      : { a: 0xFE00 + T(0xFFE3 + row + 1), b: 0xFE00 + T(0xFFE9 + row + 1), c: 0xFF00 + T(0xFFEF + row + 1), d: 0xFD00 + T(0xFE08 + row + 1) };
    else { const riv = R(0x9D + row); pf = { a: 0xFA00 + T(0xFBAF + riv), b: 0xFA00 + T(0xFBC7 + riv), c: 0xFA00 + T(0xFBDF + riv) }; }
    if (vcs.frames === showFrame) console.log(`row ${row}: gfx ${R(0xF2 + row).toString(16)} col ${R(0xF8 + row).toString(16)} coarse ${coarse.toString(16)} fine ${R(0xD3 + row).toString(16)} -> barrel x ${barrelX}; pf ${Object.values(pf).map(v => v.toString(16)).join(' ')}; Mario X ${R(0x93)}`);
    const lastY = row === 0 ? 13 : 3;
    for (let y = 27; y >= lastY; y--) {
      const line = top + 27 - y;
      const hammerLine = row === 4 && y >= 14;
      // playfield: the kernel's writes on the line
      let ev;
      if (level === 0) ev = hammerLine ? [[46, 2, T(pf.b + y)], [76, 1, T(pf.d + y)], [106, 2, 0], [130, 1, 0]]
        : [[4, 1, T(pf.a + y)], [28, 2, T(pf.b + y)], [52, 0, T(pf.c + y)], [76, 1, T(pf.d + y)], [109, 2, 0], [133, 0, 0]];
      else ev = hammerLine ? [[-65, 2, T(0xFA2A + y)], [37, 1, T(0xFA11 + y)]]
        : [[-2, 1, T(pf.a + y)], [22, 2, T(pf.b + y)], [82, 2, T(pf.c + y)]];
      pfLine(ob, line, ev, reflect);
      // Mario: his shape buffer where the colour table says so
      if (T(col + y)) drawByte(ob, line, marioX, R(0xA5 + y), P0, refp0);
      // the row's barrel (or fireball)
      if (barrelX !== null) drawByte(ob, line, barrelX, T(gfx + y), P1, refp1);
      // the hammer
      if (hammerLine) {
        if (T(R(0x95) + 0xFF00 + y)) for (let k = 0; k < m1w; k++) if (m1x + k >= 0 && m1x + k < 160) ob[line * 160 + m1x + k] |= M1;
        if (T(R(0x97) + 0xFF00 + y)) for (let k = 0; k < blw; k++) if (blx + k >= 0 && blx + k < 160) ob[line * 160 + blx + k] |= BL;
      }
    }
    // the row's three boundary lines (y = 2, 1, 0): the playfield off; Mario and the barrel go on
    if (row > 0) for (let y = 2; y >= 0; y--) {
      const line = top + 27 - y;
      pfLine(ob, line, y === 2 ? [[-65, 2, 0], [-59, 1, 0], [-50, 0, 0]] : [], reflect);
      if (T(col + y)) drawByte(ob, line, marioX, R(0xA5 + y), P0, refp0);
      if (barrelX !== null) drawByte(ob, line, barrelX, T(gfx + y), P1, refp1);
    }
  }
  return ob;
}
// where the kernel's positioning loop puts the row's barrel: pixel X - 4 for the X that gave
// the coarse count and fine value (RowSetup's arithmetic, inverted by a table)
const POS = {};
for (let X = 0; X < 256; X++) {
  let a = X, c = -3;
  do { c++; a -= 15; } while (a >= 0);
  const v = (a & 0xFF) ^ 0x0F;
  const fine = ((v << 4) & 0xFF) + 0x90 + ((v & 0x10) ? 1 : 0);   // (four shifts: the carry is bit 4)
  POS[(c & 0xFF) * 256 + (fine & 0xFF)] = (X - 4 + 160) % 160;
}
function barrelPos(coarse, fine) { return POS[coarse * 256 + fine] ?? null; }

// ------------------------------------------------------------------ check
const play = require('./play')(+opt('seed', 1));
if (+opt('level', 0)) { vcs.runFrames(2); vcs.ram[0x90 - 0x80] = 1; }
let bad = 0, checked = 0, cxBad = 0, cxSeen = { p0p1: 0, m1p0: 0 };
const seen = { hammer: 0, dying: 0, level1: 0, rivets: 0, jump: 0, attract: 0, swing: 0, gameOver: 0 };
const names = { 1: 'P0', 2: 'P1', 8: 'M1', 16: 'BL', 32: 'PF' };
for (let f = 0; f < frames; f++) {
  play.step(vcs);
  const f0 = vcs.frames;
  snap = null;
  while (vcs.frames === f0) { if (vcs.pc === 0xF613) snap = vcs.ram.slice(); vcs.step(); }
  if (!snap) continue;                   // (no picture in this frame: power-on)
  if (R(0x86)) seen.hammer++; if (R(0x8D)) seen.dying++; if (R(0x90)) seen.level1++; if (R(0x90) && [0, 1, 2, 3, 4].some(i => R(0x9D + i))) seen.rivets++;
  if (R(0x85)) seen.jump++; if (!(R(0x8C) & 0x80)) seen.attract++; if (R(0x95) === 0xA7) seen.swing++; if (R(0x8C) === 0 && R(0x87) + R(0x88)) seen.gameOver++;
  const ob = model();
  const diffs = [];
  for (let y = 40; y <= 230; y++) for (let x = 0; x < 160; x++) {
    const a = vcs.ob[y * 160 + x] & (P0 | P1 | M1 | BL | PF), b = ob[y * 160 + x];
    if (a !== b) diffs.push({ y, x, a, b });
  }
  // the collisions the game reads: player 0 - player 1 (Mario and a barrel: CXPPMM bit 7) and
  // missile 1 - player 0 (the hammer and Mario: CXM1P bit 7), latched since the kernel's CXCLR
  let p0p1 = 0, m1p0 = 0;
  for (let i = 0; i < ob.length; i++) { if ((ob[i] & (P0 | P1)) === (P0 | P1)) p0p1 = 1; if ((ob[i] & (P0 | M1)) === (P0 | M1)) m1p0 = 1; }
  const vP0P1 = (vcs.cx >> 13) & 1, vM1P0 = (vcs.cx >> 2) & 1;
  if (vP0P1) cxSeen.p0p1++; if (vM1P0) cxSeen.m1p0++;
  if (p0p1 !== vP0P1 || m1p0 !== vM1P0) { cxBad++; if (cxBad <= 5) console.log(`frame ${vcs.frames}: collisions differ: P0-P1 vcs ${vP0P1} model ${p0p1}, M1-P0 vcs ${vM1P0} model ${m1p0}`); }
  checked++;
  if (diffs.length) {
    bad++;
    if (verbose || bad <= 5) {
      const byBit = {};
      for (const d of diffs) for (const bit of [1, 2, 8, 16, 32]) if ((d.a ^ d.b) & bit) { const k = names[bit] + (d.a & bit ? '-' : '+'); byBit[k] = (byBit[k] || 0) + 1; }
      console.log(`frame ${vcs.frames}: ${diffs.length} pixels differ: ${Object.entries(byBit).map(([k, v]) => k + ' ' + v).join(', ')}; first at ` +
        diffs.slice(0, 6).map(d => `(${d.x},${d.y}) vcs ${d.a} model ${d.b}`).join(' '));
    }
  }
  if (vcs.frames === showFrame) {
    for (let y = 40; y <= 230; y++) {
      let s = '';
      for (let x = 0; x < 160; x++) { const a = vcs.ob[y * 160 + x] & 63, b = ob[y * 160 + x]; s += a === b ? (a ? (a & PF ? '#' : a & P0 ? '0' : a & P1 ? '1' : a & M1 ? 'm' : 'b') : '.') : (a ? 'V' : 'M'); }
      console.log(String(y).padStart(3), s);
    }
  }
}
console.log(`${checked} frames, ${bad} differ, collisions differ in ${cxBad} (seen: Mario-barrel ${cxSeen.p0p1}, hammer-Mario ${cxSeen.m1p0}); frames with: ${Object.entries(seen).map(([k, v]) => k + ' ' + v).join(', ')}`);
process.exit(bad ? 1 : 0);
