// Timing in VICE: does the main loop keep up with the display? Starts its own VICE (monitor on
// a port of its own), starts a game with fire, then counts over --secs=N seconds: frames
// (DbgTops), main loop passes (DbgLoops) and passes that found more than one frame gone by
// (DbgLate), and the frames the VIC drew meanwhile (VICE's cycle stopwatch): frame tops below
// the frames drawn means the interrupt loses frames (the game runs slow). --hold=XX keeps a
// joystick value on SWCHA meanwhile (e.g. 7f: right); --play moves Mario at random and jumps (each monitor command pauses the emulation, not its timing). Then
// a screenshot with the border showing where the time goes (DbgBorder: red render, green game
// ticks, black waiting). DbgRing* in the build hold the last 16 late passes.
//   node games/donkey-kong/tools/c64time.js <outdir> [--ntsc] [--secs=10] [--hold=7f | --play] [--attract] [--keep]
const fs = require('fs');
const net = require('net');
const path = require('path');
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');

const root = path.join(__dirname, '..');
const files = require('../../../tools/buildname').files(path.join(root, 'build'));
const lst = fs.readFileSync(files.lst, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return parseInt(m[1], 16);
};
const hex = n => n.toString(16).padStart(4, '0');
const A = { swcha: addr('DbgSWCHA'), inpt4: addr('DbgINPT4'), border: addr('DbgBorder'), loops: addr('DbgLoops'), late: addr('DbgLate'), tops: addr('DbgTops') };
const out = path.resolve(process.argv[2] || '.');
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const ntsc = process.argv.includes('--ntsc'), keep = process.argv.includes('--keep');
const secs = +opt('secs', 10), hold = opt('hold', 'ff');
const sleep = ms => new Promise(r => setTimeout(r, ms));
let PORT = 0, vice = null;

function mon(cmds) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(PORT, '127.0.0.1');
    let buf = '';
    sock.on('data', d => { buf += d.toString('latin1'); });
    sock.on('error', reject);
    sock.on('connect', async () => {
      await sleep(150);
      for (const c of cmds) { sock.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 300); }
      sock.write('x\n');
      await sleep(100);
      sock.end();
      resolve(buf.replace(/\(C:\$[0-9a-f]{4}\) /g, ''));
    });
  });
}
const word = (dump, a) => {
  const bytes = [];
  for (const m of dump.matchAll(/>C:([0-9a-f]{4})((?:\s+[0-9a-f]{2})+)/gi)) {
    const base = parseInt(m[1], 16);
    m[2].trim().split(/\s+/).forEach((b, i) => { bytes[base + i] = parseInt(b, 16); });
  }
  return bytes[a] + 256 * bytes[a + 1];
};

(async () => {
  fs.mkdirSync(out, { recursive: true });
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress',
    `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', files.prg]);
  let ok = false;
  for (let t = 0; t < 30 && !ok; t++) { await sleep(1000); try { ok = await runsOurs(mon, files.prg); } catch { /* not up yet */ } }
  if (!ok) throw new Error(`the VICE on port ${PORT} isn't running ${path.basename(files.prg)}: stopping`);
  await sleep(3000);
  if (!process.argv.includes('--attract')) {
    await mon([`> ${hex(A.inpt4)} 7f`]); await sleep(300); await mon([`> ${hex(A.inpt4)} ff`]);
    await sleep(2000);
  }
  const lo = Math.min(A.loops, A.late, A.tops), hi = Math.max(A.loops, A.late, A.tops) + 1;
  await mon([`> ${hex(A.swcha)} ${hold}`, `> ${hex(A.loops)} 0 0`, `> ${hex(A.late)} 0 0`, `> ${hex(A.tops)} 0 0`]);
  const clock = async () => +((await mon(['r'])).match(/^\.;.*\s(\d+)\s*$/m) || [0, NaN])[1];   // VICE's cycle stopwatch
  const c0 = await clock();
  if (process.argv.includes('--play')) {   // Mario moves at random and jumps (each poke pauses the emulation, but not its timing)
    let seed = 7;
    const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    const moves = ['bf', '7f', 'bf', '7f', 'ef', 'df'];
    const t0 = Date.now();
    while (Date.now() - t0 < secs * 1000) {
      const cmds = [`> ${hex(A.swcha)} ${moves[Math.floor(rnd() * moves.length)]}`];
      if (rnd() < 0.3) cmds.push(`> ${hex(A.inpt4)} 7f`);
      await mon(cmds);
      await sleep(250);
      await mon([`> ${hex(A.inpt4)} ff`]);
      await sleep(250);
    }
  } else await sleep(secs * 1000);
  const d = await mon([`m ${hex(lo)} ${hex(hi)}`]);
  const c1 = await clock();
  const tops = word(d, A.tops), loops = word(d, A.loops), late = word(d, A.late);
  const shown = (c1 - c0) / (ntsc ? 263 * 65 : 312 * 63);   // the frames the VIC drew meanwhile
  console.log(`${ntsc ? 'NTSC' : 'PAL'}: ${tops} frame tops of ${shown.toFixed(0)} frames drawn (${(100 * tops / shown).toFixed(1)}%: below 100 the interrupt loses frames), ${loops} main loop passes, ${late} late (${(100 * late / Math.max(1, loops)).toFixed(1)}%)`);
  await mon([`> ${hex(A.border)} 1`]);
  await sleep(500);
  const f = path.join(out, `border-${ntsc ? 'ntsc' : 'pal'}.png`);
  await mon([`screenshot "${f.replace(/\\/g, '/')}" 2`]);
  for (let t = 0; t < 50 && !fs.existsSync(f); t++) await sleep(200);
  await mon([`> ${hex(A.border)} 0`, `> ${hex(A.swcha)} ff`]);
  if (keep) console.log(`VICE left running; monitor port ${PORT}, pid ${vice.pid}`);
  else stopVice(vice);
})().catch(e => { console.log(e.message); stopVice(vice); });
