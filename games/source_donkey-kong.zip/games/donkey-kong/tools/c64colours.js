// Do Mario's per-line colours land on the right lines in VICE? Starts its own VICE (PAL, or
// --ntsc; monitor on a port of its own), starts a game, then --shots=N times: a random move,
// then (emulation paused) a screenshot plus the shown buffer's sprite 0 (Mario): its block,
// position, first colour and colour events. Each of Mario's set pixels on screen is compared
// with the colour the events give its raster line (colours learnt from the screenshots: the
// RGB most often seen for each C64 colour). Prints the lines that came out wrong, badlines
// (raster & 7 = 3) apart. Mario is drawn 0-7 lines lower in turn (DbgMarioDY, display only) so
// his colour changes meet every badline phase.
//   node games/donkey-kong/tools/c64colours.js <outdir> [--ntsc] [--shots=60] [--keep]
const fs = require('fs');
const net = require('net');
const path = require('path');
const { png } = require('../../../tools/greydots');
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');

const files = require('../../../tools/buildname').files(path.join(__dirname, '..', 'build'));
const lst = fs.readFileSync(files.lst, 'latin1');
const addr = n => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${n}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + n);
  return parseInt(m[1], 16);
};
const hex = n => n.toString(16).padStart(4, '0');
const out = path.resolve(process.argv[2] || '.');
const opt = (n, d) => { const a = process.argv.find(x => x.startsWith(`--${n}=`)); return a ? a.split('=')[1] : d; };
const ntsc = process.argv.includes('--ntsc'), keep = process.argv.includes('--keep');
const shots = +opt('shots', 60);
const NEV = 24, ENDRASTER = 242, SPRDATA = 0x4000, SCREEN = 0x5C00;
const A = {};
for (const n of ['DbgMarioDY', 'curBuf', 'StX', 'StY', 'StPtr', 'StCol', 'StMsb', 'StEn', 'EvRas', 'EvReg', 'EvVal', 'DbgSWCHA', 'DbgINPT4']) A[n] = addr(n);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let PORT = 0;

function mon(cmds) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(PORT, '127.0.0.1');
    let buf = '';
    sock.on('data', d => { buf += d.toString('latin1'); });
    sock.on('error', reject);
    sock.on('connect', async () => {
      await sleep(100);
      for (const c of cmds) { sock.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 500 : 120); }
      sock.write('x\n');
      await sleep(60);
      sock.end();
      resolve(buf);
    });
  });
}
const bytesOf = dump => {
  const mem = {};
  for (const m of dump.matchAll(/>C:([0-9a-f]{4})((?:\s+[0-9a-f]{2}){1,16})/gi)) {
    const base = parseInt(m[1], 16);
    m[2].trim().split(/\s+/).forEach((b, i) => { mem[base + i] = parseInt(b, 16); });
  }
  return mem;
};
const range = (a, n) => `m ${hex(a)} ${hex(a + n - 1)}`;

(async () => {
  fs.mkdirSync(out, { recursive: true });
  PORT = await freePort();
  const vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress',
    `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', files.prg]);
  let ok = false;
  for (let t = 0; t < 30 && !ok; t++) { await sleep(1000); try { ok = await runsOurs(mon, files.prg); } catch { /* not up yet */ } }
  if (!ok) { console.log(`the VICE on port ${PORT} isn't running the build`); stopVice(vice); return; }
  await sleep(2000);
  let seed = 3;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const moves = ['bf', '7f', 'bf', '7f', 'ef', 'df', 'ff'];
  const frames = [];
  for (let i = 0; i < shots; i++) {
    const cmds = [`> ${hex(A.DbgSWCHA)} ${moves[Math.floor(rnd() * moves.length)]}`];
    cmds.push(`> ${hex(A.DbgINPT4)} ${i % 25 === 0 || rnd() < 0.15 ? '7f' : 'ff'}`);   // fire: start a game, jump now and then
    cmds.push(`> ${hex(A.DbgMarioDY)} ${(i % 8).toString(16)}`);   // Mario 0-7 lines lower (display only): every badline phase
    await mon(cmds);
    await sleep(250 + Math.floor(rnd() * 400));
    const f = path.join(out, `m${i}.png`);
    try { fs.unlinkSync(f); } catch { /* none */ }
    const d = await mon([`screenshot "${f.replace(/\\/g, '/')}" 2`, range(A.curBuf, 1), range(A.StX, 16), range(A.StY, 16), range(A.StPtr, 16),
      range(A.StCol, 16), range(A.StMsb, 2), range(A.StEn, 2), range(A.EvRas, 2 * NEV), range(A.EvReg, 2 * NEV), range(A.EvVal, 2 * NEV)]);
    for (let t = 0; t < 30 && !fs.existsSync(f); t++) await sleep(100);
    const mem = bytesOf(d);
    const buf = mem[A.curBuf];
    if (!(mem[A.StEn + buf] & 1)) continue;                 // no Mario shown
    const blk = mem[A.StPtr + 8 * buf];
    const blkDump = bytesOf(await mon([range(SPRDATA + 64 * blk, 63)]));
    frames.push({ f, buf, mem, blk: [...Array(63).keys()].map(k => blkDump[SPRDATA + 64 * blk + k]) });
    fs.writeFileSync(f.replace(/\.png$/, '.json'), JSON.stringify(frames[frames.length - 1]));
  }
  await mon([`> ${hex(A.DbgSWCHA)} ff`, `> ${hex(A.DbgINPT4)} ff`, `> ${hex(A.DbgMarioDY)} 0`]);
  if (keep) console.log(`VICE left running: port ${PORT}, pid ${vice.pid}`); else stopVice(vice);

  // the screenshot's geometry: the score digits' top line (2600 line 42: raster 53) is the
  // first thing drawn
  const first = png(frames[0].f);
  let yofs = null;
  for (let y = 0; y < 120 && yofs === null; y++) for (let x = 0; x < first.w; x++) { const o = (y * first.w + x) * first.bpp; if (first.px[o] | first.px[o + 1] | first.px[o + 2]) { yofs = 53 - y; break; } }
  const XOFS = 8;                                          // screenshot x = sprite x register + 8
  const samples = [];                                      // [frame, raster, expected colour, rgb list]
  const offsets = {};
  let stale = 0;
  for (const fr of frames) {
    const im = png(fr.f), { mem, buf } = fr;
    const sx = mem[A.StX + 8 * buf] + ((mem[A.StMsb + buf] & 1) ? 256 : 0), sy = mem[A.StY + 8 * buf];
    const ev = [];
    for (let i = 0; i < NEV; i++) { const r = mem[A.EvRas + NEV * buf + i]; if (r >= ENDRASTER) break; if ((mem[A.EvReg + NEV * buf + i] & 0x7f) === 0x27) ev.push([r, mem[A.EvVal + NEV * buf + i]]); }
    // where the sprite's rows and pixels sit on the screenshot: the offset (rows -1..1 from
    // Y + 1, pixels -2..2 from X + XOFS) where its set bits best match lit pixels
    const lit = (x, y) => { if (y < 0 || y >= im.h || x < 0 || x >= im.w) return false; const o = (y * im.w + x) * im.bpp; return !!(im.px[o] | im.px[o + 1] | im.px[o + 2]); };
    let best = null;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -2; dx <= 2; dx++) {
      let score = 0;
      for (let row = 0; row < 21; row++) for (let b = 0; b < 8; b++) {
        const set = (fr.blk[3 * row] >> (7 - b)) & 1, x = sx + XOFS + dx + 2 * b, y = sy + 1 + dy + row - yofs;
        score += set ? (lit(x, y) && lit(x + 1, y) ? 1 : -1) : 0;
      }
      if (!best || score > best.score) best = { score, dx, dy };
    }
    // the screenshot can be the frame before the one in memory (VICE's last finished picture):
    // use a frame only if the sprite's shape on screen is exactly the block's
    let same = true;
    for (let row = 0; row < 21 && same; row++) for (let b = 0; b < 8; b++) {
      const set = (fr.blk[3 * row] >> (7 - b)) & 1, x = sx + XOFS + best.dx + 2 * b, y = sy + 1 + best.dy + row - yofs;
      if (set && !lit(x, y)) { same = false; break; }
    }
    if (!same) { stale++; continue; }
    for (let row = 0; row < 21; row++) {
      const raster = sy + 1 + best.dy + row;
      if (raster >= ENDRASTER) break;                       // (only the test's shift puts him there: no events)
      let col = mem[A.StCol + 8 * buf];
      for (const [r, v] of ev) if (r <= raster) col = v;
      const rgbs = [];
      const byte = fr.blk[3 * row];
      for (let b = 0; b < 8; b++) if ((byte >> (7 - b)) & 1) for (let k = 0; k < 2; k++) {
        const x = sx + XOFS + best.dx + 2 * b + k, y = raster - yofs;
        if (y < 0 || y >= im.h || x < 0 || x >= im.w) continue;
        const o = (y * im.w + x) * im.bpp; rgbs.push(`${im.px[o]},${im.px[o + 1]},${im.px[o + 2]}`);
      }
      if (rgbs.length) samples.push({ f: path.basename(fr.f), raster, col, rgbs, change: ev.some(([r]) => r === raster) });
    }
    offsets[`${best.dx},${best.dy}`] = (offsets[`${best.dx},${best.dy}`] || 0) + 1;
  }
  // each C64 colour's RGB: the one most often seen on lines away from a colour change
  const votes = {};
  for (const s of samples) if (!s.change) for (const c of s.rgbs) { const v = votes[s.col] || (votes[s.col] = {}); v[c] = (v[c] || 0) + 1; }
  const rgbOf = {};
  for (const [c, v] of Object.entries(votes)) rgbOf[c] = Object.entries(v).sort((a, b) => b[1] - a[1])[0][0];
  let bad = 0, badBad = 0, lines = 0, badLines = 0, changes = 0, badChanges = 0;
  const report = [];
  for (const s of samples) {
    const isBad = (s.raster & 7) === 3;
    lines++; if (isBad) badLines++;
    if (s.change) { changes++; if (isBad) badChanges++; }
    const want = rgbOf[s.col];
    const wrong = s.rgbs.filter(c => c !== want).length;
    if (want && wrong) { bad++; if (isBad) badBad++; report.push(`${s.f} raster ${s.raster}${isBad ? ' (badline)' : ''}${s.change ? ' change' : ''}: ${wrong} of ${s.rgbs.length} pixels not colour ${s.col}`); }
  }
  console.log(report.slice(0, 30).join('\n'));
  console.log(`${frames.length} frames with Mario (${stale} skipped: the screenshot a frame behind), ${lines} lines (${badLines} badlines, ${changes} with a colour change, ${badChanges} of them on a badline): ${bad} wrong (${badBad} on badlines); screenshot y = raster - ${yofs}; sprite offsets found (dx,dy: frames) ${JSON.stringify(offsets)}`);
})().catch(e => { console.log(e.stack); });
