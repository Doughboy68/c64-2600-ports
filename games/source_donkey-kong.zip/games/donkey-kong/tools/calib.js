// Measures where the kernel puts each object for each X value, by poking the RAM and watching
// the emulator's object positions after the HMOVE that follows each positioning.
//   node games/donkey-kong/tools/calib.js
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('36b20c427975760cb9cf4a47e41369e4');
const vcs = new VCS(rom);
vcs.runFrames(30);                        // attract mode: Mario stands, no barrels
const orig = vcs.tiaWrite.bind(vcs);
let log = [];
vcs.tiaWrite = (a, v) => { orig(a, v); if (a === 0x2A) log.push([vcs.line, [...vcs.pos]]); };
const R = (a, v) => { vcs.ram[a - 0x80] = v; };
const results = { mario: [], barrelTop: [], barrelRow: [], m1: [], bl: [] };
for (let X = 30; X <= 126; X++) {
  R(0x93, X);                             // Mario
  R(0x83, 12); R(0xC4, X);                // barrel slot 3 in the top row (row 5)
  R(0x82, 40); R(0xC3, X);                // barrel slot 2 in row 4
  R(0x9C, X);                             // the hammer (at rest: ball at X - 1)
  log = [];
  vcs.runFrames(1);
  const after = line => { const e = log.find(l => l[0] >= line); return e ? e[1] : null; };
  const p73 = after(73), p74 = after(74), p101 = after(100), p10 = after(10);
  results.mario.push(p73[0] - X);
  results.barrelTop.push(p74[1] - X);
  results.barrelRow.push(p101[1] - X);
  results.m1.push(p10[3] - X);
  results.bl.push(p10[4] - X);
}
for (const [k, v] of Object.entries(results)) {
  const counts = {};
  v.forEach((d, i) => { counts[d] = (counts[d] || []); counts[d].push(i + 30); });
  console.log(k.padEnd(10), Object.entries(counts).map(([d, xs]) => `${d}: X ${xs[0]}..${xs[xs.length - 1]}${xs.length < xs[xs.length - 1] - xs[0] + 1 ? ' (not all)' : ''} (${xs.length})`).join(' | '));
}
