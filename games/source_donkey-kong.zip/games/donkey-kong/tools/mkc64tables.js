// Generate lookup tables for the Donkey Kong C64 port: c64/tables.inc
//   node games/donkey-kong/tools/mkc64tables.js
const fs = require('fs');
const out = [];
const bytes = (label, arr, comment) => {
  out.push('', `; ${comment}`, `${label}:`);
  for (let i = 0; i < arr.length; i += 16)
    out.push('        .byte ' + arr.slice(i, i + 16).map(v => '$' + (v & 255).toString(16).padStart(2, '0')).join(', '));
};

// ---- 2600 NTSC colour -> C64 colour, indexed by (colour >> 1) = hue * 8 + luminance.
// Nearest C64 colour to the standard 2600 NTSC palette, compared in YUV with extra weight on
// hue. Clearly coloured 2600 colours never map to the C64's greys. Not brightened (Berzerk's
// table lifts every colour by 1.3): that turned the 2600's upper greys all white and made the
// attract mode's colour cycle jump; plain, its steps are even and Kong is brick, not pink.
const NTSC = `000000 404040 6C6C6C 909090 B0B0B0 C8C8C8 DCDCDC ECECEC
444400 646410 848424 A0A034 B8B840 D0D050 E8E85C FCFC68
702800 844414 985C28 AC783C BC8C4C CCA05C DCB468 ECC878
841800 983418 AC5030 C06848 D0805C E09470 ECA880 FCBC94
880000 9C2020 B03C3C C05858 D07070 E08888 ECA0A0 FCB4B4
78005C 8C2074 A03C88 B0589C C070B0 D084C0 DC9CD0 ECB0E0
480078 602090 783CA4 8C58B8 A070CC B484DC C49CEC D4B0FC
140084 302098 4C3CAC 6858C0 7C70D0 9488E0 A8A0EC BCB4FC
000088 1C209C 3840B0 505CC0 6874D0 7C8CE0 90A4EC A4B8FC
00187C 1C3890 3854A8 5070BC 6888CC 7C9CDC 90B4EC A4C8FC
002C5C 1C4C78 386890 5084AC 689CC0 7CB4D4 90CCE8 A4E0FC
003C2C 1C5C48 387C64 509C80 68B494 7CD0AC 90E4C0 A4FCD4
003C00 205C20 407C40 5C9C5C 74B474 8CD08C A4E4A4 B8FCB8
143800 345C1C 507C38 6C9850 84B468 9CCC7C B4E490 C8FCA4
2C3000 4C501C 687034 848C4C 9CA864 B4C078 CCD488 E0EC9C
442800 644818 846830 A08444 B89C58 D0B46C E8CC7C FCE08C`.split(/\s+/).map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
const PEPTO = ['000000','FFFFFF','96282E','5BD6CE','9F2DAD','41B936','2724C4','EFF347','9F4815','5E3500','DA5F66','474747','787878','91FF84','6864FF','AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
const BOOST = 1.0, CHROMA = 2.5, GREYS = [0, 1, 11, 12, 15];
const yuv = c => { const [r, g, b] = c; const y = 0.299 * r + 0.587 * g + 0.114 * b; return [y, 0.492 * (b - y), 0.877 * (r - y)]; };
const dist = (a, b) => { const p = yuv(a), q = yuv(b); return (p[0] - q[0]) ** 2 + CHROMA * ((p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2); };
const map = NTSC.map(c => {
  const lit = c.map(v => Math.min(255, v * BOOST));
  const mx = Math.max(...c), mn = Math.min(...c), sat = mx ? (mx - mn) / mx : 0;
  let best = -1;
  PEPTO.forEach((p, i) => {
    if (sat > 0.2 && GREYS.includes(i)) return;
    if (best < 0 || dist(lit, p) < dist(lit, PEPTO[best])) best = i;
  });
  return best;
});
// Colours Donkey Kong uses, where the nearest match looks wrong (none yet)
const OVERRIDE = {};
for (const [c, v] of Object.entries(OVERRIDE)) map[c >> 1] = v;
bytes('ColorMap', map, '2600 colour (value >> 1) -> C64 colour');

// ---- TIA sound -> SID (as Berzerk)
const TIA_CLOCK = 3579545 / 114;
const SID_CLOCKS = { '': 985248, N: 1022727 };
const AUDC = [[0x00, 1], [0x80, 1], [0x40, 15], [0x80, 2], [0x40, 2], [0x40, 2], [0x40, 31], [0x40, 31], [0x80, 1], [0x40, 31], [0x40, 31], [0x00, 1], [0x40, 6], [0x40, 6], [0x40, 93], [0x40, 186]];
bytes('SidWave', AUDC.map(a => a[0]), 'SID waveform per AUDC value (0 = silent)');
for (const [suffix, clock] of Object.entries(SID_CLOCKS)) {
  const flo = [], fhi = [];
  for (const [wave, div] of AUDC) {
    for (let f = 0; f < 32; f++) {
      let hz = TIA_CLOCK / (f + 1) / div;
      if (wave === 0x80) hz /= 16;
      const reg = Math.min(0xFFFF, Math.round(hz * 16777216 / clock));
      flo.push(reg & 255); fhi.push(reg >> 8);
    }
  }
  const sys = suffix ? 'NTSC' : 'PAL';
  bytes('SidFreqLo' + suffix, flo, `SID frequency low byte (${sys}), index AUDC * 32 + AUDF`);
  bytes('SidFreqHi' + suffix, fhi, `SID frequency high byte (${sys}), must follow the low bytes directly`);
}

// ---- bitmap line addresses: screen line s -> BITMAP + (s >> 3) * 320 + (s & 7)
const BITMAP = 0x6000;
const lines = [...Array(200).keys()].map(s => BITMAP + (s >> 3) * 320 + (s & 7));
bytes('BmpLo', lines.map(a => a & 255), 'bitmap address of each screen line, low');
bytes('BmpHi', lines.map(a => a >> 8), 'bitmap address of each screen line, high');

// ---- a row's barrel: the kernel positions player 1 from RowCoarse (loop count c) and RowFine
// (HMP1 value): pixel = 15 * c + FineX[RowFine >> 4] (the inverse of RowSetup's arithmetic)
const fineX = Array(16).fill(0);
for (let X = 0; X < 160; X++) {
  let a = X, c = -3;
  do { c++; a -= 15; } while (a >= 0);
  const v = (a & 0xFF) ^ 0x0F;
  const fine = (((v << 4) & 0xFF) + 0x90 + ((v & 0x10) ? 1 : 0)) & 0xFF;
  if (c >= 0) fineX[fine >> 4] = ((X - 4) - 15 * c + 256) & 255;
}
bytes('FineX', fineX, "a row's barrel: pixel = 15 * RowCoarse + FineX[RowFine >> 4]");
bytes('Mul15', [0, 15, 30, 45, 60, 75, 90, 105], '15 * n');

// ---- bit reversal (REFP0 / REFP1)
bytes('Reverse', [...Array(256).keys()].map(v => { let r = 0; for (let i = 0; i < 8; i++) if (v & (1 << i)) r |= 0x80 >> i; return r; }), 'the byte with its bits in reverse order');
// ---- a shape byte doubled: each bit twice (Kong, double width)
const dbl = [...Array(256).keys()].map(v => { let r = 0; for (let i = 0; i < 8; i++) if (v & (1 << i)) r |= 3 << (2 * i); return r; });
bytes('DblLo', dbl.map(v => v & 255), 'each bit twice: low byte (bits 3-0)');
bytes('DblHi', dbl.map(v => v >> 8), 'each bit twice: high byte (bits 7-4)');

fs.writeFileSync(__dirname + '/../c64/tables.inc', '; Generated by games/donkey-kong/tools/mkc64tables.js - do not edit\n' + out.join('\n') + '\n');
console.log('wrote games/donkey-kong/c64/tables.inc');
