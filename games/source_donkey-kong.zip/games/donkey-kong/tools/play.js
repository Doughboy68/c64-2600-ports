// A random player for the checks: joystick directions held for a while, jumps now and then,
// fire to start a game and Game Reset when it is over. Deterministic from a seed.
//   const play = require('./play')(seed); each frame: play.step(vcs) sets vcs.swcha / fire / swchb
module.exports = function (seed = 1) {
  let s = seed * 16807 % 2147483647 || 1;
  const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
  const DIRS = [0xFF, 0x7F, 0xBF, 0xEF, 0xDF, 0x7F, 0xBF];   // none, right, left, up, down, right, left
  let hold = 0, dir = 0xFF, fireLeft = 0, resetLeft = 0, frame = 0;
  return {
    step(vcs) {
      frame++;
      const state = vcs.ram[0x8C - 0x80];
      vcs.swchb |= 1;
      if (state === 0 && frame > 20) {                      // no game: fire starts one, and now and
        if (frame % 40 === 0) fireLeft = 3;                 // then Game Reset (after a game over on
        if (frame % 300 === 150) resetLeft = 4;             // the rivets screen fire doesn't)
      }
      if (resetLeft-- > 0) vcs.swchb &= ~1;
      if (hold-- <= 0) { hold = 10 + Math.floor(rnd() * 60); dir = DIRS[Math.floor(rnd() * DIRS.length)]; }
      if (fireLeft <= 0 && rnd() < 0.015) fireLeft = 3;
      vcs.swcha = dir;
      vcs.fire[0] = fireLeft-- > 0;
    },
  };
};
