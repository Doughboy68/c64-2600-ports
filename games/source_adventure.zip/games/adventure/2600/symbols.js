// Names for Adventure's RAM and routines, worked out by reading the code and
// watching RAM in tools/vcs.js. Used by tools/disasm.js to label the source and to
// write RAM-MAP.md. "?" marks something not yet confirmed.
//
// Conventions found in the code:
//   - The main loop (MainLoop) takes three frames per pass; each frame runs part of the
//     game logic, then calls the kernel (Kernel) as a subroutine.
//   - Objects are numbered by their offset in the object table at $FF44 (9 bytes each):
//     state address (room, X, Y), animation byte address, shape list, colour, B&W colour,
//     NUSIZ. $A2 means "no object". Dragons $36 $3F $48, keys $63 $6C $75, bat $7E,
//     dot $87, chalice $90, magnet $99, sword $51, bridge $5A, gates $09 $12 $1B,
//     the dark mazes' light $00, the number of the game $2D, the author's name $24.
//   - Rooms are numbered by their entry in the room table at $FE1B (9 bytes each):
//     playfield pointer, colour, B&W colour, CTRLPF, rooms above/right/below/left.
//   - Y coordinates count kernel line pairs from the bottom of the picture (bigger = higher).

const game = { title: 'Adventure', from: 'Atari 2600, 1980', md5: '157bddb7192754a45372be196797f284', asm: 'adventure.asm' };

const ram = [
  [0x80, 'PFPtr', 2, 'The room\'s playfield: 3 bytes (PF0, PF1, PF2) per row, 7 rows'],
  [0x82, 'P0Ptr', 2, 'Player 0 object\'s shape (bytes until a zero)'],
  [0x84, 'P1Ptr', 2, 'Player 1 object\'s shape'],
  [0x86, 'P0X', 1, 'Player 0 object X (positioned by HPos)'],
  [0x87, 'P0Y', 1, 'Player 0 object Y: the kernel starts its shape when its line counter drops below this'],
  [0x88, 'P1X', 1, 'Player 1 object X'],
  [0x89, 'P1Y', 1, 'Player 1 object Y'],
  [0x8A, 'Room', 1, 'The room the player (the square, the ball) is in; 0 = the game number screen'],
  [0x8B, 'BallX', 1, 'The player\'s X'],
  [0x8C, 'BallY', 1, 'The player\'s Y'],
  [0x8D, 'BallTop', 1, 'Kernel: BallY - 4; the ball shows for the 4 line pairs from here down'],
  [0x8E, 'KLine', 1, 'Kernel: line pair counter, $68 down to 8 (left at 7)'],
  [0x8F, 'PFIndex', 1, 'Kernel: offset of the next playfield row'],
  [0x90, 'P0Row', 1, 'Kernel: player 0 shape row'],
  [0x91, 'P1Row', 1, 'Kernel: player 1 shape row'],
  [0x92, 'LastSwitches', 1, 'SWCHB last pass (reset and select act on a press)'],
  [0x93, 'Ptr', 2, 'Scratch pointer (room or object table entries, object state)'],
  [0x95, 'Obj0', 1, 'Object shown as player 0 this frame'],
  [0x96, 'Obj1', 1, 'Object shown as player 1 this frame (the light and the bridge are always put here)'],
  [0x97, 'Touched', 1, 'Scratch: the object the player touched or that touched another'],
  [0x98, 'Unused98', 1, 'Set to $FF when looking for an object to pick up?'],
  [0x99, 'Joystick', 1, 'Joystick (SWCHA) for the player\'s move; $FF while being pushed back'],
  [0x9A, 'Temp', 1, 'Scratch'],
  [0x9B, 'Temp2', 1, 'Scratch: directions to move (joystick bits)'],
  [0x9C, 'ScanStart', 1, 'Flicker: object number where the search for this frame\'s two objects starts'],
  [0x9D, 'Carried', 1, 'Object the player carries; $A2 none'],
  [0x9E, 'CarryDX', 1, 'Carried object X - player X'],
  [0x9F, 'CarryDY', 1, 'Carried object Y - player Y'],
  [0xA0, 'DragonObj', 1, 'Scratch: the dragon being moved'],
  [0xA1, 'Dot', 3, 'The dot: room, X, Y'],
  [0xA4, 'Rhindle', 5, 'Red dragon: room, X, Y, move counter?, state (0 alive, 1 dead, 2 eating, 3 roaring?)'],
  [0xA9, 'Yorgle', 5, 'Yellow dragon: room, X, Y, move counter?, state'],
  [0xAE, 'Grundle', 5, 'Green dragon: room, X, Y, move counter?, state'],
  [0xB3, 'Magnet', 3, 'Magnet: room, X, Y'],
  [0xB6, 'Sword', 3, 'Sword: room, X, Y'],
  [0xB9, 'Chalice', 3, 'Chalice: room, X, Y'],
  [0xBC, 'Bridge', 3, 'Bridge: room, X, Y'],
  [0xBF, 'YellowKey', 3, 'Gold key: room, X, Y'],
  [0xC2, 'WhiteKey', 3, 'White key: room, X, Y'],
  [0xC5, 'BlackKey', 3, 'Black key: room, X, Y'],
  [0xC8, 'Gates', 3, 'The three castle gates (gold, white, black): open/close state, 1 = open?, $1C = closed'],
  [0xCB, 'Bat', 3, 'Bat: room, X, Y'],
  [0xCE, 'BatDir', 1, 'Bat: direction it flies (joystick bits)?'],
  [0xCF, 'BatFlap', 1, 'Bat: wing animation, 0-7'],
  [0xD0, 'BatCarries', 1, 'Bat: the object it carries'],
  [0xD1, 'BatTimer', 1, 'Bat: frames since it grabbed something (0 = looking)'],
  [0xD2, 'ListPtr', 2, 'Scratch pointer to an object list (what a dragon or the bat goes for or flees)'],
  [0xD4, 'Speed', 1, 'Scratch: steps to move'],
  [0xD5, 'MoverState', 1, 'Scratch: the moving creature\'s state address'],
  [0xD6, 'Ignore', 1, 'Scratch: object the creature ignores (the one it carries)'],
  [0xD7, 'FireHistory', 1, 'Fire button over the last frames (bit 7 newest)'],
  [0xD8, 'Temp3', 1, 'Scratch'],
  [0xD9, 'Light', 3, 'The dark mazes\' light around the player: room, X, Y'],
  [0xDC, 'AnimState', 1, 'Scratch: animation state when picking an object\'s shape'],
  [0xDD, 'GameLevel', 1, 'Game 1-3 as 0, 2, 4'],
  [0xDE, 'GameOver', 1, '$FF: the chalice is home, game won (or before the first game)'],
  [0xDF, 'SoundTimer', 1, 'Sound effect: frames left'],
  [0xE0, 'SoundEffect', 1, 'Sound effect: 0 won, 1 picked up?, 2 dragon dies?, 3 eaten?, 4 put down?, 5 roar?'],
  [0xE1, 'ListIndex', 1, 'Scratch: index into an object list'],
  [0xE2, 'SavedRoom', 1, 'The player\'s room, X, Y before this move (put back when blocked)'],
  [0xE3, 'SavedX', 1, ''],
  [0xE4, 'SavedY', 1, ''],
  [0xE5, 'FrameCount', 1, 'Frame counter (also the random number source, and the chalice\'s colour)'],
  [0xE6, 'IdleCount', 1, 'Counts up while nothing is pressed; bit 7 set: attract mode colours'],
];

const labels = {
  0xF008: ['Kernel', 'Draw the picture: position the objects, then 2 lines per pass from line pair $68 down'],
  0xF0D2: ['HPos', 'Position object X at horizontal position A (coarse wait, fine motion)'],
  0xF0EC: ['WaitVSync', 'Wait for the timer, then vertical sync; set the timer for the vertical blank'],
  0xF10F: ['SetupFrame', 'Room colours and playfield, pick this frame\'s two objects, their shapes and colours'],
  0xF235: ['PickObjects', 'Flicker: the next two objects (from ScanStart on) in the player\'s room'],
  0xF271: ['RoomEntry', 'Ptr = the room table entry for room A'],
  0xF2A1: ['FindShape', 'Y = offset of the shape list entry for animation state AnimState'],
  0xF2B2: ['IdleTimer', 'Frame counter; attract mode colours after a while without input'],
  0xF2D3: ['Colour', 'Colour A (odd: read from RAM $80 + A/2), with the attract mode colour cycle'],
  0xF2E4: ['ObjEntry', 'Ptr = the state address of object X'],
  0xF2EF: ['PowerOn', 'Power on: clear the TIA and RAM, position the walls, game select screen'],
  0xF306: ['MainLoop', 'Three frames per pass'],
  0xF365: ['GameWon', 'After the chalice is home: just the picture (and the switches)'],
  0xF371: ['PlaceWalls', 'Position the thin walls (missiles) at 13 and 150'],
  0xF384: ['Switches', 'Game Reset (start, or back to the gold castle) and Game Select'],
  0xF3D3: ['NewGame', 'Game select screen: objects to their places for the game number'],
  0xF412: ['RandomPlaces', 'Game 3: objects to random rooms'],
  0xF4C2: ['MovePlayer', 'Player: blocked by walls and objects (the bridge lets it through), joystick'],
  0xF556: ['PickUp', 'Fire drops; touching an object picks it up'],
  0xF5D4: ['MoveCarried', 'The carried object moves with the player'],
  0xF5FF: ['MoveObject', 'Move object X by the joystick bits in A, Y times; room changes at the edges'],
  0xF6AC: ['Step', 'Step object X by the direction bits in A, Y times'],
  0xF6D5: ['RoomForGame', 'Room numbers $80 and up depend on the game number'],
  0xF6E9: ['TouchesBall', 'Is object A (shown this frame) touching the player?'],
  0xF6FE: ['TouchesOther', 'Object X touching the other object shown this frame: that object, else $A2'],
  0xF715: ['Seek', 'A creature chooses what to go for or flee from its list, and moves'],
  0xF728: ['SeekList', 'Find the first object in the list in the creature\'s room'],
  0xF757: ['Direction', 'Joystick-style direction bits from the creature towards the object'],
  0xF795: ['RhindleMove', 'Red dragon'],
  0xF7B0: ['YorgleMove', 'Yellow dragon'],
  0xF7CB: ['GrundleMove', 'Green dragon'],
  0xF7EA: ['Dragon', 'A dragon: chase, bite, eat, die by the sword'],
  0xF8A5: ['BatMove', 'The bat: flap, fly, swap what it carries'],
  0xF93C: ['GatesMove', 'Castle gates: open or close when their key touches them'],
  0xF9B3: ['MagnetPull', 'The magnet pulls objects'],
  0xF9E7: ['LightMove', 'In the dark mazes the light follows the player'],
  0xFA23: ['Sound', 'Sound effects'],
  0xFF32: ['RoomByGame', 'Rooms that depend on the game number'],
  0xFF44: ['Objects', 'The object table: 9 bytes per object'],
  0xFE1B: ['Rooms', 'The room table: 9 bytes per room'],
};

// Code the tracer can't reach on its own (jump tables, pushed return addresses)
const code = [
];

module.exports = { game, ram, labels, code };
