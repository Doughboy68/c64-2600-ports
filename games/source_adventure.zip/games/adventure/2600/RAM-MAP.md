# Adventure (2600) RAM map

The 2600 has 128 bytes of RAM at `$80-$FF`. This is what the game keeps in each byte, worked out by reading
the code and watching memory in `tools/vcs.js`. A `?` marks something not fully confirmed yet.

Generated from `symbols.js` by `tools/disasm.js`; edit that file, not this one.

| Address | Name | Bytes | What it holds |
|---|---|---|---|
| `$80-$81` | PFPtr | 2 | The room's playfield: 3 bytes (PF0, PF1, PF2) per row, 7 rows |
| `$82-$83` | P0Ptr | 2 | Player 0 object's shape (bytes until a zero) |
| `$84-$85` | P1Ptr | 2 | Player 1 object's shape |
| `$86` | P0X | 1 | Player 0 object X (positioned by HPos) |
| `$87` | P0Y | 1 | Player 0 object Y: the kernel starts its shape when its line counter drops below this |
| `$88` | P1X | 1 | Player 1 object X |
| `$89` | P1Y | 1 | Player 1 object Y |
| `$8A` | Room | 1 | The room the player (the square, the ball) is in; 0 = the game number screen |
| `$8B` | BallX | 1 | The player's X |
| `$8C` | BallY | 1 | The player's Y |
| `$8D` | BallTop | 1 | Kernel: BallY - 4; the ball shows for the 4 line pairs from here down |
| `$8E` | KLine | 1 | Kernel: line pair counter, $68 down to 8 (left at 7) |
| `$8F` | PFIndex | 1 | Kernel: offset of the next playfield row |
| `$90` | P0Row | 1 | Kernel: player 0 shape row |
| `$91` | P1Row | 1 | Kernel: player 1 shape row |
| `$92` | LastSwitches | 1 | SWCHB last pass (reset and select act on a press) |
| `$93-$94` | Ptr | 2 | Scratch pointer (room or object table entries, object state) |
| `$95` | Obj0 | 1 | Object shown as player 0 this frame |
| `$96` | Obj1 | 1 | Object shown as player 1 this frame (the light and the bridge are always put here) |
| `$97` | Touched | 1 | Scratch: the object the player touched or that touched another |
| `$98` | Unused98 | 1 | Set to $FF when looking for an object to pick up? |
| `$99` | Joystick | 1 | Joystick (SWCHA) for the player's move; $FF while being pushed back |
| `$9A` | Temp | 1 | Scratch |
| `$9B` | Temp2 | 1 | Scratch: directions to move (joystick bits) |
| `$9C` | ScanStart | 1 | Flicker: object number where the search for this frame's two objects starts |
| `$9D` | Carried | 1 | Object the player carries; $A2 none |
| `$9E` | CarryDX | 1 | Carried object X - player X |
| `$9F` | CarryDY | 1 | Carried object Y - player Y |
| `$A0` | DragonObj | 1 | Scratch: the dragon being moved |
| `$A1-$A3` | Dot | 3 | The dot: room, X, Y |
| `$A4-$A8` | Rhindle | 5 | Red dragon: room, X, Y, move counter?, state (0 alive, 1 dead, 2 eating, 3 roaring?) |
| `$A9-$AD` | Yorgle | 5 | Yellow dragon: room, X, Y, move counter?, state |
| `$AE-$B2` | Grundle | 5 | Green dragon: room, X, Y, move counter?, state |
| `$B3-$B5` | Magnet | 3 | Magnet: room, X, Y |
| `$B6-$B8` | Sword | 3 | Sword: room, X, Y |
| `$B9-$BB` | Chalice | 3 | Chalice: room, X, Y |
| `$BC-$BE` | Bridge | 3 | Bridge: room, X, Y |
| `$BF-$C1` | YellowKey | 3 | Gold key: room, X, Y |
| `$C2-$C4` | WhiteKey | 3 | White key: room, X, Y |
| `$C5-$C7` | BlackKey | 3 | Black key: room, X, Y |
| `$C8-$CA` | Gates | 3 | The three castle gates (gold, white, black): open/close state, 1 = open?, $1C = closed |
| `$CB-$CD` | Bat | 3 | Bat: room, X, Y |
| `$CE` | BatDir | 1 | Bat: direction it flies (joystick bits)? |
| `$CF` | BatFlap | 1 | Bat: wing animation, 0-7 |
| `$D0` | BatCarries | 1 | Bat: the object it carries |
| `$D1` | BatTimer | 1 | Bat: frames since it grabbed something (0 = looking) |
| `$D2-$D3` | ListPtr | 2 | Scratch pointer to an object list (what a dragon or the bat goes for or flees) |
| `$D4` | Speed | 1 | Scratch: steps to move |
| `$D5` | MoverState | 1 | Scratch: the moving creature's state address |
| `$D6` | Ignore | 1 | Scratch: object the creature ignores (the one it carries) |
| `$D7` | FireHistory | 1 | Fire button over the last frames (bit 7 newest) |
| `$D8` | Temp3 | 1 | Scratch |
| `$D9-$DB` | Light | 3 | The dark mazes' light around the player: room, X, Y |
| `$DC` | AnimState | 1 | Scratch: animation state when picking an object's shape |
| `$DD` | GameLevel | 1 | Game 1-3 as 0, 2, 4 |
| `$DE` | GameOver | 1 | $FF: the chalice is home, game won (or before the first game) |
| `$DF` | SoundTimer | 1 | Sound effect: frames left |
| `$E0` | SoundEffect | 1 | Sound effect: 0 won, 1 picked up?, 2 dragon dies?, 3 eaten?, 4 put down?, 5 roar? |
| `$E1` | ListIndex | 1 | Scratch: index into an object list |
| `$E2` | SavedRoom | 1 | The player's room, X, Y before this move (put back when blocked) |
| `$E3` | SavedX | 1 |  |
| `$E4` | SavedY | 1 |  |
| `$E5` | FrameCount | 1 | Frame counter (also the random number source, and the chalice's colour) |
| `$E6` | IdleCount | 1 | Counts up while nothing is pressed; bit 7 set: attract mode colours |

## Routines

| Address | Name | What it does |
|---|---|---|
| `$F008` | Kernel | Draw the picture: position the objects, then 2 lines per pass from line pair $68 down |
| `$F0D2` | HPos | Position object X at horizontal position A (coarse wait, fine motion) |
| `$F0EC` | WaitVSync | Wait for the timer, then vertical sync; set the timer for the vertical blank |
| `$F10F` | SetupFrame | Room colours and playfield, pick this frame's two objects, their shapes and colours |
| `$F235` | PickObjects | Flicker: the next two objects (from ScanStart on) in the player's room |
| `$F271` | RoomEntry | Ptr = the room table entry for room A |
| `$F2A1` | FindShape | Y = offset of the shape list entry for animation state AnimState |
| `$F2B2` | IdleTimer | Frame counter; attract mode colours after a while without input |
| `$F2D3` | Colour | Colour A (odd: read from RAM $80 + A/2), with the attract mode colour cycle |
| `$F2E4` | ObjEntry | Ptr = the state address of object X |
| `$F2EF` | PowerOn | Power on: clear the TIA and RAM, position the walls, game select screen |
| `$F306` | MainLoop | Three frames per pass |
| `$F365` | GameWon | After the chalice is home: just the picture (and the switches) |
| `$F371` | PlaceWalls | Position the thin walls (missiles) at 13 and 150 |
| `$F384` | Switches | Game Reset (start, or back to the gold castle) and Game Select |
| `$F3D3` | NewGame | Game select screen: objects to their places for the game number |
| `$F412` | RandomPlaces | Game 3: objects to random rooms |
| `$F4C2` | MovePlayer | Player: blocked by walls and objects (the bridge lets it through), joystick |
| `$F556` | PickUp | Fire drops; touching an object picks it up |
| `$F5D4` | MoveCarried | The carried object moves with the player |
| `$F5FF` | MoveObject | Move object X by the joystick bits in A, Y times; room changes at the edges |
| `$F6AC` | Step | Step object X by the direction bits in A, Y times |
| `$F6D5` | RoomForGame | Room numbers $80 and up depend on the game number |
| `$F6E9` | TouchesBall | Is object A (shown this frame) touching the player? |
| `$F6FE` | TouchesOther | Object X touching the other object shown this frame: that object, else $A2 |
| `$F715` | Seek | A creature chooses what to go for or flee from its list, and moves |
| `$F728` | SeekList | Find the first object in the list in the creature's room |
| `$F757` | Direction | Joystick-style direction bits from the creature towards the object |
| `$F795` | RhindleMove | Red dragon |
| `$F7B0` | YorgleMove | Yellow dragon |
| `$F7CB` | GrundleMove | Green dragon |
| `$F7EA` | Dragon | A dragon: chase, bite, eat, die by the sword |
| `$F8A5` | BatMove | The bat: flap, fly, swap what it carries |
| `$F93C` | GatesMove | Castle gates: open or close when their key touches them |
| `$F9B3` | MagnetPull | The magnet pulls objects |
| `$F9E7` | LightMove | In the dark mazes the light follows the player |
| `$FA23` | Sound | Sound effects |
| `$FE1B` | Rooms | The room table: 9 bytes per room |
| `$FF32` | RoomByGame | Rooms that depend on the game number |
| `$FF44` | Objects | The object table: 9 bytes per object |
