@echo off
rem Build Adventure:
rem   build\adventure.a26       the 2600 ROM rebuilt from source (checked against the original)
rem   build\adventure-V.prg   the Commodore 64 version
rem   build\adventure-V.d64   the C64 version on a disk image
rem The original ROM (or its .zip) must be in roms_port\ (found by MD5, any file name).
rem (V: the version in the BASIC listing; file names at most 16 characters: ..\..\tools\buildname.js)
cd /d "%~dp0"
set TASS=..\..\tools\64tass\64tass.exe
set MD5=157bddb7192754a45372be196797f284
if not exist build mkdir build
if not exist 2600\adventure.asm node ..\..\tools\disasm.js . || exit /b 1
set NAME=
for /f %%n in ('node ..\..\tools\buildname.js . adventure') do set NAME=%%n
if "%NAME%"=="" (echo no build name: see tools\buildname.js & exit /b 1)

node ..\..\tools\rom.js %MD5% build\original.a26 >nul || exit /b 1
%TASS% -q --nostart -o build\adventure.a26 2600\adventure.asm || exit /b 1
fc /b build\original.a26 build\adventure.a26 >nul && (echo OK: build\adventure.a26 matches the original ROM) || (echo DIFFERENT: build differs from the original ROM & exit /b 1)

node tools\mkc64tables.js >nul || exit /b 1
del /q build\adventure-*.prg build\adventure-*.d64 build\adventure-*.lst build\adventure-c64.* 2>nul
%TASS% -q -C -a -o build\%NAME%.prg -L build\%NAME%.lst c64\main.asm || exit /b 1
echo OK: build\%NAME%.prg


where c1541 >nul 2>&1 || (echo c1541 not found, skipping the disk image & exit /b 0)
if exist build\%NAME%.d64 del build\%NAME%.d64
c1541 -format "adventure,ad" d64 build\%NAME%.d64 -write build\%NAME%.prg "adventure" >nul || exit /b 1
echo OK: build\%NAME%.d64
