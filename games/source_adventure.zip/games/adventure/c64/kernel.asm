; ================================================================= kernel
; What the 2600's kernel would have drawn, and the collisions the game reads afterwards,
; worked out the way tools/model.js does (which matches the 2600 pixel for pixel).
;
; The kernel draws 97 passes of two lines, k = 0..96 (its line pair counter v = $68 - k):
; pass k's player graphics, ball enable and playfield show on lines 2k+1 and 2k+2 (pass 96
; only on line 193, which the 2600 blanks after the first 4 pixels). Line L0 shows the
; ball enable the previous picture left, and so do the lines between the collision clear
; and L0, with the previous picture's last playfield row.
;   player 0: drawn on the passes where v - P0Y is negative, from its first shape row on,
;             one row a pass until a zero byte (0 on the other passes)
;   player 1: the same from pass 1 on, but on the passes where v - P1Y is not negative the
;             kernel doesn't write GRP1 at all, so if they come after it started drawing,
;             the last row stays (the "smear")
;   ball:     on the passes where v is BallY-4 .. BallY-1
; After the picture the playfield's last row and the ball enable stay on every line until
; the next picture's collision clear; the players are off from pixel 37 of line 193 on.
;
; The game reads six collision bits: ball-playfield, ball-M0, ball-M1, ball-P0, ball-P1, P0-P1.

NPASS       = 97

; Called from KernelHook on our own stack; returns to whoever called Tick.
Kern:
        ; ---- positions and sizes
        ldx P0X
        lda PosP,x
        sta kP0x
        ldx P1X
        lda PosP,x
        sta kP1x
        ldx BallX
        lda PosP,x              ; (the ball is always a pixel left of a player: tools/mkhpos.js)
        sec
        sbc #1
        bcs +
        lda #159
+
        sta kBlx
        lda NUSIZ0
        jsr Quad
        sta kP0q
        lda NUSIZ1
        jsr Quad
        sta kP1q
        lda kP0q                ; (quad width players start a pixel later on the 2600)
        beq +
        ldx kP0x
        inx
        cpx #160
        bcc *+4
        ldx #0
        stx kP0x
+       lda kP1q
        beq +
        ldx kP1x
        inx
        cpx #160
        bcc *+4
        ldx #0
        stx kP1x
+
        lda CTRLPF
        lsr
        lsr
        lsr
        lsr
        and #3
        tax
        lda BallMask,x
        sta kBmask

        ; ---- player 0
        lda #0
        sta kP0n
        lda #$68
        sec
        sbc P0Y
        bpl _p0late
        sec
        sbc #$7f                ; passes it is drawn on, from pass 0
        ldx #0
        beq _p0act
_p0late clc                     ; drawn from pass d0 + 1 to the end
        adc #1
        cmp #NPASS
        bcs _p0none
        tax
        eor #$ff
        sec
        adc #NPASS
_p0act  stx kP0k
        jsr CapPasses
        sta tmp                 ; passes
        lda P0Ptr
        ldx P0Ptr+1
        jsr ShapeLen
        sta kP0len
        cmp tmp
        bcc +
        lda tmp
+       sta kP0n
_p0none lda kP0n
        sta P0Row

        ; ---- player 1
        lda #0
        sta kP1n
        sta kP1m
        lda #$67
        sec
        sbc P1Y
        bpl _p1late
        sec
        sbc #$7f
        ldx #1
        bne _p1act
_p1late clc
        adc #2
        cmp #NPASS
        bcs _p1none
        tax
        eor #$ff
        sec
        adc #NPASS
_p1act  stx kP1k
        jsr CapPasses
        sta tmp                 ; passes
        lda P1Ptr
        ldx P1Ptr+1
        jsr ShapeLen
        sta kP1len
        sta tmp2                ; shape rows
        cmp tmp
        bcc _p1short            ; the shape ends (a zero row) while it is drawn
        lda tmp                 ; stops drawing before the shape ends: its last row stays
        sta kP1n
        clc
        adc kP1k
        eor #$ff
        sec
        adc #NPASS
        sta kP1m                ; passes after it stopped
        beq _p1none
        ldy tmp
        dey
        lda (P1Ptr),y
        sta kP1sb
        jmp _p1none
_p1short
        sta kP1n
_p1none lda kP1n
        sta P1Row

        ; ---- ball
        lda BallY
        sec
        sbc #4
        sta BallTop
        lda #0
        sta kBn
        lda #$ff
        sta kBk
        ldx #3                  ; v = BallTop+3 down to BallTop (k up)
_bl     txa
        clc
        adc BallTop
        cmp #8
        bcc _bnext
        cmp #$69
        bcs _bnext
        eor #$ff                ; k = $68 - v
        sec
        adc #$68
        ldy kBn
        bne +
        sta kBk
+       inc kBn
_bnext  dex
        bpl _bl
        ldy #0                  ; the ball on the last pass stays on after the picture
        lda kBn
        beq +
        clc
        adc kBk
        cmp #NPASS
        bne +
        ldy #2
+       sty kNewEn

        ; ---- what the kernel leaves in RAM
        lda #7
        sta KLine
        lda #21
        sta PFIndex

        ; ---- collisions
        lda #0
        ldx #7
-       sta CXM0P,x
        dex
        bpl -
        jsr CollideBall
        jsr CollidePlayers

        ; ---- what the next picture starts from (this one's L0 ball for the display)
        lda kOldEn
        sta kL0En
        lda kNewEn
        sta kOldEn
        ldy #18                 ; the last playfield row
        lda (PFPtr),y
        sta LastPF
        iny
        lda (PFPtr),y
        sta LastPF+1
        iny
        lda (PFPtr),y
        sta LastPF+2
        rts

; NUSIZ A -> 1 for quad width, 0 for one copy; anything else is counted (testing aid)
Quad:
        and #7
        beq +
        cmp #7
        beq ++
        inc DbgOdd
        lda #0
+       rts
+       lda #1
        rts

; passes A from pass X on, at most to the last: A = min(A, NPASS - X)
CapPasses:
        sta tmp
        txa
        eor #$ff
        sec
        adc #NPASS
        cmp tmp
        bcc +
        lda tmp
+       rts

; rows of the shape at A/X (low/high) before its first zero byte, at most NPASS
ShapeLen:
        sta ptrC
        stx ptrC+1
        ldy #0
-       lda (ptrC),y
        beq +
        iny
        cpy #NPASS
        bne -
+       tya
        rts

; player graphics on pass X: G0 / G1 return A (0 = nothing), X kept
G0:     txa
        sec
        sbc kP0k
        bcc _none
        cmp kP0n
        bcs _none
        tay
        lda (P0Ptr),y
        rts
_none   lda #0
        rts
G1:     txa
        sec
        sbc kP1k
        bcc G0._none
        cmp kP1n
        bcs +
        tay
        lda (P1Ptr),y
        rts
+       sbc kP1n                ; (carry set) in the smear?
        cmp kP1m
        bcs G0._none
        lda kP1sb
        rts

; ---- the ball's collisions
CollideBall:
        lda kOldEn              ; is the ball on any line at all?
        ora kBn
        bne +
        rts
+
        ; with the playfield: before L0 the last picture's last row, on L0 row 0 (if the
        ; ball enable was left on), then the rows of its passes
        lda kOldEn
        beq _rows
        lda #<LastPF
        sta ptrB
        lda #>LastPF
        sta ptrB+1
        jsr BallOnPF
        bne _pfhit
        lda #0
        jsr BallOnRow
        bne _pfhit
_rows   lda kBn
        beq _pfdone
        ldx kBk
        jsr RowOf
        jsr BallOnRow
        bne _pfhit
        lda kBk                 ; the last pass may be a row further down
        clc
        adc kBn
        tax
        dex
        jsr RowOf
        jsr BallOnRow
        beq _pfdone
_pfhit  lda #$80
        sta CXBLPF
_pfdone
        ; with the thin walls (on every line)
        lda ENAM0
        and #2
        beq +
        lda NUSIZ0
        ldx #POS_M0
        jsr BallOnMissile
        bcc +
        lda #$40
        sta CXM0FB
+       lda ENAM1
        and #2
        beq +
        lda NUSIZ1
        ldx #POS_M1
        jsr BallOnMissile
        bcc +
        lda #$40
        sta CXM1FB
+
        ; with the players, on the ball's passes
        lda kBn
        beq _out
        lda kBlx
        sta wX
        ldx kBk
_pass   stx colK
        jsr G0
        beq +
        sta obG
        lda kP0x
        sta obX
        lda kP0q
        sta obQ
        jsr ObjBits
        and kBmask
        jsr Last37
        beq +
        lda #$40
        sta CXP0FB
+       ldx colK
        jsr G1
        beq +
        sta obG
        lda kP1x
        sta obX
        lda kP1q
        sta obQ
        jsr ObjBits
        and kBmask
        jsr Last37
        beq +
        lda #$40
        sta CXP1FB
+       ldx colK
        inx
        txa
        sec
        sbc kBk
        cmp kBn
        bcc _pass
_out    rts

; playfield row of pass X -> A (0-6)
RowOf:  txa
        sec
        sbc #8
        bcs +
        lda #0
        rts
+       lsr
        lsr
        lsr
        lsr
        clc
        adc #1
        rts

; does the ball touch playfield row A of the room (Z clear: yes)?
BallOnRow:
        sta tmp
        asl
        adc tmp                 ; 3 * row
        clc
        adc PFPtr
        sta ptrB
        lda PFPtr+1
        adc #0
        sta ptrB+1
; ... or the playfield bytes at ptrB (PF0, PF1, PF2)?
BallOnPF:
        lda kBmask
        sta tmp2
        ldx kBlx
_px     asl tmp2                ; for each pixel of the ball
        bcc _no
        txa
        lsr
        lsr                     ; its cell, 0-39
        cmp #20
        bcc _left
        sbc #20                 ; right half: repeated, or reflected (19 - (cell - 20))
        sta tmp3
        lda CTRLPF
        lsr
        lda tmp3
        bcc _left
        eor #$ff
        adc #19                 ; (carry set)
_left   tay
        lda PFRegOf,y
        sty tmp3
        tay
        lda (ptrB),y
        ldy tmp3
        and PFBitOf,y
        bne _yes
_no     inx
        cpx #160
        bcc +
        ldx #0
+       lda tmp2
        bne _px
        lda #0
_yes    rts

; does the ball touch the missile at pixel X, NUSIZ A? (carry set: yes)
BallOnMissile:
        stx tmp3
        lsr
        lsr
        lsr
        lsr
        and #3
        tay
        lda MissileW,y
        sta tmp                 ; width
        lda kBmask
        sta tmp2
        ldx kBlx
_px     asl tmp2
        bcc _next
        txa                     ; (pixel - missile) mod 160 < width?
        sec
        sbc tmp3
        bcs +
        adc #160
+       cmp tmp
        bcc _hit
_next   inx
        cpx #160
        bcc +
        ldx #0
+       lda tmp2
        bne _px
        clc
        rts
_hit    sec
        rts

; on pass 96 (line 193) the players are only there left of pixel 37: A &= that for window wX
Last37:
        beq _z
        ldx colK
        cpx #NPASS-1
        bne _nz
        sta tmp
        lda #0
        sta tmp2
        ldx wX
        ldy #8
-       asl tmp2
        cpx #37
        bcs +
        inc tmp2
+       inx
        cpx #160
        bcc +
        ldx #0
+       dey
        bne -
        lda tmp
        and tmp2
        rts
_nz     lda #1
_z      rts

; ---- the players' collision with each other, on the passes both are drawn
CollidePlayers:
        lda kP0n
        beq _rts
        lda kP1n
        ora kP1m
        bne +
_rts    rts
+
        ldx kP0k                ; from the later start ...
        cpx kP1k
        bcs +
        ldx kP1k
+       stx colK
        lda kP0k                ; ... to the earlier end
        clc
        adc kP0n
        sta pEnd
        lda kP1k
        clc
        adc kP1n
        clc
        adc kP1m
        cmp pEnd
        bcs +
        sta pEnd
+
_pass   ldx colK
        cpx pEnd
        bcs _out
        jsr G0
        beq _nextp
        sta pG0
        jsr G1
        beq _nextp
        sta pG1
        lda kP0q                ; a window of 8 pixels at the narrower one (both quad: 4 windows)
        beq _w0
        lda kP1q
        beq _w1
        lda #4
        sta pWin
        lda kP0x
        sta wX
-       jsr _both
        bne _hit
        lda wX
        clc
        adc #8
        cmp #160
        bcc +
        sbc #160
+       sta wX
        dec pWin
        bne -
        beq _nextp
_w0     lda kP0x                ; player 0 one copy: its row is its pixels
        sta wX
        lda pG1
        sta obG
        lda kP1x
        sta obX
        lda kP1q
        sta obQ
        jsr ObjBits
        and pG0
        jmp _test
_w1     lda kP1x
        sta wX
        lda pG0
        sta obG
        lda kP0x
        sta obX
        lda kP0q
        sta obQ
        jsr ObjBits
        and pG1
_test   jsr Last37
        bne _hit
_nextp  inc colK
        jmp _pass
_hit    lda #$80
        sta CXPPMM
_out    rts
_both   lda pG0
        sta obG
        lda kP0x
        sta obX
        lda #1
        sta obQ
        jsr ObjBits
        sta pM0
        lda pG1
        sta obG
        lda kP1x
        sta obX
        jsr ObjBits
        and pM0
        jmp Last37

; ObjBits: the pixels of a player row obG (at pixel obX, quad width if obQ) in the 8-pixel
; window from pixel wX: A, bit 7 = pixel wX.
ObjBits:
        lda wX                  ; d = (wX - obX) mod 160
        sec
        sbc obX
        bcs +
        adc #160
+       ldx obQ
        cmp ObjSpan,x
        bcc _inside
        cmp #160-7
        bcs _before
        lda #0
        rts
_before eor #$ff                ; the window starts 160 - d pixels before the object
        sec
        adc #160
        sta tmp
        lda #0
        jsr _pix
        ldx tmp
-       lsr
        dex
        bne -
        rts
_inside
; pixels A.. of the row, 8 of them
_pix    ldx obQ
        bne _quad
        tax
        lda obG
        cpx #0
        beq +
-       asl
        dex
        bne -
+       rts
_quad   sta tmp2                ; the row as 32 pixels: qe+0..3 (qe+4 = 0)
        lda obG
        lsr
        lsr
        lsr
        lsr
        lsr
        lsr
        tax
        lda Quad2,x
        sta qe
        lda obG
        lsr
        lsr
        lsr
        lsr
        and #3
        tax
        lda Quad2,x
        sta qe+1
        lda obG
        lsr
        lsr
        and #3
        tax
        lda Quad2,x
        sta qe+2
        lda obG
        and #3
        tax
        lda Quad2,x
        sta qe+3
        lda #0
        sta qe+4
        lda tmp2                ; byte (A >> 3), shifted left by (A & 7) with the next one's bits
        lsr
        lsr
        lsr
        tax
        lda qe+1,x
        sta tmp3
        lda tmp2
        and #7
        tay
        lda qe,x
        cpy #0
        beq +
-       asl tmp3
        rol
        dey
        bne -
+       rts

ObjSpan:    .byte 8, 32
BallMask:   .byte $80, $c0, $f0, $ff
MissileW:   .byte 1, 2, 4, 8
; the playfield register and bit of each cell 0-19 (PF0 bits 4-7, PF1 bits 7-0, PF2 bits 0-7)
PFRegOf:    .byte 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2
PFBitOf:    .byte $10, $20, $40, $80, $80, $40, $20, $10, $08, $04, $02, $01
            .byte $01, $02, $04, $08, $10, $20, $40, $80
