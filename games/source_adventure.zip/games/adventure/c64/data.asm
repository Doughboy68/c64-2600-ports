; =================================================================== sound
; The game's TIA sound registers, translated to SID voices 1 and 2 once a frame.
UpdateSound:
        ldx #0
        jsr _chan
        ldx #1
_chan   lda AUDV0,x
        and #15
        sta v0
        lda AUDC0,x
        and #15
        sta v1
        lda AUDF0,x
        and #31
        sta v2
        cmp SndLast+4,x
        bne +
        lda v1
        cmp SndLast+2,x
        bne +
        lda v0
        cmp SndLast,x
        bne +
        rts
+       ldy SidVoice,x
        lda v0
        beq _off
        ldy v1
        lda SidWave,y
        beq _off2
        sta tmp                 ; waveform
        lda v1                  ; frequency index = AUDC * 32 + AUDF
        lsr
        lsr
        lsr
        sta ptrA+1
        lda v1
        asl
        asl
        asl
        asl
        asl
        ora v2
        clc
        adc FreqTab
        sta ptrA
        lda ptrA+1
        adc FreqTab+1
        sta ptrA+1
        ldy SidVoice,x
        sty tmp2
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d400,y
        inc ptrA+1
        inc ptrA+1
        ldy #0
        lda (ptrA),y
        ldy tmp2
        sta $d401,y
        lda #0
        sta $d402,y
        sta $d405,y
        lda #8
        sta $d403,y
        lda v0                  ; volume becomes the sustain level
        asl
        asl
        asl
        asl
        sta $d406,y
        lda v0                  ; retrigger only when volume or waveform changes
        cmp SndLast,x
        bne +
        lda v1
        cmp SndLast+2,x
        beq _save
+       lda tmp
        sta $d404,y
        ora #1
        sta $d404,y
        jmp _save
_off2   ldy SidVoice,x
_off    lda #0
        sta $d404,y
_save   lda v0
        sta SndLast,x
        lda v1
        sta SndLast+2,x
        lda v2
        sta SndLast+4,x
        rts


; ================================================================== tables
Bit:        .byte $01, $02, $04, $08, $10, $20, $40, $80
SidVoice:   .byte 0, 7
RowBit:     .byte $80, $40, $20, $10, $08, $04, $02, $01
ColBit:     .byte $08, $04, $02, $01
; a column mask (bit 3 = multicolour pixel 0) -> those pixels in colour 01
ColPat:     .for m = 0, m < 16, m += 1
            .byte ((m & 8) != 0) * $40 | ((m & 4) != 0) * $10 | ((m & 2) != 0) * $04 | ((m & 1) != 0) * $01
            .next
; the playfield row each character row shows (row 0: its "top" characters)
TmplOfRow:  .byte 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6
ScrRowLo:   .for r = 0, r < 25, r += 1
            .byte <(SCREEN0 + 40 * r)
            .next
ScrRowHi:   .for r = 0, r < 25, r += 1
            .byte >(SCREEN0 + 40 * r)
            .next

        .include "tables.inc"

; ------------------------------------------------------- variables (RAM)
DbgSWCHA:   .byte $ff           ; AND masks applied to the inputs (testing aid)
DbgINPT4:   .byte $ff
DbgSWCHB:   .byte $ff
DbgBorder:  .byte 0             ; non-zero: colour the border while drawing / running the game
DbgLoops:   .word 0             ; main loop passes
DbgLate:    .word 0             ; ... that found more than one frame gone by
DbgTops:    .byte 0             ; frame tops the interrupt has done
DbgRepeat:  .byte 0             ; frames shown again (no new one ready at the frame end)
DbgSprLate: .byte 0             ; sprite reuses written too late
DbgDrop:    .byte 0             ; sprites (or segments) that didn't fit
DbgOdd:     .byte 0             ; NUSIZ other than one copy or quad width
DbgRMax:    .word 0             ; the most cycles one pass spent drawing,
DbgTMax:    .word 0             ; ... running the game,
DbgPMax:    .word 0             ; ... in all
dbgT0:      .word 0
dbgT1:      .word 0
dbgNow:     .word 0
dbgTmp:     .word 0
FreqTab:    .word SidFreqLo     ; PAL or NTSC frequency tables
PowerReq:   .byte 0             ; F2 pressed: power off and on before the next tick
PrevF2:     .byte 0
f2now:      .byte 0
PrevFire:   .byte $80
FireStart:  .byte 0             ; frames to hold Game Reset down (fire on the number screen)
Keys:       .fill 8, $ff
PrevKeys:   .byte $ff
SndLast:    .fill 6, $ff

CurKey:     .fill 5, $ff        ; ... that TmplLo/TmplHi are set for
ScrKey:     .fill 10, $ff       ; ... that each buffer's screen holds
Flicker:    .byte 1             ; 1: objects take turns as on the 2600; 0: all shown (key F)
PrevKeyF:   .byte $ff

; staged frames (two buffers): sprite values for the frame top ...
StX:        .fill 16
StY:        .fill 16
StPtr:      .fill 16, BLK_BLANK
StCol:      .fill 16
StMsb:      .fill 2
StEn:       .fill 2
StYexp:     .fill 2
StPri:      .fill 2
StBg:       .fill 2
StC1:       .fill 2
StC2:       .fill 2
StD018:     .byte (SCREEN0 - VICBANK) / $400 * 16 | (CHARS0 - VICBANK) / $800 * 2
            .byte (SCREEN1 - VICBANK) / $400 * 16 | (CHARS1 - VICBANK) / $800 * 2

; ------------------------------- variables not in the program file ($C000-: Start clears them)
        .virtual BSS
; kernel
LastPF:     .fill 3, 0          ; the playfield the last picture ended with
pG0:        .byte 0
pG1:        .byte 0
pWin:       .byte 0
pM0:        .byte 0
pEnd:       .byte 0

; render
rbuf:       .byte 0             ; the buffer being drawn, and 16 * it, NBLK * it
rbuf16:     .byte 0
rbufBlk:    .byte 0
key:        .fill 5             ; the room as characters: playfield (2), CTRLPF & 5, ENAM0, ENAM1
TmplLo:     .fill 7             ; the current room's templates, each playfield row
TmplHi:     .fill 7
tRoom:      .byte 0
tCells:     .fill 20
pfch:       .byte 0
pfb:        .fill 3
tRow:       .byte 0
LightRows:  .fill 2, 0          ; the light's cells on each buffer's screen: rows (0 = none),
LightR0:    .fill 2             ; first row, first column, columns
LightC0:    .fill 2
LightCols:  .fill 2
lrN:        .byte 0
lrR:        .byte 0
lrC0:       .byte 0
lrNC:       .byte 0
lrC:        .byte 0
lrK:        .byte 0
lrLa:       .byte 0
lrLb:       .byte 0
lrRows:     .byte 0
lrRow:      .byte 0
LightLa:    .fill 2
LightLb:    .fill 2
LightX:     .fill 2
lrM:        .fill 3             ; row masks: first row, the ones between, last row
lrCM:       .fill 3             ; column masks: first, between, last (right after lrM: LmKey)
lrS:        .byte 0
lrCh:       .fill 3
lrPat:      .byte 0
LChar:      .fill 9             ; the light's characters, by row kind * 3 + column kind
sprN:       .byte 0             ; sprites: the next free one, and the registers being built
sprEn:      .byte 0
sprMsb:     .byte 0
sprYexp:    .byte 0
sprPri:     .byte 0
p0Count:    .byte 0
ruN:        .byte 0
blkN:       .byte 0
schIdx:     .byte 0
bestI:      .byte 0
soR:        .byte 0             ; the object being added (see AddP0)
soN:        .byte 0
soK:        .byte 0
soSB:       .byte 0
soPtr:      .word 0
soQ:        .byte 0
soX:        .byte 0
soCol:      .byte 0
soCol1:     .byte 0
soCode:     .byte 0
soXl:       .byte 0
soXh:       .byte 0
soSeg:      .byte 0
soRow:      .byte 0
soSprA:     .byte 0
soSprB:     .byte 0
soSpr:      .byte 0
soC:        .byte 0
soY:        .byte 0
soBlk:      .byte 0
bk:         .fill 7
soLen:      .byte 0
exObj:      .byte 0             ; flicker off: the object being added, its X, Y, colour; ball sprites to come
exX:        .byte 0
exY:        .byte 0
exCol:      .byte 0
exBall:     .byte 0
lgOn:       .byte 0             ; the light this frame: on?, first pass, passes, pixel
lgK:        .byte 0
lgN:        .byte 0
lgX:        .byte 0
lgCol:      .byte 0
ShownRoom:  .byte 0             ; the room the game set the picture up for (SaveRoom)
DbgSkip:    .byte 0             ; (testing aid) flicker off: objects that didn't fit
soPx:       .byte 0
irqSave:    .byte 0
DbgWrap:    .byte 0             ; (testing aid) wrapping columns not shown (quad left part at 137-147)
soM:        .byte 0
soStat:     .byte 0
nStatic:    .byte 0             ; shapes made at start-up: pointer, quad, first block, segments
ShLo:       .fill NSTATIC
ShHi:       .fill NSTATIC
ShQ:        .fill NSTATIC
ShBlk:      .fill NSTATIC
ShSeg:      .fill NSTATIC
ShLen:      .fill NSTATIC
isObj:      .word 0
isY:        .byte 0
isBlk:      .byte 0
DbgStatic:  .byte 0             ; (testing aid) segments drawn from start-up blocks
BlkUsed:    .word 0             ; object blocks used in this frame
BlkNext:    .fill 2, 0          ; each buffer: where to look for a free block next

RoomKeys:   .fill 5 * (NROOMS + 1)  ; the key of each room's templates (InitVideo: $FF)
BlkKey:     .fill 8 * 2 * NBLK      ; what each sprite block holds (InitVideo: $FF)
; ... sprite reuses, and the schedule
RuSpr:      .fill 2 * NSCHED
RuPtr:      .fill 2 * NSCHED
RuY:        .fill 2 * NSCHED
RuRas:      .fill 2 * NSCHED
SchedRas:   .fill 2 * NSCHED
SchedType:  .fill 2 * NSCHED
SchedArg:   .fill 2 * NSCHED
LmKey:      .fill 12              ; the light masks (rows, columns) each buffer's characters have
lcSkip:     .byte 0
filled:     .byte 0
rsN:        .byte 0             ; RestoreLight's own
rsR:        .byte 0
rsC0:       .byte 0
rsNC:       .byte 0
LastLChar:  .fill 18             ; the light characters each buffer's cells have             ; this frame filled the screen for a new room
BSSEND:
        .endv
        .cerror BSSEND > $d000, "variables overflow"

; ======================================================= the 2600 program
; The original ROM, copied to $F000 at start-up, with these changes:
;   $F008  JMP KernelHook        stop where the 2600 would draw the picture (Kernel)
;   $F0EC  RTS                   WaitVSync: no waiting (and its VBLANK/VSYNC writes would
;                                remap C64 memory: $00/$01 are the 6510's port)
;   $F111  JSR SaveRoom          (was JSR RoomEntry) note the room the picture is set up for
;   $F2EF  NOP                   (was SEI: our raster interrupt keeps running)
ROM = "../build/original.a26"     ; extracted from roms_port by build.cmd
GameImage:
        .binary ROM, $0000, $0008
        jmp KernelHook
        .binary ROM, $000b, $00ec-$000b
        rts
        .binary ROM, $00ed, $0111-$00ed
        jsr SaveRoom
        .binary ROM, $0114, $02ef-$0114
        nop
        .binary ROM, $02f0, $1000-$02f0
        .cerror * - GameImage != $1000, "the 2600 image must be 4K"
