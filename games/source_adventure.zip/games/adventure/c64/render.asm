; ================================================================= render
; Draws the picture the last tick worked out (kernel.asm) into the buffer the display isn't
; using: the screen and character set, sprite blocks, colours and the raster schedule.
;
; Characters: one 2600 playfield block = one character (4 multicolour pixels, 8 lines).
; Colour 01 ($D022) is the playfield, 10 ($D023) the thin wall, both behind the sprites
; except where the wall must cover player 1 and the ball (their sprites go behind 10).
; Where the playfield is in front (the dark mazes: CTRLPF bit 2) it uses 10 and every sprite
; goes behind it; 01 is then the light around the player (player 1, drawn in the characters).
; Colour 11 (colour RAM, black) is only used for character row 0's lines above L0.
;
; Sprites (all double width, so one sprite pixel = one 2600 pixel): each object takes one
; column (two for quad width), double height, in segments of 21 rows; a segment after the
; second reuses the first's sprite (raster interrupt). The ball has one sprite for its
; passes and one for line L0. Sprite numbers follow the 2600's priorities: player 0, player 1,
; the ball (the ball first where the playfield is in front).

Render:
        lda curBuf
        eor #1
        sta rbuf
        asl
        asl
        asl
        sta bufOfs              ; 8 * buffer
        asl
        sta rbuf16              ; 16 * buffer
        lda rbuf
        beq +
        lda #NBLK
+       sta rbufBlk             ; buffer * NBLK
        jsr LightLayout
        jsr Colours
        jsr Screen
        jsr Sprites
        lda #1
        sta pending
        rts

; ---- colours for this buffer
Colours:
        ldy rbuf
        lda COLUBK
        lsr
        tax
        lda ColorMap,x
        sta StBg,y
        lda CTRLPF
        and #4
        beq _norm
        lda lgCol               ; playfield in front: 01 is the light, 10 the playfield
        lsr
        tax
        lda ColorMap,x
        sta StC1,y
        lda COLUPF
        lsr
        tax
        lda ColorMap,x
        sta StC2,y
        rts
_norm   lda COLUPF
        lsr
        tax
        lda ColorMap,x
        sta StC1,y
        lda ENAM0               ; the thin wall's colour: M0's (player 0's), else M1's
        and #2
        bne +
        lda COLUP1
        jmp ++
+       lda COLUP0
+       lsr
        tax
        lda ColorMap,x
        sta StC2,y
        rts

; ================================================================ screen
; The characters of each room's 7 playfield rows (40 cells each) are made at start-up for every
; room in the game's room table (InitRooms), 280 bytes a room from ROOMTMPL. A room is known by
; its key: playfield pointer, CTRLPF & 5 (reflection, playfield in front) and its thin walls
; (ENAM0, ENAM1). Slot NROOMS is for anything else (made when needed; never seen so far).
Screen:
        lda #0
        sta filled
        lda PFPtr               ; this picture's room
        sta key
        lda PFPtr+1
        sta key+1
        lda CTRLPF
        and #5
        sta key+2
        lda ENAM0
        and #2
        sta key+3
        lda ENAM1
        and #2
        sta key+4
        jsr FindRoom
        lda rbuf                ; this buffer's screen: is it this room?
        asl
        asl
        adc rbuf                ; 5 * buffer
        tay
        ldx #0
-       lda key,x
        cmp ScrKey,y
        bne _fill
        iny
        inx
        cpx #5
        bne -
        jmp DrawLight           ; yes: just the light, if it moved
_fill   lda rbuf
        asl
        asl
        adc rbuf
        tay
        ldx #0
-       lda key,x
        sta ScrKey,y
        iny
        inx
        cpx #5
        bne -
        ldx rbuf
        lda #0
        sta LightRows,x
        inc filled              ; (a new room: no time for flicker off's extra objects this frame)
        lda rbuf
        bne +
        jsr Fill0
        jmp DrawLight
+       jsr Fill1
        jmp DrawLight

; The templates for `key`: TmplLo/TmplHi (each row), and the screen fills' loads
FindRoom:
        ldx #4
-       lda key,x
        cmp CurKey,x
        bne +
        dex
        bpl -
        rts                     ; (the same room as last time)
+       ldx #4
-       lda key,x
        sta CurKey,x
        dex
        bpl -
        ldx #0                  ; which slot? (X slot, Y 5 * slot)
        ldy #0
_slot   lda RoomKeys,y
        cmp key
        bne _next
        lda RoomKeys+1,y
        cmp key+1
        bne _next
        lda RoomKeys+2,y
        cmp key+2
        bne _next
        lda RoomKeys+3,y
        cmp key+3
        bne _next
        lda RoomKeys+4,y
        cmp key+4
        beq _found
_next   tya
        clc
        adc #5
        tay
        inx
        cpx #NROOMS
        bne _slot
        ldx #0                  ; not a room of the table: make it in the spare slot
-       lda key,x
        sta RoomKeys,y
        iny
        inx
        cpx #5
        bne -
        lda key
        sta ptrC
        lda key+1
        sta ptrC+1
        ldx #NROOMS
        jsr BuildTemplates
        ldx #NROOMS
_found  stx tmp
        ldx tmp                 ; rows of slot X
        lda SlotLo,x
        sta ptrA
        lda SlotHi,x
        sta ptrA+1
        ldx #0
-       lda ptrA
        sta TmplLo,x
        clc
        adc #40
        sta ptrA
        lda ptrA+1
        sta TmplHi,x
        adc #0
        sta ptrA+1
        inx
        cpx #7
        bne -
        ldx #6                  ; the screen fills read from there
-       ldy FillOps,x
        lda TmplLo,x
        sta Fill0+1,y
        sta Fill1+1,y
        lda TmplHi,x
        sta Fill0+2,y
        sta Fill1+2,y
        dex
        bpl -
        rts

; Start-up: every room's templates (the game's room table: 9 bytes a room from $FE1B)
InitRooms:
        lda #0
        sta tRoom
        lda #<$fe1b
        sta ptrB
        lda #>$fe1b
        sta ptrB+1
_room   ldy #0                  ; its key
        lda (ptrB),y
        sta key
        sta ptrC
        iny
        lda (ptrB),y
        sta key+1
        sta ptrC+1
        ldy #4
        lda (ptrB),y
        tax
        and #5
        sta key+2
        txa                     ; (the game: ENAM0 = CTRL bit 7, ENAM1 = bit 6, as bit 1)
        rol
        rol
        rol
        and #2
        sta key+3
        txa
        lsr
        lsr
        lsr
        lsr
        lsr
        and #2
        sta key+4
        lda tRoom               ; RoomKeys + 5 * room
        asl
        asl
        adc tRoom
        tay
        ldx #0
-       lda key,x
        sta RoomKeys,y
        iny
        inx
        cpx #5
        bne -
        ldx tRoom
        jsr BuildTemplates
        lda ptrB
        clc
        adc #9
        sta ptrB
        bcc +
        inc ptrB+1
+       inc tRoom
        lda tRoom
        cmp #NROOMS
        bne _room
        ldx #4                  ; nothing shown yet
        lda #$ff
-       sta CurKey,x
        dex
        bpl -
        rts

; Templates of slot X from the playfield at ptrC and `key` (CTRLPF, walls): 7 rows of 40
BuildTemplates:
        lda SlotLo,x
        sta ptrA
        lda SlotHi,x
        sta ptrA+1
        lda #CH_PF1
        ldx key+2
        cpx #4
        bcc +
        lda #CH_PF2
+       sta pfch
        lda #0
        sta tRow
_row    lda tRow                ; the row's playfield bytes
        asl
        adc tRow
        tay
        lda (ptrC),y
        sta pfb
        iny
        lda (ptrC),y
        sta pfb+1
        iny
        lda (ptrC),y
        sta pfb+2
        ldx #0                  ; cells 0-19
_cell   ldy PFRegOf,x
        lda pfb,y
        and PFBitOf,x
        beq +
        lda pfch
+       sta tCells,x
        inx
        cpx #20
        bne _cell
        ldy #0
-       lda tCells,y            ; left half
        sta (ptrA),y
        iny
        cpy #20
        bne -
        lda key+2               ; right half: repeated or reflected
        lsr
        bcs _refl
        ldx #0
-       lda tCells,x
        sta (ptrA),y
        inx
        iny
        cpy #40
        bne -
        beq _walls
_refl   ldx #19
-       lda tCells,x
        sta (ptrA),y
        dex
        iny
        cpy #40
        bne -
_walls  lda key+3               ; the thin walls: M0 (pixels 11-12) in columns 2 and 3
        beq _m1
        ldy #2
        lda (ptrA),y
        cmp #1
        lda #CH_W2
        adc #0
        sta (ptrA),y
        iny
        lda (ptrA),y
        cmp #1
        lda #CH_W3
        adc #0
        sta (ptrA),y
_m1     lda key+4               ; M1 (pixels 148-149) in column 37
        beq _next
        ldy #37
        lda (ptrA),y
        cmp #1
        lda #CH_W37
        adc #0
        sta (ptrA),y
_next   lda ptrA                ; the next row
        clc
        adc #40
        sta ptrA
        bcc +
        inc ptrA+1
+       inc tRow
        lda tRow
        cmp #7
        beq +
        jmp _row
+       rts

; Fill the screen from the templates: character row 0 is playfield row 0's "top" characters,
; rows 1-2 playfield row 0, then four rows each, rows 23-24 playfield row 6. (The loads'
; addresses are set by FindRoom: FillOps.)
FillScreen .macro scr
        ldx #39
_loop   lda $ffff,x
        sta \scr+40,x
        sta \scr+80,x
        clc
        adc #CH_TOP
        sta \scr,x
        lda $ffff,x
        sta \scr+120,x
        sta \scr+160,x
        sta \scr+200,x
        sta \scr+240,x
        lda $ffff,x
        sta \scr+280,x
        sta \scr+320,x
        sta \scr+360,x
        sta \scr+400,x
        lda $ffff,x
        sta \scr+440,x
        sta \scr+480,x
        sta \scr+520,x
        sta \scr+560,x
        lda $ffff,x
        sta \scr+600,x
        sta \scr+640,x
        sta \scr+680,x
        sta \scr+720,x
        lda $ffff,x
        sta \scr+760,x
        sta \scr+800,x
        sta \scr+840,x
        sta \scr+880,x
        lda $ffff,x
        sta \scr+920,x
        sta \scr+960,x
        dex
        bmi +
        jmp _loop
+       rts
        .endm
Fill0   #FillScreen SCREEN0
Fill1   #FillScreen SCREEN1
; offsets of the seven loads from the start of a fill (+1: their address)
FillOps:    .byte 2, 17, 32, 47, 62, 77, 92
SlotLo:     .for s = 0, s <= NROOMS, s += 1
            .byte <(ROOMTMPL + 280 * s)
            .next
SlotHi:     .for s = 0, s <= NROOMS, s += 1
            .byte >(ROOMTMPL + 280 * s)
            .next

; ---- the dark mazes' light: player 1 when it is object 0 and the playfield is in front.
; A solid block 32 pixels wide (8 or 9 cells) from line 2k+1 down. Cells it covers fully are
; CH_PF1; its edges get characters of their own, CH_LIGHT + 3 * row kind + column kind (kinds:
; first, middle, last). Each buffer remembers where its screen has the light (LightRows,
; LightR0, LightC0, LightCols) and for what (LightLa/Lb/X: first line, last line, pixel).
RestoreLight:
        ldx rbuf
        lda LightRows,x
        bne +
        rts
+       sta rsN
        lda LightR0,x
        sta rsR
        lda LightC0,x
        sta rsC0
        lda LightCols,x
        sta rsNC
_rrow   ldx rsR                 ; screen row and its template row
        jsr ScrRowPtr
        lda TmplOfRow,x
        tax
        lda TmplLo,x
        sta ptrA
        lda TmplHi,x
        sta ptrA+1
        ldy rsC0
        ldx rsNC
-       lda (ptrA),y
        sta (ptrB),y
        iny
        cpy #40
        bcc +
        ldy #0
+       dex
        bne -
        inc rsR
        dec rsN
        bne _rrow
        ldx rbuf
        lda #0
        sta LightRows,x
        rts

; ptrB = screen row X of this buffer's screen
ScrRowPtr:
        lda ScrRowLo,x
        sta ptrB
        lda ScrRowHi,x
        ldy rbuf
        beq +
        clc
        adc #>(SCREEN1-SCREEN0)
+       sta ptrB+1
        rts

DrawLight:
        lda lgOn                ; (LightLayout) the light's passes, up to pass 95 (line 192)
        beq _no
        lda lgN
        beq _no
        clc
        adc lgK
        cmp #NPASS-1
        bcc +
        lda #NPASS-1
+       sec
        sbc lgK
        beq _no
        bcs _yes
_no     jmp RestoreLight
_yes    sta lrN                 ; passes
        lda lgK                ; lines 2k+1 .. 2(k+n)
        asl
        sta lrLa
        inc lrLa
        clc
        adc lrN
        adc lrN
        sta lrLb
        ldx rbuf                ; the same as this screen has already?
        lda LightRows,x
        beq _move
        lda LightLa,x
        cmp lrLa
        bne _move
        lda LightLb,x
        cmp lrLb
        bne _move
        lda LightX,x
        cmp lgX
        bne _move
        rts
_move
        ; rows: line L is in character row (L + 7) / 8, pixel row (L + 7) & 7
        lda lrLa
        clc
        adc #7
        tay
        lsr
        lsr
        lsr
        sta lrR
        tya
        and #7
        tay
        lda MaskFrom,y          ; first row: pixel rows from there on
        sta lrM
        lda lrLb
        clc
        adc #7
        tay
        lsr
        lsr
        lsr
        sec
        sbc lrR
        clc
        adc #1
        sta lrRows
        tya
        and #7
        tay
        lda MaskTo,y            ; last row: pixel rows up to there
        sta lrM+2
        lda #$ff
        sta lrM+1
        lda lrRows
        cmp #1
        bne +
        lda lrM                 ; just one row: both edges
        and lrM+2
        sta lrM
+       ; columns: from pixel X, 8 cells (9 if X isn't on a cell's edge)
        lda lgX
        lsr
        lsr
        sta lrC0
        lda lgX
        and #3
        sta lrS
        tay
        cmp #1
        lda #8
        adc #0
        sta lrNC
        lda #$0f
        sta lrCM+1
        lda ColFrom,y
        sta lrCM
        eor #$0f
        sta lrCM+2
        ; the characters for each kind of row and column (their shapes are only written
        ; when this buffer's set doesn't have them already)
        lda rbuf
        asl
        adc rbuf
        asl                     ; 6 * buffer
        tay
        lda #1
        sta lcSkip
        ldx #0
-       lda lrM,x
        cmp LmKey,y
        beq +
        sta LmKey,y
        lda #0
        sta lcSkip
+       iny
        inx
        cpx #6
        bne -
        ldx #8
-       txa
        jsr LightChar
        dex
        bpl -
        ; the same cells with the same characters as this screen has? Then that is all
        ldx rbuf
        lda lrLa
        sta LightLa,x
        lda lrLb
        sta LightLb,x
        lda lgX
        sta LightX,x
        lda LightRows,x
        beq _cells
        cmp lrRows
        bne _redo
        lda LightR0,x
        cmp lrR
        bne _redo
        lda LightC0,x
        cmp lrC0
        bne _redo
        lda LightCols,x
        cmp lrNC
        bne _redo
        lda rbuf                ; 9 * buffer
        asl
        asl
        asl
        adc rbuf
        tay
        ldx #0
-       lda LChar,x
        cmp LastLChar,y
        bne _redo
        iny
        inx
        cpx #9
        bne -
        rts
_redo   jsr RestoreLight
_cells  ldx rbuf
        lda lrR
        sta LightR0,x
        lda lrRows
        sta LightRows,x
        lda lrC0
        sta LightC0,x
        lda lrNC
        sta LightCols,x
        lda rbuf
        asl
        asl
        asl
        adc rbuf
        tay
        ldx #0
-       lda LChar,x
        sta LastLChar,y
        iny
        inx
        cpx #9
        bne -
        ; the cells (the playfield is in front: its cells stay)
        lda #0
        sta lrRow
_drow   ldx lrR
        jsr ScrRowPtr
        lda TmplOfRow,x
        tax
        lda TmplLo,x
        sta ptrA
        lda TmplHi,x
        sta ptrA+1
        ldx #0                  ; this row's kind: 0 first, 2 last, 1 between
        lda lrRow
        beq +
        ldx #6
        clc
        adc #1
        cmp lrRows
        beq +
        ldx #3
+       lda LChar,x
        sta lrCh
        lda LChar+1,x
        sta lrCh+1
        lda LChar+2,x
        sta lrCh+2
        ldy lrC0
        lda lrNC
        sta lrK
        lda lrCh                ; the first cell
        jsr _put
        lda #7                  ; seven middle ones (the last is one of them when X is on a
        sta lrK                 ; cell's edge)
_mid    lda (ptrA),y
        bne +
        lda lrCh+1
        sta (ptrB),y
+       iny
        cpy #40
        bcc +
        ldy #0
+       dec lrK
        bne _mid
        lda lrS                 ; the last one
        beq +
        lda lrCh+2
        jsr _put
+       inc lrR
        inc lrRow
        lda lrRow
        cmp lrRows
        beq +
        jmp _drow
+       rts
_put    tax                     ; cell Y: character A unless the playfield is there; next cell
        lda (ptrA),y
        bne +
        txa
        sta (ptrB),y
+       iny
        cpy #40
        bcc +
        ldy #0
+       rts

; LChar+A: the character for row kind A / 3 and column kind A % 3, made in this buffer's set
; (CH_PF1 when it is all light). X kept.
LightChar:
        stx tmp2
        tax
        lda KindRow,x
        tay
        lda lrM,y
        sta tmp3                ; row mask
        lda KindCol,x
        tay
        lda lrCM,y              ; column mask
        tay
        lda tmp3
        cmp #$ff
        bne _make
        cpy #$0f
        bne _make
        lda #CH_PF1
        sta LChar,x
        ldx tmp2
        rts
_make   lda ColPat,y
        sta lrPat
        txa
        clc
        adc #CH_LIGHT
        sta LChar,x
        ldy lcSkip
        beq +
        ldx tmp2
        rts
+       asl
        asl
        asl
        sta ptrC
        lda #>CHARS0
        ldy rbuf
        beq +
        lda #>CHARS1
+       sta ptrC+1
        ldy #0
-       lda #0
        asl tmp3
        bcc +
        lda lrPat
+       sta (ptrC),y
        iny
        cpy #8
        bne -
        ldx tmp2
        rts

KindRow:    .byte 0, 0, 0, 1, 1, 1, 2, 2, 2
KindCol:    .byte 0, 1, 2, 0, 1, 2, 0, 1, 2
MaskFrom:   .byte $ff, $7f, $3f, $1f, $0f, $07, $03, $01
MaskTo:     .byte $80, $c0, $e0, $f0, $f8, $fc, $fe, $ff
ColFrom:    .byte $0f, $07, $03, $01

; ================================================================ sprites
Sprites:
        lda #0
        sta BlkUsed
        sta BlkUsed+1
        sta sprN
        sta sprEn
        sta sprMsb
        sta sprYexp
        sta sprPri
        sta ruN
        sta blkN
        ldx #7                  ; sprites not used: blank
        ldy bufOfs
-       lda #BLK_BLANK
        sta StPtr,y
        lda #0
        sta StY,y
        iny
        dex
        bpl -
        lda CTRLPF              ; the playfield in front: the ball over the players, all behind
        and #4
        beq +
        lda #$ff
        sta sprPri
        jsr AddBall
        jsr AddP0
        jsr AddP1
        lda Flicker
        ora filled
        bne _stage
        lda #0
        sta exBall
        jsr AddExtras
        jmp _stage
+       jsr AddP0
        lda sprN
        sta p0Count             ; player 0's sprites stay in front of the walls
        jsr AddP1
        lda Flicker             ; flicker off: the room's other objects (leaving the ball room;
        ora filled              ; not on the frame the screen is filled for a new room)
        bne +
        jsr BallNeed
        jsr AddExtras
+       jsr AddBall
        ldx p0Count
        lda #0
-       cpx #8
        bcs +
        ora Bit,x
        inx
        bne -
+       sta sprPri
_stage  ldy rbuf
        lda sprEn
        sta StEn,y
        lda sprMsb
        sta StMsb,y
        lda sprYexp
        sta StYexp,y
        lda sprPri
        and sprEn
        sta StPri,y
        jmp BuildSchedule

; ---- one object: rows (passes) from pass soK, soR of them; shape soPtr; the rows from soN on
; repeat soSB; quad width soQ; pixel soX; colour soCol
AddP0:
        lda kP0n
        beq _no
        sta soR
        sta soN
        lda kP0k
        sta soK
        lda #0
        sta soSB
        lda P0Ptr
        sta soPtr
        lda P0Ptr+1
        sta soPtr+1
        lda kP0q
        sta soQ
        lda kP0x
        sta soX
        lda kP0len
        sta soLen
        lda #0
        sta soM
        lda COLUP0
        jmp AddObject
_no     rts
AddP1:
        lda kP1n
        clc
        adc kP1m
        beq AddP0._no
        sta soR
        lda Obj1                ; the dark mazes' light is in the characters
        cmp #LightObj
        bne +
        lda CTRLPF
        and #4
        bne AddP0._no
+       lda kP1n
        sta soN
        lda kP1sb
        sta soSB
        lda kP1k
        sta soK
        lda P1Ptr
        sta soPtr
        lda P1Ptr+1
        sta soPtr+1
        lda kP1q
        sta soQ
        lda kP1x
        sta soX
        lda kP1len
        sta soLen
        lda kP1m
        sta soM
        lda COLUP1
AddObject:
        lsr
        tax
        lda ColorMap,x
        sta soCol
        lda soK                 ; shown up to pass 95 (line 192)
        cmp #NPASS-1
        bcc +
        rts
+
        clc
        adc soR
        cmp #NPASS-1
        bcc +
        lda #NPASS-1
        sec
        sbc soK
        sta soR
+       lda #$ff                ; one of the shapes made at start-up? Yes if it is drawn whole
        sta soStat              ; (or down to the last line) with nothing repeated
        lda soM
        bne _dyn
        lda soN
        cmp soLen
        beq +
        clc
        adc soK
        cmp #NPASS-1
        bcc _dyn
+       jsr FindStatic
_dyn    lda #0                  ; column 0, then column 1 for quad width
        sta soCol1
_col    lda soQ
        beq +
        lda soCol1
        clc
        adc #1
+       sta soCode              ; 0 one copy, 1 quad left part, 2 quad right part
        lda soCol1              ; X: 24 + 2 * pixel (+ 48 for the right part)
        beq +
        lda #24
+       clc
        adc soX
        cmp #160
        bcc +
        sbc #160
+       sta soPx
        lda #0
        sta soXh
        lda soPx
        asl
        rol soXh
        adc #24
        sta soXl
        bcc +
        inc soXh
+       lda #0
        sta soSeg
        sta soRow
        lda sprN                ; its sprites: A for even segments, B for odd ones (taken now,
        sta soSprA              ; before any wrap sprites)
        clc
        adc #1
        sta soSprB
        sta sprN
        lda soR
        cmp #22
        bcc _seg
        inc sprN
_seg    lda soR                 ; rows in this segment
        sec
        sbc soRow
        beq +
        bcs ++
+       jmp _segsdone
+
        cmp #22
        bcc +
        lda #21
+       sta soC
        lda soSeg
        lsr
        lda soSprA
        bcc +
        lda soSprB
+       sta soSpr
        cmp #8
        bcc +
        jmp _drop
+       lda soStat
        bmi +
        jsr StaticBlock
        jmp _blk
+       lda blkN
        cmp #B_BALL
        bcc +
        jmp _drop
+       jsr ObjBlock
_blk
        lda soK                 ; Y = 2 (k + row) + 1 + SPRYOFS
        clc
        adc soRow
        asl
        adc #1 + SPRYOFS
        sta soY
        lda soSeg
        cmp #2
        bcs _reuse
        ldx soSpr               ; first two segments: the frame top sets them up
        txa
        clc
        adc bufOfs
        tay
        lda soXl
        sta StX,y
        lda soY
        sta StY,y
        lda soBlk
        sta StPtr,y
        lda soCol
        sta StCol,y
        lda sprEn
        ora Bit,x
        sta sprEn
        lda sprYexp
        ora Bit,x
        sta sprYexp
        lda soXh
        beq +
        lda sprMsb
        ora Bit,x
        sta sprMsb
+       jsr WrapSprite
        jmp _nextseg
_reuse  jsr AddReuse            ; later segments: a raster interrupt moves the sprite down
_nextseg
        inc soSeg
        lda soRow
        clc
        adc #21
        sta soRow
        jmp _seg
_segsdone
        lda soQ                 ; quad width: the right part
        beq _out
        lda soCol1
        bne _out
        inc soCol1
        jmp _col
_drop   inc DbgDrop
_out    rts

; Is the shape soPtr (quad soQ) one made at start-up? soStat = its entry, else $FF
FindStatic:
        ldx nStatic
-       dex
        bmi _none
        lda ShLo,x
        cmp soPtr
        bne -
        lda ShHi,x
        cmp soPtr+1
        bne -
        lda ShQ,x
        cmp soQ
        bne -
        stx soStat
_none   rts

; soBlk = the start-up block for segment soSeg of column soCol1 of shape soStat
StaticBlock:
        ldx soStat
        lda ShSeg,x             ; blocks: column 0's segments, then column 1's
        ldy soCol1
        bne +
        lda #0
+       clc
        adc soSeg
        adc ShBlk,x
        sta soBlk
        inc DbgStatic
        rts

; Start-up: a sprite block for every segment of every shape in the game's object table
; (9 bytes an object from $FF44: shape list at +4, NUSIZ at +8; a shape list is triples
; (animation limit, shape pointer) up to a limit of $FF)
InitShapes:
        lda #0
        sta nStatic
        lda #BLK_STATIC
        sta isBlk
        lda #<$ff44
        sta isObj
        lda #>$ff44
        sta isObj+1
_obj    lda isObj               ; (ShapeLen uses ptrC: the list is walked with ptrD)
        sta ptrC
        lda isObj+1
        sta ptrC+1
        ldy #8                  ; quad width?
        lda (ptrC),y
        jsr Quad
        sta soQ
        ldy #4
        lda (ptrC),y
        sta ptrD
        iny
        lda (ptrC),y
        sta ptrD+1
        ldy #0
_entry  sty isY
        iny
        lda (ptrD),y
        sta soPtr
        iny
        lda (ptrD),y
        sta soPtr+1
        lda #$ff
        sta soStat
        jsr FindStatic          ; (made already)
        lda soStat
        bpl _nextentry
        jsr MakeStatic
_nextentry
        ldy isY
        lda (ptrD),y
        cmp #$ff
        beq _nextobj
        iny
        iny
        iny
        bne _entry
_nextobj
        lda isObj
        clc
        adc #9
        sta isObj
        bcc +
        inc isObj+1
+       cmp #<($ff44 + 9 * 18)
        bne _obj
        rts

; the blocks for shape soPtr, quad soQ (one segment per 21 rows, each column)
MakeStatic:
        lda soPtr
        ldx soPtr+1
        jsr ShapeLen
        sta soN
        beq _ret                ; (an empty shape needs none)
        ldx nStatic
        cpx #NSTATIC
        bcc +
_ret    rts
+
        lda soPtr
        sta ShLo,x
        lda soPtr+1
        sta ShHi,x
        lda soQ
        sta ShQ,x
        lda isBlk
        sta ShBlk,x
        lda soN
        sta ShLen,x
        lda soN                 ; segments: rows / 21, rounded up
        ldy #0
-       iny
        sec
        sbc #21
        beq +
        bcs -
+       tya
        sta ShSeg,x
        inc nStatic
        lda #0
        sta soCol1
        lda #0
        sta soSB
_mcol   lda soQ
        beq +
        lda soCol1
        clc
        adc #1
+       sta soCode
        lda #0
        sta soRow
_mseg   lda soN                 ; rows in this segment
        sec
        sbc soRow
        beq _mnext
        bcc _mnext
        cmp #22
        bcc +
        lda #21
+       sta soC
        lda isBlk               ; the block's data: VICBANK + 64 * pointer
        cmp #BLK_STATIC + MAXSTATIC
        bcs _out
        ldx #0
        stx ptrA+1
        asl
        rol ptrA+1
        asl
        rol ptrA+1
        asl
        rol ptrA+1
        asl
        rol ptrA+1
        asl
        rol ptrA+1
        asl
        rol ptrA+1
        sta ptrA
        lda ptrA+1
        clc
        adc #>VICBANK
        sta ptrA+1
        lda soPtr
        sta ptrB
        lda soPtr+1
        sta ptrB+1
        jsr FillRows
        inc isBlk
        lda soRow
        clc
        adc #21
        sta soRow
        jmp _mseg
_mnext  lda soQ
        beq _out
        lda soCol1
        bne _out
        inc soCol1
        jmp _mcol
_out    rts

; On the 2600 a player crossing pixel 159 goes on at pixel 0. If this column (pixel soPx,
; 8 pixels wide, 24 for a quad's left part) does, another sprite shows the rest at the left
; edge: the same block, 160 pixels to the left (X = 24 + 2 * (pixel - 160)), which works
; from pixel 148 on. (A quad's left part from 137-147 would need a shifted copy: counted.)
WrapSprite:
        ldx soCode
        lda soPx
        clc
        adc ColWidth,x
        cmp #161
        bcc _out
        ldx sprN
        cpx #8
        bcs _drop
        lda soPx
        cmp #148
        bcs _same
        ldx soCode              ; a quad's left part from 137-147: shifted by 148 - pixel
        cpx #1
        bne _lost
        lda blkN
        cmp #B_BALL
        bcs _lost
        lda soBlk
        pha
        lda #148+16
        sec
        sbc soPx
        sta soCode
        jsr ObjBlock
        lda #1
        sta soCode
        lda soPx                ; (placed at X 0: as if from pixel 148)
        pha
        lda #148
        sta soPx
        jsr _place
        pla
        sta soPx
        pla
        sta soBlk
        rts
_lost   inc DbgWrap
_out    rts
_drop   inc DbgDrop
        rts
_same
_place  ldx sprN
        inc sprN
        txa
        clc
        adc bufOfs
        tay
        lda soPx                ; X = 2 * (pixel - 148)
        sec
        sbc #148
        asl
        sta StX,y
        lda soY
        sta StY,y
        lda soBlk
        sta StPtr,y
        lda soCol
        sta StCol,y
        lda sprEn
        ora Bit,x
        sta sprEn
        lda sprYexp
        ora Bit,x
        sta sprYexp
        rts
ColWidth:   .byte 8, 24, 8

; a sprite reuse for segment soSeg (sprite soSpr, block soBlk, Y soY)
AddReuse:
        ldx ruN
        cpx #NSCHED-3
        bcs _full
        txa
        clc
        adc rbuf16
        tay
        lda soSpr
        sta RuSpr,y
        lda soBlk
        sta RuPtr,y
        lda soY
        sta RuY,y
        sec
        sbc #6                  ; the interrupt comes 6 lines before
        sta RuRas,y
        inc ruN
        rts
_full   inc DbgDrop
        rts

; the next sprite block of this buffer, filled with segment soSeg of the object (unless it
; holds that already): soBlk = its pointer
ObjBlock:
        lda soPtr               ; what the block must hold
        sta bk
        sta ptrB
        lda soPtr+1
        sta bk+1
        sta ptrB+1
        lda soRow
        sta bk+2
        lda soC
        sta bk+3
        lda soN
        sta bk+4
        lda soSB
        sta bk+5
        lda soCode
        sta bk+6
        inc blkN
        lda rbufBlk             ; any of this buffer's blocks holding it already?
        asl
        asl
        asl
        clc
        adc #<BlkKey
        sta ptrC
        lda #>BlkKey
        adc #0
        sta ptrC+1
        ldx #0
_srch   txa
        asl
        asl
        asl
        tay
        lda (ptrC),y
        cmp bk
        bne _no
        iny
        lda (ptrC),y
        cmp bk+1
        bne _no
        iny
        lda (ptrC),y
        cmp bk+2
        bne _no
        iny
        lda (ptrC),y
        cmp bk+3
        bne _no
        iny
        lda (ptrC),y
        cmp bk+4
        bne _no
        iny
        lda (ptrC),y
        cmp bk+5
        bne _no
        iny
        lda (ptrC),y
        cmp bk+6
        bne _no
        jsr _use                ; yes
        jmp BlockAddr
_no     inx
        cpx #B_BALL
        bne _srch
        ldy rbuf                ; no: the next block not used in this frame
        ldx BlkNext,y
-       txa
        and #15
        tax
        jsr _isUsed
        beq +
        inx
        bne -
+       txa
        clc
        adc #1
        and #15
        ldy rbuf
        sta BlkNext,y
        jsr _use
        jsr BlockAddr
        ldy #6
-       lda bk,y
        sta (ptrC),y
        dey
        bpl -
        jmp FillRows
_isUsed txa                     ; Z clear if block X is in use this frame
        and #7
        tay
        lda Bit,y
        cpx #8
        bcs +
        and BlkUsed
        rts
+       and BlkUsed+1
        rts
_use    txa                     ; block X is in use this frame
        and #7
        tay
        lda Bit,y
        cpx #8
        bcs +
        ora BlkUsed
        sta BlkUsed
        rts
+       ora BlkUsed+1
        sta BlkUsed+1
        rts

; Fill the sprite block at ptrA with rows soRow.. of the shape at ptrB: soC of them (blank after),
; the shape's rows below soN replaced by soSB; soCode 0 one copy, 1 / 2 quad width left / right
FillRows:
        ldy #0
        lda #0
        sta tmp3                ; row within the segment
_brow   lda tmp3
        cmp soC
        bcs _blank
        clc
        adc soRow               ; the object's row
        cmp soN
        bcc +
        lda soSB                ; past the shape: the repeated last row
        jmp ++
+       sty tmp2
        tay
        lda (ptrB),y
        ldy tmp2
+       sta tmp
        lda soCode
        bne _quad
        lda tmp
        sta (ptrA),y
        iny
        lda #0
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        jmp _bnext
_quad   cmp #2
        beq _qright
        cmp #16
        bcc _qleft
        jmp FillShifted
_qleft  lda tmp                 ; left part: bits 7-2, four sprite pixels each
        lsr
        lsr
        lsr
        lsr
        lsr
        lsr
        tax
        lda Quad2,x
        sta (ptrA),y
        iny
        lda tmp
        lsr
        lsr
        lsr
        lsr
        and #3
        tax
        lda Quad2,x
        sta (ptrA),y
        iny
        lda tmp
        lsr
        lsr
        and #3
        tax
        lda Quad2,x
        sta (ptrA),y
        iny
        jmp _bnext
_qright lda tmp                 ; right part: bits 1-0
        and #3
        tax
        lda Quad2,x
        sta (ptrA),y
        iny
        lda #0
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        jmp _bnext
_blank  lda #0
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
_bnext  inc tmp3
        cpy #63
        beq +
        jmp _brow
+       rts

; (FillRows) soCode 16 + s: the whole quad row (32 pixels) shifted left s pixels
FillShifted:
        sec
        sbc #16
        sta tmp2                ; (a wrapped left part, see WrapSprite)
        sty irqSave
        lda tmp
        lsr
        lsr
        lsr
        lsr
        lsr
        lsr
        tax
        lda Quad2,x
        sta qe
        lda tmp
        lsr
        lsr
        lsr
        lsr
        and #3
        tax
        lda Quad2,x
        sta qe+1
        lda tmp
        lsr
        lsr
        and #3
        tax
        lda Quad2,x
        sta qe+2
        lda tmp
        and #3
        tax
        lda Quad2,x
        sta qe+3
        ldx tmp2
-       asl qe+3
        rol qe+2
        rol qe+1
        rol qe
        dex
        bne -
        ldy irqSave
        lda qe
        sta (ptrA),y
        iny
        lda qe+1
        sta (ptrA),y
        iny
        lda qe+2
        sta (ptrA),y
        iny
        jmp FillRows._bnext

; block X of this buffer: ptrA = its data, ptrC = its key (7 bytes in BlkKey), soBlk = pointer
BlockAddr:
        txa
        clc
        adc rbufBlk             ; buffer * NBLK
        sta tmp
        clc
        adc #BLK_SET
        sta soBlk
        lda #0                  ; data: VICBANK + 64 * pointer
        sta ptrA+1
        lda soBlk
        asl
        rol ptrA+1
        asl
        rol ptrA+1
        asl
        rol ptrA+1
        asl
        rol ptrA+1
        asl
        rol ptrA+1
        asl
        rol ptrA+1
        sta ptrA
        lda ptrA+1
        clc
        adc #>VICBANK
        sta ptrA+1
        lda tmp                 ; key: BlkKey + 8 * (buffer * NBLK + X)
        ldx #0
        stx ptrC+1
        asl
        rol ptrC+1
        asl
        rol ptrC+1
        asl
        rol ptrC+1
        clc
        adc #<BlkKey
        sta ptrC
        lda ptrC+1
        adc #>BlkKey
        sta ptrC+1
        rts

; ---- flicker off (key F): the room's other objects as well, sprites permitting.
; The 2600 shows two objects a frame (players 0 and 1) and takes turns when a room has more.
; With flicker off the C64 adds the room's other objects, laid out as the kernel would draw
; them as player 0, behind the two the game shows this frame; one that doesn't fit is left to
; the game's turns. (The game, and its collisions, stay the 2600's.)
AddExtras:
        lda #0
        sta exObj
_obj    lda exObj
        cmp Obj0
        beq _next
        cmp Obj1
        beq _next
        cmp #LightObj           ; (the light, where the playfield is in front, is in the characters)
        bne +
        lda CTRLPF
        and #4
        bne _next
+       lda exObj
        jsr Layout
        bcc _next               ; (not in this room, or nothing to draw)
        lda soQ                 ; sprites it needs: columns x (1 or 2 segments), +1 near the right
        clc                     ; edge (a wrapped part), and the ball's still to come
        adc #1
        ldx soR
        cpx #22
        bcc +
        asl
+       ldx soX
        cpx #137
        bcc +
        adc #0                  ; (carry set)
+       clc
        adc sprN
        adc exBall
        cmp #9
        bcs _skip
        lda exCol
        jsr AddObject
        jmp _next
_skip   inc DbgSkip
_next   lda exObj
        clc
        adc #9
        sta exObj
        cmp #$a2
        bcc _obj
        rts

; Layout of object A (its table entry at $FF44 + A) as the kernel would draw it as player 0:
; carry set if it is in the room shown and has rows to draw; soPtr, soQ, soX, soK, soR, soN,
; soLen, soSB, soM set for AddObject, exCol its colour.
Layout:
        clc
        adc #<$ff44
        sta ptrD
        lda #>$ff44
        adc #0
        sta ptrD+1
        ldy #0                  ; its room, X, Y
        lda (ptrD),y
        sta ptrC
        iny
        lda (ptrD),y
        sta ptrC+1
        dey
        lda (ptrC),y
        cmp ShownRoom
        beq +
        clc
        rts
+       iny
        lda (ptrC),y
        sta exX
        iny
        lda (ptrC),y
        sta exY
        ldy #2                  ; its animation state ...
        lda (ptrD),y
        sta ptrC
        iny
        lda (ptrD),y
        sta ptrC+1
        ldy #0
        lda (ptrC),y
        sta tmp
        ldy #4                  ; ... picks its shape: the first entry with a limit not below it
        lda (ptrD),y
        sta ptrC
        iny
        lda (ptrD),y
        sta ptrC+1
        ldy #0
-       lda tmp
        cmp (ptrC),y
        bcc +
        beq +
        iny
        iny
        iny
        bne -
+       iny
        lda (ptrC),y
        sta soPtr
        iny
        lda (ptrC),y
        sta soPtr+1
        ldy #6                  ; colour (or the B&W one)
        lda SWCHB
        and #8
        bne +
        iny
+       lda (ptrD),y
        jsr Colour2600
        sta exCol
        ldy #8
        lda (ptrD),y
        jsr Quad
        sta soQ
        ldx exX                 ; pixel (quad width: a pixel later)
        lda PosP,x
        ldx soQ
        beq +
        clc
        adc #1
        cmp #160
        bcc +
        lda #0
+       sta soX
        lda #0
        sta soSB
        sta soM
        lda #$68                ; passes, as for player 0 (see Kern)
        sec
        sbc exY
        bpl _late
        sec
        sbc #$7f
        ldx #0
        beq _act
_late   clc
        adc #1
        cmp #NPASS
        bcs _none
        tax
        eor #$ff
        sec
        adc #NPASS
_act    stx soK
        jsr CapPasses
        sta tmp2
        lda #$ff                ; its rows: from the start-up table, else counted
        sta soStat
        jsr FindStatic
        ldx soStat
        bmi +
        lda ShLen,x
        jmp ++
+       lda soPtr
        ldx soPtr+1
        jsr ShapeLen
+       sta soLen
        cmp tmp2
        bcc +
        lda tmp2
+       sta soN
        sta soR
        beq _none
        sec
        rts
_none   clc
        rts

; The game's colour routine (Colour, $F2D3): an odd value is read from RAM $80 + A / 2 (the
; chalice's flashing), and the attract mode's colour cycle
Colour2600:
        lsr
        bcc +
        tay
        lda $80,y
+       ldy $e6
        bpl +
        eor $e6
        and #$fb
+       asl
        rts

; ---- the light's layout (DrawLight): player 1's when it is the light, else (flicker off) its
; own if it is in the room; only where the playfield is in front
LightLayout:
        lda #0
        sta lgOn
        lda CTRLPF
        and #4
        beq _out
        lda Obj1
        cmp #LightObj
        bne _own
        lda kP1k
        sta lgK
        lda kP1n
        clc
        adc kP1m
        sta lgN
        lda kP1x
        sta lgX
        lda COLUP1
        sta lgCol
        inc lgOn
_out    rts
_own    lda Flicker
        bne _out
        lda Obj0
        cmp #LightObj
        beq _out
        lda #LightObj
        jsr Layout
        bcc _out
        lda soK
        sta lgK
        lda soN
        sta lgN
        lda soX
        sta lgX
        lda exCol
        sta lgCol
        inc lgOn
        rts

; exBall = the sprites AddBall will take
BallNeed:
        ldx #0
        lda kBn
        beq +
        lda kBk
        cmp #NPASS-1
        bcs +
        inx
+       lda kL0En
        beq +
        inx
+       stx exBall
        rts

; ---- the ball: its passes (up to 95), and line L0 if the last picture left it on
AddBall:
        lda COLUPF
        lsr
        tax
        lda ColorMap,x
        sta soCol
        lda kBn
        beq _l0
        lda kBk
        cmp #NPASS-1
        bcs _l0
        clc                     ; lines: 2 per pass up to pass 95
        adc kBn
        cmp #NPASS-1
        bcc +
        lda #NPASS-1
+       sec
        sbc kBk
        asl
        sta soC
        lda kBk
        asl
        adc #1 + SPRYOFS
        sta soY
        ldx #B_BALL
        jsr BallSprite
_l0     lda kL0En
        beq +
        lda #1
        sta soC
        lda #SPRYOFS
        sta soY
        ldx #B_BALL0
        jsr BallSprite
+       rts

; a ball sprite: block X, soC lines high at soY, pixel kBlx
BallSprite:
        lda sprN
        cmp #8
        bcc +
        inc DbgDrop
        rts
+       jsr BlockAddr
        lda kBmask              ; key: width and lines
        sta bk
        lda soC
        sta bk+1
        ldy #1
        lda (ptrC),y
        cmp bk+1
        bne +
        dey
        lda (ptrC),y
        cmp bk
        beq _have
+       ldy #0
        lda bk
        sta (ptrC),y
        iny
        lda bk+1
        sta (ptrC),y
        ldy #0
        ldx #0
-       lda #0
        cpx soC
        bcs +
        lda kBmask
+       sta (ptrA),y
        iny
        lda #0
        sta (ptrA),y
        iny
        sta (ptrA),y
        iny
        inx
        cpx #21
        bne -
        ldy #6                  ; (the key's other bytes: never an object's)
        lda #$ff
        sta (ptrC),y
_have   ldx sprN
        inc sprN
        txa
        clc
        adc bufOfs
        tay
        lda kBlx                ; X: 24 + 2 * pixel
        asl
        sta StX,y
        lda #0
        rol
        sta tmp
        lda StX,y
        clc
        adc #24
        sta StX,y
        bcc +
        inc tmp
+       lda soY
        sta StY,y
        lda soBlk
        sta StPtr,y
        lda soCol
        sta StCol,y
        lda sprEn
        ora Bit,x
        sta sprEn
        lda tmp
        beq +
        lda sprMsb
        ora Bit,x
        sta sprMsb
+       rts

; ---- this buffer's raster schedule: the frame top, the reuses in raster order, the end
BuildSchedule:
        ldx rbuf16
        lda #TOPRASTER
        sta SchedRas,x
        lda #S_TOP
        sta SchedType,x
        inx
        stx schIdx
        lda #0
        sta tmp                 ; reuses placed
_pick   lda tmp
        cmp ruN
        bcs _end
        lda #$ff                ; the earliest one not placed yet
        sta tmp2
        ldx #0
-       cpx ruN
        bcs _take
        stx tmp3
        txa
        clc
        adc rbuf16
        tax
        lda RuRas,x
        ldx tmp3
        cmp tmp2
        bcs +
        sta tmp2
        stx bestI
+       inx
        bne -
_take   lda bestI
        clc
        adc rbuf16
        tay
        lda #$ff                ; (placed)
        sta RuRas,y
        ldx schIdx
        lda tmp2
        sta SchedRas,x
        lda #S_REUSE
        sta SchedType,x
        tya
        sta SchedArg,x
        inc schIdx
        inc tmp
        jmp _pick
_end    ldx schIdx
        lda #ENDRASTER
        sta SchedRas,x
        lda #S_END
        sta SchedType,x
        rts
