; Adventure (Atari 2600, 1980) running on the Commodore 64.
;
; The original 2600 program runs almost unchanged at $F000, in the RAM under the C64
; KERNAL (patches: see GameImage at the end of data.asm). This file and the others supply
; everything the 2600 hardware used to do:
;
;   - display (render.asm): the rooms as multicolour characters (one playfield block is one
;     character, so the 40 columns line up exactly), the thin side walls in the characters
;     too, the objects and the player's square as sprites; the dark mazes' light around the
;     player is drawn in the characters (it is a plain 32 x 64 pixel block behind the walls).
;     One 2600 pixel = two C64 pixels (one multicolour pixel), one 2600 line = one C64 line.
;   - collisions (kernel.asm): worked out from the rules in tools/model.js, which match the
;     2600 pixel for pixel, and handed to the game as the TIA collision registers
;   - input (input.asm): keyboard and joysticks mapped onto the 2600's joystick/switch ports
;   - sound (data.asm): the game's TIA sound registers translated to the SID
;
; Adventure's main loop takes three frames per pass and calls the kernel as a subroutine
; three times, so the game runs as a coroutine with a stack of its own ($01E0-$01FF): Tick
; switches to it and resumes the game; the patched kernel (KernelHook) works out what the
; picture and the collisions would have been, then switches back.
;
; The game's TIA writes land harmlessly in zero page $02-$2C; it reads the TIA at the mirrors
; $30-$3D, where we put the collisions and the fire button. Its RIOT accesses ($0280-$0297)
; hit plain C64 RAM, which we fill in each frame.
;
; Build: build.cmd (64tass -C -a -o build/adventure-c64.prg c64/main.asm)

        .cpu "6502"

; ---------------------------------------------------------------- 2600 RAM
PFPtr       = $80       ; 2 bytes: the room's playfield, 3 bytes a row
P0Ptr       = $82       ; 2 bytes: player 0's shape
P1Ptr       = $84
P0X         = $86
P0Y         = $87
P1X         = $88
P1Y         = $89
Room        = $8A
BallX       = $8B
BallY       = $8C
BallTop     = $8D       ; the kernel leaves these behind:
KLine       = $8E
PFIndex     = $8F
P0Row       = $90
P1Row       = $91
Obj0        = $95       ; the object shown as player 0
Obj1        = $96       ; the object shown as player 1 (0 = the dark mazes' light)
LightObj    = 0

; ------------------------------- 2600 hardware: TIA writes land in zero page
NUSIZ0      = $04
NUSIZ1      = $05
COLUP0      = $06
COLUP1      = $07
COLUPF      = $08
COLUBK      = $09
CTRLPF      = $0A
PF0         = $0D       ; PF0-PF2
AUDC0       = $15       ; AUDC0/1, AUDF0/1, AUDV0/1 in pairs
AUDF0       = $17
AUDV0       = $19
GRP0        = $1B
GRP1        = $1C
ENAM0       = $1D
ENAM1       = $1E
ENABL       = $1F
VDELP1      = $26
; the game reads the TIA at $30-$3D: we fill these in
CXM0P       = $30
CXM1P       = $31
CXP0FB      = $32       ; bit 6 P0-ball
CXP1FB      = $33       ; bit 6 P1-ball
CXM0FB      = $34       ; bit 6 M0-ball
CXM1FB      = $35       ; bit 6 M1-ball
CXBLPF      = $36       ; bit 7 ball-playfield
CXPPMM      = $37       ; bit 7 P0-P1
INPT4       = $3C       ; bit 7 clear: fire (the game rotates it out, so it is set before every tick)
; RIOT
SWCHA       = $0280     ; joystick (high nibble: player 0)
SWCHB       = $0282     ; console switches
INTIM       = $0284     ; timer (kept at 0 so the game never waits)

; ------------------------------------------------ 2600 program addresses
PowerOn     = $F2EF

; ------------------------------------------------------------ C64 layout
GAMESTACK   = $FF       ; the game's stack pointer at power-on (its TXS); ours starts at $DF
C64STACK    = $DF
VICBANK     = $4000     ; the VIC sees $4000-$7FFF
SCREEN0     = $4000     ; screens for the two buffers
SCREEN1     = $4400
CHARS0      = $4800     ; character sets for the two buffers (the light's edges differ)
CHARS1      = $5000
SPRDATA     = $5800     ; sprite blocks
SPRBASE     = (SPRDATA - VICBANK) / 64
IDLEBYTE    = $7FFF     ; what the VIC shows below the last character row: $FF, black
ROOMTMPL    = $8000     ; every room's characters: 7 playfield rows x 40, 280 bytes a room
NROOMS      = 30        ; rooms in the game's table
BSS         = $C000     ; variables that aren't in the program file (data.asm)
COLRAM      = $D800

; 2600 kernel line L is raster line L + LINE0RAS. Character row r covers lines 8r-7 .. 8r:
; row 0 shows only L0 (its other rows are black), rows 1-2 playfield row 0, then four rows
; for each playfield row. Below L192 the VIC is idle and shows $7FFF (black).
LINE0RAS    = 55
SPRYOFS     = LINE0RAS - 1      ; sprite Y register for 2600 line L: L + SPRYOFS
TOPRASTER   = 20        ; frame start: everything for the top of the picture
ENDRASTER   = 246       ; frame end: blank the sprites below L192 (from raster 248), swap buffers

; characters (the same in both sets, except the light's edges)
CH_BLANK    = 0
CH_PF1      = 1         ; a full block in colour 01 ($D022): the playfield, or the light
CH_PF2      = 2         ; ... in colour 10 ($D023): the playfield when it is in front
CH_W2       = 3         ; thin wall M0 in column 2 (pixel 3 of 4), playfield off / on
CH_W3       = 5         ; ... in column 3 (pixel 0)
CH_W37      = 7         ; thin wall M1 in column 37 (pixels 0-1)
NCHSTATIC   = 9
CH_TOP      = 9         ; chars 9-17: the same with rows 0-6 black (character row 0: only L0)
CH_LIGHT    = 20        ; the light's edge characters, 9 per buffer (20-28)

; sprite blocks: per buffer
NBLK        = 18        ; object segments (up to 16), the ball, the ball's L0 line
B_BALL      = 16
B_BALL0     = 17
BLK_BLANK   = SPRBASE                   ; always empty
BLK_SET     = SPRBASE + 1               ; buffer 0's blocks; buffer 1's follow
BLK_STATIC  = BLK_SET + 2 * NBLK        ; the shapes made at start-up (InitShapes)
MAXSTATIC   = 64
NSTATIC     = 48                        ; shapes at most
        .cerror VICBANK + 64 * (BLK_STATIC + MAXSTATIC) > IDLEBYTE, "sprite blocks overflow"

; raster schedule entry types
S_TOP       = 0
S_REUSE     = 2         ; move a sprite down to its next segment
S_END       = 4
NSCHED      = 16

; ------------------------------------------------------- zero page ($40+)
; $02-$2C take the game's TIA writes and $30-$3D are its TIA reads, so ours start at $40.
        .virtual $40
ptrA        .word ?
ptrB        .word ?
ptrC        .word ?
ptrD        .word ?
tmp         .byte ?
tmp2        .byte ?
tmp3        .byte ?
; kernel (kernel.asm): what the picture holds
kP0x        .byte ?     ; player 0: pixel, quad width?, first iteration, rows
kP0q        .byte ?
kP0k        .byte ?
kP0n        .byte ?
kP1x        .byte ?
kP1q        .byte ?
kP1k        .byte ?
kP1n        .byte ?
kP1m        .byte ?     ; player 1: rows its last row repeats for (the "smear"), and that row
kP1sb       .byte ?
kBlx        .byte ?     ; ball: pixel, mask of its width, first iteration, iterations
kBmask      .byte ?
kBk         .byte ?
kBn         .byte ?
kOldEn      .byte ?     ; ENABL left from the last picture (L0 and the lines before it)
kNewEn      .byte ?     ; ... and from this one
kL0En       .byte ?     ; the ball on L0 of the picture just worked out
kP0len      .byte ?     ; the players' shapes: rows before the zero byte
kP1len      .byte ?
; ObjBits
obG         .byte ?
obX         .byte ?
obQ         .byte ?
wX          .byte ?
qe          .fill 5
colK        .byte ?
; frame loop
frameFlag   .byte ?     ; frames counted by the raster interrupt
frames      .byte ?
isPal       .byte ?
tickAcc     .byte ?
firstTick   .byte ?
c64sp       .byte ?     ; the two stacks
gameSP      .byte ?
joyb        .word ?     ; port 2, port 1 (0 bits = pressed)
outv        .word ?     ; SWCHA, INPT4 being built
switches    .byte ?     ; SWCHB toggles
inpt4       .byte ?     ; INPT4 for every tick
curBuf      .byte ?     ; raster interrupt: frame buffer in use (0/1)
pending     .byte ?     ; a new frame is ready in the other buffer
irqIdx      .byte ?
irqTmp      .byte ?
bufOfs      .byte ?     ; render: 8 * buffer being drawn
v0          .byte ?     ; sound
v1          .byte ?
v2          .byte ?
        .cerror * > $80, "zero page overflow"
        .endv

; ------------------------------------------------------------ BASIC program
; LOAD and RUN start the game; LIST shows the title, credits and controls.
; (Lower case here: 64tass -a turns it into PETSCII, which the C64 shows in capitals.)
        * = $0801
        .word Bas10, 0
        .null $9e, format(" %d", Start)
Bas10   .word Bas20, 10
        .null $8f, " adventure"
Bas20   .word Bas30, 20
        .null $8f, " from the atari 2600"
Bas30   .word Bas40, 30
        .null $8f, " programmed by warren robinett"
Bas40   .word Bas50, 40
        .null $8f, " version 1.1"
Bas50   .word Bas60, 50
        .null $8f, " ported by claude and doughboy68"
Bas60   .word Bas70, 60
        .null $8f, " joy port 2/1 or wasd space-drop"
Bas70   .word Bas80, 70
        .null $8f, " f1 or fire-start f2-power off/on"
Bas80   .word Bas90, 80
        .null $8f, " f3-select game 1-3 f5-colour/b+w"
Bas90   .word Bas100, 90
        .null $8f, " f7/f8-difficulty left/right"
Bas100  .word BasEnd, 100
        .null $8f, " f-flicker on/off"
BasEnd  .word 0

; ===================================================================== init
Start:
        sei
        cld
        ldx #C64STACK
        txs
        lda #$7f                ; no CIA interrupts
        sta $dc0d
        sta $dd0d
        lda $dc0d
        lda $dd0d
        lda #$35                ; RAM everywhere except I/O at $D000
        sta $01

        lda #0                  ; clear zero page $02-$FF (2600 RAM included)
        ldx #2
-       sta $00,x
        inx
        bne -
        lda #<BSS               ; and our variables at $C000
        sta ptrA
        lda #>BSS
        sta ptrA+1
        ldy #0
-       lda #0
        sta (ptrA),y
        inc ptrA
        bne +
        inc ptrA+1
+       lda ptrA+1
        cmp #>BSSEND+1
        bne -

        ; copy the patched 2600 program to $F000-$FFFF
        lda #<GameImage
        sta ptrA
        lda #>GameImage
        sta ptrA+1
        lda #0
        sta ptrB
        lda #$f0
        sta ptrB+1
        ldx #16
        ldy #0
-       lda (ptrA),y
        sta (ptrB),y
        iny
        bne -
        inc ptrA+1
        inc ptrB+1
        dex
        bne -
        lda #<Nmi               ; our vectors replace the 2600's
        sta $fffa
        lda #>Nmi
        sta $fffb
        lda #<Irq
        sta $fffe
        lda #>Irq
        sta $ffff

        ; 2600 ports at rest
        lda #$ff
        sta SWCHA
        lda #$0b                ; colour, both difficulties B, reset/select up
        sta SWCHB
        sta switches
        lda #0
        sta INTIM
        lda #$80
        sta INPT4
        sta inpt4
        lda #1
        sta firstTick

        jsr InitVideo
        jsr InitRooms
        jsr InitShapes
        jsr InitSound
        jsr DetectPal
        lda #$ff                ; CIA 2 timer A free-running (testing aid: DbgTime)
        sta $dd04
        sta $dd05
        lda #%00010001
        sta $dd0e

        ldx #0                  ; start the raster interrupt on an empty frame
        stx curBuf
        stx irqIdx
        lda #TOPRASTER
        sta SchedRas
        sta SchedRas+NSCHED
        lda #S_TOP
        sta SchedType
        sta SchedType+NSCHED
        lda #ENDRASTER
        sta SchedRas+1
        sta SchedRas+NSCHED+1
        lda #S_END
        sta SchedType+1
        sta SchedType+NSCHED+1
        lda #TOPRASTER
        sta $d012
        lda #$18                ; YSCROLL 0, 25 rows, screen on (bit 7 = raster bit 8 clear)
        sta $d011
        lda #1
        sta $d01a
        lda #$ff
        sta $d019
        cli

; ================================================================ main loop
MainLoop:
-       lda frameFlag           ; frames since we last got here (set by the raster interrupt)
        beq -
        sei
        lda frameFlag
        ldx #0
        stx frameFlag
        cli
        inc DbgLoops            ; (testing aid: passes, and frames that came late)
        bne +
        inc DbgLoops+1
+       cmp #2
        bcc +
        inc DbgLate
        bne +
        inc DbgLate+1
+       cmp #3                  ; if we fell behind, catch up at most 3 frames
        bcc +
        lda #3
+       sta frames
        jsr DbgTime             ; (testing aid: the most cycles drawing, ticking, both)
        stx dbgT0
        sty dbgT0+1
        lda DbgBorder           ; testing aid: the border shows where the time goes
        beq +
        lda #2
        sta $d020
+       jsr Render              ; draw the state the last tick produced
        jsr ReadInput
        lda PowerReq            ; F2: the power switch
        beq +
        jsr PowerCycle
+       jsr DbgTime
        stx dbgT1
        sty dbgT1+1
        lda dbgT0               ; drawing
        ldx dbgT0+1
        ldy #0
        jsr DbgMax
        lda DbgBorder
        beq _frame
        lda #5
        sta $d020
_frame  lda isPal               ; PAL: 6 game ticks every 5 frames keeps 2600 speed
        beq _ntsc
        lda tickAcc
        clc
        adc #6
        sta tickAcc
-       lda tickAcc
        cmp #5
        bcc _done
        sbc #5
        sta tickAcc
        jsr Tick
        jmp -
_ntsc   jsr Tick
_done   dec frames
        bne _frame
        jsr DbgTime
        lda dbgT1               ; the ticks (from the end of drawing)
        ldx dbgT1+1
        ldy #2
        jsr DbgMax
        lda dbgT0               ; the whole pass
        ldx dbgT0+1
        ldy #4
        jsr DbgMax
        jsr UpdateSound
        lda DbgBorder
        beq +
        lda #0
        sta $d020
+       jmp MainLoop

; Testing aid: CIA 2 timer A counts down freely. DbgTime: dbgNow (and X/Y) = its value.
DbgTime:
-       ldy $dd05
        ldx $dd04
        cpy $dd05
        bne -
        stx dbgNow
        sty dbgNow+1
        rts
; DbgMax: cycles from the time in A/X (low/high) to dbgNow; keep the largest at
; DbgRMax+Y (Y = 0 drawing, 2 ticks, 4 the whole pass).
DbgMax:
        sec                     ; (the timer counts down: start - now)
        sbc dbgNow
        sta dbgTmp
        txa
        sbc dbgNow+1
        sta dbgTmp+1
        cmp DbgRMax+1,y
        bcc _keep
        bne _new
        lda dbgTmp
        cmp DbgRMax,y
        bcc _keep
_new    lda dbgTmp
        sta DbgRMax,y
        lda dbgTmp+1
        sta DbgRMax+1,y
_keep   rts

; One 2600 frame of game logic: resume the game on its own stack until it calls the kernel
; again (KernelHook). The very first tick starts it at power-on (which sets its stack).
Tick:
        lda inpt4               ; (the game rotates the fire button out of INPT4)
        sta INPT4
        tsx
        stx c64sp
        lda firstTick
        beq +
        lda #0
        sta firstTick
        jmp PowerOn
+       ldx gameSP
        txs
        rts                     ; back into the game, after its JSR to the kernel

KernelHook:                     ; (the game's JSR Kernel) the game would draw the picture now
        tsx
        stx gameSP
        ldx c64sp
        txs
        jmp Kern                ; what the picture and the collisions would have been
                                ; (returns to whoever called Tick)

; Replaces "JSR RoomEntry" at the start of SetupFrame: the room the picture is set up for
; (flicker off draws that room's other objects)
SaveRoom:
        sta ShownRoom
        jmp $f271

; F2: the power switch off and on. The TIA is cleared and the next tick starts at the 2600's
; power-on code, which clears its RAM (game 1); the console switches stay as they are set,
; as on a real 2600. The display catches up by itself.
PowerCycle:
        lda #0
        sta PowerReq
        ldx #2                  ; the TIA's registers ($02-$2C) and our copies of its reads
-       sta $00,x
        inx
        cpx #$3e
        bne -
        sta INTIM
        sta kOldEn              ; (the TIA's ball enable and playfield, as our kernel remembers them)
        sta LastPF
        sta LastPF+1
        sta LastPF+2
        lda #$ff
        sta SWCHA
        lda #$80
        sta INPT4
        sta inpt4
        lda #1
        sta firstTick
        rts

; =========================================================== interrupts
; Each frame is a short schedule of raster lines (SchedRas/SchedType/SchedArg), built by
; Render into the buffer the display isn't using. At the end of the frame the interrupt
; switches to a newly finished buffer, so a half-drawn frame is never shown. The entries:
;   S_TOP     sprites' first uses, colours, priorities, screen and character set
;   S_REUSE   move a sprite down to the next segment of a tall object
;   S_END     frame end: blank the sprites below the picture, swap buffers, let the main loop go
Irq:
        pha
        txa
        pha
        tya
        pha
        cld                     ; the game uses decimal mode now and then
        lda $d019
        sta $d019
_next   ldx irqIdx
        ldy SchedType,x
        lda IrqJump,y
        sta _jmp+1
        lda IrqJump+1,y
        sta _jmp+2
_jmp    jmp $ffff
_done   inc irqIdx              ; next entry; run it now if its line has passed already
        ldx irqIdx
        lda SchedRas,x
        sta $d012
        sec
        sbc #2
        cmp $d012
        bcc _next
_out    pla
        tay
        pla
        tax
        pla
        rti
IrqJump:    .word ITop, IReuse, IEnd

ITop:   inc DbgTops             ; (testing aid)
        lda curBuf
        asl
        asl
        asl
        sta irqTmp              ; 8 * buffer: staged sprite values
        asl
        sta irqIdx              ; 16 * buffer: this buffer's schedule, entry 0
        ldy irqTmp
        ldx #0
-       lda StPtr,y
        sta SCREEN0+$3f8,x      ; (both screens: the VIC reads the shown one's)
        sta SCREEN1+$3f8,x
        lda StCol,y
        sta $d027,x
        iny
        inx
        cpx #8
        bne -
        ldy irqTmp
        ldx #0
-       lda StX,y
        sta $d000,x
        lda StY,y
        sta $d001,x
        iny
        inx
        inx
        cpx #16
        bne -
        ldy curBuf
        lda StMsb,y
        sta $d010
        lda StEn,y
        sta $d015
        lda StYexp,y
        sta $d017
        lda StPri,y
        sta $d01b
        lda StBg,y              ; (the border stays black)
        sta $d021
        lda StC1,y
        sta $d022
        lda StC2,y
        sta $d023
        lda StD018,y
        sta $d018
        jmp Irq._done

IReuse: ldy SchedArg,x          ; Y = 16 * buffer + reuse entry
        ldx RuSpr,y             ; the sprite
        lda RuPtr,y
        sta SCREEN0+$3f8,x
        sta SCREEN1+$3f8,x
        txa
        asl
        tax
        lda RuY,y
        sta $d001,x
        cmp $d012               ; (testing aid) it must be there before the raster reaches it
        beq +
        bcs ++
+       inc DbgSprLate
+       jmp Irq._done

IEnd:   lda #ENDRASTER+1        ; below L192 nothing more (sprite rows there are L193, which the
-       cmp $d012               ; 2600 blanks, or below). The VIC reads raster 248's pointers in
        bne -                   ; cycles 58-62 of 247 (sprites 0-2) and 1-9 of 248 (3-7), and
        lda #BLK_BLANK          ; 247's in 58-62 of 246 and 1-9 of 247: so write them early in 247.
        ldx curBuf
        bne +
        sta SCREEN0+$3f8
        sta SCREEN0+$3f9
        sta SCREEN0+$3fa
        sta SCREEN0+$3fb
        sta SCREEN0+$3fc
        sta SCREEN0+$3fd
        sta SCREEN0+$3fe
        sta SCREEN0+$3ff
        jmp ++
+       sta SCREEN1+$3f8
        sta SCREEN1+$3f9
        sta SCREEN1+$3fa
        sta SCREEN1+$3fb
        sta SCREEN1+$3fc
        sta SCREEN1+$3fd
        sta SCREEN1+$3fe
        sta SCREEN1+$3ff
+       inc frameFlag           ; frame end: the next interrupt is the frame top
        lda pending             ; switch to a newly finished frame
        bne _swap
        inc DbgRepeat           ; (testing aid: none ready, the same picture again)
        jmp +
_swap
        lda curBuf
        eor #1
        sta curBuf
        lda #0
        sta pending
+       lda curBuf
        asl
        asl
        asl
        asl
        sta irqIdx
        lda #TOPRASTER
        sta $d012
        jmp Irq._out

Nmi:    rti

; ============================================================= setup code
DetectPal:
-       lda $d012
-       cmp $d012
        beq -
        bmi --
        ldx #0                  ; A = low byte of the last raster line: $37 on PAL
        cmp #$20
        bcc +
        inx
+       stx isPal
        txa                     ; the SID's pitch depends on the machine's clock
        bne +
        lda #<SidFreqLoN
        sta FreqTab
        lda #>SidFreqLoN
        sta FreqTab+1
+       rts

InitVideo:
        lda $dd02               ; VIC bank 1 ($4000)
        ora #3
        sta $dd02
        lda $dd00
        and #$fc
        ora #2
        sta $dd00
        lda #0
        sta $d020
        sta $d021
        sta $d015
        sta $d017
        sta $d01b
        sta $d01c
        lda #$18                ; multicolour characters, 40 columns
        sta $d016
        lda #$ff                ; every sprite double width: one 2600 pixel = one sprite pixel
        sta $d01d

        ; clear $4000-$7FFF (screens, characters, sprite blocks)
        lda #<VICBANK
        sta ptrB
        lda #>VICBANK
        sta ptrB+1
        ldx #64
        ldy #0
        tya
-       sta (ptrB),y
        iny
        bne -
        inc ptrB+1
        dex
        bne -
        lda #$ff                ; below the last character row: black
        sta IDLEBYTE
        ldx #0                  ; nothing known about the rooms' templates or the sprite blocks
-       sta RoomKeys,x
        sta BlkKey,x
        sta BlkKey+$100,x
        inx
        bne -
        ; colour RAM: multicolour everywhere, colour 11 black
        ldx #0
        lda #8
-       sta COLRAM,x
        sta COLRAM+$100,x
        sta COLRAM+$200,x
        sta COLRAM+$2e8,x
        inx
        bne -
        ; the static characters, in both sets: 0-8 and their "top" copies 9-17
        ldx #NCHSTATIC-1
_ch     stx tmp3
        lda CharPat,x
        sta tmp
        txa
        asl
        asl
        asl
        tay
        ldx #8
-       lda tmp
        sta CHARS0,y
        sta CHARS1,y
        iny
        dex
        bne -
        lda tmp3                ; top copy: rows 0-6 black (11), row 7 the pattern
        clc
        adc #CH_TOP
        asl
        asl
        asl
        tay
        lda #$ff
        ldx #7
-       sta CHARS0,y
        sta CHARS1,y
        iny
        dex
        bne -
        lda tmp
        sta CHARS0,y
        sta CHARS1,y
        ldx tmp3
        dex
        bpl _ch
        rts

; the static characters' pattern (every row the same): blank, playfield in colour 01 or 10,
; the thin walls (colour 10) in columns 2, 3 and 37 without / with the playfield
CharPat:    .byte $00, $55, $aa, $02, $56, $80, $95, $a0, $a5

InitSound:
        ldx #$18
        lda #0
-       sta $d400,x
        dex
        bpl -
        lda #$0f                ; full volume
        sta $d418
        ldx #5
        lda #$ff
-       sta SndLast,x
        dex
        bpl -
        rts

        .include "input.asm"
        .include "kernel.asm"
        .include "render.asm"
        .include "data.asm"
        ; (the 2600 program, last in the file, may run into the video bank: Start copies it to
        ; $F000 before InitVideo clears that; the code and data before it may not)
        .cerror GameImage > VICBANK, "the program runs into the video bank"
        .cerror * > $9000, "the program file is too long"
