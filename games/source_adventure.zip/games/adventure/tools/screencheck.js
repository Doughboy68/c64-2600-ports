// Check the C64 picture against the 2600's. Runs the C64 version's ticks and Render (as in
// lockstep.js) next to tools/vcs.js, then draws the C64 frame in JavaScript from what Render
// set up (screen, characters, colours, sprite registers and the raster schedule, sprites
// simulated line by line with the VIC's rule that a sprite can only start again 43 lines
// after its last start when double height, 22 when not), and compares it pixel by pixel, in
// C64 colours, with the picture the 2600 draws: 2600 lines L0-L192 (rasters 55-247) and the
// black lines above them (rasters 51-54).
// With --noflicker (key 6 off) the C64 also shows the room's other objects: the 2600 picture is
// checked with them added, each laid out by tools/model.js as player 0 would be, in the C64's
// order (on the frame a buffer is filled for a new room, only the light: they come a frame later;
// behind the two the game shows, behind the thin walls; where the playfield is in front,
// behind it and the ball; the dark mazes' light lowest of all, in the characters). Frames where
// the C64 had no sprites left for one (DbgSkip) are counted, not checked.
//   node games/adventure/tools/screencheck.js [frames] [--seed=N] [--teleport] [--every=N] [--noflicker] [--show=<frame>] [--png=dir]
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 1000);
const showFrame = arg('show', -1), pngDir = arg('png', null);

const c64 = new C64();
c64.start(true);
const sym = n => c64.sym(n), M = c64.mem;
const COLORMAP = sym('ColorMap'), NSCHED = 16, LINE0RAS = 55, FIRST = 51, LAST = 247;
const S_REUSE = 2, S_END = 4;
const VIC = 0x4000;

const c64Picture = b => c64.picture(b, FIRST, LAST);
const noflicker = process.argv.includes('--noflicker');
if (noflicker) M[sym('Flicker')] = 0;
const { snap, model } = require('./model');
let kSnap = null;

// ---- the 2600: stop at the kernel's end; the picture is lines L0.. of this frame
const vcs = new VCS(rom);
vcs.wideDelay = true;
let atEnd = false, line0 = -1;
const origStep = vcs.step.bind(vcs);
vcs.step = function () {
  if (this.pc === 0xF058) line0 = this.line;
  if (this.pc === 0xF008) kSnap = snap(this);
  if (this.pc === 0xF0D1) atEnd = true;
  return origStep();
};
const runToKernelEnd = () => { atEnd = false; let g = 0; while (!atEnd) { vcs.step(); if (++g > 2e6) throw new Error('2600 never reached the kernel'); } };
function wantPicture() {
  const H = LAST - FIRST + 1, want = new Uint8Array(160 * H), ob = new Uint8Array(160 * H);
  for (let ras = FIRST; ras <= LAST; ras++) {
    const L = ras - LINE0RAS, o = (ras - FIRST) * 160;
    for (let x = 0; x < 160; x++) {
      if (L < 0) { want[o + x] = 0; continue; }
      const i = (line0 + L) * 160 + x;
      want[o + x] = M[COLORMAP + vcs.fb[i]];
      ob[o + x] = vcs.ob[i];
    }
  }
  return { want, ob };
}

// ---- flicker off: the room's other objects added to the 2600's picture
function addExtras(want, ob, lightOnly) {
  const R = a => (a >= 0xF000 ? rom[a - 0xF000] : a >= 0x80 && a < 0x100 ? vcs.ram[a - 0x80] : 0), W = a => R(a) | R(a + 1) << 8;
  const room = M[sym('ShownRoom')], obj0 = vcs.ram[0x15], obj1 = vcs.ram[0x16], prio = kSnap.ctrlpf & 4;
  const lightP1 = prio && obj1 === 0;                   // (then player 1 is in the characters, below every sprite)
  const colour = c => {               // (the game's Colour routine, $F2D3)
    let v = c >> 1;
    if (c & 1) v = vcs.ram[v];
    const idle = vcs.ram[0x66];
    if (idle & 0x80) v = (v ^ idle) & 0xFB;
    return M[COLORMAP + (v & 0x7F)];
  };
  const taken = new Uint8Array(want.length);           // 1 light, 2 an object
  for (let o = 0; o < 0xA2; o += 9) {
    if (o === obj0 || o === obj1) continue;
    const e = 0xFF44 + o, st = W(e);
    if (R(st) !== room) continue;
    const anim = R(W(e + 2)), list = W(e + 4);
    let y = 0; while (!(anim < R(list + y) || anim === R(list + y))) y += 3;
    const ptr = W(list + y + 1), col = colour(R(e + ((vcs.swchb & 8) ? 6 : 7))), nus = R(e + 8) | 0x10;
    const ram = Uint8Array.from(kSnap.ram), set = (a, v) => { ram[a - 0x80] = v; };
    set(0x86, R(st + 1)); set(0x87, R(st + 2)); set(0x82, ptr & 255); set(0x83, ptr >> 8); set(0x89, 0); set(0x8C, 0);
    const s2 = { ...kSnap, ram, nusiz: [nus, kSnap.nusiz[1]], oldEn: 0, enam: [0, 0] };
    const M2 = a => (a >= 0xF000 ? rom[a - 0xF000] : a >= 0x80 && a < 0x100 ? ram[a - 0x80] : 0);
    const res = model(s2, M2);
    const light = o === 0 && prio;
    if (lightOnly && !light) continue;
    for (let ras = LINE0RAS; ras <= LAST; ras++) for (let x = 0; x < 160; x++) {
      const L = ras - LINE0RAS, i = (ras - FIRST) * 160 + x;
      if (!(res.ob[L * 160 + x] & 1)) continue;
      const b = ob[i];
      if (light) { if (b === 0 && !taken[i]) { want[i] = col; taken[i] = 1; } continue; }
      if (taken[i] === 2 || b & (lightP1 ? 1 : 3)) continue;
      if (prio ? b & 48 : b & 12) continue;
      want[i] = col; taken[i] = 2;
    }
  }
}

// ---- PNG (C64 colours, 2 pixels per 2600 pixel)
const PEPTO = ['000000', 'FFFFFF', '96282E', '5BD6CE', '9F2DAD', '41B936', '2724C4', 'EFF347', '9F4815', '5E3500', 'DA5F66', '474747', '787878', '91FF84', '6864FF', 'AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));
const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; return c; });
const crc32 = buf => { let c = -1; for (const x of buf) c = CRC[(c ^ x) & 0xFF] ^ (c >>> 8); return (c ^ -1) >>> 0; };
function png(file, pics) {
  const LH = LAST - FIRST + 1, W = 320 * pics.length + 8 * (pics.length - 1), H = LH * 2, raw = Buffer.alloc((W * 3 + 1) * H);
  for (let y = 0; y < H; y++) for (let p = 0; p < pics.length; p++) for (let x = 0; x < 320; x++)
    raw.set(PEPTO[pics[p][(y >> 1) * 160 + (x >> 1)]], y * (W * 3 + 1) + 1 + (p * 328 + x) * 3);
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc32(td)); return Buffer.concat([l, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2;
  fs.writeFileSync(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
}
if (pngDir) fs.mkdirSync(pngDir, { recursive: true });

// ---- run
const play = require('./play')(arg('seed', 11), { teleport: process.argv.includes('--teleport'), every: arg('every', 0) });
const KINDS = { obj: 'players', wall: 'thin walls', ball: 'ball', pf: 'playfield', bg: 'background', extra: 'C64 only' };
const bad = {}, ex = {};
let checked = 0, lostStarts = 0, lastSkip = 0, skipped = 0;
for (let f = 0; f <= frames; f++) {
  const p = play(f, vcs.ram);
  for (const [a, v] of p.poke) { vcs.ram[a - 0x80] = v; M[a] = v; }
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  M[0x0280] = p.swcha; M[0x0282] = p.swchb; M[sym('inpt4')] = p.fire ? 0 : 0x80;
  runToKernelEnd();
  c64.call(sym('Tick'));
  M[sym('pending')] = 0;
  M[sym('curBuf')] ^= 1;
  c64.call(sym('Render'));
  if (f < 60) continue;
  const b = M[sym('curBuf')] ^ 1;                   // (Render drew into the buffer not shown)
  const c64p = c64Picture(b), { want, ob } = wantPicture();
  lostStarts += c64p.lost;
  if (noflicker) {
    const sk = M[sym('DbgSkip')];
    if (sk !== lastSkip) { lastSkip = sk; skipped++; continue; }
    addExtras(want, ob, M[sym('filled')]);           // (a new room's first frame: only the light)
  }
  checked++;
  const n = {}, first = {};
  for (let i = 0; i < want.length; i++) {
    if (want[i] === c64p.col[i]) continue;
    const o = ob[i];
    const k = o & 3 ? 'obj' : o & 12 ? 'wall' : o & 16 ? 'ball' : o & 32 ? 'pf' : c64p.what[i] >= 3 ? 'extra' : 'bg';
    n[k] = (n[k] || 0) + 1;
    const ras = FIRST + Math.floor(i / 160), x = i % 160;
    if (!first[k]) first[k] = `raster ${ras} (L${ras - LINE0RAS}) x ${x}: 2600 colour ${want[i]}, C64 ${c64p.col[i]} (sprite ${c64p.spr[i]})`;
    if (f === showFrame && n[k] <= 8) console.log(`  raster ${ras} x ${x}: 2600 objects ${o.toString(2)} colour ${want[i]}; C64 colour ${c64p.col[i]} sprite ${c64p.spr[i]}`);
  }
  for (const k of Object.keys(n)) { bad[k] = (bad[k] || 0) + 1; if (!ex[k]) ex[k] = `frame ${f} (room ${vcs.ram[0x0A].toString(16)}): ${n[k]} pixels, ${first[k]}`; }
  if (pngDir && (f === showFrame || (Object.keys(n).length && Object.values(bad).reduce((a, c) => a + c, 0) <= 6) || f % 500 === 0))
    png(path.join(pngDir, `f${String(f).padStart(5, '0')}.png`), [want, c64p.col]);
}
console.log(`${checked} frames checked${noflicker ? ` (flicker off; ${skipped} frames with an object that didn't fit not checked)` : ''}; sprite starts the VIC would miss: ${lostStarts}; C64 ${['DbgDrop', 'DbgOdd', 'DbgWrap'].map(k => `${k} ${M[sym(k)]}`).join(', ')}`);
for (const k of Object.keys(KINDS)) console.log(KINDS[k].padEnd(11), bad[k] ? `${bad[k]} frames differ, e.g. ${ex[k]}` : 'exact');
