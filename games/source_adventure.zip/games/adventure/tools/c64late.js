// How the C64 version keeps up in VICE: main-loop passes, passes that found more than one frame
// gone by (late), the most cycles a pass spent drawing / running the game / in all (debug
// counters DbgLoops .. DbgPMax), sprites left out (DbgDrop) and sprite reuses written too late
// (DbgSprLate). On the game number screen, then a game played walking about, jumping to a
// new room every couple of seconds (all rooms in turn: dark mazes, thin walls, castles).
// Only the VICE started here is closed; it uses a monitor port of its own.
//   node games/adventure/tools/c64late.js [seconds] [--ntsc] [--noflicker] [--png=dir]
const net = require('net');
const fs = require('fs');
const path = require('path');
const ntsc = process.argv.includes('--ntsc');
const seconds = +(process.argv.find(a => /^\d+$/.test(a)) || 30);
const pngArg = process.argv.find(a => a.startsWith('--png='));
const root = path.join(__dirname, '..');
const prgFile = require('../../../tools/buildname').files(path.join(root, 'build')).prg;
const lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(root, 'build')).lst, 'latin1');
const addr = n => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${n}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + n);
  return parseInt(m[1], 16);
};
const hex = v => v.toString(16);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
let vice = null, PORT = 0;
const mon = cmds => new Promise((resolve, reject) => {
  const s = net.connect(PORT, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d; }); s.on('error', reject);
  s.on('connect', async () => {
    await sleep(150);
    for (const c of cmds) { s.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 400); }
    s.write('x\n'); await sleep(100); s.end(); resolve(b);
  });
});
// all the counters in one monitor session (VICE stops answering if it is asked too often)
const VARS = [['passes', 'DbgLoops', 2], ['late', 'DbgLate', 2], ['draw', 'DbgRMax', 2], ['ticks', 'DbgTMax', 2], ['pass', 'DbgPMax', 2],
  ['drop', 'DbgDrop', 1], ['sprLate', 'DbgSprLate', 1], ['tops', 'DbgTops', 1], ['repeat', 'DbgRepeat', 1]];
const read = async () => {
  const lo = Math.min(...VARS.map(([, n]) => addr(n))), hi = Math.max(...VARS.map(([, n, len]) => addr(n) + len - 1));
  const o = await mon([`m ${hex(lo)} ${hex(hi)}`]);
  const mem = {};
  for (const m of o.matchAll(/>C:([0-9a-f]{4})((?:\s+[0-9a-f]{2}\b)+)/gi))
    m[2].trim().split(/\s+/).forEach((x, k) => { mem[parseInt(m[1], 16) + k] = parseInt(x, 16); });
  const r = {};
  for (const [k, n, len] of VARS) {
    const v = [...Array(len)].map((_, i) => mem[addr(n) + i]);
    if (v.some(x => x === undefined)) throw new Error('unexpected monitor reply: ' + JSON.stringify(o.slice(0, 300)));
    r[k] = len === 2 ? v[0] + 256 * v[1] : v[0];
  }
  return r;
};
const reset = () => mon([`> ${hex(addr('DbgRMax'))} 0 0 0 0 0 0`]);
const report = (name, a, b) => console.log(`${ntsc ? 'NTSC' : 'PAL'}${process.argv.includes('--noflicker') ? ', flicker off,' : ''} ${name}: ${b.passes - a.passes} passes, ${b.late - a.late} late; ` +
  `most cycles: drawing ${b.draw}, ticks ${b.ticks}, whole pass ${b.pass} (a frame has ${ntsc ? '17095' : '19656'}); sprites dropped ${(b.drop - a.drop) & 255}; sprite reuses too late ${(b.sprLate - a.sprLate) & 255}; frames shown twice ${(b.repeat - a.repeat) & 255}`);
const shot = async name => { if (pngArg) await mon([`screenshot "${path.join(pngArg.slice(6), name).split(path.sep).join('/')}" 2`]); };

(async () => {
  if (pngArg) fs.mkdirSync(pngArg.slice(6), { recursive: true });
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prgFile]);
  const loops = async () => { try { const r = await read(); return r.passes; } catch { return -1; } };
  for (let t = 0, last = -1; t < 40; t++) {          // until the main loop runs
    await sleep(1000);
    const n = await loops();
    if (last > 0 && n > last) break;
    last = n;
  }
  if (!await runsOurs(mon, prgFile)) throw new Error(`the VICE on port ${PORT} isn't running our build: stopping`);
  if (process.argv.includes('--noflicker')) await mon([`> ${hex(addr('Flicker'))} 0`]);
  await reset();
  const a = await read();
  await sleep(4000);
  const b = await read();
  report('game number screen', a, b);
  await shot('number.png');
  await mon([`> ${hex(addr('DbgINPT4'))} 7f`]); await sleep(500); await mon([`> ${hex(addr('DbgINPT4'))} ff`]);
  await sleep(2000);
  await reset();
  const c = await read();
  const t0 = Date.now();
  let seed = 1, room = 1, n = 0; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const DIRS = ['7f', 'bf', 'ef', 'df', 'af', '6f', '9f', '5f', 'ff'];
  while (Date.now() - t0 < seconds * 1000) {
    const cmds = [`> ${hex(addr('DbgSWCHA'))} ${DIRS[Math.floor(rnd() * DIRS.length)]}`, `> ${hex(addr('DbgINPT4'))} ${rnd() < .2 ? '7f' : 'ff'}`];
    if (++n % 5 === 0) { room = room % 0x1D + 1; cmds.push(`> 8a ${hex(room)}`, `> e2 ${hex(room)}`); }
    await mon(cmds);
    await sleep(300);
    if (n % 20 === 0) await shot(`play${String(n / 20).padStart(2, '0')}.png`);
  }
  const d = await read();
  report('play', c, d);
})().catch(e => console.log(e.message)).finally(() => stopVice(vice));
