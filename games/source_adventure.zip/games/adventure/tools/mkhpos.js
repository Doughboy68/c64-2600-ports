// Where the kernel's HPos routine (and the HMOVE after it) puts each object, for every X value:
// runs HPos in tools/vcs.js for A = 0-255 and objects 0 (P0), 1 (P1), 4 (ball); missiles are
// placed once at power-on (A = $0D for M0, $96 for M1). Writes tools/hpos.json:
// { p: [pixel for A] (players), bl: [pixel for A] (ball), m0, m1 }.
//   node games/adventure/tools/mkhpos.js
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const rom = require('../../../tools/rom').load('157bddb7192754a45372be196797f284');
const HPOS = 0xF0D2;

const v = new VCS(rom);
v.runFrames(2);
function place(a, x) {
  v.r[0x2B] = 0; v.tiaWrite(0x2B, 0);              // HMCLR
  v.a = a; v.x = x; v.y = 0; v.p = 0x24;
  v.push(0x12); v.push(0x33);                      // return to $1234 (never reached as code)
  v.pc = HPOS;
  while (v.pc !== 0x1234) v.step();
  v.tiaWrite(0x02, 0);                             // sta WSYNC
  v.tick(3);
  v.tiaWrite(0x2A, 0);                             // sta HMOVE
  return v.pos[x];
}
const p = [], p1 = [], bl = [];
for (let a = 0; a < 256; a++) { p.push(place(a, 0)); p1.push(place(a, 1)); bl.push(place(a, 4)); }
for (let a = 0; a < 256; a++) if (p[a] !== p1[a]) throw new Error(`P0 and P1 differ at ${a}`);
const out = { p, bl, m0: place(0x0D, 2), m1: place(0x96, 3) };
fs.writeFileSync(path.join(__dirname, 'hpos.json'), JSON.stringify(out));
console.log('m0', out.m0, 'm1', out.m1);
console.log('players:', p.map((v, a) => `${a}:${v}`).filter((_, a) => a % 16 === 0 || a < 4 || (a > 155 && a < 165)).join(' '));
console.log('ball - player:', [...new Set(bl.map((v, a) => (v - p[a] + 160) % 160))].join(','));
