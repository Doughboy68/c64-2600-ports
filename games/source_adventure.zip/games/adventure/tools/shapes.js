// What InitShapes made: the shapes with sprite blocks made at start-up (testing aid).
//   node games/adventure/tools/shapes.js
const { C64 } = require('./c64sim');
const c64 = new C64();
c64.start(true);
const M = c64.mem, S = n => c64.sym(n);
const n = M[S('nStatic')];
console.log(`${n} shapes`);
for (let i = 0; i < n; i++) {
  const ptr = M[S('ShLo') + i] | M[S('ShHi') + i] << 8;
  console.log(`$${ptr.toString(16)} quad ${M[S('ShQ') + i]} first block ${M[S('ShBlk') + i]} segments ${M[S('ShSeg') + i]}`);
}
