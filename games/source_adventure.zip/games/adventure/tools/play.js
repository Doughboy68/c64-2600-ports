// Random play for the test tools: joystick runs, the fire button, now and then the console
// switches; optionally (teleport) every few hundred frames the player and some objects jump
// to a random room, to reach every room and object quickly. The same seed gives the same game.
//   const play = require('./play')(seed, { teleport })
//   each frame: const p = play(frame, ram)  ->  { swcha, swchb, fire, poke: [[addr, value], ...] }
module.exports = (seed = 1, opts = {}) => {
  let s = seed;
  const rnd = n => { s = (s * 1103515245 + 12345) & 0x7FFFFFFF; return s % n; };
  const DIRS = [0xFF, 0xEF, 0xDF, 0xBF, 0x7F, 0xAF, 0x6F, 0x9F, 0x5F];
  let joy = 0xFF, hold = 0, fire = false, swchb = 0x0B, reset = 0, select = 0;
  // start: a game number 1-3, then Game Reset
  const level = rnd(3);
  const OBJS = [0xA4, 0xA9, 0xAE, 0xB3, 0xB6, 0xB9, 0xBC, 0xBF, 0xC2, 0xC5, 0xCB, 0xA1];
  return (f, ram) => {
    const poke = [];
    if (f >= 10 && f < 10 + 12 * level && (f - 10) % 12 < 4) select = 1;
    else select = 0;
    if (f >= 50 && f < 54) reset = 1;
    if (f >= 60) {
      if (--hold <= 0) {
        joy = DIRS[rnd(DIRS.length)]; hold = 10 + rnd(80);
        fire = rnd(6) === 0;
        if (rnd(40) === 0) swchb ^= 0x40 << rnd(2);        // difficulty switches
        if (rnd(300) === 0) swchb ^= 0x08;                 // colour / B&W
        if (rnd(150) === 0) reset = 3;                     // Game Reset (back to the castle)
      }
      const every = opts.every || 300;
      if (opts.teleport && f % every === every >> 1) {
        const room = opts.every ? 1 + (Math.floor(f / every) % 0x1D) : 1 + rnd(0x1D);
        poke.push([0x8A, room], [0xE2, room]);
        for (const o of OBJS)
          if (rnd(3) === 0) poke.push([o, room], [o + 1, 10 + rnd(140)], [o + 2, 10 + rnd(100)]);
      }
    }
    let b = swchb;
    if (reset > 0) { b &= ~1; if (f >= 60) reset--; }
    if (f >= 54 && f < 60) reset = 0;
    if (select) b &= ~2;
    return { swcha: (f >= 60 ? joy & 0xF0 : 0xF0) | 0x0F, swchb: b, fire: f >= 60 && fire, poke };
  };
};
