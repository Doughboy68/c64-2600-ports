// The C64 version's code on a plain 6502 (the 6502 core of tools/vcs.js) with 64K of RAM,
// for lockstep.js and screencheck.js. $D000-$DFFF is I/O when the CPU port ($01) says so;
// I/O writes land in `io`. Set up like Start: the patched game copied to $F000, video set up.
const fs = require('fs');
const path = require('path');
const { VCS } = require('../../../tools/vcs');
const NSCHED = 16, S_REUSE = 2, S_END = 4, VIC = 0x4000;
const ROMMD5 = '157bddb7192754a45372be196797f284';
const rom = require('../../../tools/rom').load(ROMMD5);
const build = path.join(__dirname, '..', 'build');

class C64 extends VCS {
  constructor() {
    super(rom);
    this.mem = new Uint8Array(65536);
    this.io = new Uint8Array(4096);
    const prg = fs.readFileSync(require('../../../tools/buildname').files(path.join(build)).prg);
    this.lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(build)).lst, 'latin1');
    this.mem.set(prg.subarray(2), prg.readUInt16LE(0));
  }
  ioOn() { return (this.mem[1] & 3) !== 0 && (this.mem[1] & 4) !== 0; }
  read(a) { a &= 0xFFFF; return a >= 0xD000 && a < 0xE000 && this.ioOn() ? this.io[a - 0xD000] : this.mem[a]; }
  write(a, v) { a &= 0xFFFF; if (a >= 0xD000 && a < 0xE000 && this.ioOn()) this.io[a - 0xD000] = v; else this.mem[a] = v; }
  commit() {} flush() {} tick(n) { this.cycles += n; }
  sym(name) {
    const m = this.lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
    if (!m) throw new Error('no symbol ' + name);
    return parseInt(m[1], 16);
  }
  call(addr, limit = 3e6) {      // JSR addr from a stub, run until it returns
    const STUB = 0x0300;
    this.mem.set([0x20, addr & 255, addr >> 8, 0x4C, 0x03, 0x03], STUB);
    this.pc = STUB;
    const start = this.cycles;
    for (let i = 0; this.pc !== STUB + 3; i++) { this.step(); if (i > limit) throw new Error('runaway at $' + this.pc.toString(16)); }
    return this.cycles - start;
  }
  // The C64 picture of buffer b as Render set it up, drawn line by line like the VIC (sprites
  // start again only 43 lines after their last start when double height, 22 when not):
  // C64 colours for rasters FIRST..LAST, 160 pixels each.
  picture(b, FIRST = 51, LAST = 247) {
    const M = this.mem, sym = n => this.sym(n);
    const H = LAST - FIRST + 1;
    const col = new Uint8Array(160 * H), what = new Uint8Array(160 * H), spr = new Int8Array(160 * H).fill(-1);
    const scr = VIC + (b ? 0x400 : 0), chars = VIC + (b ? 0x1000 : 0x800);
    const bg = M[sym('StBg') + b], c1 = M[sym('StC1') + b], c2 = M[sym('StC2') + b];
    const en = M[sym('StEn') + b], msb = M[sym('StMsb') + b], yexp = M[sym('StYexp') + b], pri = M[sym('StPri') + b];
    const regs = [...Array(8)].map((_, n) => ({
      en: (en >> n) & 1, x: M[sym('StX') + 8 * b + n] + ((msb >> n) & 1) * 256, y: M[sym('StY') + 8 * b + n],
      ptr: M[sym('StPtr') + 8 * b + n], col: M[sym('StCol') + 8 * b + n], yexp: (yexp >> n) & 1, pri: (pri >> n) & 1, start: -1, last: -999,
    }));
    const changes = [];
    for (let i = 1; i < NSCHED; i++) {
      const e = b * NSCHED + i, type = M[sym('SchedType') + e], ras = M[sym('SchedRas') + e];
      if (type === S_END) break;
      if (type === S_REUSE) { const a = M[sym('SchedArg') + e]; changes.push({ ras, n: M[sym('RuSpr') + a], y: M[sym('RuY') + a], ptr: M[sym('RuPtr') + a] }); }
    }
    let ci = 0, lost = 0;
    for (let ras = 48; ras <= LAST; ras++) {
      while (ci < changes.length && changes[ci].ras < ras) { const c = changes[ci++]; Object.assign(regs[c.n], { y: c.y, ptr: c.ptr }); }
      // sprite starts: the VIC compares Y with the line in its cycle 55 and shows the sprite from
      // the next line, if its last start's rows are done (43 lines double height, 22 single)
      for (const s of regs) {
        if (!s.en) continue;
        const len = s.yexp ? 42 : 21;
        if (s.start >= 0 && ras - s.start >= len) s.start = -1;
        if (s.y + 1 === ras) { if (s.start < 0 && ras - s.last >= len + 1) { s.start = ras; s.last = ras; } else lost++; }
      }
      if (ras < FIRST) continue;
      const row = (ras - 48) >> 3, li = (ras - 48) & 7, o = (ras - FIRST) * 160;
      for (let x = 0; x < 160; x++) {
        const ch = M[scr + row * 40 + (x >> 2)], byte = M[chars + ch * 8 + li], pair = (byte >> (6 - 2 * (x & 3))) & 3;
        col[o + x] = [bg, c1, c2, 0][pair]; what[o + x] = pair >= 2 ? 2 : pair;
      }
      for (let x = 0; x < 160; x++) {               // the lowest numbered sprite with a pixel here wins
        for (let n = 0; n < 8; n++) {
          const s = regs[n];
          if (s.start < 0) continue;
          const j = x - ((s.x - 24) >> 1);
          if (j < 0 || j >= 24) continue;
          const r = s.yexp ? (ras - s.start) >> 1 : ras - s.start;
          const byte = M[VIC + s.ptr * 64 + 3 * r + (j >> 3)];
          if (!(byte & (0x80 >> (j & 7)))) continue;
          if (!(s.pri && what[o + x] === 2)) { col[o + x] = s.col; what[o + x] = 3 + n; spr[o + x] = n; }
          break;
        }
      }
    }
    return { col, what, spr, lost };
  }
  // what Start does that matters here
  start(pal = true) {
    const m = this.mem, img = this.sym('GameImage');
    this.s = 0xDF;
    this.p = 0x20;                // interrupts on, as at the end of Start (there are none here)
    m[1] = 0x35;
    m.copyWithin(0xF000, img, img + 0x1000);
    const w = (a, v) => { m[a] = v & 255; m[a + 1] = v >> 8; };
    w(0xFFFA, this.sym('Nmi')); w(0xFFFE, this.sym('Irq'));
    m[0x0280] = 0xFF; m[0x0282] = 0x0B; m[0x0284] = 0; m[0x3C] = 0x80;
    m[this.sym('inpt4')] = 0x80;
    m[this.sym('firstTick')] = 1;
    m[this.sym('switches')] = 0x0B;
    m[this.sym('isPal')] = pal ? 1 : 0;
    this.call(this.sym('InitVideo'));
    this.call(this.sym('InitRooms'));
    this.call(this.sym('InitShapes'));
  }
}
module.exports = { C64, rom, ROMMD5 };
