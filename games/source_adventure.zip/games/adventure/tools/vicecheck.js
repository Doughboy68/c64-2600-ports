// Does VICE show what the picture check (c64sim's picture()) says the C64 shows? Starts a game
// in VICE and in the simulator the same way (fire on the number screen, then nothing: the
// first room is still), screenshots VICE, and compares it pixel by pixel with the simulated
// C64 picture; also tries the screenshot shifted by a few pixels each way, to tell an offset
// from a difference. Only the VICE started here is closed; it uses a monitor port of its own.
//   node games/adventure/tools/vicecheck.js [outdir] [--ntsc] [--room=N]
const fs = require('fs');
const net = require('net');
const path = require('path');
const zlib = require('zlib');
const { C64 } = require('./c64sim');
const ntsc = process.argv.includes('--ntsc');
const out = path.resolve(process.argv.slice(2).find(a => !a.startsWith('--')) || '.');
const roomArg = (process.argv.find(a => a.startsWith('--room=')) || '').slice(7);
const root = path.join(__dirname, '..');
const prgFile = require('../../../tools/buildname').files(path.join(root, 'build')).prg;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
let vice = null, PORT = 0;
const mon = cmds => new Promise((resolve, reject) => {
  const s = net.connect(PORT, '127.0.0.1'); let b = '';
  s.on('data', d => { b += d; }); s.on('error', reject);
  s.on('connect', async () => {
    await sleep(150);
    for (const c of cmds) { s.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 300); }
    s.write('x\n'); await sleep(100); s.end(); resolve(b);
  });
});

// ---- the simulator: the same start
const c64 = new C64();
c64.start(!ntsc);
const M = c64.mem, sym = n => c64.sym(n);
let pic = null;
for (let f = 0; f < 200; f++) {
  M[0x0280] = 0xFF; M[0x0282] = 0x0B;
  M[sym('inpt4')] = 0x80;
  if (f >= 30 && f < 34) M[0x0282] = 0x0A;                      // Game Reset (as fire on the number screen)
  if (roomArg && f === 100) { M[0x8A] = +roomArg; M[0xE2] = +roomArg; }
  c64.call(sym('Tick'));
  M[sym('pending')] = 0;
  M[sym('curBuf')] ^= 1;
  c64.call(sym('Render'));
  if (f === 199) pic = c64.picture(M[sym("curBuf")] ^ 1, 51, 247);
}

// ---- PNG reading (8-bit RGB or RGBA)
function readPng(f) {
  const b = fs.readFileSync(f);
  let p = 8, w, h, ct, idat = [];
  while (p < b.length) {
    const len = b.readUInt32BE(p), type = b.toString('ascii', p + 4, p + 8), d = b.subarray(p + 8, p + 8 + len);
    if (type === 'IHDR') { w = d.readUInt32BE(0); h = d.readUInt32BE(4); ct = d[9]; }
    if (type === 'IDAT') idat.push(d);
    p += 12 + len;
  }
  const raw = zlib.inflateSync(Buffer.concat(idat)), bpp = ct === 6 ? 4 : 3, px = Buffer.alloc(w * h * 3);
  let prev = Buffer.alloc(w * bpp);
  for (let y = 0; y < h; y++) {
    const f = raw[y * (w * bpp + 1)], line = Buffer.from(raw.subarray(y * (w * bpp + 1) + 1, (y + 1) * (w * bpp + 1)));
    for (let x = 0; x < w * bpp; x++) {
      const a = x >= bpp ? line[x - bpp] : 0, up = prev[x], c = x >= bpp ? prev[x - bpp] : 0;
      const pa = Math.abs(up - c), pb = Math.abs(a - c), pc = Math.abs(a + up - 2 * c);
      line[x] = (line[x] + [0, a, up, (a + up) >> 1, pa <= pb && pa <= pc ? a : pb <= pc ? up : c][f]) & 255;
    }
    for (let x = 0; x < w; x++) for (let k = 0; k < 3; k++) px[(y * w + x) * 3 + k] = line[x * bpp + k];
    prev = line;
  }
  return { w, h, px };
}
const PAL = ['000000', 'FFFFFF', '96282E', '5BD6CE', '9F2DAD', '41B936', '2724C4', 'EFF347', '9F4815', '5E3500', 'DA5F66', '474747', '787878', '91FF84', '6864FF', 'AEAEAE'].map(h => [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)));

(async () => {
  fs.mkdirSync(out, { recursive: true });
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prgFile]);
  await sleep(7000);
  if (!await runsOurs(mon, prgFile)) throw new Error(`the VICE on port ${PORT} isn't running our build: stopping`);
  await mon([`> ${sym('DbgINPT4').toString(16)} 7f`]); await sleep(400); await mon([`> ${sym('DbgINPT4').toString(16)} ff`]);
  await sleep(1500);
  if (roomArg) { await mon([`> 8a ${(+roomArg).toString(16)}`, `> e2 ${(+roomArg).toString(16)}`]); await sleep(1500); }
  const file = path.join(out, `vice-${ntsc ? 'ntsc' : 'pal'}.png`);
  await mon([`screenshot "${file.split(path.sep).join('/')}" 2`]);
  stopVice(vice); vice = null;
  const img = readPng(file);
  // palette: each screenshot colour -> nearest C64 colour
  const cmap = new Map();
  const c64col = (x, y) => {
    const i = (y * img.w + x) * 3, k = img.px[i] << 16 | img.px[i + 1] << 8 | img.px[i + 2];
    if (!cmap.has(k)) { let best = 0, bd = 1e9; PAL.forEach((p, n) => { const d = (p[0] - img.px[i]) ** 2 + (p[1] - img.px[i + 1]) ** 2 + (p[2] - img.px[i + 2]) ** 2; if (d < bd) { bd = d; best = n; } }); cmap.set(k, best); }
    return cmap.get(k);
  };
  // the screenshot's display window: raster 51 and C64 pixel 0 at (X0, Y0) for VICE's default borders
  const X0 = 32, Y0 = ntsc ? 23 : 35;
  const compare = (dx, dy) => {
    let bad = 0, first = null;
    for (let r = 0; r < 197; r++) for (let x = 0; x < 320; x++) {
      const want = pic.col[r * 160 + (x >> 1)], got = c64col(X0 + x + dx, Y0 + r + dy);
      if (want !== got) { bad++; if (!first) first = `raster ${51 + r} x ${x}: sim ${want} VICE ${got}`; }
    }
    return { bad, first };
  };
  const res = compare(0, 0);
  console.log(`${ntsc ? 'NTSC' : 'PAL'}: ${res.bad} of 63040 pixels differ (rasters 51-247)${res.first ? ', first at ' + res.first : ''}`);
  if (res.bad) for (const [dx, dy] of [[-2, 0], [2, 0], [0, -1], [0, 1], [-1, 0], [1, 0]]) console.log(`  shifted ${dx},${dy}: ${compare(dx, dy).bad}`);
})().catch(e => { console.log(e.message); stopVice(vice); });
