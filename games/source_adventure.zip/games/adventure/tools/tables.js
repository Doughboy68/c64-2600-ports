// Dumps Adventure's ROM tables: the object list (9 bytes each at $FF44), the room list
// (5 bytes each at $FE1B) and each object's shapes.
//   node games/adventure/tools/tables.js [--shapes]
const rom = require('../../../tools/rom').load('157bddb7192754a45372be196797f284');
const M = a => rom[a - 0xF000], W = a => M(a) | M(a + 1) << 8;
const h = (v, n = 2) => '$' + v.toString(16).toUpperCase().padStart(n, '0');

console.log('Objects (number: state RAM, anim byte, shape list, colour, B&W, NUSIZ)');
for (let n = 0; n < 0xA2; n += 9) {
  const e = 0xFF44 + n;
  const st = W(e), an = W(e + 2), gl = W(e + 4);
  // shape list: (state limit, pointer) triples, ends where state <= limit
  const list = [];
  for (let i = 0; i < 24; i += 3) { list.push(`${h(M(gl + i))}:${h(W(gl + i + 1), 4)}`); if (M(gl + i) === 0xFF) break; }
  console.log(`${h(n)} state ${h(st, 4)} anim ${h(an, 4)} col ${h(M(e + 6))} bw ${h(M(e + 7))} nusiz ${h(M(e + 8))} shapes ${list.join(' ')}`);
  if (process.argv.includes('--shapes')) {
    for (let i = 0; i < 24; i += 3) {
      let p = W(gl + i + 1), rows = [];
      for (let k = 0; k < 40 && M(p + k); k++) rows.push(M(p + k).toString(2).padStart(8, '0').replace(/0/g, '.').replace(/1/g, '#'));
      console.log('   ', h(W(gl + i + 1), 4), rows.length, 'rows'); rows.forEach(r => console.log('     ', r));
      if (M(gl + i) === 0xFF) break;
    }
  }
}
console.log('\nRooms (number: playfield, colour, B&W, CTRLPF, exits up right down left)');
for (let r = 0; r < 0x1E; r++) {
  const e = 0xFE1B + r * 9;
  console.log(`${h(r)} pf ${h(W(e), 4)} col ${h(M(e + 2))} bw ${h(M(e + 3))} ctrl ${h(M(e + 4))} exits ${[5, 6, 7, 8].map(i => h(M(e + i))).join(' ')}`);
}
