// A model of what Adventure's kernel draws, and the collisions the game then reads, built
// only from RAM and the TIA settings in place when the kernel starts. Checked pixel by pixel
// against tools/vcs.js, and each collision register the game reads against the model's.
// The C64 version draws and collides by the same rules, so this is where they are proven.
//   node games/adventure/tools/model.js [frames] [--seed=N] [--verbose] [--teleport]
//   (--teleport: every few hundred frames put the player in a random room with random
//   objects, to reach every room and object quickly)
'use strict';
const { VCS } = require('../../../tools/vcs');
const ROM = require('../../../tools/rom').load('157bddb7192754a45372be196797f284');
const HPOS = require('./hpos.json');

const KERNEL = 0xF008, LINE0 = 0xF058;
const NLINES = 194;                      // kernel lines L0 (old ball, playfield row 0) .. L193
const LAST = NLINES - 1;
const LAST_VBLANK_X = 4;                 // L193: VBLANK from this pixel (sta VBLANK ends at cycle 24)
const LAST_GRP_X = 37;                   // L193: players off from this pixel (sta GRP0 ends at cycle 35)
const COPIES = [[0], [0, 16], [0, 32], [0, 16, 32], [0, 64], [0], [0, 32, 64], [0]];

// ---- snapshot of the state the kernel starts from (RAM, and TIA registers the game set)
function snap(v) {
  const r = v.r;
  return {
    ram: Uint8Array.from(v.ram),
    nusiz: [r[4], r[5]], ctrlpf: r[0xA], enam: [r[0x1D], r[0x1E]], refp: [r[0xB], r[0xC]],
    oldEn: r[0x1F], oldPF: [r[0xD], r[0xE], r[0xF]],
    colu: [r[6], r[7], r[8], r[9]],
  };
}

// ---- the kernel, line by line: what each of lines L0-L193 shows
// Each line: { pf: [PF0, PF1, PF2], en, g0, g1, pfAt: [x, x, x] (pixels from which this line
// shows pf[i]; to the left it shows prevPF[i]), prevPF }
function kernelLines(s, M) {
  const R = a => s.ram[a - 0x80];
  const pfPtr = R(0x80) | R(0x81) << 8, p0Ptr = R(0x82) | R(0x83) << 8, p1Ptr = R(0x84) | R(0x85) << 8;
  const p0Y = R(0x87), p1Y = R(0x89), ballTop = (R(0x8C) - 4) & 0xFF;
  const lines = [];
  let pfIndex = 0, r90 = 0, r91 = 0;
  let pf = [M(pfPtr), M(pfPtr + 1), M(pfPtr + 2)];
  pfIndex = 3;
  let en = s.oldEn, g0 = 0, g1 = 0, g1reg = 0;
  lines.push({ pf: pf.slice(), en, g0, g1 });                      // L0
  for (let v = 0x68; v >= 8; v--) {
    if (v !== 0x68 && ((v - p1Y) & 0x80)) {                        // line 2k: GRP1 (vertically delayed)
      const g = M(p1Ptr + r91); g1reg = g; if (g) r91 = (r91 + 1) & 0xFF;
    }
    let x = 0;
    if ((v - p0Y) & 0x80) { x = M(p0Ptr + r90); if (x) r90 = (r90 + 1) & 0xFF; }
    en = ((v - ballTop) & 0xFC) === 0 ? 2 : 0;
    g0 = x; g1 = g1reg;
    const line = { pf: pf.slice(), en, g0, g1 };
    if ((v & 0x0F) === 0) {                                        // a new playfield row, written mid-line
      const lo = pfPtr & 0xFF, cross = i => (lo + pfIndex + i > 0xFF ? 1 : 0);
      const c0 = cross(0), c1 = cross(1), c2 = cross(2);
      line.prevPF = pf.slice();
      pf = [M(pfPtr + pfIndex), M(pfPtr + pfIndex + 1), M(pfPtr + pfIndex + 2)];
      pfIndex += 3;
      line.pf = pf.slice();
      line.pfAt = [3 * (17 + c0) - 68, 3 * (27 + c0 + c1) - 68, 3 * (37 + c0 + c1 + c2) - 68];
    }
    lines.push(line);                                              // line 2k+1
    if (v > 8) lines.push({ pf: pf.slice(), en, g0, g1 });         // line 2k+2
  }
  const ram = { 0x8D: ballTop, 0x8E: 7, 0x8F: pfIndex, 0x90: r90, 0x91: r91 };
  return { lines, ram, lastPF: pf, lastEn: en };
}

// ---- TIA pixel rules (as tools/vcs.js)
function playerBit(g, nusiz, refp, pos, x) {
  if (!g) return 0;
  // (double and quad width players start a pixel later on the real TIA: tools/vcs.js wideDelay)
  const n = nusiz & 7, scale = n === 5 ? 2 : n === 7 ? 4 : 1, d = (x - pos - (scale > 1 ? 1 : 0) + 160) % 160;
  for (const c of COPIES[n]) {
    const dd = d - c;
    if (dd >= 0 && dd < 8 * scale) { let b = Math.floor(dd / scale); if (!(refp & 8)) b = 7 - b; return (g >> b) & 1; }
  }
  return 0;
}
function missileBit(en, nusiz, pos, x) {
  if (!(en & 2)) return 0;
  const w = 1 << ((nusiz >> 4) & 3), d = (x - pos + 160) % 160;
  return COPIES[nusiz & 7].some(c => d - c >= 0 && d - c < w) ? 1 : 0;
}
function ballBit(en, ctrlpf, pos, x) {
  if (!(en & 2)) return 0;
  return (x - pos + 160) % 160 < 1 << ((ctrlpf >> 4) & 3) ? 1 : 0;
}
function pfBit(pf, ctrlpf, x) {
  let c = x >> 2;
  if (c >= 20) c = ctrlpf & 1 ? 39 - c : c - 20;
  if (c < 4) return (pf[0] >> (4 + c)) & 1;
  if (c < 12) return (pf[1] >> (11 - c)) & 1;
  return (pf[2] >> (c - 12)) & 1;
}

// Object bits of one pixel: 1 P0, 2 P1, 4 M0, 8 M1, 16 BL, 32 PF
function pixelBits(s, st, x, pos) {
  let pf = st.pf;
  if (st.pfAt) pf = [0, 1, 2].map(i => (x < st.pfAt[i] ? st.prevPF[i] : st.pf[i]));
  const players = st.playersUntil === undefined || x < st.playersUntil;
  return (players ? playerBit(st.g0, s.nusiz[0], s.refp[0], pos.p0, x) : 0)
    | (players ? playerBit(st.g1, s.nusiz[1], s.refp[1], pos.p1, x) << 1 : 0)
    | missileBit(s.enam[0], s.nusiz[0], pos.m0, x) << 2
    | missileBit(s.enam[1], s.nusiz[1], pos.m1, x) << 3
    | ballBit(st.en, s.ctrlpf, pos.bl, x) << 4
    | pfBit(pf, s.ctrlpf, x) << 5;
}

// ---- the model: the picture (object bits for L0-L193, 0 where VBLANK hides it) and the
// collision latches the game reads after the kernel (bit order as tools/vcs.js)
const PAIRS = [[4, 2], [4, 1], [8, 1], [8, 2], [1, 32], [1, 16], [2, 32], [2, 16], [4, 32], [4, 16], [8, 32], [8, 16], [16, 32], [1, 2], [4, 8]];
function cxOf(o) { let c = 0; if (o & (o - 1)) PAIRS.forEach(([a, b], i) => { if ((o & a) && (o & b)) c |= 1 << i; }); return c; }

function model(s, M) {
  const R = a => s.ram[a - 0x80];
  const pos = { p0: HPOS.p[R(0x86)], p1: HPOS.p[R(0x88)], bl: HPOS.bl[R(0x8B)], m0: HPOS.m0, m1: HPOS.m1 };
  const k = kernelLines(s, M);
  const ob = new Uint8Array(160 * NLINES);
  let cx = 0;
  // before L0: whole lines with last frame's playfield and ball enable, everything at its new place
  const pre = { pf: s.oldPF, en: s.oldEn, g0: 0, g1: 0 };
  for (let x = 0; x < 160; x++) cx |= cxOf(pixelBits(s, pre, x, pos));
  k.lines.forEach((st, y) => {
    if (y === LAST) st = { ...st, playersUntil: LAST_GRP_X };
    for (let x = 0; x < 160; x++) {
      const o = pixelBits(s, st, x, pos);
      cx |= cxOf(o);
      if (y < LAST || x < LAST_VBLANK_X) ob[y * 160 + x] = o;
    }
  });
  // after the picture: the last playfield row and ball enable stay, players are off
  const post = { pf: k.lastPF, en: k.lastEn, g0: 0, g1: 0 };
  for (let x = 0; x < 160; x++) cx |= cxOf(pixelBits(s, post, x, pos));
  return { ob, cx, ram: k.ram, lines: k.lines, pos };
}

// TIA read registers $00-$07 from the 15 latches
function cxReg(cx, a) {
  const b = i => (cx >> i) & 1;
  return [b(0) << 7 | b(1) << 6, b(2) << 7 | b(3) << 6, b(4) << 7 | b(5) << 6, b(6) << 7 | b(7) << 6,
    b(8) << 7 | b(9) << 6, b(10) << 7 | b(11) << 6, b(12) << 7, b(13) << 7 | b(14) << 6][a & 7];
}

module.exports = { snap, model, kernelLines, cxReg, pixelBits, NLINES, HPOS };

// ---------------------------------------------------------------- the check
if (require.main === module) {
  const frames = +(process.argv[2] || 3000);
  const opt = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? a.split('=')[1] : d; };
  const verbose = process.argv.includes('--verbose'), teleport = process.argv.includes('--teleport');
  let seed = +opt('seed', 1);
  const rnd = n => { seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF; return seed % n; };
  const v = new VCS(ROM);
  v.wideDelay = true;
  const M = a => (a >= 0xF000 ? ROM[a - 0xF000] : a >= 0x80 && a < 0x100 ? v.ram[a - 0x80] : 0);

  let cur = null, prevKernel = null, line0 = -1, errors = 0, checked = 0, reads = 0, readErr = 0;
  const preLines = {};                                   // full lines between CXCLR and L0 (histogram)
  let cxclrLine = -1;
  const origRead = v.tiaRead.bind(v);
  v.tiaRead = a => {
    const val = origRead(a);
    if (cur && (a & 0x0F) < 8 && v.lastPc !== undefined) {
      reads++;
      const want = cxReg(cur.res.cx, a & 0x0F);
      if (want !== val) {
        readErr++;
        if (readErr <= 10) console.log(`frame ${v.frames}: read $${(a & 0xF).toString(16)} at $${v.lastPc.toString(16)}: TIA ${val.toString(16)}, model ${want.toString(16)}`);
      }
    }
    return val;
  };
  const origWrite = v.tiaWrite.bind(v);
  v.tiaWrite = (a, val) => { if (a === 0x2C) cxclrLine = v.line; origWrite(a, val); };

  const compare = () => {
    if (!cur || line0 < 0) return;
    checked++;
    let bad = 0, first = null;
    for (let y = 0; y < NLINES; y++) for (let x = 0; x < 160; x++) {
      const got = v.ob[(line0 + y) * 160 + x], want = cur.res.ob[y * 160 + x];
      if (got !== want) { bad++; if (!first) first = { y, x, got, want }; }
    }
    if (bad) {
      errors++;
      if (errors <= 10 || verbose) console.log(`frame ${v.frames}: ${bad} pixels differ, first L${first.y} x${first.x}: TIA ${first.got} model ${first.want} (room ${cur.s.ram[0x0A].toString(16)})`);
    }
  };

  // drive: random joystick runs, fire, occasional switches
  let joy = 0xFF, hold = 0;
  const step = () => {
    v.step();
    if (v.pc === KERNEL) {
      compare();
      const s = snap(v);
      cur = { s, res: model(s, M) };
      line0 = -1;
    } else if (v.pc === LINE0 && cur) {
      line0 = v.line;
      const n = line0 - cxclrLine - 1;
      preLines[n] = (preLines[n] || 0) + 1;
    }
  };
  // start game 1..3
  v.runFrames(5);
  const press = (bit, f) => { v.swchb &= ~bit; for (let i = 0; i < f; i++) runFrame(); v.swchb |= bit; };
  const runFrame = () => { const t = v.frames + 1; while (v.frames < t) step(); };
  for (let i = 0, n = rnd(3); i < n; i++) { press(2, 3); for (let j = 0; j < 4; j++) runFrame(); }
  press(1, 3);
  const ROOMS = 0x1E;
  for (let f = 0; f < frames; f++) {
    if (--hold <= 0) {
      const dirs = [0xFF, 0xEF, 0xDF, 0xBF, 0x7F, 0xAF, 0x6F, 0x9F, 0x5F];
      joy = dirs[rnd(dirs.length)]; hold = 10 + rnd(80);
      v.fire[0] = rnd(6) === 0;
      if (rnd(40) === 0) v.swchb ^= 0x40 << rnd(2);              // difficulty switches
      if (rnd(200) === 0) v.swchb ^= 0x08;                       // colour / B&W
      if (rnd(150) === 0) press(1, 2);                           // Game Reset
    }
    v.swcha = (joy & 0xF0) | 0x0F;
    if (teleport && f % 300 === 150) {                           // random room, objects nearby
      const room = 1 + rnd(ROOMS - 1);
      v.ram[0x8A - 0x80] = room; v.ram[0xE2 - 0x80] = room;
      for (const o of [0xA4, 0xA9, 0xAE, 0xB3, 0xB6, 0xB9, 0xBC, 0xBF, 0xC2, 0xC5, 0xCB, 0xA1])
        if (rnd(3) === 0) { v.ram[o - 0x80] = room; v.ram[o + 1 - 0x80] = 10 + rnd(140); v.ram[o + 2 - 0x80] = 10 + rnd(100); }
    }
    runFrame();
  }
  console.log(`${checked} frames checked: ${errors} with differences; ${reads} collision reads, ${readErr} differ`);
  console.log('full lines between CXCLR and L0:', JSON.stringify(preLines));
  process.exit(errors || readErr ? 1 : 0);
}
