// The player inside a dead dragon: does the 2600 let it walk out, and does the C64 version do
// exactly the same? Starts game 1 on both (tools/vcs.js and the C64 code on c64sim), puts the
// yellow dragon, dead, over the player in room 3 (the sword beside it), then pushes the
// joystick each way for a while and reports where the player ends up on each machine.
//   node games/adventure/tools/stuck.js
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const vcs = new VCS(rom);
vcs.wideDelay = true;
const c64 = new C64();
c64.start(true);
const sym = n => c64.sym(n), M = c64.mem;
let atEnd = false;
const st = vcs.step.bind(vcs);
vcs.step = function () { if (this.pc === 0xF0D1) atEnd = true; return st(); };
const frame = (swcha, swchb = 0x0B) => {
  vcs.swcha = swcha; vcs.swchb = swchb; vcs.fire[0] = false;
  atEnd = false; while (!atEnd) vcs.step();
  M[0x0280] = swcha; M[0x0282] = swchb; M[sym('inpt4')] = 0x80;
  c64.call(sym('Tick'));
};
const poke = (a, v) => { vcs.ram[a - 0x80] = v; M[a] = v; };
for (let f = 0; f < 60; f++) frame(0xFF, f >= 30 && f < 34 ? 0x0A : 0x0B);   // Game Reset: game 1
const where = () => `room ${vcs.ram[0x0A].toString(16)} X ${vcs.ram[0x0B]} Y ${vcs.ram[0x0C]} | C64 room ${M[0x8A].toString(16)} X ${M[0x8B]} Y ${M[0x8C]}`;
const DIRS = { up: 0xEF, down: 0xDF, left: 0xBF, right: 0x7F };
for (const [name, joy] of Object.entries(DIRS)) {
  // room 3, the player at (80, 40); Yorgle dead on top of it; the sword to its left
  for (const [a, v] of [[0x8A, 3], [0xE2, 3], [0x8B, 80], [0xE3, 80], [0x8C, 40], [0xE4, 40],
    [0xA9, 3], [0xAA, 76], [0xAB, 50], [0xAD, 1], [0xB6, 3], [0xB7, 50], [0xB8, 40], [0x9D, 0xA2]]) poke(a, v);
  for (let f = 0; f < 6; f++) frame(0xFF);
  const before = where();
  for (let f = 0; f < 90; f++) frame(joy);
  let same = true;
  for (let a = 0x80; a <= 0xE6; a++) if (vcs.ram[a - 0x80] !== M[a]) same = false;
  console.log(`${name.padEnd(5)}: from ${before}  ->  ${where()}  (RAM ${same ? 'identical' : 'DIFFERENT'})`);
}
