// Testing aid: run the C64 version's ticks and Render as lockstep.js does, keeping the last
// instructions executed; when the program crashes (a BRK or a runaway) print where it went.
//   node games/adventure/tools/trace.js [frames] [--seed=N] [--teleport] [--every=N] [--noflicker] [--watch=address]
const { C64 } = require('./c64sim');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 1000);
const c64 = new C64();
c64.start(true);
const sym = n => c64.sym(n), M = c64.mem;
if (process.argv.includes('--noflicker')) M[sym('Flicker')] = 0;
const labels = [...c64.lst.matchAll(/^\.([0-9a-f]{4})\t.*?\t([A-Za-z_][A-Za-z0-9_]*)\b/gm)].map(m => [parseInt(m[1], 16), m[2]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xF000) return '2600'; let r = '?'; for (const [a, n] of labels) { if (a <= pc) r = `${n}+${pc - a}`; else break; } return r; };
const hist = [];
const watch = arg('watch', -1);
if (watch >= 0) { const w = c64.write.bind(c64); c64.write = function (a, v) { if ((a & 0xFFFF) === watch) console.log(`write ${v.toString(16)} to ${watch.toString(16)} at pc ${this.lastPc.toString(16)} ${labelOf(this.lastPc)}`); return w(a, v); }; }
const st = c64.step.bind(c64);
c64.step = function () { hist.push([this.pc, this.s]); if (hist.length > 60) hist.shift(); return st(); };
const play = require('./play')(arg('seed', 11), { teleport: process.argv.includes('--teleport'), every: arg('every', 0) });
let f = 0;
try {
  for (; f < frames; f++) {
    const p = play(f, M.subarray(0x80, 0x100));
    for (const [a, v] of p.poke) M[a] = v;
    M[0x0280] = p.swcha; M[0x0282] = p.swchb; M[sym('inpt4')] = p.fire ? 0 : 0x80;
    c64.call(sym('Tick'));
    M[sym('pending')] = 0;
    M[sym('curBuf')] ^= 1;
    c64.call(sym('Render'));
  }
  console.log(`${frames} frames, no crash`);
} catch (e) {
  console.log(`frame ${f}: ${e.message}`);
  for (const [pc, s] of hist) console.log(`  $${pc.toString(16)} ${labelOf(pc)} s=${s.toString(16)}`);
}
