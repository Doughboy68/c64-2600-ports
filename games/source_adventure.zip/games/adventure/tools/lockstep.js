// Run the C64 version's game ticks (the patched 2600 program plus kernel.asm, from
// build/adventure-<version>.prg) on a plain 6502 (tools/c64sim.js), side by side with the original
// game in tools/vcs.js, with the same inputs (tools/play.js). Once a frame both stop after
// the kernel: the game RAM must be identical, and the collision bits the C64 hands the game
// must be the model's (tools/model.js). Any difference is a bug. Also runs Render each frame
// and reports the cycles both take.
//   node games/adventure/tools/lockstep.js [frames] [--seed=N] [--teleport] [--ntsc] [--power=N] [--verbose] [--profile]
// --power=N: at frame N press F2 (power off and on) on the C64, and switch on a new 2600.
const { VCS } = require('../../../tools/vcs');
const { C64, rom } = require('./c64sim');
const { snap, model, cxReg } = require('./model');
const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); if (!a) return d; const v = a.split('=')[1]; return isNaN(+v) ? v : +v; };
const frames = +(process.argv[2] || 3000);
const verbose = process.argv.includes('--verbose');

const c64 = new C64();
c64.start(!process.argv.includes('--ntsc'));
const sym = n => c64.sym(n);
if (process.argv.includes('--noflicker')) c64.mem[sym('Flicker')] = 0;
const profile = process.argv.includes('--profile') ? {} : null;
const labels = [...c64.lst.matchAll(/^\.([0-9a-f]{4})\t.*\t([A-Z][A-Za-z0-9_]*):/gm)].map(m => [parseInt(m[1], 16), m[2]]).sort((a, b) => a[0] - b[0]);
const labelOf = pc => { if (pc >= 0xF000) return '2600 program'; let lo = 0, hi = labels.length - 1, r = '?'; while (lo <= hi) { const mid = (lo + hi) >> 1; if (labels[mid][0] <= pc) { r = labels[mid][1]; lo = mid + 1; } else hi = mid - 1; } return r; };
let frameProf = {}, worstRender = { cyc: 0 }, worstTick = { cyc: 0 };
if (profile) { const st = c64.step.bind(c64); c64.step = function () { const pc = this.pc, c = this.cycles; const r = st(); const k = labelOf(pc); profile[k] = (profile[k] || 0) + this.cycles - c; frameProf[k] = (frameProf[k] || 0) + this.cycles - c; return r; }; }

// ---- the original: stop once a frame at the kernel's start (for the model) and its end
let vcs, atEnd = false, kSnap = null;
const KERNEL = 0xF008, KERNEL_END = 0xF0D1;
const newVcs = () => {
  vcs = new VCS(rom);
  vcs.wideDelay = true;
  const origStep = vcs.step.bind(vcs);
  vcs.step = function () {
    if (this.pc === KERNEL) kSnap = snap(this);
    if (this.pc === KERNEL_END) atEnd = true;
    return origStep();
  };
};
newVcs();
const M = a => (a >= 0xF000 ? rom[a - 0xF000] : a >= 0x80 && a < 0x100 ? vcs.ram[a - 0x80] : 0);
const runToKernelEnd = () => { atEnd = false; let g = 0; while (!atEnd) { vcs.step(); if (++g > 2e6) throw new Error('2600 never reached the kernel'); } };

// The 2600's stack is RAM $E7-$FF (the C64 keeps the game's stack in page 1)
const RAMEND = 0xE6;
const NAMES = {};
for (const [a, n, size] of require('../2600/symbols.js').ram) for (let i = 0; i < size; i++) NAMES[a + i] = size > 1 ? `${n}+${i}` : n;
const CXBITS = [[2, 0x40, 'P0-ball'], [3, 0x40, 'P1-ball'], [4, 0x40, 'M0-ball'], [5, 0x40, 'M1-ball'], [6, 0x80, 'ball-PF'], [7, 0x80, 'P0-P1']];

const play = require('./play')(arg('seed', 11), { teleport: process.argv.includes('--teleport'), every: arg('every', 0) });
let lastDrop = 0, dropShown = 0;
let bad = 0, cxBad = 0, done = 0, maxTick = 0, totalTick = 0, maxRender = 0, totalRender = 0;
const diffCount = {}, cxSeen = {}, rooms = new Set();
const powerAt = arg('power', -1);
for (let f = 0; f < frames; f++) {
  if (f === powerAt) {
    c64.call(sym('PowerCycle'));
    newVcs();
    console.log(`frame ${f}: power off and on`);
  }
  const p = play(f, vcs.ram);
  for (const [a, v] of p.poke) { vcs.ram[a - 0x80] = v; c64.mem[a] = v; }
  vcs.swcha = p.swcha; vcs.swchb = p.swchb; vcs.fire[0] = vcs.fire[1] = p.fire;
  c64.mem[0x0280] = p.swcha; c64.mem[0x0282] = p.swchb; c64.mem[sym('inpt4')] = p.fire ? 0 : 0x80;
  runToKernelEnd();
  frameProf = {};
  const cyc = c64.call(sym('Tick'));
  if (profile && cyc > worstTick.cyc) worstTick = { cyc, f, prof: { ...frameProf } };
  maxTick = Math.max(maxTick, cyc); totalTick += cyc;
  c64.mem[sym('pending')] = 0;                    // draw it, as the main loop would
  c64.mem[sym('curBuf')] ^= 1;                    // (and show it)
  frameProf = {};
  const rc = c64.call(sym('Render'));
  if (f === arg("dump", -1)) { const b = c64.mem[sym('curBuf')] ^ 1; console.log('sprites', [...Array(8)].map((_, n) => [c64.mem[sym('StX') + 8 * b + n], c64.mem[sym('StY') + 8 * b + n], c64.mem[sym('StPtr') + 8 * b + n]].join('/')).join(' '), 'en', c64.mem[sym('StEn') + b].toString(2), 'msb', c64.mem[sym('StMsb') + b].toString(2)); } if (f === arg("dump", -1)) console.log('frame', f, 'render', rc, ['kP0x','kP0q','kP0k','kP0n','kP1x','kP1q','kP1k','kP1n','kP1m','kBk','kBn'].map(n => n + ' ' + c64.mem[sym(n)]).join(', '), 'obj0', c64.mem[0x95].toString(16), 'obj1', c64.mem[0x96].toString(16), 'room', c64.mem[0x8a].toString(16), 'P0Y', c64.mem[0x87], 'P1Y', c64.mem[0x89]);
  if (profile && rc > worstRender.cyc) worstRender = { cyc: rc, f, prof: { ...frameProf } };
  maxRender = Math.max(maxRender, rc); totalRender += rc;
  if (c64.mem[sym('DbgDrop')] !== lastDrop) { lastDrop = c64.mem[sym('DbgDrop')]; if (verbose || dropShown++ < 5) console.log(`frame ${f}: sprite dropped (room ${c64.mem[0x8a].toString(16)}, objects ${c64.mem[0x95].toString(16)} ${c64.mem[0x96].toString(16)}, sprites used ${c64.mem[sym('sprN')]}, P0 rows ${c64.mem[sym('kP0n')]} quad ${c64.mem[sym('kP0q')]}, P1 rows ${c64.mem[sym('kP1n')]}+${c64.mem[sym('kP1m')]} quad ${c64.mem[sym('kP1q')]})`); }
  done++;
  // the collisions
  const res = model(kSnap, M);
  const cxd = [];
  for (const [r, bit, name] of CXBITS) {
    const want = cxReg(res.cx, r) & bit, got = c64.mem[0x30 + r] & bit;
    if (want !== got) cxd.push(`${name} model ${want ? 1 : 0} C64 ${got ? 1 : 0}`);
  }
  for (const [r, bit, name] of CXBITS) if (c64.mem[0x30 + r] & bit) cxSeen[name] = (cxSeen[name] || 0) + 1;
  rooms.add(vcs.ram[0x0A]);
  if (cxd.length) { cxBad++; if (cxBad <= 5 || verbose) console.log(`frame ${f}: collisions: ${cxd.join(', ')}`); }
  const diffs = [];
  for (let a = 0x80; a <= RAMEND; a++) if (vcs.ram[a - 0x80] !== c64.mem[a]) {
    diffs.push(`${NAMES[a] || '$' + a.toString(16)} 2600 ${vcs.ram[a - 0x80].toString(16)} C64 ${c64.mem[a].toString(16)}`);
    diffCount[a] = (diffCount[a] || 0) + 1;
  }
  if (diffs.length) {
    bad++;
    if (bad <= 5 || verbose) console.log(`frame ${f} (room ${vcs.ram[0x0A].toString(16)}): ${diffs.join(', ')}`);
    for (let a = 0x80; a <= RAMEND; a++) c64.mem[a] = vcs.ram[a - 0x80];   // resync and carry on
  }
}
if (bad) console.log('bytes that differed (frames):', Object.entries(diffCount).map(([a, n]) => `${NAMES[a] || '$' + (+a).toString(16)} ${n}`).join(', '));
console.log("collision bits set (frames):", JSON.stringify(cxSeen), "rooms seen:", rooms.size);
const dbg = ['DbgDrop', 'DbgOdd'].map(n => `${n} ${c64.mem[sym(n)]}`).join(', ');
const top = pr => Object.entries(pr).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => `${k} ${v}`).join(', ');
if (profile) console.log(`worst tick: frame ${worstTick.f}, ${worstTick.cyc} cycles: ${top(worstTick.prof)}`);
if (profile) console.log(`worst render: frame ${worstRender.f}, ${worstRender.cyc} cycles: ${top(worstRender.prof)}`);
console.log(`${done} frames, ${bad} with RAM differences, ${cxBad} with collision differences; C64 tick ${Math.round(totalTick / done)} cycles on average, ${maxTick} at most; render ${Math.round(totalRender / done)} on average, ${maxRender} at most; ${dbg}`);
process.exit(bad || cxBad ? 1 : 0);
