// Quick runner: boot the ROM, optionally press Game Reset, step frames, save a screenshot.
//   node games/adventure/tools/run.js <frames> [out.png] [--reset] [--joy=RLDU-bits-hex]
const { VCS } = require('../../../tools/vcs');
const vcs = new VCS(require('../../../tools/rom').load('157bddb7192754a45372be196797f284'));
let lines = 0;
vcs.onFrame = v => { lines = v.line; };
const frames = +(process.argv[2] || 60);
const opt = k => (process.argv.find(a => a.startsWith(`--${k}=`)) || '').split('=')[1];
if (process.argv.includes('--reset')) {
  vcs.runFrames(10);
  vcs.swchb &= ~1; vcs.runFrames(5); vcs.swchb |= 1;   // press and release Game Reset
}
if (opt('joy')) vcs.swcha = parseInt(opt('joy'), 16);
vcs.runFrames(frames);
console.log('frames', vcs.frames, 'lines/frame', lines, 'cycles', vcs.cycles);
const hex = b => [...b].map(x => x.toString(16).padStart(2, '0')).join(' ');
for (let i = 0; i < 128; i += 16) console.log((0x80 + i).toString(16), hex(vcs.ram.subarray(i, i + 16)));
const out = process.argv.slice(3).find(a => !a.startsWith('--'));
if (out) { vcs.savePNG(out); console.log('saved', out); }
