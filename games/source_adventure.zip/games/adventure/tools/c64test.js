// Scripted play test of the C64 build in VICE (through the remote monitor, on a port of its
// own; only the VICE started here is closed): the game number screen, fire to start, then
// walking about, with screenshots.
//   node games/adventure/tools/c64test.js <outdir> [seconds-of-play] [--ntsc] [--keep] [--room=N,...]
// --room=N,...: jump to these rooms (2600 RAM $8A) one after another, a screenshot in each.
// --crowd: put three dragons, the sword and the bridge in the first room; screenshots with
// flicker on and off (key 6).
const fs = require('fs');
const net = require('net');
const path = require('path');

const out = path.resolve(process.argv[2] || '.');
const playSeconds = +(process.argv[3] || 10);
const ntsc = process.argv.includes('--ntsc');
const keep = process.argv.includes('--keep');
const roomsArg = (process.argv.find(a => a.startsWith('--room=')) || '').slice(7);
const root = path.join(__dirname, '..');
const prgFile = require('../../../tools/buildname').files(path.join(root, 'build')).prg;
const lst = fs.readFileSync(require('../../../tools/buildname').files(path.join(root, 'build')).lst, 'latin1');
const addr = name => {
  const m = lst.match(new RegExp(`^[.>]([0-9a-f]{4})[ \\t].*?\\b${name}(?::|[ \\t]+\\.)`, 'm'));
  if (!m) throw new Error('no label ' + name);
  return m[1];
};
const A = { swcha: addr('DbgSWCHA'), inpt4: addr('DbgINPT4'), swchb: addr('DbgSWCHB'), flicker: addr('Flicker') };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const { freePort, runsOurs, startVice, stopVice } = require('../../../tools/vicemon');
let vice = null, PORT = 0;

function mon(cmds) {
  return new Promise((resolve, reject) => {
    const sock = net.connect(PORT, '127.0.0.1');
    let buf = '';
    sock.on('data', d => { buf += d.toString('latin1'); });
    sock.on('error', reject);
    sock.on('connect', async () => {
      await sleep(150);
      for (const c of cmds) { sock.write(c + '\n'); await sleep(c.startsWith('screenshot') ? 1200 : 150); }
      sock.write('x\n');
      await sleep(100);
      sock.end();
      resolve(buf.replace(/\(C:\$[0-9a-f]{4}\) /g, ''));
    });
  });
}
const poke = (a, v) => mon([`> ${a} ${v}`]);
const shot = name => mon([`screenshot "${path.join(out, name).replace(/\\/g, '/')}" 2`]);

(async () => {
  fs.mkdirSync(out, { recursive: true });
  PORT = await freePort();
  vice = startVice(['-default', ...(ntsc ? ['-ntsc'] : []), '+sound', '-remotemonitor', '-remotemonitoraddress', `ip4://127.0.0.1:${PORT}`, '-autostartprgmode', '1', '-autostart', prgFile]);
  await sleep(6000);
  if (!await runsOurs(mon, prgFile)) throw new Error(`the VICE on port ${PORT} isn't running our build: stopping`);
  await sleep(1000);
  await shot('t0-number.png');
  await poke(A.inpt4, '7f'); await sleep(400); await poke(A.inpt4, 'ff');   // fire: start a game
  await sleep(1500);
  await shot('t1-start.png');
  if (process.argv.includes('--crowd')) {
    // Rhindle, Yorgle, Grundle (room, X, Y), the sword and the bridge, in room $11
    await mon(['> a4 11 20 40', '> a9 11 40 50', '> ae 11 70 30', '> b6 11 60 20', '> bc 11 30 18']);
    await sleep(300);
    for (let i = 0; i < 4; i++) { await shot(`t2-crowd-flicker${i}.png`); await sleep(50); }
    await poke(A.flicker, '0');
    await sleep(500);
    for (let i = 0; i < 2; i++) { await shot(`t2-crowd-noflicker${i}.png`); await sleep(50); }
  }
  if (roomsArg) {
    for (const r of roomsArg.split(',')) {
      await mon([`> 8a ${(+r).toString(16)}`, `> e2 ${(+r).toString(16)}`]);
      await sleep(800);
      await shot(`t2-room${String(r).padStart(2, '0')}.png`);
    }
  }
  let seed = 1;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const t0 = Date.now();
  let n = 0;
  const DIRS = ['7f', 'bf', 'ef', 'df', 'ff'];
  while (Date.now() - t0 < playSeconds * 1000) {
    await poke(A.swcha, DIRS[Math.floor(rnd() * DIRS.length)]);
    await sleep(700);
    if (++n % 3 === 0) await shot(`t3-play${String(n / 3).padStart(2, '0')}.png`);
  }
  await poke(A.swcha, 'ff');
  await shot('t4-end.png');
  if (!keep) { await sleep(300); stopVice(vice); }
})().catch(e => { console.log(e.message); stopVice(vice); });
